# Research Paper — External service labels — bounded recheck, 5 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The three destinations have public exchange/service associations of unequal evidentiary strength. **No direct authenticated declaration from Bittrex, Binance or NEMChange naming the queried address was recovered in this bounded search.** Keep the chain's observed addresses as the primary labels and service names as qualified annotations. No personal owner was assigned.

| Observed destination | Public association | Assessment |
|---|---|---|
| `ND2JRPQIWXHKAA26INVGA7SREEUMX5QAI6VU7HNR` | Bittrex | **Historically corroborated, not directly authenticated by the exchange.** DIMCOIN's own historical payout announcement explicitly pairs this address with Bittrex. A 2018 developer report reproduces a Bittrex API currency response identifying it as XEM's `BaseAddress`. |
| `NC64UFOWRO6AVMWFV2BFX2NT6W2GURK2EOX6FFMZ` | Binance | **User/community attribution, unverified by the service in reviewed material.** Multiple historical users call it their Binance deposit address. NEM's official exchange-integration examples include it but never identify Binance. |
| `NDOYB24G46N53HYTCP66Q5K4RYT4XFWKDW4CM3DI` | NEMChange | **Plausible service association, exact address attribution unverified.** A third-party NEM account list labels it NemChange. The parent investigation's `166NEMCHANGEDOTCOM166` payment reference fits a deposit-message pattern, but a sender's reference is not the service's declaration. |

## Bittrex evidence

[DIMCOIN announcement](https://medium.com/welcome-to-dimcoin/dim-announcement-dd38006e5e59) is the publishing project's primary statement about its own payout handling. Its exchange-address list includes the exact ND2JRP destination next to Bittrex. It is independent public corroboration of the historical label, but DIMCOIN is not Bittrex. The same list labels a *different* account `NANOXGYIH52QCQEMEP5LAF36UMVT3JFCWNGWENCB` as NEMChange; that account has not been equated with NDOYB or added to the project graph.

[CCXT issue 3511, July 2018](https://github.com/ccxt/ccxt/issues/3511) contains pasted verbose exchange API output. In a currency record, `Currency` is XEM, `CurrencyLong` is NEM and `BaseAddress` is the exact ND2JRP address. The retrieved issue JSON is preserved in *Historical file: ccxt-3511.json*, with an extracted local context file. This is a developer-published copy of an API response, not a newly authenticated response from the old Bittrex service.

## Binance evidence

[NEM official transaction examples](https://docs.nem.io/pages/Exchanges/integration/examples/docs.en.html) contain NC64UF as a multisignature transfer recipient. That directly confirms its use as an example address; it does not name the service that controlled the address.

Two historical support sources associate the exact destination with Binance: [April 2018 report](https://forum.nem.io/t/lost-withdrawal-nem-without-message-moved/16192) and [March 2021 report](https://forum.nem.io/t/i-didn-t-get-xem-on-binance-when-i-sent-coins/28611). They are customers' statements, not Binance records. Unrelated people's public financial disclosures and donation lists were not used for identification.

## NEMChange evidence and deposit-message significance

The [operator's own January 2018 launch thread](https://forum.nem.io/t/nemchange-com-mosaic-exchange-ico-platform-open-beta/13368) establishes a NEM mosaic exchange and ICO platform in development. In March, the operator says sending a mosaic to the exchange address would list it. This source establishes the service's claimed function, but does not give NDOYB as its address.

A [June 2018 first-person Cache tutorial](https://forum.nem.io/t/how-to-exchange-cache-and-other-mosaics-on-nemchange/17293) includes a screenshot of NEMChange's deposit instructions: a shared address plus a mandatory unencrypted message, with balances and open orders handled inside the service. The retrieved screenshot deliberately blurs the particular address and message, so neither was recovered or guessed. It corroborates the mechanism, not the precise NDOYB assignment.

The [third-party NEM 10k account list](https://nemnodes.org/richlist10k/) labels NDOYB as NemChange; the source does not supply an operator-signed declaration or its attribution method. A current archive-index query was also captured. The bounded retrieval did not recover a historical service page giving this exact destination.

The chain reference `166NEMCHANGEDOTCOM166` may identify an internal deposit account if the service confirms its format. The repeated reference and address should be retained in the evidence ledger as literal transaction fields. They do not authenticate an internal account holder, establish that a trade completed, show what asset was purchased, or prove fiat withdrawal. This follow-up does not establish KID was listed or traded at NEMChange.

## Graph treatment

Use annotations such as **ND2JRP — historical Bittrex attribution (corroborated)**, **NC64UF — reported Binance destination (unverified)** and **NDOYB — possible NEMChange destination**. Transfers into a shared exchange address can belong to different customer accounts; the same endpoint is not a common-owner link. Money sent to an exchange remains a deposit observation, not proof of sale or cash-out.

Captured source files are under `full-history/external-sources/`, with URL, retrieval-time and SHA-256 sidecars for direct downloads. The Medium page was readable via the web research tool; a direct HTML download returned 403 and is not represented as a preserved original file.
