# Research Paper — > Preservation note: this memo records its stage of the investigation. The consolidated report and collector supplements supersede former incoming-flow gaps and earlier coverage totals. The ETH-related counter identified in QA has been corrected. Exact continuity is not proof of exclusive balances or uniquely identified fungible token units.

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

# Kaskade collector inbound reconciliation supplement

Observed 5 September 2026. This bounded follow-up resolves the two incoming-token gaps identified in the independently reviewed nine-wallet reconstruction. The original 326-receipt dataset and its calculations remain unchanged; this supplement adds three individually verified incoming LUSD receipts.

## April 17: exact source of the additional 1,617.058452519882063872 LUSD

Collector `0x425e16a88a0dAcc38424B7d1F60868d728b46168` received two additional transfers outside the original nine-address sample:

| UTC timestamp | Sender | LUSD received | Successful receipt / block |
|---|---|---:|---|
| 2024-04-17 14:54:59 | `0x64bc278b28DCdfC2F1cB2f90dc62e03e02D2f09a` | 807.403300464772513792 | [19675922](https://etherscan.io/tx/0x601d0155d8edfcf11b7483b1035a4907001c1f9ba597c552a4e73dee2043e37f) |
| 2024-04-17 14:57:11 | `0x0ad9f1027a77519f3D6eD6Aeeb24cf6e76c774A6` | 809.65515205510955008 | [19675933](https://etherscan.io/tx/0x5fdffda80dea1aff83585a26a5c9cfdbb69183162738b2166960fb255d30c54a) |

Their sum is **1,617.058452519882063872 LUSD**. Added to the eight previously verified April 17 claims of **3,968.390622853786468352 LUSD**, this gives **5,585.449075373668532224 LUSD**, exactly the collector's [15:03:23 conversion input](https://etherscan.io/tx/0x68463eae0fdba055af3c3c31fa5d8cbcadbd21523182f4ded110d8002e0d8df7).

This resolves the unexplained conversion amount through two actual incoming transfers. It does not establish where those two senders originally obtained the LUSD or identify their owners. Their earlier claim/trading histories were not opened in this bounded follow-up. The verified original nine-address reward total therefore remains **21,944.778215493719293952 LUSD**; do not add these inbound transfers as newly proven rewards without verifying their source.

## April 24: exact return of the previously forwarded reward total

The observed sequence is now complete for the questioned amount:

| UTC timestamp | Movement | Quantity | Receipt |
|---|---|---:|---|
| 16:55:35 | Collector4E958 → external3ac0030a | 8,285.027398394077806592 LUSD | [outward](https://etherscan.io/tx/0xfab7c4bf93deb33f611a6180eba41e03a9284029a7f98ef59645fcb35fdf0b18) |
| **16:57:23** | **External3ac0030a → collector4E958** | **8,285.027398394077806592 LUSD** | **[newly verified return](https://etherscan.io/tx/0xe537e084ff562ffe638015c9a1af38f5d911a9f914068b36a839cbfbfc5fee3a)** |
| 16:58:11 | Collector4E958 swaps returned LUSD | 8,285.027398394077806592 LUSD → 8,280.806398 USDC | [conversion](https://etherscan.io/tx/0xfc863e0b4accb05ce479fe3464ffa5c4c6f0a4d983b4b2509ca25b520ff99283) |
| 16:58:47 | Collector4E958 → external3ac0030a | 8,280.806398 USDC | [final forward](https://etherscan.io/tx/0x26ccb436b5e216974cabe40feec2acf2b4f0f656a9d3565d2ea7ae51482adca7) |

Collector4E958 is `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b`; external3ac0030a is `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF`. The exact LUSD returned **108 seconds** after the outward transfer and **48 seconds** before conversion. The new return receipt succeeded in block **19726566**, using canonical LUSD contract `0x5f98805A4E8be255a32880FDeC7F6728C6568bA0`, and cost **0.000706656759470464 ETH**.

The repeated movement is now reconciled; it is one reward amount routed out, back, converted, and forwarded as USDC. Count reward income once. These transfers establish public financial links, not human ownership or a separate criminal offense.

## Preservation and scope

Discovery used the collectors' ordinary [425e token list](https://etherscan.io/tokentxns?a=0x425e16a88a0dacc38424b7d1f60868d728b46168&ps=100) and [4E958 token list](https://etherscan.io/tokentxns?a=0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b&ps=100), displaying 91 and 96 transfer rows respectively. Default explorer settings hide zero-value and flagged suspicious/spam transfers; those settings were not altered. All three new receipt hashes, UTC timestamps, exact amounts, source/recipient pairs and canonical LUSD token links were verified. Current explorer dollar annotations were excluded.

Files: `kaskade_collector_inbound_supplement_raw.json`, `kaskade_collector_inbound_supplement_decoded.json`, and `calculate_kaskade_collector_inbound.py`. Run the Python script alongside the original decoded claim/swap/transfer files to reproduce the amount and time reconciliations. This supplement resolves the two specific former gaps, without claiming complete incoming history for every wallet or expanding the original nine-wallet trading coverage.
