# Research Paper — SCR Advisors Limited registration-number hunt

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Research date: 6 September 2026 UTC. Intermediate research notes.

## Outcome

No exact Gibraltar registration number was independently retrieved. Do not substitute the separate UK company SIMPSON CONSULTING & RESEARCH LTD number 11267241, Companies House Gibraltar itself number 47937, US SCR advisers, or Spanish SCR fund identifiers.

The substantive identity source remains the 3 November 2020 incorporation of UK LAUNCH POOL LTD, company 12992979, which names SCR ADVISORS LIMITED with 11 of 100 shares and a Gibraltar business correspondence address, 5 Secretary's Lane. This identifies a named shareholder, not the shareholder's own registry number or owner.

## Search coverage

Both public search engines checked exact-name variants (SCR ADVISORS LIMITED, SCR ADVISORS LTD, S.C.R. Advisors, SCR Advisers) and Gibraltar official-domain, Gazette, legal-identifier and registration-number combinations. No reliable exact-company identifier surfaced. Search fallbacks returned irrelevant SCR-token, UK regulatory abbreviation, Spanish investment fund, US adviser, and design-mockup results; none accepted as identity evidence.

Direct GLEIF API request was attempted at https://api.gleif.org/api/v1/lei-records?filter%5Bentity.legalName%5D=SCR+ADVISORS&page%5Bsize%5D=100, but the request did not return a response. It is an unperformed lookup, not a no-record result. No access control was bypassed.

## Official records route reverified

1. Official eRegistry information https://www.companieshouse.gi/login.html (web ref historical retrieval) explicitly requires paid subscription for online searches. The individual profile service is a separate access route.
2. Official Company Profile guidance, updated August 2025: https://www.companieshouse.gi/publications/C0008.pdf (historical retrieval). Any member of the public may request a profile. It lists registration number, incorporation date, status, registered office, share capital, recorded shareholders/directors/secretary, charges and filing dates. Standard GBP20.50; following working day; may be delivered as emailed PDF. Certified GBP25.50 requires collection or post.
3. Official request form https://www.companieshouse.gi/publications/Profiles.pdf (historical retrieval) explicitly asks registration numbers IF KNOWN. Number is therefore not a prerequisite. The form can identify the company by full name when its registration number is unknown. No order or contact was made; access requirements and prices remain historical observations.
4. Guidance5, updated August2025, https://www.companieshouse.gi/publications/C0005.pdf (historical retrieval), confirms annual returns include shareholders and directors. Current profile does not prove 2020 ownership; after identity match, historical annual returns and changes of members around 3 November2020 are the relevant next documents.

Existing downloaded originals are in research/followup_scr, with SOURCE_RECEIPTS.json. Those were not duplicated here.
