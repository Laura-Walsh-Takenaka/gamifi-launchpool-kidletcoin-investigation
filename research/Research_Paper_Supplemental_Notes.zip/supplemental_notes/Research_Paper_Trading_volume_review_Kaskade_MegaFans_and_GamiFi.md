# Research Paper — Trading-volume review: Kaskade, MegaFans and GamiFi

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Reviewed 5 September 2026 UTC. This supplements the earlier company reviews with transaction reconstruction, recovered leaderboard evidence and fixed-block pool checks. Historical activity is dated separately from present observations.

**Kaskade has concrete evidence of rapid capital recycling and concentrated leaderboard activity. Comparable artificial-volume evidence was not established for MegaFans or GamiFi. None of the checked wallets or trading instructions has been attributed to Laura Walsh / Laura Takenaka.**

| Project / market | What this review establishes | What remains unproved |
|---|---|---|
| Kaskade / April 2024 LUSD campaign | Nine consecutive swaps reuse exact preceding outputs; four complete round trips; eight ETH transfers connect nine leading wallets; token distributions to the reconstructed trader | Common beneficial ownership, whole-campaign artificial-volume percentage, distributor operator, illegality or Laura's involvement |
| Kaskade / March 2024 Redacted campaign | Published volume-based incentives; stronger reported gross fee recovery than the LUSD campaign; possible overlap with Laura's reported tenure | Independent campaign-wide reconciliation, recurring trading loops, durable liquidity gains or personal authorization |
| MegaFans / MBUCKS | Genuine PancakeSwap pair, fixed-block reserves and three sampled swap transactions, including its matched latest reserve update | Repeated round trips, fabricated published volume, complete exchange trading history |
| GamiFi / GMI | Genuine PancakeSwap pair, fixed-block reserves and separately classified swaps and token payments | Historical wash-trading pattern, current market-wide volume or personal direction |

**Kaskade: the same capital was repeatedly turned over.**

On 20 April 2024, address `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` executed nine consecutive USDC/LUSD swaps. Every output from swaps 1–8 exactly equals the next swap's input, including token decimals. The first eight complete four USDC→LUSD→USDC loops; the ninth ends in LUSD. These are successful public Ethereum records inspected through Etherscan. The sequence starts with [swap 1](https://etherscan.io/tx/0x66e91ec0018193397cfd98a2e7ed941f61c90e2a76d11d8f1891e0ed635432dd), reverses in [swap 2](https://etherscan.io/tx/0xb41b25cef02424ec43c872307d746ba76b522f0c6d7bc7b46c97d53ca84e3d1a), completes its fourth loop at [swap 8](https://etherscan.io/tx/0xe67ac3a8c799d7c8013dfd7c4281890e5111e76fc1f36791305e25c1ad67bbd3), and ends with [swap 9](https://etherscan.io/tx/0x9e7b5b2f587afb617704778508850dccd07d8cffdb18b990b368c98da562f63a). The evidence archive contains all nine exact records.

| Recalculated measure | Result |
|---|---:|
| Initial capital deployed | 30,281.192454 USDC |
| Returned after four complete loops | 30,208.594924 USDC |
| Four-loop duration | 204 seconds / 3 minutes 24 seconds |
| Four-loop USDC shortfall, before gas | 72.597530 USDC |
| Gas for those eight swaps | 0.019105787240709009 ETH |
| Nine-swap duration | 312 seconds / 5 minutes 12 seconds |
| Sum of nine swap inputs | 272,237.315765355903132629 nominal stablecoin units |
| Input turnover / initial capital, under equal token valuation | 8.9903103× |

Valuing both stablecoins at $1 gives approximately **$272,237 of turnover from $30,281 initially deployed**. This is an explicit valuation assumption, not a historical USD price reconstruction. It demonstrates why gross volume cannot be read as new money entering a project, revenue or independent customer demand. The trades themselves executed and incurred costs; capital recycling does not mean the transaction records were invented.

One minute after swap 9, the wallet [transferred its exact 30,207.867080991279108779 LUSD output](https://etherscan.io/tx/0xdfae4f391d2451cf88237717943caaa0a73ac57c203e0258512f8ba1a73feb52) to leaderboard wallet `0x9D383…A97D`. It then [sent that wallet ETH](https://etherscan.io/tx/0xb9093c9f721e0a5e7b3b8bfea6704e56066e01d30dd508f5f841052704b0aa7c). This establishes a principal transfer between two participants. The complete later trading history of the recipient was not reconstructed.

**Nine leading wallets are connected by verified transfers.**

The partner's public receipts sheet identifies eight ETH transfers joining nine of Week 2's top ten addresses. All eight transaction pages were checked. The arrows below mean successful native-ETH transfers during 20–24 April 2024; they do not mean proven common ownership. Full addresses, amounts, timestamps and transaction links accompany the archive's six-transfer table and Kaskade reconstruction.

```mermaid
flowchart TD
    C["4E958…C65b"] --> A["cfC2…B455"]
    C --> E["52Af…2f5d"]
    C --> F["7737…d122"]
    C --> D["425e…6168"]
    A --> B["9D383…A97D"]
    B --> G["9B054…EbDA"]
    F --> H["97592…Ed47"]
    D --> I["68d3…7F2f"]
```

Recalculation from the partner-published historical leaderboard image gives **$1,963,490.77** volume for those nine addresses out of **$2,329,011.36** displayed top-ten volume: **84.3058%**. Their displayed point shares instead sum to **82.85%**; those are different measures. The exact image capture time and historical backend export were not recovered. [Public receipts sheet — publisher campaign report](https://deficollective.org/blog/kaskade-campaign-report/); [leaderboard image](https://raw.githubusercontent.com/deficollective/deficollective.github.io/main/assets/images/kaskade-campaign-report/image1.png).

**84.3% applies only to the displayed top-ten volume.** It is neither a proven wash-trading share of the full campaign nor the percentage of incentives actually paid to the group. Transfers support financial connectedness; one address's reconstructed loops do not prove identical behavior by all nine.

The DeFi Collective's May 2 report calls the behavior wash trading and infers a single trader behind the addresses. Our transaction checks corroborate the links and example loops, but do not independently establish that ownership inference or concealment intent. The partner also reports that Kaskade reviewed its draft. [Partner outcome report](https://deficollective.org/blog/kaskade-campaign-report/).

**Actual distributions were received, with an attribution limit.**

The reconstructed wallet also received the following LUSD amounts from `0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B`. Each exact amount was forwarded to another leaderboard wallet within 24–72 seconds.

| Claim date, 2024 UTC | LUSD received | Subsequent recipient |
|---|---:|---|
| [April 17](https://etherscan.io/tx/0x100eabbf75e5dbbba6bbfb66dfeeb1a6fb3638fcd09371f71c115f507b597ed9) | 386.799056455249362944 | 425e…6168 |
| [April 24](https://etherscan.io/tx/0x502e4215d33af4817f95b57ef2b0ee6aaf246c78384bc71b010e75e63755538b) | 1,170.2736549072093184 | 4E958…C65b |
| [May 1](https://etherscan.io/tx/0x98878c870617ac53d0670030fd7c87bac6057b827edd827e8b0212c220b84205) | 913.743550266616578048 | 4E958…C65b |
| **Total** | **2,470.816261629075259392** | |

The April 24 payment equals 11.702736549…% of 10,000 LUSD, matching the displayed 11.70% Week 2 share after rounding. This strongly corroborates campaign attribution for that payment. Weekly dates and a shared distributor support the broader connection, but its generic MerkleDistributor code label does not identify its operator. April 17 precedes the reconstructed April 20 trades. No net-profit figure is inferred by subtracting one day's sample costs from three weeks of distributions. [Distributor contract page](https://etherscan.io/address/0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B#code).

**The campaign's own disclosures partly acknowledge the problem.**

Kaskade reports $12.02 million volume, $30,000 incentives and $5,601 direct LP fees for April 10–May 1. Direct fee recovery is **18.67%**, leaving a **$24,399** incentive-minus-fee gap. These are independently recalculated ratios of company-reported totals, not independently rebuilt totals or corporate losses. Kaskade acknowledged farmers/whales, weak fee recovery and uncertain causes of liquidity growth, while presenting activity as support for its model. Its volume-based rewards and multipliers made repeated turnover potentially attractive. Durable activity after incentives ended was not established. [Company retrospective](https://medium.com/@KaskadeFinance/kaskade-x-liquity-campaign-analysis-a0f0d48ee97f).

Two corrections also matter when relying on criticism: the exact nine swaps took **5m12s**, rather than under five minutes; and the partner's printed reward-per-$1,000 formula divides by 1,000 where it must multiply. Its stated approximate $4.27 rate is consistent with the corrected formula. Its separate profitability illustration uses different trade amounts from our reconstruction. None should be silently combined into one verified profit calculation. [Partner report](https://deficollective.org/blog/kaskade-campaign-report/).

The leaderboard's $272,419.78 for this wallet differs from our approximately $272,237.32 assuming both tokens equal $1. Historical pricing, attribution rules and exact screenshot timing remain unresolved; this small difference is not established false reporting.

**The earlier Redacted campaign needs a separate judgment.**

Kaskade dates that program **March 18–April 7, 2024**, using a BTRFLY/WETH Uniswap V3 pool with a 1% fee tier and volume-proportional rewards. It reports $3.2 million turnover, $32,000 fees and rewards worth $21,393 when distributed, against an original $30,000 allocation. Those figures imply gross fee-to-incentive ratios of **149.58%** using distribution value or **106.67%** using the original budget. Neither establishes sponsor profit: fee recipients, token-price changes, other costs and indirect effects matter. Reported liquidity growth was minimal and sustained post-campaign activity untested. No repeating transaction sequence was independently verified for this campaign. [April 26 company analysis](https://medium.com/@KaskadeFinance/kaskade-x-redacted-campaign-analysis-f169098f970f).

Laura was contemporaneously identified as Kaskade CMO on March 8, and her indexed profile dates the role through March 2024. A March 18 launch therefore **may overlap her tenure**; the exact departure day is unknown. The April 20 loops occur after that stated end month. Neither timing establishes authorship, approval or wallet control. [March 8 podcast account](https://www.moneyneversleeps.ie/farcaster-digital-identity-decentralized-social-media/); [self-reported professional profile](https://ca.linkedin.com/in/lauralwalsh).

The March 13 gas-rebate announcement makes greater trading activity relevant to rebate eligibility, but supplies no exact formula, threshold, cap or round-trip exclusion in that article. No anti-farming implementation was validated. This is a disclosure and verification gap, not proof that no controls existed or rebates went unpaid. [Gas-rebate announcement](https://medium.com/@KaskadeFinance/gas-fee-rebates-187061a6ed57).

**MegaFans and GamiFi: real pools confirmed; manipulation not established.**

Both identified markets are BNB Smart Chain PancakeSwap V2 pairs. The documented factory's `getPair(token,WBNB)` independently returned each pair. Read-only RPC responses preserve exact block numbers, token identities, reserves and historical transaction receipts. [Official factory addresses](https://developer.pancakeswap.finance/contracts/v2/addresses); [factory read functions](https://developer.pancakeswap.finance/contracts/v2/factory-v2); [BNB public RPC documentation](https://docs.bnbchain.org/bnb-smart-chain/developers/wallet-configuration/).

| Fixed-block field | MegaFans / MBUCKS | GamiFi / GMI |
|---|---|---|
| Token | `0x3638fea0c645b1aa79db706fab6e8a761385c390` | `0x93d8d25e3c9a847a5da79f79ecac89461feca846` |
| Pair | `0x5282c0ea15348dfa64a8a2690e0cb770e56a72dc` | `0x58d4b61983ca0afe6e352e90719f403e24e016f4` |
| Observation block | 120,142,920 | 120,144,015 |
| September 5, 2026 observation UTC | 16:30:56 | 16:39:10 |
| Token reserve, rounded | 7,834,273.576714 MBUCKS | 264,515,119.841511 GMI |
| WBNB reserve, rounded | 9.522022017 | 0.844195682 |
| Stored reserve-update UTC | August 20, 2026 06:11:55 | August 10, 2026 16:05:30 |

These describe particular pools at particular blocks. They are not current dollar valuations, aggregate exchange volume, ownership concentration or proof that the entire token market was inactive. Pool inventory belongs to the liquidity mechanism; it is not evidence of one person's token holdings.

For **MBUCKS**, three successful sampled transactions were decoded, dated July 29, 2024; November 15, 2024; and August 20, 2026. The November receipt includes a liquidity burn and a distinct swap, which must be counted separately. The August transaction's reserve update exactly matches the September snapshot. Its swap sells **2,432 MBUCKS** for **0.002949454917464755 WBNB**. Three token-transfer events total **5,120 MBUCKS** because tokens move through intermediate addresses. Summing transfers would inflate measured input to approximately 2.1053× the actual swap input, a 110.53% overstatement, but **no evidence shows MegaFans or an index used that faulty method**. No buy/sell loop was established by these examples. [July receipt](https://bscscan.com/tx/0x7a6fa7044e1279088e5e2a66336ffb6baeaa6944383951afda6802a0bcb43054); [November receipt](https://bscscan.com/tx/0x7b0b2cb8751d406444580cef5a1f653354c64c35d7ecb231a94dfbd234e7bf7e); [August receipt](https://bscscan.com/tx/0xb8b46f88394e8f77e86363c691e6cdec73e493523f6999b35552a96b2b4d36d9).

For **GMI**, the April 17, 2026 sample sells **174.453334004017548483 GMI** for **0.000000556858842504 WBNB**. Two other retrieved receipts, June 6 and December 14, 2022, contain token payments without matching pool Swap events. They cannot be relabeled as trading volume merely because tokens moved. This small, purposefully selected sample cannot measure historical wash trading. [April swap](https://bscscan.com/tx/0x834e56f99483153e367aeeb196ec26a7cc786f0e6e539f8f5a0c6925b02a6136); [June payments](https://bscscan.com/tx/0xfa6f3443e0143f196d3eb038135d814830929222d98cd9c6d3f77b0dd9595736); [December payment](https://bscscan.com/tx/0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639).

A second verified GMI sale, on August 10, 2026, exchanges **85,359.092875973092463512 GMI** for **0.000271828813591857 WBNB**. Its Sync event exactly matches the September reserve snapshot. Both blocks at the stored update second were checked: only this receipt touched the identified pair. Neither sampled sale contains a return purchase; histories before and after them were not reconstructed. [August sale, block 115,149,751](https://bscscan.com/tx/0xe07e5f5ba7b0ddf0403d2eaa244c251011fc9e3e3b5f98c1d17e5ba390dbb0ac).

Laura's indexed MegaFans profile describes advising and early investment from May 2022; it does not establish trading control. GamiFi announced her CEO succession on September 1, 2022, so its 2026 trades cannot automatically be attributed to her earlier role. [Profile](https://ca.linkedin.com/in/lauralwalsh); [GamiFi succession announcement](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147).

**Gotbit and the legal question.**

No verified public connection was found between Gotbit and Laura under either surname, or through the three investigated projects. Reviewed Gotbit case materials do not identify her. This is a bounded negative search result, not proof no undisclosed relationship exists. Gotbit's admitted conduct in its own case cannot establish an offense by the participants examined here. [DOJ sentencing announcement](https://www.justice.gov/usao-ma/pr/cryptocurrency-financial-services-firm-gotbit-and-founder-sentenced-market-manipulation); [SEC August 2026 case update](https://www.sec.gov/enforcement-litigation/litigation-releases/lr-26598).

The supported criticism is that Kaskade's headline turnover could reflect intensive reuse of a small capital base and reward-seeking activity. That weakens an inference of broad organic demand. Establishing illegal manipulation would require additional evidence about applicable rules, intent, control, representations and execution. These AMM swaps do not by themselves establish literal matching of a participant's own exchange orders. The earlier MegaFans financial-projection arithmetic errors also do not establish any executed trading scheme.

**Validation performed and remaining evidence.**

Exact Kaskade amounts, adjacency of inputs/outputs, gas sums, claim sums, elapsed times and leaderboard denominators were recalculated with decimal arithmetic and independently reviewed. BNB receipts were decoded by token identity and event type; pool factory lookups and reserve matches were checked. The included scripts reproduce calculations from preserved data. This is historical reconstruction and consistency checking, not an exhaustive chain audit or statistical backtest of every trade.

| Remaining question | Evidence needed to resolve it |
|---|---|
| What fraction of Kaskade's entire campaign was repetitive turnover? | Complete eligible swap export, exact historical USD valuation rules, all epochs and all wallets, with an explicit classification method |
| Who controlled the connected wallets or paid for their activity? | Corroborated ownership or authorization records; transfers alone are insufficient |
| Were all distributions Kaskade rewards, and were exclusions enforced? | Authenticated distributor deployment/administration records, epoch Merkle allocations and exclusion policy/history |
| Did subsidies produce lasting demand or liquidity? | Consistent pre-, during- and post-campaign pool series with concurrent incentives and market changes accounted for |
| Was MBUCKS/GMI volume artificial on other venues? | Complete DEX pool coverage and exchange trade/account records; deposits and withdrawals are insufficient |
| Did Laura direct or approve relevant conduct? | Dated instructions, sign-offs, contracts or authenticated communications tied to the conduct |

Some explorer pages blocked automated access. Ethereum verification used ordinary public Etherscan pages; BNB verification used the documented public node. The BNB node rejects broad log queries and prunes older state, although historical receipts and headers were accessible. Re-running an old fixed-state query may consequently fail even though its saved response is available. No failed retrieval was treated as proof of misconduct or inactivity.

The accompanying evidence ZIP contains the source leaderboard image, exact Kaskade transaction transcriptions, transfer checks, source links, BNB raw requests/responses and numerical reproduction scripts. It preserves the distinction between explorer transcriptions, node responses, publisher claims and analyst inference.
