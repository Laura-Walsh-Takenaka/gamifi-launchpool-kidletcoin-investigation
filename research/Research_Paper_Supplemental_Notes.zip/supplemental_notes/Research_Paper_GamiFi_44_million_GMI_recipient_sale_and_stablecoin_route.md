# Research Paper — GamiFi 44 million GMI recipient, sale and stablecoin route

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research date: 2026-09-06. Network: BNB Smart Chain, chain ID 56. All times UTC.

## Result

The address that received a combined **44,000,000 GMI**, including the **14,000,000 GMI removed from Launchpool vesting contract `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb`**, sold all 44 million six minutes and twelve seconds later. The successful swap receipt proves actual proceeds of **5,174.293394005109506048 BUSD**. The address sent **5,174 BUSD** to a second address, which sent exactly that amount to `0x4727250679294802377dd6ca6541b8e459077c95` twenty-one seconds later. Etherscan's indexed public page labels the last address **“FixedFloat: Hot Wallet,” based on hildobby compilation**. That is an explorer attribution, not a provider-confirmed customer identity.

## Exact chronology

| UTC 2022-11-05 | Block | Transaction | Action |
|---|---:|---|---|
| 06:45:09 | 22786456 | `0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48` | Safe batch transfers 14m GMI from Launchpool vesting, 23m from `0xee57b1241f243a1a794f60ffa643d202188d31d9`, and 7m from `0xba306306b117a25145d58c67a03deb7f22ee2a3a`, all to `0x35dc4a16db1e30036fee83e733ee065ad8535422`. Initial batch verified by parent/outflow lane; historical recipient balances independently checked here: zero before, 44m after. |
| 06:45:39 | 22786466 | `0xb954f172ba0faed75a15967fce0e72a52ee674fd585d9d1e5385199c72f82a17` | `0x343cebd1e7d1a6838cd8b82f6238b29ad78e235e` sends **0.019849782233850894 BNB** to `0x35dc...`. This is its nonce 249; the Safe execution was its immediately preceding nonce 248 (cross-confirmed with Safe control lane). |
| 06:49:42 | 22786547 | `0xeb6b16fd5b6fd878ed594792c33a6373346c2bcd5d21f2c561a9ca9acd56dd99` | Recipient's nonce 0 approves router `0x1111111254fb6c44bac0bed2854e76f90643097d` for maximum GMI allowance. |
| 06:51:21 | 22786580 | `0x7096720b8dc95afac5ad1029a489ce8dd2b2dcb5ff78e960fcb5e10d03acd8aa` | Recipient's nonce 1 sells **44,000,000 GMI**, receiving **5,174.293394005109506048 BUSD** in the same successful transaction. |
| 07:15:11 | 22787056 | `0x34bfa37b43fc0426e45ffcd3af9927be6495d4710f340f7f80e09d2fc41fe1b4` | Recipient's nonce 2 directly sends **5,174 BUSD** to `0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6`. |
| 07:15:32 | 22787063 | `0x7702b5e67906c5eb1dea5d1fdde0f7ade3e37cb5cd657944bd539ed460791e48` | `0x96f0...` directly sends **5,174 BUSD** to `0x4727250679294802377dd6ca6541b8e459077c95`, the explorer-labeled FixedFloat hot wallet. |

## Destination funds the intermediate address and receives its remainder

A bounded inspection of full blocks 22787056–22787069 also confirms:

| UTC 2022-11-05 | Block | Transaction | Action |
|---|---:|---|---|
| 07:15:20 | 22787059 | `0xfce9f602e9b578c45f056eaa29343e0932d46f796d3fcb9a9b2dc326e1367a7a` | `0x472725...` sends **0.00084 BNB** to `0x96f0...`, nine seconds after the 5,174 BUSD deposit. |
| 07:15:32 | 22787063 | `0x7702b5e67906c5eb1dea5d1fdde0f7ade3e37cb5cd657944bd539ed460791e48` | `0x96f0...` sweeps all **5,174 BUSD** back to `0x472725...` in its nonce-0 transaction. Gas paid: 0.000169016 BNB. |
| 07:15:41 | 22787066 | `0xfc4c26165b9fad6ae7aa5c69b0763f4bed1af11f97ecebb9112793ca121303c4` | `0x96f0...` returns **0.000502984 BNB** to `0x472725...` in its nonce-1 transaction. Gas paid: 0.000168 BNB. |

All three receipts returned success. The two outgoing transactions exhaust `0x96f0...`'s sampled lifetime nonce count of two. Its funded 0.00084 BNB reconciles exactly to returned BNB plus the two network fees. This directly observed deposit, gas funding, token sweep and native remainder return is **consistent with an exchange deposit-sweep workflow**. That description is an inference from the transaction pattern; the ultimate customer and exchange order remain unidentified. Exact extracted transactions are in `hop2_nearby_transactions_extracted.json`, with full source blocks and separate receipts.

## Exact swap receipt

The receipt emits these transfers, in sequence:

1. **44,000,000 GMI:** `0x35dc...` → GMI/WBNB pool `0x58d4b61983ca0afe6e352e90719f403e24e016f4`.
2. **14.390078733258475207 WBNB:** pool → execution contract `0x18101ac1d35230f1a3c005e2abaaeb25cae79e7f`.
3. **14.387902306636222347 WBNB:** execution contract → `0xbe883a42d6ae7f08f73d7d91c69e603f61b58e3d`.
4. **5,174.293394005109506048 BUSD:** `0xbe883...` → execution contract → router → original recipient `0x35dc...`.

The pool's `Swap` event independently records 44m GMI in and 14.390078733258475207 WBNB out. The router event records the original recipient, GMI source, BUSD destination, source amount and output amount. The route's aggregate execution rate was about **0.0001175975771364797615 BUSD per GMI**, before separately paid network fees. Differences between intermediate WBNB amounts are not assigned a fee category without corresponding contract decoding.

BUSD is token `0xe9e7cea3dedca5984780bafc599bd69add087d56`. WBNB is `0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c`. Both quantities decoded with 18 decimals. The separate price lane is responsible for any historical USD conversion; these exact BUSD amounts are not claimed to be bank dollars.

## Recipient state and bounded completeness

- GMI balance of `0x35dc...` was **zero at block 22786455**, **44m at 22786456**, and **zero at sampled blocks 25m, 30m, 40m, 60m, 90m and 120225607**.
- Nonce was zero before receiving GMI, then three by block 25m, and remained **three at block 120225607**. The approval, swap and stablecoin transfer account for all three normal outgoing transactions as of that head. This does not prove an exhaustive incoming-token history or exclude externally triggered token transfers.
- Its residual **0.293394005109506048 BUSD** remained at block 120225607. No GMI remained.
- The intermediate `0x96f0...` had nonce zero and zero BUSD immediately before receipt. It had nonce two and zero BUSD 10,000 blocks later, and the same sampled latest nonce and BUSD balance. No code was returned for either recipient address.
- Outgoing GMI logs were queried over a bounded 10,000-block range beginning at the original receipt, yielding the single 44m transfer to the pool. Outgoing BUSD logs for each recipient were queried in similarly bounded ranges, yielding the two exact 5,174 BUSD hops.
- First outgoing nonce and native funding blocks were identified by historical state bisection; historical block transactions then identified the exact approval and funding transactions. Raw requests and responses preserve the provider, query, block and retrieval time.

## Attribution and inference limits

The on-chain link is established through actual successful transactions and token logs. The Safe executor and gas funder are the same address, with successive nonces. This does not establish that the executor, Safe signer, seller address and service customer share one human owner. The Safe control lane identifies a separate authorization signer.

The 44m sale combines balances from three contracts. **Do not describe all 5,174.29 BUSD as proceeds of the 14m Launchpool tokens alone.** A proportional 14/44 allocation would be a calculated attribution only, not an independently observed payout from those particular tokens.

The final destination is an address labeled by Etherscan, which explicitly credits a third-party compilation. The label has not been confirmed by FixedFloat and does not identify an ultimate customer, payout asset, destination chain or withdrawal address. It is a concrete lead for relevant exchange order/deposit/withdrawal records. No outgoing transfer from a pooled service wallet is assigned to this deposit solely because of proximity in time or matching value.

Nothing in this lane identifies Laura's personal wallet, demonstrates a bank transfer, or establishes why the authorized transfer and sale occurred. This route postdates the previously documented September 2022 CEO succession.

## Public source leads

- Swap receipt: https://bscscan.com/tx/0x7096720b8dc95afac5ad1029a489ce8dd2b2dcb5ff78e960fcb5e10d03acd8aa
- First BUSD hop: https://bscscan.com/tx/0x34bfa37b43fc0426e45ffcd3af9927be6495d4710f340f7f80e09d2fc41fe1b4
- Hot wallet hop: https://bscscan.com/tx/0x7702b5e67906c5eb1dea5d1fdde0f7ade3e37cb5cd657944bd539ed460791e48
- Label source: https://etherscan.io/address/0x4727250679294802377dd6ca6541b8e459077c95 (search retrieval `historical retrieval`; direct retrieval returned HTTP403; do not cite failed direct view as successful retrieval).
- Router indexed contract page: https://www.codeslaw.app/contracts/bnbchain/0x1111111254fb6c44bac0bed2854e76f90643097d identifies AggregationRouterV4 / 1inch v4 Router; this label is contextual, and the receipt itself establishes conversion regardless of label.
- Public RPC used: https://docs-demo.bsc.quiknode.pro/ . Files preserve endpoint and exact RPC requests. `decoded_transfers.json` is derived from receipt logs.
