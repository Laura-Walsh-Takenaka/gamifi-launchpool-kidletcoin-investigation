# Research Paper — > Preservation note: this memo records its stage of the investigation. The consolidated report and collector supplements supersede former incoming-flow gaps and earlier coverage totals. The ETH-related counter identified in QA has been corrected. Exact continuity is not proof of exclusive balances or uniquely identified fungible token units.

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

# Independent skeptical QA — Kaskade history calculations

Reviewed `calculate_kaskade_history.py`, preserved raw swap receipt text, decoded swaps, normal-transaction inventory, all 65 stablecoin transfers and claim/forward ledger on 2026-09-05.

## Checks that passed

- **235 unique swap-like inventory hashes = 235 unique decoded receipt hashes**, with no omission or duplicate. Each raw receipt independently matches its claimed transaction hash, block, success status and full AM/PM UTC timestamp.
- **231 USDC/LUSD swaps** are partitioned exactly once among the calculated chains. All **202 continuity links** have no intervening relevant outgoing swap, claim or stablecoin Transfer call in the full inventory. No same-sender same-block ties were found, so the script's strict block-order comparison does not change this dataset's result.
- The strongest chain has **66 unique swaps**, **65 exact asset-and-amount continuity links**, **nine distinct swapping addresses**, and **eight cross-wallet swap links supported by ten actual transfers**. Two handoffs route through `4E958` before reaching the next swapping wallet. All ten transfer amounts, assets, source/recipient relationships and block ordering independently match the adjacent swaps.
- Independently recomputed strongest-chain nominal input sum: **1,993,826.456664144632875365** stablecoin units, assuming par for a dollar figure. Start **30,500 USDC**, end **29,902.00513 USDC**, decrease **597.99487 USDC** before gas. Ten handoff transfers cost **0.006298926931151368 ETH**, additional to the chain's swap gas.

## Concrete correction

`native_ETH_swaps` counts only `input_token == 'ETH'`, producing **2**, while the dataset contains **three ETH-related swaps**: two ETH inputs and one USDC-to-ETH output. Count either side or rename the field `native_ETH_input_swaps`; the stablecoin-swap total and strongest chain are unaffected.

## Collector accounting

**May 1 reconciles as two tranches**, not one simultaneous retained balance:

| UTC time | Transaction | LUSD input | USDC output |
|---|---|---:|---:|
| 13:58:59 | `0x184d34d6f7f4d76a6713178ddcd2a403fe6ddc38867a3bb2141e4adbe23c2019` | 8672.178100811423023104 | 8659.48532 |
| 14:48:35 | `0x3b8fc6f31ea2060012beb802a086a2efd232f7d833ce75a626ad5eae0a6f9e12` | 1019.182093434431995904 | 1017.688077 |
| Total | | **9691.360194245855019008** | **9677.173397** |

The LUSD total exactly equals the nine May 1 claims. The second tranche equals the two later claims/forwards from `425e` and `68d3`; it is not missing the first seven payouts. Combined swap gas is **0.003369960171067216 ETH**. The USDC-to-LUSD numerical difference is not an exact dollar P&L without token valuations, gas and complete flow reconciliation.

**April 24 requires an inbound-token-history gap to remain explicit.** `4E958` sends **8285.027398394077806592 LUSD** to `3ac0030a…E8CAF` at 16:55:35, then a 16:58:11 swap spends exactly that LUSD amount and receives **8280.806398 USDC**. The preceding outward payment and the later swap cannot both be treated as fresh reward revenue. A return transfer or another existing/incoming LUSD balance is not resolved by this normal-transaction inventory.

**April 17 also includes an unreconciled amount:** `425e` swaps **5585.449075373668532224 LUSD** at 15:03:23, exceeding the selected eight wallets' **3968.390622853786468352 LUSD** reward total by **1617.058452519882063872 LUSD**. Do not attribute this entire swap to those eight rewards without additional inbound/balance evidence.

## Wording limits

Exact amount continuity supports a reproducible path through the observed transactions; fungible-token tracing without complete incoming transfer/balance history does not uniquely identify individual token units. The **8.435m** aggregate nominal input figure includes all selected-wallet stablecoin swaps, including reward conversion, and is not independently reconciled to Kaskade's campaign-attributed backend volume. The result is not a finding that every included trade was fake or unlawful.

Receipt preservation uses rendered explorer text, with some intermediary addresses abbreviated. The swap decoder identifies token symbols from this text and does not store per-receipt token-contract links. Transfer receipts separately preserve and verify full canonical token links. This is explorer-based verification, not a cryptographic full-node audit.

Machine-readable independent strongest-chain check: `kaskade_chain_independent_qa.json`.
