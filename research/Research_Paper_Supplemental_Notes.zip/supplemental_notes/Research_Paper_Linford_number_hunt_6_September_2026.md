# Research Paper — Linford number hunt — 6 September 2026

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

## Confirmed official identifiers

| Exact company name in official record | Jurisdiction of record | Company number |
|---|---|---:|
| LINFORD CORPORATE SERVICES INC. | British Virgin Islands | 1943018 |
| LINFORD MANAGEMENT SERVICES INC. | British Virgin Islands | 1943021 |

Source: Virgin Islands Official Gazette, Vol. LII No. 102 (Extraordinary), 11 December 2018, printed page 6680 (PDF page 238; zero-based page 237).

Official PDF: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/governmentandstatutorynotices/%23102%2011th%20December%2C%202018%20EXTRA.pdf

The number/name pairs were inspected in the actual PDF screenshot and confirmed against extracted text. Original PDF saved as `BVI_GAZETTE_2018-12-11_NO102_ORIGINAL.pdf`, SHA-256 `e838ed232a879114c4a54332efa15c961793c0867d4b5382e03b0d516bcd6090`.

## Historical status stated in source

Printed page 6444 (PDF page 2) introduces the list as companies struck from the register on **1 November 2018 for non-payment of annual fees**. The full document has only that strike-off heading, so the two Linford entries belong to that list. This is a historical event, not a current registry-status certificate. No restoration, continuation, dissolution or current-status record was established in this search.

## Identity boundary

These are official BVI numbers for exact-name entities. They are not Panama folio numbers. Linking them conclusively to the two subscribers in Asociados Carajo Inc.'s Panama incorporation requires the subscriber particulars in the original incorporation instrument (jurisdiction, company number, address or certified entity documents). A subscriber is not automatically a current shareholder, controller or beneficial owner.

This early note did not independently inspect the Asociados Carajo deeds; consult the later consolidated Launchpool and Panama reports for their examination of those copies.

## Secondary corroboration / leads only

i-BVI lists LINFORD CORPORATE SERVICES INC., company number 1943018, registration date 21 April 2017:
https://i-bvi.com/company/linford-corporate-services-inc_722355

The date is secondary-source information and has not been verified by an incorporation certificate.

Public secondary Panama databases show the two names together as subscribers of multiple unrelated companies using Quijano & Asociados, including WBS LATAM S.A. and Witchy Tech S.A. This pattern is consistent with formation services, but establishes neither ownership of Linford nor ownership of Launchpool and should not be used as such.

## Useful document request targets

1. Original Asociados Carajo incorporation instrument under folio 155733022 / initial entry 44706/2023: subscriber identity paragraphs and signature pages.
2. BVI company search / historical status for 1943018 and 1943021, including any restoration or continuation record.
3. If BVI identity is confirmed, current registered-agent and director records for those numbers.

No purchase, account creation, communication or registry contact was performed.
