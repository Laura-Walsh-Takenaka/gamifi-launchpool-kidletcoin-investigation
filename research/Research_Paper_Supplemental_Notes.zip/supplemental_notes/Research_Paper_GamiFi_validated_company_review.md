# Research Paper — GamiFi — validated company review

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Reviewed 2026-09-05. Public professional, product and campaign records only. No account access, contact, transactions, wallet connection or intrusive testing. This expands the initial review and supersedes its incomplete ShibaFriend lead and overly broad staking-disclosure concern. Source access dates below are 2026-09-05; publication dates are distinct.

The strongest findings are documented launch delays, a canceled public offering with announced participant remedies, and a later suspension of the launchpad's core service. Several stronger accusations are unsupported. GamiFi/GMI is distinct from GameFi.org/GAFI; terms for the latter were excluded.

## Lead dispositions

| Lead | Disposition | Validated conclusion and limit |
|---|---|---|
| GF01 — Laura's tenure | **Resolved** | The primary succession announcement is September 1, 2022. A profile end month of September 2022 is consistent with it, not a demonstrated contradiction. Later management decisions cannot automatically be attributed to Laura. |
| GF02 — Launch delivery | **Confirmed, mitigation announced** | The company acknowledged fewer IDOs than anticipated and extended Golden Ticket validity. This supports an execution shortfall, not a finding that tickets never provided utility. |
| GF03 — ShibaFriend | **Confirmed cancellation; settlement open** | The June 30 public IDO was canceled June 29. Refunds or an alternative allocation plus bonus were offered. Completion of those remedies was not verified. |
| GF04 — Staking promotion | **Downgraded** | Duration, rate, caps and a generic risk warning were published. The actual deployed reward formula, funding, principal-exit provisions and fee schedule remain unverified. |
| GF05 — FOMO schedule | **Confirmed schedule change; outcome open** | May and September announcements describe substantially different dates. Neither establishes final subscriptions, settlement or investor returns. |
| GF06 — Service continuity | **Confirmed historical pause; current state open** | October 3, 2022 announced no IDOs for the time being. It also described continuing work, so it cannot establish permanent closure. |
| GF07 — MegaFans promotion | **Conditional disclosure gap** | The article contains no Laura interest disclosure. Her reported overlapping advisor/seed-investor role requires role-date corroboration before a firmer finding. No illegal promotion finding follows. |
| GF08 — Audit/code | **Open** | An official token address was identified, but no specific auditor report or deployed staking implementation was validated. A candidate repository is insufficient to establish deployed vulnerabilities. |
| GF09 — Fees, minimums and legal operator | **Open** | A complete GamiFi fee/minimum schedule and an unambiguous primary legal-entity identification were not recovered. Unknown is not zero, concealed, or unregistered. |

## Role and responsibility boundary

GamiFi's September 1, 2022 announcement names Eleanor Rooney as incoming CEO and thanks Laura for her leadership. That direct event date is more precise than a month-only profile. The October pause and September FOMO update are successor-era actions. The reviewed announcement does not assign personal responsibility for earlier difficulties or state Laura's reason for leaving. [S1](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147)

## Actual launch activity and delivery failures

On May 4, GamiFi acknowledged that market-driven project delays had reduced its IDO frequency. Golden Ticket NFTs originally covered three IDOs or three months, but only two IDOs had occurred. The company extended validity and introduced a pool reserved for holders. This is direct evidence of a delivery shortfall and a stated accommodation during Laura's tenure; fulfillment of the extension itself was not separately verified. [S2](https://gamifi-launchpad.medium.com/new-staking-pools-launch-290e4bcc4c79)

The February 28 issuer release proposed GAMI's March 11–14 offering: one million tokens at $0.10, a $100,000 target. Ordinary participants entered a whitelist ballot; Golden Ticket owners received guaranteed whitelisting. These are campaign terms, not evidence that the target was raised. The release also reports completion of GamiFi's own earlier token campaigns. [S3](https://www.businesswire.com/newsPlay-to-Earn-Company-GAMI-Lists-GamiFis-First-Launchpad-IDO)

GamiFi's March 22 podcast notes report that its second IDO, Time Raiders, launched March 17 and was being distributed. This is primary company-reported delivery, countering a blanket claim of no launches; it is not an independent settlement audit. The same notes advertise up to 225% APY and publish the GMI contract address, `0x93D8d25E3C9A847a5Da79F79ecaC89461FEcA846`. [S4](https://player.captivate.fm/587ac29a-5fc4-4db8-95e3-87f16c20e2af)

### ShibaFriend — stronger evidence recovered

The full June 29 announcement now establishes cancellation of the June 30 public offering. GamiFi attributed the decision to repeated tokenomics/release changes and insufficient remaining time to contact investors individually and rewrite staking contracts. Participants were offered either a refund or SHF from GamiFi's private allocation plus 1,000 GMI. This was a material last-minute reversal, but also an announced protective intervention. The post does not establish completed refunds, each investor's election, the replacement allocation's final vesting, or losses. A separate deferred-unlock announcement and its implementation remain unverified. [S5](https://gamifi-launchpad.medium.com/shibafriend-ido-announcement-e57f229783f7)

A June 11 announcement by another participating launchpad, Oxbull, supplies an earlier SHF tokenomics snapshot: ten billion total supply; 1% public IDO allocation; 18% at TGE followed by 41% in subsequent months; $0.0054 IDO/listing price; June 30 planned listing. Its private-sale terms described a seven-day lock followed by an 18-month daily release. These are pre-change, Oxbull-published terms and do not establish the terms GamiFi eventually offered. Oxbull's own minimum-holding and refund restrictions must not be attributed to GamiFi. [S6](https://oxbull.medium.com/oxb-being-humans-best-friend-with-shibafriend-nft-e9f2cda8f58)

### FOMO Lab — schedule versus outcome

The May 5 announcement proposed May 9–13 whitelisting, May 16–23 funding and May 30 listing, with approximate times. [S7](https://gamifi-launchpad.medium.com/new-ido-information-with-fomo-labs-battlechain-battle-royale-game-437117244b0e) The September 20 update instead scheduled September 21–25 whitelisting, September 25–27 funding and September 28 listing. [S8](https://gamifi-launchpad.medium.com/fomo-lab-ido-update-7733bd7d5693) The proposed listing date moved 121 calendar days. That arithmetic measures schedule movement, not a verified duration of investors' locked funds. Actual GamiFi fundraising, distributions and final launch outcome remain open.

## Staking terms: what 225% actually establishes

The May 4 opening announcement provided these terms and a generic warning that investment decisions were at participants' risk. Its maximums were described as stake amounts without clarifying whether they were per participant or pool-wide. [S9](https://gamifi-launchpad.medium.com/new-staking-pool-open-50dd1e1eb064)

| May 4 pool | Advertised duration | Advertised APY | Stated maximum stake |
|---|---:|---:|---:|
| RPG NFT holders | 30 days | 225% | 1,000,000 GMI |
| Standard | 60 days | 150% | 6,000,000 GMI |
| Standard | 90 days | 175% | 3,400,000 GMI |

The August 23 announcement introduced pools opening August 24: nine months at 75% APY and twelve months at 100%. It expressly identified a 2.5 million GMI **individual** maximum and allowed reward withdrawals with a 24-hour cooldown. This resolves a blanket assertion that reward withdrawal timing was never disclosed; these are later pools, not necessarily the May pool's terms. Principal withdrawal is a different question. [S10](https://gamifi-launchpad.medium.com/new-staking-pools-a931ff7dfd6a)

**Illustrations, not verified payouts:** conventional effective APY implies a constant-equivalent 30-day return of `(1 + 2.25)^(30/365) − 1 = 10.1723%`. Simple annual-rate prorating gives `2.25 × 30/365 = 18.4932%`. Neither means 225% earned in thirty days. The deployed calculation remains unverified.

The remaining requests are specific: deployed pool addresses and code version, actual initialization values/formula, compounding availability, reward asset and reserve source, principal release and early-exit rules, any fees, and whether advertised returns depended on restaking or token price. A higher token balance alone would not establish a positive cash return: cash value depends on both token quantity and sale price. No loan agreement was established by these staking announcements.

## Pause and present continuity

On October 3, Eleanor Rooney described project difficulties and made restoring GMI performance the immediate priority. The company would reduce activity and stop hosting IDOs for the time being. It also said work and pipeline preparation continued. This confirms a historical interruption of the launchpad's core service. Current continuity remains unresolved; no later primary resumption record was validated. [S11](https://gamifi-launchpad.medium.com/gamifi-update-f8d6326f1780)

The official Medium index's newest displayed entry was October 3, 2022. That describes one communications channel, not all company activity. A failed main-site retrieval and automated market pages were excluded as proof of closure. A currently identifiable legal operator, ownership chain or current operational status remains unestablished in this review. [S12](https://gamifi-launchpad.medium.com/)

## Conditional related-interest disclosure

The August 29 GamiFi article promotes MegaFans without mentioning Laura's advisor/seed-investor interest. Earlier profile research dates that association from May 2022, overlapping her GamiFi tenure. If substantiated, this supports a publication-specific disclosure gap. The article does not establish Laura's authorship, approval, publishing compensation, control of MegaFans, or a legal violation. It distinguishes some future plans from existing products. [S13](https://gamifi-launchpad.medium.com/today-we-are-super-excited-to-be-covering-an-up-and-coming-esports-and-gamefi-powerhouse-megafans-a022934c4a67) Profile lead: [Laura's public professional profile](https://www.linkedin.com/in/lauralwalsh).

## Audit and code boundary

The token address in S4 is an official identifier. Read-only explorer retrieval did not establish the deployed staking code or an auditor's report. The public repository [sheandev/gamifiContracts](https://github.com/sheandev/gamifiContracts) was discovered through an aggregator; its README describes GamiFi development and it contains staking Solidity files. An official company-to-repository link and an exact deployment match were not validated. Consequently no source-code behavior is reported here as a deployed GamiFi defect, and no vulnerability finding was made.

A PeckShield logo appears on old website copies, but the reviewed evidence did not identify a report, report date, audited address/commit or remediation scope. This is an **unverified audit lead**, not proof that the company falsely claimed an audit or that no audit occurred. The official report list checked was [PeckShield publications](https://github.com/peckshield/publications/tree/master/audit_reports).

## Source register

All access dates: **2026-09-05**. Publication dates and retrieval limits are recorded separately below.

| ID | Publisher / record | Publication date | Retrieval |
|---|---|---|---|
| S1 | GamiFi, new CEO | 2022-09-01 | Full text inspected earlier in this research session; later direct retrieval intermittent |
| S2 | GamiFi, new staking pools launch | 2022-05-04 | Full text inspected earlier; later direct retrieval intermittent |
| S3 | GamiFi issuer release, Business Wire | 2022-02-28 | Full indexed release inspected |
| S4 | GamiFi podcast episode 20, Captivate | 2022-03-22 | Full show notes inspected |
| S5 | GamiFi, ShibaFriend IDO announcement | 2022-06-29 | Full text recovered and inspected; prior snippet-only limitation resolved |
| S6 | Oxbull, SHF offering | 2022-06-11 | Full text inspected; primary for Oxbull's published terms |
| S7 | GamiFi, FOMO offering schedule | 2022-05-05 | Full text inspected |
| S8 | GamiFi, FOMO IDO update | 2022-09-20 | Full text inspected |
| S9 | GamiFi, staking pools open | 2022-05-04 | Full text inspected earlier; later direct retrieval intermittent |
| S10 | GamiFi, new staking pools | 2022-08-23 | Full text inspected |
| S11 | GamiFi, CEO operational update | 2022-10-03 | Full text inspected earlier; later direct retrieval intermittent |
| S12 | GamiFi Medium index | Undated current index | Full index inspected |
| S13 | GamiFi, MegaFans promotion | 2022-08-29 | Full text inspected |

## Evidence needed to close remaining questions

1. Public settlement totals or a company reconciliation for ShibaFriend refunds and replacement allocations, plus the final SHF release schedule.
2. Official deployed staking addresses, reward parameters, audited commit and audit/remediation report.
3. Contemporaneous fee, minimum-stake and principal-exit terms for each named pool/IDO.
4. GamiFi-specific final outcomes for GAMI and FOMO Lab; announcement targets are insufficient.
5. A dated primary resumption/closure notice and the legal operator's exact registered identity.
6. Corroborated dates and nature of Laura's MegaFans interest, and any applicable publication disclosure policy.

The validated record supports operational and disclosure questions. Settlement outcomes, financial condition and individual responsibility remain unverified.
