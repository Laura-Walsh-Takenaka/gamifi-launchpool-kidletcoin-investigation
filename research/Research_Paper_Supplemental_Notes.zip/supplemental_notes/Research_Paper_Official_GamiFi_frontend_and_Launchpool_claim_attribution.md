# Research Paper — Official GamiFi frontend and Launchpool claim attribution

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Checked 2026-09-06. All actions were read-only.

## New established connection

GamiFi's own archived claim frontend explicitly configures `launchpoolVesting` as `0xf50488dC8339fb7D1d5A8e8B401c4A5D71a090bb`. This independently links the previously identified repository deployment and live vesting contract to the public GamiFi claim interface.

The page capture is 2022-04-20 12:10:48 UTC at `https://app.gamifi.gg/launchpool-claim/`. Its script reference `/_nuxt/f76e883.js` resolves to a capture from 2022-04-20 12:11:12 UTC. The JavaScript selects the other configured vesting address only when the pathname contains `private-claim`; otherwise it selects `launchpoolVesting`. Its claim action uses the selected address, `getNonce`, `getClaimable` and `claim(address,nonce)`.

Sources:

- https://web.archive.org/web/20220420121048id_/https://app.gamifi.gg/launchpool-claim/
- https://web.archive.org/web/20220420121112id_/https://app.gamifi.gg/_nuxt/f76e883.js

The frontend HTML says users should review the vesting terms defined in their Token Agreement. This points to participant agreements as an off-chain record needed to establish legal entitlements. The initial server-rendered zeros on the page are placeholders before wallet connection; they are not investor-balance evidence.

## Primary organizational announcement

Launchpool's official announcements channel message **1254**, timestamp **2022-04-19 21:12:55 UTC**, directs investors to that exact GamiFi `/launchpool-claim/` URL, identifies the canonical GMI token address, and describes the remaining tokens as vesting linearly over nine months. The announcement is a direct operational GamiFi–Launchpool distribution link, beyond a shared corporate affiliation or a developer's variable name.

- Public text: https://t.me/s/launchpoolannouncements/1254
- Raw timestamp retrieved through equivalent working domain: https://telegram.me/s/launchpoolannouncements/1254
- Web reference with announcement text: `historical retrieval` lines 195–208; root must open itself before final citation.
- Raw file: `msg1254_alternate.html`; compact metadata: `launchpool_claim_message.json`.

## Later status statement and its limit

Launchpool's official announcements message **1506**, timestamp **2024-02-29 23:32:28 UTC**, lists Gamifi among projects whose vesting was completed. This is an organizational status representation. It does not establish that every beneficiary claimed, that every allocation was paid, or that the contract remains funded now. Vesting-period completion and token payout are distinct.

- Public text: https://t.me/s/launchpoolannouncements/1506
- Raw timestamp: https://telegram.me/s/launchpoolannouncements/1506
- Web reference containing message: `historical retrieval` lines 197–222 (the `/1500` context page includes message1506).
- Raw file: `msg1506_alternate.txt`; compact metadata: `completed_vesting_message.json`.
- Linked X post 1762833659093041216 has a separate **2024-02-28 13:34:30 UTC** timestamp, confirmed by X's syndication endpoint `created_at`. Do not use that timestamp for the Telegram post.

## Concrete official frontend identifiers

| Role in the April 2022 frontend | Address | Evidence |
|---|---|---|
| Launchpool vesting | `0xf50488dC8339fb7D1d5A8e8B401c4A5D71a090bb` | `launchpoolVesting` and claim routing |
| Private-claim vesting | `0x74e0dDF89807107378BeB02e6BC504243E0cdF6c` | `vesting` and pathname selection |
| IDO Project contract | `0x56c0cb2d047b69278f49b4759c1718436a546c7f` | Module689 variable `v`, used for `projects(id)`, funding and staking calls |
| GMI token | `0x93D8d25E3C9A847a5Da79F79ecaC89461FEcA846` | `token` |
| Pair | `0x58d4B61983Ca0aFE6E352e90719F403E24e016F4` | `pair`; previously independently identified as GMI/WBNB |
| Membership NFT | `0x0bE0e13C828B60b53D7577651cc54581855f7BAD` | `memberCard` |
| Payment token address | `0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56` | Labeled `usdt` in one object, but this is the BUSD address used as BUSD elsewhere in the app |

These labels establish configuration at the capture date. They do not, by themselves, establish current implementation, current owners, receipt of money, or a person's beneficial ownership. `official_frontend_identifiers.json` preserves exact labels, source offsets, snippets and hashes.

There is no sound treasury-recipient attribution solely from this frontend. A hardcoded helper calls `setFundingReceiver(1, 0xbC6dCC38142F564d9515C5792005BCBEA84b058c)`; another helper prepares a three-address vesting example. Neither proves execution or present funding-recipient settings. They are intentionally excluded from the established role table. Staking methods often receive their target address dynamically as a parameter, rather than identifying one static pool.

## Search limits

Bounded exact-address searches using both available web engines did not find a usable primary public label assigning `0xf27f9a2...`, `0x538a8b6...` or `0x3e0f4c7...` to Laura, Alphabit, Launchpool or another legal person. An explorer NFT item repeats the already known Duke deployer address. A GitHub developer account or commit author does not identify the person controlling a blockchain key.

The repository scripts were checked for contextual identifiers. They added no verified bank account or organizational controller identity. No conclusions about a Cayman bank account, personal receipt, fraud or misconduct follow from this lane.

## Evidence selection

Core files to preserve: this note, `claim_20220420.html`, `f76e883.js`, `8cd9c70.js`, `claim_cdx`, `claim_assets_summary_slim.json`, `official_frontend_identifiers.json`, `launchpool_claim_message.json`, `completed_vesting_message.json`. Raw Telegram context pages and X JSON are available if useful. The 6.9MB vendor bundle `0d9f56e.js` and the large full regex-address summary are not necessary for the established connection.

SHA256 of core frontend JS: `625120707c8c8505a1794be03015d7dab4e03ec99df70502bf9aff6221d8008c`.

SHA256 of claim HTML: `185b9f777c72158387fa972f6f6c8166b3bd5330136c7fc31513749f5d95d2e8`.
