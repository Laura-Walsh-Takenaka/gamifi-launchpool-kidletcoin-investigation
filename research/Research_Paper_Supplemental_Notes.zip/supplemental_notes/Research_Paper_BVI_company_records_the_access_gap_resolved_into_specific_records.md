# Research Paper — BVI company records: the access gap resolved into specific records

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The ordinary company search is **US$50**. It provides an index of corporate filings, with copies of documents ordered separately. A later statutory schedule provides **US$250 inspection of all qualifying documents** held for one company. Neither service overrides restrictions on private registers. [R1–R3]

The target is **Gamifi Limited, BVI number 2082070**. The supplied screenshot establishes the returned name and number. It does not disclose status, incorporation date, agent, directors or bank information. The $50 price is corroborated by official sources; the screenshot itself does not show a price or currency. Statutory amounts are US dollars under the Act’s section 2 definition. [R4]

### Exact record and fee matrix

| Record / action | Access and government fee | Relevance |
|---|---|---|
| Basic entity lookup | Free identification stage shown by the supplied screenshot | Matching name/number; no good-standing determination. |
| Company Search Report | **US$50** [R1–R3] | Incorporation, recorded status/date, current agent/office, capital/share details, earlier names, filing and certificate histories. |
| Additional corporate document copy | Generally **US$100 each**, unless another fee applies [R2–R3] | The instrument behind a filing-history entry. |
| One other qualifying document: inspection | **US$100** [R3] | Inspection is distinct from provision of a copy. |
| All qualifying company documents: inspection | **US$250** [R3] | Broader inspection subject to access restrictions; not a certified bundle. |
| Memorandum/articles copy | **US$100 each**, certified or uncertified, as described in R820 [R2] | Constitutional rules and information in that dated version. |
| Listed event certificate copy/extract | **US$75 certified / US$50 uncertified** [R3] | Incorporation, restoration, merger, consolidation, arrangement, continuation, discontinuance or dissolution. |
| Fresh good-standing certificate | **US$100** [R2, R5] | A current result, if statutory conditions are satisfied. |
| Existing good-standing certificate copy | **US$75 certified / US$50 uncertified** [R3] | Copies that particular dated certificate; does not update it. |
| Public director list | **US$75**; R820 lists **US$100 certified** [R2, R5–R7] | Current director names; not historical signing-key ownership. |
| Full directors register | Restricted access; US$75 / US$100 copy fees do not create public entitlement [R3, R8] | Company/agent and specified authorities can obtain the fuller record. |
| Members/shareholders register | Restricted unless the company elects public access [R8] | No GamiFi election has been established. |
| Annual financial return | Held by the registered agent, outside the ordinary public search [R9–R11] | Summary financial statements, obtainable by an entitled holder or authority. |

### What the history does—and does not—contain

FSC guidance revised **1 September 2025** defines the report’s history as transactions **filed with the Registry**. These are corporate filings. It is not a bank ledger, token-transfer history, revenue statement or custody record. Specific filed documents can be ordered using that index. The US$50 product therefore cannot alone identify the people behind the November transfers. [R1; final sentence is investigative inference]

The US$250 category is in **S.I.57/2024, section 2(d), pages 3–4**. It commenced **2 January 2025**, through the 2024 Amendment Act’s commencement notice. The still-linked **R820 is dated March 2023** and omits this newer category. Later S.I.70/2024, 62/2025 and 119/2025 were reviewed: they concern beneficial ownership and transitional filings, rather than replacing the ordinary inspection fees. [R2–R3, R12–R15]

### Public director names are a different product from historical control records

FSC’s legislative circular describes the public list as **current directors**. Its October 2023 newsletter gives the **R811** certification function and US$75 fee. The 2024 amendment expressly separates the full register, available to the company, its agent and specified authorities, from the list other people may request. [R6–R8]

The investigative implication is that today’s list cannot settle Laura’s authority in 2022. Dated director entries, appointment/resignation instruments, corporate instructions and key-custody records for that period remain necessary. A current officer name is not proof of who signed a historical transaction.

### Shareholder and financial records require a different route

Section **43A(5)–(6)** restricts the members register unless the company elects public availability. Company/agent, competent-authority and lawful law-enforcement access are expressly identified. Section **43A(9)** concerns members as of filing and subsequent changes; the new regime does not guarantee a publicly backfilled 2021–2022 ownership history. [R8]

Section **98A** sends annual financial returns to the **registered agent**, who must supply a copy to the FSC or another competent authority on request. The prescribed form contains balance-sheet and income-statement summaries. The regime began **1 January 2023**, with the earliest returns becoming due in 2024; it is not a promised 2021–2022 transaction ledger. Later initial-filing extensions mean generic deadlines cannot establish GamiFi’s compliance status. [R9–R11, R16]

### Lawful routes that require no purchase by a researcher

- **Existing primary disclosures:** the registry screenshot, archived terms and litepaper remain evidence of what was publicly returned or stated. They cannot substitute for absent certificates.
- **Independently published records:** company/counterparty disclosures, court exhibits and liquidator notices may legitimately reproduce records otherwise obtained through the Registry. No extra GamiFi filing was recovered in this registry-access lane.
- **Existing entitled holders:** a company or agent may provide its own records. Section 100 grants directors inspection rights and members specified rights subject to statutory and constitutional limits. GMI token ownership alone does not establish shareholder status. [R4]
- **Investigators:** section 43A(5), section 118B(4) and section 98A(3) identify routes to restricted registers and annual returns. These are records to seek through appropriate powers, not free public-search products. [R8–R9]

No payment, account creation, request or contact was made. No GamiFi corporate status, human wallet owner or bank account is inferred from these access rules.
