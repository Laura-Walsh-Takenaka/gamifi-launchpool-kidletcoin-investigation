# Research Paper — Redacted campaign: pool identity and historical coverage

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Review date: 2026-09-05. Bounded public, read-only investigation of the March 18–April 7, 2024 Kaskade campaign. This file is an investigation intermediate for integration into the consolidated report.

## Verified pool identity

The pool `0x3e6E23198679419cD73bB6376518dCc5168c8260` is an authentic Uniswap V3 **WETH/BTRFLY V2 1%** pool. Live Etherscan receipt inspection verified its `PoolCreated` event, log index 534, in transaction:

https://etherscan.io/tx/0x6d666d1fd4e502da1704748dbaa687d8a85e47943c9452601d0436b9bd2a881b#eventlog

| Field | Value |
|---|---|
| Emitting factory | `0x1f98431c8ad98523631ae4a59f267346ea31f984` |
| token0 | WETH `0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2` |
| token1 | BTRFLY V2 `0xc55126051B22eBb829D00368f4B12Bde432de5Da` |
| Fee | `10000` = 1% |
| Tick spacing | `200` |
| Pool | `0x3e6E23198679419cD73bB6376518dCc5168c8260` |
| Creation block / timestamp | 15,304,899 / 2022-08-09 00:47:43 UTC, independently displayed in indexed pool internal-creation history |

The same receipt includes `Initialize`, the initial BTRFLY transfer, and liquidity mint. These are creation facts, not 2024 campaign trades.

Pool explorer source: https://etherscan.io/address/0x3e6e23198679419cd73bb6376518dcc5168c8260 (web ref `historical retrieval`). Token source: https://etherscan.io/address/0xc55126051B22eBb829D00368f4B12Bde432de5Da (web ref `historical retrieval`).

Uniswap’s primary documentation identifies pool addresses using the two tokens plus fee tier; the creator event supplies all three fields. Source: https://developers.uniswap.org/docs/sdks/v3/guides/pool-data (`historical retrieval`).

## Campaign mapping: strong match, attribution still unresolved

The retrospective's token pair, venue, and fee match this pool, but it supplies no address or raw dataset. Campaign mapping is therefore an inference. Frontend attribution remains unresolved; a standard router cannot identify the originating website.

Source: https://medium.com/@KaskadeFinance/kaskade-x-redacted-campaign-analysis-f169098f970f (`historical retrieval`).

The earlier candidate `0xdf9ab3c649005ebfdf682d2302ca1f673e0d37a2` remains **unverified for this campaign and must not be used**. Exact-address search found it in a March 2022 holder-table example, before the verified V2 pool was created. That is an obsolete-token lead, not enough evidence to establish its immutable token configuration here. A DEXTools ticker match was insufficient. Discovery-only source: https://stackoverflow.com/questions/71385737/scraping-table-using-beautiful-soup (`historical retrieval`).

## Precisely defined historical sample

One post-campaign transaction was inspected to discover and corroborate the V2 pool. It is **not counted as a campaign transaction** and provides no wash-trading finding:

- Transaction: `0xe6a7382851c687cf9c5b4621861313562bc3804aa9163e1e1c21cd7d82e6cb37`
- Block 19,791,642; 2024-05-03 19:21:47 UTC; successful CoW Protocol settlement interacting with the above pool.
- The pool received `214.671362679304956421` BTRFLY and sent `15.106643594249015653` WETH to the settlement contract.
- User-level BTRFLY sent was `214.68585375439804286`, distinct from the pool receipt. Do not treat settlement, user, and pool legs as three independent trades or three times the turnover.
- Fee: `0.001616459638413078` ETH.

Source: https://etherscan.io/tx/0xe6a7382851c687cf9c5b4621861313562bc3804aa9163e1e1c21cd7d82e6cb37 (`historical retrieval`); live browser overview independently inspected before access became blocked. Explorer present-day USD labels were deliberately excluded from historical valuation.

## Coverage limits and failed paths

No complete March 18–April 7 swap export, campaign-specific distributor, reward claim, participant leaderboard, or retention dataset was obtained. The total reconstructed campaign trades in this follow-up is **zero**, not an assertion of no trading.

Etherscan's Advanced Filter, reached through the verified pool's own link, displayed persistent Cloudflare security verification. After a later visible-state check remained on the challenge, the block was reported and this browser route stopped. No CAPTCHA, fingerprint changes, alternate Etherscan routes, credentials, wallet connections, or transactions were attempted. Uniswap's legacy pool analytics URL redirected in web retrieval to its generic Explore application; the direct official-interface navigation timed out. Neither path yielded historical campaign data.

The issuer's aggregates and reported reward values therefore remain issuer-reported. Future reproduction requires the authenticated frontend attribution rule, campaign participants or tagged router, distributor address, complete swap/claim/rebate events, and epoch timestamps. Full pool events alone cannot assign frontend origin or prove unique human traders.

## Derived checks, not new chain evidence

Issuer figures imply that 13.84% of reported traders made 45% of trades: approximately 5.09 times the other group's average frequency, with 42.9% of its average trade size. Those calculations cannot distinguish arbitrage, farming, or manipulation. The claimed $32,000 fees equal exactly 1% of $3.2 million; the figures are not independent corroboration. Sponsor profitability additionally requires LP beneficiary attribution, rebate costs, and other expenses.

## Attribution safeguard

Laura's reported month-only CMO tenure endpoint in March 2024 leaves possible temporal overlap. None of these pool records identifies her, assigns wallet ownership to her, or proves she selected the scoring model or authorized trades. April Liquity trading loops are separate evidence and were not imported into this campaign assessment.
