# Research Paper — Forty recipients present in both Tornado windows — completed continuation

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

## Main result

One newly examined public withdrawal route reaches a Binance-disclosed address **25 minutes 33 seconds after the first of five 100-BNB withdrawals**. Six additional recipient-to-collector-to-Binance intervals are verified. A further route reaches a **KuCoin 28 explorer-labeled** address. None of these withdrawals has been paired to a GamiFi deposit commitment. The amounts describe public Tornado users and their onward payments; they are not additional established GamiFi proceeds or losses.

All 40 recipient addresses appearing in both expanded April and July windows were examined. They appear in 288 withdrawal events: 196 April events (6,460 BNB gross) and 92 July events (2,090 BNB gross). `register_40.json` gives each address, branch counts, denominations, hashes and exact history coverage. These public-pool amounts are intentionally not aggregated with the tracked 1,210-BNB GamiFi deposit total.

## Five withdrawals into a fully reconciled Binance route

On **3 August 2022**, five separate 100-BNB withdrawals reached `0x01a73190bc3daa9638ca1097aefe9ebe8875e0a5` between **16:34:34 and 16:41:28 UTC**. Each used a different relayer. Their total fees were 0.65475 BNB, leaving **499.34525 BNB** with the recipient. The recipient's balance was zero before the first withdrawal.

| UTC | Sender → receiver | BNB | Verified transaction |
|---|---|---:|---|
| 16:42:16 | 01a731 → 6ac367 | 499.345145 | [88b353](https://bscscan.com/tx/0x88b35344447f1fbe7d4868fedd187923e67d5e3b42ec226d9922d6da22e8fc85) |
| 16:42:43 | 6ac367 → a6b5a8 | 499.34504 | [efb3a4](https://bscscan.com/tx/0xefb3a4e3f08d092d4c51bac1744fcd7fadc26ae2d2c4d2644baea4ead85d63ca) |
| 17:00:07 | a6b5a8 → Binance 8894 | 499.345435 | [1e415e](https://bscscan.com/tx/0x1e415e17ab0ad658fa008a34426eeac24eec7085601b126404ed404450c945e4) |

Full intermediary addresses:

- `0x6ac367f0d34fb0b1828134c925b0863d07e2c11c`
- `0xa6b5a85f2f3d91e1b3bc037d9c8daa0bab4263da`
- Binance endpoint: `0x8894e0a0c962cb723c1976a4421c95949be2d4e3`, listed in Binance's 10 November 2022 organizational disclosure. The disclosure postdates these transfers and does not identify a customer.

All eight transactions have full RPC transaction, receipt and block captures. Each withdrawal receipt matches the corresponding pool log. Historical balances reconcile exactly for all three addresses. The recipient and first intermediary both start and end at zero. The final collector starts with **0.006395 BNB** and ends with **0.005895 BNB**. Thus its final output includes prior funds and it is not a complete sweep. The time from the last withdrawal to Binance is **18 minutes 39 seconds**.

Canonical evidence: `verified_five_withdrawal_binance_route.json`, with raw source paths for every transaction, receipt, block and balance. The address also received April-window withdrawals; neither month's note origin is identified.

## Six more verified collector-to-Binance intervals

Each row below includes a verified payment from a cross-month recipient into the listed collector and an onward payment from that collector to the same Binance 8894 endpoint. All transactions in each selected interval, plus the collector's opening and closing historical balances, were checked. All six balance equations pass. Several intervals contain prior or other incoming funds; their onward amounts cannot be assigned wholly to the initiating recipient.

| Repeat recipient | Collector | Onward BNB | Binance transaction |
|---|---|---:|---|
| b27bf6 | 684541 | 920.56202879 | [eb02cd](https://bscscan.com/tx/0xeb02cdd5d765a8273077a425f49b27350a205d30f838340ea899a28581c9a9eb) |
| edb394 | 0460ed | 51.575174938790401151 | [3a3af2](https://bscscan.com/tx/0x3a3af2a7537f6c5f020ccab202477f8dbf6f0637429badc24aa47bd1ff91f14b) |
| cdb73a | cca999 | 99.962855 | [69eccb](https://bscscan.com/tx/0x69eccb8facd443f8682bced6a8edcf26ff8521ccc30d466ec7262dc5299fcaea) |
| 35c2c6 | b5a97c | 49.999658195 | [8f2ece](https://bscscan.com/tx/0x8f2ece997abfa9c2d771f55548e12cba36ebe3506471366a1f0bc0b1f68be43d) |
| 6b063f | 90e30d | 43.462032 | [e55a6d](https://bscscan.com/tx/0xe55a6db55bd99b941c8b29a66a5c3ed81d1789541bf467c193ab378ff8833020) |
| 05356d | 4c77b7 | 60.179895 | [a1b1a5](https://bscscan.com/tx/0xa1b1a5238c91b6843a7aafa5fbba746d982f1aa733d674f57e477ee1ca1be437) |

`verified_binance_routes.json` provides exact addresses, dates, input amounts, all interval transactions, gas costs and retained balances. The 920.56202879-BNB payment includes a 299.744045-BNB payment from the repeat recipient, 599.318195 BNB from another address and earlier balance. It is not a 920-BNB withdrawal attributed to that recipient or to GamiFi. All collectors retain a small balance at the verified interval end.

## KuCoin-labeled route

On **4 August 2022 at 05:37:07 UTC**, `0x5803aec37dd94b2f90db372d183c8920e0c1b351` received a 10-BNB-pool withdrawal, net **9.98305 BNB**. At 05:50:40 it sent **10 BNB** to `0x22c49cfa901768f12a091c2ccb298682f3db53bf`. At 06:51:20 that intermediary sent **9.999895 BNB** to `0x635308e731a878741bfec299e67f5fd28c7553d9`:

[Onward transaction 062760](https://bscscan.com/tx/0x062760055ae7087b465883df695dbb196469e50904f4828d744c7ad2370ae087).

[BscScan](https://goto.bscscan.com/address/0x635308e731a878741bfec299e67f5fd28c7553d9) labels the endpoint **KuCoin 28**, explicitly based on hildobby's compilation. This is an explorer attribution, not an exchange-published wallet attestation. All three transactions/receipts/blocks, the exact withdrawal log, and two historical balance equations are verified. The initial recipient already held **7.2455557 BNB**, so the 10-BNB payment contains a mixed balance and is not an exclusive transfer of the new withdrawal. No GamiFi note pairing is established.

An earlier 5.99985-BNB payment to a different KuCoin-labeled endpoint occurred on 13 March 2022, before the tracked deposits. It is retained as background only. Canonical: `verified_kucoin_labeled_route.json`.

## Other exact relationships and coverage limits

- The 40 histories contain **8,347 unique normal transactions**. Thirty-six indexes are complete under the stated pagination rule. Four retain lifetime gaps; only the `4f5b71…` and `c3a367…` gaps overlap the 2022 target windows. The `82ca345…` and `84ca63…` gaps occur later. The `58ef0d…` ascending/descending samples overlap in 231 hashes, producing 769 unique rows.
- **18 selected follow-up addresses** were examined: 17 complete normal indexes and one capped common-funder history (`41772e…`). Across this lane, 149 unique index-page captures were used: 125 newly retrieved and 24 reused. There are no failed attempts or unrecovered requests in these used captures.
- Exact comparison against the 116-address investigation register yields only infrastructure matches: PancakeSwap router, Tornado proxy, Binance addresses, and the known FixedFloat-associated address. No sampled native normal transfer matches a project funding/admin/control address. Separately, the 16 primary Binance addresses produce **41 incoming indexed payments** into these recipients and zero direct outgoing matches; the verified outbound paths use intermediaries.
- Nine full-receipt-verified payments totaling **55.47 BNB** link `c3a367…` to `52d0d9…`, March–June 2022. A separate address `41772e…` funds both `35c2c6…` and `6b063f…` in three verified payments. These are real relationships among pool users, not human-control or GamiFi-note identifications.
- Six full-receipt-verified payments totaling **6.626767 BNB** from the known FixedFloat-associated `472725…` address fund `c3a367…` between 3 January and 4 February 2024. They share service infrastructure with an earlier GamiFi route but do not establish a shared order or customer.
- Overall targeted verification retrieved **44 full transactions, 44 receipts, 43 distinct block headers, and 22 historical balances**. This is not an internal-transfer or token census. The source inventory records hashes of all raw captures and reused dependencies.

Canonical composite: `findings.json`. Supporting inventories: `register_40.json`, `analysis.json`, `followup_coverage.json`, `second_hop_coverage.json`, and `SHA256_MANIFEST.json`.
