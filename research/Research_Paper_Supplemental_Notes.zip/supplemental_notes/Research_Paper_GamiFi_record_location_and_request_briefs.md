# Research Paper — GamiFi — record-location and request briefs

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Prepared 6 September 2026. **Unsent working briefs for an investigator or properly authorized representative.** No provider, company, individual or regulator has been contacted. No private account or order record has been accessed. These briefs identify evidence to request; they do not certify that it exists, remains retained, or can be disclosed to the requester.

All transaction times are UTC. Blockchain: BNB Smart Chain, chain ID 56. GMI contract: `0x93d8d25e3c9a847a5da79f79ecac89461feca846`. BUSD contract: `0xe9e7cea3dedca5984780bafc599bd69add087d56`.

## 1. Corporate identity and key-custody records

**Prospective record holder:** GamiFi's responsible corporate record holder, once the legal entity is verified, and any identified development or key-custody contractor. GamiFi's archived terms describe GamiFi Limited as a BVI company; the terms do not provide the registry number. A registry match is still needed before identifying a specific company or registered agent as the correct recipient.

**Purpose:** establish who held and exercised each key for the particular actions below, in what capacity, and under what business instructions. A blockchain key and a CEO title are not substitutes for these records.

| UTC | Action | Full transaction |
|---|---|---|
| 2022-09-19 14:24:11 | Withdrawal Safe owner change: 7e01 → afd9 | `0x958512439479d367fc0afd13e8928f810dfe40b4945b084bc51fffedc5b9627b` |
| 2022-09-29T08:24:51+00:00 | Launchpool owner: original deployer → f27 | `0xa8b12962f2cecd9136794c2bef6c462c4b88d85ce0f9ba98275f4b033eb8bf75` |
| 2022-11-04T04:29:30+00:00 | ProxyAdmin owner: original deployer → 538a | `0xadbe145db91127aa89e416895092f4865b2c966ea5b3d2c39e359372b769bb66` |
| 2022-11-05T05:51:26+00:00 | ProxyAdmin owner: 538a → approval Safe6bf | `0xe1391addc79820a59676b049d2a4545719cbdc241b5d12164caab588beb5982a` |
| 2022-11-05 06:14:38 | Temporary implementations, GMI spending allowances, original implementations restored | `0x4af5d1dccd4008191749c6f193b552edd4e2d10d96028661eed4d508b8901a63` |
| 2022-11-05 06:45:09 | 44m GMI transfer, including 14m from Launchpool | `0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48` |

Relevant addresses:

- Original deployer / handover sender: `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`.
- Launchpool owner after 29 September: `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`.
- Upgrade-control signer: `0x538a8b615e98e87d025c4336be44e4b8588277c7`.
- Upgrade ProxyAdmin: `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475`.
- Approval Safe: `0x6bf55810ab061a016a968016818a6e1246aa8b5a`.
- Withdrawal Safe: `0x9362ced428b4179650252ad87731240b32ef25f3`.
- Withdrawal signer: `0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9`.
- Former withdrawal-Safe owner: `0x7e0135da76bb6cdb35ac5f1342808925e3ef7445`.
- Transaction executor: `0x343cebd1e7d1a6838cd8b82f6238b29ad78e235e`.

**Requested records:** the key-assignment/custody register and dated handover acknowledgments for these addresses; the relevant corporate or operational mandates; records showing authorized signatories and approvers on the transaction dates; instructions for the temporary upgrade, spending allowance, withdrawals and sale; and any corresponding settlement, refund or liability-adjustment records. Request attestations or custody documentation, **not private keys, seed phrases or passwords**.

For the separate 120m allocation, request the allocation agreement and any platform-account/wallet mapping for beneficiary `0x36048413c4edf0cf3e633aab317fcd9824dfb4d4`, linked to funding transaction `0xac39350f0f652c95dfb73e0cd8f2028a2c8aa34a51d081374a6c850647625787` (18 January 2022). The archived terms anticipate identity-verification records, but do not establish that this particular wallet used the account/KYC process.

Also request any settlement or recipient-assignment record for onward wallet `0xf4f86e37815217ed73ae817a4e5164d56315b1d7`. Its public human/business ownership remains unproved; the address prefix does not identify FixedFloat. The bounded follow-up establishes four BNB payments back to the private beneficiary totaling 12 BNB. One sent 1 BNB at 14:25:04 UTC on 4 November 2022, transaction `0x1d511630993eefca8a67f6a63e189a6e25054f340e0d8867a00c6b5fb67cfbf3`, 36 seconds before the large private claim. Request the instructions, business purpose and counterparties recorded for these transfers.

The same onward wallet paid 0.5 BNB to each of two addresses already present in the project trace: `0x78d09e1435e1906878621bcb0aaa9d47561214c3` at 13:07:05 UTC on 7 November 2022, transaction `0xdcd15c3761db237bf135a6733531ccbf8293f7c96197ea782c1cecb3d1822f72`, and `0x35b119730f79881dac623dc51c831c6a04cab5f3` at 14:00:56 UTC that day, transaction `0x2640f592d8b45f512e121a014b7de6b7293aaf8b06785bd388e66d9c13195520`. These are specific counterparties for accounting-record questions; no common human ownership is inferred.

Another unassigned recipient, `0xba4d665059c97d6baa42e097707a504aecafbf53`, received 6,590 BUSD and 25,906.285983337104699148 USDT in four payments. The ledger and *Historical file: counterparty_totals.json* preserve every transaction identifier. No business/service assignment was verified for this recipient. The sending wallet had commingled assets; those amounts cannot all be designated GamiFi proceeds.

## 2. FixedFloat — historical custody and order/payout mapping

**Attribution basis:** a provider-attributed administrator reply dated 10 May 2025 on FixedFloat's own FAQ-linked BestChange listing identifies `0x4727250679294802377dd6ca6541b8e459077c95` as a main BSC outgoing address. The reply is later than the transactions and is hosted on a third-party listing. Historical custody in November 2022 remains a question for the service.

**Identifier bundle:**

| UTC | Amount | From | To | Transaction |
|---|---:|---|---|---|
| 2022-11-05 07:15:11 | 5,174 BUSD | `0x35dc4a16db1e30036fee83e733ee065ad8535422` | `0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6` | `0x34bfa37b43fc0426e45ffcd3af9927be6495d4710f340f7f80e09d2fc41fe1b4` |
| 2022-11-05 07:15:32 | 5,174 BUSD | `0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6` | `0x4727250679294802377dd6ca6541b8e459077c95` | `0x7702b5e67906c5eb1dea5d1fdde0f7ade3e37cb5cd657944bd539ed460791e48` |

**Questions to resolve:**

1. Did the service control the destination on 5 November 2022, and was the intermediary one of its deposit/order addresses? Which operator holds the historical records?
2. Was the first transaction accepted as an order payment, credited another way, refunded, or unrecognized? Supply any associated order identifier and bookkeeping.
3. For a matched order, identify its output asset, network, amount, payout address and transaction hash, and any refund or cancellation.
4. Identify any account or verification information actually retained and the available preservation process. The service supports no-registration exchanges, so a conventional named account cannot be presumed.

A pooled-wallet outgoing payment must be matched through the service's records, not inferred from a similar amount or nearby time.

The official support page currently publishes the published organizational contact for law enforcement and the published organizational contact for victims. Those labels do not establish the requester qualifies for either route. No request has been sent.

## 3. MEXC — four deposits and the credited account(s)

**Purpose:** confirm historical receiving-wallet custody, deposit-address assignment, whether each transfer was credited, and any linked trade or withdrawal. Do not assume that the common intermediary means a common customer account.

All four transfers below came through intermediary `0x9564f530d9f270a48c510a92c97b59248cefd464`:

| UTC | GMI | Destination | Transaction |
|---|---:|---|---|
| 2022-11-04T15:00:29+00:00 | 5000000 | `0x2e8f79ad740de90dc5f5a9f0d8d9661a60725e64` | `0x7f8323049c6585d0dee94b8ba6b7dcb96d9bd0f2ac11617a00ca2299cb7ae3a8` |
| 2022-11-08T17:48:21+00:00 | 5000000 | `0x2e8f79ad740de90dc5f5a9f0d8d9661a60725e64` | `0xb0b3bf6768b4cb92820c90c4aca9a2103e3b49c753b31bf6258916b3dab5855c` |
| 2022-12-08T02:27:14+00:00 | 5000000 | `0x2e8f79ad740de90dc5f5a9f0d8d9661a60725e64` | `0xff3ac1adab98247b4a1c468612618e00f322c6a7ab66b3b9825150a7f7aa4d8f` |
| 2023-01-21T02:34:05+00:00 | 3000000 | `0x4982085c9e2f89f2ecb8131eca71afad896e89cb` | `0x2e371d5d37cc3deaef36f8c4798f0a18256257304d8eb4db697e6b4414cec02e` |

The `4982…89cb` wallet was disclosed by MEXC in July 2021. The `2e8f…5e64` wallet appears in MEXC's current proof-of-reserves disclosures and current explorer labels; its 2022 custody still needs confirmation.

**Requested records:** the historically assigned deposit account(s), any credits/reversals, associated GMI order and execution records, related withdrawals linked by the exchange's own ledger, and identity/authority records actually held for those accounts. Request retention/preservation confirmation. Public delivery to a hot wallet alone proves neither credit nor sale.

MEXC's current official LEORS workflow is restricted to eligible agency/judicial officials. An authorized requester should supply their genuine capacity, case reference and legally appropriate process. No account access, request, preservation submission or identity claim has been made here.

## 4. Audit and deployment acceptance records

The corroborated GamiFi development repository contains public pull request #13, **fix audit report**, and #25, **Update code for audit**. They provide specific document-discovery targets. Neither title identifies an auditor, verifies a delivered report, or proves coverage of the deployed contracts or later administrative actions.

**Requested records:** any audit engagement letter, auditor identity, delivered report and version, audited source commit, contract-address scope, remediation correspondence, sign-off or deployment acceptance, and any later review of the upgrade/allowance mechanism. Relevant public links:

- https://github.com/sheandev/gamifiContracts/pull/13
- https://github.com/sheandev/gamifiContracts/pull/25
- https://github.com/sheandev/gamifiContracts/blob/main/.openzeppelin/unknown-56.json

The review of PeckShield's current public report catalog did not locate a GamiFi report. That is not proof that no private audit or engagement occurred and is not proof that the repository's audit references concern PeckShield.

## 5. BVI entity verification — manual lookup

The registry's security service blocked the research browser before any query could be entered. The registry lookup had not been completed in this historical pass. 1. Open https://www.bvifsc.vg/public-search and choose Entity Search.
2. Search **GamiFi Limited**, then **GAMIFI** if necessary.
3. Record the exact legal name, company number, incorporation date, status and registered agent. A name match alone must be compared with the project's 2022 chronology.
4. If a paid report is offered, record the report names and prices before deciding what to purchase. The official information page says a search report includes registered-agent and filing-history information; additional filed documents may be requested separately.

The useful subsequent documents are the correct entity's historical corporate records and custody/authority records for 2022, not merely its present directors or present registered agent. Corporate ownership and wallet-key custody are separate questions.

## Primary and attributed source links

- GamiFi archived terms, prior successful capture: https://web.archive.org/web/20221007163947id_/https://app.gamifi.gg/terms-and-conditions/
- BVI registry search information: https://www.bvifsc.vg/searches-bvi-registered-entities
- FixedFloat FAQ endorsing the listing: https://ff.io/ru/faq
- Provider-attributed exact-address reply: https://www.bestchange.ru/fixedfloat-exchanger-79.html (10 May 2025; review-page pagination may change)
- FixedFloat support: https://ff.io/support
- MEXC 2021 wallet disclosure: https://mexcglobal.medium.com/recent-rumors-against-mexc-global-clarified-7205e6828907
- MEXC current wallet disclosure: https://www.mexc.com/nb-NO/proof-of-reserve?page=34
- MEXC current record-access guidance: https://www.mexc.com/support/article/law-enforcement-guidelines-4403594593434

No Cayman bank account, Laura-owned receiving wallet or personal bank receipt has been established. The briefs are evidence-location tools; they do not assign wrongdoing or substitute a company title for a verified signing-key identity.
