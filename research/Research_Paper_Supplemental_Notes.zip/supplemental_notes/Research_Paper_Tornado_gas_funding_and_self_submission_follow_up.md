# Research Paper — Tornado gas funding and self-submission follow-up

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The missing gas-funding source is resolved: **the candidate account was seeded by a paid-relayer withdrawal from Tornado's 0.1 BNB pool**, four minutes and three seconds before its first self-submitted withdrawal. This exposes another privacy-pool withdrawal; it does not expose a bridge input or a GamiFi/control-key payment.

Account: `0x1cf0eeeb39fe5c8316e505bdcb5f1c8252598661` on BSC. It was selected because eight zero-fee withdrawals fell in the previously examined July window, not because ownership or note attribution was established.

## Verified gas seed

- 2022-07-18 18:14:50 UTC, transaction [0xec9bb8994686bb40ecb3b16917639d37cc859d1e081644acb4700766fd14b80d](https://bscscan.com/tx/0xec9bb8994686bb40ecb3b16917639d37cc859d1e081644acb4700766fd14b80d).
- Pool `0x84443cfd09a48af6ef360c6976c5392ac5023a1f`: 0.1 BNB denomination; recipient 1cf0 received **0.0979 BNB**; relayer `0x12d92fed171f16b3a05acb1542b40648e7ced384` received **0.0021 BNB** and also submitted the transaction.
- Independently verified by successful transaction/receipt and Withdrawal log, archive call trace containing the native payment, and historical balance/nonce: block 19,665,329 balance 0 and nonce 0; block 19,665,330 balance 0.0979 BNB and nonce 0.
- Before the first self-submission, block 19,665,410 still has 0.0979 BNB and nonce 0. The first self-submitted 10 BNB withdrawal at 18:18:53 used nonce 0: [0xf5bdd232def468d9b9b95565321a42ea7e119377a3b0671afa6d02e6249aa8f8](https://bscscan.com/tx/0xf5bdd232def468d9b9b95565321a42ea7e119377a3b0671afa6d02e6249aa8f8).

## Complete observed account accounting

The fresh normal index returned all **90 reported rows**, all sent by 1cf0. The internal index returned all **85 reported rows**, all inbound payouts from Tornado's four BSC BNB pools. All **93 unique transactions** across those indexes have independently fetched full transactions and receipts; all succeeded. Every indexed inbound payout matches a decoded Withdrawal event for recipient, pool, and exact net amount. The 90 sender nonces cover **0 through 89 without gaps** and match the pinned chain transaction count of 90.

The 85 withdrawals comprise 49 × 0.1 BNB, 9 × 1 BNB, 25 × 10 BNB and 2 × 100 BNB: **463.9 BNB gross**, less **0.0076 BNB relayer fees**. Of these, 82 were self-submitted; three were submitted by other relayers. These counts include the prior eight zero-fee records and must not be added to them.

| Observed native balance component | BNB |
|---|---:|
| Net Tornado withdrawals received | 463.8924 |
| Seven verified Tornado redeposits: six × 1 and one × 0.1 | −6.1 |
| Final forwarding transfer | −457.631418205 |
| Gas paid across all 90 sender transactions | −0.160981795 |
| Residual | **0** |

The current pin is block **120,507,266**, 2026-09-07 14:04:51 UTC: nonce 90, balance 0, code `0x`. Contiguous sender nonces and exact balance reconciliation support the observed accounting; they do not prove absence of every possible unindexed offsetting internal event.

## First onward transfer

On **2022-08-03 20:58:48 UTC**, nonce 89 sent **457.631418205 BNB** to `0x829254368b9b46ea4d12ac2324728d2e0495ea3a` in [0x2dfbeae6c9724b1950fd10dc76fda1a229c7d21875127ae662eacb20007ce1d4](https://bscscan.com/tx/0x2dfbeae6c9724b1950fd10dc76fda1a229c7d21875127ae662eacb20007ce1d4). The successful receipt, full transaction and block header were fetched. Adjacent archive balances are 457.631523205 BNB before the block and 0 after; the difference is the transfer plus exactly 0.000105 BNB gas.

For this forwarder, all **94 normal, 62 internal and 42 token rows** reported by the address index were retrieved. `first_forwarder_index_findings.json` records subsequent outbound amounts and full hashes. Four August 21 USDT payments total **141,207.582674659643341201 USDT** to `0x20f0ad2e0bd202a57bdf1aa53524145a2e8d5f4d`; a November 23 payment adds **70,175.610656935028897864 USDT**. These onward index leads are handed to the main investigation for receipt/bridge verification. They are outside this subtask's 93-transaction verification scope.

## Link assessment

All ten direct account counterparties and observed relayer addresses were compared with the prior 116-address register. The only exact matches are the shared Tornado proxy and its 10/100 BNB pools. There is **no exact project/control/exchange address match** among 1cf0, its three paid relayers, or its first forwarder.

The gas seed predates the July 26 GamiFi-linked sale/liquidity removal. This account's flows are traceable after withdrawal, but **no particular withdrawal here has been linked to a GamiFi deposit**. The main investigation's separate historical Merkle-root analysis may further exclude candidate withdrawals; that result is not assumed here. Do not present the 457.63 BNB or downstream stablecoins as recovered GamiFi money or as an identified exchange exit.

## Evidence and limits

Canonical machine files: `gas_findings.json`, `verified_account_transactions.json`, `verified_account_withdrawals.json`, `first_forwarder_index_findings.json` and `raw/`. Raw request/response wrappers include URL, method/params and retrieval UTC. The first seed has an independent debug call trace; the remaining indexed payouts are receipt-event verified rather than individually debug-traced. Selected birth, first self-withdrawal, final forwarding and pinned times have independently fetched headers; other retained UTC values are index timestamps. Official pool mapping is retained from the prior verified deployment evidence, with its pinned source provenance.
