# Research Paper — Tornado Cash — Public BSC RPC alternative probe

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Captured 2026-09-07 14:06:43–14:06:52 UTC. Read-only historical `eth_getLogs` requests used both official BSC Tornado 10 BNB and 100 BNB pool addresses and the exact Withdrawal topic. The tested inclusive interval was 17,355,471–17,365,469 (9,999 blocks), with a preserved existing archive response containing 67 logs as the comparison baseline.

| Endpoint | Result | Seconds |
|---|---|---:|
| bsc-rpc.publicnode.com | HTTP 403, error code 1010 | 7.753 |
| bsc.drpc.org | HTTP 403, error code 1010 | 7.422 |
| binance.llamarpc.com | HTTP 502, connection refused | 7.749 |
| rpc.ankr.com/bsc | JSON-RPC -32000, API authentication required | 8.121 |
| bsc-dataseed.bnbchain.org | JSON-RPC -32005, limit exceeded | 7.512 |

No endpoint returned logs, so none could be validated against the 67 baseline transaction-hash/log-index pairs. No larger-range probe was issued. These results establish failure of these specific unauthenticated requests from this environment, not that the endpoints never support historical logs. There was no retry using credentials, evasion of access controls, or request to the archive endpoint.

`small_0.json` through `small_4.json` preserve request parameters, endpoint, timing, HTTP status and headers, parsed response or complete decoded body, and response-body hash. Matching `_response.bin` files retain exact response bytes. `baseline_source.json` records the existing successful response path/hash and all 67 comparison keys. `small_summary.json`, `large_summary.json`, and `manifest.json` provide machine-readable result and integrity records.

## Authorized extension: two additional official dataseed hostnames

Both used the identical request and 67-log baseline.

| Endpoint | Result | Seconds |
|---|---|---:|
| https://bsc-dataseed1.defibit.io | {"jsonrpc": "2.0", "id": 1, "error": {"code": -32005, "message": "limit exceeded"}} | 6.775 |
| https://bsc-dataseed1.ninicoin.io | {"jsonrpc": "2.0", "id": 1, "error": {"code": -32005, "message": "limit exceeded"}} | 7.06 |

Full request/response captures are `official_0.json`, `official_1.json`, and matching response binary files. Seven endpoints were tested in total, following explicit authorization to extend the original five-endpoint cap.
