# Research Paper — Time Raiders: buyer delivery and a separate November 2025 withdrawal

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Evidence collected 7 September 2026 UTC. Polygon chain ID 137 unless explicitly labelled BSC chain ID 56. This is a working evidence memorandum for incorporation into the master investigation.

## Findings that change the account

**The original GamiFi Time Raiders funders did receive tokens. A separate, much later event removed the remaining tokens from their Polygon vesting contract and sold them. Neither result establishes that Laura performed or approved that event.**

The complete project-7 BSC funding-window census identifies 111 contributions from 80 distinct wallet addresses, totalling **23,722.715761539594859905 BUSD**. All 80 addresses appear in the Polygon vesting allocation. Each allocation matches the original 0.022 BUSD-per-XPND rate exactly after applying the contract's rounding separately to each contribution. All 80 received the first distribution, verified through actual XPND transfer logs.

The vesting contract contained 149 allocation records in total. We verified all 440 ordinary transactions indexed as Claim: **437 succeeded and three reverted**. Every successful claim contains both a Claim event and a matching XPND token transfer. For **each of the 149 allocation addresses**, the initial payment plus these later transfers equals its historical claimed counter exactly.

At Polygon block **78,964,530**, 13 November 2025 **11:39:06 UTC**, the original vesting implementation still applied. The following figures reconcile both to the initial allocations and the primary payment receipts:

| Group | Addresses | Allocated XPND | Actually delivered XPND | Unclaimed XPND immediately before the upgrade |
|---|---:|---:|---:|---:|
| Original BSC project-7 funders | 80 | 1,078,305.261888163402722904 | 634,523.415691679492334646 | 443,781.846196483910388258 |
| Other allocation addresses | 69 | 2,330,785.738111836597277096 | 1,261,989.920557900869328958 | 1,068,795.817553935727948138 |
| All recorded allocations | 149 | 3,409,091 | 1,896,513.336249580361663604 | **1,512,577.663750419638336396** |

Of the original 80 funding addresses, **42 had fully claimed**, **23 had received later claims but were incomplete**, and **15 had only the initial distribution**. Thus **38 of the original 80 funding addresses**, and **107 of all 149 allocation addresses**, still had an unclaimed recorded amount. These are addresses, not a proven count of individual people. The 69 other allocation addresses have not been assigned a commercial funding source or human identity.

The total unclaimed amount **exactly equalled the vesting contract's token balance**, and then **exactly equalled the amount withdrawn on 13 November 2025**. The original vesting schedule had ended on **14 September 2022 at 12:37:03 UTC**, so these amounts were mature under the original contract's claim rules. Later compensation, replacement arrangements and the legal treatment of those records remain unresolved.

## The 13 November 2025 sequence

All four decisive transactions below succeeded. Dates are from primary Polygon receipt/block timestamps, with explorer pages preserved independently where available.

| Time UTC | Block | Action | Primary transaction |
|---|---:|---|---|
| 11:37:26 | 78,964,480 | A type-4 EIP-7702 transaction replaces the original admin address's existing code delegation. During the same transaction, the ProxyAdmin owner changes from `3e0f…7199` to `4d96…ed55`. | `0x4e8f533f07d6294332437777661389d9fb6668c768bc49c645c5c868af3b2d84` |
| 11:39:08 | 78,964,531 | The new ProxyAdmin owner calls the upgrade function, replacing the vesting implementation. | `0x70b2ca519be59b73947714d7c9fcc7dcfe0b8aa4e3a2f59ad5f97044f494755a` |
| 11:40:16 | 78,964,565 | The same caller withdraws **1,512,577.663750419638336396 XPND** from the vesting proxy to itself. The proxy's XPND balance becomes zero. | `0xbd929f950089a74c90bff99743514421126bf31a9abd4c943fefb6cee317b38a` |
| 11:46:10 | 78,964,742 | The recipient sends the full withdrawn amount into a 1inch Router v6 transaction. After the route's intermediate swaps and native-token unwrap, **325.142524926446493136 POL** is paid to the same recipient. | `0x97b91a02cd4efa3668fccfe2962e40fb7f398c3587b3a4613ff8bbbd65aeff64` |

The swap is demonstrated by its receipt, not inferred merely from a nearby transfer. The recipient had **zero XPND before the vesting withdrawal**, the **exact withdrawn amount immediately before the swap**, and **zero immediately after the swap**. A complete, bounded XPND-outflow search covering blocks 78,964,565–79,009,564 found this one outgoing transfer from that recipient. This includes transfers made through an approved spender.

Within the swap transaction, 3,781.44415937604909584 XPND goes to `0xcd6b980029e6e6e0733ac8ec3e02be9410d09799`, and the remaining 1,508,796.219591043589240556 XPND goes to a swap pair. The separate split is not assigned a contractual purpose here. The route receives 56.841822 units of token `0x2791…4174` (historical symbol USDC, six decimals), then 0.00055277 WBTC, then 325.142524926446493136 WPOL. The WPOL is unwrapped and the final native POL payment goes to `4d96…ed55`.

The native system-contract LogTransfer event records both the amount and the recipient's before/after balances; the increase equals the stated POL amount exactly. This is a **gross payout** of 325.142524926446493136 POL. Deducting this swap transaction's 0.09397863443621738 POL gas cost leaves **325.048546292010275756 POL net of this transaction's gas**, excluding fees for the preceding ownership, upgrade and withdrawal transactions. The intermediate USDC, WBTC and WPOL amounts are steps within this one route, not additional proceeds to add to the final POL payout. Neither payout figure is a US-dollar valuation of the historical token entitlement, the original BSC funding or customer damages.

## Two different forms of admin control

The vesting contract was created on **18 March 2022 at 08:46:55 UTC**, block 26,068,913, by `3e0f…7199`. Its initial distribution was made by that same address at **12:37:03 UTC**, block 26,074,871. That transaction transferred 3,409,091 XPND into the contract and immediately paid the 149 allocation addresses their initial amounts, totalling 511,363.649999999999999897 XPND.

On **29 September 2022**, transaction `0x8f0d64e9b434bc9da6b06e16b91442739e126ae2ab54f2db7839991afea38c8d` changed the vesting contract's **business-logic owner** from `3e0f…7199` to `f27f…c27b`. Historical calls immediately before and after that transaction verify the change.

However, the distinct **ProxyAdmin owner**, which could replace the entire vesting implementation, remained `3e0f…7199` at that point and immediately before the November 2025 change. Immediately before the 2025 upgrade, the ordinary vesting owner was still `f27f…c27b`. A transfer of the ordinary vesting owner therefore does not, by itself, establish transfer or revocation of upgrade authority.

The November 2025 ownership-change transaction was sent externally by `4d96…ed55` to the original admin address `3e0f…7199`. It was not an ordinary transaction externally sent by `3e0f…7199`. It carried an EIP-7702 authorization tuple, and its calldata included the ProxyAdmin ownership-transfer call. Applying the EIP's specified signature-recovery formula recovers **exactly `3e0f…7199` as the authorization authority**. The calculation, input bytes, digest, signature fields and independent on-chain ecrecover response are saved.

At block 78,964,479, the original admin address was already delegated to `0xa50fe3ea063719cd7b028c1938bbc0e5fd58db66`, with nonce 35. At block 78,964,480, its delegation had changed to `0xaf271f06ae4cecca813df93ca096d65d5efb67e9`, with nonce 36. Accordingly, the evidence shows **replacement of an existing delegation**, not the first creation of delegated authority.

A valid authorization signature ties the code delegation to the address's cryptographic authority. The signed tuple commits to a chain, code target and nonce; it does **not** itself sign a business mandate or the explicit ProxyAdmin transfer instruction. It does not identify the person using the key, establish informed business approval, or distinguish a deliberate action from compromised credentials or a misleading signing request. No such human attribution is made here. A separate reviewer independently reconstructed the digest and recovered the signer using local secp256k1 arithmetic, without relying on RPC ecrecover; the low-s and ECDSA checks passed. See `peer_review_7702.py` and `peer_review_7702.json`.

## Address register

| Role | Chain | Full address |
|---|---|---|
| Original project-7 funding contract | BSC 56 | `0x56c0cb2d047b69278f49b4759c1718436a546c7f` |
| Original BUSD withdrawal recipient | BSC 56 | `0xd2b806f9c0352a267ce7ccf33e74d68c070d6171` |
| Issuer-identified XPND token | Polygon 137 | `0x03f61137bfb86be07394f0fd07a33984020f96d8` |
| GamiFi project-7 vesting proxy | Polygon 137 | `0xcfb37488ee5ebbadf9b879c05d318beb7b85f6a5` |
| Original vesting implementation | Polygon 137 | `0xfa83e6a35d98e5243cd3e5740b6f52daa316c075` |
| ProxyAdmin | Polygon 137 | `0x7ece517ee810f95f540c0ebdbdb09c4ae3d64720` |
| Original deployment/admin address | Polygon 137 | `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199` |
| Vesting owner after September 2022 transfer | Polygon 137 | `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b` |
| New 2025 implementation | Polygon 137 | `0xd346309df75eb6832bdc90dd8ba3b8e0264c97e3` |
| New 2025 code delegate | Polygon 137 | `0xaf271f06ae4cecca813df93ca096d65d5efb67e9` |
| 2025 caller, withdrawal recipient and swap beneficiary | Polygon 137 | `0x4d96f2d2143dd74a96d015a70953a5686fa6ed55` |
| 1inch Router v6 | Polygon 137 | `0x111111125421ca6dc452d289314280a0f8842a65` |
| Swap execution address | Polygon 137 | `0x8c864d0c8e476bf9eb9d620c10e1296fb0e2f940` |

The original implementation address also appears elsewhere in the investigation on **BSC with different contract code**. An equal address on a different chain is not the same contract.

## Verification and evidence files

* **Funding coverage:** `bsc_project7_funding_logs.json` preserves six adjacent successful log queries covering the complete configured BSC funding window, blocks 16,083,700–16,141,300 inclusive. `bsc_project7_funders.json` aggregates 111 events into 80 addresses. `bsc_funder_initial_delivery_reconciliation.json` records exact per-contribution price reconciliation for all 80.
* **Initial delivery:** `initial_vests_transaction.json` contains the primary transaction and receipt. `initial_allocations.json` decodes its 149 records. `initial_transfer_verification.json` verifies every initial transfer against the calldata. Initial transaction: `0x3900a0e07fededf79d5479c25bf50ba68ed61f6defd9964bcd167f589bdf34d4`.
* **Subsequent delivery:** `explorer_transaction_index.json` contains 444 unique ordinary transactions, matching the explorer's total across five preserved pages. `claim_receipts_verified.json` contains all 440 Claim-call receipt results, including the three failures, and the exact 149-address reconciliation. Last successful indexed claim: 3 June 2024, transaction `0xde67826dd6aa7752af88997ea8c98eefe131da185196d8b239e4e3ff838190a3`.
* **Customer ledgers:** `all149_buyer_delivery_ledger.csv` and `original80_bsc_funder_delivery_ledger.csv` give address-level funding, allocations, actual receipts and historical unclaimed amounts. `pre_upgrade_claim_states.json` contains all 149 historical getter responses decoded at block 78,964,530.
* **Runtime and ownership:** `vesting_compiler_input.json`, `vesting_compiler_output.json`, and `vesting_compiler_provenance.json` document independent compilation with Solidity 0.8.4. The resulting **4,960-byte runtime matches the on-chain original implementation exactly** at creation and immediately before the 2025 upgrade. `final_pins_and_runtime_verification.json` also preserves the September 2022 ownership receipt and historical owner calls.
* **2025 mechanism:** `proxyadmin_owner_transfer_2025.json`, `authorization_recovery.json`, `event2025_transactions.json`, and `event2025_states.json` preserve the primary transactions, authorization recovery and historical before/after balances, implementation and admin slots.
* **2025 onward proceeds:** `recipient2025_bounded_onward.json`, `recipient2025_onward_transaction.json`, `recipient2025_swap_asset_verification.json`, and `recipient2025_swap_decoded.json` preserve bounded transfer coverage, the swap receipt, historical token metadata and native payout/balance verification.
* **Raw provenance:** `chain_raw/` contains endpoint, request, response and collection UTC for original RPC queries. Explorer HTML and matching `.meta.json` files preserve URL, collection UTC and SHA-256. Source-code extracts are under `contract_sources/`. `SHA256SUMS.txt` inventories the evidence files, excluding dependency directories, Python caches and itself.

Current zero balance is pinned at Polygon block **93,358,017**, hash `0xe2a1912dcb06a1edbe5fbf2ed330ede7b499927e5b5cb5f0dd9fc50c08bbd71b`, timestamp **7 September 2026 00:47:39 UTC**. This snapshot is not a claim that the balance was continuously zero throughout every intervening block.

The public Polygon RPC used for successful historical retrieval was `https://rpc-mainnet.matic.quiknode.pro`. Broad log calls were rejected for exceeding the provider's block-range limit; those failures are preserved. The ordinary transaction index and the exact receipt/state reconciliation are a bounded substitute for this question, **not** a claim of an unrestricted all-block internal-call census.

## Public source anchors and limitations

Issuer token identification: https://medium.com/timeraiders/how-to-buy-xpnd-on-quickswap-the-ultimate-guide-d3b81a3e7a9b . The issuer's March 2022 article supplies the Polygon XPND address. Retrieved through web search; a direct archival HTML attempt returned HTTP 403, preserved in `xpnd_issuer_token_primary.meta.json`.

EIP-7702 authoritative format and signature-recovery rules: https://eips.ethereum.org/EIPS/eip-7702 . Preserved as `eip7702_primary.html`.

1inch's own deployment list identifies the exact Router v6 address on Polygon: https://github.com/1inch/limit-order-protocol . Its README is preserved as `oneinch_router_primary.md`.

Polygon's native system-token address is documented at https://docs.polygon.technology/pos/reference/contracts/genesis-contracts . The LogTransfer event's amount and before/after-balance fields are described by Polygon at https://medium.com/the-polygon-blog/finer-details-of-matics-plasma-implementation-jaynti-kanani-d333550fa71d . Polygon's September 2024 native-token name change is documented at https://polygon.technology/blog/matic-to-pol-migration-is-now-live-everything-you-need-to-know . These support labelling the 2025 native payout POL rather than relying on an outdated display ticker.

The preserved Polygonscan pages label the 2025 caller `Fake_Phishing1420456` and the new implementation `Fake_Phishing1509325`. Those are explorer annotations, **not** independently established legal findings or human identification. The chain mechanism, balances and sale are independently verified as set out above.

The existing first-party Time Raiders/GamiFi notice corpus is predominantly from 2022. Limited current searches did not identify a relevant 2025 migration, compensation or incident disclosure; they do **not** prove none existed. We have not established the commercial status of every allocation, any later replacement payment, the economic value of each outstanding claim, who obtained or used the relevant signing authority, or whether a particular person knew of or authorized the events.

Finally, the **23,722.715761539594859905 BUSD located at `d2b8…6171` on BSC** is a different asset on a different chain. Its original withdrawal/current holding is documented in `project_withdrawals_work/recipientd2b8/`. The new Polygon XPND withdrawal and swap do not establish that the BUSD was stolen, settled to a bank, or received personally by Laura. The November 2025 events cannot explain a September 2022 departure without separate evidence connecting them.
