# Research Paper — KIDLetCoin curriculum: provenance and evidentiary assessment

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Reviewed 5 September 2026. Scope: the supplied PDF, its GitLab publication history, and its promotion by the KIDLetCoin Twitter account. This is a separate addendum; it does not replace the existing project investigation.

## Finding

The supplied PDF is demonstrably the file shared by KIDLetCoin's project Twitter account on 2 July 2020. GitLab attributes the PDF upload to **D K (@kln_nurv)** on 30 June 2020. The public account's full real-world identity and relationship to Laura Takenaka remain unverified. The PDF provides a direct connection to the project's public educational outreach, but it does not establish Foundation funding, Laura's authorship, or collection of children's information through this document.

## Verified publication chain

| Evidence | Result |
|---|---|
| GitLab namespace | Group `free-blockchain-curriculum`, display name `free blockchain curriculum` |
| Project | `free-blockchain-curriculum/free-blockchain-curriculum`, project ID 18610512 |
| Project creation | 6 May 2020 |
| GitLab project creator | User ID 5604513; matches the account linked as the PDF commit's author |
| PDF upload | Commit `e9d3f30f10ab953471b952dbb9624106d0c0d129`, message `Upload New File` |
| Upload attribution | Author/committer name `D K`; GitLab author link resolves to `@kln_nurv`, user ID 5604513 |
| Commit timestamp | 30 June 2020, 06:55:41 UTC |
| File addition | The commit diff identifies `blockchain-curriculum.pdf` as a new file |
| Supplied URL branch | `latest`, pointing to the above commit when inspected |
| Public profile | D K / @kln_nurv; member since 13 March 2020; no verified full name or explanatory biography recovered |
| Project promotion | The archived 2 July 2020 `@kidletcoin` post links to the exact supplied GitLab URL |
| File identity | The historical PDF copy and the PDF fetched at the immutable commit are byte-identical: 1,609,807 bytes |
| SHA-256 | `9f81e9a98fd8203b8c424d620f3307899850f3a4c05b78acad3ffe2e74f0b396` |

The tweet says the project had been affected by pandemic/home-schooling disruption, offers a blockchain curriculum, and says it will also appear on the website. It tags `@NEMofficial`. The archive's HTML preserves the expanded GitLab link, independently corroborating the curriculum’s stated source. A tag does not establish endorsement, funding, or a response from the tagged organization.

GitLab identifies an account associated with the upload. It does not independently authenticate that account holder's legal identity. The same username on unrelated services is not enough to identify a person.

Sources:

- [PDF upload commit](https://gitlab.com/free-blockchain-curriculum/free-blockchain-curriculum/-/commit/e9d3f30f10ab953471b952dbb9624106d0c0d129)
- [Public GitLab profile](https://gitlab.com/kln_nurv)
- [GitLab project metadata](https://gitlab.com/api/v4/projects/18610512)
- [PDF-specific commit history](https://gitlab.com/api/v4/projects/18610512/repository/commits?ref_name=latest&path=blockchain-curriculum.pdf&per_page=100)
- [Immutable PDF copy](https://gitlab.com/free-blockchain-curriculum/free-blockchain-curriculum/-/raw/e9d3f30f10ab953471b952dbb9624106d0c0d129/blockchain-curriculum.pdf)
- [Same-day archived KIDLetCoin tweet](https://web.archive.org/web/20200702154157id_/https://twitter.com/kidletcoin/status/1278708267678654464)

## What the document contains

The 111-page PDF is titled *Blockchains and Cryptocurrencies in the Real world*. Its cover describes educational reuse of permissively licensed materials without naming an author, editor, publisher, or sponsor. It reads as a compilation of general reference material, with chapters on blockchain, cryptocurrencies, regulation, Bitcoin, Ethereum, NEM, smart contracts, and CryptoKitties.

Physical PDF page numbers below refer to the viewer's page count; printed numbers differ.

| Location | Finding |
|---|---|
| PDF p.1 | Uncredited cover and educational-purpose statement |
| PDF pp.87-90 / printed pp.83-86 | Dedicated NEM chapter; discusses history, Foundation activity, NanoWallet, mosaics and token creation |
| PDF p.87 / printed p.83 | Describes the Foundation's general marketing, training and partnership activity; does not disclose sponsorship of this curriculum |
| PDF p.90 / printed p.86 | Describes XEM harvesting as a blockchain reward mechanism; no connection to harvesting personal information is stated |
| PDF pp.99-102 / printed pp.95-98 | General CryptoKitties material, not a KIDLet contest |
| PDF p.101 / printed p.97 | Unresolved citation-needed marker |
| PDF p.3 and pp.110-111 | Contents pagination mismatch and effectively empty glossary/index |

The full extracted text and embedded links supplied no Laura Takenaka or KIDLetCoin credit, contact email, child-photo/video submission instruction, enrollment form, or sponsor declaration.

PDF metadata reports Writer / LibreOffice 6.4 and a creation time of 30 June 2020, 13:54:17 +07:00 (06:54:17 UTC), shortly before the GitLab upload. No Author field was present. These editable metadata values do not prove a person's location or identity. The older repository ODT source also supplied no creator/editor name.

## Meaning of "sketchy"

The supported concerns in this file are weak authorship transparency, rough editorial quality, and historical material that should not be treated as a current technical or legal authority. Public hosting and a branch named `latest` do not amount to a current review or institutional endorsement.

Static PDF inspection found no JavaScript, executable launch actions, form submission actions, embedded files, or form fields. The annotation actions were HTTP(S) hyperlinks; no embedded KIDLet destination was identified. This is a limited structural inspection, not a malware-free certification or a live safety review of every linked website.

The separate KIDLet contest remains relevant to child privacy. Its request for identifying details, a video link and a wallet address is documented in the prior evidence audit; the currently indexed original contest page also retains the instruction to email the video link and wallet address to the project's published submission mailbox. A full fresh retrieval of the video description in this pass was rate-limited. Nothing in this curriculum establishes receipt, retention, access controls or misuse of submissions.

- [Original contest](https://www.youtube.com/watch?v=3ydvqwGaw0o)

## Relationship to Laura and NEM

Laura's public KIDLetCoin wallet-demo post describes the KID wallet as a NEMPay fork and discusses a next project milestone. Her public NEM election statement identifies her as NEM Thailand Country Lead. These sources establish project participation and NEM involvement independently of the curriculum.

- [Laura's KIDLetCoin wallet-demo post](https://www.linkedin.com/posts/lauralwalsh_kidletcoin-wallet-demo-video-activity-6491593875063439360-Nte8)
- [Laura's NEM candidacy statement](https://forum.nem.io/t/laura-takenaka-for-secretary-council/20442)

The defensible additional connection is: **GitLab account D K / @kln_nurv uploaded this PDF; KIDLetCoin's account publicly distributed it; its content includes NEM.** The tweet supplies evidence of project outreach continuing into July 2020. It does not identify who operated the Twitter account on that date, who commissioned the curriculum, or who funded it.

Unresolved attribution questions are the uploader's full identity, any project role or commission, and the human authorship of the promotional tweet. No identified document or record in this pass establishes that Laura uploaded or wrote the PDF, that NEM Foundation paid for it, or that it was a mechanism for collecting children's information.

## Method and limits

Reviewed the supplied local PDF, extracted its full text, visually inspected its cover and NEM chapter, inspected PDF object/action structures, retrieved GitLab public API/HTML and an immutable raw PDF, compared hashes and bytes, and recovered the archived tweet HTML and its expanded destination. GitLab and archive pages failed through one retrieval interface but succeeded through direct public HTTP reads. The source PDF was not modified.
