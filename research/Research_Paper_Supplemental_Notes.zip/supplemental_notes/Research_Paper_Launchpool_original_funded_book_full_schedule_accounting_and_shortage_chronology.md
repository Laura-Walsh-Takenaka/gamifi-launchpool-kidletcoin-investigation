# Research Paper — Launchpool original funded book: full schedule accounting and shortage chronology

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Observed at BNB Smart Chain block **120,235,949**, **6 September 2026 04:08:52 UTC**.

## Result

The original Launchpool funded schedule book reconciles exactly. The **14,000,000-GMI removal on 5 November 2022 created a 14,000,000-GMI backing deficit**, and the same exact deficit remains at the observation block. Later normal claims reduce both the remaining schedule balances and the tokens held, preserving that deficit.

This conclusion now covers **all 7,495 original funded schedules**, not just the previously sampled large beneficiary. It is an aggregate accounting closure, not a complete date-by-date census of every historical transaction.

| State | Original funded amount (GMI) | Cumulative claimed field (GMI) | Unpaid scheduled amount (GMI) | Vault tokens (GMI) | Backing deficit (GMI) |
|---|---:|---:|---:|---:|---:|
| Immediately before removal, block 22,786,455 | 15,456,885.882908530406846 | 533,820.314641446014626059 | 14,923,065.568267084392219941 | 14,923,065.568267084392219941 | 0 |
| Immediately after removal, block 22,786,456 | 15,456,885.882908530406846 | 533,820.314641446014626059 | 14,923,065.568267084392219941 | 923,065.568267084392219941 | **14,000,000** |
| Observation block 120,235,949 | 15,456,885.882908530406846 | 1,456,678.470579126225819039 | 14,000,207.412329404181026961 | 207.412329404181026961 | **14,000,000** |

All **7,495 `getVest` results are byte-for-byte identical immediately before and after the removal**. The transaction changed the token balance without reducing any original funded schedule's unpaid amount.

At the November date, unpaid scheduled amounts included tokens that would vest later; this table does not treat every future scheduled token as immediately claimable then. Every original schedule had fully matured by **14 January 2023 at 17:29:53 UTC**. At the 2026 observation, the remaining original scheduled amounts are mature.

Exact final reconciliation:

`15,456,885.882908530406846 funded − 1,456,678.470579126225819039 recorded claims − 14,000,000 removal = 207.412329404181026961 GMI held`

The arithmetic residual is **zero base units**. GMI has 18 decimals; these are token quantities, not dollars.

## How the full funded book was verified

1. Retrieved all **39 successful opening GMI funding transfers** in the previously verified opening window, blocks 17,082,000–17,091,999.
2. Retrieved and decoded the full input of each associated funding transaction. Every input calls `initiateVests` (`0x872e8f27`). These inputs enumerate **7,495 schedule creations across 7,490 distinct beneficiary addresses**, and the enumerated amounts sum exactly to the token funding total.
3. The initial 10-GMI transaction creates **two 5-GMI schedules**. The remaining 38 funding transactions create the 7,493 schedules corresponding to the previously recovered CSV. The counts differ from distinct addresses because five funded schedules reuse an address. Nonces distinguish those schedules.
4. Checked `getNonce` for every one of the 7,490 beneficiaries at block **17,084,823**, immediately before the opening funding transaction: every value was **zero**. This establishes the correct starting index for each decoded funding record.
5. Checked every beneficiary's nonce at the observation block: each exactly matches its number of decoded funded schedules. There are **no extra current schedules for any beneficiary in the original funded set**.
6. Derived every original `getVestId(address, nonce)` and retrieved every `getVest` using read-only `aggregate3` calls through Multicall3 `0xca11bde05977b3631167028862be2a173976ca11`. All current stored owners and amounts match the decoded funding inputs exactly.
7. Repeated the complete 7,495-record reads at the block immediately before and immediately after the November removal. Every full record is identical across those adjacent blocks. Between pre-removal and current records, all non-`claimed` fields are identical and every `claimed` field is greater than or equal to its earlier value.
8. Independently read canonical GMI `balanceOf` at each compared block. These are actual archive state reads, not balances inferred solely from the selected transfer ledger.

At observation, **684 schedules** across **683 distinct beneficiary addresses** have a positive claimed field: **290 schedules fully claimed**, **394 partially claimed**, and **6,811 never claimed**. These are schedule and address counts, not counts of identified people.

The verified vesting implementation increments `claimed` and transfers the same claim amount to the schedule owner in an atomic transaction; a failed transfer reverts the increment. The full state comparison provides complete aggregate accounting for the original funded records. Individual receipts remain necessary for an independently enumerated dated payment history.

## The specific large beneficiary becomes uncovered in January

The previously selected beneficiary `0xe356fe28b7b6b015a3b2bb4419dbdf2777d7420b`, nonce 0, has an original and still-unclaimed allocation of **587,755.519557566 GMI**.

A documented coverage crossing occurred on **24 January 2023 at 15:45:16 UTC**, block **25,067,647**:

- Vault balance before: **591,902.853950097638463553 GMI**.
- Normal claim paid: **8,309.56763892731 GMI**.
- Vault balance after: **583,593.286311170328463553 GMI**.
- Recipient and outer caller: `0xae1ff4f54d1c97f432ce20c87a1d5d7ede320c9b`.
- Transaction: [0x7f556eb1d5da208355961506485c529d11ee850d5ebf136188a9a5e20dc202e5](https://bscscan.com/tx/0x7f556eb1d5da208355961506485c529d11ee850d5ebf136188a9a5e20dc202e5).
- Input calls `claim(address,uint256)` (`0xaad3ec96`); the successful receipt contains the GMI Transfer and vesting Claim event.
- The selected large beneficiary's own `getVest` is byte-identical at the two adjacent blocks, with **claimed = 0**. Its full 587,755.519557566-GMI claim was not settled by this payment to the other beneficiary.

The valuation lane marks the 8,309.56763892731 GMI at **US$0.746603669 / C$0.998209105** at this transaction's time, using the previous completed block's pool ratio and available BNB/USD oracle quote. The GMI pool ratio was approximately 3 hours 45 minutes old; this is a marginal token mark, not cash proceeds. See *Historical file: launchpool_crossing_valued.json* for exact source ages and FX.

The full-book deficit already existed from November. January is a distinct documented point when the remaining tokens also fell below this particular large unclaimed allocation. Balance bisection and a bounded 10,000-block log window locate this crossing; without a complete transfer census, this lane does **not** claim it is the first-ever balance crossing.

## Scope remaining after this closure

- The net backing deficit for the **entire original funded book is closed exactly**. It is explained by the known 14m token removal plus recorded ordinary claims.
- A complete, dated, whole-life Transfer/Claim event census is **not** supplied. The current equality cannot rule out offsetting deposit/withdrawal cycles that leave the same net balance.
- This audit validates all beneficiaries in the original funded set. Because the contract permits public schedule creation without enumerating a global list, it does not establish whether unfunded schedules for entirely different addresses were created elsewhere in history. Any such records would be outside the original funded book.
- No human ownership of beneficiary, signer, executor or receiving addresses is inferred. Nothing in this accounting establishes a Cayman bank account or a personal receipt by Laura.
- The 14m quantity should not be presented as a 14m-dollar loss. Prior valuation research separately identifies the actual proceeds of the combined 44m-GMI sale.

## Evidence and reproducibility

Core machine-readable outputs:

- `aggregate_reconciliation.json`: current exact totals, zero residual, address/amount/nonce checks.
- `all_funded_records_current.json`: every decoded funded schedule, on-chain ID and current fields, with all nonce checks.
- `funded_schedule_audit.csv`: 7,495 rows suitable for investigator filtering or workbook inclusion.
- `funded_records_input.json`: schedules decoded directly from funding transaction inputs.
- `pre_withdrawal_book.json` and `post_withdrawal_book.json`: full before and after book comparison.
- `book_validation.json`: assertions for record identity, nondecreasing claims and exact deficit.
- `coverage_crossing_transfer.json`, `coverage_crossing_receipt.json`, `coverage_crossing_tx.json`: selected January event.
- `selected_threshold_result.json`: complete balance-bisection path and its explicit scope limitation.
- `material_transfer_ledger.json`: 39 opening funding transactions plus the January coverage crossing. The 39 opening transactions are already in the prior ledger and must not be duplicated when combining artifacts.

Each `funding_tx_*.json`, `record_*.json`, `nonce_*.json`, `balance_*.json` and selected vest-state JSON preserves the original JSON-RPC request, public endpoint, observation time and exact response. The principal archive endpoint is `https://docs-demo.bsc.quiknode.pro/`. `threshold.py`, `records.py`, `historical_book.py`, `post_book.py` and `finalize.py` reproduce the reads and accounting.

The failed explorer/API probes are preserved as failures, never interpreted as empty histories. The unrelated large `block_receipts_probe.json` was exploratory and is not required to reproduce the findings.
