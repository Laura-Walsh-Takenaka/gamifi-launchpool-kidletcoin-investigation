# Research Paper — GMI DEX audit — additional findings, 5 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

## Result

This pass verifies two additional PancakeSwap markets, quantifies the remaining reserves and custody of liquidity tokens, and completes a consecutive on-chain check around the advertised launch minute. **It establishes no wash-trading sequence or personally attributable insider sale.** It also does not establish that the launch never occurred: the narrow historical result concerns one minute and a small buffer only.

## Exact identity and market state

The official PancakeSwap V2 factory, `0xca143ce32fe78f1f7019d7d551a6402fc5350c73`, returned these exact pools for GMI `0x93d8d25e3c9a847a5da79f79ecac89461feca846` and the three queried quote-token contracts. This is a **three-quote enumeration**, not enumeration of every possible GMI pool or exchange.

| Pair | Pool address | GMI reserve | Quote reserve | Reserve update UTC |
| --- | --- | ---: | ---: | --- |
| GMI/WBNB | `0x58d4b61983ca0afe6e352e90719f403e24e016f4` | 264,515,119.841511288910891833 | 0.844195681546778659 WBNB | 2026-08-10 16:05:30 |
| GMI/BUSD | `0xccab7bb7f864fabdfa1e5dc8465543735c9e4534` | 2,441.906796850782869108 | 0.004679503566586585 BUSD | 2026-04-12 07:30:16 |
| USDT/GMI | `0x6d76baed9761e4ffe72f51751bf4078f87a25e01` | 11,155.591066945886877154 | 0.020764761073702194 USDT | 2026-06-19 18:57:19 |

Recorded state blocks, respectively: **120,181,991**, **120,182,018**, **120,182,043**, at 21:24:05, 21:24:17, and 21:24:28 UTC on 5 September 2026. These are three closely timed fixed blocks, not one identical block. Token ordering was independently read; all four token contracts and all three LP contracts returned **18 decimals**. No USD conversion or combined dollar liquidity estimate was made. BUSD and USDT labels identify the queried contracts, not a redemption guarantee.

The two stablecoin pools contain only tiny quote balances. This is evidence of thin present liquidity, **not evidence about who removed earlier liquidity or manipulated trading**. Each stored timestamp is the latest reserve update, which can arise from a swap or another reserve-changing operation.

Files: `pool_discovery.json`, `*_fresh_head.json`, `*_fresh_state.json`, `decoded_pool_state.json`, `decimals_verification.json`.

## Liquidity-token custody

At block **120,182,209**, the main GMI/WBNB pair had **7,081.195780349608516861 LP tokens** outstanding. The documented PancakeSwap farming contracts held:

- MasterChef V1 `0x73feaa1ee314f8c655e354234017be2193c9e24e`: **492.497205429887860174 LP**.
- MasterChef V2 `0xa5f8c5dbd5f286960b9d90548680ae5ebff07652`: **4,320.254505452520943119 LP**.
- Combined: **67.96524005504613424987855526%** of LP supply; the remaining supply is **2,268.444069467199713568 LP**.

This is contract custody, not proof that PancakeSwap or a single trader beneficially owns those positions. It is also not proof of a time lock. The current GMI/NFT admin address `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b` and earlier NFT-owner/deployer address `0x0d2c8df71c846d0dbc9c8bc75ea39c45d5197dca` each held **zero LP** in each of the three checked pool snapshots. Those zeroes cannot exclude past holdings, other addresses or deposited farm positions. Each pool returned **1,000 raw LP units** at the zero address and zero at `0x000000000000000000000000000000000000dead`; the 1,000 raw units are only 0.000000000000001 LP at 18 decimals, not 1,000 whole LP.

Files: `chef_balances.json`, `chef_custody_decoded.json`, three `*_fresh_state.json` records.

## Complete historical window at the advertised launch time

The recovered official Fair Launch Notice stated a PancakeSwap listing on **18 January 2022 at 14:30 GMT**. Source: [17 January archive capture](https://web.archive.org/web/20220117125329/https://gamifi-launchpad.medium.com/fair-launch-notice-a842e1bf320c). The local recovered article is *Historical file: a842e1bf320c_20220117125329.txt*. The canonical URL was checked against the recovered article inventory.

A binary search of historical block headers located the listing minute, after which all block receipts were retrieved for **24 consecutive blocks, 14,475,046 through 14,475,069 inclusive**, timestamped **14:29:52 through 14:31:01 UTC**. The requested interval includes the full 14:30 minute and small buffers.

- **14,751 receipts** recovered; **14,057 successful / 694 failed** across all chain activity in those blocks.
- Every block's set of transaction hashes exactly matched the recovered receipt set; receipt block hashes, block numbers and unique transaction indexes were also checked.
- **Zero logs** were emitted by GMI or any of the three verified pools in that interval.
- **Zero direct receipt destinations** were GMI or those pools.
- Accordingly, there are no GMI pool Swap, Mint, Burn or Sync events to decode in this window; the CSV legitimately contains its schema and no trade rows.

This is a precise negative result for logged GMI activity around the announced minute. It is **not** a finding that no launch occurred that day, that no activity occurred later, or that a brief delay was unlawful. Failed routed attempts cannot be classified as GMI-related from receipts alone without transaction inputs. No volume denominator or wash-trading percentage is calculated from this empty minute.

Files: `launch_window_bounds.json`, `launch_search_*.json`, `launch_receipts_*.json`, `launch_coverage.json`, `launch_summary.json`, `launch_independent_validation.json`, `launch_direct_calls_check.json`, `launch_swaps.csv`.

## Access and cross-check outcomes

- PublicNode, dRPC and Automata 1RPC each publish a public BSC endpoint. Each first request here returned HTTP 403; no alternate route, bypass, or repeat request to the blocked provider was attempted.
- The official BNB endpoint's documentation states `eth_getLogs` is disabled. Historical block/receipt methods remained available and were used instead of a broad log scan.
- An initial large state batch hit a method rate limit; smaller calls at the earlier block returned `missing trie node`. These failed responses are retained. Fresh per-pool fixed blocks then succeeded. Failure messages are infrastructure limitations, not token defects.
- Sourcify's public API returned **404 for the pool**, so no pool-creation transaction was established from that route. It returned a match for the GMI proxy, independently repeating the already known deployment: block **14,456,972**, transaction `0x9fe6991e983acb627cfaeb307bcb3a0d26bedfc1ad9a7de296722c9b82b4ff08`, deployer `0x0d2c8df71c846d0dbc9c8bc75ea39c45d5197dca`.
- No new personally identified wallet owner, Gotbit relationship, repeated buy/sell loop or historical liquidity-removal recipient was established by this bounded lane.

## Primary reference URLs

- [PancakeSwap V2 addresses](https://developer.pancakeswap.finance/contracts/v2/addresses) — official factory and router.
- [PancakeSwap MasterChef contract documentation](https://docs.pancakeswap.finance/to-delete/smart-contracts/main-staking-masterchef-contract) — V1 and V2 farm contract identities.
- [BNB RPC documentation](https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/json-rpc-endpoint/) — chain ID, official endpoint, disabled log method.
- [PublicNode BSC endpoint](https://bsc.publicnode.com/) — published keyless RPC route.
- [dRPC BSC log-method documentation](https://drpc.org/docs/bsc-api/eventlogs/eth_getLogs) — published RPC route.
- [Automata 1RPC networks](https://docs.1rpc.io/using-the-web3-api/networks) — published public BNB RPC route.
- [BNB extra API methods](https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/bsc-api-list/) — public read APIs.

All actions were read-only; no wallet connection, signature, transfer or on-chain mutation occurred. Raw request/response provenance and local decoding scripts are preserved with the lane data.
