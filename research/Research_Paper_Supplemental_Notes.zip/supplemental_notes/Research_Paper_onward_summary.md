# Research Paper — onward_summary

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

**Onward wallet: payments back to the beneficiary and further address intersections**

The selected recipient **0xf4f86e37815217ed73ae817a4e5164d56315b1d7** now has a receipt-verified inventory of **24 normal outgoing transactions**, nonces 50–73, from **7 October 2022 through 16 May 2023**. There are 23 successful transactions and one failed swap, represented only by its actual network fee. All 54 transfer and fee records carry exact base units, transaction identifiers and separate historical USD/CAD marks. This is a bounded sender inventory; inbound activity, third-party allowance transfers, earlier transactions and transactions after nonce 73 are not comprehensively inventoried.

The clearest new link is a **1 BNB** payment from this wallet back to private beneficiary **3604…b4d4** on **4 November 2022 at 14:25:04 UTC**, worth approximately **US$356.08 / C$481.31** at the historical mark. Its [successful transaction](https://bscscan.com/tx/0x1d511630993eefca8a67f6a63e189a6e25054f340e0d8867a00c6b5fb67cfbf3) preceded the beneficiary's **96,645,563.271604938271604938 GMI claim by 36 seconds**. Three further payments—3 BNB and 5 BNB on 6 November, then 3 BNB on 7 November—bring the selected reverse-direction total to **12 BNB**. This directly establishes a funding and counterparty relationship; purpose, business authority and human control remain unproved.

| New observed movement | Exact asset amount | Historical US$ mark | Historical C$ mark |
|---|---:|---:|---:|
| Back to the private beneficiary, four transfers, 4–7 Nov 2022 | 12 BNB | 4,173.22 | 5,638.53 |
| To earlier Launchpool token source 78d0…14c3, 7 Nov 2022 | 0.5 BNB | 166.41 | 224.54 |
| To earlier project-contract recipient 35b1…b5f3, 7 Nov 2022 | 0.5 BNB | 164.35 | 221.75 |
| To unassigned recipient ba4d…bf53, 7 Dec 2022 | 6,590 BUSD | 6,589.99 | 8,988.75 |
| To the same unassigned recipient, three transfers, 21 Oct–7 Dec 2022 | 25,906.285983337104699148 USDT | 25,906.29 | 35,478.50 |
| 11 BNB conversion: output returned to the sending wallet, 16 May 2023 | 3,398.645844082231 USDT | 3,399.33 | 4,574.14 |

The two 0.5 BNB payments intersect with earlier established transactions: **0x78d09e1435e1906878621bcb0aaa9d47561214c3** supplied 15,456,876 GMI to the original deployer on 19 April 2022; **0x35b119730f79881dac623dc51c831c6a04cab5f3** received project-contract withdrawal ID 4's 2,000 BUSD on 23 March 2022. The corresponding new transaction hashes and individual marks are in the ledger and record-request briefs. The intersections establish address relationships, not a shared human owner.

The other direct recipient is **0xba4d665059c97d6baa42e097707a504aecafbf53**. No reliable public business/service assignment was established for it in the searches performed. Its subsequent history is an open public-chain lead; this pass does not trace it onward. The May conversion returned USDT to the sending wallet and supplies no bank-payment evidence. Its swap contract remains unattributed in this report because a primary BSC deployment attribution was not established.

These values must **not be added to the earlier GMI-sale proceeds**. The onward wallet had commingled activity. It sold **4,816,523.694499999999787008 GMI** across three earlier swaps, including an October sale equal in quantity to a selected September receipt of 161,278.104499999999787008 GMI. It also made stablecoin/BNB conversions and a 0.02 BTCB conversion, and transferred a larger existing USDT balance. These events precede or overlap the selected private-claim period and are not all attributable to its 120m allocation.

Likewise, the earlier **27.336801380291603498 BNB** sent from the private beneficiary to this wallet remains a **gross directional total**. The newly documented 12 BNB sent back makes it unsuitable as a net-receipt or personal-income figure. Neither matching selected amounts nor close timing removes commingling. The address prefix “f4f” is simply an address abbreviation and does not establish FixedFloat control.

USD amounts use the prior completed block's supported oracle/reference mark, with observation ages preserved. USDT is valued using its historical USDT/USD feed, rather than assumed to equal exactly US$1. BTCB's separate ledger mark is explicitly a BTC-underlying reference valuation, not a verified BTCB market execution. CAD uses Bank of Canada's daily rate for the date or the preceding available business day. Values are estimates of cryptoasset amounts, not proof of fiat receipts.
