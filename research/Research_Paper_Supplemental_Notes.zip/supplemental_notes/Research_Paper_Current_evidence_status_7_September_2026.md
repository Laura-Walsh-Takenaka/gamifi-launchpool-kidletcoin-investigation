# Research Paper — Current evidence status — 7 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

**The original register still contains exactly 54 compound requests: 23 open, 31 narrowed, none fully closed.** Nine items gained substantive evidence; EV-018 and EV-025 change from open to narrowed. Forty-five items were not revisited in this focused follow-up. Their earlier findings remain preserved and are not presented as fresh verification.

The dated JSON preserves every original 6 September field and adds `current_status`, `current_finding` and `current_remaining`. Read those current fields for this update. Source paths and SHA-256 digests are included. The separate new issue **N2025-XPND** is excluded from the original 54-item count.

## What this pass actually resolved

- **Original FOMO principal:** all 27 funding addresses received exactly their contributed BUSD, totaling **3,775.228767123287671432 BUSD**, on 23 May 2022. That amount is no longer an unexplained missing principal payment. Other FOMO campaigns, token migration, staking and NFT rights remain separate.
- **GAMI allocation and backing:** all 127 original funding addresses match the vesting setup exactly. The entire remaining **290,789.005821999944860026 GAMI** across all 157 allocation records is backed at the 7 September pin. Of the 127 funders, 53 fully claimed, 62 partly claimed and 12 have no recorded claim. The **30 additional allocation addresses**, holding 271,343.58719030880680741 GAMI of original allocations, still need an entitlement and consideration explanation. GAMI is distinct from GamiFi GMI; these claims are contract counters, not a complete individual claim-receipt census.
- **Time Raiders initial delivery:** all 80 original funding addresses received initial XPND. Initial payments plus 437 successful later claims, with three failed claim calls excluded, reconcile exactly to all 149 pre-upgrade allocation records. This establishes actual delivery but leaves the separate 2025 event below.
- **Pooled 35b1 history:** all 184 signed outgoing transactions, nonces 0–183, are receipt-verified at the pinned nonce 184. The selected BUSD ledger matches eight historical balance observations. This does not close every upstream/onward wallet or every possible internal/allowance transfer.
- **Project 4 linkage:** an observed 2,000-BUSD route runs from 35b1 through private beneficiary 3604 and contributor 391a into project 4, then back to 35b1 after a receiver change. The route is established; human ownership, purpose and entitlement are not. It is not proof of an internal test or external-customer theft.
- **Private 120m GMI:** all claims were already reconciled before this pass. That completed arithmetic is retained; identity, consideration and entitlement remain open.

## The seven withdrawals are not one established loss

All seven used the contract's designed withdrawal function under the sampled owner/admin roles. That proves how the payments worked, not who was commercially entitled to retain them.

| Original project | BUSD withdrawal | Current result |
|---|---:|---|
| ID1, unnamed | 252.5 | Actual funding/withdrawal records; recipient identity and commercial purpose unresolved. |
| ID3, unnamed | 110 | Actual funding/withdrawal records; recipient identity and commercial purpose unresolved. |
| ID4, unnamed | 2,000 | Observed circular address route; commercial purpose unresolved. |
| ID6, GAMI | 28,421.141280969119319259 | BUSD forwarded to pooled 35b1; original funder allocations match and remaining GAMI backing is complete. Ultimate cash accounting remains open. |
| ID7, Time Raiders | 23,722.715761539594859905 | Exact BUSD amount remains at original recipient d2b8 at its pin; all 80 funders received initial Polygon tokens. Separate 2025 event below. |
| ID8, original FOMO | 3,775.228767123287671432 | Exact full contribution refunds to all 27 funding addresses. |
| ID9, ShibaFriend | 4,720.231567727363184247 | BUSD forwarded to 35b1; 26 funders identified. Refund/replacement delivery remains unresolved. |
| **Total** | **63,001.817377359365034843** | **A withdrawal subtotal, not a proved stolen or cashed-out amount.** |

The selected later SHF token transfers reach two addresses outside the original 26-address funding set. An intermediary distribution route remains possible. The pooled wallet's August 2022 sweep reaches administrative address 14cc; its purpose and custody remain unproved. Stablecoin turnover, self-transfers and a 200-BNB conversion must not be added as fresh fundraising or assigned to a particular customer's money by FIFO. Bank receipts matter where fiat settlement is claimed; on-chain refunds and delivery have their own evidence.

## Separate new issue: N2025-XPND

On **13 November 2025**, the Polygon Time Raiders vesting proxy was upgraded, then its entire **1,512,577.663750419638336396 XPND** balance was removed and sold. That balance exactly matched mature recorded unclaimed amounts for **107 of 149 allocation addresses**. The original GamiFi funder subset contains **38 of 80 addresses**, with **443,781.846196483910388258 XPND** outstanding; 42 had fully claimed. The sale paid **325.142524926446493136 POL gross** to the withdrawal recipient. This is neither a US-dollar loss valuation nor the original BSC cash proceeds.

The ordinary vesting owner had changed to f27f in September 2022, while the separate upgrade owner remained 3e0f. The 2025 delegation authorization recovers cryptographically to 3e0f, with 4d96 as the outer transaction sender and eventual recipient. It does not identify a human signer or establish informed consent, business mandate, compromise, theft or Laura's involvement. Accessible issuer publications supplied no event-specific explanation or replacement/compensation terms, but channel coverage is incomplete. Those records and onward POL proceeds remain material targets.

## Original 54-item coverage

| Area | Items | Open | Narrowed | Closed | Updated this pass |
|---|---:|---:|---:|---:|---:|
| Human control and final recipients | 7 | 4 | 3 | 0 | 4 |
| Corporate ownership and Cayman/Panama | 10 | 7 | 3 | 0 | 0 |
| GamiFi fundraising, representations and customer outcomes | 11 | 2 | 9 | 0 | 4 |
| Remaining blockchain reconstruction | 4 | 2 | 2 | 0 | 1 |
| KidletCoin data handling, software and delivery | 5 | 2 | 3 | 0 | 0 |
| NEM payment purpose, governance and custody | 8 | 4 | 4 | 0 | 0 |
| Secondary related projects | 9 | 2 | 7 | 0 | 0 |
| **Total** | **54** | **23** | **31** | **0** | **9** |

Updated: **EV-001, EV-002, EV-005, EV-007, EV-018, EV-019, EV-020, EV-025, EV-030**. EV-018 advances because actual pooled treasury movements are now evidenced, although the US$3.055m financing plan is not reconciled. EV-025 advances because purchaser-address payment and recovery records now exist, although authenticated personal reliance and net loss remain unproved.

Unchanged and not revisited: **EV-003–004, EV-006, EV-008–017, EV-021–024, EV-026–029, EV-031–054**. This explicitly includes the corporate/offshore documents, MEXC/FixedFloat private mappings, Launchpool lifetime history, other GMI pools, trading/manipulation evidence, and the Kidlet/NEM/secondary-project requests. Formatting other reports does not count as new substantive evidence for those items.

The new records improve the case by distinguishing proven repayment and delivery from unresolved custody and the separate, documented 2025 removal. They do not establish that Laura stole funds or explain her departure.
