# Research Paper — Material finding: original FOMO campaign contributions returned in full

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

The original contract project-ID8's **34 successful funding events from 27 funding addresses total 3,775.228767123287671432 BUSD**. The configured funding window was blocks **17853530–18041680**, as read at block 18051155 immediately before withdrawal. All 19 consecutive log-query chunks covering that inclusive window were recovered with no remaining gap. The sum equals the original recorded funded-total counter and the May 23 withdrawal.

On May 23 the receiving wallet returned that exact amount to administrator `3e0f` at 11:56:31 UTC. The administrator subsequently approved batch contract `0x4867171d50f734c34b020c45df23133cab5793a6`, then initiated two successful batch payments:

| UTC May 23,2022 | Payouts | BUSD distributed | Transaction |
|---|---:|---:|---|
|15:23:53|2|23|`0x41beaff61e66c1f292a53d0aaf60214b757c1130804535dd3f79e4c8c07e9f09`|
|15:37:05|25|3752.228767123287671432|`0xe49f8251937633b2e184fc4c4219c89cdbc110446cb822caab013e30be2b3837`|

**Every one of the 27 payout addresses matches an original funding address, and every returned amount equals that address's aggregated original contribution exactly, including all 18 decimals.** No contributor address or amount is unmatched. This is direct evidence of full BUSD contribution returns for this original campaign, completed within 3h 46m 49s of the project withdrawal. Accordingly, this 3,775.228767123287671432 BUSD should not remain classified as an unexplained missing principal payment in the approximately 63,002 BUSD withdrawal subtotal.

The source implementation was separately recompiled by the contract-review lane to an exact 15,877-byte runtime match. Its Funding event topic is `0x261eef0a9bca6d5e251dabbfb67268ac5711273f959abc61f49497e9350926ca`; the account is indexed topic 1, project ID topic 2, BUSD amount topic 3. Project 8 is the original campaign later named FOMO by the archived app, distinct from version 2 ID 1's later FOMO relaunch. The return conclusion does not resolve separate GMI staking principal, NFT access costs, token distributions, reliance damages, or the later campaign.

See `fomo_funding_payout_reconciliation.csv` and its JSON counterpart for all 27 address-by-address comparisons and funding/payout transaction hashes. Original full-window logs, both batch receipts, exact transaction input and raw RPC envelopes are preserved in this directory. All 34 original funding-event receipts were independently retrieved from the Binance public endpoint and passed exact event, block-hash, successful-status and BUSD transfer checks. The census used Quicknode; these receipts confirm the same events and actual cash-token transfers through a second provider. All-pass status is recorded in `fomo_funding_receipt_verification.json`.
