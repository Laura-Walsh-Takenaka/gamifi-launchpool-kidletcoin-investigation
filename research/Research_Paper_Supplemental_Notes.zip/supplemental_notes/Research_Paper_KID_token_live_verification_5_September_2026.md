# Research Paper — KID token live verification — 5 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The public explorer index was freshly retrieved, including an explicit terminal page. It returned 28 unique `kidlet:kid` transfer hashes, forming 25 directed address pairs among 19 addresses. Gross repeated movement is exactly **60,901,115.523681 KID**. This counts units again when forwarded; it is neither revenue nor newly issued supply.

All 28 index records were reconciled with the explorer's full transaction payload and then with historical blocks fetched directly from **nem02.symbol-node.com:7891**. All 28 asserted outer transaction signatures occur exactly once in their asserted blocks (24 distinct blocks). All 28 inner quantities, recipient addresses, signer public keys and timestamps agree. Public-node account records also independently match all 28 sender addresses to their signing public keys. This is corroboration of ledger records, not an independent cryptographic signature or whole-chain audit.

The oldest confirmed transfer is **9 December 2018 at 07:04:02 UTC**, and the newest in the retrieved index is **16 July 2019 at 04:56:54 UTC**. No subsequently indexed KID transfer was returned. All date displays should prefer `confirmed_utc`; `created_utc` is the transaction's creation time. None of these 28 changed calendar date between creation and block inclusion.

Of the 28 transactions, 20 are multisignature wrappers and 8 ordinary transfers. Explicit transaction fees across the outer transfers, inner transfers and cosignatures total **25.50 XEM**. This is a separate network-fee calculation; it excludes mosaic levies, account initialization/control/namespace fees and all other wallet payments. It should not be mixed into KID quantities or represented as money paid to token recipients.

## Source interface

- [Explorer asset view](https://explorer.nemtool.com/#/mosaic?ns=kidlet&m=kid)
- `POST https://explorer.nemtool.com/mosaic/mosaicTransferList` with `{"ns":"kidlet","m":"kid"}`; follow with `no` equal to the oldest row's `no`. Terminal query returned `[]`.
- `POST https://explorer.nemtool.com/tx/tx` with `{"height":null,"hash":"<HASH>"}`.
- `POST https://nem02.symbol-node.com:7891/block/at/public` with `{"height":<HEIGHT>}` returns historical full block.
- `GET https://nem02.symbol-node.com:7891/account/get?address=<ADDRESS>` supplies account public-key/address relationships; existing nem01 records in the parent's live recheck were reused where available. These hosts share an operator; they are not independent economic witnesses.

## Deliverable data

- *Historical file: kid_transfers_node_verified.json*: canonical normalized 28-row transaction file, with `sender`, `recipient`, `quantity_kid`, atomic quantities, hashes, creation and confirmation times, block height, exact node validation results, sender/initiator/cosigner public keys and network fees.
- *Historical file: kid_edges_aggregated.json*: 25 directed pair summaries with exact amount strings and source hashes.
- *Historical file: kid_index_page1.json* and *Historical file: kid_index_terminal.json*: untouched API response bodies.
- *Historical file: tx_<hash>.json*: full explorer transaction responses.
- *Historical file: nem02_block_<height>.json*: untouched historical block bodies.
- *Historical file: kid_address_publickeys.json*: primary account lookup records and source locations.
- *Historical file: kid_source_manifest.json*: retrieval date and SHA-256 hashes of saved JSON records.

## Interpretation limits for the visualization

The initial two 21,000,000-KID transfers are issuer → staging → distributor. They move the same supply and are not two separate funding contributions. A graphical supply node, if used, should be labelled as issuance/accounting context rather than an incoming payer.

The retrieved index stops after 28 rows, but that proves the end of this index's available result set, not exhaustive recovery of all possible historical transfers. Historical index consistency also cannot establish current spendable balances: the namespace is currently absent from the queried public node, and the explorer's rich list is inconsistent with a simple transfer-only ledger replay. Use transfer histories and clearly labelled reconstructed historical positions; do not label them current KID holdings.

Wallet addresses remain pseudonymous unless separately supported by evidence. An address receiving 20 KID is not, by that fact alone, a child, a contest winner, a customer or a paid contractor. Transfer amounts are not proof of purpose or wrongdoing. All natural-person ownership/control attribution belongs in a separate, evidence-backed layer.
