# Research Paper — Independent reciprocal KID/XEM review

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The three proposed reciprocal groups pass independent raw-history checks for amount, asset, sender, recipient, height and authorizers. Each comprises three distinct signed transactions: KID into NCIT7A…, XEM back to the KID sender, and a separate XEM payment from NCIT7A… to NAYIOJ…. All three legs of every group were actually cosigned by NBGTCB….

| Date | KID into NCIT7A | XEM back | Separate XEM to NAYIOJ | Ratio XEM per KID | Maximum block gap |
|---|---:|---:|---:|---:|---:|
| 2019-06-11 | 1 | 2.421466 | 0.484293 | 2.421466000 | 1 |
| 2019-06-12 | 1.073681 | 2.5 | 0.5 | 2.328438335 | 0 |
| 2019-07-12 | 0.2 | 0.533328 | 0.106666 | 2.666640000 | 0 |

All three third-address amounts equal **20% of the paired reciprocal XEM, rounded to six decimal places**. Exact residuals from unrounded 20% are −0.0000002, 0 and +0.0000004 XEM. This is a precise numerical relationship. Calling the third-address transfers a contractual service fee or commission would be an interpretation; the transactions contain no such public description.

The arithmetic ratios differ across transactions and are not verified public market quotes. The July 11 reverse-direction pair is 1 XEM into NCIT7A… and 0.25 KID back, nine blocks later: an arithmetic ratio of 4 XEM/KID. Its transaction creation gap is 614 seconds; block confirmation times, where available, are separately included in JSON.

## Explicit transfers, protocol levy and return

All six NCIT7A… → NAYIOJ… payments are native-XEM transfers (inner type 257, no mosaics) inside signed multisig wrappers. They have their own transaction hashes, recipients and network fees. They are separate from KID's automatic **0.00001-XEM levy to NCEUKZ…**.

**The complete seven-record NAYIOJ… history reconciles exactly:**

| Item | XEM |
|---|---:|
| First five receipts from NCIT7A… | 2.031170 |
| Returned to NCIT7A… on July 12 | −1.981170 |
| Network fee paid by NAYIOJ… for that return | −0.050000 |
| Balance immediately after return | **0** |
| Sixth, later receipt | +0.106666 |
| Reconstructed and queried current balance | **0.106666** |

Total receipts were 2.137836 XEM. The ledger shows the first five receipts were fully exhausted by the return and its fee. Therefore 2.137836 XEM is gross receipts, not retained revenue. The return purpose is not described. The raw return transaction is [c2615d867f…](https://explorer.nemtool.com/#/s_tx?hash=c2615d867ffdaaa2ef9d2bb35329c635d6fd35ea5ba2a24b90a268851fdd5fc9), block 2,235,831.

## Exceptions and interpretation

- A June 12 incoming 1-KID transfer is accompanied by 0.0408 XEM to NAYIOJ… but no separately matched XEM payment back to its KID sender. The later June 12 1.073681-KID transaction is the precise 2.5-XEM reciprocal group; these two KID events must not be conflated.
- June 14 and July 12 include outgoing KID from NCIT7A… with payments to NAYIOJ… (0.470419 and 0.535658 XEM respectively), but do not provide the same three-leg reverse-XEM pattern. A uniform pricing or fee formula cannot be imposed across all activity.
- The three participating multisig wallets share two assigned keys, NCYKQW… and NBGTCB…, sufficient together for their 2-of-3 thresholds. The latter actually cosigns both sides and the third-address payment in every examined three-leg group. This demonstrates coordinated authorization and does not identify independent customers or human keyholders.
- The evidence supports **coordinated reciprocal KID/XEM activity and a repeated 20% numerical relationship**. It strengthens an exchange-mechanism interpretation compared with token transfers alone. It does not establish a merchant purchase, an externally quoted KID price, a legally classified exchange, or a contractual fee rate.

All full raw-source records, exact hashes, separate creation/confirmation times, block-file references where verified, mathematical residuals and exceptions are retained in `reciprocal_pair_qa.json`.
