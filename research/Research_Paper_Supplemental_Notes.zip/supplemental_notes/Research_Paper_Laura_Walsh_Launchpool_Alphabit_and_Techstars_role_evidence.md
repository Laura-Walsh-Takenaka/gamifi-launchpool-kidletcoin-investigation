# Research Paper — Laura Walsh: Launchpool, Alphabit and Techstars role evidence

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Bounded public-source check, 5 September 2026 UTC. Intermediate research notes for the consolidated attribution review. Sources were read through public web retrieval; no private records, account access or wallet-owner identification was attempted.

## Supported role and action chronology

| Date | Source and supported finding | Attribution strength |
|---|---|---|
| 2 July 2021 event; 3 July publication | Launchpool Labs' company AMA summary lists Laura as Launchpool COO. Its answers attributed to Laura cover LPOOL holdings and staking eligibility, threshold decisions, bridge-fee exceptions, allocation preferences and the planned Techstars initiative. | Contemporary company attribution; named operational and promotional statements. [L1] |
| 27 September 2021 | The Irish Times interviews Laura Walsh as Launchpool COO about the decision to locate the planned accelerator in Dublin. | Named interview in a contemporaneous publisher record; supports her participation in the public launch narrative. [L2] |
| 7 October 2021 episode; 11 October publisher summary | Pete Townsend's interview identifies her as COO. Laura explains that Launchpool and Alphabit obtain project allocations for retail investors on fund-equivalent pricing terms, and discusses the rationale for their Techstars collaboration. | Her publicly attributed statements connect her to allocation marketing and the partnership's commercial rationale. They do not establish that she personally executed every allocation agreement. [L3] |
| 9 July 2022 | Nativz's issuer newsletter dates her Launchpool COO start to May 2021 and identifies her as Corporate Liaison for the Launchpool Web3 Techstars programme. | Contemporary business-counterparty description. May commencement is retrospective; a May 2021 employer appointment notice was not recovered. [L4] |
| 4 July 2023 recording; 4 August publication | In MoneyNeverSleeps episode 227, Techstars Web3 managing director Pete Townsend identifies Laura as the programme's entrepreneur in residence and describes her accompanying the cohort during the Canada/New York investor-event trip. | First-person colleague account in the publisher's transcript, especially 05:33, 08:54 and 10:55. The audio was not independently retranscribed. [L5] |
| 19 February 2024 | Techstars' official 2023 All-Star Mentors announcement lists Laura Walsh specifically under Techstars Web3 Accelerator. | Direct institutional recognition of 2023 mentoring. Publication year and award year differ. [L6] |
| 23 July 2025 | Pete Townsend's retrospective credits Laura with helping start the programme and supporting it as EIR and All-Star Mentor. He also says the standalone Web3 accelerator is being integrated into Techstars' wider programmes. | Direct programme-leader account; confirms substantial historical involvement without establishing a current salaried executive position. [L7] |

## The 2021 AMA is more informative than a job title

Laura's published answers defend the 200-LPOOL entry threshold, say the team accommodated bridge-fee reductions, explain that eligible holdings could be on Ethereum or BSC, and describe preferential allocation for longer-term and larger holders. She encourages continued holding and represents that cohort projects receive extensive research and vetting. These are concrete representations about participation policy and diligence, suitable for comparison with the corresponding programme records. The same answer cautions investors about loss and the heightened risk of incubation. Those disclosures belong with the promotion. [L1]

The AMA distinguishes Launchpool, Labs and Techstars. Their distinct models should not be conflated. Statements attributed to Rich or Roxana must not be reattributed to Laura, including Rich's concern that a proposed profit-sharing wallet might constitute a security. [L1]

## Limits and excluded leads

- This evidence establishes a Launchpool executive role, attributed statements concerning programme mechanics, and an active accelerator support role. It does not identify a Laura-controlled trading address, prove custody of programme tokens or establish an individual signing mandate.
- The Alphabit relationship is established through the allocation and accelerator accounts. No distinct formal Alphabit officer appointment or investment-committee delegation was recovered in this bounded search.
- The exact May 2021 commencement and 2022 Corporate Liaison title currently rely on Nativz's contemporary biography rather than a recovered employment instrument.
- A CBInsights page reproduces an apparent 11 April 2023 Techstars class announcement naming Laura EIR. The likely Techstars article URL returned 404. The reproduction was used as a search lead only; the primary programme-leader transcript independently supports the 2023 EIR role.
- The 2024 cohort announcement contains a closing reference to the 2023 class, apparently editorial carryover. It does not mention Laura, and was excluded from personal-attribution evidence.
- No inference of misconduct follows from the accelerator role, mentor recognition, institutional association or the disclosed use of allocation incentives alone.

## Source register

| ID | URL | Retrieval reference / provenance |
|---|---|---|
| L1 | https://launchpoollabs.medium.com/launchpool-labs-community-ama-summary-546fc8b122a | Company publication, full text recovered; `historical retrieval`, expanded `historical retrieval`; 3 July 2021 date and 2 July event. |
| L2 | https://www.irishtimes.com/business/technology/techstars-to-hold-blockchain-focused-accelerator-in-dublin-1.4684207 | Full indexed interview; `historical retrieval`; 27 September 2021. |
| L3 | https://irishtechnews.ie/moneyneversleeps-laura-walsh-launchpool-techstars/ | Named interviewer/producer Pete Townsend; full indexed publisher text `historical retrieval`; 11 October 2021. Episode date 7 October from https://www.moneyneversleeps.ie/guests/laura-walsh/ (`historical retrieval`). |
| L4 | https://www.nativzgaming.com/p/newsletter-09-07-22 | Full issuer newsletter; `historical retrieval`, lines 17 and 30–31; 9 July 2022. |
| L5 | https://www.moneyneversleeps.ie/227-encore-eoin-fitzgeralds-last-dance-techstars-web3-recap/ | Full publisher transcript; `historical retrieval`; publication 4 August 2023, recording date explicitly 4 July. |
| L6 | https://www.techstars.com/blog/impact/2023-techstars-all-star-mentors-named | Full institutional announcement; `historical retrieval`, lines 9, 227–235; published 19 February 2024. |
| L7 | https://www.linkedin.com/pulse/techstars-web3s-evolution-my-next-phase-pete-townsend-e6zpe | Full programme-leader article; `historical retrieval`, date `historical retrieval`, named credit `historical retrieval`; 23 July 2025. |

Searches used both available web search systems and exact-name/project combinations. No full copyrighted transcripts or article copies are included in these notes. Source-specific summaries are intentionally short.
