# Research Paper — KidletCoin consent: historical legal tests and records for law-enforcement authorities

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Research note | 7 September 2026 | Public evidence; no complaint filed or private account accessed

## What this adds

**The consent issue is concrete enough to investigate, but the public record does not establish that Laura committed a child-related crime.** The current master records a contest video with upload metadata dated 2 June 2019, aimed at ages 8–18 and requesting a video link, name, age, email, location and a receiving wallet. Its recovered instructions do not show a parent-first consent step or contest privacy notice. The master authenticates the editable description by a 10 December 2022 capture, not every word as of June 2019. Actual receipt, private consent arrangements, publication and the adult who controlled each process remain unresolved. A generic NEM wallet was an alternative; entering did not demonstrably require the Kidlet app.

Two newly recovered **official YouTube contest-policy captures, 26 April and 17 July 2019**, bracket the contest. Their substantive requirements match: organizers needed official rules, a privacy notice explaining collection/use, and administration and awards consistent with those rules. The notice requirement therefore has a contemporary platform basis. The copies do not establish that no separate notice existed or who approved the Kidlet contest. Platform noncompliance is not itself a finding of crime. [KL17–KL18]

## Historical law: questions to apply to proved conduct

| Framework | Supported legal position | Facts needed for this case |
|---|---|---|
| Canada: PIPEDA, April 2019 consolidation | Covered commercial processing required meaningful consent, appropriate purposes, limited collection, protection and appropriate use/retention. Section 6.1 assesses understanding of nature, purpose and consequences. Its specific offence provision, section 28, did not make every consent failure a criminal offence. [KL01] | Identify operator, commercial activity and a sufficient Canadian connection; then actual data, process, recipients, safeguards and responsible decisions. Nationality or later Canadian residence alone does not establish this. |
| Historical Canadian child-consent guidance | OPC's archived December 2015 guidance already expected parent/guardian consent for under-13s except exceptional cases; older youths' understanding mattered. It also addressed excessive detail, public disclosure defaults and indefinite retention. This is regulator interpretation of meaningful consent, not a universal statutory age prohibition. [KL02] | Which eligible ages actually participated, what parents saw and agreed to, and whether participation, publication and other uses were intelligible and authorized. |
| Quebec: exact 2 June 2019 private-sector law | Sections 4–5, 8, 10 and 12–14 covered legitimate file purpose, necessity, notice, security and consent/use/disclosure. Section 91 provided a penal route. Section 93 attached corporate officers/directors/representatives to an offence where they prescribed, authorized or consented to the offending act or omission. [KL03] | Establish an enterprise and Quebec territorial connection, the particular breach and the individual's actual involvement. A title or family connection is insufficient. Do not apply later Law 25 child thresholds or penalties retroactively. [KL09] |
| Thailand: June 2019 PDPA timing | Section 2 delayed the substantive protection chapters; the 2021 decree extended specified exemptions through 31 May 2022. June 2019 cannot be assessed as though the later-operative consent regime already applied. [KL04–KL05] | Separate initial 2019 conduct from proven handling after 1 June 2022; identify the actual controller and processing dates. |
| Thailand: later handling | Section 95 permits continued collection/use of pre-existing information for original purposes, with an accessible withdrawal route; disclosures and other acts follow the Act. Section 20 has capacity-based minor rules and a specific rule for under-10s when consent is the basis. Consent is not the Act's only lawful basis. [KL04] | Evidence of surviving information, later use/disclosure, original purpose, lawful basis, notices/withdrawal route and who controlled it at the later date. An archived webpage alone proves none of these. |
| Thailand: Child Protection Act 2003 | Section/article 26 prohibits specified harmful or risky treatment and certain harmful commercial involvement; section/article 27 addresses publication concerning a child with intent to damage interests or obtain unlawful benefit. Ordinary educational publicity or a contest invitation does not establish those elements. [KL15] | Identify an affected child under the Act, specific conduct, required risk/harm or intention, actor and territory. Have Thai investigators assess limitation periods and applicable historical text before asserting prosecutability. |

English Thai-law copies are translations; the Thai originals govern. The June 2019 Quebec page identifies itself as an official historical consolidation, though an administrative minister-designation note refers to a later decree. The operative sections above were read in the historical body.

PIPEDA's foreign-operator case analysis asks whether relevant connections are real and substantial; the 2015 OPC decision is an example, not proof that Kidlet had the same facts. Relevant questions include where an operator acted, where affected users were and how activities were directed or monetized. [KL10]

**A U.S. COPPA route remains conditional.** The 2013 rule expressly includes soliciting online submissions within its collection definition, covers covered services for under-13s, and addresses notices, parental consent, security, retention and unnecessary prize-entry data. Its explanation expects safeguards before information arrives; it does not make every invitation a completed violation. Determine U.S. commerce/children and actual operation before asserting jurisdiction. No U.S. child entrant has been established here. Use the 2013 rule, not later revisions. [KL21–KL22]

## Records that would resolve the consent question

These are proposed investigative record categories, not assertions that a provider still retains them or that a complainant can compel them.

| Priority record | What it resolves |
|---|---|
| Dated official rules, privacy notice and linked policy bodies; email auto-replies and entry instructions | What a child or parent was actually told at each step; whether another consent process existed. |
| Aggregate receipt/selection/award register, followed by securely held source records for relevant entries | Whether there were entries, their age bands and countries, winners and promised payments. Use coded entrant references in the general report. |
| Parent/guardian consent and publication authorization, with time, version and verification method | Who agreed to which uses; whether consent preceded receipt/publication and covered reuse. A parent authorizing entry is not automatically authorizing every later use. |
| Historical mailbox provider/subscriber, administrators, delegates, forwarding and access changes | Who had custody and who could access or export entries, including the dates Laura held or relinquished any role. The `info@` address proves no particular security arrangement. |
| Channel owner/manager records, upload records, original descriptions and retained edit history | Who approved and published contest material or entries; whether private/unlisted/deleted uploads survive. |
| Retention schedule, deletion actions, backups, exports, processor contracts and handover | What happened after the contest and whether later controllers retained or reused children's information. Domain reacquisition does not prove mailbox transfer. |
| Commissioning, approvals, incident tickets, production build and release records | Who made the relevant operational decisions. A defect in public source is not proof of a defective production app or that Laura knew of it. |

## What to ask law-enforcement authorities to do with the package

**Suggested request:** “Please assess the archived child-directed contest and the missing consent and custody records, identify the responsible adults and applicable jurisdiction, and consider preserving the surviving provider and operator records. I am reporting documented solicitation and unresolved safeguards; I cannot presently identify an entrant or prove that Laura accessed or misused a child's information.”

For a Canadian investigation, Criminal Code section 487.012 provides an officer/public-officer preservation demand for existing computer data when statutory suspicion and investigative conditions are met. It is not a private complainant's power, cannot be directed at the person under investigation, and preserves rather than automatically discloses data. The officer decides the appropriate demand/order, recipient and international route. [KL11]

Google's current provider guidance confirms a verified-government request system and distinguishes preservation from disclosure. YouTube records potentially available under appropriate legal process include subscriber details, sign-in/upload IPs and timestamps, and retained private-video content. Preservation only reaches information held when requested; it does not recreate deleted seven-year-old records. Google is a relevant channel custodian, **not an established provider of the project's published submission mailbox**. [KL12]

For a Canadian report, RCMP's current national reporting guidance accepts witnesses as well as victims and permits supporting evidence; local law-enforcement authorities remain an appropriate contact. Do not present a consent concern as proved fraud merely to fit an online category. [KL16]

Privacy oversight may proceed separately from law-enforcement authorities: OPC offers a concern/information route and generally expects prior contact with the organization for a formal complaint; explain the historical or unidentified controller if that makes contact impractical. [KL07] Quebec's CAI accepts written complaints about suspected handling practices and can receive anonymous complaints, although individual redress can require identity disclosure. Its access/rectification-dispute deadlines are distinct from a general practice complaint. Its jurisdiction must still be established. [KL08] No operator, regulator or provider has been contacted in this research.

## Platform age boundary

The bracketing contest-policy captures contain **no blanket requirement that entrants be adults**. A separately retrieved 3 June 2019 Terms page includes legal-capacity/parental-consent language and an under-13 service restriction, but its rendered regional context is New Zealand. It is a lead for obtaining the exact applicable terms, not proof of Thai or Canadian user terms. A submission link alone also does not prove the child personally opened or used a YouTube account. Do not backdate later “made for kids” controls or assume the contest required every entrant to publish independently. [KL17–KL20]

## Primary source locators

Retrieval timestamps, exact URLs, sizes, hashes and failures are in the accompanying manifests. The local historical law bodies and archive responses were inspected. The capsules file carries bounded quotations/paraphrases for distribution; full third-party HTML is working material, not needed in the public packet.

- KL01: https://laws-lois.justice.gc.ca/eng/acts/p-8.6/20190401/P1TT3xt3.html
- KL02: https://www.priv.gc.ca/en/privacy-topics/privacy-for-businesses/protection-of-children-for-businesses/02_05_d_62_tips/
- KL03: https://www.legisquebec.gouv.qc.ca/fr/document/lc/p-39.1/20190602
- KL04: https://www.mdes.go.th/law/detail/3577-Personal-Data-Protection-Act-B-E--2562--2019
- KL05: https://www.etda.or.th/getattachment/33f1c767-6339-41da-8309-97569ed4ef4a/PDPA-2021.aspx
- KL07: https://www.priv.gc.ca/en/report-a-concern/
- KL08: https://www.cai.gouv.qc.ca/protection-renseignements-personnels/citoyens-protection-renseignements-personnels/recours-devant-commission
- KL09: https://www.cai.gouv.qc.ca/protection-renseignements-personnels/sujets-et-domaines-dinteret/principaux-changements-loi-25
- KL10: https://www.priv.gc.ca/en/opc-actions-and-decisions/investigations/investigations-into-businesses/2015/pipeda-2015-002/
- KL11: https://laws-lois.justice.gc.ca/eng/acts/C-46/section-487.012.html
- KL12: https://support.google.com/transparencyreport/answer/9713961?hl=en
- KL15: https://asean.org/wp-content/uploads/2016/08/Thailand151.pdf
- KL16: https://rcmp.ca/en/news/2025/11/rcmp-launches-new-national-cybercrime-and-fraud-reporting-system
- KL17: https://web.archive.org/web/20190426101812id_/https://support.google.com/youtube/answer/1620498?hl=en
- KL18: https://web.archive.org/web/20190717202723id_/https://support.google.com/youtube/answer/1620498?hl=en
- KL20: https://web.archive.org/web/20190603000330id_/https://www.youtube.com/t/terms
- KL21: https://www.govinfo.gov/content/pkg/FR-2013-01-17/pdf/2012-31341.pdf ; searchable official-agency rendition: https://www.federalregister.gov/documents/2013/01/17/2012-31341/childrens-online-privacy-protection-rule
- KL22: https://www.ftc.gov/business-guidance/blog/2018/04/where-world-warning-letters-address-geolocation-coppa-coverage

KL06 (Thai Ministry of Education copy) failed with HTTP 502 and is not treated as read. KL13, KL14 and KL19 are archive index/availability responses, not the substantive policies themselves. June 2019 rule continuity between the two matching captures is a well-supported inference; an intervening unrecorded edit cannot be excluded.
