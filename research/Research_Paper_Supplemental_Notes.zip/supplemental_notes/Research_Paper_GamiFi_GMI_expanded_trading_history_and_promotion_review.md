# Research Paper — GamiFi/GMI: expanded trading-history and promotion review

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Research cutoff: 2026-09-05 UTC. Scope is the exact BNB Smart Chain token `0x93d8d25e3c9a847a5da79f79ecac89461feca846` and its documented venues and promotional channels. This is a supplement to `volume_gamifi_notes.md` and `company_audits/GAMIFI_VALIDATED_REVIEW_2026-09-05.md`.

**New evidence establishes direct public promotion by Laura, a repeated high-yield advertising campaign, disclosed trading restrictions, and a later effort to retain staked tokens. It does not establish fabricated GMI trading volume. A complete trade history was not recovered.** No public wallet was attributed to Laura, no market-making contract was found, and no Gotbit relationship was established.

## 1. Trading launch and venue timeline

| Date or period | Public primary evidence | What it establishes |
|---|---|---|
| 2022-01-17 notice; planned trading 2022-01-18 14:30 GMT | GamiFi's Fair Launch Notice [S1] | Planned PancakeSwap listing, alongside the Launchpool IDO. Company disclosed anti-snipe/anti-bot measures that could blacklist wallets and freeze GMI, continuing for the foreseeable future. Telegram would be muted for 30 minutes during launch. |
| 2022-01-23 announcement; Jan 24 voting | MEXC Kickstarter terms [S2] | A 1m GMI reward pool for users temporarily staking MX to vote for listing; token reference price $0.05. MX was to be unlocked, rewards proportional to votes, KYC required. This was a disclosed incentive to vote, not a trading-volume competition. |
| 2022-01-24 result; Jan 25 13:00 UTC trading | MEXC result [S3] | Exchange reported 10,088,700.1609595 MX votes and distributed airdrops, then scheduled GMI/USDT trading. The votes were not GMI purchases, new company capital or DEX turnover. |
| 2022-02-23 | MEXC's Laura/Casey AMA recap [S4] | Laura promoted GMI's availability on PancakeSwap/MEXC and its staking and whitelist utility. |
| After the October 2022 update in the channel's displayed sequence; exact dates unresolved | Official Telegram posts 821–822 [S8,S9] | Casey discussed potential MEXC delisting, pointed users to PancakeSwap using the exact GMI/pair addresses, and then promoted a new staking pool. The sequence alone does not establish the effective delisting date or a resumption of IDOs. |
| 2026-04-17 and 2026-08-10 | Previously decoded BNB RPC receipts [S12] | Two small actual sales through the verified GMI/WBNB pool. Neither individual receipt contains a GMI purchase/return leg. No consecutive trader history was recovered. |

The disclosed blacklist/freeze mechanism is a concrete control requiring deployment and usage verification. An anti-bot announcement does not prove a honeypot, arbitrary confiscation or selective protection of insiders. The public launch notice itself contradicts an assertion that no trading restriction was disclosed.

## 2. Laura's own promotional statements

The February 23 MEXC transcript attributes GMI acquisition, whitelist tiers, staking returns and future NFT purchases to Laura. She calls GMI **“pure utility”** and states **“Yes our token contract has been audited by Peckshield.”** She also says market conditions could delay forthcoming offerings. This is direct personal promotion; the transcript does not identify her as a trader or trading director. [S4]

The utility label does not settle legal classification. The stated token audit remains unmatched to a report, date, version or deployed address. Its claimed scope is the token contract, not every staking product. Those are verification questions, not established falsehoods. [S4]

On July 1, the official podcast identifies Laura and Casey as discussing a forthcoming gamified burn initiative. The recovered show notes establish that named association with the initiative, but contain no verbatim transcript. We did not listen to or transcribe the audio in this pass and cannot assign individual burn mechanics to Laura's spoken words. [S5]

## 3. Repeated return promotions, and what was actually promised

The current official RSS feed contains 39 episodes. Local parsing finds 18 descriptions containing 225% APY, covering feed publication dates February 8–April 7 2022. Twenty-two descriptions mention MEXC; 26 mention PancakeSwap. These are publisher show-note counts, not verified audio endorsements by the guests or an immutable archive of what each page said on publication day. `gmi_history_promotions_raw/compute_promotions.py` regenerates counts and a per-episode register from the preserved XML. [S6]

The May 4 primary staking announcement already reviewed gives a 30-day NFT-holder pool at 225% APY, plus 60-day 150% and 90-day 175% pools. It also publishes caps and a general risk warning. A 225% annualized rate is not 225% earned in 30 days; the deployed reward formula, funding and paid investor returns remain unresolved. [S7]

**Successor-period retention campaign:** Telegram post 822, displayed under Casey's name, describes six-month staking at 40% APR, an individual 2.5m GMI cap and 500k GMI rewards at that cap. It offers full rewards on certain old pools despite time remaining, encourages withdrawal and restaking, and creates a 21-day deadline. [S9]

Own arithmetic: `2,500,000 × 0.40 × 0.5 = 500,000 GMI`, so that specific illustration reconciles. The post's favorable investment language and urgency merit examination alongside token-price and exit-liquidity disclosures. Paying a larger token quantity is not the same as a positive cash return. The exact post date, deployed new pool address, fulfilled early rewards and source of reward tokens were not recovered. No inference of a Ponzi scheme follows from the restaking offer alone.

## 4. Burn/mystery-box promotion

The official Medium tag listing identifies the Mystery Box article as July 2 2022. Search-indexed portions of that exact company article state a 25,000 GMI mint price, a matching company contribution and 50,000 GMI sent to a burn address per NFT. The full article was not recovered: the live browser was hard-blocked by Cloudflare and access stopped. These specific terms have primary indexed support but incomplete surrounding context. [S10]

Third-party Reddit posts repeat the mechanics, describe a July 13 launch, 1,000 boxes and exclusive 50%/75%/150% APY pools. Those additional terms remain secondary leads in this supplement. No burn address, matching treasury transfer, NFT mint ledger, fulfilled whitelist benefit or aggregate campaign burn was independently verified. [S11]

A transfer to a burn address must not be counted as a DEX swap. An unchanged ERC20 `totalSupply` value would also not by itself contradict a burn-address campaign: token destruction through a supply-reducing method and sending existing units to an inaccessible address are different mechanisms. Do not call the promotion false without tracing its exact implementation and promises.

## 5. FOMO correction and other promotional leads

The official Telegram channel has an explicit FOMO token-distribution announcement, post 813. This improves the earlier company review's outcome coverage: distribution is now **company-reported**, although individual settlements and totals remain unverified. It appears among the September 2022 launch updates and before the October 3 operational update; exact post-date metadata was not recovered. [S13]

The channel also contains gaming and meme competitions, referral-style game invitation codes and partner token promotions. A game leaderboard is not automatically a trading leaderboard; a public invitation code is not proof that Laura personally received referral compensation. Current later entries show planned rebuilding and new staking, so the 2022 pause should not be described as proven permanent closure. [S8,S9]

Coinband's own indexed 2023 marketing article says it built a 25,000-plus community for GamiFi and achieved an IDO sellout. This is an agency's retrospective claim, not independently verified subscriber quality, fundraising totals or a demonstrated trading-volume service. A generic agency service page listing shilling elsewhere does not prove that exact service was supplied to GamiFi. [S14]

## 6. Trading-history coverage and failed routes

The previously preserved on-chain evidence remains the historical baseline: four individually inspected receipts, two of which are token payments without Swap events and therefore excluded from trading volume. The fixed September 5 pool snapshot and exhaustive filtering of the two August 10 reserve-update candidate blocks verify the identified pool's state and last observed sale; they are not an all-pool or all-exchange ledger. [S12]

This pass attempted the documented public MEXC `exchangeInfo` lookup and daily candles for the exact historical symbol, with a bounded Jan 25–Aug 1 2022 request and maximum 1,000 rows. Both timed out; no candle data or symbol-status conclusion was returned. The requests/outcomes are preserved. MEXC's published bulk historical-data facility starts January 1 2023 and therefore would not cover Laura's 2022 CEO tenure even if fully available. [S15]

CoinLore reports its GMI price feed stopped August 10 2023; current and older cached versions disagree on the quoted 2022 high. No independently matched venue-by-venue dataset was obtained. Its stale/zero values and inconsistent cached statistics were excluded from volume conclusions. [S16]

No complete consecutive swap, funding-flow or CEX matching-account dataset was recovered. Consequently, no defensible total-volume, artificial-volume percentage, trader concentration, wash-loop frequency or promotion-event return series can be calculated. Annual aggregate prices or a pair's current reserve ratio would not fix that evidentiary gap.

## 7. Questions that now have exact evidentiary targets

1. Match the stated PeckShield token audit to its report, contract address, version and findings; distinguish staking products.
2. Obtain deployment addresses and parameters for each advertised staking pool, then reconcile reward funding and payouts.
3. Match Mystery Box mints to the promised user contribution, company match and burn-address receipts.
4. Recover dated MEXC assessment/delisting notices and historical GMI/USDT trades; separate exchange figures from DEX swaps.
5. Obtain a complete, routing-aware swap dataset for every verified GMI pool, including liquidity events and transfers, before applying wash-trading tests.
6. Attribute any allegedly deceptive promotion or trading instruction to its actual speaker/approver and date. Laura's named promotional record is established; direction of trades is not.

## Source register

All inspected 2026-09-05. Browser-source failures and cached observations are expressly marked.

| ID | Primary record and URL | Retrieval and date |
|---|---|---|
| S1 | [GamiFi Fair Launch Notice](https://gamifi-launchpad.medium.com/fair-launch-notice-a842e1bf320c?responsesOpen=true) | Full indexed text; 2022-01-17 |
| S2 | [MEXC Kickstarter terms](https://www.mexc.com/announcements/article/initial-listing-mexc-kickstarter-vote-to-win-free-1-000-000-gamifi-gg-gmi-airdrops-4415532646041) | Full text; 2022-01-23 |
| S3 | [MEXC listing result](https://www.mexc.com/announcements/article/voting-result-and-listing-arrangement-for-gamifi-gg-gmi-4415635423001) | Full text; 2022-01-24 |
| S4 | [MEXC AMA with Laura and Casey](https://blog.mexc.com/mexc-ama-gamefi-session-with-laura-and-casey/) | Full search-indexed transcript; 2022-02-23; direct retrieval returned 404 |
| S5 | [Official episode 33](https://www.rageworksnetwork.com/show/gamifi-everything-beyond-the-metaverse/33-a-conversation-with-gamifis-laura-walsh-and-casey-mcquillan/) | Full show notes; 2022-07-01 |
| S6 | [Official podcast RSS](https://feeds.captivate.fm/gamifi/) | Downloaded XML 174,813 bytes; 39 episodes; linked from publisher page |
| S7 | [May staking terms](https://gamifi-launchpad.medium.com/new-staking-pool-open-50dd1e1eb064) | Full primary text inspected in prior review; 2022-05-04 |
| S8 | [Official Telegram post 821 context](https://t.me/s/GamiFiAnnouncements/821) | Full indexed channel context; exact posting date unresolved; Casey authorship displayed |
| S9 | [Official Telegram post 822](https://t.me/GamiFiAnnouncements/822), [readable preceding context](https://t.me/s/GamiFiAnnouncements/813) | Full text of post 822 appears in context; exact posting date unresolved |
| S10 | [Mystery Box article](https://medium.com/@gamifi-launchpad/gamifi-mystery-box-nfts-2840e0eb885e), [official tag index](https://medium.com/tag/gmiarmy) | Article terms indexed only; July 2 date in tag listing; Cloudflare browser access denied |
| S11 | [Secondary burn promotion](https://www.reddit.com/r/NFTsMarketplace/comments/wfcdre), [secondary rollout terms](https://www.reddit.com/r/NFTExchange/comments/w4d65x) | Unverified third-party posts; 2022-08-03 and 2022-07-21 |
| S12 | `volume_gamifi_notes.md` and `volume_gamifi_raw/` | Prior public BNB RPC requests and decoded receipts preserved; no new full-chain scan |
| S13 | [Official FOMO distribution announcement](https://t.me/GamiFiAnnouncements/813), [readable context](https://t.me/s/GamiFiAnnouncements/813) | Company-reported outcome; exact post date unresolved |
| S14 | [Coinband agency claim](https://coinband.medium.com/how-to-create-and-engage-the-web3-community-for-your-project-1a839d6b0ea5) | Primary agency's indexed claim; 2023 publication; client service scope unverified |
| S15 | [MEXC public API documentation](https://mexcdevelop.github.io/apidocs/spot_v3_en/) | Documents public candles and bulk history starting 2023-01-01; two requests timed out |
| S16 | [CoinLore historical page](https://www.coinlore.com/coin/gamifi/historical-data) | Inactive-feed warning and conflicting cache versions; excluded numerical series |
| S17 | [GamiFi Linktree](https://linktr.ee/GamiFi) | Links to the official announcements channel, establishing channel provenance |

## Reproduction files

Distributable factual ledger: `gmi_history_promotions_raw/GMI_PROMOTION_FACTUAL_LEDGER.json` contains dates, titles, source URLs and short paraphrases, with no full show-note bodies.

Internal source files: `gmi_history_promotions_raw/podcast.xml`, `compute_promotions.py`, `promotion_calculations.json`, `podcast_episode_index.json`, `mexc_exchange_info.json`, `mexc_launch_klines.json`.

The raw RSS is a research preservation copy. Derived report wording stays bounded per source; do not publish an entire collection of show notes as a new authored work. No messages, accounts, wallet signatures, trades or state-changing chain calls were used.
