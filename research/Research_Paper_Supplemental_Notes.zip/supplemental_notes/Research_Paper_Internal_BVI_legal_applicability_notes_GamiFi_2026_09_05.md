# Research Paper — Internal BVI legal applicability notes — GamiFi — 2026-09-05

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Scope: primary-source review; no finding of a GamiFi offence, no corporate-registry identity confirmation. Review separates the 2022 operation from post-commencement VASP conduct.

## Verified legal hooks

**2020 FSC virtual-asset guidance** (PDF downloaded, source ref historical retrieval): utility-only payment/access tokens fall outside the financial-services regime described; additional rights can bring a product within SIBA. Assess the economic substance, holder rights and business activity. Equity/profit rights, debt instruments, collective investment interests and derivatives are examples. Staking's quoted APY alone does not establish one of these legal categories. Its contract may create a debt/reward obligation requiring separate analysis. The guidance's cover says 10 July 2020; another official mirrored edition says published 13 July 2020. Use July 2020, avoiding spurious exact-day disagreement.

**SIBA Revised 2020** (historical retrieval; authoritative consolidation):
- Section 4(1): licensing for investment business; 4(2)(b) deems BVI companies' overseas investment business to be from BVI.
- Schedule 1: qualifying investments; Schedule 2 Part A: dealing, arranging, management, advice, custody, administration, exchange. Part B 1(2), 2(4): specified own-issuance exclusions.
- Section 19 addresses licensees' misleading advertisements.
- Section 91(1)-(3): deceptive investment inducements, including knowing/reckless statements; 91(4): intentionally creating misleading market/price/value impressions to induce dealing. Section 91(5) requires conduct in/from BVI. Section 92 contains defences.
- Commencement explicitly excludes Part II. Do not allege its prospectus offences for 2022 from the uncommenced text.

**VASP Act 2022** (downloaded, historical retrieval):
- Section 2: business services for another person, including issuer-sale financial services, transfers, exchange and custody; technology-only exceptions.
- Section 5(1): registration requirement; 5(4): overseas services/holding out by BVI companies deemed from BVI.
- Section 24: knowing/reckless material misstatements or dishonest concealment by a VASP.
- Sections 22/23/29: records, client assets and custody protections.
- Section 40: existing-operator transition; timely applicants may continue pending decision.
- Section 44(b): registered VASP-only business exemption from SIBA/FMSA licensing.
- Section 46(2): senior officers' personal liability requires knowing authorisation, permission or acquiescence in the company's offence.

**FSC commencement notice** (historical retrieval): effective 1 February 2023; existing operators had to apply by 31 July 2023 to continue. Thus no retroactive 2022 VASP-registration accusation. Registration guidance paragraph 2.1 (historical retrieval) expressly says DeFi/NFT/peer-to-peer offerings are captured only if statutory definitions are met.

## Application to recovered GamiFi evidence — analysis/inferences

1. **The IDO intermediary business is more legally significant than token creation alone.** GamiFi advertised other issuers' offerings, accepted allocation payments, performed whitelisting/KYC and described a percentage fee. This business model is a closer factual match to arranging and issuer-sale financial services than a developer simply publishing software. Actual operator agreements, payment recipients and control roles determine the applicable category. Own NFT/token issuance does not automatically answer the on-behalf-of-another question.

2. **The staking package requires its own classification.** Recovered 100–225% annualised promotions and principal locks raise a stronger investment-product question than a gaming-access token by itself. On-chain tests should determine what was deposited, whether GamiFi could move it, how rewards were funded, whether the position was transferable and what enforceable return/redemption rights were sold. Do not call all reward contracts mutual funds: a NAV-linked collective investment interest is different from receiving a preset amount of newly distributed project tokens.

3. **The clearest misconduct leads are transaction-specific misrepresentations.** The 500/1,000 NFT conflict, advertised matching burn and lingering IDO access offer after pause are concrete representations to compare with code and receipts. A known failure to perform a advertised burn while taking purchases is materially stronger than the numerical mismatch alone. A mistyped valuation or later commercial failure does not supply knowledge, recklessness or intentional market distortion by itself.

4. **Post-2023 continuation has evidential significance.** The October 2023 purchase page can be evidence of holding out, because section 5(4) expressly includes being able to carry on services. However, attribution and in-scope service remain necessary: a passive obsolete page offering the issuer's own NFT cannot simply be equated with continuing a regulated third-party launchpad. Read-only on-chain post-February/post-July receipts and admin actions could strengthen this part considerably. A live contract that users operate independently is not automatically continuing business by the original company.

5. **BVI identity and Laura liability are distinct.** The archived terms call the contracting issuer GamiFi Limited, a BVI registered company. They do not contain an independently verified registry certificate or director appointment record. Laura's CEO/promoter role during 2022 is relevant to her own representations and directions. Her September 2022 succession means a post-February 2023 VASP theory must establish her later conduct/control rather than assume it from a former title.

6. **Contract disclaimers do not classify the activity.** Clause 14 denies an intermediary/advisory role while referring to savings and investment services. That drafting inconsistency supports examining economic activity and holder rights. It is not itself a statutory admission or adjudication.

## Bounded register/enforcement search

Read current FSC VASP register pages 1–4: 57 displayed entries, including repeat categories and authorised representatives, NOT 57 separate operating exchanges. No case-insensitive Gami match found on any page. Exact site searches for GamiFi and GamiFi Limited returned no relevant FSC result. No GamiFi enforcement notice recovered in that bounded search. These observations neither establish absence of a historical application/approval nor certify legality. Corporate register not searched through paid/authenticated systems.

Public sources available through web retrieval; direct HTML downloads of commencement/register pages returned 403 and are logged. Primary PDFs were downloaded with URL, response metadata, date, SHA-256 and extracted text. Consolidated SIBA text is preferred over original 2010 statute.

## Source URLs and root reopening refs

- https://www.bvifsc.vg/sites/default/files/guidance_on_regulation_of_virtual_assets_in_the_virgin_islands_bvi_final.pdf — historical retrieval
- https://www.bvifsc.vg/sites/default/files/securities_and_investment_business_act.pdf — historical retrieval; specific s91 passage historical retrieval; own-issuance exceptions historical retrieval
- https://www.bvifsc.vg/sites/default/files/virtual_assets_service_providers_act_2022.pdf — historical retrieval; section24 historical retrieval; transition/enforcement historical retrieval
- https://www.bvifsc.vg/news/industry-updates/virtual-assets-service-providers-act-2022 — historical retrieval
- https://www.bvifsc.vg/sites/default/files/guidance_-_application_for_vasp_registration_0_0.pdf — historical retrieval
- https://www.bvifsc.vg/sites/default/files/virtual_assets_faqs.pdf — historical retrieval, published November 2025 (use as current explanation, not 2022 guidance)
- https://www.bvifsc.vg/regulated-entities-vasp — historical retrieval; no-match historical retrieval
- https://www.bvifsc.vg/regulated-entities-vasp?page=1 — historical retrieval / historical retrieval
- https://www.bvifsc.vg/regulated-entities-vasp?page=2 — historical retrieval / historical retrieval
- https://www.bvifsc.vg/regulated-entities-vasp?page=3 — historical retrieval / historical retrieval
