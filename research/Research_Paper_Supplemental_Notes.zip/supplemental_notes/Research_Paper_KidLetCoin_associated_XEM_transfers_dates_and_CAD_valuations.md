# Research Paper — KidLetCoin-associated XEM transfers: dates and CAD valuations

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Valuation snapshot: **2026-09-05T12:59:50+00:00**. Current rate: **CA$0.00079851 per XEM**. This addendum values the 49 exact-block-checked XEM transactions from the 5 September 2026 on-chain review. It does not price every broader account-history record.

“Then” is an estimate obtained by multiplying each transfer quantity by the Yahoo XEM-CAD UTC daily close on that transaction’s confirmed block date, then summing the individual values. It is not an execution-time quote or evidence of a sale. “Now” prices the same transferred quantity at the CoinGecko snapshot rate. It is not a current wallet balance, realized loss or cash-out amount.

The named wallet paths overlap. Do not add their rows as unique funding or project spending. The two 500,000-XEM legs are a clear repeated movement. The common external destination total concerns five associated wallets across 2018–2022; attribution of that amount to KidLetCoin’s business, a named person or misconduct is unestablished. The issuer also handled another asset, `loyalcoin`.

## Path totals

| Observed path | Transfers | Confirmed UTC date range | XEM | Estimated CAD then | Same quantity in CAD now |
|---|---:|---|---:|---:|---:|
| Foundation SEA → shared signer | 12 | 2018-04-02 to 2019-09-06 | 221,287.57 | CA$52,553.72 | CA$176.70 |
| Shared signer → shared issuer | 9 | 2018-04-05 to 2019-03-20 | 151,894 | CA$38,339.17 | CA$121.29 |
| Shared signer → NDMV5M…; message “For KID” | 1 | 2019-01-09 to 2019-01-09 | 100 | CA$8.55 | CA$0.08 |
| Five register wallets → common external destination NC64UF… | 18 | 2018-09-12 to 2022-03-24 | 5,748,124 | CA$784,624.39 | CA$4,589.93 |
| Issuer → levy/signing wallet; first 500,000-XEM leg | 1 | 2019-03-06 to 2019-03-06 | 500,000 | CA$28,383.00 | CA$399.26 |
| Levy/signing wallet → ND2JRP…; onward 500,000-XEM leg | 1 | 2019-03-06 to 2019-03-06 | 500,000 | CA$28,383.00 | CA$399.26 |
| Issuer → ND2JRP…; later direct transfer | 1 | 2019-06-06 to 2019-06-06 | 300,000 | CA$33,648.30 | CA$239.55 |
| Six explicit staging/distribution/fund-wallet transfers | 6 | 2018-12-09 to 2019-05-04 | 518 | CA$43.79 | CA$0.41 |

## Exact transfer times and estimates

All 49 times below are confirmed block timestamps in UTC. Amounts and confirmation dates were previously checked against historical blocks. Price quotes are daily closing estimates; they may include market changes after the transfer hour. Values are rounded to cents only for presentation, after multiplication.

| Confirmed UTC | Path | XEM | CAD per XEM on that date | Estimated CAD then | CAD now | Transaction |
|---|---|---:|---:|---:|---:|---|
| 2018-04-02T01:01:15+00:00 | Foundation SEA → shared signer | 18,741.15 | 0.29321399 | CA$5,495.17 | CA$14.96 | [c5a1f4ad908b…](https://explorer.nemtool.com/#/s_tx?hash=c5a1f4ad908bc5369a94d8eb0b8c114ef23b7488891d0f4d2b8bc39b6e9d98ff) |
| 2018-04-05T06:24:27+00:00 | Shared signer → shared issuer | 17,237 | 0.28698400 | CA$4,946.74 | CA$13.76 | [3af266b71eff…](https://explorer.nemtool.com/#/s_tx?hash=3af266b71effdc825d436ad3212bd6d1c0675d7f6e16612566888846c4485833) |
| 2018-05-02T20:57:12+00:00 | Foundation SEA → shared signer | 18,669.21 | 0.54184401 | CA$10,115.80 | CA$14.91 | [2ed3f7641c2b…](https://explorer.nemtool.com/#/s_tx?hash=2ed3f7641c2b250411ace074f73a922fba5e0c977cecc83ad22f7d0b5914ff50) |
| 2018-05-03T10:47:42+00:00 | Shared signer → shared issuer | 16,000 | 0.55753702 | CA$8,920.59 | CA$12.78 | [acb192c08b5b…](https://explorer.nemtool.com/#/s_tx?hash=acb192c08b5ba0a4ac9c1cead2e2513d13307c2d2f476d7ed6e1b9a016748036) |
| 2018-05-04T16:40:21+00:00 | Foundation SEA → shared signer | 9,440.73 | 0.55383599 | CA$5,228.62 | CA$7.54 | [eea5afcb38af…](https://explorer.nemtool.com/#/s_tx?hash=eea5afcb38af846b23be953af89094bc045c88be795a2f2a823a4d4430ff38a7) |
| 2018-05-09T03:43:18+00:00 | Shared signer → shared issuer | 8,602 | 0.48749000 | CA$4,193.39 | CA$6.87 | [30e66565ba38…](https://explorer.nemtool.com/#/s_tx?hash=30e66565ba38f30eb652b0c9727d6435bd8eb66297a92151643426e3c3134afb) |
| 2018-06-05T15:12:19+00:00 | Foundation SEA → shared signer | 21,910.45 | 0.32659999 | CA$7,155.95 | CA$17.50 | [61ad8fb01cf1…](https://explorer.nemtool.com/#/s_tx?hash=61ad8fb01cf16baae8313bda9fbbe662298e705f2b6badee48dee83fc6ffef70) |
| 2018-06-06T00:39:26+00:00 | Shared signer → shared issuer | 20 | 0.32488701 | CA$6.50 | CA$0.02 | [3fe28026c74c…](https://explorer.nemtool.com/#/s_tx?hash=3fe28026c74c7acd7b6dbd684a406847a58475feedd93a04dc9eae4dee82c750) |
| 2018-06-06T00:40:02+00:00 | Shared signer → shared issuer | 20,000 | 0.32488701 | CA$6,497.74 | CA$15.97 | [458626ca4b91…](https://explorer.nemtool.com/#/s_tx?hash=458626ca4b91c359bb48001bdc1cea5375e3a65049e9eb8f4d5601dbd4700ea1) |
| 2018-07-08T19:50:59+00:00 | Foundation SEA → shared signer | 35,388.31 | 0.24178299 | CA$8,556.29 | CA$28.26 | [49025cd0e439…](https://explorer.nemtool.com/#/s_tx?hash=49025cd0e4395158046b70ad795bbf4fa08a4fa4dbbf6b08243901925ec0bfde) |
| 2018-07-10T05:26:39+00:00 | Shared signer → shared issuer | 35 | 0.21485101 | CA$7.52 | CA$0.03 | [67938e13bba3…](https://explorer.nemtool.com/#/s_tx?hash=67938e13bba37117f3026966309e1675e74f0956587ab4dd36b1d717bf8be513) |
| 2018-07-10T05:27:09+00:00 | Shared signer → shared issuer | 35,000 | 0.21485101 | CA$7,519.79 | CA$27.95 | [a570b1c7a518…](https://explorer.nemtool.com/#/s_tx?hash=a570b1c7a5186d69c317fb9035426d56ee00f3fcf5dd587f1e15619d22025285) |
| 2018-08-07T15:48:23+00:00 | Foundation SEA → shared signer | 37,208.64 | 0.17705899 | CA$6,588.12 | CA$29.71 | [a776693d646f…](https://explorer.nemtool.com/#/s_tx?hash=a776693d646f0fd382841995155469eeea88d575ee9e472e66332acfb236c8b5) |
| 2018-08-13T04:18:34+00:00 | Shared signer → shared issuer | 35,000 | 0.14004700 | CA$4,901.64 | CA$27.95 | [da3106f872d9…](https://explorer.nemtool.com/#/s_tx?hash=da3106f872d94a731f332f3ef7e340c5ed139de8236e1f1051463f8f9df245be) |
| 2018-09-11T18:13:13+00:00 | Foundation SEA → shared signer | 55,996.8 | 0.11532800 | CA$6,458.00 | CA$44.71 | [1704d90c693a…](https://explorer.nemtool.com/#/s_tx?hash=1704d90c693a14e21f84a405355981a19a5df63ad7e5b52f861ddbab0fdd1930) |
| 2018-09-12T11:58:16+00:00 | Five register wallets → common external destination NC64UF… | 40,000 | 0.11514500 | CA$4,605.80 | CA$31.94 | [30810e8f381d…](https://explorer.nemtool.com/#/s_tx?hash=30810e8f381df87fc505a2a62dd83e8f7160e62db756d6bd350881eb38c37c36) |
| 2018-10-08T00:20:28+00:00 | Foundation SEA → shared signer | 8,821.37 | 0.14119300 | CA$1,245.52 | CA$7.04 | [1e5710d2b56f…](https://explorer.nemtool.com/#/s_tx?hash=1e5710d2b56ff65481b322415311a283e99fa1f71c40642a993c39a91789efe8) |
| 2018-11-12T08:55:21+00:00 | Foundation SEA → shared signer | 8,865.08 | 0.14599299 | CA$1,294.24 | CA$7.08 | [a2acc94f4a12…](https://explorer.nemtool.com/#/s_tx?hash=a2acc94f4a12a23f1eb1c63d12b21f2e9db8900e3dfcc54bcbc04b2c16f540ec) |
| 2018-12-09T07:12:14+00:00 | Six explicit staging/distribution/fund-wallet transfers | 10 | 0.09903200 | CA$0.99 | CA$0.01 | [f0e874f61bad…](https://explorer.nemtool.com/#/s_tx?hash=f0e874f61bad93cabc03420deb317bfb74c04069074cafdfd6e87769b9a1ac0e) |
| 2018-12-09T07:14:37+00:00 | Six explicit staging/distribution/fund-wallet transfers | 100 | 0.09903200 | CA$9.90 | CA$0.08 | [cfe17b932840…](https://explorer.nemtool.com/#/s_tx?hash=cfe17b93284097aae90b437f27676733e2fd1c663dfaa17a3d98e29b283754db) |
| 2018-12-09T07:32:43+00:00 | Six explicit staging/distribution/fund-wallet transfers | 108 | 0.09903200 | CA$10.70 | CA$0.09 | [94109e11c700…](https://explorer.nemtool.com/#/s_tx?hash=94109e11c700dd8a6669d7b8f2dbe80f1ea35aa6c4aca1b1c5d5c486fb6213cf) |
| 2018-12-14T08:13:35+00:00 | Foundation SEA → shared signer | 1,871.3 | 0.08219000 | CA$153.80 | CA$1.49 | [f0fd899a5ad7…](https://explorer.nemtool.com/#/s_tx?hash=f0fd899a5ad729c24068ff5521fa7c589d537b1333190962b6e629bd88722114) |
| 2019-01-09T03:41:52+00:00 | Shared signer → NDMV5M…; message “For KID” | 100 | 0.08552300 | CA$8.55 | CA$0.08 | [e5c7ad591401…](https://explorer.nemtool.com/#/s_tx?hash=e5c7ad5914018167b6125fc31d6133d65667aae2771807c116d750d9be9a1e07) |
| 2019-02-13T07:15:46+00:00 | Foundation SEA → shared signer | 601.3 | 0.05417000 | CA$32.57 | CA$0.48 | [b9b1e216d270…](https://explorer.nemtool.com/#/s_tx?hash=b9b1e216d270e216652d02eba9fc12f0cbce67689c96c4efd41c7778eaebb890) |
| 2019-03-06T03:39:49+00:00 | Issuer → levy/signing wallet; first 500,000-XEM leg | 500,000 | 0.05676600 | CA$28,383.00 | CA$399.26 | [9e715ed554f0…](https://explorer.nemtool.com/#/s_tx?hash=9e715ed554f0830fc93d867f6a48e0b0aeaebaa61bdaadea73691f6b2b741baf) |
| 2019-03-06T03:42:31+00:00 | Levy/signing wallet → ND2JRP…; onward 500,000-XEM leg | 500,000 | 0.05676600 | CA$28,383.00 | CA$399.26 | [905643ede832…](https://explorer.nemtool.com/#/s_tx?hash=905643ede8322b230f03f4b9cb36d0021e49dfdc7705af4d2d03e9a7ff69f1af) |
| 2019-03-20T04:36:50+00:00 | Shared signer → shared issuer | 20,000 | 0.06726300 | CA$1,345.26 | CA$15.97 | [d0d92edcccce…](https://explorer.nemtool.com/#/s_tx?hash=d0d92edcccce440102022115588e7aaf67a63e8fbb0b578a0b3d616b19719a1e) |
| 2019-05-04T07:24:34+00:00 | Six explicit staging/distribution/fund-wallet transfers | 100 | 0.07398800 | CA$7.40 | CA$0.08 | [da1af718a111…](https://explorer.nemtool.com/#/s_tx?hash=da1af718a1119df5833d927930769ea4d64a3cb7c85908a256c503c2ea17d0d3) |
| 2019-05-04T07:29:30+00:00 | Six explicit staging/distribution/fund-wallet transfers | 100 | 0.07398800 | CA$7.40 | CA$0.08 | [ace24ad9c377…](https://explorer.nemtool.com/#/s_tx?hash=ace24ad9c377427b9d54e14672c65af40c77cd7f347605af6de0b94bd4ec9a65) |
| 2019-05-04T08:59:09+00:00 | Six explicit staging/distribution/fund-wallet transfers | 100 | 0.07398800 | CA$7.40 | CA$0.08 | [eabb63f690db…](https://explorer.nemtool.com/#/s_tx?hash=eabb63f690db10f97a50e6594de617812448f3583262003e1a74e4ee56e0d9c6) |
| 2019-05-20T05:34:38+00:00 | Five register wallets → common external destination NC64UF… | 200,000 | 0.11958600 | CA$23,917.20 | CA$159.70 | [2339ce0d9261…](https://explorer.nemtool.com/#/s_tx?hash=2339ce0d9261990dd334a5a277db7560f0472135ddaa9205d36f1f70f600b4cd) |
| 2019-06-06T10:15:21+00:00 | Issuer → ND2JRP…; later direct transfer | 300,000 | 0.11216100 | CA$33,648.30 | CA$239.55 | [fa86f51c3f2a…](https://explorer.nemtool.com/#/s_tx?hash=fa86f51c3f2a88197aeac376e0f445c3d3bb11ada66163fdcb56aede39825b25) |
| 2019-06-27T09:17:22+00:00 | Five register wallets → common external destination NC64UF… | 10,000 | 0.11675200 | CA$1,167.52 | CA$7.99 | [e5edfda14a6a…](https://explorer.nemtool.com/#/s_tx?hash=e5edfda14a6a1491930ea54d1e13479e7c7388e2c974ef09b32d72d55f49c8a4) |
| 2019-09-06T17:42:22+00:00 | Foundation SEA → shared signer | 3,773.23 | 0.06086000 | CA$229.64 | CA$3.01 | [0137e3422de1…](https://explorer.nemtool.com/#/s_tx?hash=0137e3422de11d75421bbc5fb04bac739d3aa81e3b9850a11b046e82942a36a5) |
| 2019-12-04T06:44:53+00:00 | Five register wallets → common external destination NC64UF… | 1,000,000 | 0.04655400 | CA$46,554.00 | CA$798.51 | [05d1c5c20316…](https://explorer.nemtool.com/#/s_tx?hash=05d1c5c2031619e9e027e51aabf12844fa4f56ddad6cace3503c6c31f2bdd28b) |
| 2020-03-05T04:11:14+00:00 | Five register wallets → common external destination NC64UF… | 3,000,000 | 0.07275200 | CA$218,256.00 | CA$2,395.53 | [d497819f848b…](https://explorer.nemtool.com/#/s_tx?hash=d497819f848b7c8e62ac89950d5ba8bd7bc9e950a1252bd20f840631bfcdbe06) |
| 2020-12-05T01:16:13+00:00 | Five register wallets → common external destination NC64UF… | 90,000 | 0.33297199 | CA$29,967.48 | CA$71.87 | [252e38fb1b5b…](https://explorer.nemtool.com/#/s_tx?hash=252e38fb1b5b6f1483d13d8c5c419ca6724752ad2975af81e6fe7d4f806edf9e) |
| 2020-12-05T05:29:04+00:00 | Five register wallets → common external destination NC64UF… | 300,000 | 0.33297199 | CA$99,891.60 | CA$239.55 | [87829765979a…](https://explorer.nemtool.com/#/s_tx?hash=87829765979abe89fa3e1e397937e9c692ada9598d21dde43b126e1778d23461) |
| 2020-12-05T12:52:08+00:00 | Five register wallets → common external destination NC64UF… | 77,500 | 0.33297199 | CA$25,805.33 | CA$61.88 | [e1007a287abc…](https://explorer.nemtool.com/#/s_tx?hash=e1007a287abc49e5839de51fab3c6102ecc1bfc5266537afb3fb1fa0ea367f2b) |
| 2021-01-07T08:53:54+00:00 | Five register wallets → common external destination NC64UF… | 2 | 0.31498301 | CA$0.63 | CA$0.00 | [4472861bae5a…](https://explorer.nemtool.com/#/s_tx?hash=4472861bae5a84fee7c3078c5de40a2f787e17afabf1915980aac269a8864c7d) |
| 2021-01-27T20:39:32+00:00 | Five register wallets → common external destination NC64UF… | 26,000 | 0.29778799 | CA$7,742.49 | CA$20.76 | [cf3fe0cd2d78…](https://explorer.nemtool.com/#/s_tx?hash=cf3fe0cd2d78dc14cfe599583631505febd576f5153eee0d8c0d5ba100cb3d2d) |
| 2021-03-03T12:51:35+00:00 | Five register wallets → common external destination NC64UF… | 364 | 1.00797606 | CA$366.90 | CA$0.29 | [bdfd3075c4bc…](https://explorer.nemtool.com/#/s_tx?hash=bdfd3075c4bcc5ad019bdf1b3b4a4c9e185952446642373dd5d16d2f7c5630bc) |
| 2021-03-22T04:17:57+00:00 | Five register wallets → common external destination NC64UF… | 5,100 | 0.45936999 | CA$2,342.79 | CA$4.07 | [e1808af1e1d0…](https://explorer.nemtool.com/#/s_tx?hash=e1808af1e1d096c5eec06aadb81571df6b289463bffd021356dc00e59672262c) |
| 2021-03-22T12:31:39+00:00 | Five register wallets → common external destination NC64UF… | 500,000 | 0.45936999 | CA$229,684.99 | CA$399.26 | [fabaf43d50d1…](https://explorer.nemtool.com/#/s_tx?hash=fabaf43d50d1dca62d0135b64df32e81054cd37c58da0f3f83ccc0b441e69b8b) |
| 2021-10-20T07:24:43+00:00 | Five register wallets → common external destination NC64UF… | 250,000 | 0.21378100 | CA$53,445.25 | CA$199.63 | [e21ec34d82b0…](https://explorer.nemtool.com/#/s_tx?hash=e21ec34d82b0ef649f4e778a51bc7d3451ad8992ea229e221c2886dda2dea63e) |
| 2021-11-02T12:57:11+00:00 | Five register wallets → common external destination NC64UF… | 50,000 | 0.26776499 | CA$13,388.25 | CA$39.93 | [63be1be4273c…](https://explorer.nemtool.com/#/s_tx?hash=63be1be4273c982c340ea1037c93ce00436fa4f2997694708cbbea89b7183ae1) |
| 2022-03-01T08:50:24+00:00 | Five register wallets → common external destination NC64UF… | 158 | 0.13959000 | CA$22.06 | CA$0.13 | [bf446a6ebef7…](https://explorer.nemtool.com/#/s_tx?hash=bf446a6ebef7125f6a97fd4057c4a531d7009b08d66eb71e428e9e59e8367432) |
| 2022-03-01T08:56:17+00:00 | Five register wallets → common external destination NC64UF… | 99,000 | 0.13959000 | CA$13,819.41 | CA$79.05 | [bd9bed0b1808…](https://explorer.nemtool.com/#/s_tx?hash=bd9bed0b180875d8122dfeac5b0ad8cf511a0f3616e1c45fb9d857e8881e9136) |
| 2022-03-24T12:42:54+00:00 | Five register wallets → common external destination NC64UF… | 100,000 | 0.13646699 | CA$13,646.70 | CA$79.85 | [30ec45d51bff…](https://explorer.nemtool.com/#/s_tx?hash=30ec45d51bfffd4aa6a3ac239522c3da154dd66178a27b40ccf05ded418e8c6e) |

## KID and XEM are different assets

The historical issuance/distribution chain moved 21 million KID through issuer, staging and distributor. Gross repeated movement across the 28 KID index rows was 60,901,115.523681 KID. No verified CAD market price or cash-redemption rate for the original `kidlet:kid` asset was established. These KID quantities cannot be multiplied by XEM’s market price. The original KID namespace became inactive in May 2021. A missing verified quote is not the same as establishing an exact zero-dollar historical value.

## Sources and arithmetic verification

- [Yahoo XEM-CAD daily historical data](https://query1.finance.yahoo.com/v8/finance/chart/XEM-CAD?period1=1522540800&period2=1648252800&interval=1d), retrieved 2026-09-05T13:02:15.432699+00:00. All 38 required confirmation dates were matched directly to raw UTC timestamp indices and non-null CAD closes.
- [CoinGecko current NEM quote](https://api.coingecko.com/api/v3/simple/price?ids=nem&vs_currencies=cad,usd&include_last_updated_at=true), quoted 2026-09-05T12:59:50+00:00. Raw response is retained as `current_coingecko.json`.
- [Yahoo current XEM-CAD quote](https://query1.finance.yahoo.com/v8/finance/chart/XEM-CAD?interval=1d&range=5d) independently showed approximately the same current rate. No averaging of different snapshots was used.
- Each transaction links directly to its explorer record. The original chain evidence is retained in `KIDLETCOIN_ONCHAIN_EVIDENCE_2026-09-05.zip` from the preceding response.
- Independent arithmetic QA recomputed all 49 row values from the raw Yahoo arrays and original verified transfer records; zero mismatches. Decimal arithmetic was used, with source price precision retained before final rounding.
- The supplementary Bank of Canada USD/CAD series was retrieved as a fallback but was not used: direct historical XEM-CAD prices were available.

The companion valuation evidence ZIP retains the historical price arrays, the current snapshots with provenance, per-transfer calculations and the arithmetic QA result.
