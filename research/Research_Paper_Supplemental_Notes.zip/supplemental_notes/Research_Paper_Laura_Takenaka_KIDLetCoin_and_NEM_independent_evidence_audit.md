# Research Paper — Laura Takenaka, KIDLetCoin and NEM: independent evidence audit

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

**Review date:** 5 September 2026; updated after the fifth archive pass with Canadian act-to-law analysis, contest-language verification and domain-country/company distinctions. **Scope:** standalone assessment of the two supplied memoranda, with fresh public-source verification. This assessment is independent of any other dispute. It distinguishes observed records, inference, technical risk and unresolved personal responsibility.

**Assessment:** The evidence establishes substantial adult involvement by Laura in KIDLetCoin and meaningful overlap with her NEM Foundation work. The deeper review strengthens the association between Laura and the shared project/Foundation signing account. It also confirms a serious credential-handling defect in the located wallet source. The contest’s identifying-data request is real. Foundation funding of KIDLetCoin, receipt or misuse of children’s submissions, and Laura’s responsibility for the contest’s data practices remain unestablished. These are material investigation questions; the present evidence does not establish a personal criminal offence.

**Second-pass findings:** a separately attributed Foundation regional account made twelve payments to the Laura-associated shared signer in 2018–2019, with accounting references but no stated KID purpose. The promoted quiz beta remains outside the wallet-source audit. Original interviews reveal an incompletely identified adult support/funding team and inconsistent descriptions of redemption readiness. A same-day archived project post establishes communication in July 2020, correcting any blanket 2019-abandonment theory. Unrelated content appeared in the domain space by December 2023; its operator is unidentified.

**Third-pass findings:** a public post attributed to Laura and dated 28 August 2018 directly describes work on KIDLetCoin’s business logic and recruitment of helpers. Her later first-person posts supply a sequence of planning, educational outreach, milestone promotion and release discussion. This is evidence of active adult project participation. The legal assessment also distinguishes unproven responsibility from lawfulness: applicable child-data consent, collection-limit and security duties can be violated without a sale, hack or predatory motive.

**Fourth-pass findings:** an International Baccalaureate article published in September 2019 and archived the following day explicitly credits Laura with helping establish KIDLetCoin and jointly planning its curriculum. Historical control records establish the shared key’s authority during the June 2019 contest; five project transfers show that key actually cosigning KID movements. The complete embedded Foundation ROI report was recovered, independently verifying its Council listing and aggregate financial explanations already described in the supplied memorandum. An unreconciled expenditure percentage was identified. These records strengthen the project-role and financial-authorization connections while leaving contest administration, data custody and the purpose of regional payments unresolved.

**Fifth-pass findings:** a January 2019 wallet-demo capture preserves the project’s announcement of Play availability and its exact package identifier. A December 2022 contest capture preserves the complete identifying-information request, including the submission email; both descriptions exactly match their currently retrieved versions. Separately, Arquivo.pt preserved a November 2019 post by NEM’s own account describing Laura as Foundation Secretary appearing alongside KIDLetCoin at the 0110 Thailand Tech Festival. An earlier Medium capture credits the known project article to NEM’s editorial account. These improve historical authentication and institutional-promotion evidence; they do not identify the contest inbox custodian or supply a grant record.

**Canadian-law and domain clarification:** the later domain record's registrant-country field is VN (Vietnam, Asia), while Namecheap is the current US registrar; the buyer's identity/company and connection to Laura remain unknown. This field already appeared in earlier saved records. The contest instructions are English, with English automatic-caption metadata supporting the spoken-language inference. The historical Canadian analysis identifies specific consent, necessity, notice, disclosure and security questions, including a pre-existing Quebec penal route, while distinguishing territorial applicability, personal participation and substantial limitation obstacles for discrete 2019 acts. See sections 1, 7 and 8b.

**The proposed explanation, tested link by link**

| Proposition | Result of this review |
|---|---|
| Laura participated in both projects | Supported by her statements and Foundation records. She held Foundation roles and helped KIDLetCoin; this does not make her the founder or sole controller of NEM. |
| NEM Foundation financed the KID project | Not established. The earlier operating-wallet screen found zero matches. A second regional-wallet screen found twelve payments to the shared signer, but none to the five core KID wallets and no identified KID expense purpose. |
| The project solicited children’s identifying information | Confirmed in the retrieved contest description. |
| The wallet automatically harvested the contest information | No such application upload path was identified in the reviewed wallet source. The quiz beta and distributed binaries remain unaudited; the contest separately directed submissions to email. |
| Children actually submitted information | No verified submission, recipient record or result announcement was recovered. |
| Children were offered cryptocurrency for selected content | Supported: the offered reward was KID, the project’s NEM-based asset. XEM was the underlying network’s separate native currency. |
| The structure generated illicit profit from children’s data | Not established. Solicitation, technical weakness and promotional benefit do not themselves prove sale, abuse, deception or profit. |

**1. What the contest actually requested**

The official video’s current description, now also recovered in an exact **10 December 2022, 14:15:19 UTC archive capture**, directs ages 8–18 to submit a short explanation of a listed financial/blockchain topic. It asks for a video link, public wallet address, name, age, email and location, directed to **the project's published submission mailbox**. Selected videos were offered 20–30 KID and channel publication. Retrieved page metadata identifies a 2 June 2019 upload; the description gives an 11 June deadline. [Original contest](https://www.youtube.com/watch?v=3ydvqwGaw0o); [complete archived description](https://web.archive.org/web/20221210141519id_/https://www.youtube.com/watch?v=3ydvqwGaw0o).

This independently corroborates the supplied KID memorandum, pp.21–22. The retrieved description contains no parent-first submission step, consent process or linked contest privacy notice. It does not establish the historical inbox’s configuration or prove there were no separate safeguards.

The evidentiary precision matters:

- A video request creates the possibility of revealing a child’s image, voice and surroundings. The reproduced instruction does not expressly require an on-camera face, voice, photographs, home address, GPS coordinates, private key or seed phrase.
- A recipient of the combined submission could associate a child’s identity with a public wallet. That private mapping does not automatically become public merely because a video is published. Public attribution would require disclosure or inference of the mapping.
- The full decoded December 2022 description exactly matches the September 2026 version, including line breaks. This authenticates the solicitation’s wording by December 2022, before the June 2025 re-created domain registration. It does not establish an uninterrupted edit history, unchanged wording in June 2019, or a contest still accepting entries in 2022. The 2019 upload date applies to the video, not independently to every word in its description.
- The stated rationale was educational content and channel publication. That is evidence of the advertised purpose, not proof of every operator’s motive or of proper handling.

These qualifications preserve the concrete concern: the invitation sought a linkable bundle concerning children, and the available materials do not demonstrate how the adults protected it.

**Contest language:** the recovered written instructions are **English**. Both the December 2022 archived player response and the current response identify one source caption track as English, with `languageCode=en` and `kind=asr`. The default audio track references it. This supports an inference of English speech from YouTube's automatic-caption metadata; no direct listening or recovered transcript is claimed. Thai appears as an available automatic-translation target, not a separate original-language track. The rules do **not** require English-language entries or exclude Thai. English publication alone does not establish Canadian targeting. [Archived original contest](https://web.archive.org/web/20221210141519id_/https://www.youtube.com/watch?v=3ydvqwGaw0o); [current original](https://www.youtube.com/watch?v=3ydvqwGaw0o).

**1a. What was the product and business actually offering? — second pass**

The recovered original e27 interview, published 21 June 2019 and captured that July, describes funding from the mother and friends, plus unnamed private investors assisting MVP development. It acknowledges other adult blockchain helpers who preferred no publicity. It also explicitly rejects an ICO. These are participant claims, without contracts, investor identities, amounts or verified proceeds. The public-facing child-CEO narrative therefore does not fully identify the adults financing and operating the project. It does not establish a concealed crime. [Original interview archive](https://web.archive.org/web/20190721025351id_/https://e27.co/meet-kaede-takenaka-the-10-year-old-ceo-of-thai-blockchain-startup-kidletcoin-20190620/).

The same interview describes shopping with KID as available and says an earlier parental takeback idea was abandoned. In contrast, the event organizer’s 18 June account says redemption partners were still being sought and describes parental takeback. Publication dates are three days apart; interview dates and changes to the prototype are unknown. The discrepancy warrants checking implementation and merchant records, rather than inferring deliberate falsehood. [Techsauce’s original announcement](https://techsauce.co/pr-news/meet-young-entrepreneurs-at-techsauce-global-summit-2019).

THE STANDARD’s 14 June Thai interview describes hoped-for project income, future fundraising, task/homework tracking and future store redemption. These are commercial ambitions and proposed features, not verified sales, automatic monitoring, token appreciation or investor returns. Its accompanying app caption describes development in progress. Educational purpose does not by itself establish that a project was noncommercial. [Original Thai interview](https://thestandard.co/kaede-takenaka-kidletcoin-ceo/).

NEM’s own article, dated 28 November 2018 in a recovered May 2021 capture, promoted the project and described one KID as an hour-of-work unit, with a store to follow. That is not a fiat peg, wage entitlement or guaranteed cash redemption. The article contains no KID grant amount or funding agreement. Its original publication date must not be confused with the later preservation date. [Archived official NEM article](https://web.archive.org/web/20210509035924id_/https://blog.nem.io/kidlet-will-utilize-nem-technology-in-delivering-its-mission-to-teach-kids-about-blockchain-and-fiscal-management/).

No named redemption merchant, verified shop transaction, parent token-purchase mechanism, price list, redemption rate or enforceable redemption terms was recovered. This leaves a material gap between promotional descriptions and a demonstrated operating rewards economy. A token transfer alone would not fill that gap.

**2. Was the email route insecure?**

The email submission route is validated. A categorical finding that the mailbox was unencrypted, publicly accessible or compromised is not supported.

| Question | What can be established |
|---|---|
| Does an `info@` name reveal who could read it? | No. It could represent a mailbox, forwarding alias, group or ticketing system. The label does not establish permissions. |
| Must email have travelled without encryption? | No. Historical transport protection is unknown. |
| Would TLS alone protect stored copies from every administrator or delegate? | No. Transport protection and end-to-end content encryption are different controls. |
| Were consent, access and deletion arrangements demonstrated? | Not by the recovered contest description or the missing archived policy bodies. That is an evidence gap, not proof each control was absent. |
| Was the requested combination privacy-sensitive? | Yes, as an analytical assessment: identifying details associated with video and a public wallet can create persistent linkage if received and retained. |

Contemporaneous technical standards already distinguished encryption of email connections from protection of message content. RFC 8314 addressed submission/access transport security, while NIST SP 800-177 Rev.1 addressed trustworthy email, including TLS and content encryption. Neither lets us infer a particular historical mailbox’s protection from its address. [RFC 8314, January 2018](https://www.rfc-editor.org/info/rfc8314/); [NIST SP 800-177 Rev.1, February 2019](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-177r1.pdf).

Resolving this requires historical provider/configuration records, access and forwarding permissions, authentication controls, consent arrangements, retention/deletion rules and any original-message headers obtained through an authorized process. Current DNS and a modern test cannot reconstruct the 2019 configuration. No test messages were sent.

**Defensible finding:** a child-data solicitation with an email submission route and unverified handling safeguards. The record does not yet establish actual receipt, a security breach or misuse.

**3. What can personally be attributed to Laura?**

Her involvement exceeds a family connection. In February 2019 she described “The KID wallet we did for the KIDLetCoin project” and identified its NEMPay lineage. Her professional-profile post also promoted the demonstration and further project work. These are first-person participation evidence, not proof she personally programmed the app. [Forum statement](https://forum.nem.io/t/catapult-mobile-wallet-discussion/21808); [wallet demonstration post](https://www.linkedin.com/posts/lauralwalsh_kidletcoin-wallet-demo-video-activity-6491593875063439360-Nte8).

The historical demonstration post now displays Laura Walsh as its author, while a contemporary comment addresses Laura Takenaka. That supplies a public professional-record bridge between the two names; it is not a civil-identity document. This distinction matters when assessing the later name-bearing transaction messages.

A stronger operational connection emerges from the May 2019 Foundation update: Laura and its creative director were responsible for the global content calendar, communications policies and media materials. This makes the approval and conflict-management process for family-project promotion a concrete inquiry. It does not identify who approved any particular post. The same update describes her interim secretary role as nonvoting and without additional remuneration. [May 2019 update](https://forum.nem.io/t/nem-foundation-update-may-2019/22634).

The family affiliation was publicly disclosed in her December 2018 AMA. Public disclosure of that relationship does not establish a formal interest declaration, recusal or independent approval, but an allegation that the family relationship itself was hidden would be inaccurate. [Laura’s AMA](https://www.reddit.com/r/nem/comments/a1yh9g/ama_laura_takenaka/).

A newly recovered 20 November 2018 forum contribution by Nelson Valero already discusses Laura’s candidacy alongside the family’s KID project and offers future assistance. This is earlier evidence that the affiliation was discussed publicly. An offer does not establish that assistance or funding followed. [Contemporaneous conflict discussion](https://forum.nem.io/t/transparency-with-proximax-candidates/20658/8).

The appointment chronology substantially survives review. June’s update concerns NEM Malaysia; September separately reports her appointment as a NEM.io Foundation director through the 13 June EGM and the later honorary-secretary appointment under bylaw 33 after the August AGM. Electoral defeat followed by a later appointment is not inherently a fraudulent reversal. Full procedural compliance still requires the governing documents and resolutions. [September update](https://forum.nem.io/t/nem-foundation-update-september-2019/23549).

The Foundation’s January 2020 year-in-review also credits Laura’s Secretariat work on forum communications. Its March 2020 ROI report lists **Laura Takenaka as a Council Member** on its closing page. The complete embedded report is now independently readable and was checked against the supplied memorandum. This is institutional role attribution, not a personal signature, proof she wrote the report, or approval of every expense. [Foundation year-in-review](https://forum.nem.io/t/nem-foundation-2019-year-in-review/24213); [ROI report, closing page](https://forum.nem.io/uploads/default/4bfe9c190bc29c726e8d26f31a9e3a7eb877d785).

The official election guide describes decision-recording and member-distribution duties for the Secretary, while distinguishing that position from the Company Secretary. Missing public internet copies do not prove members were denied records. [Official guide](https://medium.com/nem-sea/nem-elections-voting-guide-f39b99eebc29).

Laura’s candidacy discussion also states that she was not on Council in November 2018 and lacked Foundation-wide hiring/firing authority. Those limits prevent automatically assigning the institution’s earlier spending failure to her. [Candidacy discussion](https://forum.nem.io/t/laura-takenaka-for-secretary-council/20442).

**3a. Direct evidence connecting Laura to project planning and execution**

The newly recovered public Instagram caption, dated **28 August 2018**, identifies the project as KIDLetCoin on NEM and states: **“We’re still working out the core business logic”**. It also invites people to assist, thanks existing helpers and represents that a wallet works. Current public page metadata attributes the post to Laura Walsh under `lwbkk`; the caption and author metadata were read without accessing the accompanying child video. This supports personally expressed participation in the project’s planning and recruitment, beyond a family connection. [Public project post](https://www.instagram.com/reel/BnDQ-S2jnPp/).

The relevant sequence is:

| Public post date | Specific act or statement | Supported connection |
|---|---|---|
| 28 August 2018 | Describes ongoing business-logic work and invites helpers | Project planning and recruitment |
| 2 November 2018 | Discusses her daughter’s NEM education project in an existing school-project thread and describes her daughter’s hoped-for hackathon | Laura’s educational outreach concerning the project |
| 17 January 2019 | Promotes the official wallet demonstration and refers to the next milestone | Public participation in the project’s development milestones |
| 3 February 2019 | Describes the wallet work collectively and discusses possible reconsideration of an iOS release | Participation in wallet work and familiarity with release decisions |
| 27 September 2019 | International Baccalaureate article credits Laura with helping establish KIDLetCoin and jointly planning its curriculum | Contemporaneous institutional reporting of establishment and educational-planning roles |

Sources after the Instagram post: [school-project discussion](https://forum.nem.io/t/marketing-sponsorship-proposal-for-kierans-kids/7268/13); [Laura’s wallet-demo post](https://www.linkedin.com/posts/lauralwalsh_kidletcoin-wallet-demo-video-activity-6491593875063439360-Nte8); [wallet and iOS discussion](https://forum.nem.io/t/catapult-mobile-wallet-discussion/21808/2).

The November school-project reply describes her daughter’s mosaic/education project without explicitly naming KIDLetCoin; its connection is contextual. That thread’s separate funding proposal belongs to another project and is not evidence of a KID grant.

The LinkedIn schema gives publication time **17 January 2019, 09:16:27 UTC**. Forum server metadata gives **3 February 2019, 02:40:57 UTC**, with matching creation/update timestamps and version 1. These improve provenance. The Instagram caption and LinkedIn metadata are currently served historical posts; an unchanged contemporaneous copy was not authenticated, and public display names can change.

The International Baccalaureate article has stronger contemporaneous preservation: publication **27 September 2019**, exact archive capture **28 September 2019, 21:00:16 UTC**. It expressly describes Laura helping establish KIDLetCoin and jointly planning a blockchain curriculum and school partnerships. The project’s own account linked the article on 3 October 2019, with a same-day preserved post. This is an institutional account of the project narrative, rather than an incorporation record or evidence that the proposed partnerships were delivered. It supplies no contest-administration assignment. [Next-day article capture](https://web.archive.org/web/20190928210016id_/http://blogs.ibo.org/blog/2019/09/27/young-ib-student-starts-a-block-chain-company/); [project’s archived link](https://web.archive.org/web/20191003132650id_/https://twitter.com/kidletcoin/status/1179745410509750273).

**Assessment:** these statements connect Laura to planning, recruiting assistance, promotion and wallet/release discussions. They strengthen the basis for examining whether her actual responsibilities included the contest and quiz. They do not by themselves assign her authorship of the contest rules, mailbox permissions or decisions about children’s data. Those are specific acts requiring their own evidence; missing proof is not an affirmative finding that she had no such role.

**3b. Contemporary institutional promotion recovered from a separate archive — fifth pass**

Arquivo.pt preserves an original NEMofficial timeline captured **16 November 2019, 03:12:41 UTC**. Its post `1193951524348661761`, published **11 November 2019, 18:00:00 UTC**, identifies Laura as Foundation Secretary and reports her participation alongside the KIDLetCoin CEO in the recent **0110 Thailand Tech Festival**. It describes discussion of blockchain and encouraging the younger generation’s involvement. The original account attributes, permalink and numeric publication timestamp are present in the archived HTML; the UTC time was calculated from that field rather than the localized interface clock. [Exact archived NEM timeline](https://arquivo.pt/noFrame/replay/20191116031241id_/https://twitter.com/NEMofficial); [original post permalink](https://twitter.com/NEMofficial/status/1193951524348661761).

This is contemporary institutional reporting of a joint public appearance, published through NEM’s own account. Combined with Laura’s documented communications role and separate KID establishment/planning statements, it strengthens the basis for examining the approval and conflict-management arrangements for that promotion. It does not identify the human who authored or approved the post, establish a grant or travel/staff expense, or assign contest-data duties. The post’s shortened supporting link yielded no archived destination; the precise festival date is not inferred from the November 11 publication date.

This is a separate event from the supplied Foundation Facebook announcement promoting a **November 30, 2019** appearance. The latter’s current public metadata was recovered and confirms the joint-promotion wording, but no historical capture was recovered from the tested desktop/mobile routes. Its event date is not an independently established post-publication date. [Supplied Foundation Facebook announcement](https://www.facebook.com/ourNEM/posts/nem-foundation-secretary-laura-takenaka-and-kidlet-ceo-kaede-takenaka-will-be-sp/1228852777305718/).

The known official KID article was also recovered in an earlier **8 November 2020, 11:54:18 UTC Medium capture**, credited to **NEM Official (Editors)** and canonically linked to the same NEM blog article. Its visible date and structured creation/publication fields say **28 November 2018**; its modification field says **8 December 2018**. An OpenGraph field misleadingly repeats that modification time as publication, so it must not shift the article’s original date. This is an additional preserved copy and editorial-account credit, not independent journalism or identification of an individual author. It names no KID grant. [Earlier Medium capture](https://web.archive.org/web/20201108115418id_/https://medium.com/nemofficial/kidlet-will-utilize-nem-technology-in-delivering-its-mission-to-teach-kids-about-blockchain-and-2bdf12d23c4f).

**4. New evidence concerning the shared signing account**

The original NEM memorandum identifies the account abbreviated **NBDCOH…** as a signer for both the old Foundation operating wallet and three KID multisignature accounts. Fresh public-node account responses reproduce that overlap. The current Foundation configuration requires four signatures from six listed keys; the KID distributor/development accounts require three of six, while the education account requires one of six. A count of keys does not establish a count of independent people. Current configurations must not be assumed to apply unchanged to every historical date. [Foundation state](https://nem01.symbol-node.com:7891/account/get?address=NBFOUNDXB54PVVPG6AN4WJ7BAOYFBC2XLLHDU5YM); [shared account state](https://nem01.symbol-node.com:7891/account/get?address=NBDCOHCTOKI3RY46YK7EEPPQRG2UHPCNUQIDVLU5).

The fresh history review found three direct outgoing transactions signed by that same public key with name-bearing messages:

| Transaction creation date | Relevant message excerpt | Primary transaction |
|---|---|---|
| 15 August 2018 | “Laura coin” | [ded96af…](https://explorer.nemtool.com/#/s_tx?hash=ded96af556bed84c643ee8d5f5d48180d0249d041c2b0ef9520e1449c3d46ebd) |
| 15 November 2021 | “sent from Laura” | [b50b2d1…](https://explorer.nemtool.com/#/s_tx?hash=b50b2d1b96953632cdb1b3d12c5f26f4e429465de84366b52e1567c6ec814c49) |
| 16 November 2021 | “Laura Walsh BSC” followed by a destination omitted here | [095db53…](https://explorer.nemtool.com/#/s_tx?hash=095db539eeaba5c0e4c75d838e8a0a84062dbdb4bcfaab176df612b7690ceaf0) |

These are outgoing transaction-message fields associated with the common signing key, not an explorer’s informal owner label. The 2021 records were cross-checked against a second public node and exact explorer lookups. The earlier record provides a name-bearing association before the 2019 control overlap.

**Inference:** this materially strengthens the account’s association with Laura compared with the original report’s wholly unattributed treatment. **Limit:** signing authenticates key use, not civil identity. A custodian or associate could include a beneficiary’s name, keys can be shared or transferred, and a name in a message does not prove sole human custody throughout 2019. None of these messages is itself evidence of misconduct. Unrelated personal holdings and destination addresses are outside this assessment.

The review also found sustained use of the shared key: **358 actions by the old Foundation account**, comprising **354 outgoing transfers and four control changes**, contain it as outer signer or explicit cosignatory. Relevant signature dates span 27 August 2019 to 9 July 2020. Another nine signed records are incoming transfers from other multisignature accounts and are excluded from that Foundation-action count. This expands the original report’s isolated control-change example into repeated participation in treasury authorization. It does not prove sole control, beneficial receipt, diversion or an improper purpose. The method and limits appear below.

**4a. Historical KID control and actual use of the common key — fourth pass**

Replaying the five core project wallets’ control events establishes their configurations during **2–11 June 2019**, the advertised contest window. No control change occurred within that window.

| Project wallet | Required authorization during the contest | Common NBDCOH… key included? |
|---|---|---|
| Issuer NC7HKO… | 2 of 2 keys | No |
| Staging NADLLJ… | Ordinary single-key account | No; different public key |
| Distributor NC6JT7… | 3 of 6 keys | Yes |
| Development fund NA5JKI… | 3 of 6 keys | Yes |
| Education fund NDSTP4… | 1 of 6 keys | Yes |

The common key was a joint authorizer for distribution and development, and could technically authorize an education-wallet transaction alone. Different keys do not establish different human custodians. The education wallet’s complete returned three-record history contains **no outgoing transfer**; its one-signature threshold establishes capability, not exercised misuse. The issuer’s current 1-of-1 arrangement dates from October 2021 and cannot describe its 2019 state.

Exact initial conversions: [issuer, 14 February 2018](https://explorer.nemtool.com/#/s_tx?hash=17a3361ddc7091c5807596b268e28e8cc88f4d793672a0b6d1ce4877de792b93); [distributor, 9 December 2018](https://explorer.nemtool.com/#/s_tx?hash=3d459e1a7ea38c3078f369797be848fe85b969b6d02d7d5de8b510f20b944439); [development, 4 May 2019](https://explorer.nemtool.com/#/s_tx?hash=81cbdf1f4bca65ebb7a43f7457e148793035f8c6b1b5a43eaf866cad2968a3be); [education, 4 May 2019](https://explorer.nemtool.com/#/s_tx?hash=9dd108cb37478b4fe959e789816c2c9f11278fac69e39e31e603e71e5e03186a). Being assigned membership is distinct from signing the conversion: the common key neither initiated nor cosigned a control modification for these five wallets.

More directly, the common key supplied explicit cosignatures for **five outgoing project-wallet KID transfers**. It initiated none of these five transactions.

| Project source | Confirmed inclusion, UTC | Block | Exact transfer |
|---|---|---:|---|
| Distributor | 8 January 2019, 01:36:14 | 1,971,298 | [63d14a3d…](https://explorer.nemtool.com/#/s_tx?hash=63d14a3d3c156527559048ed8d80a6fad23f018c3f32b3ef6e87211e6d1eef22) |
| Development fund | 26 June 2019, 08:47:33 | 2,213,169 | [277e86f0…](https://explorer.nemtool.com/#/s_tx?hash=277e86f0486b61633bcaa2723672ac998f9df7262af3619fdbfe838c588cee31) |
| Development fund | 26 June 2019, 08:48:08 | 2,213,170 | [7ee2de0c…](https://explorer.nemtool.com/#/s_tx?hash=7ee2de0c36c4da1d0e0ddfec77f85e3bae3e557606272b1d664bfafb90822cc6) |
| Development fund | 26 June 2019, 08:48:09 | 2,213,171 | [137082b8…](https://explorer.nemtool.com/#/s_tx?hash=137082b8ae733de7d78b7ae3ba9e7423723033a9d9d3ed6510688df9a170e1f8) |
| Development fund | 16 July 2019, 04:56:54 | 2,241,470 | [668848f8…](https://explorer.nemtool.com/#/s_tx?hash=668848f801960ed636f3bd31cdface6b2b28018b463f09a52cbf990420d179a0) |

These are demonstrated uses of project spending authority by the key associated with Laura. The human-attribution limit in §4 still applies: the records do not independently identify the person supplying each signature. All five project authorizations precede the key’s **26 August 2019** addition to the signer set of the old Foundation operating wallet NBFOUND…; the Foundation authorizations followed. Persistent overlapping membership does not make the observed actions simultaneous.

No outgoing KID transfer from these **five core project wallets** falls within 2–11 June. This bounded result does not erase the previously documented separate June 11 transfer from the common signing account itself. That account is outside this five-wallet set, and the transfer does not establish a contest winner. Financial key control also does not identify who controlled the contest inbox, approved its requirements or accessed submissions.

**Verification:** terminal histories contain issuer 780 records, staging 5, distributor 12, development 9 and education 3. Replaying every returned control event reproduces all five current signer sets and thresholds. The four initial conversions and five relevant transfers each match their complete raw transaction object exactly once in their stated primary-node block, with separate explorer cross-checks. This reconstructs node-served historical events; it is not an independently operated consensus replay or local cryptographic verification of every signature.

**5. Does Foundation money reach the KID project?**

**Updated finding:** the regional screen below establishes payments to a KID-associated account, but their purpose remains unknown. It would now be incorrect to generalize the earlier zero-match result to all Foundation accounts.

The old Foundation operating account returned **584 unique records** through terminal pagination. Of these, **545 outgoing transfer records** were screened against the **14 identified addresses in the original NEM memorandum’s KID register**. **No direct recipient match was found.**

That result specifically limits the proposed direct-funding narrative. It does not exclude transfers through other wallets, unrecognized project accounts, exchanges, bank payments, reimbursed expenses, staff time, sponsorship or contracts. It does not establish that a grant never existed. It is not a comprehensive audit of every NEM-related entity or every indirect route.

The major reserve allocation was separately rechecked against primary history and exact transaction records:

| Transfer | Verified XEM amount | Reference |
|---|---:|---|
| Initial reserve transfer | 25,000,000 | [f79a6dc…](https://explorer.nemtool.com/#/s_tx?hash=f79a6dccf674a253b11534e451864e2eacd215fb44ab8be75c5866024dbfb992) |
| Second allocation, source part one | 41,764,164.163755 | [b3f6f68…](https://explorer.nemtool.com/#/s_tx?hash=b3f6f68c36c7cb4dde0b1863896a7d40ab2551127cab025d215dc47f8f1b3386) |
| Second allocation, source part two | 38,235,835.836245 | [0ac2ed1…](https://explorer.nemtool.com/#/s_tx?hash=0ac2ed1f1ea6e6fc529440bb50477bf0cd889253eb25ee9491fbac6ed58bb9de) |
| Later reserve allocation | 105,000,000 | [60f6de0…](https://explorer.nemtool.com/#/s_tx?hash=60f6de0abcafef1e09d2e366beedffc9b486106ab4b160da134dd2c11d07d1a9) |
| **Source allocation total** | **210,000,000** | Exact arithmetic; excludes internal forwarding |
| Later trustee transfer to new Foundation wallet | 35,000,018.45 | [c0f6080…](https://explorer.nemtool.com/#/s_tx?hash=c0f6080da5bb27400988bd9d8c9934978db670a3e8ac3c459fa1bdd6fb70e45c) |

The verified intermediate 80-million transfer forwards the second allocation; adding it again would double-count the same money. The final 35-million transfer concerns the remaining authorization, with 18.45 XEM additional residual value. These are institutional wallet movements, not proof of subsequent off-chain expenditure or KID financing.

**New chronology correction:** block inclusion was checked for eleven selected transactions. Four funding entries use creation dates in the memoranda that differ from confirmation dates:

| Event | Creation date in memorandum | Confirmed block inclusion, UTC |
|---|---|---|
| Initial 25 million | 7 March 2019 | **8 March 2019, 10:03:19**, block 2,056,090 |
| Second tranche, part one | 18 June 2019 | **19 June 2019, 06:59:19**, block 2,203,056 |
| Second tranche, part two | 18 June 2019 | **19 June 2019, 12:04:06**, block 2,203,363 |
| 105 million | 10 December 2019 | **11 December 2019, 08:53:34**, block 2,453,144 |

The Foundation control-addition and later control-change dates remain 26 August and 16 October 2019. This correction affects chronology, not transfer amounts. The exact outer signature appeared once in each of the eleven asserted blocks; that is a record-consistency check, not a separate cryptographic signature audit.

The Foundation’s own January/February 2019 statements acknowledge weak accountability, high spending and acute operating pressure. That supports institutional management concerns. It does not allocate responsibility for particular transactions to Laura. [Community statement](https://forum.nem.io/t/nem-foundation-message-to-the-community/21753); [Foundation response](https://forum.nem.io/t/nem-foundation-update-a-response-to-questions-and-anticipated-questions/21776).

A further personally attributable statement appears in the March 2020 ROI discussion: Laura asserted that all expenses were reflected and defended the applicability of Singapore privacy law. This is a specific reporting assurance that could be tested against the accounts. This review has not established it was false. Although its former Google Docs link is unavailable, **all nine embedded report pages were recovered and visually checked in the fourth pass**. The report’s main totals, regional-liability explanation and Council credits were already described in the supplied NEM memorandum; they are now independently verified against that embedded source, not newly audited private accounts. [ROI discussion and embedded report](https://forum.nem.io/t/nem-foundation-2019-roi-report/24550).

The report names neither KIDLetCoin nor Thailand and supplies no matching invoice references, staff-time assignments or KID grant. Page 5 attributes regional costs collectively to 2019 redundancies and outstanding 2018 liabilities. That provides a relevant aggregate explanation but does not reconcile the twelve regional payments in §5a. Generic Foundation wallet and education expenditure cannot be assigned to KID without that bridge. [Regional explanation, page 5](https://forum.nem.io/uploads/default/8ef505ed46ebf3eacb2593ce5f6e89b89d6035f9).

One accounting presentation issue requires correction: page 4’s narrative assigns **43%** to technology development, while its chart and page 3’s table show **US$1,848,635**, approximately **27.3%** of the reported **US$6,770,159** total. A different grouping or denominator might explain this, but the report does not visibly reconcile it. The supplied memorandum repeats 43% without flagging the discrepancy. Treat that percentage as an unreconciled management statement, not a verified expenditure share or proof of fraud. This report contains no attached auditor’s opinion. [Expense table, page 3](https://forum.nem.io/uploads/default/4b5860a1db38f534e16768d4c97eff22b0fcdc7a); [chart and narrative, page 4](https://forum.nem.io/uploads/default/eae16ef658f64b36e37e772810e268956d54e70f).

The KID transfer index was also independently retrieved and replayed. It still returns **28 unique transfers**, with creation dates from 9 December 2018 to 16 July 2019. Starting from the memorandum’s 21-million initial supply, the indexed movements conserve that amount with no negative running balances. Gross movement is 60,901,115.523681 KID because the same units moved repeatedly; it is not a sales total or additional issuance. Eleven transfers are at most 30 KID. Two exactly 20-KID records represent a transfer followed by forwarding, not two established contest winners. No recipient was identified as a child. [KID mosaic index](https://explorer.nemtool.com/#/mosaic?ns=kidlet&m=kid).

Both queried public nodes reject the current `kidlet` namespace, and current namespace/mosaic queries return no active definition. This supports inactivity/expiry of the original NIS1 asset, without independently fixing its exact expiration date. Historical ledger positions are not current spendable balances. The 2020 renewal and 2021 control changes are administrative records, not new KID transfers. Index consistency does not establish exhaustive historical coverage or replay the effects of namespace expiration/redefinition. [Namespace query](https://nem01.symbol-node.com:7891/namespace?namespace=kidlet).

**5a. New regional-account evidence: twelve payments with accounting references**

In April 2019, the Foundation president’s public response expressly identified `NASEACHB4GDLNLC2EGU7KQB3T2WY23UWTNVUSLKH` as the former Southeast Asia regional account. The thread discusses restructuring and continuing contractual liabilities. This supplies a contemporaneous institutional attribution of the exact sender, rather than an inference from its address name. It does not explain each individual payment. [Foundation response identifying the account](https://forum.nem.io/t/how-long-will-nf-fund-each-region/22488/2).

Fresh terminal pagination returned **276 unique records** across three pages of 100, 100 and 76. Screening **241 outgoing transfer records** against the same fourteen-address KID register found **twelve positive-XEM payments**, all to NBDCOH…, the account later documented as a shared KID/Foundation signer. None matched the other thirteen register entries, including the five core KID issuer, staging, distribution, development and education wallets. The outgoing set includes 240 nonzero-signature records and one later zero-signature record; all twelve matches have nonzero signatures.

The dates below are block inclusion dates in UTC. Their messages contain accounting references, with no KID or grant description.

| Settlement date | Accounting reference | Transaction |
|---|---|---|
| 2 April 2018 | `SEA/2018/04/04` | [c5a1f4ad…](https://explorer.nemtool.com/#/s_tx?hash=c5a1f4ad908bc5369a94d8eb0b8c114ef23b7488891d0f4d2b8bc39b6e9d98ff) |
| 2 May 2018 | `SEA/2018/05/04` | [2ed3f764…](https://explorer.nemtool.com/#/s_tx?hash=2ed3f7641c2b250411ace074f73a922fba5e0c977cecc83ad22f7d0b5914ff50) |
| 4 May 2018 | `SEA/2018/05/07` | [eea5afcb…](https://explorer.nemtool.com/#/s_tx?hash=eea5afcb38af846b23be953af89094bc045c88be795a2f2a823a4d4430ff38a7) |
| 5 June 2018 | `SEA/2018/06/04` | [61ad8fb0…](https://explorer.nemtool.com/#/s_tx?hash=61ad8fb01cf16baae8313bda9fbbe662298e705f2b6badee48dee83fc6ffef70) |
| 8 July 2018 | `SEA/2018/07/03` | [49025cd0…](https://explorer.nemtool.com/#/s_tx?hash=49025cd0e4395158046b70ad795bbf4fa08a4fa4dbbf6b08243901925ec0bfde) |
| 7 August 2018 | `SEA/2018/08/04` | [a776693d…](https://explorer.nemtool.com/#/s_tx?hash=a776693d646f0fd382841995155469eeea88d575ee9e472e66332acfb236c8b5) |
| 11 September 2018 | `SEA/2018/09/03` | [1704d90c…](https://explorer.nemtool.com/#/s_tx?hash=1704d90c693a14e21f84a405355981a19a5df63ad7e5b52f861ddbab0fdd1930) |
| 8 October 2018 | `SEA/2018/10/02` | [1e5710d2…](https://explorer.nemtool.com/#/s_tx?hash=1e5710d2b56ff65481b322415311a283e99fa1f71c40642a993c39a91789efe8) |
| 12 November 2018 | `SEA/2018/11/02` | [a2acc94f…](https://explorer.nemtool.com/#/s_tx?hash=a2acc94f4a12a23f1eb1c63d12b21f2e9db8900e3dfcc54bcbc04b2c16f540ec) |
| 14 December 2018 | `SEA/2018/12/05` | [f0fd899a…](https://explorer.nemtool.com/#/s_tx?hash=f0fd899a5ad729c24068ff5521fa7c589d537b1333190962b6e629bd88722114) |
| 13 February 2019 | `SEA/2019/02/01` | [b9b1e216…](https://explorer.nemtool.com/#/s_tx?hash=b9b1e216d270e216652d02eba9fc12f0cbce67689c96c4efd41c7778eaebb890) |
| 6 September 2019 | `SEA/2019/09/01` | [0137e342…](https://explorer.nemtool.com/#/s_tx?hash=0137e3422de11d75421bbc5fb04bac739d3aa81e3b9850a11b046e82942a36a5) |

All twelve were cross-checked against explorer records and exact block contents, including matching transaction details and outer signatures. This is record corroboration, not separate cryptographic signature validation. The recipient key did **not** initiate or appear as a cosigner on these payments. Eleven predate its 26 August 2019 addition to the signer set of the old Foundation operating wallet NBFOUND…; the same dual authority must not be assumed throughout the payment period.

**Meaning:** a recurring institutional payment relationship is established. The account’s human custody and the purpose of the receipts remain unresolved. Ordinary compensation, contracting or reimbursement are possible explanations. No KID grant, onward expenditure on KID, self-authorization or diversion is established. The twelve exact references now provide concrete targets for ledger, invoice, payroll/contract and expense documentation. No unrelated personal holdings or onward personal transactions were traced.

**6. The wallet security finding survives, with sharper boundaries**

At pinned Kidlet commit `d8c2e9b3a364734a17bead61f5549672dfb73de6`, fingerprint enrollment stores the actual wallet password in ordinary Ionic Storage. Login retrieves it and invokes a console log with that value before fingerprint authentication. The code therefore defeats separation between the wallet’s encrypted material and its retained password within that storage system. Device encryption and app sandboxing may still limit access. [Settings](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/settings/settings.ts); [login](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/login/login.ts); [wallet storage](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/providers/wallet/wallet.provider.ts).

The exact Ionic Storage 2.1.3 implementation adds no encryption around its get/set delegation. The fingerprint plugin can return protected output, but the application retains the original password instead. This confirms an implementation weakness; it does not show collection of fingerprint images/templates. [Ionic implementation](https://github.com/ionic-team/ionic-storage/blob/e6806200f2e7d525faf4c488c32a87c037fbaa26/src/storage.ts); [fingerprint plugin v1.3.6](https://github.com/NiklasMerz/cordova-plugin-fingerprint-aio/blob/v1.3.6/src/android/Fingerprint.java).

**New lineage finding:** Kidlet advertises fingerprint authentication as an added feature, and the path is absent from both reviewed upstream NEMPay baselines, including the last upstream commit preceding Kidlet’s upload. Scrutiny therefore belongs on this customization and its review process, rather than assuming every defect was inherited unchanged. This comparison does not identify who commissioned or approved it. [Kidlet README](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/README.md); [earlier upstream login](https://github.com/dgarcia360/NEMPay/blob/058ac65829420964a8e5017670f4c75cba08ed93/src/pages/login/login.ts).

Other independent checks:

| Issue | Result and limit |
|---|---|
| Password logging | Source call confirmed. Actual Android logcat exposure is unproved: Cordova 6.4.0 routes console messages through DEBUG while defaulting its native threshold to ERROR. |
| Network transport | Exact dependency package integrity matched the lockfile. Default nodes include 13 HTTP entries, one duplicated, and one HTTPS entry; a historical node is also HTTP. This shows a transport-security weakness in defaults, not observed private-key transmission. |
| Asset naming | Balance filtering ignores namespaces, but transfer confirmation and signing preserve the full asset identifier. Display confusion is supported; on-chain counterfeit equivalence is not. |
| Contacts and contest fields | Reviewed contact storage is local. No automatic upload path for the contest’s names, ages, location, video or email was identified. Absence in this source is not a forensic examination of a deployed app. |

Sources: [Cordova console handler](https://github.com/apache/cordova-android/blob/rel/6.4.0/framework/src/org/apache/cordova/engine/SystemWebChromeClient.java), [Cordova default logging](https://github.com/apache/cordova-android/blob/rel/6.4.0/framework/src/org/apache/cordova/CordovaActivity.java), [pinned dependency lock](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/package-lock.json), [network provider](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/providers/nem/nem.provider.ts), [transfer confirmation](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/transfer/transfer.ts), [contact provider](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/providers/contact/contact.provider.ts).

**Production boundary:** the public repository has eleven commits dated 8–9 June 2018. Its app identifier is `com.Kidlet.app`; the contest’s Play link names `com.kidletcoin.app`. No authenticated APK, release-signing certificate or reproducible source-to-binary connection was recovered. The located source cannot establish the exact behavior of the distributed app. Nor does it establish Laura’s code authorship, knowledge of defects or access to users’ credentials. [Commit history](https://github.com/baconbkk/Kidlet/commits/master/); [app configuration](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/config.xml).

**6a. Product coverage gap: the quiz beta and the missing release build**

The official channel’s January 2019 wallet-demo description links the same `com.kidletcoin.app` Play package. Its June 22 upload instead announces a KID Quiz Game App beta demonstrated on June 20. The located wallet source has no identified quiz, scoring or parent/child task workflow. These descriptions establish different promoted functionality; they do not prove two separately distributed binaries. No authenticated quiz source, package, download or service architecture was recovered. Consequently, findings about the wallet’s local contact handling cannot establish how the quiz handled information. [Wallet demonstration page](https://www.youtube.com/watch?v=64uyb1se5OY); [quiz beta page](https://www.youtube.com/watch?v=S2B4UIKd0jI).

The fifth pass recovered the wallet demo’s exact **22 January 2019, 15:04:51 UTC capture**, including its original player metadata. It announces Google Play availability and links `com.kidletcoin.app`; the full decoded description exactly matches the current version. This supplies contemporary evidence of the project’s release announcement and package linkage. It does not prove successful installation, a particular APK’s behavior, source-to-binary identity, the earliest release date or Laura’s release approval. The recovered author is the project channel, without a named human publisher. Additional quiz watch/short/embed/feature variants and a Play locale/query-order variant returned no captures in the tested 2018–2022 indexes. [January 2019 wallet announcement](https://web.archive.org/web/20190122150451id_/https://www.youtube.com/watch?v=64uyb1se5OY&gl=US&hl=en).

A retrieved Play screenshot in THE STANDARD’s June 2019 article visibly shows the fingerprint-authentication control and matches the source’s login layout. Its SHA-256 matches the image in the supplied memorandum. That corroborates the represented feature and identical retrieved image bytes, without proving the distributed binary used the defective storage path or establishing independent historical chain of custody. [Article screenshot](https://thestandard.co/wp-content/uploads/2019/06/Kaede-Takenaka-2.jpg); [pinned login template](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/login/login.html).

The second pass checked repository branches, config history, releases, forks, issues and PRs; it recovered no package-rename or source-to-release mapping. Public archive/package searches recovered no APK. Some third-party app pages refused access, which is an access limitation rather than proof they never held the app. No application was installed or executed.

The six currently listed project videos and five recovered descriptions supplied no identified contest-results announcement. Full audiovisual contents were not reviewed, and removed, unlisted or embedded entries are not excluded. Empty caption responses and failed storyboard retrievals cannot support claims about what appeared in the videos.

**Fourth-pass site-asset check:** the 2021 and 2022 archived homepages explicitly configure WordPress.com page-view and external-link statistics. A recovered 2022 script confirms paths for site/page identifiers, referrer and performance information, plus external-link targets. This establishes configured website analytics; no visitor records or successful transmissions were observed. It does not establish child-specific tracking, quiz answers, contest submissions or Laura’s control, and cannot be backdated to June 2019. The same HTML explicitly describes MonsterInsights as unconfigured with no UA code, so plugin presence is not evidence of Google Analytics operation. The recovered theme scripts/styles supply no quiz backend or named commissioner. All inspection was static, without executing scripts or contacting tracking beacons. [2021 homepage](https://web.archive.org/web/20210726013520id_/https://kidlet.io/); [2022 homepage](https://web.archive.org/web/20221210005341id_/https://kidlet.io/); [exact 2022 statistics script](https://web.archive.org/web/20221210005245id_/http://stats.wp.com/e-202249.js).

**7. Who re-registered kidlet.io?**

The re-created registration is confirmed. The buyer’s identity is not public in the records retrieved.

| Field | Verified public record |
|---|---|
| Creation | 17 June 2025, 10:10:51 UTC |
| Expiration | 17 June 2026 |
| Registrar | Namecheap, Inc., IANA 1068 |
| Registrant name | Redacted/empty |
| Public registrant-country field | VN: Vietnam, Asia; actual buyer's location unverified |
| Registry's privacy-service label | Privacy service provided by Withheld for Privacy ehf; see current-provider discrepancy below |
| Registry status | Transfer prohibited and pending delete |
| Registrar status | Also includes redemption period |
| DNS on 5 September 2026 | A, NS and MX queries returned NXDOMAIN |
| Laura or former-project connection | Not established |

Both the registry and registrar were queried directly. Their status sets differ, so an exact deletion countdown or claim of a newer post-report registration would be unsupported. A last-changed timestamp does not by itself identify an ownership change. [Registry RDAP](https://rdap.identitydigital.services/rdap/domain/kidlet.io); [registrar RDAP](https://rdap.namecheap.com/domain/kidlet.io); [DNS MX query](https://dns.google/resolve?name=kidlet.io&type=MX).

**Country, company and jurisdiction:** fresh public registry and registrar responses checked at approximately 07:53 UTC on 5 September 2026 both retain `cc: "VN"` in the entity assigned the registrant role. The same field was already present in the earlier saved records: it was newly noticed, not newly changed. It denotes Vietnam, in Asia. It does not authenticate a person's physical location, identify a Vietnamese company or establish where the registration order was placed. Both services can reproduce the same underlying entered data, so their agreement is not independent verification of the buyer's location. The actual buyer's name/company is undisclosed. [Registry record](https://rdap.identitydigital.services/rdap/domain/kidlet.io); [registrar record](https://rdap.namecheap.com/domain/kidlet.io).

| Distinct role | Country / continent | Established jurisdictional fact and its limit |
|---|---|---|
| Recorded registrant | Country entry Vietnam / Asia | Actual human/company identity, domicile and incorporation jurisdiction unknown. |
| Current registrar: Namecheap, Inc. | United States / North America; Delaware corporation | Its current registration agreement §29 selects US/Arizona law and Arizona courts for relevant registrar disputes, with exceptions. This is not a ruling on the original project's privacy obligations. |
| .io registry: Internet Computer Bureau Limited, trading as NIC.IO | United Kingdom / Europe; company 03226374 | NIC.IO registration terms §22 select English law and proceedings in England for that agreement. |
| Historical privacy-service identity shown by RDAP: Withheld for Privacy ehf | Historically Iceland / Europe | Privacy-service identity is not buyer identity or buyer-country evidence. |
| Privacy provider's current own legal description: Withheld for Privacy LLC | United States / North America; Delaware | Current registrar-partner terms select Delaware law/courts. Transition date and applicability to this domain's 2025 registration were not established. |

Namecheap's Delaware corporate identity is stated in an [official US court document dated 11 March 2026, first-page caption](https://cdn.ca9.uscourts.gov/datastore/memoranda/2026/03/11/25-3358.pdf); the unrelated dispute in that document has no asserted connection to KIDLetCoin. Its own [registration agreement §29](https://www.namecheap.com/legal/domains/registration-agreement/) provides the Arizona contract clauses. The registry's identity is corroborated by [IANA](https://www.iana.org/domains/root/db/io.html), [Companies House](https://find-and-update.company-information.service.gov.uk/company/03226374) and [NIC.IO terms §22](https://nic.io/terms.htm).

The privacy-provider discrepancy is material: Namecheap's [March 2021 announcement](https://www.namecheap.com/blog/domain-privacy-is-changing-at-namecheap/) described an Iceland-based service, whereas the provider's [current terms](https://withheldforprivacy.com/terms-of-service.html) and [privacy statement](https://withheldforprivacy.com/privacy-statement.html) identify a Delaware-based US entity. No transition date or domain-specific service contract was recovered. Neither version identifies the beneficial purchaser, and neither makes Iceland or Delaware the governing jurisdiction of KIDLetCoin's contest.

IANA associates the `.io` delegation with the British Indian Ocean Territory; that territorial label does not locate the purchaser. The registry's [allocation rules §3.1](https://nic.io/rules.htm) permit second-level applicants from any legal jurisdiction. Hosting and submission-storage locations remain unknown.

These findings concern the later registration record. The original project's registrar, registration-country record and registration contract have not been recovered. Current Namecheap sponsorship also does not independently prove who served as registrar at the precise instant of the June 2025 creation. No registration record examined ties the reacquirer to Laura. Registrar, registry and privacy-service forum clauses neither establish nor exclude Canadian jurisdiction over the original operating activity.

A stale third-party observation from June 2025 reports Sedo parking. Sedo is the reported parking provider, Namecheap the registrar, and Withheld for Privacy the privacy service. None is identified as the buyer. Privacy and default parking are ordinary offered services, not independent proof of concealment. [Historical third-party observation](https://website.informer.com/kidlet.io); [Namecheap privacy explanation](https://www.namecheap.com/security/domain-privacy-service/); [default parking explanation](https://www.namecheap.com/support/knowledgebase/article.aspx/9250/46/how-can-i-point-my-domain-to-namecheap-parking-page/).

An original-project homepage survives in a December 2022 capture. Together with the later creation date, that supports a dropped/re-created registration, but does not identify the reacquirer. Domain ownership does not automatically convey the former provider’s stored emails, website databases or wallet keys. A later operator could create a prospective misdelivery risk by enabling mail for stale addresses; actual later delivery or historical-inbox access was not established. [2022 homepage](https://web.archive.org/web/20221210005341id_/https://kidlet.io/).

The historical project’s submission address should not be treated as a verified present-day contact route.

Fresh public-activity checks also found the historical Google Play package unavailable (404), six old public channel uploads with the latest dated 22 June 2019 UTC, and the known repository’s latest commit/push still in June 2018. No authenticated recent project announcement was located in the bounded search. These are checks of the known public project, not proof that private development or activity under another identity is impossible. Indexed business-name results were inconclusive and are not a formal registry clearance. [Official channel](https://www.youtube.com/channel/UC2sui4vaP9sWpevdKbytQUA/videos); [latest public upload](https://www.youtube.com/watch?v=S2B4UIKd0jI); [historical Play listing](https://play.google.com/store/apps/details?id=com.kidletcoin.app); [repository metadata](https://api.github.com/repos/baconbkk/Kidlet).

**7a. Recovered chronology beyond 2019**

The second pass recovered a **2 July 2020 post from @kidletcoin, preserved by Wayback that same day**. The project account says pandemic disruption affected activity, shares a blockchain curriculum and plans to put it on the website. This establishes public project communication at least through that date. It does not identify the human author, prove curriculum authorship, establish continued app use or demonstrate sales. A claim that all project activity ended in 2019 is too broad. [Same-day archived project post](https://web.archive.org/web/20200702154157id_/https://twitter.com/kidletcoin/status/1278708267678654464).

The linked curriculum was subsequently recovered at its pinned **30 June 2020 commit** and read across all 111 PDF pages. Its cover and metadata name no author; it contains no KIDLetCoin or Laura Takenaka/Walsh credit. Its NEM chapter is general technical/history material. References to journalist Laura Shin are unrelated. This authenticates the shared educational material without connecting its authorship or commissioning to Laura’s September 2019 curriculum plans. [Pinned curriculum PDF](https://gitlab.com/free-blockchain-curriculum/free-blockchain-curriculum/-/blob/e9d3f30f10ab953471b952dbb9624106d0c0d129/blockchain-curriculum.pdf).

Six further original project status archives were recovered. The latest, dated **24 September 2021**, contains only **“Test”** and carries the same project account ID as earlier captures. It establishes a later post, with no evidence of product use, relaunch or the human custodian. The returned desktop archive set contains no recovered contest administrator or result counts. The fifth pass successfully rechecked the `www` variant and obtained the same seven-record index byte for byte; the mobile variant still timed out. Coverage remains incomplete. [Same-day 2021 status capture](https://web.archive.org/web/20210924052233id_/https://twitter.com/kidletcoin/status/1441203877777338371).

An expanded archive index returned **94 distinct URL keys** for 2018–2023, not 94 complete pages or every historical capture. Newly recovered 2022 post/category/tag sitemaps contain generic blog paths, without an identified contest-results post or operator declaration. The post bodies were not recovered. Original-project homepages from 2021 and 2022 have changed software asset-version references; automatic or hosting-provider updates remain possible. These do not establish resumed business. [2022 posts sitemap](https://web.archive.org/web/20221210102045id_/https://kidlet.io/wp-sitemap-posts-post-1.xml); [2021 homepage](https://web.archive.org/web/20210726013520id_/https://kidlet.io/); [2022 homepage](https://web.archive.org/web/20221210005341id_/https://kidlet.io/).

An exact **8 December 2023** capture of `jagatslot.kidlet.io` contains unrelated gambling promotion and search links. This establishes different content in the domain space before the June 2025 re-created registration. It identifies neither the publisher nor the date original control ended. Ownership transfer, delegated use, expiration or compromise cannot be distinguished from this record. **There is no evidence attributing that content to Laura or the original project.** It supplies no evidence of access to historical children’s emails. [Archived subdomain](https://web.archive.org/web/20231208224250id_/https://jagatslot.kidlet.io/).

**8. Historical legal relevance**

**Collecting children’s information without legally required notice or consent can be unlawful. This review has not established that the contest was lawful.** Consent, security and collection-limit violations can arise independently of a sale, hack or predatory motive. Personal liability and jurisdiction still require evidence about the relevant activity and responsible operator. The FTC’s April 2019 i-Dressup action separately addressed consent and security failures, illustrating that these were enforceable duties at the time. [Contemporaneous FTC explanation](https://www.ftc.gov/business-guidance/blog/2019/04/i-dressup-data-security-mess).

| Framework | Historically supportable position |
|---|---|
| Thailand | The substantive PDPA framework was deferred after the 2019 Act and subsequently postponed through May 2022. Do not label the June 2019 contest a breach of later-effective Thai PDPA duties. Later handling requires separate analysis, including transitional provisions. |
| Singapore | PDPA duties and specific child-data guidance existed before the contest. Relevant Singapore collection/use/disclosure must be established; incorporation is not the sole possible connecting factor. |
| U.S. COPPA | The 2013 rule was in force. Commercial purpose, child-directed/actual-knowledge tests and the U.S. connection require evidence. Overseas accessibility alone does not settle scope. |
| Canada | The OPC had already adopted a presumptive parent/guardian-consent position for under-13s, with maturity-appropriate consent for older youth. Meaningful-consent guidance enforcement began in January 2019. Relevant Canadian commercial activity and territorial connection must be established. |

Sources: [Thai Act](https://www.mdes.go.th/law/detail/3577-Personal-Data-Protection-Act-B-E--2562--2019-), [2021 postponement decree](https://www.etda.or.th/getattachment/33f1c767-6339-41da-8309-97569ed4ef4a/PDPA-2021.aspx), [Singapore guidance, August 2018](https://www.pdpc.gov.sg/-/media/files/pdpc/pdf-files/legislation-and-guidelines/final-advisory-guidelines-on-pdpa-for-selected-topics-31-august-2018.pdf), [historical COPPA rule](https://www.federalregister.gov/documents/2013/01/17/2012-31341/childrens-online-privacy-protection-rule).

Canadian historical sources: [OPC 2016–17 report, consent and children](https://www.priv.gc.ca/en/opc-actions-and-decisions/ar_index/201617/ar_201617/); [December 2018 commencement announcement](https://www.priv.gc.ca/en/opc-news/news-and-announcements/2018/an_181221/). Foreign operation is not an automatic exemption: the OPC’s 2015 Globe24h findings examined a real and substantial Canadian connection. Equivalent case-specific connections have not been established for KID. [Historical cross-border findings, paragraphs 60–62](https://www.priv.gc.ca/en/opc-actions-and-decisions/investigations/investigations-into-businesses/2015/pipeda-2015-002/).

The 2018 Singapore guidance already discussed children’s understanding, representative consent where appropriate, undue influence and additional safeguards. Singapore’s 2018 Taekwondo decision demonstrates contemporaneous enforcement concerning proven disclosure of children’s data; its facts and outcome must not be assigned to this project. [PDPC decision](https://www.pdpc.gov.sg/-/media/files/pdpc/pdf-files/commissions-decisions/grounds_of_decision_singapore_taekwondo_federation_220618.pdf).

A lack of recovered submissions limits findings about actual receipt and harm, but does not categorically eliminate prospective privacy duties: COPPA’s definition of collection includes requesting or encouraging submission, and applicable consent duties can arise before receipt. The unresolved questions remain jurisdiction, operator identity and the actual arrangements. [2013 rule and explanation](https://www.federalregister.gov/documents/2013/01/17/2012-31341/childrens-online-privacy-protection-rule).

**8a. Specific potential violations raised by the contest design**

For a covered under-13 commercial service, the historical COPPA provisions identify three distinct inquiries:

| Potential issue | What would need establishing here |
|---|---|
| Required parental notice/consent before collection, §§312.4–312.5 | Applicable operator and territorial scope; gathering of covered information; whether the required process existed and was followed |
| Excessive information required for participation or a prize, §312.7 | Which fields were mandatory and whether each was reasonably necessary for this activity |
| Security and retention, §§312.8 and 312.10 | The actual protection, access, use, retention and deletion arrangements for any received information |

These rules were already in effect in 2019. Consent does not automatically excuse unnecessary collection or inadequate protection. The definition covers online contact information and media containing a child’s image or voice. The contest’s age range expressly includes under-13s, while the recovered instructions do not show a parental step. [2013 rule, §§312.2–312.10](https://www.federalregister.gov/documents/2013/01/17/2012-31341/childrens-online-privacy-protection-rule).

This makes the consent inquiry concrete. Nevertheless, the FTC’s explanation describes requesting/encouraging as means of gathering information; it does not establish every element of a violation from an invitation where actual gathering remains unproved. The required process must be ready before gathering, not retrofitted after children respond.

The narrow exception for using online contact information to respond once to a child does not authorize the entire proposed bundle and later publication. An educational label also does not decide commercial status. The original funding and income claims warrant that inquiry. [FTC FAQ, one-time contact and operator-scope explanations](https://www.ftc.gov/business-guidance/resources/complying-coppa-frequently-asked-questions), read consistently with the historical rule rather than later amendments.

Age could serve eligibility, email communication, video judging and a wallet address payment. Those plausible purposes must be evaluated before calling each field unnecessary. The purpose and required precision of location are particularly useful questions. A generic location request does not prove collection of a home address or precise geolocation; a video does not invariably reveal a face or voice.

**Personal responsibility:** evidence that Laura determined the requested fields, approved the contest, controlled processing or directed those responsible would connect her to the alleged practices. Evidence of active project participation in section 3a gives a stronger basis for investigating that role, without supplying those missing records. Incorporation is not a prerequisite to every form of operator responsibility. The 2019 i-Dressup complaint named individual officers and alleged their direction, control or participation; it provides an example of conduct-based attribution, not a finding about Laura. [FTC complaint, paragraphs 8–10 and 19–22](https://www.ftc.gov/system/files/documents/cases/i-dressup_complaint_ecf_4-24-19.pdf).

There is no present basis here to assign a fine, sentence or definitive personal offence to Laura. Evidence that she designed, directed, controlled or participated in the disputed processing would materially change the assessment. A corporate title alone does not supply that evidence.

**8b. Canada: specific acts, historical duties and possible offences**

**Canadian law did not categorically prohibit every collection of information about children. It did impose duties that could make the proposed processing unlawful. Quebec also already had a statutory offence covering unlawful collection itself.** The analysis must separate a privacy contravention, a provincial penal offence and a Criminal Code offence. A sale of information, completed hack or predatory motive is not a prerequisite to every privacy breach. Conversely, requesting a video and contact information does not establish a particular offence or the responsible adult.

This section uses the [PIPEDA consolidation effective 1 April–20 June 2019](https://laws-lois.justice.gc.ca/eng/acts/p-8.6/20190401/P1TT3xt3.html). Quebec's [1 February 2021 pre-Law-25 consolidation](https://www.legisquebec.gouv.qc.ca/fr/document/lc/p-39.1/20210201) verifies the relevant earlier duties through its amendment histories; it is not presented as a June 2019 capture. The available contest description is authenticated by December 2022, with a video upload dated June 2019. That distinction remains relevant to proving the precise date of any act.

**Which Canadian law could govern?** For the federal route, establish covered commercial activity and a sufficient Canadian connection. Quebec's private-sector Act instead uses an enterprise concept; it should not be reduced to PIPEDA's commercial-activity test. The Quebec route separately requires a sufficient territorial connection to Quebec; the OPC's federal jurisdiction analysis does not itself establish that connection. An educational or nonprofit label does not settle either question. The historical [Civil Code article 1525](https://legisquebec.gouv.qc.ca/en/showdoc/cs/ccq-1991/20140501) includes organized economic activity in its enterprise definition. The applicable federal/provincial division and exemptions must then be resolved for the actual processing; the table below gives alternative provisions, not an assumption that both govern every act.

The OPC's [2015 Globe24h findings, paragraphs 61–62](https://www.priv.gc.ca/en/opc-actions-and-decisions/investigations/investigations-into-businesses/2015/pipeda-2015-002/) explain its real-and-substantial-connection approach to foreign operations. For this project, useful evidence would concern where the contest was operated and controlled, the markets actually targeted, relevant transactions and reliable aggregate participant geography. No Canadian entrants or Canadian processing operation were established in this review. English instructions, a foreign registrar, a Canadian associate or a later domain-country entry do not individually resolve jurisdiction.

| Documented act or proposed step | Relevant historical provisions | Application to the recovered record and decisive gap |
|---|---|---|
| Inviting ages 8–18 to send identifiable entries | PIPEDA §6.1 and Schedule 1, 4.3: meaningful consent | Ages 8–12 are expressly included. The public description shows no parent-first process. Determine the complete notice and consent workflow used before any covered collection; the description alone does not establish that no other process existed. |
| Linking name, age, email, location, video and wallet | PIPEDA 4.4 and 4.3.3; Quebec §5: necessary collection | The bundle is expressly requested. Which fields were actually required and received? Location has no stated eligibility purpose in the recovered text; precision and operational need remain unknown. |
| Giving only brief contest/payment/publication instructions | PIPEDA 4.2 and 4.8; Quebec §8: purposes and handling information | The purpose is partly described, but the visible text does not identify the complete handling arrangements or access route. Archived policy bodies were not recovered. This is a visible notice gap, not proof that every required notice was absent. |
| Featuring selected videos on the project channel | PIPEDA 4.3 and 4.5; Quebec §§13–14: authorized use/disclosure | Public dissemination of an identifiable entrant's video would need a valid basis. Publication is announced in the invitation, so it was not wholly undisclosed there. Actual publication, identifiability and the scope/validity of consent remain unproved. |
| Receiving and keeping submissions in the project's published submission mailbox | PIPEDA 4.7; Quebec §10: appropriate/reasonable safeguards | Investigate the actual historical service, access rights, forwarding, protection and retention. The generic inbox name is not evidence of public access or plaintext storage. A completed breach is not necessary to a safeguards finding, but an inadequate protection arrangement must be established. |
| Deploying the located wallet's password-storage/logging behavior | PIPEDA 4.7; Quebec §10, if the relevant processing/controller is covered | The source defect is concrete. The missing production-build link, local-device architecture and controller relationship prevent treating it as proof that the contest inbox or a central child-data database was exposed. |
| Keeping or reusing entries after the contest | PIPEDA 4.5; Quebec old §§12–14: retention/use limits and purpose-related consent | Obtain evidence of actual later holding/use/disclosure and its basis. A surviving upload or re-created domain does not prove records were kept, passed to a new owner or reused. Old Quebec §12 must not be rewritten as today's general destruction requirement. |

The statutory references above are to the historical [federal consolidation and Schedule 1](https://laws-lois.justice.gc.ca/eng/acts/p-8.6/20190401/P1TT3xt3.html) and [pre-reform Quebec text](https://www.legisquebec.gouv.qc.ca/fr/document/lc/p-39.1/20210201). The applications and alternative data-minimization questions are this review's analysis of the recovered project record, not findings already made by a regulator.

**Consent and necessity are separate questions.** The OPC's [October 2017 guidance on online educational tools](https://www.priv.gc.ca/en/about-the-opc/what-we-do/international-collaboration/international-privacy-networks/international-privacy-sweep/2017_result/) states its position that, barring exceptional circumstances, under-13 consent must come from a parent or guardian; older youth need maturity-appropriate treatment. This is contemporaneous regulatory interpretation, not an express age cutoff written into PIPEDA. The separate meaningful-consent guidance became subject to enforcement from [1 January 2019](https://www.priv.gc.ca/en/opc-news/news-and-announcements/2018/an_181221/).

Even sufficient consent does not end the inquiry. The OPC's [May 2018 §5(3) guidance](https://www.priv.gc.ca/en/privacy-topics/privacy-for-businesses/appropriate-handling-of-personal-information/collecting-personal-information-and-consent/consent/gd_53_201805/) examines sensitivity, genuine need, effectiveness, less intrusive alternatives and proportionality. Quebec's regulator had already applied necessity independently of consent: its [2017–2018 annual report, printed page 19](https://www.cai.gouv.qc.ca/uploads/pdfs/CAI_RAG_2017-2018.pdf?v=1705427364) describes an order to stop unnecessary rental-screening collection in Services d'enquêtes Oligny & Thibodeau, file 1008641. That administrative example is not a finding or conviction concerning this contest.

Applied field by field, the useful questions are concrete:

- **Age:** eligibility provides a plausible reason. Could an age band and appropriate adult verification achieve it? Collecting age is not automatically excessive.
- **Name and email:** entry management/contact provide plausible reasons. The instruction says name, not verified legal identity. Could a limited identifier and parent contact suffice for younger entrants?
- **Location:** no geographic restriction or location-dependent function appears in the recovered wording. What precision was requested and why? Country, town and home address are materially different; only the word location is proved.
- **Wallet address:** a receiving address serves the promised payment. Why collect it before selection from all entrants? Linking an identified child to an address is different from merely seeing an anonymous public address. No seed, password or private-key request appears in the contest.
- **Video:** judging requires content, but an educational explanation need not show a child. Was identifiable appearance necessary or optional, and was prospective public distribution explained in a way the relevant child/parent could understand?

The 20–30 KID reward does not cure unnecessary collection. It also does not automatically make consent coerced. The complete conditions and real process determine that question. Adequately explained consent can cover contemplated publication; a separate checkbox is not universally mandated by the cited historical provisions.

**When could this have been an offence?** Quebec's old [§91](https://www.legisquebec.gouv.qc.ca/fr/version/lc/P-39.1?code=se%3A91&history=20161104) covered collection, holding, use and disclosure contrary to the specified privacy divisions. Thus actual excessive collection by a covered enterprise could support a provincial penal allegation without an additional data sale or identity-theft theory. Old [§93](https://www.legisquebec.gouv.qc.ca/fr/version/lc/P-39.1?code=se%3A93&historique=20180524) addressed corporate directors/officers/representatives who ordered, authorized or consented to the offending act or omission. The underlying offence and the individual's participation still require proof.

PIPEDA's historical §28, by comparison, listed particular offences involving specified knowing noncompliance or obstruction; it did not turn every consent or safeguards contravention into an offence. Ordinary contraventions could lead through investigation and the statutory Federal Court process, including corrective orders and damages where established. No knowing breach-reporting failure or obstruction is established here. [Historical PIPEDA §§14–16 and 28](https://laws-lois.justice.gc.ca/eng/acts/p-8.6/20190401/P1TT3xt3.html).

The [OPC's 2012 Nexopia findings](https://www.priv.gc.ca/en/opc-actions-and-decisions/investigations/investigations-into-businesses/2012/pipeda-2012-001/) provide a pre-contest example of youth-related consent, disclosure and retention enforcement without making a sexual motive or data sale an element. That case had evidence of an operating service and actual users; it does not fill KIDLetCoin's factual gaps.

**A separate Quebec advertising question:** the published invitation itself warrants analysis under Consumer Protection Act §§248–249 if it was commercial advertising with the necessary Quebec connection. It expressly invites under-13 participation and encourages wallet adoption and branded educational content. The regulator's [2012 guide, including the statutory appendix](https://cdn.opc.gouv.qc.ca/media/documents/consommateur/sujet/publicite-pratique-illegale/EN_Guide_publicite_moins_de_13_ans_vf.pdf) covers online promotion and explains that educational presentation does not automatically remove commercial character. This route concerns advertising, so proving a child emailed an entry is not its central factual prerequisite.

Nevertheless, a free educational contest is not automatically commercial advertising. Establish the advertised goods/services or commercial organization, the Quebec-directed promotion, the actual publisher/authorizer and applicable exceptions. The historical [CPA §6(a)](https://www.legisquebec.gouv.qc.ca/fr/document/lc/P-40.1/20191001?langCont=en) also excludes relevant securities/derivatives transactions; classify the activity before stacking inconsistent legal theories. The historical consolidation was only partly available through official indexed passages, supplemented by the regulator's pre-2019 guide. No later fine increases or 2025 administrative-penalty scheme are applied here.

**Criminal Code offences require additional elements.** These are separate from the privacy duties above:

| Possible charge | Legal requirement | What this record supplies and what is missing |
|---|---|---|
| Fraud, §380 | Dishonest means causing economic deprivation/risk, with the required knowledge | The contest offered rewards, and interviews contain inconsistent store/readiness claims. Establish the operative representation, dishonesty when made, induced work/payment or other economic interest, resulting deprivation/risk and the accused's knowing participation. Failed plans alone do not establish these. [Historical provision](https://laws-lois.justice.gc.ca/eng/acts/C-46/section-380-20111101.html). |
| Identity theft, §402.2(1) | Obtaining/possessing identity information intending its use in an indictable offence involving fraud, deceit or falsehood | The invitation asks for identifying information. Receipt/possession, the responsible recipient and the specified criminal intent remain unproved. The version effective from 13 December 2018 governs this historical wording. [Applicable provision](https://laws-lois.justice.gc.ca/eng/acts/C-46/section-402.2-20181213.html). |
| Identity fraud, §403 | Fraudulent personation with a listed intent | No act of impersonating an entrant or using a child's identity as one's own is established. A name-to-wallet association is not itself personation. [Historical provision](https://laws-lois.justice.gc.ca/eng/acts/C-46/section-403-20100108.html). |
| Unauthorized computer use, §342.1 | Specified computer/password conduct, fraudulently and without colour of right | The located password-handling defect does not establish that anyone obtained actual credentials or services through such conduct. Actual deployment, the actor's conduct/authority and personal participation remain unresolved. [Historical provision](https://laws-lois.justice.gc.ca/eng/acts/C-46/section-342.1-20150309.html). |

Fraud is not confined to cash purchases: §380 also covers services. A knowingly sham reward or redeemability offer used to obtain valuable work could merit scrutiny if the requisite facts were proved. No submitted work, applicable bargain or deliberate nonperformance is established here. The Supreme Court's [R. v. Théroux, 1993](https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/992/index.do) recognizes economic risk without completed loss and explains that hope of eventual success does not excuse a knowingly dishonest act. That does not convert an optimistic forecast or ordinary project failure into fraud. Knowledge can be inferred from proved circumstances; direct admission is not necessary.

Similarly, some password possession/trafficking conduct under §342.1(1)(d) needs no completed intrusion. The source bug still does not prove fraudulent possession without colour of right. Publicizing content is also not automatically trafficking in identity information under §402.2(2), which has its own qualifying purpose/knowledge elements. Neither a missing hack nor a generic inbox establishes the answer to these offences.

Criminal territorial jurisdiction needs separate analysis. [Criminal Code §6(2)](https://laws-lois.justice.gc.ca/eng/acts/C-46/section-6.html) and [Libman v. The Queen, 1985, paragraphs 74–76](https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/79/index.do) direct attention to the offence's real and substantial Canadian connection. Libman involved Canadian operations and foreign victims: a Canadian victim is not invariably necessary. For this project, determine where the alleged deceptive communications, operations, access or other constituent acts occurred. Current domain-service jurisdictions and later personal connections do not establish those historical facts.

**What would connect Laura personally to a legal violation?** Her documented business-logic work, recruitment of helpers, wallet-release statements, curriculum involvement and associated signing activity provide substantial evidence of project participation. They do not identify who wrote the contest terms, controlled its inbox, approved the requested fields or decided on publication. Those are the missing links that matter legally: approvals, instructions, contracts, access/administration records or reliable testimony tying her to the disputed act. A director role in NEM Foundation is not automatically a director role in whichever person/entity operated KIDLetCoin. General project involvement cannot substitute for the participation required by the applicable offence provision; a proved direct actor can also be assessed on their own conduct.

For Criminal Code responsibility, [§21](https://laws-lois.justice.gc.ca/eng/acts/C-46/section-21.html) addresses commission and intentional assistance/abetting. Organizational attribution under [§22.2](https://laws-lois.justice.gc.ca/eng/acts/C-46/section-22.2.html) is a different question involving an underlying offence and a senior officer's role, fault and intended organizational benefit; it does not make every officer personally guilty. The shared key's actual cosignatures establish cryptographic authorization acts, while human custody and any transaction's alleged dishonest purpose need their own evidence. The twelve regional payments do not themselves prove a deceptive funding request or misuse of restricted funds.

**Timing materially affects present enforceability.** Quebec's express under-14 provision came into force on 22 September 2023, as confirmed in the regulator's [implementation recap, printed pages 101–102](https://www.cai.gouv.qc.ca/uploads/pdfs/CAI_ECredits_2025-2026.pdf?v=1778702218). It must not be backdated to June 2019. Earlier consent/capacity obligations still require their own analysis.

For historical Quebec privacy prosecutions, the pre-reform Act contained no special limitation in its penal sequence. The unchanged [Code of Penal Procedure article 14, shown in the March 2020 consolidation](https://www.legisquebec.gouv.qc.ca/fr/document/lc/C-25.1/20200317), generally allowed one year from commission unless another enactment provided otherwise. Discrete completed June 2019 conduct therefore faces a serious time bar to a fresh September 2026 prosecution, subject to properly applicable interruption/suspension rules. The later [privacy Act §92.2](https://www.legisquebec.gouv.qc.ca/fr/version/lc/P-39.1?code=se%3A92_2&history=20231125) introduced five years from commission; it should not be assumed to revive an expired proceeding.

The advertising route has its own [CPA §290.1 two-year limitation](https://www.legisquebec.gouv.qc.ca/fr/version/lc/p-40.1?code=se%3A290_1&historique=20251113), also a substantial problem for a solely 2019 completed act. The historical section was corroborated through official indexed text rather than a fully recovered 2019 body, so precise procedural advice requires that version and any applicable exception. Neither the continuing availability of an old invitation nor a later domain registration proves a new or continuing offence. Actual later processing would require separate dates, facts and law. A prosecution time bar is not a finding that the conduct was lawful, and it does not by itself decide civil or regulatory remedies.

**9. Corrections needed when using the original memoranda**

| Original wording or inference | Required precision |
|---|---|
| KID p.15 describes collection as occurring through email | Replace with solicitation through email; actual receipt is not established elsewhere in the same report. |
| KID pp.21–24 treats face and voice as part of the required bundle | Identify possible audiovisual exposure; do not claim the instructions mandated appearance on camera. |
| Missing safeguards treated as proven absence | Separate no recovered notice, unsuccessful archive retrieval and proven lack of a process. |
| Identity-to-wallet linkage treated as automatically public | Recipient linkage is distinct from public disclosure of that mapping. |
| NEM account entirely unattributed | Add the newly recovered name-bearing outgoing-message evidence, with civil-identity and custody limits. |
| One example of shared Foundation signing | Add 358 verified Foundation actions involving the common key; keep the additional nine incoming transactions separate and do not infer misconduct from signing alone. |
| An exact KID supply reconciliation proves complete transfer history | Conservation of supply does not independently prove index completeness; omitted ordinary transfers also conserve the total. |
| No activity after 2019 | A same-day archived project post establishes communication on 2 July 2020. Distinguish that from verified product use, later administrative ledger records and archived site captures. |
| No Foundation payments to any KID-associated account | Restrict the original zero-match finding to its operating account. The regional screen found twelve payments to the later shared signer; purpose and onward use are unresolved. |
| The wallet review covers every promoted product feature | Quiz functionality remains unaudited; separate packaging and its data handling were not established. |
| Password console call proves Android logcat exposure | Source call is confirmed; runtime output depends on platform/build configuration. |
| Recovered repository proves shipped-app behavior | Retain the app-identifier and missing-APK provenance boundary. |
| Current domain metadata identifies the old project or buyer | Registration continuity and holder identity are unresolved. Privacy, registrar and parking-provider identities are different. |
| Transaction creation dates equal confirmed settlement | Check block confirmation time for multisignature transactions; later cosignatures can move confirmation into the following day. |

The archived 2022 homepage was independently recovered with the same SHA-256 stated in the supplied KID memorandum. It contains links to `/privacy-policy/` and `/terms-conditions/`; their archived bodies were not recovered. Requests for June 2019 homepages redirected to a 2021 capture, which cannot authenticate 2019 safeguards. The archived author sitemap contains a Laura-named author URL, not a declaration of who administered contest data. [Author sitemap](https://web.archive.org/web/20221211065542id_/https://kidlet.io/wp-sitemap-users-1.xml).

A separate Common Crawl search checked nine selected indexes spanning 2018–2022. Eight returned no captures; the remaining index held only homepage and robots responses captured on 27 June 2022 as HTTP 406 Mod_Security errors. Exact public WARC ranges were retrieved and their payload hashes matched the index. No consent or operator text was recovered. This documents archive coverage limits, not proof that policies never existed, deliberate concealment, or who configured the server.

The fifth pass removed capture collapsing for original-site navigation records. The returned 46 rows reveal repeated 2018–2019 homepage redirects, without additional policy/operator bodies. Exact May 25 and June 25, 2019 replay requests explicitly redirect to the **26 July 2021** capture. Availability queries for the originally linked privacy, terms, author, feed and public REST page paths returned empty snapshots. This closes a query-method gap while preserving the central limit: later footer links and empty archive results cannot establish the 2019 safeguards or their absence.

**10. Evidence that would materially change the assessment**

The next meaningful evidence concerns operation and responsibility:

1. The adult/entity responsible for the contest inbox and channel, and who approved the entry requirements and publication decisions.
2. Contemporaneous notices, parental permission workflow, aggregate entrant/winner counts, access arrangements and retention/deletion records. Any examples should be redacted to protect children.
3. The distributed wallet APK and quiz build/service records, signing certificates, release history and review/approval records linking source to deployment.
4. The ledger and supporting documents for the twelve exact regional payment references, plus any KID-related staff-time, sponsorship or promotional approvals, declarations of interest and recusals.
5. Authorized evidence explaining the shared signer’s institutional mandate and human custody at the relevant dates.
6. The legal operating entity, adult funding agreements, actual merchant contracts and redemption/order records that would establish whether the advertised rewards economy operated.

Without those records, the strongest conclusion is **substantial involvement and serious unresolved oversight questions**. The deeper review supplies concrete new evidence of association and engineering weakness. It does not complete a chain from Foundation funds to child-data receipt, improper use and Laura’s personal liability.

**Verification coverage and reproducibility**

Both supplied PDFs were read across the review team. Source checks included current contest-page metadata/description; archived original-project pages and exact policy paths; public NEM statements and role records; pinned application/dependency code; registry and registrar RDAP; DNS; and public NIS1 account/transaction responses. This was a factual and source-code review, not a production-app penetration test, independent revalidation of the entire blockchain, complete tracing of indirect funds, or a new audit of private accounts.

Blockchain pagination was deduplicated by transaction hash, multisignature wrappers were inspected for their inner transfer, and recipient screening used the fourteen KID-register addresses rather than informal explorer names. Signature-field participation was counted from the shared public key in outer-signer or explicit-cosignatory positions; the Foundation-action subset additionally required the inner transaction signer to be the old Foundation account. Returned public-node data, exact explorer records and selected block contents were compared; no separate standalone cryptographic verification of every signature was performed. The corroborating nodes share a domain/operator family and must not be described as three independently controlled institutions. Endpoint completeness remains a limit even when pagination terminates.

The entire 2018 election was not independently recomputed in this pass. Its original report calculations were assessed for interpretation and evidentiary limits, while personal-role and control claims received fresh source checks. The 28-record KID index was independently retrieved and replayed as an index-consistency check, not as a full namespace-lifecycle replay. The 210-million source allocation and specified final trustee transfer were independently rechecked; every claimed off-chain expenditure was not.

The second regional screen covers returned records created between June 2017 and November 2021, but nonzero-signature outgoing transfers end in May 2020. Its later zero-signature record is not treated as evidence of a human-authorized regional operation. All twelve matched payments were compared with exact blocks. Terminal pagination limits results to the endpoint’s returned history; it does not prove complete coverage of every regional, institutional or off-chain account.

Additional source recovery included the original e27 interview archive, NEM’s project article, organizer publicity, a same-day 2020 project-account post, app-listing imagery and the expanded domain archive inventory. Thai-language interpretations are working translations, not certified translations. Current e27 profile templates contain unrelated placeholder funding material; that material and unrelated similarly named businesses or tokens were excluded. No production quiz data collection was observed.

The third pass added Laura-attributed project-caption metadata, precise dates for her milestone and wallet statements, public educational-outreach posts and a historical consent/collection-limit analysis. No newly recovered source identifies the contest’s adult approver or mailbox custodian. The repository’s `blockchaintoken.tech` author field is inherited upstream metadata and must not be used as independent attribution of a KID developer agency or operator.

The fourth pass recovered a next-day archived institutional article, six additional project status archives, all nine embedded ROI report pages, five linked website assets and the pinned 111-page curriculum. Five project-wallet control histories were replayed with terminal pagination, and nine exact historical blocks were checked. Common Crawl was checked separately from Wayback. The ROI topic’s server metadata records creation on 10 March 2020 and an update on 14 March; its displayed March 14 date is not treated as an unqualified first-publication date. Image OCR was checked visually. None of these new sources identifies who handled contest submissions.

Selected fourth-pass source fingerprints identify the retrieved bytes, not unchanged content throughout every historical period:

| Source | SHA-256 |
|---|---|
| IB article, exact 28 September 2019 archive capture | `8ad6c561918a8c3b9408d6e6dded694e304fd4b8c9cf9722bf388a71fcf52c09` |
| ROI report closing page, original embedded image | `07d3aad98152f54ab6105caf439c6e872dfd16df3027dabb03923f6d388c97fd` |
| Pinned June 2020 curriculum PDF | `9f81e9a98fd8203b8c424d620f3307899850f3a4c05b78acad3ffe2e74f0b396` |
| Recovered December 2022 statistics script | `82d0aae1e7b8cfc0574d6548d1f35096f5e4310321aa964ff3fdb46c4d12e302` |

The fifth pass inspected exact URL variants and uncollapsed navigation indexes, decoded archived YouTube metadata without executing scripts, and compared complete descriptions with the previously preserved current versions. It also used Arquivo.pt full-text results to recover original institutional timeline HTML. Two other Arquivo.pt results contained contemporaneous links to known press coverage, rather than new operator evidence. Internet Archive item-metadata search returned no matching items; this was not a complete search inside every archived document. Availability queries for the personal Instagram and LinkedIn posts returned no snapshots, while the e27 directory query selected the already known 2023 dynamic template. Blank/template directory fields were not treated as genuine company funding or staff records. No newly recovered archive identifies the contest inbox operator.

| Selected fifth-pass source | SHA-256 |
|---|---|
| Complete wallet-demo HTML, 22 January 2019 capture | `8de634336169bea6b5ca85888eb9f12e79b6601928603485fe4685a8da38dcad` |
| Complete contest HTML, 10 December 2022 capture | `524c174c0baffeddb9856c53d5bf3886ced6c950495ad40fe6f973ed9225a8d3` |
| Decoded wallet description, identical at the checked 2019/2026 dates | `2ea52a32639d0896eee0ad152b1b6401b318e04e9299eae40530cd453bc3cd29` |
| Decoded contest description, identical at the checked 2022/2026 dates | `589e279af0d419a83cac42a3d4d5522b36ce9004b5d69874e6a37331fdf87105` |
| Original NEMofficial timeline, Arquivo.pt 16 November 2019 capture | `a66110d668754cc268a7be1b5cd025cd78127a6360364d2b1b09bf3adf4bad54` |
| Official Medium article, 8 November 2020 capture | `4d265c9520386c31cef115291c3104f108ccdfd545321d9603eafe77f09d9d7a` |

The Canadian-law follow-up checked contemporaneous federal consent guidance, historical federal provisions, pre-reform Quebec duties and amendment histories, the regulator's 2012 advertising guide, and the Supreme Court's Théroux and Libman decisions. Historical Quebec page retrieval was intermittent; the advertising section expressly identifies its indexed-text/full-guide reliance. No current under-14 rule or later penalty scale was applied to the 2019 contest. Language verification used already preserved player metadata without inspecting entrants' media. Fresh domain checks separated the registrant-role country field, registrar incorporation/contract, registry contract and privacy provider's current legal description; none identifies the later buyer or historical child-data storage location.

| Selected follow-up public record, 5 September 2026 | SHA-256 |
|---|---|
| Registry RDAP, retrieved 07:53:00 UTC | `051d003f41ea9cba9e31871a796c35c0261aa71c7e9a6ca568386b2a80787645` |
| Namecheap RDAP, retrieved 07:53:00 UTC | `4d99b60581c8e33bf47b2c4172e7cdff2ae3f25b8525d603c51a263f432c5717` |
| Withheld for Privacy current terms | `af4b7447b545ef21c09f71f2ca4035ec7edaa9c61116a7b4106c9c88a4fd2e55` |
| NIC.IO current registration terms | `698a5c9eaf7dafca574ede3794f4f44a45dca958113fb67d22e22004d319faf5` |

Input fingerprints:

| Supplied PDF | SHA-256 |
|---|---|


No child submissions were obtained or exposed, and no attempt was made to identify unnamed child wallet holders. No emails, regulator complaints or other third-party messages were sent.
