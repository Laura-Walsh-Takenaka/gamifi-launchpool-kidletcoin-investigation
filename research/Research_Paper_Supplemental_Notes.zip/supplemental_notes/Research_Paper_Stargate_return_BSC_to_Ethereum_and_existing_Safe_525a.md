# Research Paper — Stargate return: BSC to Ethereum and existing Safe 525a

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The selected BSC bridge transfer has an exact destination match. On 24 January 2023, `0x412869e0cda40f3a1972d2c09cd23545d1b0709a` transferred 224,223.10984 BUSD through Stargate on BSC. Ethereum delivered 224,088.575976 canonical USDC to the same address 107 seconds later. That address sent the entire matching USDC amount to the previously identified Safe `0x525a234de4eee961de7a7fabbf43a0ddcc289494` after another 9 minutes 48 seconds.

| UTC time, 24 January 2023 | Action | Transaction |
|---|---|---|
| 11:52:24 | 224,223.10984 BUSD from 412869 to BSC Stargate pool 98a573 through router 4a364f | [BSC source](https://bscscan.com/tx/0xa8398e337b7a49a037e3b09ce49cabe3aa6d79230397c0a12b770ca6b520fc5c) |
| 11:54:11 | 224,088.575976 canonical USDC from Ethereum Stargate pool df0770 to 412869 | [Ethereum destination](https://etherscan.io/tx/0xb79355d2c3b22cd6647f2b82437e92f8377dd6ed8a7393e0ba515a913e48e715) |
| 12:03:59 | 224,088.575976 USDC from 412869 to Safe 525a | [Onward transfer](https://etherscan.io/tx/0xa240bf5b3f74f7981fe7dc59dbf8e1e297701cde4000bc5e1ec70e89a25e8a22) |

## Exact protocol join

The source `Packet(bytes)` was decoded independently from the BSC receipt. Its packed fields match the destination `PacketReceived(uint16,bytes,address,uint64,bytes32)` event:

- LayerZero source chain 102, destination chain 101; these are protocol identifiers, distinct from BSC/Ethereum EVM chain IDs 56/1.
- Source bridge `0x6694340fc020c5e6b96567843da2df01b2ce1eb6`.
- Destination bridge `0x296f55f8fb28e498b858d0bcda06d955b2cb3f97`.
- Nonce **5826** (`0x16c2`).
- Recomputed payload Keccak-256 **`0xbad3f796439260728abbb75c202cfed608154cac4951e9b99742365f40ca9a51`** exactly matches the destination event.
- Destination transaction calldata includes the exact source block hash `0x5bebb331361e4a38d94b986a14e9db1468387cd26f79bee46ace6d3633b9e902`. Its proof bytes also contain the entire 596-byte source packet, which includes a 544-byte payload.

This match relies on packet identity and hash equality, not temporal proximity. The proof's Merkle validation was not independently re-executed; the destination transaction is successful according to the explorer's transaction and event data.

## Amount reconciliation

The source receipt records **224,223.10984 BUSD actually transferred**. The destination Transfer event records **224,088.575976 USDC delivered**. Their nominal-unit difference is **134.533864**, exactly equal to the destination `SwapRemote` fields of **127.807171 protocol fee + 6.726693 destination fee** in six-decimal shared units. Native gas and bridge message charges are separate. These are token quantities, not a historical dollar valuation.

The onward transfer is checked against both signed-call inputs and the canonical USDC Transfer log, and its sender is 412869. The canonical-token index has six records and no next page: four positive transfers in two equal inbound/outbound pairs, plus two zero-value events. The January 24 credit and payment are adjacent positive entries. Zero-value entries involving lookalike address `0x525e841de26234b19332823e1ac43925a9089494` are excluded from financial links; this is a different address from Safe 525a.

## Interpretation and scope

This closes a traceable return route into the existing Safe and supplies context for its capital movements. It does not identify the source of all capital in that Safe, an exchange customer, or a human operator. No amount is attributed to GamiFi in this subtask, and this transfer is not a matched Tornado withdrawal.

Two selected Ethereum transactions and their complete log pages were retrieved through Blockscout v2, with canonical USDC token filtering used for discovery. Ethereum RPC receipts and historical `balanceOf` calls were not independently retrieved. The source BSC RPC transaction and receipt were already obtained by the parent investigation. The 20 checks in `findings.json` pass. `analyze.py` reproduces the protocol join and amount checks from preserved raw files.

## Primary protocol references

- [LayerZero v1 UltraLightNodeV2.sol](https://github.com/LayerZero-Labs/LayerZero-v1/blob/main/contracts/UltraLightNodeV2.sol): packed Packet format and receipt's payload hash.
- [LayerZero v1 interface](https://github.com/LayerZero-Labs/LayerZero-v1/blob/main/contracts/interfaces/ILayerZeroUltraLightNodeV2.sol): event signatures.
- [Stargate Bridge.sol](https://github.com/stargate-protocol/stargate/blob/main/contracts/Bridge.sol): swap payload decoding and forwarded recipient.
- [Stargate Pool.sol](https://github.com/stargate-protocol/stargate/blob/main/contracts/Pool.sol): remote swap event fields.
- [Stargate mainnet contract register](https://stargateprotocol.gitbook.io/stargate/developers/contract-addresses/mainnet): chain IDs 101/102 and all four bridge/pool addresses match.
- [Circle USDC contract register](https://developers.circle.com/stablecoins/usdc-contract-addresses): canonical Ethereum contract `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48`.

Source bodies, retrieval dates and hashes are preserved in *Historical file: source_manifest.json*. They interpret the encoding; no independent recompilation of historical deployed protocol runtimes is claimed.
