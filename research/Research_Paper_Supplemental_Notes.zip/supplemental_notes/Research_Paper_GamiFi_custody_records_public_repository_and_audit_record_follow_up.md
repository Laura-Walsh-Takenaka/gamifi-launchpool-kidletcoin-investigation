# Research Paper — GamiFi custody records: public repository and audit-record follow-up

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Checked 6 September 2026. This is a public business-record review. No account was accessed, no person was contacted, and no signing address was assigned to a human from a developer's name or profile.

**The additional public material does not identify a human key custodian. It adds two precise audit-document leads and substantially expands the checked repository coverage.** The previously established project-to-ProxyAdmin link is corroborated, not newly discovered.

## New audit-document identifiers

| Public development record | Verified dates and status | What the visible code record contains |
|---|---|---|
| [GamiFi PR 13, “fix audit report”](https://github.com/sheandev/gamifiContracts/pull/13) | Created 4 January 2022 at 10:32:45 UTC; closed 23 February 2022 at 04:21:10 UTC; API `merged_at` is null. Latest visible PR-head commit is `0d7acec2bc0f33a786dd1afd6e4079cc5f86fcf7`, dated 7 January 2022. | Changes to MemberCard, Staking, the Vendor example and related tests. No description, report attachment, auditor name, report number or wallet-custody assignment appears in the inspected PR metadata/conversation. Closure without merger of this PR does not establish whether equivalent changes were deployed by another route. |
| [GamiFi PR 25, “Update code for audit”](https://github.com/sheandev/gamifiContracts/pull/25) | Created 28 March 2022 at 11:04:14 UTC and merged at 11:04:32 UTC. Change commit `0e93729c1f7189ab7b6f5b458ed4bd824118193c`; merge commit `be5aeec1bf9dd577febc3696086e00ae1b3d43af`. | Six changed files: MemberCard, Staking45d, Staking60d, Staking90d, antiBot and multisigWallet. Neither a named auditor nor a report/engagement identifier is supplied. The Launchpool vesting file is not one of this commit's changed files. |

The logical records to locate are the underlying January/March audit engagement, complete report and revisions, scope/commit hashes, customer entity, delivery correspondence, remediation acceptance and deployment approval records. These public references show audit-related development language. They do **not** verify that PeckShield performed an audit, prove the scope of any audit, or authorize the later November transfers.

PeckShield's complete current `publications` repository tree was retrieved at commit `37558e095a7c82c9f4f8db4a84af313ed5eba67c`: 498 entries, with `truncated: false`. Searching its paths for GamiFi, Alphabit and Launchpool found only an unrelated Xterio Launchpool report. No GamiFi-named report was located in that current catalog. This is not proof that an unpublished, privately delivered, removed or differently named audit never existed. [Primary catalog](https://api.github.com/repos/peckshield/publications/git/trees/master?recursive=1).

## Expanded key-custody coverage

Exact case-insensitive searches covered these five addresses:

- Approval signer: `0x538a8b615e98e87d025c4336be44e4b8588277c7`
- Withdrawal signer: `0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9`
- Former withdrawal-Safe owner: `0x7e0135da76bb6cdb35ac5f1342808925e3ef7445`
- Transaction executor: `0x343cebd1e7d1a6838cd8b82f6238b29ad78e235e`
- Current sampled common administrator: `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`

The GamiFi review covered **143 reachable commits and 384 unique file blobs**, including the 115-commit main history, other fetched branches/tags and all 34 advertised public pull-request heads. It also checked all 34 public PR metadata records; the public issue-comment and code-review-comment endpoints each returned zero comments, with no pagination continuation. None of the five exact addresses was found in the scanned file contents or those conversation records. No matches for the additional terms PeckShield, Alphabit, custody, handover, Rooney or Takenaka were found in the scanned file contents. The byte hashes and Git object identifiers are retained in `public_repo_history_scan.json`.

The latest fetched GamiFi commit is dated **24 August 2022**, before the September CEO announcement and the September/November on-chain actions. That cutoff limits what this source can establish about later operational handovers. This coverage does not include private repositories, private communications, deleted unreachable objects or superseded force-push versions outside the fetched refs.

The deployment configuration loads the deploying account from an environment variable, and transaction tasks similarly load an administrative signing account at runtime. These are implementation settings, not a public register of the person or company holding the key. [Pinned configuration](https://github.com/sheandev/gamifiContracts/blob/4e7c1c6f68466bb62c68e77ed3beafeb0bbe65b6/hardhat.config.js).

Five public repositories under the [Launchpool organization](https://github.com/Launchpool), which self-links launchpool.xyz, were also checked across their cloned reachable branches/tags: Smart-Contracts, API-Token, LPOOL_Arbitrum, merkle-distributor and merkle-distributor-new. None contained a match for the five keys. Their individual counts, source refs and hashes are in `launchpool_repo_history_scans.json`. The two distribution forks share substantial upstream history, so their commit/blob totals must not be described as entirely distinct evidence. The Olympus fork and unadvertised/private material were outside scope.

## Existing project-administration link corroborated

The [GamiFi deployment manifest at commit `3d2f970…`](https://github.com/sheandev/gamifiContracts/blob/3d2f970b3533e98dd39a0198dfe607b623946159/.openzeppelin/unknown-56.json), dated 19 April 2022, records both:

- ProxyAdmin `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475`, creation transaction `0x528547faadbe40961e8a90e6506f6093d9271a1863824ab1885d26440e6e94e7`.
- Launchpool vesting proxy `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb`, creation transaction `0xe42d218340a4a53c8ed687bb8ac26a4cc9d07e4d0af061a6abd3b8f347ff4c66`.

This matches the administration infrastructure already established in *Historical file: FINDINGS.md*. The manifest names contracts and deployment transactions; it does not identify the human custodian of the later signing keys. A commit timestamp is source metadata, not by itself proof of the date on which a public reader could first access the file.

Launchpool's [5 January 2021 announcement](https://launchpool.medium.com/launchpool-egalitarian-regulatory-compliant-investing-adc5908adbc9) identifies Alphabit and other supporting funds, and Alphabit's [current portfolio](https://alphabit.fund/portfolio/) includes Launchpool. These business associations do not establish custody of a GamiFi signing key or the authority for a particular withdrawal. No public mandate, custody contract or key-handover record bridging those facts was located here.

## Boundary and evidence files

The remaining key questions still require the dated key-assignment register, mandates, handover records and transaction-specific instructions already itemized in the main report. The audit PR identifiers add a way to locate technical engagement and deployment records. They do not supply the missing business authority or human identity.

`custody_provenance.json` contains compact verified metadata; selected patches preserve the actual code differences; `public_fetch_provenance.json` records successful and failed retrievals. Current gamifi.gg returned unrelated content and was excluded from historical project evidence. No Cayman bank account, bank beneficiary or personal receipt by Laura was established in this lane.

For packaging, use only the files listed in `deliverable_manifest.json` and this findings file. Exclude cloned repository subdirectories, which contain large unrelated source/distribution data.
