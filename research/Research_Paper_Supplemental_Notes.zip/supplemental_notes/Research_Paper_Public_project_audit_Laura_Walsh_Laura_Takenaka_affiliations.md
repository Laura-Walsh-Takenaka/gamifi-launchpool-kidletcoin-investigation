# Research Paper — Public project audit: Laura Walsh / Laura Takenaka affiliations

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

**Later Cardano correction.** The validated Cardano review resolves the apparent budget-allocation and cohort-size discrepancies through the approved milestone records. Payment tranches are not spending categories; twenty selected companies and eighteen graduates are reconciled. Earlier unresolved-budget or missing-delivery wording must be read with that correction.

**Reviewed: 5 September 2026.** Scope: MegaFans, Nativz/Ireland Esports Leagues/Nemesis, Techstars/Cardano Founder Catalyst, Kaskade Finance, and the previously mentioned historical GamiFi role.

This is a critical review of public claims, documents and delivered activity. It distinguishes documented defects, commercial weaknesses and unresolved questions. It is not an accounting audit, penetration test or finding of personal misconduct. No people were contacted, purchases made, wallets connected, or private participant information inspected.

## 1. MegaFans: material inconsistencies in historical offering documents

**Priority: high for document reconciliation. The offering records are from 2024.**

The Republic campaign displays a **$400,000 allocation/maximum**. Its June 25, 2024 private placement memorandum (PPM) instead specifies a **$40,000 Regulation D maximum**, calculated as 400,000 tokens at $0.10. The PPM describes expected delivery 30 days after final agreement processing; the linked token purchase agreement (TPA) specifies three days. These are discrepancies affecting the amount offered and delivery expectations. The PPM is a summary qualified by the definitive documents, so this comparison establishes inconsistent disclosure, not an actual contractual default. [Campaign](https://republic.com/megafans), [PPM, printed pp. 7–10](https://republic.com/documents/9987?view=preview), [TPA, PDF p. 3](https://uploads.republic.com/p/offerings/security_attachments/original/000/010/004/10004-1719345900-f13c893d37d6ef54e9a1dedc70542cfa0fabe4f1.pdf)

The TPA also describes an unlock one year after release, while Exhibit A uses one year after purchase. Those starting points require reconciliation. An unsigned public template does not establish what any particular investor signed or received. [TPA, main terms and Exhibit A](https://uploads.republic.com/p/offerings/security_attachments/original/000/010/004/10004-1719345900-f13c893d37d6ef54e9a1dedc70542cfa0fabe4f1.pdf)

Republic now records the campaign as withdrawn and says subscriptions were refunded. Its page retains an unfilled token-name placeholder and inconsistent issuer/form labels. The PPM explains a BVI company and a related California IP company: the existence of two entities is therefore explained, not itself suspicious. [Campaign status](https://republic.com/megafans), [PPM, printed pp. 6 and 23](https://republic.com/documents/9987?view=preview)

There is also a current product-maintenance question. The linked US iOS listings show latest binary releases on March 24, March 30 and April 5, 2023, respectively. These dates do not rule out subsequent backend changes. The current listings are rated 18+; this review provides no basis to describe these apps as openly soliciting children. [Candy Boo](https://apps.apple.com/us/app/candy-boo-esports-tournament/id1447419350), [Crash n Win](https://apps.apple.com/us/app/crash-n-win/id1503172280), [Tunnel Tournament](https://apps.apple.com/us/app/tunnel-tournament/id1503582224)

Candy Boo and Crash n Win link to an **Appic Studio** privacy policy. It does not explain that business's relationship to MegaFans or clearly cover MegaFans tournament-wallet, prize and KYC processing. This is a disclosure-fit weakness; the actual data flows were not inspected. [Linked privacy policy](https://appicstudio.com/privacy-policy.html)

**Evidence needed:** reconciled final offering documents and version history; the actual investor agreement if a transaction is disputed; current software/support records; controller and processor responsibilities. Laura's advisory/investor listing does not establish that she drafted these documents, controlled the issuer or received adviser tokens.

## 2. Nativz: admitted commercial setback, delivery changes and document defects

**Priority: high for business viability; medium for document and consent review.**

The CEO's January 22, 2026 annual review acknowledges that **Office Showdown did not succeed commercially in 2025**. It reports no capital raised that year, presented as a deliberate choice. This qualifies the same review's positive language about workplace demand and the Company Series launch: demand, event delivery and commercial success are different measures. It also openly describes Nemesis as a lightweight product built on Challengermode's engine. That is a disclosed dependency, not evidence of falsely claimed ownership. [2025 review](https://www.nativzgaming.com/p/2025-in-review)

An April 16 update moves the next Company tournament to Winter 2026 after two pilots, while prioritising the Schools pilot. The Schools homepage still advertises a forthcoming 2025/26 pilot. These records support execution risk and stale launch information, not a conclusion that every company or school activity stopped. The Company site separately advertises an alumni summer event and recordings. [April update](https://www.nativzgaming.com/p/esports-olympics-to-enc-iel-stepping-forward-making-choices-and-more), [Schools](https://schools.irelandesportsleagues.com/), [Company Series](https://company.irelandesportsleagues.com/)

The terms identify Nativz as operator but section 8.2 requires permission from **EFL Digital**, without explaining that entity's role. This is a concrete drafting inconsistency. [Terms, updated July 27, 2025](https://www.nativzgaming.com/terms-of-use)

The April 4, 2026 privacy policy automatically adds subscribers of individual series publications to the umbrella IEL newsletter, citing legitimate interests. However, the site also displays a consent checkbox for newsletters, offers unsubscribe controls and requires consent for third-party direct marketing. The actual question is whether each signup clearly covers the combined mailing purposes. Irish DPC guidance generally requires consent for electronic marketing, subject to a limited customer exception; the policy alone cannot establish whether a particular email breached those rules. [Privacy policy](https://www.nativzgaming.com/privacy-policy), [DPC guidance](https://www.dataprotection.ie/en/faqs/direct-marketing/consent-explicitly-required-all-cases-electronic-direct-marketing)

**Counterevidence:** the May 30 finals report provides champions, scores and recordings. The collegiate operation delivered real events. School FAQs include supervision commitments and allocate responsibilities to schools. Laura appears on the official adviser list; no reviewed source assigns her the operational decisions above. [Finals report](https://www.irelandesportsleagues.com/p/collegiate-lan-finals-delivered-relive-the-weekend), [Parents FAQ](https://schools.irelandesportsleagues.com/parent-faqs), [Team](https://www.nativzgaming.com/our-team)

**Evidence needed:** segment revenue and costs, revised pilot outcomes, service dependencies, actual signup text and consent logs held by the controller. Newsletter subscription is not evidence that a child is the recipient.

## 4. Techstars/Cardano: completed program; payment-schedule reconciliation remains an open question

**Priority: medium for grant-document clarity. Several initial suspicions were resolved.**

The official Catalyst record marks the grant complete and records **1.3 million ADA distributed**. Its original proposal and completed milestones use different payment allocations: core delivery is labelled 80% in the narrative and 30% in the completed schedule. The original six-month project estimate became a ten-month administrative schedule. This is a request for the approved amendment/reconciliation history. Milestone payments are not actual expense accounting; neither the percentage change nor the elapsed period establishes diverted funds or an overlong teaching program. [Official grant record](https://projectcatalyst.io/funds/13/cardano-partners-growth-and-acceleration/techstars-will-help-cardano-builders-grow-their-businesses-to-drive-cardanos-adoption)

The final report, dated February 27, 2026, was successfully retrieved. It explains that **20 companies were selected and 18 completed graduation requirements**, resolving the apparent discrepancy with 18 showcase presenters. It lists **Laura Walsh among the mentors**, independently substantiating that role. It reports a ten-week program, 12 masterclasses and 447 scheduled mentor meetings. These are program-reported results, not independently audited outcomes. They substantiate delivery while leaving longer-term founder revenue, survival and investment impact for later evaluation. [Final report — publisher milestone record](https://milestones.projectcatalyst.io/projects/1300182/milestones/6)

The dedicated program-information URL returned 404, although dated announcements and the final report remain available. This is a maintenance issue, not evidence of a fictitious cohort. Founder Catalyst's official description distinguishes this education program from equity-taking accelerators. No reviewed record gives Laura grant-budget authority or establishes a specific September 2026 assignment. [Original announcement](https://www.techstars.com/blog/program-news/techstars-and-cardano-foundation-launch-new-founder-catalyst-program), [Program description](https://www.techstars.com/founder-catalyst)

## 5. Kaskade Finance: current continuity unclear; funding disclosure incomplete

**Priority: high before relying on it as a current operating project.**

The former official domain, kaskade.finance, is advertised for sale on a domain marketplace. That verifies a public listing, not ownership, sale completion, corporate closure or a loss of investor funds. The newest visible entry on the official Medium timeline is September 28, 2024. Together these create an unresolved support and continuity question. Direct-fetch failures were not counted as proof of an outage. [Domain listing](https://expireddomains.com/domain/kaskade.finance), [Official publication channel](https://medium.com/@KaskadeFinance)

Its March 11, 2024 company release calls the financing pre-seed in the title and seed in the body. It names more than 40 investors but discloses neither total proceeds nor valuation or instrument. An investor count cannot establish funded runway, and the separately advertised campaign reward budget is not the capital raised. [Company release](https://www.accessnewswire.com/newsroom/en/banking-and-financial-services/kaskade-finance-closes-successful-pre-seed-round-841039)

The incentive design rewards trading volume. The resulting review question is whether liquidity and genuine demand persist after rewards end. It is not evidence of wash trading. A partner reported prior trading volume and LP fees exceeding incentives; Scroll announced the platform live in August 2024. These sources defeat an assertion that it never delivered its launch. [Partner campaign](https://deficollective.org/blog/kaskade-campaign-launch/), [Scroll launch](https://scroll.ghost.io/kaskade-x-scroll/)

**Attribution:** Laura's reported role ended in March 2024; a contemporary podcast confirms her historical CMO/founding-team role. Later domain and operating conditions cannot be attributed to her without further evidence. [Profile](https://ca.linkedin.com/in/lauralwalsh), [March 8, 2024 interview](https://www.moneyneversleeps.ie/farcaster-digital-identity-decentralized-social-media/)

## 6. GamiFi: historically acknowledged pause, after CEO succession

**Priority: historical project-performance issue, not a current accusation.**

GamiFi's October 3, 2022 update announced reduced activity and no IDOs for the time being, prioritising its GMI token and rebuilding. This is direct evidence of a pause in its core launchpad business, not merely a stale website or market-price inference. The September 1 announcement had already named Eleanor Rooney as Laura's replacement. The successor announced the pause. [October update](https://gamifi-launchpad.medium.com/gamifi-update-f8d6326f1780), [CEO succession](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147)

Company podcast notes from March 22, 2022 promoted up to 225% APY without explaining the yield calculation, funding, exit conditions or principal risk within those notes. Complete linked terms were not recovered, so this is a promotion-level disclosure question, not a finding that no disclosures existed or the yield was impossible. The notes also describe an actual Time Raiders IDO and distribution. [Company podcast](https://player.captivate.fm/587ac29a-5fc4-4db8-95e3-87f16c20e2af)

## Findings to carry forward

The strongest confirmed defects are MegaFans' inconsistent offering terms, Nativz's acknowledged commercial setback and unexplained entity reference. Kaskade needs current operating verification. GamiFi's historical pause is documented. Techstars' final report resolves meaningful initial concerns and confirms Laura's mentoring role.

Company association does not establish personal authorship, control, receipt of funds or responsibility for a defect. This review found no source tracing funds or personal data between these projects and Kidletcoin. It did not establish fraud, child abuse, misappropriation or a security breach.

Public pages can change. Dates describe the records reviewed, not guaranteed present conditions. A current profile's open-ended title is weaker evidence of a specific current assignment than a dated employer/program record. Search failures and inaccessible product endpoints were treated as retrieval limits. The 2025-labelled MegaFans deck yielded only partial extractable text, so it was not used to infer absent advisers, complete financial disclosure or full product status.
