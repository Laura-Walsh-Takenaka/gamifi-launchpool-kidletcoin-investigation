# Research Paper — GamiFi administrative handovers: three additional dated transactions

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Observation date: 6 September 2026. Network: BNB Smart Chain, chain ID 56. This document extends the previously verified Safe control evidence. It identifies blockchain authorization addresses; it does not identify the natural persons who controlled the keys.

## Newly verified handovers

| UTC | Control layer | Ownership transfer | Block | Transaction |
|---|---|---|---:|---|
| 2022-09-29 08:24:51 | Launchpool vesting operational owner | `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199` → `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b` | 21,747,966 | [0xa8b12962f2cecd9136794c2bef6c462c4b88d85ce0f9ba98275f4b033eb8bf75](https://bscscan.com/tx/0xa8b12962f2cecd9136794c2bef6c462c4b88d85ce0f9ba98275f4b033eb8bf75) |
| 2022-11-04 04:29:30 | Shared project ProxyAdmin owner | `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199` → `0x538a8b615e98e87d025c4336be44e4b8588277c7` | 22,755,381 | [0xadbe145db91127aa89e416895092f4865b2c966ea5b3d2c39e359372b769bb66](https://bscscan.com/tx/0xadbe145db91127aa89e416895092f4865b2c966ea5b3d2c39e359372b769bb66) |
| 2022-11-05 05:51:26 | ProxyAdmin placed under approval Safe | `0x538a8b615e98e87d025c4336be44e4b8588277c7` → `0x6bf55810ab061a016a968016818a6e1246aa8b5a` | 22,785,401 | [0xe1391addc79820a59676b049d2a4545719cbdc241b5d12164caab588beb5982a](https://bscscan.com/tx/0xe1391addc79820a59676b049d2a4545719cbdc241b5d12164caab588beb5982a) |

Each transaction succeeded. Its sender was the previous owner, its destination was the contract whose owner changed, and its calldata was `transferOwnership(address)` (selector `0xf2fde38b`) naming the new owner. Each emitted `OwnershipTransferred(previousOwner,newOwner)`. Historical `owner()` calls at the immediately preceding block and the event block independently match the event's previous and new owners. Exact transaction objects, receipts, events and historical calls accompany this document.

## What this adds to the already established sequence

- On 19 September 2022, the withdrawal Safe `0x9362ced428b4179650252ad87731240b32ef25f3` replaced its sole owner `0x7e0135da76bb6cdb35ac5f1342808925e3ef7445` with `0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9`. That separately verified Safe event remains the earliest of these selected post-announcement handovers.
- On 29 September, the Launchpool vesting contract's operational owner moved from original project deployer address `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199` to `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`.
- On 4 November at 04:29:30 UTC, the separate upgrade-authority contract, ProxyAdmin `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475`, moved from that original deployer address to `0x538a8b615e98e87d025c4336be44e4b8588277c7`.
- At 07:53:58 UTC on 4 November, 538a created approval Safe `0x6bf55810ab061a016a968016818a6e1246aa8b5a` with itself as sole owner and threshold one, as established in the prior Safe evidence.
- On 5 November at 05:51:26 UTC, 538a transferred ProxyAdmin ownership to that Safe. This was 23 minutes 12 seconds before the already verified 06:14:38 approval/temporary-upgrade transaction. The prior evidence shows that transaction's two Safe signatures recover 538a, and that ProxyAdmin ownership returned to 538a by the end of the transaction.
- At 06:45:09 UTC, the separate withdrawal Safe executed the 44 million GMI withdrawal, including 14 million GMI from Launchpool. Its three verified signatures recover afd9. These actions and quantities come from the prior receipt and signature evidence, not a newly discovered transfer in this lane.

The September 29 and November 4 events therefore give distinct dates for changes to operational ownership and upgrade authority. The November 5 Safe transfer explains how the signer already identified in the approval transaction acquired the immediately preceding administrative path.

## Records now identifiable more precisely

For custody/authority records, the concrete targets are: the September 29 handover of the Launchpool operational-owner role; the November 4 handover of the shared ProxyAdmin role; the November 4 creation and November 5 administrative use of approval Safe6bf; and the separately recorded September 19 Safe9362 owner swap. Relevant records could include key-custody agreements, corporate approvals or handover instructions that identify who controlled each signing address at those dates. Such records are not contained in the public blockchain evidence collected here, and no request was sent.

The original deployer address actively submitted the two newly dated handover transactions. That fact identifies the signing address, not a named employee, contractor, officer or beneficial owner. A CEO announcement cannot establish who possessed these keys, and none of these administrative events proves a Cayman bank account or a personal receipt by Laura.

## Bounded method and coverage

Historical anchor calls first established the original owner for both control layers at block 21,470,205 and their differing owners by block 22,759,425. The latter observations were used only to select bounded discovery windows. Repeated historical calls narrowed each selected change to fewer than 10,000 blocks, after which an exact-address `OwnershipTransferred` log query located a concrete event. The final ranges were:

- `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475`, blocks 22,754,388–22,759,425: 1 matching ownership event.
- `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb`, blocks 21,747,185–21,752,221: 1 matching ownership event.
- `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475`, blocks 22,779,254–22,785,864: 1 matching ownership event.

A state-guided search does not establish a monotonic or complete lifetime history. Ownership may change and return between sampled blocks. Accordingly, this report verifies the three listed events and their adjacent states; it does not claim that no other handovers occurred. Exact September 1 ownership was not sampled. The target-address log queries cover only the listed bounded windows, not the whole period between deployment and today.

Endpoint: https://docs-demo.bsc.quiknode.pro/ . Full request, response and retrieval time are retained. A transient HTTP 429 was preserved and resolved with slower requests; it is not evidence of missing events. Discovery scripts and all successful primary responses are included.

## Included machine-readable outputs

- `verified_handover_events.json`: the three receipt- and adjacent-state-verified events.
- `bounded_transitions.json`: sampled discovery points and bounded log results.
- `owner_*.json`, `*_logs.json`, `transaction_*.json`, `receipt_*.json`: underlying primary responses.
- `probe.py`, `isolate.py`, `verify.py`, `write_findings.py`: reproducible collection and assembly logic.
