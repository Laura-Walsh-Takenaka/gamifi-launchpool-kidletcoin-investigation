# Research Paper — Synapse bridge completion, liquidity use, and shared Safe owners

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The previously open Ethereum-to-BSC bridge lead now has an exact protocol match and a concrete on-chain use: DAO/BUSD liquidity provision, migration to a second pool, and a later stablecoin return to the original Ethereum Safe. This is a downstream branch from the **pooled Ethereum Safe**, so the amounts below are not an exclusive GamiFi allocation and are not identified Tornado withdrawals.

## Exact Synapse completion

On **23 September 2022 at 13:43:35 UTC**, Ethereum Safe **0x525a234de4eee961de7a7fabbf43a0ddcc289494** sends **310,000 USDC** to **0x50c999deb7f140082edb48c8b1c8802cacc2b14d**, in [05db2dca…](https://etherscan.io/tx/0x05db2dcab8f535198968a528b907230ff9d44af2c5d8c295981399728923a2dd). At **13:46:59**, that recipient commits **302,000 USDC** to Synapse in [357dc71b…](https://etherscan.io/tx/0x357dc71b24846d69c2e38a1b94613f468ff003856fa88af622d4c99402d7213a).

At **14:04:10**, **17 minutes 11 seconds later**, BSC [50bbc090…](https://bscscan.com/tx/0x50bbc09029c993c4821cdafe8bf0ee057308694c3a43f192b0d68b2d1b8ac037) pays the same address **301,792.181393206737262224 BUSD**. The destination `mintAndSwap` call succeeds.

The match uses Synapse's exact cross-chain identifier. Its [official explorer parser](https://github.com/synapsecns/sanguine/blob/ef5f972c4be446b74daf781b6a90b6198b7a4486/services/explorer/consumer/parser/bridgeparser.go) derives destination `kappa` by Keccak-256 hashing the UTF-8 source transaction hash, including its `0x` prefix. Independently computing that hash for `357dc71b…` produces:

`0x6ea98b6aa59f3fe6b550b0455eb28fdac6f60e6b297ce44cf050c22221c7d77b`

That value appears identically in the BSC destination calldata and `TokenMintAndSwap` event. Recipient, destination chain 56, intermediate amount, pool token indices, minimum output, and deadline also match. The intermediate **301,605.120907739002033060 nUSD** amount matches the destination mint argument exactly; its separately specified fee is **241.284096726191201626 nUSD**. The final BUSD payout is the actual asset delivered. The USDC-to-BUSD difference is not described as an independently isolated fee because the route also uses liquidity swaps.

Archive state independently confirms that the recipient's BUSD balance changes from **zero** at block **21,584,357** to **301,792.181393206737262224 BUSD** at block **21,584,358**.

## What the BSC recipient does with the assets

The DAO-labeled token contract is **0x4d2d32d8652058bf98c772953e1df5c5c85d9f45**. The old DAO/BUSD pair is **0xfc38d99970b70a35b624202e7b15820487a16eb3**; the later pair is **0xc5d5e5d5650d10908abc98f2ad3ca72bbd302fe3**. Both pairs' `token0()` and `token1()` getters independently identify that DAO contract and BUSD.

| UTC | Verified action | Transaction |
|---|---|---|
| 23 Sep 2022 13:49:06 | BSC Safe **43184b** supplies **200,000 DAO** to 50c999. | [adebbda9…](https://bscscan.com/tx/0xadebbda97801db62720cdff43d9e43c03ac14d079aa35cefa78f3372a022e0ee) |
| 23 Sep 2022 14:29:16–14:30:46 | Three small sales spend **11.5 DAO** and receive **18.757700127062216887 BUSD** in total. | [53271fcc…](https://bscscan.com/tx/0x53271fccde745cbef8af86b41f2633fb0c0a826988e8b82c4418b92627d1ccc8), [67036c46…](https://bscscan.com/tx/0x67036c4671d961f4ec58a0659a63e2996fdb48ce7d2c79dc28dbb1627ae4e10c), [1947a17b…](https://bscscan.com/tx/0x1947a17b41701cfdc32595ea07b5b8240b423cb9e2d9d62c3a5c58a87dc37190) |
| 23 Sep 2022 14:34:13 | Adds **190,444.011202082043752132 DAO** and **299,999.999999999999999998 BUSD** to the old pair; receives **239,004.732911589103502865 LP tokens**. | [c0417973…](https://bscscan.com/tx/0xc04179730545933b5eecb83d841b390c06517d7c5cb204f08a5a3471a8f11e7f) |
| 14 Jan 2023 10:54:21 | Burns the entire old LP position, receiving **255,588.345053223088700542 DAO** and **225,843.099231724425601880 BUSD**. | [b75fe23c…](https://bscscan.com/tx/0xb75fe23c648422e2a021a08bc540bd8ebeb1dd1e8e7b9838dd0e3a25baf13017) |
| 14 Jan 2023 11:01:33–11:03:21 | Two additions to the new DAO/BUSD pair, with two intervening swaps, produce **221,580.680600947638264440 LP tokens**. | [c454f9b9…](https://bscscan.com/tx/0xc454f9b967bf5012b5d78824b54904597d4b05416f61f3355cc2b4527119240f), [6f9739ce…](https://bscscan.com/tx/0x6f9739cef6ac395d6c87c3328e40adadd20e97186d00b76752ce9802aa6fd5d5) |
| 14 Jan 2023 17:12:55 | Transfers all new LP tokens to **0x412869e0cda40f3a1972d2c09cd23545d1b0709a**. | [a423f019…](https://bscscan.com/tx/0xa423f019cc176628aa2461c193b345e45170d23f9449b2d0839ce5e22cbc8a3b) |

The full four-token event ledger for 50c999 reconciles exactly to independently queried balances at BSC block **120,515,052**, **7 September 2026 at 15:03:19 UTC**: **7,860.785212975957449802 DAO**, **one wei of BUSD**, and **zero old or new LP tokens**. All **26** indexed transfers involving these four token contracts were matched to separately obtained successful receipts. The other 33 returned token rows are outside this four-token ledger.

The LP recipient 412869 subsequently receives **461,316.102459353131620590 BUSD** through another Synapse completion and **510,000 DAO** from the same supplier Safe 43184b. These are independently verified additional inputs; their upstream source is not assigned to the first bridge. On 18 January 2023, it adds **439,827.188100488995874743 BUSD** and all **510,000 DAO** to the new pair, minting another **433,209.153082345850174526 LP tokens**. Its pooled LP balance therefore includes substantial new capital.

Later verified dispositions include:

- **262,000 BUSD** and **306,536.144056591686055624 DAO** to **0x380ba929de57d8f74b418f0c90d0d1cb19df914c**, on 23 January: [BUSD](https://bscscan.com/tx/0xdabc8518ce7117835464ae360fcee9803e95709f615fce8ee4b1826a76bcdfc8), [DAO](https://bscscan.com/tx/0xf4946bbbd2e351212544d0c8131eca6082a1e5f9d1595e8c47c586e25fbd9117). That destination has no exchange attribution in this pass.
- **170,068.979619950037605937 DAO** returned to supplier Safe **43184b**, on 24 January: [b6c5edde…](https://bscscan.com/tx/0xb6c5edde2a557ea607229cc107e8a6b8d1394583e7927ab76d20ef5bc85559cd).
- The remaining **250,260.674433754771281374 LP tokens**, sent in a **260-token** transfer followed by **250,000.674433754771281374**, to Safe **0xd27301a265fdd7572b93a168f8507db084e5840e** on 24 January: [first](https://bscscan.com/tx/0x90dda669a2c6c051678bd5a256cb0584788ae54161ddc838d95a85f926299e64), [remainder](https://bscscan.com/tx/0xc68ca2ae39418024e4ea176413221becf86bd72defb59633ba5cec219b3b25fd).
- **224,223.109840 BUSD** committed to Stargate on 24 January, followed by an exactly matched Ethereum completion and onward return to the original Safe. See *Historical file: FINDINGS.md* for the independent packet match, actual USDC payout, and final transfer.

These later pooled dispositions cannot be assigned wholly to the first 302,000-USDC bridge. Successive transfers, LP minting, and return payments must not be added together as separate proceeds or losses.

## New control connection: all five Ethereum owners appear in the BSC supplier Safe

The owner relationship is established for the **September 2022 transaction period**, using historical state rather than today's configuration.

By **23 September 2022**, the Ethereum Safe 525a has **five configured owners and threshold three**, reconstructed from its creation setup and **106 indexed Safe logs** across blocks **0–15,596,438**. In August it adds d2361d, removes 5747d3, removes a8da91, and lowers the threshold to three. The three management transactions that make those changes were separately retrieved with their full log pages. This updates the earlier report's **July 2022** snapshot, which was correctly **four of six at that earlier date**.

At its DAO transfer on 23 September, BSC supplier Safe **43184b** is independently confirmed by archive `getOwners()` and `getThreshold()` calls to be **four of six**. **All five** of the Ethereum Safe's then-configured owner addresses appear in its owner list:

| Shared configured owner address | Ethereum Safe 525a, 23 Sep 2022 | BSC Safe 43184b, 23 Sep 2022 |
|---|---|---|
| `0xbc832c02920d53c37e9590dfb129975eab468dee` | Owner | Owner |
| `0xbed705ed328ca48e6112925b980cf80673743407` | Owner | Owner |
| `0xd2361dc1334414c82add43a478c026770bc091d6` | Owner | Owner |
| `0xe504a4c4c7edced18f445eb0ff94ed5a8f708855` | Owner | Owner |
| `0xe5342d500d7e5578d412f0379abed1fe08ba85b5` | Owner | Owner |

The sixth BSC owner is **0x9ff9253e46f1f838f03ac81cf37b3b67ccf5c619**. This is a direct configured-owner connection between the Ethereum stablecoin funding and BSC DAO funding. The shared set numerically exceeds both signature thresholds. It does not identify the humans holding the keys or establish which of those addresses signed the selected payments; actual signature recovery was not performed.

At the **24 January 2023** LP receipt, Safe d273 is independently confirmed as **two of four**, with owners e5342d, a8372d, bed705, and d2361d. Three addresses also appear in the September owner sets. This is a separately dated historical snapshot; no unchanged configuration throughout the intervening period is claimed.

## Coverage and remaining boundaries

- **30 distinct BSC transactions** have separately obtained full transactions, successful receipts, block headers, and block inclusion checks.
- All **15** indexed normal transactions of 50c999 are outgoing nonces **0–14**, matching its independently queried transaction count. Each is fully receipt-verified.
- The 412869 index returns **18 normal rows**, including **17 outgoing transactions**, matching its transaction count. **11 of those 17 outgoing transactions** and selected incoming asset transactions were fully receipt-verified; the six other outgoing rows remain index evidence.
- Both token index pages were exhausted below their page limit: **59 rows for 50c999**, **85 for 412869**. The four specified token ledgers reconcile to pinned current balances. Of 412869's **62 BUSD rows**, **52 are zero-value** and contribute no money-flow amount. Unrelated token contracts are excluded.
- Four independent archive BUSD state calls validate the bridge payout and the first liquidity addition before/after blocks. Eight archive calls validate the two BSC Safes' historical and current owner lists and thresholds.
- Ethereum verification consists of public Blockscout full transaction records, separately retrieved logs, and Safe creation data. It is not independent Ethereum RPC receipt/state verification.
- No full internal-native-BNB accounting, organizational attribution, later LP holdings of d273, or onward 380ba cash-out census was completed. Exact current BSC owner sets are retained in the machine file, separate from historical sets.
- All requested RPC/API payloads for this lane were obtained without network retries. Three exploratory BscScan address-page opens failed through the web retrieval service; no address label was inferred from those failed lookups.

Primary machine records: `findings.json`, `token_ledgers.json`, and `verified_bsc_transactions.json`. Independently collected raw payloads, request parameters, timestamps, historical block identifiers, and official protocol source are retained under `raw/` and `protocol/`.
