# Research Paper — Historical GMI dollar valuation method — 6 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

We recovered historical state for the GMI/WBNB PancakeSwap pair and Chainlink's BNB/USD price feed. This supports transaction-time USD estimates without substituting today's price, the IDO offering price, or a different token with a similar name.

## Contracts and procedure

- Chain: BNB Smart Chain, chain ID 56.
- GMI token: `0x93d8d25e3c9a847a5da79f79ecac89461feca846`.
- GMI/WBNB pair: `0x58d4b61983ca0afe6e352e90719f403e24e016f4`.
- Pair token0 returned GMI; token1 returned WBNB `0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c`. Both assets have 18 decimals in existing token verification.
- Chainlink BNB/USD feed: `0x0567f2323251f0aab15c8dfb1967e4e8a7d42aee`.
- Historical feed description returned `BNB / USD`; historical `decimals()` returned 8.
- Source endpoint: QuickNode's publicly advertised documentation demonstration RPC `https://docs-demo.bsc.quiknode.pro/`.
- Query `eth_call` for pair `getReserves()` selector `0x0902f1ac` and feed `latestRoundData()` selector `0xfeaf968c`, both pinned to the block immediately before the transaction block. The block parameter is critical: `latestRoundData` here returns the answer latest at that historical block, not at the present date.
- USD estimate per GMI = `(WBNB reserve / GMI reserve) × (Chainlink answer / 10^8)`.
- Multiply the exact GMI transfer quantity by that unit estimate. Keep full decimal precision until rounding the displayed money amount.
- Record both the pair's last-reserve-update timestamp and oracle `updatedAt`, including their age at the transaction timestamp.

The estimate is the marginal market mark available immediately before the transaction block. It is not an executed sale, cash proceeds, an investor's purchase cost, a realizable block-sale quotation, a bank balance, or a loss calculation. A large sale changes the pair price and incurs fees. The model excludes that price impact. At block 22786456 the reserve ratio had last updated 4 hours 22 minutes 44 seconds earlier; this limitation is explicitly recorded.

## Results

| Transfer timestamp, UTC | Prior block | BNB/USD feed | GMI/USD marginal mark | Oracle age | Pool reserve-update age |
|---|---:|---:|---:|---:|---:|
| 2022-04-19 16:30:49 | 17086173 | 421.45 | 0.0138638203109748987795672683272524756383823572 | 63 s | 30 s |
| 2022-04-19 17:14:29 | 17087042 | 418.90255435 | 0.0138027226933832663927460370953828991768977497 | 42 s | 36 s |
| 2022-11-05 06:45:09 | 22786455 | 359.64 | 0.000191134246647142652438987261696108176220394142 | 3 s | 15,764 s |
| 2022-12-14 16:01:19 | 23901240 | 272.455 | 0.0000803148099914936256123922743650383076982012399 | 3 s | 41 s |

For the reported 14,000,000 GMI transfer on 5 November, this method gives US$2,675.879453059997..., conventionally rounded to **US$2,675.88**. Its token quantity and transaction purpose must be verified from the receipt separately; this price lane does not independently classify that transfer.

## Independent reasonableness checks

CoinLore's own historical-data pages show daily USD ranges of $0.0136–$0.0163 on 19 April 2022 and $0.0000782–$0.000106 on 14 December 2022. On 5 November 2022 CoinLore shows a daily range of $0.000124–$0.000192. All four derived pool/oracle marks lie inside their respective daily ranges. These are daily rounded data, used as a check rather than substituted for transaction-time prices. CoinLore says it operates its own exchange-data infrastructure; its GamiFi series begins in March 2022 and ends 10 August 2023.

Binance's public BNB/USDT minute candles independently bracket nearby BNB prices: 19 April 16:30 UTC, 421.30–421.70 USDT; 17:14 UTC, 418.30–418.50 USDT; 14 December 16:01 UTC, 272.60–273.10 USDT. They are a different market/quote asset from the Chainlink USD feed, and are not used in the final USD calculation. No assumption that USDT equals one USD is necessary.

## Public documentation

- Chainlink feed identification: https://data.chain.link/feeds/bsc/mainnet/bnb-usd — search retrieval identifies BNB Chain Mainnet, BNB/USD, standard address beginning 0x0567 and ending 2aeE. Direct page retrieval returned 403; do not treat that failed download as contents evidence.
- Chainlink ABI, decimals, and timestamps: https://docs.chain.link/data-feeds/api-reference — directly retrieved successfully and saved in `chainlink_api_docs.json`.
- Binance candle fields and UTC time: https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints — web documentation retrieved successfully.
- CoinLore series: https://www.coinlore.com/coin/gamifi/historical-data
- CoinLore April date range: https://www.coinlore.com/coin/gamifi/historical-data/1650240000/1650499200
- CoinLore December date range: https://www.coinlore.com/coin/gamifi/historical-data/1670889600/1671148800
- CoinLore methodology: https://www.coinlore.com/methodology

The dated CoinLore pages and raw BNB candles were retrieved using Python urllib. Web-parser opens of the date-specific pages failed; the actual raw successful response and retrieval metadata are preserved locally. CoinGecko's contract endpoint returned 404; CryptoCompare and GeckoTerminal attempts returned 401; Binance.US BNB/USD, Coinbase USDT/USD and Bitstamp USDT/USD attempts timed out. These failures are preserved to document the retrieval path, and are not the valuation basis.

## Files

`price_marks.json` holds the original three decoded marks. `price_mark_22786456.json` holds the 14-million-token transfer mark. `pool_reserves_<prior block>.json` and `oracle_round_<prior block>.json` preserve requests and responses. `oracle_decimals.json`, `oracle_description.json`, `pool_token0.json`, and `pool_token1.json` preserve identification checks. `value_blocks.py` can repeat the same method for a bounded list of transaction block numbers; its raw JSON outputs should be inspected for provider errors before calculation.

## Full feed address confirmation

The reference-data directory endpoint `https://reference-data-directory.vercel.app/feeds-bsc-mainnet.json` returned a successful public JSON response. It identifies both BNB/USD `0x0567F2323251f0Aab15c8dFb1967E4e8A7D42aeE` and BUSD/USD `0xcBb98864Ef56E9042e7d2efef76141f15731B82f`, each with eight response decimals. The two relevant records are extracted in `chainlink_feed_identity.json`; the response is preserved in `chainlink_reference_bsc.json`.

## All opening deposit transactions priced

All 39 transfer logs in the supplied bounded opening deposit query were valued separately at their own immediately preceding block. Together they moved **15,456,885.882908530406846 GMI**, whose summed transaction-time USD marks are **US$213,274.6476983695001283046218882332** (US$213,274.65 rounded). This includes the 10-GMI test transfer and 38 allocation batches. It is a mark of project tokens deposited, not dollars paid by investors. Oracle ages were 9–111 seconds and reserve-update ages 3–42 seconds. Complete machine-readable rows are in `opening_inflows_valued.json` and `opening_inflows_valued.csv`. This valuation is complete for the 39 input logs only, not a claim about full lifetime transfer coverage.

## Stablecoin proceeds and private-recipient native BNB

BUSD proceeds and onward transfers use the historical BUSD/USD oracle `0xcbb98864ef56e9042e7d2efef76141f15731b82f`, queried at the block immediately before each transfer. Historical description and decimals checks returned `BUSD / USD` and 8. This avoids silently equating every BUSD with one USD. Results are in `busd_price_marks.json` and `private_oracle_marks.json`; the raw requests are `busd_oracle_round_<block>.json`. The November 5 sale block 22786580 returned a BUSD/USD answer of 0.99997113, updated 261 seconds before the sale; 5,174.293394005109506048 BUSD therefore marks to **US$5,174.144012154824578536560394** (US$5,174.14). This remains an on-chain stablecoin receipt, not evidence of fiat dollars reaching a bank.

Some earlier BUSD feed answers were updated hours before their transaction, including 79,865 seconds for June 22, 2022. Record the actual update age; do not apply the current feed heartbeat retrospectively, and do not describe these as contemporaneous exchange fills.

The private-recipient native BNB sale at block 24966612 on January 21, 2023 used BNB/USD 305.02342, updated 10 seconds beforehand. The April 4 onward BNB transfer at block 27053891 used BNB/USD 310.010068, updated 9 seconds beforehand. These are conversion marks for actual BNB amounts in the transaction evidence, distinct from hypothetical GMI liquidation estimates.

The 120-million-GMI private vesting funding at block 14476742 on January 18, 2022 has marginal mark $0.04807573620455228 per GMI. Such a multiplication is highly theoretical: the main pair held only 3.983 million GMI and 413.8 WBNB at that time. It is not purchase cost, capital raised, or an executable valuation of the full transfer.
