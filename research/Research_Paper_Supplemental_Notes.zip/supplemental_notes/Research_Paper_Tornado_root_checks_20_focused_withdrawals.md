# Research Paper — Tornado root checks: 20 focused withdrawals

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Twenty withdrawal transactions were checked against actual calldata, successful receipts, and pool Withdrawal logs: 12 April withdrawals on candidate onward exchange routes, plus eight July zero-fee withdrawals by `0x1cf0eeeb39fe5c8316e505bdcb5f1c8252598661`.

**The pre-first-deposit root test did not exclude any of these 20 withdrawals, and did not identify any GamiFi note being spent.** All seven distinct roots returned `false` when queried at the appropriate boundary. False is inconclusive because the pool keeps a circular history of 30 roots; it is not evidence of a link.

## Three April root snapshots

The ten April 100-BNB candidate withdrawals use three roots. Historical `getLastRoot()` calls exactly match those roots after d676's fifth, eighth, and tenth 100-BNB deposits. Historical `nextIndex()` values also match the cumulative leaf counts.

| Candidate withdrawal | Root observed at block | Root leaf count | Supported restriction |
|---|---:|---:|---|
| cb18021c… to 17586… | 17,324,287 | 7,916 | Cannot spend any of d676's last five 100-BNB notes, which were deposited later. |
| 18b59cf0… to 9fa847… | 17,325,621 | 7,919 | Cannot spend d676's last two 100-BNB notes, which were deposited later. |
| Eight withdrawals to 471c…, 38d3…, and 7eb9… | 17,325,949 | 7,921 | Root already contains all ten tracked 100-BNB deposits; no tracked-note exclusion from this snapshot. |

These exact root matches establish which historical tree state each proof used. They leave earlier notes unresolved. The cumulative leaf count includes previously spent commitments and is **not** a count of spendable candidates. Matching a root that contains GamiFi deposits does not establish that one of those deposits was withdrawn. No whole withdrawal is excluded by the two later-note restrictions.

## Boundary validation

| Branch / pool | First deposit block | Historical boundary block | `nextIndex()` before deposit |
|---|---:|---:|---:|
| April / 100 BNB | 17,324,279 | 17,324,278 | 7,911 |
| April / 10 BNB | 17,326,897 | 17,326,896 | 27,484 |
| July / 10 BNB | 19,909,171 | 19,909,170 | 37,482 |
| July / 100 BNB | 19,912,158 | 19,912,157 | 10,962 |

Every boundary nextIndex equals the first tracked deposit's event leaf index. Boundary block hashes and timestamps, exact request/response captures, all candidate hashes, and the prior evidence hashes are retained in the JSON files.

## Separate chronological exclusions

Of the 444 withdrawals in the prior report's short windows, 16 occurred before that branch's first deposit into the same denomination pool: nine April 10-BNB withdrawals and seven July 100-BNB withdrawals. Those 16 cannot spend the later same-branch notes. This is a chronological exclusion, independent of the root tests. It does not exclude other earlier deposits, identify wallet ownership, or exclude any of the 20 primary candidates.

## Method and primary sources

The official Merkle tree source appends each deposit, stores the newest root in a 30-slot circular history, and checks root equality in `isKnownRoot`. The official withdrawal circuit proves membership of the private note commitment in the submitted root. Consequently, a root observed before a tracked commitment was inserted excludes that later commitment, under the standard proof-system and hash-security assumptions. The inverse is not valid: `false` does not establish a connection.

- Merkle tree and root-history logic: https://github.com/tornadocash/tornado-core/blob/master/contracts/MerkleTreeWithHistory.sol
- Withdrawal acceptance and public inputs: https://github.com/tornadocash/tornado-core/blob/master/contracts/Tornado.sol
- Withdrawal membership circuit: https://github.com/tornadocash/tornado-core/blob/master/circuits/withdraw.circom
- Exact public proxy ABI: https://github.com/tornadocash/tornado-classic-ui/blob/a83fae0772c8da084c0e76b3a756b456f5b9f5bb/abis/TornadoProxy.abi.json

The prior official deployment configuration maps the examined BSC pools. Actual historical contract calls were made at those addresses. This work does not claim an independently recompiled deployed runtime or a proof-system audit. Transaction and receipt records reused from parallel agents were copied into this evidence directory with their original request/response captures.

Files: `results.json`, `boundaries.json`, `summary.json`, `april_root_snapshots.json`, `chronological_exclusions.json`, `method_and_findings.json`, `request_manifest.json`, `prior_source_manifest.json`, `sources/`, and `raw/`.
