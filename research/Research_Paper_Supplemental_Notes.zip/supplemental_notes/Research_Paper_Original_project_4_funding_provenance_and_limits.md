# Research Paper — Original project 4: funding provenance and limits

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research date: 7 September 2026 (UTC). BSC chain ID 56. Working note for incorporation into the master investigation. Original project contract: `0x56c0cb2d047b69278f49b4759c1718436a546c7f`.

## Material result

The sole recorded contributor to original project 4, `0x391a51d884b240908a88e1e757ec42189d294423` (391a), was supplied with its 10,000 GMI participation tokens and 1 BNB before its first outgoing transaction by `0x35b119730f79881dac623dc51c831c6a04cab5f3` (35b1). Its exact 2,000 BUSD contribution followed an observed, same-amount route from 35b1 through `0x36048413c4edf0cf3e633aab317fcd9824dfb4d4` (3604). The contract ultimately paid the 2,000 BUSD to 35b1 on 23 March after its owner changed project 4's configured recipient.

This connects the previously unnamed contribution to addresses already present in the operational treasury and private-vesting investigation. It establishes a same-amount circular transfer route at the observed address level. This is a linkage of transfers, not identification of unique fungible units after mixing or a determination of the earlier commercial origin of 35b1's funds. It does **not** identify the humans signing those transactions, establish that the campaign was a test, establish common beneficial ownership, or prove that the withdrawal stole an outside customer's money. A legitimate operational test, an internally financed participation, another contractual arrangement, and misuse are not distinguished by the transfers alone.

All times below are UTC in 2022. Exact amounts use each token's 18 decimal places; the table displays whole-token quantities where the base units divide exactly.

| Time | Observed event | Transaction |
|---|---|---|
| Mar 11 10:25:19 | 35b1 sends 10,000 GMI to 391a | [16be6d6e](https://bscscan.com/tx/0x16be6d6e38bf5db8dc321c7f3efe215d8886ab5c074476f0736beb7a3355aa98) |
| Mar 11 10:29:16 | 35b1 sends 1 BNB directly to 391a | [c8d79ad0](https://bscscan.com/tx/0xc8d79ad08102d07abffa43ed4baa359d123cffd1cd05c1db20af73967147ef40) |
| Mar 11 10:29:52 | 391a's nonce 0 approves GMI to the project contract | [ba828cbe](https://bscscan.com/tx/0xba828cbea31467abd538065419fab2b08dcbd8020c8e28ad5cad5445203203c2) |
| Mar 11 10:30:10 | 391a stakes 10,000 GMI in original project 4 | [1c471303](https://bscscan.com/tx/0x1c47130392716d42a4d40e6fd8a7a3b66b683a99afc3299041c36d9399caf3e3) |
| Mar 11 10:48:01 | 391a approves BUSD to the project contract | [0635a2b5](https://bscscan.com/tx/0x0635a2b5571ea5af4ac214c91cd7221db091746f58f832225eb5aa0235eceb83) |
| Mar 11 10:52:07 | 35b1 sends 2,000 BUSD to 3604 | [4a298bd4](https://bscscan.com/tx/0x4a298bd4a19e7993c92d2e54651f55145330c93e8f9a2b61592b6f7a65ec7ccd) |
| Mar 11 10:54:34 | 3604 sends 2,000 BUSD to 391a | [9397957f](https://bscscan.com/tx/0x9397957fd74ccd8680e56b5c8734c1917efec4c57611bf4a59fa8705b5ce6a62) |
| Mar 11 10:55:04 | 391a contributes 2,000 BUSD to original project 4 | [553cf238](https://bscscan.com/tx/0x553cf2385ef6d40f35e589accd89be0129ee78ff4e1ce3edae423700ce27a288) |
| Mar 11 11:55:43 | 391a calls `claimBack(4)` and receives its 10,000 GMI stake back | [2909ca27](https://bscscan.com/tx/0x2909ca27c96fcbe49ab6274dcc4317c0107c2b4b9bc83aa410f48e8e8448c715) |
| Mar 23 14:56:37 | Historical project owner 3e0f changes project 4's funding recipient to 35b1 | [39f7777f](https://bscscan.com/tx/0x39f7777f43b5155f7238fa822d796206ddcd74e0b27481c78f33b7debf00f8cc) |
| Mar 23 14:58:07 | Owner 3e0f calls the ordinary project withdrawal; contract pays 2,000 BUSD to 35b1 | [33f6c2ae](https://bscscan.com/tx/0x33f6c2ae7893cf8763b5306d4220780592390cc22ab9399034f4b3ac6ee09683) |

The native BNB transfer, available to pay gas, preceded 391a's first normal outgoing transaction by 36 seconds. It is the observed pre-use gas funding link, not a complete proof that the address had never received BNB earlier. The selected three-block native-transfer probe around the separate GMI transfer found no native transfers, but that narrow negative has no significance once the actual 10:29:16 gas transfer is located.

The existing master's selected private allocation identified 3604 as the beneficiary of the 120 million GMI vesting allocation funded on 18 January 2022, transaction `0xac39350f0f652c95dfb73e0cd8f2028a2c8aa34a51d081374a6c850647625787`. The present lane adds the route back into project 4. It does not resolve 3604's human identity or entitlement. The March BUSD must not be represented as proceeds from its November and later GMI vesting claims.

## Additional 391a observations

391a's nonce 5 sent 100 GMI to `0xecc90d54b10add1ab746abe7e83abe178b72aa9e` on 29 March at 09:32:17, transaction `0x80f583f1e6d13ba17984a2f06c1e23a6ce5c27d29af8003a66eae6f77d3553c8`. No human or commercial purpose is assigned to that recipient.

The existing master separately identifies a later 9,900 GMI transfer from 391a to 3604. The present independent Defibit receipt check dates this nonce-8 transaction to 6 December 2022 at 11:32:09 UTC, block 23,670,820, in transaction `0x782a3cb1e15038899222d883a233bcf031c20236ba0b8a3f8584052d799de7ae`. That link predates this research as an established master finding; it is cross-referenced here and its successful receipt is now independently reproduced in the checks file, including the exact GMI amount and recipient. The fact that 100 + 9,900 equals the returned 10,000 is not a claim that a full intervening incoming-token census was completed in this lane.

## Control history and attribution limits

Existing historical implementation and state work already proves that 3e0f was contract owner for the 23 March recipient change and withdrawal, and that 8fea had been the configured project recipient at the sampled funding start. The May/June samples showed owner 14cc and enabled administrator 3e0f. These are dated address-level roles, not human signing mandates.

This lane sampled outgoing nonces immediately before project 4 funding (block 15,963,752), immediately before the recipient change (16,311,896), and at research block 120,400,892:

| Address | Before funding | Before recipient change | Pinned research block |
|---|---:|---:|---:|
| 391a | 3 | 5 | 10 |
| 8fea | 19 | 21 | 22 |
| 3e0f | 109 | 117 | 447 |
| 14cc | 0 | 0 | 59 |

391a had no deployed code at the contribution block and exactly 2,000 BUSD immediately before its contribution. Seven of its ten normal outgoing transactions are represented (nonces 0–5 and 8; nonce 3 independently rechecked from the known contribution and nonce 8 from an existing master reference). A rate limit interrupted the later nonce search. This note does not claim a complete later sender history, token history, owner/admin appointment history, earliest gas census, or full control-change timeline.

Exact-address public searches for 391a, 8fea and 14cc returned no useful indexed identity result. Searching the already recovered public `gamifiContracts` Git history for 391a and 8fea returned no matching commits. No positive public source found in this bounded lane names Laura or any other human as the transaction signer. Search failure is not proof that such evidence does not exist.

## Evidence and reproducibility

- `funder_prefunding_incoming.json`: selected GMI/BUSD incoming logs for blocks 15,953,753–15,963,753 from QuickNode, with Binance transaction and successful receipt checks. Preserves the new 35b1→391a GMI and 3604→391a BUSD links.
- `funder_nonce_0.json`, `_1.json`, `_2.json`, `_4.json`, `_5.json`: located sender transactions and Binance receipts, with decoded summaries. `probe.json` preserves known nonce-3 contribution, its receipt, historical nonce samples, code and pre-contribution BUSD balance.
- `selected_pooled35b_source_records.json`: exact relevant records copied from the independent pooled35b lane with source-file SHA-256. These include 35b1 nonces 79–81; the original lane checked transaction and receipt against Binance.
- `operational_chain_independent_checks.json`: separate provider's retrieved transactions, receipts and block timestamps for the main joined route, with errors preserved if any check fails. All five Defibit checks completed successfully: 35b1 native funding, 35b1→3604 BUSD, 3604→391a BUSD, 391a→project BUSD, and the later 391a→3604 GMI transfer.
- `chain_raw/`: exact JSON-RPC endpoint, UTC retrieval time, request and response/error envelopes. Queries used public QuickNode and Binance; independent verification used Defibit. A PublicNode request returned HTTP 403, QuickNode eventually HTTP 429, and a broad Binance ownership-log probe hit its query limit. Those failures are preserved and support no negative chain finding.
- Exact method decoding uses the already byte-for-byte matched March implementation signature list in *Historical file: 0xfa83e6a35d98e5243cd3e5740b6f52daa316c075_signatures.json*: `stake(uint256,uint256)` = `0x7b0472f0`; `funding(uint256,uint256)` = `0x9f5e994d`; `claimBack(uint256)` = `0x7d529d72`. The latter returns staked GMI and is not a BUSD refund.
- The sole-contributor census and 23 March receiver change/withdrawal are reused from *Historical file: CONTRACT_MECHANICS_FINDINGS.md* and associated preserved raw records; this lane does not redo those seven withdrawal mechanics.

The next material nonpublic records are the contemporaneous purpose and authorization of the 35b1→3604→391a funding sequence, project 4's actual customer/campaign terms or test record, and custody/signing mandates for 35b1, 3604, 391a and 3e0f. Until obtained, the evidence establishes operational money movement without a theft or named-human conclusion.
