# Research Paper — Tornado Cash — Unassigned withdrawal branch: later Polygon bridge requests

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The address `20f0ad2e0bd202a57bdf1aa53524145a2e8d5f4d` received four canonical BSC pegged-USDT transfers from `829254368b9b46ea4d12ac2324728d2e0495ea3a` on 21 August 2022. Full transactions and successful receipts independently verify **141,207.582674659643341201 USDT** received. The token is exactly `55d398326f99059ff775485246999027b3197955`, with 18 decimals; the transfer event topic, sender, recipient and raw quantities were checked.

Four subsequent successful calls to the previously verified Anyswap router request **100 + 10,000 + 30,000 + 101,107 = 141,207 USDT** for destination chain **137 (Polygon)** and address `82f6ac7d4c8a00a4cced3f673d67e1bcf8d7e8f8`. Full source calldata and receipt logs agree. Polygon completion was not retrieved. The selected inputs exceed those requests by **0.582674659643341201 USDT**; that is arithmetic over the selected records, not a historical balance assertion.

The complete reported address indexes returned 21 normal rows, 37 token rows and one internal row. Only the eight selected August input/bridge transactions received fresh full transaction/receipt verification. November bridge activity is retained in the indexes as an unexamined continuation, including a return followed by another request; its amounts must not be added as new income. UTC times in these selected summaries come from the index, while block numbers are receipt-verified.

The earlier 1cf0 account sent 457.631418205 BNB to 8292, but the intervening conversions and other funding at 8292 are not allocated here. These source-side bridge requests **are not identified GamiFi exits**, and the 141,207 USDT must not be assigned to the 1cf0 payment or to a particular Tornado note.

## Exact source transactions

- Input 100 USDT: https://bscscan.com/tx/0xfc40e9867382aeb363af5a6fb23a9eb2da8a995f9c56aae3d0c789ef9982f775
- Input 10000 USDT: https://bscscan.com/tx/0x331ac23eea7f7453c601e8594a69f0fe9c9fd630a7c9eb1b18adb792776becaa
- Input 30000 USDT: https://bscscan.com/tx/0xfc6ba439f22fd926efaacf053fab119d8649398cec0fac89c63de666d5148702
- Input 101107.582674659643341201 USDT: https://bscscan.com/tx/0x8b868b987f36d207694c039c76ee93e4c8a382bf368a43cdc58c46c5f10701f2
- Bridge request: https://bscscan.com/tx/0x226f283da928fcb4a875b4ae9e63ca975c7f816a2d9dc42eabee6e71e5d35689
- Bridge request: https://bscscan.com/tx/0x8bf60de37cf6b76c619515f4f4b89525411755e29d29eb1c9343cedd7fb2fa58
- Bridge request: https://bscscan.com/tx/0x34d96bba38436bdc872dd565c54d7674f121869f95f74ce8f3d76439f9d2fead
- Bridge request: https://bscscan.com/tx/0xbb03af6388c994425f786418c285763b21153e967a081e10c10d891c98a48f4f
