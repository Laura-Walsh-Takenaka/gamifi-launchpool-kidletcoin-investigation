# Research Paper — KidletCoin apps: law-enforcement authorities evidence update

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Public-source collection: 7 September 2026, approximately 03:21–03:24 UTC. This note supplements EV035–EV036. No child identities, private accounts or production devices were accessed. No app was installed, built or executed.

## What this pass adds

**The advertised Google Play package circulated publicly by 4 December 2018, earlier than the January 2019 announcement already in the master.** Finnish Discourse post 37866 (topic 2916, post 1161) records creation at 07:17:34.620 UTC and an edit at 19:44:05.639 UTC that day. The exact URL ending `id=com.kidletcoin.app` appears in the public raw post and in both unchanged sides of revision 2. This is platform-history evidence of the link's circulation. The current cached preview names *Kidlet.io Wallet*, describes its NEMPay basis and uses the words “easily and securely.” The generated preview is not an independently dated copy of Google's complete listing. It supplies neither a publisher identity nor an authenticated binary. [KA01–KA02]

**The production-source match remains open.** The pinned June 2018 repository configuration still says `com.Kidlet.app`, version `1.0.1`. Both exact Google Play URLs returned HTTP 404 in the US/English public view on 7 September 2026. Those responses do not prove the app was never available, identify when it was removed, or show what existing users retained. Google explains that an unpublished app can remain usable by existing users. No APK/AAB, signing certificate, historical installation count or release approval was recovered. [KA03–KA05; KA11]

**A quiz beta remains a distinct product and evidence request.** Fresh project-channel metadata for video `S2B4UIKd0jI` identifies the same channel `UC2sui4vaP9sWpevdKbytQUA`, reports upload/publication 22 June 2019 at 06:26:59 UTC, and describes a 20 June Bangkok demonstration. The video is currently public and listed. Metadata is editable. The automatic-caption request returned HTTP 200 with an empty body; three storyboard requests timed out. No transcript or frame review is claimed. A demonstration announcement cannot supply the actual quiz app, consent screen, back-end fields, reward accounting or merchant settlements. [KA06]

## Keep the data paths separate

| Path | What the available record supports | What still needs a real operational record |
|---|---|---|
| Contest email | Prior master documents a request for an identity/video/wallet bundle at the project's published submission mailbox. | Actual receipts, parent permissions, mailbox access/forwarding and retention. This source review does not answer them. |
| Reviewed wallet source | Local wallet storage; a local SQLite address book linking wallet owner, contact name and address; the already documented password-storage/logging defect in its fingerprint feature. | Whether the released package contained those files and what happened on actual devices. |
| Fingerprint feature | Reviewed TypeScript invokes a fingerprint plugin and stores the wallet password under its wallet address. | No fingerprint image/template collection or child-biometric database was demonstrated. Plugin/build and production evidence are required for broader claims. |
| Quiz beta | A dated public demonstration description. | Production binary/site, operator and hosting identity, registration/consent screens, data schema, access logs and rewards. |
| Shopping/redemption | Contemporary product claims and plans remain in the baseline. | Named merchants, accepted customer terms, actual orders and settlements. No such record was authenticated in this pass. |

The source's address book is not evidence of importing a device's contacts. A wallet's name field is a user-assigned label, not proof that real legal names were required. No parent/guardian/consent/privacy screen or contest identity/video upload routine was identified in the reviewed application source files; this is a bounded source observation, not proof no private consent process or separate application existed. [KA03, KA07]

## Specific records that would resolve the app questions

| Custodian to identify or approach through the appropriate process | Exact preservation target | Why it matters |
|---|---|---|
| Google Play and the historical publisher for `com.kidletcoin.app` | Developer-account identity and dated roles; first publication and every release/version; submitted and delivered APKs/AABs; public signing-certificate fingerprints and any key lineage; listing/privacy-policy/target-audience/rating/territory history; review/removal notices; retained aggregate installation statistics. Start with December 2018–2020 and any later retained versions. | Connects an actual released app to an operator, period, audience and reviewed source. Request what remains; no retention guarantee is assumed. |
| App commissioning party and developers | Executed scope, invoices, accepted source commit, reproducible build inputs, generated manifest and distribution files, test/security reports, release approval, support complaints and fixes. | Distinguishes a repository defect from a shipped defect and identifies who approved or knew about it. |
| Lawfully obtained historical device or backup | Original installed package/version and certificate; forensic copy and hash; relevant app-local databases/logs with minimized child information. | Direct production comparison. Avoid publishing passwords, private keys or child identifiers in the report. |
| Quiz operator, demonstration organizers and hosting/development providers once identified | June 2019 demo build and recording; production deployments/domains; data dictionary and consent screens; access/retention logs; anonymized reward and redemption ledgers; acceptance and approval records. | Determines whether a demo became a service that received children's data or issued redeemable rewards. |

Google's current documentation explains versioned APK access in the publisher console and distinguishes app-signing keys from upload keys. It supports the specificity of these requests; it does not establish that this 2018 app used today's bundle/signing arrangements or that Google retains every requested record. AAB publication became mandatory for new apps in August 2021, so **request original APKs as well as any bundles**. [KA08–KA10]

## Retrieval limits and conclusion

This pass also queried public GitHub deployments (empty), Actions runs (zero), repository-name search for `kidletcoin` (zero), Internet Archive item search for the project/package names (zero), and the Portuguese archive's exact advertised Play URL history (zero). A name search is not all public/private code; current empty platform lists are not lifetime deletion histories. Current similarly named apps found in general search have different package IDs and were excluded.

The useful gain is an earlier, precisely identified publication lead and a provider-specific route to the missing production/consent evidence. **This pass does not establish receipt of children's entries, unlawful processing, credential theft, or Laura's personal access to any child record.** EV035 and EV036 remain open compound questions.

## Sources

- **KA01** Public native post: https://forum.bittiraha.fi/posts/37866.json . Human view: https://forum.bittiraha.fi/t/2916/1161 . Post-response SHA-256 `8d1ab52f59af45523410bfecdd045a90b8fe1a66ba06141c762b908192878d02`.
- **KA02** Native revision 2: https://forum.bittiraha.fi/posts/37866/revisions/2.json . SHA-256 `2b68e381745c687d46ddf52b0937fc275410874f82933ad4b36068206a50a26b`. `side_by_side_markdown` contains the exact Play URL in both the previous and current unchanged cells.
- **KA03** Pinned configuration: https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/config.xml . Entire pinned MIT-licensed source ZIP: https://codeload.github.com/baconbkk/Kidlet/zip/d8c2e9b3a364734a17bead61f5549672dfb73de6 . Retrieved ZIP SHA-256 `05a90c60b22165d0ca4f2032af18a1a931fdd3f8270c602e1cfc09d1dc87d3c1`.
- **KA04** Advertised package view: https://play.google.com/store/apps/details?id=com.kidletcoin.app&hl=en&gl=US . HTTP 404.
- **KA05** Source package view: https://play.google.com/store/apps/details?id=com.Kidlet.app&hl=en&gl=US . HTTP 404.
- **KA06** Project quiz metadata: https://www.youtube.com/watch?v=S2B4UIKd0jI . Current response SHA-256 `5425f4fc74f33d9e0c4a72801729943e086377d6a7b2d5dc8e917f57f1e75230`.
- **KA07** Source data paths: https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/providers/contact/contact.provider.ts ; https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/settings/settings.ts ; https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/app/app.module.ts . Individual hashes are in `source_file_hashes.json`.
- **KA08** Google publisher artifact access and August 2021 bundle transition: https://support.google.com/googleplay/android-developer/answer/9844279?hl=en . Current documentation retrieved through search, 7 September 2026.
- **KA09** Google signing-key distinctions: https://support.google.com/googleplay/android-developer/answer/9842756?hl=en . Current documentation retrieved through search, 7 September 2026.
- **KA10** Android application ID continuity: https://developer.android.com/studio/publish/preparing?hl=en . Current documentation retrieved through search, 7 September 2026.
- **KA11** Google unpublishing behavior: https://support.google.com/googleplay/android-developer/answer/9859350?hl=en . Current documentation retrieved through search, 7 September 2026.

The machine manifests record additional bounded discovery queries and failures. The delivery directory contains concise factual extracts, hashes and licensed source; full mixed-topic forum/YouTube response bodies stay outside the delivery bundle. Original URLs permit reacquisition, whose dynamic response hashes may differ.
