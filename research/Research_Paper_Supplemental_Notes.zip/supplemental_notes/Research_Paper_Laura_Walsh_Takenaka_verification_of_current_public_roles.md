# Research Paper — Laura Walsh / Takenaka — verification of current public roles

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

**Later Cardano correction.** The validated Cardano review resolves the apparent budget-allocation and cohort-size discrepancies through the approved milestone records. Payment tranches are not spending categories; twenty selected companies and eighteen graduates are reconciled. Earlier unresolved-budget or missing-delivery wording must be read with that correction.

Research notes, checked 5 September 2026. Scope: official employer, program and investee sources. Public professional activity only; no private contact, family or address details gathered. Search results and page listings show the status of public records, not private employment or investment contracts.

## Findings and date limits

| Organization | Public evidence | Status supported |
|---|---|---|
| Nativz Gaming | Official team page plus CEO newsletter of 9 July 2022 | Currently publicly listed adviser; historically confirmed first angel investor. Current shareholding, amount invested, precise advisory assignments and operational authority were not disclosed in these sources. |
| Syndika | Company announcement embedded in Laura's own repost; current syndicate roster checked | Historical membership and proposed advice on business outlook, marketing and community growth confirmed. Current roster does not contain Laura or Walsh; this omission does not prove departure. No dated 2026 assignment found. |
| Techstars Web3 | Official All-Star Mentor award list dated 19 February 2024; program leader's 23 July 2025 retrospective | 2023 All-Star designation and historical Entrepreneur in Residence (EiR) role independently confirmed. The leader's departure and accelerator restructuring do not establish Laura's own employment end date. |
| Techstars + Cardano Founder Catalyst | Official final report dated 27 February 2026, mentor roster p. 32 | Mentoring in the 2025 cohort confirmed. The report date is a 2026 reporting event, not evidence of a new 2026 teaching assignment. No specific September 2026 Cardano assignment verified. |

## Nativz Gaming

The current company team page places Laura in the advisory group; Kurt Pittman appears as founder and CEO. Pittman's July 2022 company newsletter expressly welcomes Laura as the first angel investor and also credits her prior Launchpool and GamiFi work. Those records establish a disclosed relationship. They do not say she runs Ireland Esports Leagues, the Schools Series, the Company's data systems, or every subsequent financing and marketing decision.

- Current official team: https://www.nativzgaming.com/our-team — `historical retrieval`, Laura line 47.
- Dated issuer newsletter: https://www.nativzgaming.com/p/newsletter-09-07-22 — `historical retrieval`, 9 July 2022, investment lines 22 and 31.

## Syndika

Laura's own public repost contains Syndika's welcome statement and her acknowledgement. The statement anticipates advice to portfolio companies but does not identify completed client engagements, remuneration, equity, signing powers or trading mandates. Its rendered timestamp is only “3y.” Both the current homepage and full syndicate page were checked; the latter returned no matches for either Laura or Walsh. Treat the role as historical with current status unconfirmed, not as a demonstrated resignation.

- Issuer statement embedded in Laura's repost: https://www.linkedin.com/posts/lauralwalsh_more-than-thrilled-to-be-a-member-of-syndika-activity-7087741668275208192-JAri — `historical retrieval`, `historical retrieval`, `historical retrieval`.
- Current full roster: https://syndika.co/syndicate/ — `historical retrieval`; negative text checks `historical retrieval` and `historical retrieval`.
- Current homepage: https://syndika.co/ — `historical retrieval`.

## Techstars: firmer independent attribution

The official 2023 All-Star Mentor announcement, published 19 February 2024, lists Laura Walsh under Techstars Web3 Accelerator. This is a direct program confirmation, stronger than her own profile headline. A July 2025 retrospective by former program managing director Pete Townsend thanks Laura for helping start the program and for years of support as EiR and All-Star Mentor. It describes integrating Web3 support across Techstars programs. It gives no Laura-specific termination date or current assignment.

- Official award announcement: https://www.techstars.com/blog/impact/2023-techstars-all-star-mentors-named — `historical retrieval`; publication line 9, Web3 list lines 227–235. Old `/innovation-in-action/` URL redirects here.
- Program leader's primary retrospective: https://www.linkedin.com/pulse/techstars-web3s-evolution-my-next-phase-pete-townsend-e6zpe — `historical retrieval`, dated 23 July 2025, Laura line 80.
- Official social award announcement contains Laura's acknowledgement: https://www.linkedin.com/posts/techstars_2023-techstars-all-star-mentors-named-activity-7165465155642871809-25Bt — `historical retrieval`; redundant corroboration, not a separate award.

## Cardano: use the later validated review

The preserved official report extraction contains Laura's name split by a vertical-tab character at line 652, in the mentor list; the report begins with its 27 February 2026 date. The cohort taught in late 2025. Direct retrieval of the report and milestone URLs failed in this pass, so the mentor finding relies on the already retrieved report preserved locally, not a newly completed origin fetch.

- Official report URL: https://milestones.projectcatalyst.io/projects/1300182/milestones/6 (publisher milestone links to the final report)
- Preserved source extraction: `techstars_2025_final_report_extracted.txt`.
- Later validated review: `TECHSTARS_CARDANO_VALIDATED_REVIEW_2026-09-05.md`.

The later review resolves the earlier alleged payment-allocation and cohort-size inconsistencies through approved milestone records. It supersedes the older public-project audit's unresolved-budget wording. No evidence in this role check assigns Laura custody of grant funds, selection authority, program budget control or responsibility for any participant's token trading.

## Retrieval cautions

Common-name results included unrelated Laura Walsh profiles; excluded unless the source linked to the established professional identity. Aggregated people-search contact records were not used. Relative social timestamps, stale profile headers, current footer dates and likes of someone else's post were not treated as precise employment dates or authored work. Consult the cited primary sources when rechecking these findings.
