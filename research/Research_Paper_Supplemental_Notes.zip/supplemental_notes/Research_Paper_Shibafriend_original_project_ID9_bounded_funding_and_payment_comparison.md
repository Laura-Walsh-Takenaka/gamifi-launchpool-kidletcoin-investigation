# Research Paper — Shibafriend original project-ID9: bounded funding and payment comparison

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

The complete configured funding window, BSC blocks **18684400–18766000**, yielded **27 Funding events from 26 funding addresses**. Their contributions total **4,720.231567727363184247 BUSD**, exactly the recorded project total and selected withdrawal. All nine consecutive log-query chunks succeeded; there is no remaining gap in this configured-window census.

This census was compared with the parent investigation's ten outgoing BUSD payments from `0x35b119730f79881dac623dc51c831c6a04cab5f3` in blocks **18908374–19100000**. Those ten payments total **39,970 BUSD** and occurred on June 27, 2022. The money in that wallet was pooled; these payments must not be assigned to Shibafriend merely because they followed its incoming withdrawal proceeds.

There are **two address overlaps and no exact aggregate amount matches**:

| Address | Recorded ID9 contribution, BUSD | Selected June 27 payment, BUSD | Payment transaction |
|---|---:|---:|---|
|`0xd2d686771f2726f827b1d17930fd17dd8df4b7e2`|0.0000000000000001|600|`0x598945e0dd41bec6a316932b77bf41086359c043541b6c6bc772a5f9fce07423`|
|`0xe5d5245dce768ef43f1c5fa9c96b7e1520d96dc8`|1243.781094527363184079|4050|`0x68fc44134dc1fe1a310a7ce10ad25cd202cb71a51ba116cea14729dfe2767963`|

These are accounting intersections. A payment larger than a contribution could include different obligations; the public amounts alone do not establish its purpose. This comparison does not establish a complete or partial Shibafriend refund schedule. The June 29 publisher notice offered private allocation plus 1,000 GMI or a refund; accepted choices, allocations, refund instructions and fulfilment remain unresolved. The comparison neither proves that the original contributions were stolen nor proves that refunds were never made through another route or at another time.

No additional outward-history scan was performed in this lane. The parent supplied the bounded treasury payment inventory. Original contributions, sums and comparison rows are preserved in `shf_funding_logs.json` and `shf_funding_selected_outgoing_reconciliation.csv` / `.json`. Independent Binance receipt verification passed for all 27 funding events: successful status, matching block hash, matching Funding event, and actual BUSD transfer from the funding address to the project contract. The census used Quicknode, and the receipt crosscheck used the Binance public endpoint. All-pass results are recorded in `shf_funding_receipt_verification.json`.
