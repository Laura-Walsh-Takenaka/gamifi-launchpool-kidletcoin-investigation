# Research Paper — Free public-record follow-up: Gamifi Limited, BVI 2082070

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research date: 2026-09-06 UTC. No purchase, account creation, record request or outbound contact occurred. This is a bounded free-source pass, not a complete company-file examination.

## New exact match

The free i-BVI public search returned one match for `Gamifi`. Its detail page displays:

| Field | Displayed value | Evidence quality |
| --- | --- | --- |
| Jurisdiction | British Virgin Islands company | Commercial index statement |
| Entity name | Gamifi Limited | Matches the name visible in the supplied official BVI screenshot |
| Registration number | 2082070 | Exact match to the supplied official BVI screenshot |
| Registration date | 12.11.2021 | Commercial index only; read as 12 November 2021 using the site's day.month.year date format |

Source: https://i-bvi.com/company/gamifi-limited_978843 ; web reference `historical retrieval`, lines 8–14. The final URL was reached through the live site's normal public name-search form and then opened successfully by the web retrieval tool. No cart control was clicked. The web renderer's generic “Document Added to Cart” text is part of its extraction of the template; it is not evidence that a document was ordered.

The site's date format is also visible without ambiguity on another public company page, which displays 26.06.2009 (https://i-bvi.com/company/kingsdan-investment-limited_1162803 ; `historical retrieval`). This confirms the formatting convention only. That other company is not asserted to be related to Gamifi.

The exact entity number makes this a stronger commercial-index match than name-only results. The incorporation date still needs an official certificate or registry report for primary-source verification. The free detail page does not disclose a registered agent, current status, directors, shareholders, or beneficial owners.

## Primary-source search result and access limits

No exact Gamifi Limited/2082070 match was located in the bounded web-index searches of official BVI government, Gazette, Financial Services Commission, or Eastern Caribbean Supreme Court material. This is a search-coverage result, not proof that a notice, court proceeding, filing or company record does not exist.

The Official Gazette's help page states that its native search requires login and that older liquidation/other notices require paid electronic subscription. It describes a free basic subscription retaining Government/Statutory portions after two months. No Gazette account was created and no paid material was accessed.

- Official Gazette help: https://eservices.gov.vg/gazette/content/help-support ; `historical retrieval`, lines 10–12, 21–24, 28–33.
- Official Gazette home: https://eservices.gov.vg/gazette/ ; `historical retrieval`.
- FSC registered-entity search guide: https://www.bvifsc.vg/searches-bvi-registered-entities ; `historical retrieval`. It lists the fields normally included in a paid search report, including date, status and current registered agent. It supplies no Gamifi-specific facts.

## False matches excluded

- The number 2082070 also occurs as a UK company identifier for Novae Syndicates Limited, an unrelated Hong Kong registration for Chen Ke Industrial Limited, product numbers and other record identifiers. No connection to BVI Gamifi is inferred.
- GamyFi Labs Ltd., BVI 2071947, is a different name and number; excluded.
- UK Gamifi Solutions Limited, Indian Gamifi Consulting Services Private Limited, South African Gamifi Industrial Properties and US Gamifi LLC results are not the target company.
- i-BVI's rotating “Get information about these companies” footer is not an ownership, registered-agent or business-relationship statement. Names appearing beside Gamifi in those footers were not treated as connected companies.

## Practical consequence

There is now a free exact-name/number corroboration and a secondary-source registration-date lead. Nothing in this follow-up identifies a bank account, wallet owner, human key holder or personal recipient. No director/agent attribution should be made from these results.
