# Research Paper — GamiFi contract-control chronology — 6 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

## New verified transactions

BNB Smart Chain, chain ID 56. Exact transaction objects and successful receipts were obtained from https://bsc-dataseed.bnbchain.org. The upgrade event topic is `0xbc7cd75a20ee27fd9adebab32041f755214dbc6bffa90cc0225b39da2e5c2d3b`.

| UTC | Action | Block | Transaction |
|---|---|---:|---|
| 2022-04-19 13:16:18 | Deploy current vesting implementation `0x7ed8022c43ab08e79c79addd8a7e5427aaa52250` | 17082298 | `0xef89c5f6b43f8ecc4aaf95286916f39d0dabd06a3b10f4c36b09cd19c476c2d7` |
| 2022-04-19 13:16:42 | Upgrade vesting proxy `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb` to `0x7ed8022c43ab08e79c79addd8a7e5427aaa52250` | 17082306 | `0x963741dcdeacc8a278325816da43502af75025b91478554781de533b501cf46e` |
| 2022-08-25 06:55:32 | Deploy current Duke implementation `0x1979dac9cff265bd446d08b5a162c05e417196e2` | 20743827 | `0xd98ec441ce0ac50266c7517359f608d060fe679a0dbaa11ed2f4d58fd14e438b` |
| 2022-08-25 06:55:47 | Upgrade Duke proxy `0x3e5ff726d5026488e58619b21215c7902cc34a98` to `0x1979dac9cff265bd446d08b5a162c05e417196e2` | 20743832 | `0x518565fd8433db6179ed2eed06e4ceb981bf499ae16f2fa980384573ba50ef0c` |
| 2022-08-25 06:55:59 | Deploy current Mystery implementation `0xced850373d573b58d2494c41f04d1fe34b965dfe` | 20743836 | `0x8749f2f6c50fb0b441adb493f25a3e3eb7ea7d441b73a83d7f5c1a528ed0a12a` |
| 2022-08-25 06:56:11 | Upgrade Mystery proxy `0x0169057ff42652f919456dce4424d9881daed399` to `0xced850373d573b58d2494c41f04d1fe34b965dfe` | 20743840 | `0xdd7c15e21b5908e100a1d2b38dbf841f11c7e8bbd63e46e73f18f5d13962cef5` |

All six transactions were sent by `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`. All three upgrade calls targeted ProxyAdmin `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475`, carried `upgrade(address,address)` calldata, succeeded with status `0x1`, and emitted `Upgraded` on the expected proxy for the expected new implementation. The vesting upgrade was 6 minutes 3 seconds after the original proxy deployment and precedes the sampled beneficiary schedule starts.

The successful calls prove that the sender exercised this upgrade path on those dates. They do not establish uninterrupted control between observations or identify who held its private key. An implementation update is not in itself evidence of wrongdoing.

## Initial control and present control are different observations

Existing deployment receipts in `contract_links` show vesting, Duke, Mystery and their shared ProxyAdmin were initialized with owner `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`.

Initial Duke implementation was `0x47d24bfa8b63d15b25de4ebc4308e5a2a39370be`; initial Mystery implementation was `0x9a6520867d44a648b954a4a13297dd2fb62a807f`. These were replaced by the implementations recorded above at least on 25 August 2022. No complete intervening upgrade history is claimed.

Current readings already independently established owner `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b` for vesting/Duke/Mystery. The present lane rechecked the shared ProxyAdmin's owner at block **120222531 (`0x72a7343`)**: `0x538a8b615e98e87d025c4336be44e4b8588277c7`.

An additional current connection was found: the **former GMI token ProxyAdmin**, `0xd3b3024bc9059d630e1058154b1d02412143a412`, returns **`0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`** from `owner()` at that same pinned block. The current GMI proxy admin is already known to be `0xf27...` directly, so the former ProxyAdmin contract should not be described as the current token upgrade administrator.

The original GMI mint/deployment and its two 18 January 2022 upgrades had a **different sender**, `0x0d2c8df71c846d0dbc9c8bc75ea39c45d5197dca`, and used the former ProxyAdmin above. This is visible in existing primary receipts at *Historical file: upgrade_transactions.json*. The common `0x3e0f...` deployment finding applies to vesting/NFT contracts, not original GMI deployment. A current code check of `0x0d2c...` returned `0x`; no natural-person attribution follows.

No exact later ownership-transfer transaction was obtained for either owner change, or for the GMI proxy administrator change. Their dates remain unresolved. Do not assign these changes to Laura or infer her personal receipt of any funds. The parent lane observed delegated-code bytes at `0x3e0f...` today, so do not describe that address as currently having no code.

## Bounded discovery and completeness

The public repository manifest supplied the current vesting implementation's creation hash. A 12-block window beginning at block 17082298 revealed its upgrade call. Sourcify APIv2 supplied the two NFT implementation creation hashes and block numbers. Their receipts were independently checked against the BNB Chain RPC. A 30-block window beginning at block 20743827 revealed both exact NFT upgrade calls.

The saved `*_matches.json` files contain only transactions matching a fixed watch set of seven project/control addresses. Full raw block responses retain provenance; empty blocks in these small windows are not evidence of absence of activity elsewhere. Broad ownership logs were unavailable. BscScan HTTP requests returned 403; drpc/publicnode calls returned 403, llamarpс 502. No large chain sweep was attempted. Exact transaction receipts, not failed explorer pages or search absence, substantiate the findings.

BNB Chain's official documentation confirms `eth_getLogs` is disabled on its listed public mainnet endpoints: https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/json-rpc-endpoint/

Sourcify's documented selective-field API: https://docs.sourcify.dev/blog/apiv2-lookup-endpoints/

Exact public discovery URLs:
- https://raw.githubusercontent.com/sheandev/gamifiContracts/main/.openzeppelin/unknown-56.json
- https://sourcify.dev/server/v2/contract/56/0x1979dac9cff265bd446d08b5a162c05e417196e2?fields=deployment
- https://sourcify.dev/server/v2/contract/56/0xced850373d573b58d2494c41f04d1fe34b965dfe?fields=deployment

## Suggested compact evidence selection

Include this file, `head.json`, `old_gmi_proxyadmin_owner.json`, `nft_proxyadmin_owner.json`, `old_gmi_deployer_code.json`, `vesting_current_impl_creation.json`, `vesting_upgrade_receipt.json`, `duke_upgrade_receipt.json`, `mystery_upgrade_receipt.json`, `duke_impl_creation_receipt.json`, `mystery_impl_creation_receipt.json`, the two matching Sourcify deployment JSONs, `vesting_upgrade_matches.json`, and `nft_upgrade_matches.json`. For full raw block corroboration include blocks 17082298, 17082306, 20743827, 20743832, 20743836 and 20743840. All request/response files record endpoint, request, and retrieval time.
