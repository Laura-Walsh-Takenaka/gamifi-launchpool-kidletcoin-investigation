# Research Paper — Panama follow-up: primary company and resident-agent record found

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

## Exact public-registry result
On 6 September 2026, the official Registro Publico de Panama resident-agent portal at https://registro-publico.gob.pa/aresidente/ returned this row after the agent-name search QUIJANO and visible result filter CARAJO:

| Official column | Displayed value |
|---|---|
| Agente Residente | QUIJANO & ASOCIADOS |
| Estado agente | Renuncia |
| Nombre de la Sociedad | ASOCIADOS CARAJO INC |
| Tipo de Organizacion | SOCIEDAD ANONIMA |
| Folio | 155733022 |
| Estatus del Folio | Vigente |
| Fecha de Inscripcion | 02/02/2023 |

This establishes a primary public-registry company/folio match and a recorded resident-agent relationship with Quijano & Asociados. The agent's displayed status is Renuncia (resignation); do not describe Quijano as the current agent without that qualification. The folio separately displays Vigente. No resignation date, successor agent, director, shareholder or beneficial owner is shown. The date column says only Fecha de Inscripcion: report the displayed registration date; do not claim the page specifies whether it is incorporation or agent-association entry.

The browser observation is primary evidence but is not a certified company extract. Preserved resident_agent_carajo_dom.txt, resident_agent_carajo_rendered.html, resident_agent_carajo_observation.json and resident_agent_carajo.png. Screenshot was inspected and matches the DOM. The raw rendered HTML contains the page state at capture, not a fresh unauthenticated HTTP response.

## Other official access attempts and limits
- https://www.rp.gob.pa/ rendered the official Servicios Web sign-in page. A username/email, password and reCAPTCHA are required before services; no company/folio search was visible before login. No login, account creation or CAPTCHA interaction was attempted. Preserved registry_login_dom.txt.
- The initial resident-agent query took time to return. Early form-only observations were inconclusive. During preservation, results had loaded: resident_agent_form_dom.txt shows the unfiltered first page; the subsequent CARAJO filter yielded the exact company above. This supersedes the initial inconclusive observation.
- https://www.gacetaoficial.gob.pa/busqueda-avanzada: a Titulo search for ASOCIADOS CARAJO returned the rendered message 'No se encontraron resultados para los criterios de búsqueda especificados.' This is a title-search result only, not a full-text Gazette search or evidence the company was never registered. Preserved gazette_title_search_dom.txt. The separate urllib GET returned HTTP200 but an Incapsula 'Request unsuccessful' response, retained honestly in gazette_search.html/txt; the rendered browser observation is the actual search evidence.

## RUC format background
The official registry page https://registro-publico.gob.pa/descargarfoliossuspendidos/ describes the post-21-October-2014 company RUC format as FOLIO-2-AAAA for specified company types. The claimed RUC 155733022-2-2023 is from Persono and is consistent with a 2023 year; the format itself does not independently authenticate that RUC. This format page is on a suspended-folios resource: no statement that the subject company appears in those lists is made.

## Unresolved at this historical stage
At this early stage, no company-specific certified registry extract, pacto social or registered amendments had been obtained. The later deed review supersedes the document-availability part of this gap. Those would be required to establish the precise incorporation entry, directors/officers, registered-agent resignation date and successor, and any formally disclosed shareholding. Director or resident-agent titles are not proof of shareholder or beneficial ownership. No inference about Laura, the associated individuals in Persono, or ultimate owners follows from the row.

## Preservation
Raw downloads preserve response bytes and metadata. Rendered DOM/HTML and screenshot preserve the live public UI state. Access observations are current as of accompanying timestamps. SHA256SUMS.txt covers all evidence files except itself.

Subsequent evidence: the supplied folio and entry printouts supply additional displayed governance and deed-reference fields. See the consolidated report S39–S41 and registry_printouts. Later research obtained and examined deed copies; consult the consolidated Launchpool and Panama reports for those later findings.
