# Research Paper — Kaskade: two additional April 17 reward claimants

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Observed 5 September 2026. This one-hop follow-up verifies the source of the two external LUSD inflows documented in `KASKADE_COLLECTOR_INBOUND_SUPPLEMENT.md`. It does not expand the original nine-wallet trading reconstruction.

**Both additional senders claimed the exact subsequently forwarded amount from the same distributor, `0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B`.** Their immediately preceding outgoing normal transaction was a Claim call; individual receipts independently confirm successful canonical-LUSD transfers from that contract.

| Claimant | Claim UTC on April 17, 2024 | Exact LUSD claimed | Claim receipt / block | Exact-amount forward |
|---|---|---:|---|---|
| `0x64bc278b28DCdfC2F1cB2f90dc62e03e02D2f09a` | 14:53:59 | 807.403300464772513792 | [19675917](https://etherscan.io/tx/0xe75a96480f9aa16c11951ac4b638535e5359c54eeaf14c95d6b7b3ffdda5d796) | [14:54:59](https://etherscan.io/tx/0x601d0155d8edfcf11b7483b1035a4907001c1f9ba597c552a4e73dee2043e37f), 60 seconds later |
| `0x0ad9f1027a77519f3D6eD6Aeeb24cf6e76c774A6` | 14:56:35 | 809.65515205510955008 | [19675930](https://etherscan.io/tx/0x0173429cbf2317bd73221846d0e2f5e4f2de5a3ab17041aa0e7791b58012dedd) | [14:57:11](https://etherscan.io/tx/0x5fdffda80dea1aff83585a26a5c9cfdbb69183162738b2166960fb255d30c54a), 36 seconds later |

Both forwards go to collector `0x425e16a88a0dAcc38424B7d1F60868d728b46168`. Their claim fees were **0.003937140781826318 ETH** and **0.003811058118496984 ETH**, respectively. Current explorer dollar conversions were not used.

These receipts establish that the extra **1,617.058452519882063872 LUSD** originated in two additional same-distributor claims. Together with the original eight April 17 claims, **ten claimants' receipts total 5,585.449075373668532224 LUSD**, exactly the collector's later conversion input. Their prior trading or qualification for rewards was not reconstructed in this limited check. There is no human-owner attribution.

## Preserve the original sample distinction

| Clearly defined sample | Verified claims | Distinct claimant addresses | Actual LUSD receipts | Share of announced 30,000 LUSD campaign budget |
|---|---:|---:|---:|---:|
| Original nine-wallet reconstruction | 26 | 9 | 21,944.778215493719293952 | 73.1492607% |
| Two additional April 17 claims | 2 | 2 | 1,617.058452519882063872 | 5.3901948% |
| Explicit combined observed receipts | 28 | 11 | 23,561.836668013601357824 | 78.5394556% |

The combined figure covers the original sample plus these two verified claims; it is not a full-history audit of eleven wallets. The original nine-wallet figures and trading calculations remain unchanged. Campaign attribution continues to rely on the distributor/date/leaderboard corroboration established in the main report; the blockchain receipts alone do not state the campaign brand.

Discovery used the two public [64bc normal-transaction](https://etherscan.io/txs?a=0x64bc278b28DCdfC2F1cB2f90dc62e03e02D2f09a&ps=100) and [0ad9 normal-transaction](https://etherscan.io/txs?a=0x0ad9f1027a77519f3D6eD6Aeeb24cf6e76c774A6&ps=100) lists, preserving only the April 17 rows relevant to the claim-forward sequences. The two claim receipts' hashes, block numbers, UTC times, exact amounts, distributor address and canonical LUSD token links were verified.

Evidence: `kaskade_extra_claimants_raw.json` and `kaskade_extra_claimants_decoded.json`. Run `python3 calculate_kaskade_extra_claimants.py` beside the original claim ledger and inbound supplement to reproduce the amounts and timing checks. These two claim hashes are new: original326 receipts + prior3 incoming receipts + these2 claims = **331 distinct reviewed receipts** across the explicitly separated scopes.
