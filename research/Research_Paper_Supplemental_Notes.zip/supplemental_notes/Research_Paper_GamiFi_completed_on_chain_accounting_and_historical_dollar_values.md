# Research Paper — GamiFi: completed on-chain accounting and historical dollar values

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research date: **6 September 2026**. Network: **BNB Smart Chain, chain ID 56**. All times are UTC. This updated report supersedes the earlier selected-transaction report. The accompanying ledger contains **208 material transfer legs across 148 transactions**, plus all **7,495 original funded Launchpool schedules**. Raw receipts, historical contract calls, calculation code and independent accounting checks accompany it.

**Two numerical gaps are closed.** The previously untraced 107.87 million GMI consists of three additional private-vesting claims; all five claims sum to exactly 120 million GMI. Separately, Launchpool's original funded obligations were fully backed immediately before the 5 November 2022 withdrawal. That transaction removed exactly 14 million GMI without reducing any of the 7,495 obligations, creating a 14-million-GMI deficit. The same exact deficit is present at the pinned September 2026 observation.

**The human and banking links remain unproved.** We can identify signing keys, token recipients, swaps and exchange-wallet leads. No verified public evidence located here identifies the human owners of the critical wallets, a Cayman bank account, or a personal receipt by Laura. Public blockchain data cannot supply an exchange's private customer ledger.

| Finding | Established amount | Historical dollars / interpretation |
|---|---:|---|
| Complete private allocation paid out | 120,000,000 GMI in five claims | Claim-time marginal marks total US$22,859.76 / C$30,902.87; not cash proceeds |
| Private beneficiary's direct GMI sales | 42 sale outputs across four assets | Gross received-asset value US$10,226.39 / C$13,755.46; not profit or bank cash |
| Private route into MEXC-associated wallets | 18,000,000 GMI in four sweeps | Arrival-time marginal marks total US$2,153.25 / C$2,906.98; exchange sales unproved |
| Launchpool backing deficit created 5 Nov 2022 | 14,000,000 GMI | Withdrawal-time marginal mark US$2,675.88 / C$3,616.99; not a dollar-loss calculation |
| Combined sale of Launchpool's 14m and two other contracts' 30m | 5,174.293394005109506048 BUSD | Actual on-chain output; US$5,174.14 / C$6,993.89 |
| Seven earlier project-contract withdrawals | 63,001.817377359365034843 BUSD | US$63,019.16 / C$79,740.69; purpose and entitlement unresolved |

A market mark multiplies quantity by a historical marginal price. It does not establish investment, realizable liquidation value or cash received. Sale proceeds are actual received cryptoassets converted at their own transaction dates. Repeated hops, liquidity inputs, LP shares, redemptions and later conversions overlap. **Do not add these categories into a grand total or an alleged loss.** Dollar figures are gross of transaction gas costs.

**Launchpool: all original funded obligations reconciled**

Thirty-nine funding transactions on 19 April 2022 created 7,495 schedules for 7,490 distinct addresses, totaling **15,456,885.882908530406846 GMI**. The opening 10 GMI created two 5-GMI records; the remaining records match the decoded bulk funding inputs. The sum of the deposits' individual historical marks is US$213,274.65 / C$269,237.92, not cash raised.

| Observation | Unpaid original schedules, GMI | Vault balance, GMI | Backing deficit, GMI |
|---|---:|---:|---:|
| Immediately before withdrawal, block 22,786,455 | 14,923,065.568267084392219941 | 14,923,065.568267084392219941 | 0 |
| Immediately after withdrawal, block 22,786,456 | 14,923,065.568267084392219941 | 923,065.568267084392219941 | 14,000,000 |
| 6 Sep 2026 04:08:52, block 120,235,949 | 14,000,207.412329404181026961 | 207.412329404181026961 | 14,000,000 |

Every complete vesting record is byte-identical immediately before and after the withdrawal. Before it, aggregate claimed counters were **533,820.314641446014626059 GMI**. At the current observation, aggregate claimed counters are **1,456,678.470579126225819039 GMI**. All original schedules had matured by 14 January 2023 at 17:29:53 UTC.

The current identity is exact in integer token units:

**15,456,885.882908530406846 funded − 1,456,678.470579126225819039 claimed − 14,000,000 removed = 207.412329404181026961 held.**

Independent decoding of all funding inputs and historical/current records found no amount, owner or nonce mismatch. Current non-claimed fields match their earlier values; claimed counters only increase. Of the 7,495 schedules, 684 show claims: 290 fully claimed, 394 partially claimed, and 6,811 never claimed.

This closes the **aggregate accounting of the original funded book**. It does not constitute a dated census of every intervening token movement, rule out offsetting intermediate refill/withdrawal cycles, or cover hypothetical records for wholly different unfunded addresses. Equal deficits at two observations do not prove the deficit was constant at every intervening block.

The selected 587,755.519557566-GMI allocation requires a separate timing distinction. Immediately after the November withdrawal, the vault could still cover that one allocation, although the full funded book was already short. On **24 January 2023 at 15:45:16**, a normal claim of **8,309.56763892731 GMI** lowered the vault from **591,902.853950097638463553** to **583,593.286311170328463553 GMI**, below the selected still-unclaimed allocation. The [receipt](https://bscscan.com/tx/0x7f556eb1d5da208355961506485c529d11ee850d5ebf136188a9a5e20dc202e5) and before/after balances verify this crossing. Its claim-time mark was about **US$0.75 / C$1.00**. It is a documented crossing, not a proven first-ever crossing.

**How the November tokens left the vesting contracts**

The Launchpool vesting implementation active before the November changes had no ordinary owner-withdrawal function. The historical transaction shows a different mechanism: administrative control temporarily changed the implementation, granted a spending allowance, and restored the original implementation. A later transaction used that allowance to transfer tokens out. Restored code alone would not reveal the earlier permission grant.

| 5 Nov UTC | Verified action | Evidence |
|---|---|---|
| 06:14:38 | Three proxies temporarily upgraded to 0x1ee3…e6fb; each grants maximum GMI allowance to Safe 0x9362…25f3; original implementations restored. | [transaction](https://bscscan.com/tx/0x4af5d1dccd4008191749c6f193b552edd4e2d10d96028661eed4d508b8901a63) |
| 06:45:09 | 23m + 14m + 7m GMI transferred from three contracts into 0x35dc…5422 using transferFrom. | [transaction](https://bscscan.com/tx/0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48) |
| 06:45:39 | Withdrawal executor 0x343c…235e sends 0.019849782233850894 BNB to 0x35dc…5422 for subsequent activity. | [transaction](https://bscscan.com/tx/0xb954f172ba0faed75a15967fce0e72a52ee674fd585d9d1e5385199c72f82a17) |
| 06:51:21 | All 44m GMI sold through router 0x1111…097d; 5,174.293394005109506048 BUSD received by 0x35dc…5422. | [transaction](https://bscscan.com/tx/0x7096720b8dc95afac5ad1029a489ce8dd2b2dcb5ff78e960fcb5e10d03acd8aa) |
| 07:15:11 | 5,174 BUSD sent from 0x35dc…5422 to 0x96f0…aeb6. | [transaction](https://bscscan.com/tx/0x34bfa37b43fc0426e45ffcd3af9927be6495d4710f340f7f80e09d2fc41fe1b4) |
| 07:15:20 | 0x4727…7c95 funds 0x96f0…aeb6 with 0.00084 BNB. | [transaction](https://bscscan.com/tx/0xfce9f602e9b578c45f056eaa29343e0932d46f796d3fcb9a9b2dc326e1367a7a) |
| 07:15:32 | The same 5,174 BUSD moves from 0x96f0…aeb6 to 0x4727…7c95. | [transaction](https://bscscan.com/tx/0x7702b5e67906c5eb1dea5d1fdde0f7ade3e37cb5cd657944bd539ed460791e48) |
| 07:15:41 | Remaining 0.000502984 BNB swept from 0x96f0…aeb6 back to 0x4727…7c95. | [transaction](https://bscscan.com/tx/0xfc4c26165b9fad6ae7aa5c69b0763f4bed1af11f97ecebb9112793ca121303c4) |

The original receiving wallet retained 0.293394005109506048 BUSD and no GMI at the checked later state. The two intermediary wallets' subsequent top-level transactions were accounted for using their nonces and receipts. Swap-routing intermediate WBNB/BUSD legs are preserved in the evidence but excluded from ledger endpoint totals to avoid repeated counting.

[Etherscan's current label](https://etherscan.io/address/0x4727250679294802377dd6ca6541b8e459077c95) calls the final address “FixedFloat: Hot Wallet” and attributes the label to the hildobby compilation. That is an Ethereum explorer label for the same address, not first-party confirmation of its November 2022 BSC role. The gas-funding and immediate-sweep sequence is consistent with a service collection process; that is an inference. A specific customer, conversion order, payout asset, destination chain, final withdrawal and bank account remain unknown.

**Which keys authorized it**

Historical Safe owner/threshold calls and cryptographic recovery of the transaction signatures agree:

| Role | Safe / administrator | Signing address | Required signatures |
|---|---|---|---|
| Permission grant | 0x6bf55810ab061a016a968016818a6e1246aa8b5a | 0x538a8b615e98e87d025c4336be44e4b8588277c7 | 1 of 1 |
| Three token withdrawals | 0x9362ced428b4179650252ad87731240b32ef25f3 | 0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9 | 1 of 1 |

The approval signer authorized two Safe calls; the withdrawal signer authorized three. Both Safes pointed to the Safe 1.3.0 L2 singleton whose runtime matched the official deployment artifact. These were single-owner smart accounts at the relevant blocks; the word “Safe” does not establish approval by several people. The transaction submitter paying gas was a separate address, not automatically the owner of the signing key.

Safe 0x9362…25f3 changed its sole owner from 0x7e01…7445 to 0xafd9…c3f9 on **19 September 2022**, transaction [0x958512…](https://bscscan.com/tx/0x958512439479d367fc0afd13e8928f810dfe40b4945b084bc51fffedc5b9627b). The approval Safe was created by its sole owner 0x538a…7c7 on **4 November 2022**, transaction [0x2ecfae…](https://bscscan.com/tx/0x2ecfaeb4b20fedb2a1d0fd838c01cc9e26e898c48284d74062898861eab1bda5). No verified public evidence identifies the humans controlling these keys.

GamiFi [announced Eleanor Rooney as CEO on 1 September 2022](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147), thanking Laura for her prior leadership. That announcement precedes the September owner change and November transactions. Neither Laura's earlier role nor Eleanor's later title identifies either person as a signer or establishes personal responsibility for these transfers.

GamiFi's [3 October 2022 update](https://gamifi-launchpad.medium.com/gamifi-update-f8d6326f1780), signed by Eleanor Rooney as CEO, announced a pause in IDOs and reduced activity focused on GMI performance. This is operating context, not transaction-specific authorization for the November withdrawals.

**Private vesting: all 120 million GMI and the beneficiary's token balance**

On **18 January 2022 at 15:56:50**, the original GMI deployer funded 120,000,000 GMI for beneficiary **0x36048413c4edf0cf3e633aab317fcd9824dfb4d4** in private vesting contract **0x74e0ddf89807107378beb02e6bc504243e0cdf6c**. The [funding transaction](https://bscscan.com/tx/0xac39350f0f652c95dfb73e0cd8f2028a2c8aa34a51d081374a6c850647625787) sets zero initial release, zero cliff and 360-day linear vesting. Category 5 has no human-readable definition in the verified implementation; it cannot identify the allocation as a particular person's, team's or investor's property.

At funding, multiplying the marginal token quote gives **US$5,769,088.34 / C$7,228,090.79**. The pool held only about **3.983m GMI and 413.8 WBNB**. This highly theoretical mark is not evidence of a multi-million-dollar payment or realizable sale.

All five successful payout receipts are now reconstructed:

| UTC | GMI | Historical US$ mark | Historical C$ mark | Receipt |
|---|---:|---:|---:|---|
| 2022-11-04 14:25:40 | 96,645,563.271604938271604938 | 21,061.17 | 28,468.38 | [transaction](https://bscscan.com/tx/0x6f2c3e43f94de965feaf666ad8a35a6951c72a9367360d9dc138d236902e787f) |
| 2022-12-06 10:46:01 | 10,615,821.759259259259259259 | 756.09 | 1,031.99 | [transaction](https://bscscan.com/tx/0xf692b324a95a159bd4c5142cd7eed711211ac0b4e85912fa336cfde0ca961453) |
| 2022-12-08 06:32:39 | 608,016.975308641975308642 | 59.66 | 81.03 | [transaction](https://bscscan.com/tx/0x325e3df49c8f81d74d5343bff786dd8d08f4996d798cefff4a31dcbf8e4b1078) |
| 2022-12-14 16:01:19 | 2,131,635.802469135802469136 | 171.20 | 232.17 | [transaction](https://bscscan.com/tx/0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639) |
| 2023-01-20 05:38:45 | 9,998,962.191358024691358025 | 811.64 | 1,089.31 | [transaction](https://bscscan.com/tx/0x8657b3b3182771a12734fa434536f6f2a667246a2f94998546da301f7e464f3d) |

The first three rows are the previously unresolved **107,869,402.006172839506172839 GMI**. Their individual claim-time marks sum to **US$21,876.92 / C$29,581.40**. Including the two previously studied payouts gives exactly **120 million GMI**, with claim-time marks totaling **US$22,859.76 / C$30,902.87**. Claims and later sales are different events and must not be summed.

The beneficiary's reconstructed GMI balance also closes exactly from immediately before the first November claim through its last February 2023 disposal:

| GMI entering beneficiary | Exact GMI | GMI leaving beneficiary | Exact GMI |
|---|---:|---|---:|
| Five vesting claims | 120,000,000 | Direct GMI sale inputs | 103,642,447.956409389183293472 |
| Tokens returned from liquidity positions | 29,574,727.895903672410206412 | Tokens contributed to liquidity | 27,942,179.939494283226912940 |
| Separate incoming transfer | 9,900 | Forwarded to exchange intermediary | 18,000,000 |
| **Total in** | **149,584,627.895903672410206412** | **Total out** | **149,584,627.895903672410206412** |

Opening and ending GMI balances are both zero. The separate 9,900-GMI receipt is [transaction 0x782a…de7ae](https://bscscan.com/tx/0x782a3cb1e15038899222d883a233bcf031c20236ba0b8a3f8584052d799de7ae), from 0x391a51d884b240908a88e1e757ec42189d294423. Liquidity tokens were mixed with the vested allocation; individual fungible units cannot be labeled as uniquely belonging to one source after mixing.

The 42 direct GMI sale outputs are:

| Asset actually received | Exact quantity | Historical US$ | Historical C$ |
|---|---:|---:|---:|
| BNB | 12.733084792018608967 | 3,993.65 | 5,359.27 |
| WBNB | 2.296091425541797281 | 820.80 | 1,109.48 |
| BUSD | 5,361.649777056501864007 | 5,362.44 | 7,219.59 |
| CAKE | 13.065639141470576526 | 49.50 | 67.13 |
| **Gross output value** | Different assets; no unit total | **10,226.39** | **13,755.46** |

This total includes the earlier five selected sales worth US$756.14 / C$1,021.91; those five are not additional proceeds. It measures cryptoassets received, not profit, a bank withdrawal or Laura's income.

Three liquidity additions also supplied **11.779827980541797281 BNB gross**; trace-verified refunds totaled **0.000000000000000003 BNB**, giving **11.779827980541797278 BNB net supplied**. Two redemptions returned **11.149287235974376070 BNB** alongside the GMI shown above. Received and redeemed LP shares total **9,177.891351247917090180 LP**. These position movements are separate from the 42 direct-sale receipts and cannot be added as additional sale profit.

**Correction to the earlier selected report:** the later CAKE transaction was related to the GMI route. A GMI sale received **13.065639141470576526 CAKE**, then [transaction 0x30c5…aca71](https://bscscan.com/tx/0x30c5e3af5fa69cf54e59ec46a3cf3c74ffea59cd3e795cf6aa8923b6482aca71) converted that CAKE into **49.354088681602483584 BUSD**. The CAKE receipt is already included in the direct-sale total. Its later BUSD conversion is shown separately, not counted again as new GMI-sale proceeds. A failed GMI swap remains excluded from financial transfer totals.

All **100 normal transactions sent by the beneficiary**, nonces 0–99, were recovered and receipt-checked. They span 1 February 2022 through 4 April 2023; the nonce remained 100 at sampled block 120,238,607. Nine failed transactions contribute no completed asset flows. This completes the normal sender inventory through that observation; it does not establish a complete census of third-party incoming transfers or internal native funding.

The **5,361.649777056501864007 BUSD** received in GMI swaps plus the later **49.354088681602483584 BUSD** from the CAKE conversion total **5,411.003865738104347591 BUSD**. That equals exactly the ten BUSD transfers to **0xf4f86e37815217ed73ae817a4e5164d56315b1d7**. Their individual forwarding-date marks total **US$5,411.28 / C$7,278.79**. This is an aggregate flow reconciliation, not additional income or identification of the recipient's human owner.

An earlier separate 2,000-BUSD transfer on 11 March 2022 went to 0x391a51d884b240908a88e1e757ec42189d294423. Seven normal native transfers also sent **27.336801380291603498 BNB** to 0xf4f8…b1d7. Those native balances were commingled with liquidity returns and external funding; the full BNB forwarding amount cannot be assigned to GMI sale income. The **2.296091425541797281 WBNB** sale output was later unwrapped into the same quantity of BNB, an overlapping conversion preserved separately in the ledger.

**Expanded exchange route: 18 million GMI**

Four token transfers from the beneficiary passed through **0x9564f530d9f270a48c510a92c97b59248cefd464** and then arrived at two exchange-associated wallets:

| UTC | GMI | Historical US$ mark | Historical C$ mark | Receipt |
|---|---:|---:|---:|---|
| 2022-11-04 15:00:29 | 5,000,000.000000000000000000 | 877.32 | 1,185.87 | [transaction](https://bscscan.com/tx/0x7f8323049c6585d0dee94b8ba6b7dcb96d9bd0f2ac11617a00ca2299cb7ae3a8) |
| 2022-11-08 17:48:21 | 5,000,000.000000000000000000 | 576.08 | 774.31 | [transaction](https://bscscan.com/tx/0xb0b3bf6768b4cb92820c90c4aca9a2103e3b49c753b31bf6258916b3dab5855c) |
| 2022-12-08 02:27:14 | 5,000,000.000000000000000000 | 467.87 | 635.46 | [transaction](https://bscscan.com/tx/0xff3ac1adab98247b4a1c468612618e00f322c6a7ab66b3b9825150a7f7aa4d8f) |
| 2023-01-21 02:34:05 | 3,000,000.000000000000000000 | 231.98 | 311.33 | [transaction](https://bscscan.com/tx/0x2e371d5d37cc3deaef36f8c4798f0a18256257304d8eb4db697e6b4414cec02e) |

The first three transfers total **15 million GMI** into **0x2e8f79ad740de90dc5f5a9f0d8d9661a60725e64**. Current [MEXC proof-of-reserves disclosures](https://www.mexc.com/nb-NO/proof-of-reserve?page=34), successfully retrieved through search indexing, list that exact address; explorers also label it MEXC 5. Direct page opens did not return the same address data. This establishes a current public association; historical custody and customer credit on the 2022 dates still require confirmation.

The January **3 million GMI** arrived at **0x4982085c9e2f89f2ecb8131eca71afad896e89cb**, which MEXC identified as its BSC wallet in its [own July 2021 disclosure](https://mexcglobal.medium.com/recent-rumors-against-mexc-global-clarified-7205e6828907). The four arrivals' marginal marks total **US$2,153.25 / C$2,906.98**. No exchange sale at those prices, credited customer or fiat withdrawal is established. Sharing an intermediary does not prove all four deposits belonged to the same exchange account.

**Project-contract stablecoin withdrawals and shared operational links**

The archived official application identifies project contract 0x56c0…46c7f. Seven successful receipts show withdrawals totaling **63,001.817377359365034843 BUSD**, historically marked at **US$63,019.16 / C$79,740.69**. Their sum reconciles to the nine current project records' funded-total counters. That is not a lifetime audit of investor deposits or company revenue.

| Project ID | UTC | BUSD | US$ mark | C$ mark | Recipient | Receipt |
|---|---|---|---|---|---|---|
| 1 | 2022-03-10 15:25:05 | 252.5 | 252.51 | 322.61 | 0x8fea0bb760218398d32d4a9ef18553c403e3c2a0 | [receipt](https://bscscan.com/tx/0x4b0b66e2f020479b6381a1b31be240bfb86347cf1813ddb520c094576e6158df) |
| 3 | 2022-03-11 09:35:55 | 110 | 109.99 | 139.91 | 0x8fea0bb760218398d32d4a9ef18553c403e3c2a0 | [receipt](https://bscscan.com/tx/0x4389510604c93f928c4e1a2f6fda07979d792228de1b6bb66a8242a7a7ee05b5) |
| 7 | 2022-03-18 06:58:39 | 23722.715761539594859905 | 23,730.18 | 29,940.37 | 0xd2b806f9c0352a267ce7ccf33e74d68c070d6171 | [receipt](https://bscscan.com/tx/0xa68d28501388dd1939659be1a24f6fbed8c0c22d6df5bbe43196ff408b3ffba4) |
| 6 | 2022-03-18 12:23:52 | 28421.141280969119319259 | 28,430.09 | 35,870.24 | 0x56aa83035aea8bfeb9e395a51607cc4621649aa2 | [receipt](https://bscscan.com/tx/0x4e2b2cebb9895bb8ed1ffa817e730273d9271e97e559a2fdd7ba2d4e86fd5299) |
| 4 | 2022-03-23 14:58:07 | 2000 | 2,000.00 | 2,514.20 | 0x35b119730f79881dac623dc51c831c6a04cab5f3 | [receipt](https://bscscan.com/tx/0x33f6c2ae7893cf8763b5306d4220780592390cc22ab9399034f4b3ac6ee09683) |
| 8 | 2022-05-23 11:50:16 | 3775.228767123287671432 | 3,775.69 | 4,843.83 | 0x56aa83035aea8bfeb9e395a51607cc4621649aa2 | [receipt](https://bscscan.com/tx/0xfb51cbbf265af6b604ba3499d1608f36ab04a57eb3a71a4d5cbe3c6fe807d780) |
| 9 | 2022-06-22 08:29:58 | 4720.231567727363184247 | 4,720.69 | 6,109.52 | 0x56aa83035aea8bfeb9e395a51607cc4621649aa2 | [receipt](https://bscscan.com/tx/0x757fe0ce1d898fff34b0d4c4f58f2fc7610d3821eacc51c43d7e7e6ac0edcf63) |

IDs 6–9 account for 60,639.317377359365034843 BUSD. The earlier IDs 1, 3 and 4 account for 2,362.5 BUSD and should stay separate until their purposes are documented. Project names, commercial purpose, contractual entitlement and recipient ownership have not been independently established.

The same address **0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199** initiated withdrawals for IDs 4, 6, 7, 8 and 9 and funded the Launchpool vesting contract. It received **15,456,876 GMI** from **0x78d09e1435e1906878621bcb0aaa9d47561214c3** at 13:32:12 on 19 April, [receipt](https://bscscan.com/tx/0x00f1ad6f5d7560d5325d08d0afcf253a99b46d588a6509abb37349bacdea965f). Later that day, 39 deposits moved 15,456,885.882908530406846 GMI into Launchpool, including an initial 10 GMI transfer. The bounded upstream history also contains a 5 GMI transfer; these are not a full funding-wallet balance reconciliation.

Recipient **0x56aa…9aa2** received 36,916.601615819770174938 BUSD across IDs 6, 8 and 9. This repeated recipient and **0xd2b8…6171**, which received project 7's 23,722.715761539594859905 BUSD, are concrete accounting leads. No personal or corporate key ownership has been proved for them.

At the sampled current September 2026 blocks, the project contract owner and the private vesting owner/proxy administrator equal **0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b**, also seen in prior GMI/NFT/Launchpool control checks. Current common control does not prove control by that address throughout 2022–23, and it does not identify a human.

**Contract and address directory**

| Role | Full BSC address |
|---|---|
| Canonical GMI token | [0x93d8d25e3c9a847a5da79f79ecac89461feca846](https://bscscan.com/address/0x93d8d25e3c9a847a5da79f79ecac89461feca846) |
| Launchpool vesting proxy | [0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb](https://bscscan.com/address/0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb) |
| Other November source: 23m | [0xee57b1241f243a1a794f60ffa643d202188d31d9](https://bscscan.com/address/0xee57b1241f243a1a794f60ffa643d202188d31d9) |
| Other November source: 7m | [0xba306306b117a25145d58c67a03deb7f22ee2a3a](https://bscscan.com/address/0xba306306b117a25145d58c67a03deb7f22ee2a3a) |
| ProxyAdmin used in November | [0x6ef316a4e3d378e5b75599daeca94c86d5ce4475](https://bscscan.com/address/0x6ef316a4e3d378e5b75599daeca94c86d5ce4475) |
| Temporary implementation / withdrawal helper | [0x1ee38d535d541c55c9dae27b12edf090c608e6fb](https://bscscan.com/address/0x1ee38d535d541c55c9dae27b12edf090c608e6fb) |
| Combined 44m recipient | [0x35dc4a16db1e30036fee83e733ee065ad8535422](https://bscscan.com/address/0x35dc4a16db1e30036fee83e733ee065ad8535422) |
| November stablecoin intermediary | [0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6](https://bscscan.com/address/0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6) |
| Currently FixedFloat-labeled address | [0x4727250679294802377dd6ca6541b8e459077c95](https://bscscan.com/address/0x4727250679294802377dd6ca6541b8e459077c95) |
| Private vesting proxy | [0x74e0ddf89807107378beb02e6bc504243e0cdf6c](https://bscscan.com/address/0x74e0ddf89807107378beb02e6bc504243e0cdf6c) |
| Selected private beneficiary | [0x36048413c4edf0cf3e633aab317fcd9824dfb4d4](https://bscscan.com/address/0x36048413c4edf0cf3e633aab317fcd9824dfb4d4) |
| Private token intermediary | [0x9564f530d9f270a48c510a92c97b59248cefd464](https://bscscan.com/address/0x9564f530d9f270a48c510a92c97b59248cefd464) |
| MEXC-disclosed wallet | [0x4982085c9e2f89f2ecb8131eca71afad896e89cb](https://bscscan.com/address/0x4982085c9e2f89f2ecb8131eca71afad896e89cb) |
| Additional currently disclosed MEXC wallet | [0x2e8f79ad740de90dc5f5a9f0d8d9661a60725e64](https://bscscan.com/address/0x2e8f79ad740de90dc5f5a9f0d8d9661a60725e64) |
| April onward recipient | [0xf4f86e37815217ed73ae817a4e5164d56315b1d7](https://bscscan.com/address/0xf4f86e37815217ed73ae817a4e5164d56315b1d7) |
| Project contract | [0x56c0cb2d047b69278f49b4759c1718436a546c7f](https://bscscan.com/address/0x56c0cb2d047b69278f49b4759c1718436a546c7f) |

**Remaining ownership and record links: exact targets**

Exact-address public searches and the inspected official deployment scripts did not identify the humans controlling the November signers, the former Safe owner, the transaction executor, the common current contract owner, or the private beneficiary. This is a bounded negative finding, not proof that no identifying record exists. A signature proves use of a key, not a legal name or the signer's commercial authority.

| Record holder / lead | Concrete identifiers | Record needed to resolve the gap |
|---|---|---|
| GamiFi and relevant key custodians | Permission signer 0x538a8b615e98e87d025c4336be44e4b8588277c7; withdrawal signer 0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9; former owner 0x7e0135da76bb6cdb35ac5f1342808925e3ef7445; executor 0x343cebd1e7d1a6838cd8b82f6238b29ad78e235e | Key assignments and handover records; mandates; instructions and approval records for the 19 September owner change and 5 November permission/withdrawal transactions |
| Private-allocation record holder | 120m funding receipt and beneficiary 0x3604…b4d4; current common owner 0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b; onward recipient 0xf4f86e37815217ed73ae817a4e5164d56315b1d7 | Allocation agreement, beneficial ownership and custody records; recipient identification, business purpose and settlement records |
| MEXC | All four dated arrival hashes above, chain ID 56, exact GMI contract, amounts, intermediary and two destination addresses | Historical custody; assigned deposit address and credited account; account authority/identity information actually held; associated orders, fills and withdrawals; record-retention status |
| FixedFloat, subject to historical address confirmation | 5,174 BUSD deposit/sweep on 5 Nov 2022 at 07:15:11/07:15:32; hashes 0x34bfa…fe1b4 and 0x7702…91e48 in the November table; intermediary 0x96f0…aeb6; destination 0x4727…7c95 | First confirm historical service custody/operator; then any order mapping, payout asset/network/amount/address/transaction, refunds and customer or verification information actually retained |
| Project withdrawal recipients / accounting record holders | Seven project IDs and receipts above, particularly repeated recipient 0x56aa…9aa2 and recipient 0xd2b8…6171 | Project identities, funding agreements, invoices, entitlement, settlement and any onward accounting records |

The evidence archive contains a full record-location schedule with complete hashes and addresses. No requests were sent. MEXC's [current law-enforcement guidance](https://www.mexc.com/support/article/law-enforcement-guidelines-4403594593434) restricts its LEORS process to eligible agency/judicial officials and describes formal disclosure and preservation requirements. This is not a public account-lookup tool or a guarantee that historical records remain.

FixedFloat's [guide](https://ff.io/en/blog/guides/how-to-exchange) describes exchanges without registration, so the crucial missing item may be an **order and payout mapping**, rather than a named exchange account. Its [support page](https://ff.io/support) publishes the published organizational contact for law enforcement and the published organizational contact for victims. Any approach must first confirm the address's historical relationship to the service. Amount/timing similarities among pooled-wallet outputs do not prove a particular customer's payout.

No bank document, wire reference, named bank beneficiary or verified Laura-owned receiving wallet was located. Cayman incorporation of an associated entity, if established separately, is not evidence of a Cayman bank account. The September CEO succession neither identifies the November key holders nor, by itself, proves or disproves any former or current executive's involvement.

**Valuation method and reproducibility**

For a transaction in block N, GMI marks use the GMI/WBNB pool reserves at block N−1 multiplied by the Chainlink BNB/USD answer available at that same historical block. This is the previous completed block, not necessarily the state immediately before a transaction within block N. Each row preserves its block, exact token quantity, price and source age. BUSD and BNB proceeds use their own historical USD oracle answers. BUSD is not silently treated as exactly one US dollar.

The main pool is 0x58d4b61983ca0afe6e352e90719f403e24e016f4; BNB/USD feed is 0x0567f2323251f0aab15c8dfb1967e4e8a7d42aee; BUSD/USD feed is 0xcbb98864ef56e9042e7d2efef76141f15731b82f. The [Chainlink API documentation](https://docs.chain.link/data-feeds/api-reference) defines the decimals and historical observation timestamps used. Successful feed-identity responses and compact official-document excerpts are retained.

Canadian-dollar equivalents use [Bank of Canada daily USD/CAD averages](https://www.bankofcanada.ca/rates/exchange/daily-exchange-rates/), taking the previous available business-day observation on weekends and holidays. These are dated daily averages, not transaction-time FX quotes. For example, April 19 uses 1.2624 CAD/USD; November 5 uses November 4's 1.3517; December 14 uses 1.3561. The workbook shows the FX observation date separately.

Price-age limitations matter. The November withdrawal's GMI pool ratio was 15,764 seconds old; the January 20 private claim's ratio was 17,222 seconds old. One June 22 BUSD oracle answer was 79,865 seconds old. They are explicitly identified as then-available marks, not exact contemporaneous exchange fills. A large position can move a shallow pool substantially, explaining why multiplying a marginal quote can exceed actual sale proceeds. The 44m sale's actual BUSD output is therefore the relevant realized on-chain amount.

The workbook preserves exact decimal quantities in text and uses formulas for dollar columns. Spreadsheet numeric precision is limited; JSON/raw integer evidence remains authoritative for exact token units. No total adds across overlapping transfer categories. Each transaction links to its explorer page, while primary RPC receipts and historical calls are preserved in the evidence archive. Some exploratory downloads failed; error responses are not proof of missing transactions.

CAKE outputs use historical Chainlink CAKE/USD feed **0xb6064ed41d4f67e353768aa239ca86f4f73665a1**, with identity and decimals checked. WBNB uses its redeemable BNB underlying mark while remaining labeled WBNB. LP marks use the previous block's reserves and LP supply to value the underlying position; they are theoretical position values, not additional proceeds. The first November private claim used a pool ratio 8,135 seconds old; the January coverage-crossing mark used a ratio 13,519 seconds old. Observation ages are retained in each ledger row.

**Coverage, validation and limits**

- Full private-allocation payout accounting: five successful receipts, exactly 120 million GMI; no reliance on the current claimed counter alone.
- Beneficiary GMI balance accounting: exact zero residual over the reconstructed disposal period, including the separate 9,900-token inflow and liquidity returns.
- Original Launchpool funded book: all 7,495 records checked against decoded funding inputs and archived pre/post/current state. Independent recomputation confirms zero pre-withdrawal deficit and exactly 14 million GMI afterward and at observation.
- A complete dated lifetime Launchpool transfer census remains outside coverage. Current state and bounded historical observations cannot rule out offsetting intervening movements.
- Human ownership, customer credit, off-chain trades, business entitlement, bank records and intent are not established by these numerical reconciliations.

The workbook's exact-text quantities and the raw integer JSON remain authoritative where spreadsheet floating-point precision rounds low-order digits. Reconciliation formulas use visible source balances and link to all original funded schedules. There is no across-category money total. A separate analyst independently decoded the funding and payout evidence and found no material arithmetic errors.

The evidence archive retains the earlier raw record set for provenance and adds this completed investigation, ledger inputs, calculation scripts, historical RPC responses, record-location schedule and SHA-256 manifest. Earlier selected-only findings within the retained evidence are historical snapshots and are superseded by this report. These findings establish token movement, contract mechanics and measured obligations; they do not establish theft, laundering, fraud or a final human beneficiary.
