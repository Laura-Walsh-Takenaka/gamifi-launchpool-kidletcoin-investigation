# Research Paper — MegaFans public-source audit — 2026-09-05

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Temporary research notes for consolidated research; passive reads only. No logins, messages, purchases, intrusive testing, or personal-data collection. Historical disclosures must retain their 2024 date. Laura's advisory affiliation does not establish responsibility for these faults. Notes below group source-derived facts within approximately 200 words per source; no long excerpts.

## Strongest findings and source facts

### A. Historical offering record — direct primary source
URL: https://republic.com/megafans
Observed September 5, 2026; historical deadline June 27, 2024.
The campaign is withdrawn and Republic states that all investments were refunded. It must not count as a completed raise.
The page displays a $400,000 allocation/maximum, describes a Regulation D 506(c) offering by MEGAFANS INC., identifies the legal name as Megafans Ltd., and labels the form a BVI Limited Partnership. Legal placeholders remain: "[token name]".
Its pitch reports 699,325 cumulative unique users, 1,602,000+ tournament sessions, sub-$0.20 CAC, $6.60 ARPU, and above-average 30-day retention; these lack cohort/period/methodology context in the text reviewed. A disclaimer says the new company generated no revenue.
It admits repeated business-model pivots and an unproven sustainable model. The "Press" block links general crypto coverage pages; do not count that block as evidence of major-media coverage of MegaFans.
These are disclosure/quality faults and dated business risks. Refunds are counterevidence against claiming investors lost their Republic subscriptions. The reason for withdrawal is not established.

### B. PPM — primary legal document
URL: https://republic.com/documents/9987?view=preview
35-page PDF; dated June 25, 2024. Page numbers below are printed numbers.
- pp.6/23: Ltd is a BVI Business Company; Inc is a common-owned California IP company. Distinct entities explain different histories; the campaign labels remain inconsistent.
- pp.7/9-10: Reg D maximum is $40,000 (400,000 tokens × $0.10), contrasting with the page's $400,000.
- p.7: expected delivery 30 days after final TPA processing, contrasting with TPA's three days.
- pp.7-8: incentive reserve described as 45% of supply versus a detailed 19m-token incentive allocation. No reconciliation located; allocations otherwise total 100m.
- p.9: tokens had not yet been minted.
- pp.14-15: repeated pivots, difficult publisher sales and capital-intensive development.
- pp.23-24: founders Donnelley/Bracey own 85%/15%, are sole full-time employees; issuer says no board and founder control.
- pp.24-25: unaudited June7 balance sheet records $131,218 cash/crypto, $160,000 liabilities and $290,718 equity.
These establish historical disclosure and governance concerns, not Laura's ownership or current insolvency. The no-revenue sentence cannot conclusively be reconciled without inspecting the P&L image (p.26).

### C. Token Purchase Agreement — primary contract
URL: https://uploads.republic.com/p/offerings/security_attachments/original/000/010/004/10004-1719345900-f13c893d37d6ef54e9a1dedc70542cfa0fabe4f1.pdf
21-page PDF, currently linked from campaign.
PDF page 3 (zero-based 2) sets delivery within three days after the final TPA across Reg D/S is processed; unlock one year after release. Exhibit A (PDF page19) says Reg D tokens release one year after purchase. Section3.1 says tokens will not reach a wallet until restrictions end, then says delivered tokens will subsequently unlock. These are concrete drafting inconsistencies affecting timing/custody clarity.
Exhibit A separates 400,000 Reg D tokens from 3m Reg S tokens; do not conflate them. It also earmarks 3m tokens collectively for advisers; it does not identify Laura or establish receipt.
Token holders get no shareholder rights. The contract imposes individual arbitration, transfer locks and additional KYC conditions. Those are disclosed investor limitations, not necessarily defects or unlawful terms.
Disqualified jurisdictions include Ontario and British Columbia; this is no proof of Canadian solicitation.
This is an unsigned template, not evidence of completed contracts or actual token delivery.

### D. Product-maintenance evidence — primary app stores
Candy Boo:
https://apps.apple.com/us/app/candy-boo-esports-tournament/id1447419350
Current US listing shows last release v24.0.7 on March24,2023, seller MegaFans Inc, 18+ rating with gambling/contests descriptor. It advertises real prizes and real-money tournaments. Privacy label declares identifier tracking and third-party-ad usage data. Its developer privacy link points to https://appicstudio.com/privacy-policy.html . Source is a current store page, not an installed-app test. Low rating count alone proves nothing about total cross-platform usage.

Crash n Win:
https://apps.apple.com/us/app/crash-n-win/id1503172280
Last listed release v2.0.8 March30,2023; privacy link also Appic Studio. Some individual 2020 reviews complain about ads/UI, while other reviews are positive; old anonymous reviews were not promoted into factual findings.

Tunnel Tournament:
https://apps.apple.com/us/app/tunnel-tournament/id1503582224
Last listed release v2.0.6 April5,2023; current US rating18+ with gambling/contests descriptors. Declares tracking identifiers and advertising usage data.

Assessment: three linked iOS products have no publicly listed binary releases since spring2023. This is a maintenance question relevant to current growth/AI claims, not proof of abandonment; server-side updates and other platforms may differ. Current 18+ ratings should be preserved as counterevidence against any unsupported claim of children being invited into these apps.

### E. Privacy-policy mismatch — primary policy
https://appicstudio.com/privacy-policy.html
Viewed September5,2026. The policy applies to Appic Studio services. It does not identify MegaFans, clarify its relationship to Appic, or address MegaFans tournament wallets, prize payouts or KYC. It generically discusses SDKs, advertising IDs, location/IP, optional email, social identifiers and optional device access. A child clause says it does not knowingly collect under-13 personal data and provides a remediation contact. A static copyright line is 2017, but that is not proof of the policy's last update.
Assessment: real disclosure-fit weakness, particularly for a platform marketing money and token rewards. The page's failure to explain the parties is observable. Whether actual processing breaches privacy law requires further facts; no conclusion of child-data exploitation or unlawful collection is established.

### F. Current promotion — company profiles
https://www.linkedin.com/company/megafansesports
Viewed September5,2026. Company describes AI-driven tournaments, Unity/Unreal SDK integration, crypto/NFT/token pools and real-money engagement. "800k users" appears among specialties, without a date/cohort. Compared with 699k historical cumulative users, this can reflect ordinary growth rather than contradiction. Change from 2024 Unity/HTML5 support likewise could reflect product expansion. No public technical docs or independent benchmark verified those current claims in this bounded review.

https://linktr.ee/MegaFans_esports
Company LinkedIn points here. It links five games and PDFs titled "Megafans Deck 2025" and "MegaFans White Paper 2022-23". Thus there is a 2025-labelled collateral artifact, but not verified 2026 operations.
Deck: MegaFans forecast deck (source title retained)
Whitepaper: MegaFans whitepaper (source title retained)
Search could read metadata only. Full retrieval remained pending at this research stage; the later validated review reports successful examination.

### G. Listing rhetoric — company-issued press release
https://www.prnewswire.com/news-releases/megafans-launches-and-lists-token-mbucks-on-binance-smart-chain-302158231.html
May29,2024; clearly "News provided by Megafans". Announces launch/listing on Binance Smart Chain, calls this a "Binance listing", predicts MEXC/PancakeSwap trading in June2024, but final paragraph calls launch upcoming.
Assessment: ambiguous launch status and loose chain-versus-exchange language; not an independently corroborated Binance exchange listing. Compare with June25 PPM unminted status. This may be an announcement ahead of deployment, so call it an unresolved chronology/wording inconsistency rather than a proven false listing or proven failure to launch.
Search found official X contract post https://x.com/MegafansGaming/status/1806408017103175844 referencing 0x3638feA0C645B1aa79Db706Fab6E8a761385c390. BscScan inaccessible in this tool; no verified chain/price/liquidity findings produced.

## Recommended priority for final synthesis
1. Contract/page inconsistencies: 3-day vs30-day delivery; $40k vs$400k; entity/form labels and placeholders.
2. Dated business-model/financial/governance admissions, clearly2024.
3. Current iOS maintenance gap and privacy-policy mismatch.
4. Current AI/SDK/traction claims need substantiation; not proven false.
5. Promotional chain/listing chronology is secondary.

## Negative checks and limitations
No independently verified current legal case, regulatory finding, unpaid prize, scam determination or evidence implicating Laura personally was found in this bounded pass. Direct site tool errors on megafans.com/io are retrieval limitations, not outage evidence. The 2024 offering PDFs have substantive text extracted by web and screenshots requested; image-only P&L values were not rendered to the agent, so no profit/loss assertion based on that image is made. Direct PDF download attempt was403 and was not bypassed.
