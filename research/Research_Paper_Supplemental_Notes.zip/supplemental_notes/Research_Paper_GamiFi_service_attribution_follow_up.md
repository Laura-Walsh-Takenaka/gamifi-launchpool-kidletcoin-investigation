# Research Paper — GamiFi service attribution follow-up

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Checked 6 September 2026. Scope: public service attribution for four already-established addresses. No provider was contacted, no exchange order/account was accessed, and no human wallet owner was inferred.

## New finding: a provider-attributed statement names the exact FixedFloat BSC wallet

The earlier report described `0x4727250679294802377dd6ca6541b8e459077c95` using only an Ethereum explorer label credited to a third-party compilation. This follow-up found materially stronger public provenance:

1. FixedFloat's own Russian FAQ links directly to its Russian BestChange listing. The English FAQ also links to the English version of its listing. [F1–F3]
2. On that Russian listing, a reply dated **10 May 2025, 12:47** by the account displayed as **Administrator FixedFloat** identifies three addresses as examples of the service's main outgoing addresses. One is the exact BNB Chain address `0x4727250679294802377dd6ca6541b8e459077c95`, linked to BscScan. The displayed time has no established timezone and must not be converted to UTC. [F4]
3. The exact BscScan address page is now indexed with a FixedFloat Hot Wallet label. Direct retrieval of that page returned 403; the new evidence is a successful search-index result, not a successful direct page download. An indexed BscScan transaction also explicitly displays the exact address with that label on BNB Chain. [F5–F6]

This is a **provider-attributed business statement through a channel linked by FixedFloat itself**, plus a chain-specific explorer label. It strengthens the service attribution beyond the previous Ethereum-only label. The channel endorsement does not independently authenticate the particular human posting the reply, and the statement is dated 2025. It does **not** establish custody on 5 November 2022, identify the order behind the 5,174-BUSD deposit, identify a payout, or identify a customer.

The substantive fact taken from the review page is the administrator account's exact-address statement. Other customers' complaints or allegations on that page are not evidence about GamiFi and are excluded from the findings.

## What the historical service material does and does not establish

FixedFloat's own guide on wrong-network transfers expressly says its service supports BEP20 and discusses BSC/Ethereum network-selection issues. Its guide index dates the article to **14 September 2021**. The content was retrieved from the current site; it is not a frozen 2021 archive and may have been edited. It establishes a first-party published BSC-support statement associated with an older article, but not uninterrupted support at every moment in November 2022. [F7–F8]

The narrower question—whether BUSD/BEP20 was available for the particular 5 November 2022 order—is still open. Targeted searches found historical public user tutorials describing BUSD/BEP20 exchanges on FixedFloat in January and February 2022. Those are retained as historical leads only: they do not supply the provider's order record or certify availability on 5 November. An official Instagram search result mentions BUSD on BEP2/BEP20, but direct retrieval failed and no reliable post date was obtained; it is not used to establish 2022 support. [F9–F11]

FixedFloat's own consolidation guide explains that client funds may be consolidated into a main address and that consolidation costs enter its pricing. This supplies service-process context; it is not a statement that the specific GamiFi intermediary belonged to FixedFloat. [F12]

The existing on-chain route remains:

| UTC | Exact BUSD | From | To | Transaction |
|---|---:|---|---|---|
| 2022-11-05 07:15:11 | 5,174 | `0x35dc4a16db1e30036fee83e733ee065ad8535422` | `0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6` | `0x34bfa37b43fc0426e45ffcd3af9927be6495d4710f340f7f80e09d2fc41fe1b4` |
| 2022-11-05 07:15:32 | 5,174 | `0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6` | `0x4727250679294802377dd6ca6541b8e459077c95` | `0x7702b5e67906c5eb1dea5d1fdde0f7ade3e37cb5cd657944bd539ed460791e48` |

Transaction facts above are carried from the already receipt-verified financial evidence; this lane did not run new chain accounting. These are two movements of the same funds. Neither the 21-second interval nor a similarly valued outgoing service transfer supplies an order/payout match.

## Exact-address disclosure checks

| Address | New public result | Remaining conclusion |
|---|---|---|
| `0x4727250679294802377dd6ca6541b8e459077c95` | Provider-attributed 2025 exact-address statement on FixedFloat-linked BestChange listing; current BscScan label | Stronger service attribution, with historical custody and order mapping still requiring confirmation |
| `0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6` | No indexed exact-address provider disclosure found in targeted searches | Still an on-chain intermediary; not independently established as a FixedFloat order address |
| `0xf4f86e37815217ed73ae817a4e5164d56315b1d7` | One search engine returned an unrelated explorer address page containing the address; no provider label or official business assignment was located; the second engine returned no exact result | The private-beneficiary BUSD recipient remains unattributed |
| `0x9564f530d9f270a48c510a92c97b59248cefd464` | No exact-address MEXC or other official service disclosure found | Its verified forwarding to MEXC-associated hot wallets does not establish deposit-address assignment or a customer account |

Coverage is bounded: two search engines, exact-address and provider-domain searches, FixedFloat FAQ links, relevant official guide pages and the endorsed review listing. A negative result means no disclosure was located in that coverage, not that one cannot exist.

## Revised record target

The FixedFloat record target can now cite the service-linked **10 May 2025 exact-address statement** as supporting address provenance. The request should still ask the provider to confirm whether it controlled `0x472725...` on 5 November 2022 and whether `0x96f0...` was its order-deposit address. If confirmed, obtain the order identifier, input credit/sweep bookkeeping, output asset and chain, payout amount, destination, payout transaction and any refund/cancellation record. Ask for customer or verification information only to the extent actually held. The existing no-registration documentation means an ordinary named account may never have existed.

No Cayman bank account, bank beneficiary, personal Laura wallet, key custodian, MEXC account credit or FixedFloat payout was established by this follow-up.

## Source register

- **F1 — Primary provider page:** FixedFloat Russian FAQ, https://ff.io/ru/faq . Successful open `historical retrieval`, line 68 links to the exact Russian BestChange listing. The linked page was independently opened by clicking link 28.
- **F2 — Primary provider page:** FixedFloat English FAQ, https://ff.io/faq . Successful open `historical retrieval`, lines 66–69 name and link the review channels.
- **F3 — Provider-linked listing:** https://www.bestchange.ru/fixedfloat-exchanger.html . Successful first-party-link click `historical retrieval`. Used to confirm the destination of the provider's FAQ link, not as an independent audit of the provider.
- **F4 — Provider-attributed statement on an endorsed external channel:** https://www.bestchange.ru/fixedfloat-exchanger-79.html . Successful open `historical retrieval`, lines 207–216 show the 10 May 2025 administrator reply and exact BscScan address. Page numbering can shift as reviews are added: locate the displayed date and exact wallet address.
- **F5 — Primary explorer's published label, current indexed retrieval:** https://bscscan.com/address/0x4727250679294802377dd6ca6541b8e459077c95 . Successful search `historical retrieval`; direct open failed with 403 (`historical retrieval`).
- **F6 — Primary explorer's published label, current indexed retrieval:** https://bscscan.com/tx/0x42c29d018f6f0dff39fe50b1c950e06feb0a0ad2060b86db992128b0a04fc240 . Search `historical retrieval` explicitly pairs the BSC sender with FixedFloat Hot Wallet. This unrelated March 2026 transaction is not included in GamiFi's flow or dollar totals.
- **F7 — Primary provider guide:** https://ff.io/blog/guides/sent-to-the-wrong-network . Successful open `historical retrieval`, line 65 explicitly states BEP20 support; current page, no frozen historical capture.
- **F8 — Primary provider index:** https://ff.io/en/blog/guides/ . Search `historical retrieval` displays 14 September 2021 for the wrong-network guide. Current indexing is not proof of an unchanged historical page.
- **F9 — Historical user tutorial, lead only:** https://forum.cardano.org/t/cara-mendapatkan-fee-withdrawal-crypto-yang-lebih-murah-menggunakan-fixedfloat-com/93056 . Search `historical retrieval`, displayed 20 January 2022, describes BUSD/BEP20 input on FixedFloat. Not used as provider confirmation.
- **F10 — Historical user tutorial, lead only:** https://forum.cardano.org/t/how-to-get-less-withdrawal-fees-on-crypto-exchanges-using-fixedfloat-com-example-cardano-withdrawal/96360 . Search `historical retrieval`, displayed 24 February 2022, describes the same mechanism. Same author/topic in two languages, not independent corroboration.
- **F11 — Incomplete official-social lead, excluded from historical finding:** https://www.instagram.com/p/CdJJYbqsnEQ/ . Search `historical retrieval` names BUSD BEP2/BEP20; direct open throttled, date not established. FixedFloat FAQ links its Instagram profile, but the incomplete post result is not dated historical proof.
- **F12 — Primary provider process documentation:** https://ff.io/blog/guides/what-is-consolidation . Successful open `historical retrieval`, especially lines 59–66. Supports general consolidation behavior only.

Compact machine-readable provenance and retrieval diagnostics accompany this note. All source paraphrases are short and scoped to the particular finding; unrelated review details and account information are not reproduced.
