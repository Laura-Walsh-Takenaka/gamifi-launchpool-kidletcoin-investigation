# Research Paper — Public project links and attribution recheck — 5 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

## Findings

**The public record strongly supports professional identity continuity between Laura Takenaka and Laura Walsh, and directly connects that profile to promoting the KidLetCoin wallet. It does not authenticate exclusive ownership of the NBDCOH signing account.** The operational account roles are established most firmly by the blockchain records. No new operational address was recovered from the public app source.

### 1. Laura Takenaka / Laura Walsh: a direct public account link

The public LinkedIn post about the KIDLetCoin wallet demo has a current author label **Laura Walsh**. A comment addresses **Laura Takenaka**. These two labels link to exactly the same profile path, `https://ca.linkedin.com/in/lauralwalsh`; only LinkedIn tracking parameters differ. The HTML was retrieved directly and both link targets extracted into *Historical file: linkedin-identity-links.json*.

In the post, the author describes the KID wallet as a NEMPay fork, promotes the project demo and speaks about completing its next milestone. The same page's more-from-author item links to `work-nem-thailand-laura-takenaka` while displaying the current name Laura Walsh. The linked old article itself returned 404 and is not relied on for its text.

Primary source: [Public wallet-demo post](https://www.linkedin.com/posts/lauralwalsh_kidletcoin-wallet-demo-video-activity-6491593875063439360-Nte8?trk=public_profile_like_view).

A first-person 2021 interview published by MoneyNeverSleeps under Laura Walsh corroborates the professional history: she describes opening NEM's Thailand office, teaching token creation with her daughter and launching the daughter's project. These are the interviewee's statements, not independent proof of all underlying events. The page displays 7 October 2021.

Primary source: [Laura Walsh interview, 2021](https://www.moneyneversleeps.ie/156-3-is-the-magic-number-laura-walsh-launchpool-and-techstars/).

The older NEM Forum candidacy was published by `LauraBKK` under the title Laura Takenaka for Secretary/Council. It describes her involvement in her daughter's coding project. The 2018 NEM Southeast Asia voting guide separately identifies Laura Takenaka as country head of NEM Thailand.

Primary sources: [Candidate's own forum thread](https://forum.nem.io/t/laura-takenaka-for-secretary-council/20442), [NEM Southeast Asia voting guide](https://medium.com/nem-sea/nem-elections-voting-guide-f39b99eebc29).

**Confidence:** high that these public professional identities refer to the same project participant. This resolves the apparent surname mismatch in contextual research. The text `Laura Walsh BSC` in a transaction remains an account-authored message, not a verified civil identity credential, exclusive-custody proof or authority to attribute unrelated holdings. No BSC holdings were followed.

### 2. Operational addresses: roles and attribution limits

| Address | Supported role | Source and confidence |
|---|---|---|
| `NC7HKOMA4N4ZCYJ7PXJPUGGQLSBLQL6S6LEFQHNZ` | Creator/issuer account of `kidlet:kid`; also has broader non-KID history | High for protocol role: historical mosaic definition and existing verified account/control records. No matching fixed address in the reviewed app source; no newly recovered first-person declaration of its human owner. |
| `NCEUKZQJXJGQSTEWUIRURSQVX2MDTXU5ZW37YQ4I` | Explicit levy recipient in both 2018 and 2019 `kidlet:kid` definitions; reviewed chain records also associate its key with definition initiation | High for levy role. This is a direct project-function link. Human ownership is unresolved in reviewed primary material. |
| `NDMV5M4Y2GKQOJ3C4W6HYUK32PSEWLKRHPGS4V2V` | Project multisignature participant and recipient of the previously verified 100-XEM transfer bearing `For KID` | High for chain roles, from parent investigation. No new off-chain owner declaration or code constant found. |
| `NASEACHB4GDLNLC2EGU7KQB3T2WY23UWTNVUSLKH` | Former NEM Foundation Southeast Asia regional account | High: Foundation representative's contemporary reply explicitly identifies this account as SE Asia. |

The [2018 definition transaction](https://explorer.nemtool.com/#/s_tx?hash=7f8910e2fa04ef06ea233fd6d56f97a621095a3f0c225e6c813787d2007baddd) occurred at height 1,580,152, confirmed 9 April 2018 at 05:35:06 UTC. The [2019 definition](https://explorer.nemtool.com/#/s_tx?hash=250b0463c72bc6e1322d5e8bc3a5f726bc2094bebc5c9fb6d1a1635ad6b7610b) occurred at height 2,137,280, confirmed 4 May 2019 at 05:59:47 UTC. Both designate NCEUKZ as levy recipient. The description frames the asset as an educational experiment for children and parents covering blockchain and financial management. Chain descriptions are issuer-authored claims about purpose; they are not audited accounts of real-world operations.

The levy field has fee 10 in XEM atomic units, i.e. 0.00001 XEM fixed per applicable transfer. It must not be presented as 10 XEM or as a percentage. The prior lifecycle replay records the 2019 description edit rather than a second 21-million issuance.

Local chain authority: *Historical file: lifecycle-replay.json*, with original paired blocks in that directory. These chain facts are reused from the parent investigation, not newly fetched by this public-source subtask.

The Foundation's response says regional funds had been reallocated following the funding audit and gives the SE Asia address explicitly. It does not state that all receipts from that account financed KidLetCoin. Other addresses in the same reply concern former staff claims and have not been added to the project graph.

Primary source: [NEM Foundation account explanation](https://forum.nem.io/t/how-long-will-nf-fund-each-region/22488/2), directly preserved via [forum JSON](https://forum.nem.io/t/how-long-will-nf-fund-each-region/22488.json).

### 3. Public source-code connection and its limits

The complete public source snapshot at commit `d8c2e9b3a364734a17bead61f5549672dfb73de6` was downloaded from GitHub's codeload endpoint. Its README describes Kidlet as a customized NEMPay wallet for XEM and Kidlet Coins. The app's About page describes teaching cryptocurrency and personal finance. `NemProvider` explicitly bootstraps `NetworkTypes.MAIN_NET`, with the test-network line commented out. Wallet creation/import derives a user-selected account through the NEM library; recipients are supplied at transfer time.

Primary sources: [README](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/README.md), [About page](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/about/about.html), [NEM provider](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/providers/nem/nem.provider.ts).

All 94 UTF-8 text files in this snapshot were searched for the three specified operational addresses, including after stripping whitespace and hyphens. There were **zero matches**. A contiguous NEM-address-shaped text scan also returned zero matches. This is a text-source result; binary image assets and screenshots were not decoded. Therefore this repository does not provide a fixed treasury, issuer or levy address constant that independently assigns the queried accounts to a named person. A repository account name is not a wallet-ownership credential.

**New code observation relevant to identifying KID:** the balance page filters by `mosaicId.name == 'kid'` or `'xem'` and displays the short mosaic name; the login notification likewise checks the short name alone. Those paths do not constrain the `kidlet` namespace or creator. A short displayed name is consequently weaker evidence than the full `kidlet:kid` on-chain identifier. The transfer confirmation does use `mosaicId.description()`, and the transfer carries the selected mosaic's full ID, so this is not a claim that all token identity information is omitted. No actual counterfeit-token incident was established.

Primary sources: [Balance logic](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/balance/balance.ts), [Balance display](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/balance/balance.html), [Login](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/login/login.ts), [Transfer logic](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/transfer/transfer.ts).

The public snapshot declares app identifier `com.Kidlet.app`; the later contest points to Google Play package `com.kidletcoin.app`. The prior source-to-binary limitation remains: no authenticated APK/signing certificate/reproducible connection establishes that the distributed app used every path in this snapshot. The source's generic author/homepage fields do not identify the operators of the three queried wallets.

Primary source: [App configuration](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/config.xml).

## Evidence capture and follow-up

Raw GitHub tree, metadata, pinned source archive, forum thread JSON, LinkedIn post HTML and interview HTML are in `full-history/public-source/`. Each directly downloaded file has a `.source.json` sidecar with exact URL, retrieval time and SHA-256. `code-address-scan.json` records the bounded source scan. `linkedin-identity-links.json` preserves the extracted link labels and targets.

No new address requires graph expansion from this subtask. Exact searches for the issuer also surfaced third-party harvester labels and election-account speculation. Those were not promoted to human-owner findings. No child participant was identified and no minor wallet was assigned a name. Further business-purpose attribution requires project-account declarations, approved grant/payment records or invoices tying a specific transfer to the project; public name similarity cannot substitute for those records.
