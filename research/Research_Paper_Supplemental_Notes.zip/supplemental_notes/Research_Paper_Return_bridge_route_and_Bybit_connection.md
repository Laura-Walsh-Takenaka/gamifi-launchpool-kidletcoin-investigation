# Research Paper — Return bridge route and Bybit connection

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The transparent continuation reaches an exchange endpoint disclosed by Bybit. On January 27–28, 2024, `0x60282bd31ceb60aa217df9859465e4396348a1ed` sent **533,062.057758 USDC** in 11 transfers to `0x1bb1102fb6145ff7b42854cb708c6ab1f67bb900`. That intermediary forwarded exactly the same total in 10 transfers to **`0xf89d7b9c864f589bbf53a82105107622b35eaa40`**. All 21 transfer legs were checked against full Ethereum transaction records and separately fetched logs. The intermediary's exhausted canonical USDC ledger contains only those 21 positive transfers and ends at zero.

Bybit's [June 2024 Hacken proof-of-reserves report](https://testnet.bybit.com/common-static/cht-static/por/Bybit_PoR_Audit_06_06_2024_12_00_00.pdf) lists that exact address in its **Ethereum** row (physical page 10, printed page 9). The report postdates the January transfers. It corroborates the exchange organization, not an exchange customer. The web text and page screenshot were checked; a separate direct PDF download timed out, so the evidence folder preserves source metadata rather than a full copy.

## BSC holding period and the next bridge

The preceding Polygon investigation exact-joined four August 21, 2022 return completions, delivering **141,176.8908 USDT** to BSC `0x1c44608f21043bac13bd6f2e078fc9889e719187`. Its complete bounded index has 9 normal, 31 token and 1 internal record. All 9 normal transactions have full successful receipts and block headers. The outgoing nonces cover 0–7; a pinned current count of 8 corroborates that coverage.

It swapped **50 USDT** through PancakeSwap on August 21, then retained **141,126.8908 USDT** until November 22. Archive `balanceOf` checks after the last August receipt and immediately before the November bridge show that identical balance. This was a roughly three-month holding interval, not an immediate exchange transfer.

| BSC source, November 22 UTC | Ethereum completion UTC | Requested / received USDT |
|---|---|---|
| [04:53:56](https://bscscan.com/tx/0xa9fbb86fadeb5fadf63a5ea1fcf62e95cd5820d95ca6cfebb30172c6eac5d260) | [04:57:47](https://etherscan.io/tx/0x517dcdd97a0c3b53d69f6670db03d79e79daa1e9b68fb8710287d4ed1531e132) | 1,000 / 995.1 |
| [05:08:19](https://bscscan.com/tx/0x476ab43c8bdc9d8cc4b23454832725b06276c6127b45576a05b7f0701b8f0225) | [05:12:47](https://etherscan.io/tx/0x732d5245ff539191e62107c79fe2d56b2f0d60287b365a91d156b34037d04de3) | 140,126 / 140,111.9874 |

Both destination calldata and `LogAnySwapIn` events name the exact BSC source hash, chain 56, Ethereum destination chain 1 and the same recipient. This establishes the protocol join directly. The BSC post-bridge archive balance is **0.8908 USDT**. A later small purchase produces its pinned **4.033743100254871777 USDT** balance.

## Where additional funds enter

On November 23, the same Polygon wallet `0x82f6ac7d4c8a00a4cced3f673d67e1bcf8d7e8f8` requested another **70,155.6 USDT** to Ethereum. [The Ethereum completion](https://etherscan.io/tx/0xd525ebe5b6b4edb463fc246ae0ef7281b1fcbf450965ed508d64e170cdd24875) exact-joins that source hash and pays **70,148.58444 USDT** to 1c446. Funding of this additional Polygon tranche is an open lead.

The combined **211,255.67184 USDT** moves from 1c446 to 60282 on December 1. On March 11, 2023, [it is swapped](https://etherscan.io/tx/0xebf7349a53d785cbdf67b7bd36c196e5004c1b3288794145053e568e70927b8b) for **224,983.672898628694112445 DAI**. A separate **212,854.5569 USDC** conversion adds **212,813.983472001375325684 DAI** to the same wallet. On March 14, **300,000 DAI** from this mixed balance becomes **300,011.88247 USDC**, while the remaining **137,797.656370630069438129 DAI** is sent into a different swap execution. That latter asset's subsequent lineage is not traced here.

Two later additional USDC inflows of **95,434.926655** and **137,615.248633** raise the USDC total to **533,062.057758**, all subsequently routed through 1bb110 to Bybit. Those additional inflows are documented in the exhausted ledger; their upstream origin is not assigned to the original branch. The canonical USDT, USDC and DAI ledgers for 60282 are exhausted at 4, 24 and 4 rows, respectively, with self-transfers neutralized and zero-value rows excluded from economic totals.

## Attribution and coverage

This is an **unassigned Tornado-recipient branch**, followed transparently through 1cf0, mixed 8292, 20f0, Polygon, BSC and Ethereum. It is not a demonstrated exit of a GamiFi deposit note. Neither the full Bybit amount nor a specific share is assigned to GamiFi. No person or exchange customer is identified.

All BSC counterparty matches against the prior 116-address register were common protocol/token contracts: PancakeSwap router, canonical USDT and Anyswap router. None matched the 16-address Binance BSC disclosure register. The BSC native seed sender has a ChangeNOW label on Ethereum only; BSC service attribution remains unconfirmed and is not included as a verified exchange connection.

The Ethereum legacy internal-history endpoint reported unprocessed blocks. No complete Ethereum internal-history or independently verified Ethereum archive-balance claim is made. Legacy token-history requests for 60282 returned 429 despite backoff; canonical paginated v2 ledgers and selected transaction/log records succeeded. The final package includes failed-request records, full successful captures, and source hashes.
