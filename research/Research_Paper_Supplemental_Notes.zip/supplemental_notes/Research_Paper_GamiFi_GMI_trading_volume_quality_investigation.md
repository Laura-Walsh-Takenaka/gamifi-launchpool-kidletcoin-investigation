# Research Paper — GamiFi (GMI): trading-volume quality investigation

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Research date: **2026-09-05 UTC**. Public, read-only investigation. This is a bounded evidence review, not a complete transaction-history or exchange-book audit.

## Disposition

**No GamiFi wash-trading pattern or Gotbit relationship was established.** The new evidence verifies a genuine PancakeSwap pool, two small 2026 sales, and two historical token-payment receipts that must not be counted as DEX trades. The available sample cannot establish the proportion of artificial volume, address concentration, repeated round trips, or common control. Sparse current liquidity and missing analytics data are not proof of manipulation.

Laura's CEO succession was announced **September 1, 2022**. The 2026 sales and pool state must not be attributed to her. Source: [GamiFi CEO announcement](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147), published 2022-09-01; accessed 2026-09-05. No trader address was linked to Laura or another identified individual.

## Exact asset and venue

| Item | Verified identity |
|---|---|
| GamiFi token | `0x93d8d25e3c9a847a5da79f79ecac89461feca846` |
| Chain | BNB Smart Chain mainnet, chain ID **56** (`0x38`) |
| PancakeSwap V2 GMI/WBNB pool | `0x58d4b61983ca0afe6e352e90719f403e24e016f4` |
| WBNB token | `0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c` |
| PancakeSwap V2 factory | `0xca143ce32fe78f1f7019d7d551a6402fc5350c73` |

The official GamiFi podcast's March 22, 2022 show notes link the exact GMI contract through PancakeSwap and identify MEXC as the other available venue at that time. This is historical venue evidence, not verification of a present MEXC listing or current volume. [Official show notes](https://player.captivate.fm/587ac29a-5fc4-4db8-95e3-87f16c20e2af); [linked PancakeSwap trade page](https://pancakeswap.finance/swap?outputCurrency=0x93D8d25E3C9A847a5Da79F79ecaC89461FEcA846); [linked MEXC market](https://www.mexc.com/exchange/GMI_USDT). Accessed 2026-09-05.

The live [PancakeSwap pool page](https://pancakeswap.finance/info/pair/pairs/0x58d4b61983ca0afe6e352e90719f403e24e016f4) identifies GMI/WBNB on BNB Smart Chain. Independently, public RPC calls returned the same `token0`, `token1`, and factory. Calling the **documented factory's** `getPair(GMI,WBNB)` returned this exact pool. This checks identity in both directions rather than relying only on a pool's self-reported factory. [PancakeSwap official factory documentation](https://developer.pancakeswap.finance/contracts/v2/addresses), accessed 2026-09-05.

## Fixed-block baseline

Source record: public BNB Chain RPC state at **block 120,144,015**, timestamp **2026-09-05 16:39:10 UTC**. Raw requests and responses: `volume_gamifi_raw/current_state_and_dates.json`; verification: `factory_and_route.json`. Endpoint: [BNB Chain public RPC](https://bsc-dataseed.bnbchain.org), accessed 2026-09-05.

| Metric | Decoded value |
|---|---:|
| GMI decimals | 18 |
| GMI total supply | 1,000,000,000 |
| Pool GMI reserve | 264,515,119.841511288910891833 |
| Pool WBNB reserve | 0.844195681546778659 |
| GMI balance equals stored GMI reserve | Yes |
| Reserve-update timestamp | 2026-08-10 16:05:30 UTC |

Own calculations: reserve / total supply = **26.451511984%**; WBNB / GMI reserve = **0.000000003191483655 WBNB/GMI**; elapsed time since stored reserve update = **26.02338 days**. The supply percentage describes pooled liquidity, not a single beneficial owner's holding or share of trading volume. The stale reserve timestamp is consistent with inactivity; it is not a reconstructed historical trade dataset. No dollar valuation was inferred from mismatched analytics snapshots.

The live PancakeSwap interface displayed **$508.59 liquidity**, approximately **264.52m GMI / 0.84 WBNB**, **$0 24-hour volume**, and an empty transactions table on 2026-09-05. Its token search also showed tiny USDT/GMI and GMI/BUSD entries. Those secondary pools were not independently validated or exhaustively enumerated. These are interface observations, not proof of zero volume across every pool or exchange. The browser page's rounded reserves agree with the fixed-block token quantities above. [Pool interface](https://pancakeswap.finance/info/pair/pairs/0x58d4b61983ca0afe6e352e90719f403e24e016f4).

## Individually verified receipts

The first three hashes were convenience-sampled from indexed explorer results. The fourth was found by locating the pool's stored reserve-update second in public block headers, retrieving the two matching blocks' receipts, and filtering to the exact pool. These are **not a random, consecutive, or complete time-window sample**. Full receipts and block timestamps were retrieved through BNB's public RPC. Explorer links below identify the records; the BscScan browser itself was blocked by security verification.

| UTC date | Record and decoded result | Interpretation |
|---|---|---|
| 2026-04-17 10:46:15 | [Transaction 0x834e…6136](https://bscscan.com/tx/0x834e56f99483153e367aeeb196ec26a7cc786f0e6e539f8f5a0c6925b02a6136), block 93,048,034: one pool Swap, **174.453334004017548483 GMI in**, **0.000000556858842504 WBNB out**. Additional GMI payment: 0.437226401012575309. | A real small sale through a contract route. No GMI purchase or return leg appears in this receipt. It does not establish the sender's behavior before or afterward. |
| 2022-12-14 16:01:19 | [Transaction 0x03aa…8639](https://bscscan.com/tx/0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639), block 23,901,241: **2,131,635.802469135802469136 GMI** paid from the called address to the initiating address; one Transfer log. | No Swap event in the receipt. Excluded from DEX volume. The called address's business purpose was not independently established; do not assert a staking or vesting category from amount alone. |
| 2022-06-06 13:31:54 | [Transaction 0xfa6f…5736](https://bscscan.com/tx/0xfa6f3443e0143f196d3eb038135d814830929222d98cd9c6d3f77b0dd9595736), block 18,453,628: two GMI payments, **350** and **32.10763056485683965**, total **382.10763056485683965**. | No Swap event in the receipt. Excluded from DEX volume. The transaction happened during Laura's tenure, but no personal involvement or defect was established. |
| 2026-08-10 16:05:30 | [Transaction 0xe07e…b0ac](https://bscscan.com/tx/0xe07e5f5ba7b0ddf0403d2eaa244c251011fc9e3e3b5f98c1d17e5ba390dbb0ac), block 115,149,751: **85,359.092875973092463512 GMI in**, **0.000271828813591857 WBNB out**; one pool Swap. | The stored reserve-update timestamp corresponds to a sale, not merely a liquidity addition/removal. Its Sync reserves exactly match the September fixed-block reserves. This single receipt contains no GMI purchase or round trip. |

For the final row, all **227 receipts** in blocks **115,149,751 and 115,149,752** were locally filtered; only one contained logs from this GMI/WBNB pool. Adjacent headers timestamp the preceding block at 16:05:29 and following block at 16:05:31. This is a complete check of the two candidate blocks at that second, not a scan of the intervening months. Retained selected evidence: `last_update_pool_receipts.json`; headers: `last_update_candidates.json`.

The April Swap event's `sender` and `to` both contain the route address `0x63242a4ea82847b20e506b63b0e2e2eff0cc6cb0`; the initiating transaction address is different. Current RPC code checks show executable code at that route and the transaction's destination. **Matching Swap event endpoints alone are not evidence of self-trading**: these fields can describe routing contracts, not both economic counterparties. No beneficial ownership inference is made.

Both verified sales call `0x6131b5fae19ea4f9d964eac0408e4408b66337b5` from different initiating addresses. The indexed official [KyberSwap contract documentation](https://docs.kyberswap.com/developer-guide/aggregator-api/contracts) identifies that destination as its MetaAggregationRouterV2 (checked 2026-09-05; full-page extraction failed). Shared use of a public aggregation router therefore provides no basis to cluster the two initiating addresses as one trader. Their funding histories were not reconstructed.

## What the evidence can and cannot test

| Lead | Disposition | Evidence limit |
|---|---|---|
| Wrong chain or similarly named asset | Resolved | Exact official contract, chain ID, factory and pair matched. Generic GameFi, GameFi.org/GAFI, GMI2.0, and other GMI tickers excluded. |
| Token payments mistaken for volume | Confirmed classification hazard | Two sampled receipts contain transfers without swaps. No evidence that GamiFi itself reported these payments as trading volume. |
| Same-address Swap endpoints prove wash trading | Downgraded | The verified example is a contract route; the receipt contains one sale. |
| Repeated buy/sell round trips or capital recycling | Open | No consecutive trader-history dataset or funding-path evidence recovered. |
| Trader volume concentration / artificial-volume percentage | Not computable | A convenience sample cannot provide a market denominator, independent traders, or account-control clusters. |
| Current active, liquid market | Weak support | Small WBNB reserve and stale stored update time; UI reports zero daily volume. Pool existence alone does not establish commercial activity. |
| CEX wash trading | Open | MEXC's historical association is documented, but no off-chain order/trade/account data was obtained. On-chain transfers cannot audit its matched trades. |
| Inflated numerical volume claim by GamiFi | Not established | No specific primary company trading-volume claim was located for comparison against a complete ledger window. Aggregator figures are not automatically GamiFi's own representations. |
| Gotbit relationship | Not established | No direct primary contract, statement, or identifiable service relationship located. Unrelated industry allegations were excluded. |

## Reproducibility and access limits

- Public RPC provenance: [BNB Chain JSON-RPC documentation](https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/json-rpc-endpoint/), dated 2026-08-19; accessed 2026-09-05. It identifies mainnet chain ID 56 and this endpoint, and states that `eth_getLogs` is disabled on listed public mainnet endpoints. Only ordinary read methods were used. No private keys, wallet connections, signatures, state-changing calls, or account logins were involved.
- An initial snapshot request at the earlier recorded block returned `missing trie node`. A newly selected head block succeeded. Retained both outcomes; an unavailable historical state is not a token defect.
- BscScan and DexScreener browsers remained at Cloudflare security-verification pages. Reported the blocks and stopped accessing those sites. Cached DexScreener data was approximately 1.2 years old and was excluded from present-day numerical conclusions. Its zeroes and absent trade rows were not treated as a historical dataset.
- Event interpretation reference: [PancakeSwap published PancakePair code](https://github.com/pancakeswap/pancake-swap-core/blob/master/contracts/PancakePair.sol), archived 2021-10-14; accessed 2026-09-05. It defines separate Transfer, Swap, Mint, Burn and Sync behavior and the three returned reserve fields. Used as an ABI/behavior reference, not a verified-bytecode audit of this pool. No vulnerability claim is made.
- `volume_gamifi_raw/read_rpc.py` records public requests and full responses; `compute.py` deterministically decodes the saved state and receipts using decimal arithmetic; `decoded_results.json` contains computed values and public address flows. Individual trade size is not classified as fake or legitimate solely from its magnitude.

For a defensible wash-volume estimate, the missing material is a complete, time-bounded swap dataset across verified pools, routing-aware attribution, funding histories, liquidity-event exclusions, and separate exchange-side evidence for CEX trades. Current evidence does not justify an accusation or a clean bill of health.
