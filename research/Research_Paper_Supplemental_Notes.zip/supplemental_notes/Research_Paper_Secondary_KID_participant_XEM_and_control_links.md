# Research Paper — Secondary KID participant XEM and control links

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The expanded 22-history collection adds **38 unique records** beyond the earlier 16 histories: **24 XEM transfers, nine previously indexed KID transfers, and five control changes**. Every new record was reviewed. The original KID ledger already contained the nine token transfers; the new evidence is their surrounding XEM/control context.

## Initial funding and the shared source

The original 20-KID recipient NCYKQW… had already received **10 XEM from NBDCOH… on May 28, 2019**, before the June 2 contest video and June 11 KID transfer. It sent XEM onward along the same subsequent KID chain.

| Recipient | First observed XEM source | XEM | Creation UTC | Transaction |
|---|---|---:|---|---|
| NCYKQW… | NBDCOH… | 10 | 2019-05-28T08:40:46+00:00 | [5a096a6ad1f4…](https://explorer.nemtool.com/#/s_tx?hash=5a096a6ad1f4996f606d6d4425f814044cc4051cd273d626f9624cffea62748b) |
| NBQVQ6… | NCYKQW… | 8.29999 | 2019-06-11T03:41:28+00:00 | [7dbec695d48e…](https://explorer.nemtool.com/#/s_tx?hash=7dbec695d48ed5982cd0730d1e6ae29831d21912932a4f6be5d77a0f3475898f) |
| ND6D4I… | NBQVQ6… | 3 | 2019-06-11T03:51:59+00:00 | [8ceb1ebb7a70…](https://explorer.nemtool.com/#/s_tx?hash=8ceb1ebb7a7045ac6a6f6fabac4e6bd710225cf0ec98eefa26ca7d110201be7e) |
| NCIT7A… | NB3RVC… | 0.3 | 2019-06-03T03:12:59+00:00 | [7efb95d133fc…](https://explorer.nemtool.com/#/s_tx?hash=7efb95d133fca3c5f527ca730ea4b639ae8f6237fd2c4a993b7aafc68b036f3f) |
| NBYH5N… | NBQVQ6… | 2.14 | 2019-07-12T04:13:58+00:00 | [6b99d369fd2c…](https://explorer.nemtool.com/#/s_tx?hash=6b99d369fd2c7b47c2e29650f402b7ad15672933e6108fb8c28af0af25ad4bce) |
| NBXPW6… | NBDCOH… | 5 | 2019-06-30T09:38:56+00:00 | [fc2429fe7434…](https://explorer.nemtool.com/#/s_tx?hash=fc2429fe7434ddc0b1df92de7754a8cdc1312997cd5504035c744c587a9ad5dc) |

NCIT7A… also received **1.5 and 8.9 XEM from NBGTCB… on June 3**, before its first KID receipt. Thus the branch has a common operational setup history; it is not a set of independently established contest winners. Initial observed funding identifies transaction senders, not real-world account creators.

## Five related 2-of-3 conversions

The five new control transactions all add three keys and set a required threshold of two. They share **both NCYKQW… and NBGTCB…**. Each account has one further, distinct key. The two common keys together meet the configured threshold. NCYKQW… is also the original 20-KID recipient.

| Converted account | Creation UTC | Third key | Transaction |
|---|---|---|---|
| NB3RVCUTXBD7D775SUACUBPDHZFXTEX3SMRMLN3C | 2019-05-30T06:17:38+00:00 | NCMBPO65GHIFN4NJMMAG4NSRF6K2W6EFGTYNIHLJ | [16c06041e753…](https://explorer.nemtool.com/#/s_tx?hash=16c06041e75352125941d8bffe00b98276596828ac388bb75a7404c543aac798) |
| NCIT7ATTMW67VKKSD5DKIWZVKITN5GSHNSC264CP | 2019-06-03T03:15:27+00:00 | NA5D3OH234C7C32INKU6P4QSW5SOWVWYMZ4UZYXR | [510bb72a0f41…](https://explorer.nemtool.com/#/s_tx?hash=510bb72a0f4130ded8197f2d1f569435ee4689d670a407c29e78c2ad1d52df2b) |
| ND6D4I6T2UD2ZVFR5UWLW6PAIEXMFCNN5BIMHWOS | 2019-06-11T03:53:50+00:00 | NAXOAYPEYBHPNOXSFZ3FSCZ2LXKNIWKGCYRYMM7E | [c21a21976937…](https://explorer.nemtool.com/#/s_tx?hash=c21a2197693750f484fdfdb98f5ea7f2b017a05796305985e1edb102054dabdc) |
| NBQWPYOIRII6MWE4MPPM2WZMVN24QWFUFL7H2YXH | 2019-06-26T05:12:06+00:00 | NCRL47XNELWVJKBPZMOORAUU6UMOX2GZI3KVAJ7N | [b71541e9aef8…](https://explorer.nemtool.com/#/s_tx?hash=b71541e9aef8cad413c816a6fef8dedadb5a01e3c9b48cb8f47e12498ac86baa) |
| NBYH5NYA4GOH4V6HEQQKVWCRZBTMRY7L356JUEQK | 2019-07-12T04:15:15+00:00 | NAHGR4VEKEL6MUBAKDNO7WFVZLOICPM2ASI2RKOA | [3067b5e1a2c3…](https://explorer.nemtool.com/#/s_tx?hash=3067b5e1a2c36a09f4ea9e96b4336016ed4e5608d11bcd47da2541c21a719705) |

NCIT7A…, ND6D4I… and NBYH5N… are KID participants. NB3RVC… and NBQWPY… are related control neighbors, not established KID holders. Actual outgoing secondary multisig payments were initiated by each distinct third key and cosigned by NBGTCB… in the observed transactions. Shared signing authority does not identify humans or establish that keys were independently held.

## Reciprocal KID and XEM activity

**Three observed pairs move KID one way and XEM back between the same two accounts in the same or adjacent blocks**, with a separate XEM payment to NAYIOJ… near 20% of the reciprocal XEM amount. This is stronger evidence of exchange-like activity than a token-only graph, but lacks an explicit sale description, operating terms or independent-customer evidence.

| Date | KID into NCIT7A… | XEM back to same sender | Parallel XEM to NAYIOJ… | Block relationship |
|---|---:|---:|---:|---|
| 2019-06-11 | 1 from ND6D4I… [7366d75af66b…](https://explorer.nemtool.com/#/s_tx?hash=7366d75af66b6a876f63bb39fa801b62931c6bc37e74cfc37c1896fdf3df7cfd) | 2.421466 [3b52186f73bf…](https://explorer.nemtool.com/#/s_tx?hash=3b52186f73bfb32e47eed684df599fbc5d6dedb9445b7e8d912c88afaebed5a1) | 0.484293 [2ad6b0b83c17…](https://explorer.nemtool.com/#/s_tx?hash=2ad6b0b83c1769d540c8892cf660df16ffc82bbb9fdeeb988e5b074f9f80c2b0) | Maximum 1 block apart |
| 2019-06-12 | 1.073681 from ND6D4I… [3cff7d284c43…](https://explorer.nemtool.com/#/s_tx?hash=3cff7d284c437fdb4aeb3bee1c14a6d06d1acef87ac39b0be46450f89172b8a8) | 2.5 [cb8c0f41bf6f…](https://explorer.nemtool.com/#/s_tx?hash=cb8c0f41bf6f99e6eede43e0f4c49980abb36ef6937ea6f12efb925d3415ddb8) | 0.5 [69c9503f5256…](https://explorer.nemtool.com/#/s_tx?hash=69c9503f52565247be4d633d4eb6d9fc0e9ba94da35e115d0582da8dd004b281) | Maximum 0 block apart |
| 2019-07-12 | 0.2 from NBYH5N… [640513d8ce8d…](https://explorer.nemtool.com/#/s_tx?hash=640513d8ce8d400b2ffb6fc49ba21f4160bb2127cd6f994b2cfdc950d8274eb3) | 0.533328 [3e051740aa3e…](https://explorer.nemtool.com/#/s_tx?hash=3e051740aa3ef45f3e0477d7dd8db2940ad43dcdca2d8412ed10f46ae008b317) | 0.106666 [0d824bf3c68d…](https://explorer.nemtool.com/#/s_tx?hash=0d824bf3c68d6227bbbc6ac533318c0e7b36e5c0d8dcbe1d74f48359f30c4ad8) | Maximum 0 block apart |

On **July 11**, NBQVQ6… sends **1 XEM to NCIT7A…**, followed nine blocks later by **0.25 KID back to NBQVQ6…**. This provides an observed pair in the other direction. The creation timestamps are 06:52:24 and 07:02:38 UTC; the KID block confirmation is 07:04:56 UTC. These values are historical transaction amounts, not a verified market quote.

| UTC and basis | Direction | Amount | Height | Transaction |
|---|---|---:|---:|---|
| 2019-07-11T06:52:24+00:00 (created) | NBQVQ6… → NCIT7A… | 1 XEM | 2234470 | [217dc9cc91df…](https://explorer.nemtool.com/#/s_tx?hash=217dc9cc91df4ad0aa87948aba65c72ecf0e4427c74ba1e7b5a4dffcb569c211) |
| 2019-07-11T07:02:38+00:00 (created) | NCIT7A… → NBQVQ6… | 0.25 KID | 2234479 | [6b6787e3dc93…](https://explorer.nemtool.com/#/s_tx?hash=6b6787e3dc932030c87a8cf07358347596424b5371d6bf5927e238c4621dcb7d) |

The broader pattern is incomplete: June 12 also has a 1-KID incoming transfer accompanied by a 0.0408-XEM third-address payment without a matching direct XEM payment back to that KID sender in these histories. June 14 and July 12 include outgoing KID accompanied by third-address XEM payments. These exceptions must remain in the ledger; a uniform exchange rule cannot be imposed on every transfer.

NAYIOJ… receives **2.137836 XEM in 6 explicit transfers** from NCIT7A… and returns **1.98117 XEM in 1 transfer**. The parallel recipient is different from the original KID levy address NCEUKZ…. These are separate signed transfers, not the token’s protocol levy or automatically inferred network fees.

## Reproducible evidence

The accompanying JSON includes all 38 new records, the complete new XEM/KID rows, initial incoming XEM for every new participant, raw-derived signer additions, exact reciprocal transaction groups and further block-verification targets. Known KID block timestamps are reused; newly inspected XEM times are explicitly creation timestamps pending additional block checks.

The next useful bounded histories are NBGTCB… (common signer and operational funder) and NAYIOJ… (parallel payment recipient). There is no need to infer child identity, private ownership, merchant purchases or an exchange operator from this record alone.
