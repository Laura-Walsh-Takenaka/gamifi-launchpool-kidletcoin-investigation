# Research Paper — Polygon round trip completed — unassigned Tornado-candidate branch

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

All four previously unresolved BSC→Polygon transfers are now linked to their exact destination transactions. The recipient then returned almost all received USDT to a different BSC address through four further bridges, also linked by exact source transaction hashes.

Scope: this branch came from the 1cf0 gas account through the mixed 8292 wallet and 20f0. No GamiFi Tornado deposit note has been paired with a withdrawal. This work does not allocate the 141,207 USDT requests to 1cf0 or to GamiFi. It resolves the bridge route itself.

## Verified quantities

| Stage | USDT |
|---|---:|
| Requested from BSC 20f0 | 141,207 |
| Delivered to Polygon 82f6 | 141,192.3893 |
| Requested back from Polygon | 141,191.5 |
| Delivered to BSC 1c446 | 141,176.8908 |
| Residual at Polygon block 32,158,846 | 0.8893 |

The Polygon recipient had zero USDT immediately before the first receipt. A gap-free USDT Transfer-event scan from block 32,157,228 through 32,201,173 recovered exactly four incoming and four outgoing transfers. The historical balance equation reconciles exactly: 0 + 141,192.3893 − 141,191.5 = 0.8893. Thus the bounded Polygon onward flows are funded by the four matched bridge receipts. This does not resolve the upstream mixed-funds attribution.

Measured source/destination differences are 14.6107 USDT outbound and 14.6092 USDT on return. These are not separately asserted as verified fees; a historical fee schedule was not recovered.

## BSC → Polygon completions

| Source transaction | Completion transaction | Received USDT | Completion UTC on 21 August 2022 | Delay |
|---|---|---:|---|---:|
| [0x226f283da928fcb4a875b4ae9e63ca975c7f816a2d9dc42eabee6e71e5d35689](https://bscscan.com/tx/0x226f283da928fcb4a875b4ae9e63ca975c7f816a2d9dc42eabee6e71e5d35689) | [0x00b1af18a0fb93c0895d91bcdf18eecc917415aadf11eddd1554b4e5af7f4da9](https://polygonscan.com/tx/0x00b1af18a0fb93c0895d91bcdf18eecc917415aadf11eddd1554b4e5af7f4da9) | 99.5 | 15:54:27 | 77 s |
| [0x8bf60de37cf6b76c619515f4f4b89525411755e29d29eb1c9343cedd7fb2fa58](https://bscscan.com/tx/0x8bf60de37cf6b76c619515f4f4b89525411755e29d29eb1c9343cedd7fb2fa58) | [0x85b15f2b89b60fa887c104c36959264a4786903534257adfc410865739828409](https://polygonscan.com/tx/0x85b15f2b89b60fa887c104c36959264a4786903534257adfc410865739828409) | 9999 | 16:10:24 | 98 s |
| [0x34d96bba38436bdc872dd565c54d7674f121869f95f74ce8f3d76439f9d2fead](https://bscscan.com/tx/0x34d96bba38436bdc872dd565c54d7674f121869f95f74ce8f3d76439f9d2fead) | [0xa738660f41217a9e20a46537b27ad922b964b469f52771d53039dc8f5f9aaaa3](https://polygonscan.com/tx/0xa738660f41217a9e20a46537b27ad922b964b469f52771d53039dc8f5f9aaaa3) | 29997 | 16:20:18 | 80 s |
| [0xbb03af6388c994425f786418c285763b21153e967a081e10c10d891c98a48f4f](https://bscscan.com/tx/0xbb03af6388c994425f786418c285763b21153e967a081e10c10d891c98a48f4f) | [0xa6ed5d66758ff36cf1c819759b419bfa90c8026fb3e0c6f43457b76d16ed2a85](https://polygonscan.com/tx/0xa6ed5d66758ff36cf1c819759b419bfa90c8026fb3e0c6f43457b76d16ed2a85) | 101096.8893 | 16:24:22 | 84 s |

## Polygon → BSC completions

| Source transaction | Completion transaction | Received USDT | Completion UTC on 21 August 2022 | Delay |
|---|---|---:|---|---:|
| [0x4a7861a599aceed6368bb586d4acacb2a8ef7ce9b0f0cf024db1c8c860ec7945](https://polygonscan.com/tx/0x4a7861a599aceed6368bb586d4acacb2a8ef7ce9b0f0cf024db1c8c860ec7945) | [0x9e788f0be2bbc93451b50396c65a8037e76790c46cddecc6353aed211c379ae9](https://bscscan.com/tx/0x9e788f0be2bbc93451b50396c65a8037e76790c46cddecc6353aed211c379ae9) | 99 | 16:05:34 | 455 s |
| [0xcfd566e2686d7d6c06cc660f8a48f0b9777f24f4bf9e9fe1f457969485833535](https://polygonscan.com/tx/0xcfd566e2686d7d6c06cc660f8a48f0b9777f24f4bf9e9fe1f457969485833535) | [0x0d2c779a049b5cb61375edee312a5f1a87190c6b4f312d3a6d91e1c9a13649a2](https://bscscan.com/tx/0x0d2c779a049b5cb61375edee312a5f1a87190c6b4f312d3a6d91e1c9a13649a2) | 9998.0001 | 16:24:22 | 482 s |
| [0x22f323a47602e1c59785a0541b86bb6da4187947e33ff1a668453d425e5c2fde](https://polygonscan.com/tx/0x22f323a47602e1c59785a0541b86bb6da4187947e33ff1a668453d425e5c2fde) | [0xdffef59ce1facbf600a0144fba29a5b2207458ba4c8f66b7c1baae9c0e3d74f4](https://bscscan.com/tx/0xdffef59ce1facbf600a0144fba29a5b2207458ba4c8f66b7c1baae9c0e3d74f4) | 49995 | 16:33:19 | 463 s |
| [0x48d6d9ec132a95e7ff2c80a986d1ff794fab7f430a365a9946c4b077a79d82cb](https://polygonscan.com/tx/0x48d6d9ec132a95e7ff2c80a986d1ff794fab7f430a365a9946c4b077a79d82cb) | [0x4eddaaed480feb4608d38a2f341270441821512c0b3df085e796f1283d6b93f0](https://bscscan.com/tx/0x4eddaaed480feb4608d38a2f341270441821512c0b3df085e796f1283d6b93f0) | 81084.8907 | 16:45:52 | 460 s |

## Return instructions from Polygon

| Transaction | Requested USDT | UTC on 21 August 2022 |
|---|---:|---|
| [0x4a7861a599aceed6368bb586d4acacb2a8ef7ce9b0f0cf024db1c8c860ec7945](https://polygonscan.com/tx/0x4a7861a599aceed6368bb586d4acacb2a8ef7ce9b0f0cf024db1c8c860ec7945) | 99.5 | 15:57:59 |
| [0xcfd566e2686d7d6c06cc660f8a48f0b9777f24f4bf9e9fe1f457969485833535](https://polygonscan.com/tx/0xcfd566e2686d7d6c06cc660f8a48f0b9777f24f4bf9e9fe1f457969485833535) | 9999 | 16:16:20 |
| [0x22f323a47602e1c59785a0541b86bb6da4187947e33ff1a668453d425e5c2fde](https://polygonscan.com/tx/0x22f323a47602e1c59785a0541b86bb6da4187947e33ff1a668453d425e5c2fde) | 50000 | 16:25:36 |
| [0x48d6d9ec132a95e7ff2c80a986d1ff794fab7f430a365a9946c4b077a79d82cb](https://polygonscan.com/tx/0x48d6d9ec132a95e7ff2c80a986d1ff794fab7f430a365a9946c4b077a79d82cb) | 81093 | 16:38:12 |

All four requests name destination chain 56 and recipient `0x1c44608f21043bac13bd6f2e078fc9889e719187`. The initial Polygon recipient is `0x82f6ac7d4c8a00a4cced3f673d67e1bcf8d7e8f8`; the initial BSC sender is `0x20f0ad2e0bd202a57bdf1aa53524145a2e8d5f4d`. No Polygon exchange endpoint was identified. The BSC return recipient is being reviewed separately.

## Verification and retrieval coverage

- Twelve full transactions, successful receipts and block headers were retrieved and cross-checked: four Polygon arrivals, four Polygon return requests and four BSC arrivals. Each transaction occurs in the returned block transaction list.
- Every completion has the source hash in both its calldata and indexed `LogAnySwapIn` event; destination, chain IDs and quantity agree. Each receipt includes the corresponding underlying USDT transfer.
- Polygon USDT contract `0xc2132d05d31c914a87c6611c10748aeb04b58e8f` reports six decimals and symbol USDT at historical block 32,157,574. BSC USDT is the previously verified `0x55d398326f99059ff775485246999027b3197955`.
- The protocol-log window covers blocks 32,157,539–32,196,628, found by historical timestamp bisection. It starts at the first BSC request time and reaches the first Polygon block at or after 24 hours later. Four successful ≤10,000-block queries recover the complete interval.
- Ten failed RPC retrievals were resolved: eight PublicNode transaction/receipt lookups returned null and were recovered at QuickNode; two oversized log calls were recovered with four smaller ranges. All failed raw responses remain preserved.
- Blockscout incorrectly omitted the 2022 normal/token activity in the returned history; its zero-row history was not treated as absence. PolygonScan page fetches returned HTTP 403. Direct RPC supplied the successful proof.
- Polygon nonce was 7 after the final return and at the end of the bounded token scan. A later unpinned nonce query returned 9. A separate follow-up verified nonce 7 on 23 November; nonce 8 remains unexamined. This is not a lifetime normal-transaction census.

## Reproducible evidence

Canonical machine-readable results: `polygon_findings.json`. Full cross-check results: `verification_checks.json`. Per-request outcomes: `request_coverage.json`. Raw JSON captures are under `raw/`; every capture includes request URL/payload, fetch UTC, HTTP status and response content/hash. `verified_completion_raw_bundle.json`, `verified_onward_raw_bundle.json` and `verified_return_bsc_raw_bundle.json` assemble the 12 full records. Prior evidence was read without modification.

Primary reference pages discovered before direct RPC queries: [Polygon RPC endpoints](https://docs.polygon.technology/pos/reference/rpc-endpoints), [Blockscout REST pagination](https://docs.blockscout.com/devs/apis/rest), and [PolygonScan verified Router V4](https://polygonscan.com/address/0x4f3aff3a747fcade12598081e80c6605a8be192f). Search recovered the router ABI, but direct PolygonScan page retrieval failed; the transaction-level proof uses RPC records.

## Subsequent November connection

On 23 November 2022 at 10:50:05 UTC, the same Polygon address 82f6 made [another bridge request](https://polygonscan.com/tx/0x81c690c2a131344c553bd990c8fd527005dee572d1ad25a746a15c20b183f14b) for **70,155.6 USDT** to chain 1 (Ethereum), naming recipient `0x1c44608f21043bac13bd6f2e078fc9889e719187`. The full transaction, successful receipt, underlying transfer, protocol event and block header agree. This is sender nonce 7, one of the two later transactions disclosed above. The return-onward analysis verifies the Ethereum completion separately. The new Polygon funding for this November transfer remains untraced here; the August 0.8893 USDT residual cannot fund it. See `november_polygon_request_findings.json` and `november_polygon_request.json`.
