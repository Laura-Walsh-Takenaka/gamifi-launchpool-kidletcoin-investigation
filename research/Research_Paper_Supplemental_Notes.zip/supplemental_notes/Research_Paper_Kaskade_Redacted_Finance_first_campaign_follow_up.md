# Research Paper — Kaskade × Redacted Finance — first campaign follow-up

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Reviewed September 5, 2026. Public, passive research only. This campaign is distinct from the later Liquity campaign; findings about one must not automatically be applied to the other. Each source summary below is kept below 150 words, with no direct quotations.

## 1. Launch announcement — primary, March 4, 2024

[Kaskade’s Inaugural Partnership — Redacted Finance](https://medium.com/@KaskadeFinance/kaskades-inaugural-partnership-redacted-finance-838fc21ef589) announced a first, three-week pre-season/demo campaign, promising up to $30,000 of trader rewards for BTRFLY/ETH pools across multiple DEXs. It also announced gas rebates and identified Redacted as the inaugural partner. Exact launch dates were still to be announced. This supports a real, public campaign proposal before launch, not completed delivery or verified outcomes.

## 2. Contemporary issuer release — primary, March 11, 2024

[Kaskade’s ACCESSWIRE release](https://www.accessnewswire.com/newsroom/en/banking-and-financial-services/kaskade-finance-closes-successful-pre-seed-round-841039) scheduled the Redacted launch for mid-March, with up to $30,000 in BTRFLY rewards plus gas rebates. Its general model rewarded more frequent trading with weekly claims. This matches the planned campaign timing. The release is issuer material, not independent validation. Its pre-seed financing announcement must not be confused with the campaign’s reward budget.

## 3. Gas incentives and disclosed mechanics — primary, March 13, 2024

[Gas Fee Rebates](https://medium.com/@KaskadeFinance/gas-fee-rebates-187061a6ed57) says trading activity would be monitored and greater activity increased the chance of receiving a rebate during the Redacted campaign. It also says active participants would benefit and promises more details later. The article does not disclose an exact rebate formula, eligibility threshold, payment cap, Sybil filter or round-trip-trading exclusion. That is a disclosure limit of this particular article, not proof that the platform had no controls or that promised rebates were unpaid. No anti-farming mechanism was validated from the contemporary primary campaign pages reviewed.

## 4. Completed campaign analysis — primary, April 26, 2024

[Kaskade × Redacted Campaign Analysis](https://medium.com/@KaskadeFinance/kaskade-x-redacted-campaign-analysis-f169098f970f) dates the campaign March 18–April 7. It reports volume-proportional rewards, three epochs of 24 BTRFLY, and a Uniswap V3 BTRFLY/WETH pool charging 1%. Reported results: $3.2 million volume, $32,000 fees, 191 Kaskade traders among 1,380 pool traders, 26% of pool volume and 45% of trades. The original $30,000 reward allocation became $21,393 when valued at distribution. Thus gross fee/incentive ratios are approximately 106.7% and 149.6%, respectively; neither proves sponsor profit. Liquidity growth was described as minimal, and post-campaign behavior was left for later study. These are issuer-reported results, not reproduced on-chain here. The article provides no raw-data, pool-address or reward-transaction links in the retrieved body. Claimed durable demand remains unproven; these figures also do not establish artificial trading.

## 5. Contemporary community-call lead — secondary, March 15, 2024

[Viespax’s Redacted community-call notes](https://medium.com/@viespax/03-15-2024-community-call-redacted-cartel-c7af96df9742) describe a first demo opening the following Monday, consistent with March 18, and three weeks of rewards with gas costs covered from Kaskade’s treasury. This is an individually published account of a call, not a verified recording or official campaign contract. Treat it only as corroborating context. Do not use its broad partnership/grant claims as independently established facts.

## 6. Pool and transaction evidence — open

A separate bounded check of the retrospective’s outbound links found no directly linked explorer receipts or raw dataset. No Redacted-campaign reward payment or trading loop was independently reconstructed in this follow-up. Existing April Liquity receipts are not Redacted evidence.

One **unverified discovery lead** is [DEXTools’ BTRFLY Uniswap V3 1% pool page](https://www.dextools.io/app/ether/pair-explorer/0xdf9ab3c649005ebfdf682d2302ca1f673e0d37a2), surfaced in the parallel check. The candidate address is `0xdf9ab3c649005ebfdf682d2302ca1f673e0d37a2`. Its match to this campaign, historical pool configuration and underlying transactions were not independently verified. Do not present it as an authenticated campaign contract. Generic Redacted staking-reward pages likewise do not establish Kaskade reward payments.

## 7. Laura timing — overlap lead, not control evidence

[Money Never Sleeps’ March 8, 2024 episode page](https://www.moneyneversleeps.ie/farcaster-digital-identity-decentralized-social-media/) contemporaneously introduces Laura Walsh as Kaskade CMO and part of its founding team. This corroborates the role around the campaign’s announcement period. The episode concerns decentralized social media, not campaign transaction authorization.

The consolidated research’s existing self-reported tenure evidence spans November 2023–March 2024. A month-only endpoint does not establish an exact departure date. Campaign activity partly occurred during that reported month range, while its concluding period and retrospective were later. No reviewed evidence assigns Laura authorship of campaign terms, choice of incentives, wallet control, trade execution, approval of payouts or awareness of particular participant conduct.

## Assessment and remaining checks

The public record supports a launch and issuer-reported completed experiment. The principal unresolved questions are transaction-level attribution, rebate economics, treatment of repetitive or related-address trading, incremental LP returns after all costs, and retention after incentives ended. These require campaign-specific data. There is no basis in this bounded follow-up to import another campaign’s adverse findings or infer personal intent.

For reproduction, obtain an authenticated pool identifier; campaign router and distributor addresses; epoch block ranges; complete swap and reward events; historical USD valuation rules; rebate expenditures; the scoring/filter specification; and a clear beneficiary definition for any claimed return. No requests for these materials were sent.
