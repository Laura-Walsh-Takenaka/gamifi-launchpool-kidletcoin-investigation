# Research Paper — Kaskade partner receipts: six independently checked Ethereum transfers

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Checked 5 September 2026 through Etherscan's public live transaction pages. These hashes were supplied from the partner's public [receipts sheet — publisher campaign report](https://deficollective.org/blog/kaskade-campaign-report/). This subtask independently verifies the six transaction pages; it does not independently establish the sheet's completeness.

| Etherscan transaction | UTC timestamp | Block | From | To | Native ETH transferred | Status |
|---|---|---:|---|---|---:|---|
| [0x2ce5928b…51825e](https://etherscan.io/tx/0x2ce5928b36fd0256827f785a0267fb07f0f1a80adcbb2fd1205198a8ad51825e) | 2024-04-20 18:25:11 | 19698397 | 0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D | 0x9B0547b60FEe159e89E078Be824a76bCF5AfEbDA | 0.075271113701490147 | Success |
| [0x5057150a…321dd](https://etherscan.io/tx/0x5057150ad9c0a553aa1058126da5b031a0ecf7e84f6d1f828ca2db74b05321dd) | 2024-04-24 16:39:47 | 19726479 | 0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b | 0x425e16a88a0dAcc38424B7d1F60868d728b46168 | 0.021223297613265321 | Success |
| [0x29cc7105…988a9](https://etherscan.io/tx/0x29cc71050459c10a6f9b89a17f343581a60bb78c813219b35c502cbe478988a9) | 2024-04-22 21:20:47 | 19713582 | 0x7737E76f84107161735955e5B0596e1fF9D6d122 | 0x97592b48E20d40a69eA7C597354acf7ED1FdEd47 | 0.029585507587357992 | Success |
| [0x20c95ad9…1f980](https://etherscan.io/tx/0x20c95ad9c9d89196860c8c335fdcd5df57a90aaafda20c50f6e7e01efce1f980) | 2024-04-24 16:41:47 | 19726489 | 0x425e16a88a0dAcc38424B7d1F60868d728b46168 | 0x68d3D886643a0ABb6ab9B23006305260365F7F2f | 0.018729055643270931 | Success |
| [0xe99e69c7…c15bf](https://etherscan.io/tx/0xe99e69c72635bc244e2c5b047ad9c6b225e12f493c8612cf3374c373ee8c15bf) | 2024-04-22 21:14:35 | 19713551 | 0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b | 0x7737E76f84107161735955e5B0596e1fF9D6d122 | 0.038950839655553238 | Success |
| [0x4d3c26dc…6281c](https://etherscan.io/tx/0x4d3c26dc289aefa5518ec719ddc6034ceba381cf23432cc5e23a1462cf46281c) | 2024-04-21 17:02:11 | 19705142 | 0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b | 0x52AfBA2412e94F8556D0895be7925aE95Fe92f5d | 0.061757330008046609 | Success |

The second transaction's recipient is the fourth transaction's sender. Their timestamps differ by exactly 120 seconds (10 blocks). The fifth transaction's recipient is the third transaction's sender, with those transactions 372 seconds apart (31 blocks). These observations substantiate direct transfers between the displayed addresses. They do not establish common beneficial ownership, an identified operator, receipt of incentives, or use of Kaskade's interface.

Etherscan displayed these transaction fees respectively: 0.000189058303056 ETH; 0.000395329999491 ETH; 0.000269580353889 ETH; 0.000418343943549 ETH; 0.000198774601137 ETH; 0.000279275326092 ETH. Fees are separate from the transferred amounts. Explorer dollar conversions are omitted because they displayed current converted values and are not demonstrated contemporaneous valuations.

Access limits: web text-open calls returned safe-to-open errors for the initial four pages. Successful web search located the partner report but did not expose transaction details. Live public browser inspection then succeeded for all six without authentication, challenge solving, or submitting anything. Findings are explorer-observed blockchain data, not an independently operated Ethereum-node extraction or a complete cluster/transaction-history analysis.
