# Research Paper — Independent review — Time Raiders Polygon vesting and November 2025 withdrawal

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

7 September 2026 UTC. Scope: independent arithmetic/signature review of the delivery lane and fresh checks of five decisive transactions. No modifications to the source lane or PDFs.

**Result: no material amount or address error found.** The evidence supports removal and subsequent sale of the contract's entire XPND backing, matching the historical unclaimed vesting amounts immediately before the upgrade. It does not identify Laura or another human, prove knowing consent or unauthorized access, establish the beneficial owner of the destination, or establish contemporary economic loss after any migration/compensation arrangements.

## Amounts independently recomputed

I decoded the original `initiateVests` transaction calldata, all 149 saved raw RPC vesting records at block 78,964,530, the actual initial token-transfer receipt, and the 440 saved explorer-indexed claim receipts. I did not rely on the agent's computed totals. The 437 successful later claims plus initial transfers equal each of the 149 records' claimed amount exactly; three failed calls made no token transfers. Original BSC funding logs independently reproduce 80 funders and each allocation using per-contribution integer flooring at 0.022 BUSD/XPND.

| Population | Allocated XPND | Actually transferred XPND | Recorded outstanding XPND | Addresses with positive remainder |
|---|---:|---:|---:|---:|
| All 149 records | 3,409,091 | 1,896,513.336249580361663604 | 1,512,577.663750419638336396 | 107 |
| Original 80 BSC funders | 1,078,305.261888163402722904 | 634,523.415691679492334646 | 443,781.846196483910388258 | 38 |
| Other 69 allocations | 2,330,785.738111836597277096 | 1,261,989.920557900869328958 | 1,068,795.817553935727948138 | 69 |

The recorded vesting period had fully elapsed before November 2025; under the reviewed original code the remaining amount was claimable, without a claim-expiry rule in that code. That is a contract-state finding, not a finding about external settlement or legal entitlement after any superseding agreement.

The withdrawal receipt contains exactly **1,512,577.663750419638336396 XPND**, from `0xcfb37488ee5ebbadf9b879c05d318beb7b85f6a5` to `0x4d96f2d2143dd74a96d015a70953a5686fa6ed55`. Fresh before/after calls confirm the vesting balance became zero and the destination's XPND balance rose from zero to that exact amount.

## Authority and chronology

Fresh transaction, receipt and block-header retrievals confirm:

| UTC | Event | Transaction |
|---|---|---|
| 2022-09-29 08:22:14 | Vesting contract ownership changes from 3e0f to f27f; the separately held ProxyAdmin ownership remains 3e0f in the preserved historical state sample | `0x8f0d64e9b434bc9da6b06e16b91442739e126ae2ab54f2db7839991afea38c8d` |
| 2025-11-13 11:37:26 | Outer sender 4d96 submits a type-4 transaction to 3e0f, replacing its existing delegation and transferring ProxyAdmin ownership from 3e0f to 4d96 | `0x4e8f533f07d6294332437777661389d9fb6668c768bc49c645c5c868af3b2d84` |
| 2025-11-13 11:39:08 | 4d96 calls ProxyAdmin and upgrades the vesting implementation to d346 | `0x70b2ca519be59b73947714d7c9fcc7dcfe0b8aa4e3a2f59ad5f97044f494755a` |
| 2025-11-13 11:40:16 | 4d96 calls the upgraded vesting contract; all its XPND moves to 4d96 | `0xbd929f950089a74c90bff99743514421126bf31a9abd4c943fefb6cee317b38a` |
| 2025-11-13 11:46:10 | 4d96 sends the full received XPND into a swap execution and receives native POL | `0x97b91a02cd4efa3668fccfe2962e40fb7f398c3587b3a4613ff8bbbd65aeff64` |

Using independent local secp256k1 arithmetic, the EIP-7702 authorization recovers to `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`. The signature verifies, has low-s form, chain ID 137 and authorization nonce 35. This reproduces the other agent's separate precompile-based result. The [primary EIP](https://eips.ethereum.org/EIPS/eip-7702) defines that recovered address as the authority. It does not identify who physically signed, whether access was compromised, or what the signer understood.

**Required distinctions:** 3e0f was the ProxyAdmin owner, while f27f was the vesting owner immediately before the upgrade. November 13 replaced an existing EIP-7702 delegation (`a50f…db66` to `af27…67e9`); it was not the first delegation. An `owner()` call reverting after the upgrade is not proof that all prior storage was deleted or that remediation became impossible.

## Onward swap independently checked

The successful swap consumes the destination's exact XPND holding; its XPND balance is zero after that block. The native system log pays **325.142524926446493136 POL gross** to 4d96. I independently recomputed the `LogTransfer` topic from its signature and checked its balance words using the [Polygon-published event schema](https://medium.com/the-polygon-blog/finer-details-of-matics-plasma-implementation-jaynti-kanani-d333550fa71d).

A fresh native-balance cross-check corroborates the payout: the destination's block balance increases **325.048546292010275756 POL**, and the swap transaction's fee is **0.093978634436217380 POL**. Their sum equals the gross payout exactly. This is net of this swap's gas only, not overall profit after earlier transaction costs.

USDC, WBTC and WPOL route legs are intermediates, not additional sale proceeds. The separate 3,781.444159376049095840 XPND split to `cd6b…9799` must not be called a fee without evidence. Neither the original offering price nor an intermediary stablecoin amount measures the beneficiaries' contemporary economic loss.

## Remaining qualifications and verification limits

- Say **149 allocation records / 107 outstanding addresses**, and **80 original funders / 38 outstanding addresses**. Forty-two original funders had already fully claimed; all 80 received initial tokens.
- The destination's explorer phishing label is a third-party investigative lead, not independently established identity or a legal finding. The authority recovery does not establish Laura's participation.
- The existing issuer/Telegram corpus reviewed in this lane is predominantly from 2022. It cannot establish absence of a 2025 migration, compensation, incident disclosure, or settlement. The receipt of sale proceeds does not resolve those questions.
- Claim receipt coverage is all 440 explorer-indexed ordinary Claim transactions and its exact reconciliation to all 149 saved records; it is not a complete all-block internal-call census.
- Three alternate public Polygon providers rejected requests (403/401). The reviewer freshly retrieved and matched the decisive receipts through the **same QuickNode provider** used by the source lane. Do not describe this as cross-provider receipt agreement. The arithmetic and local signature recovery are independent methods.

Files: `independent_recalculation.json`, `independent_signature_recovery.json`, `fresh_primary_checks.json`, `independent_swap_recalculation.json`, and `chain_raw/`. The preserved source lane contains the byte-for-byte runtime compilation checks; I reviewed their output and code semantics but did not rerun compilation.
