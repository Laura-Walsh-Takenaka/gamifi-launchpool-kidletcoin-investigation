# Research Paper — Gazette access: the gap is narrower than the previous summary implied

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

**Historical liquidation notices are not uniformly inaccessible without payment.** The Gazette describes a paid archival subscription, but this review successfully downloaded older liquidation PDFs from publicly indexed URLs on its own host. The government also intentionally republishes selected complete Gazettes on its main website during service outages. Those are genuine free routes for particular issues; neither route provides a complete searchable corporate history.

### Published access rules versus observed access

| Material or function | Published access rule | What was verified in this review |
|---|---|---|
| Complete Gazette, first two months after publication | Free basic registered account | Official Help and FAQ describe this entitlement; no account was created. |
| Government and Statutory sections older than two months | Free basic account | Older Part 1 PDFs downloaded without credentials from public search results. |
| Separately listed attachments, including legislation | Remain free according to FAQ | Entitlement verified from FAQ; attachments are distinct from commercial notices. |
| Liquidation and Other sections older than two months | Enhanced subscription, advertised at $500 per year | Selected older Part 2 files nevertheless downloaded from their publicly indexed official URLs, without credentials. |
| Gazette website's own search and recent-publication menu | Website login required for search | Anonymous Recent Publications request returned HTTP 403; this is an access result, not evidence of a company notice. |
| Complete issues republished in government bulletins | Bulletin invites public review | Full 26 March and 30 July 2026 issues downloaded from gov.vg without registration. |

Sources: [GZ-01], [GZ-02], [GZ-04], [GZ-05], and downloaded PDFs [GZ-P01]–[GZ-P11]. The $500 is the amount displayed by the official Help page; it was not a checkout quote. No fee was paid. Basic registration asks for name, email and password. A free account is a useful next step, but it does not confer the published paid archival entitlement. [GZ-01]

### A particularly clear free example: March 2026 liquidation notices

The Cabinet Office's bulletin of 26 March 2026 explicitly attached Gazette No. 29 while the Gazette website was experiencing technical difficulties. The attached 72-page PDF remains downloadable in this review on 6 September 2026—more than two months after publication. Its cover identifies Liquidator Appointments at printed page 1013, Dissolution Notices at 1038, other liquidation notices at 1056 and company continuations at 1058. The commercial section starts at PDF page 26, printed page 1013. This directly disproves an absolute claim that every older liquidation notice requires buying a subscription. [GZ-04, GZ-P10]

A second Cabinet Office bulletin dated 31 July 2026 supplies the complete 78-page Gazette No. 80 of 30 July 2026. This is a currently recent issue, independently available through the government bulletin. Neither sample contains a text match for Gamifi or 2082070. [GZ-05, GZ-P11]

### Corporate-status information can also appear in the free Part 1

The official 16 June 2022 Part 1 contains Registrar notices warning that named companies may be struck off for failure to appoint a registered agent. Those notices begin at PDF page 23; the 15 December 2022 Part 1 contains similar warnings at PDF page 4. These are examples involving other companies, not GamiFi findings. They show why an investigation should examine Government and Statutory notices as well as the commercial liquidation section. A warning, completed strike-off, voluntary liquidation and dissolution are separate events and should be recorded separately if a matching notice is found. [GZ-P03, GZ-P06]

### Exact coverage of the free PDF search

Eleven discovered Gazette files were downloaded successfully, comprising **599 PDF pages**. Ten files, **511 pages**, are dated after the secondary-reported November 2021 incorporation date; the May 2021 file was an access demonstration only. Text extraction succeeded for all eleven. Case-insensitive `Gamifi`, a whitespace-tolerant spelling check, and whitespace-tolerant `2082070` produced **zero matches**. This is a bounded text search of these files, not a visual examination of every notice and not an exhaustive archive search. It cannot detect a name appearing solely in an unrecognized image or establish the company's present status.

| Reference | Gazette date / issue | Saved portion | PDF pages | Source classification |
|---|---|---|---:|---|
| GZ-P01 | 6 May 2021 / 42 | Part 2; access example before reported incorporation | 88 | Official Gazette host |
| GZ-P02 | 3 March 2022 / 14 | Part 2 | 41 | Official Gazette host |
| GZ-P03 | 16 June 2022 / 47 | Part 1 | 66 | Official Gazette host |
| GZ-P04 | 14 July 2022 / 60 | Part 2 | 29 | Official Gazette host |
| GZ-P05 | 15 September 2022 / 84 | Part 2 | 35 | Official Gazette host |
| GZ-P06 | 15 December 2022 / 115 | Part 1 | 46 | Official Gazette host |
| GZ-P07 | 2 February 2023 / 12 | Part 2 | 59 | Official Gazette host |
| GZ-P08 | 23 February 2023 / 21 | Part 2 | 51 | Official Gazette host |
| GZ-P09 | 11 April 2024 / 35 | 34-page republished extract | 34 | Third-party hosted Gazette copy |
| GZ-P10 | 26 March 2026 / 29 | Complete issue | 72 | Official government bulletin attachment |
| GZ-P11 | 30 July 2026 / 80 | Complete issue | 78 | Official government bulletin attachment |

The April 2024 copy is hosted by europeanmet.com. It was obtained openly and checked as a potential source, but was not byte-matched to an official original and is labelled accordingly. Its presence supplies no relationship between its host, GamiFi or any company named in it. Direct official-host files and government bulletin attachments are the stronger evidence of public availability.

Targeted web searches also included the exact company name, entity number, Gazette domain and liquidation terms, using two search engines. No verified GamiFi liquidation or dissolution notice emerged. Search results were incomplete and sometimes broadened into unrelated names or identical numbers; none was treated as a company match. The official internal Gazette search was not run because it requires a login. No 2025 issue was recovered in this bounded sample. The source manifest records exact URLs, retrieval times, successful bytes, hashes and failed access attempts.

### Legitimate next steps without a subscription purchase

1. **Use a free basic Gazette account.** Register at the official link, then use the site's internal search for `Gamifi`, `Gamifi Limited` and `2082070`. Check both Ordinary and Extraordinary issues. For the historical project, use November 2021 through the present; retain any exact-match result, issue date, section and printed page. Save the original PDF rather than a cropped search result. This work did not create an account or test its search coverage.
2. **Use the issue links already preserved.** The two government bulletin attachments and selected publicly indexed official PDFs are working free sources now. Their absence of a GamiFi match does not fill intervening dates.
3. **Ask an existing institutional subscriber or investigator to check its lawful access.** An institutional or library collection may already hold the relevant Gazette, but no particular third-party subscription or free entitlement was verified here. Request a specific company-and-number search or cited pages, not someone else's credentials. No requests were sent.
4. **Use the Gazette Office's physical holdings as a fallback lead.** Its History page states that a complete 1967-to-present set is kept at the Passport Office. The FAQ advertises individual copies at $0.50 per page, so an annual subscription is not the only described paid route. Neither in-person free inspection nor free remote copies are promised on the sources reviewed. Ask first whether a no-charge company-name index search or inspection is available. This is a request to clarify service availability, not a verified free service. [GZ-02, GZ-03]

### Posted prices and service-detail caution

The FAQ displays annual print subscriptions of $300 within BVI, $350 within the Caribbean and $450 elsewhere; its individual-copy price is $0.50 per page. These are posted figures, not confirmed quotations. The Help page advertises $500 for annual enhanced electronic access. No shorter enhanced term or verified free complete archive was found. [GZ-01, GZ-02]

The FAQ still refers to an intended archive expansion in 2007, and older pages give different office locations. Therefore its physical holdings and print service details are leads to confirm before travel or ordering. The official Gazette website is the locator for current service information. No contact was made. [GZ-03, GZ-P10, GZ-P11]

## Gazette source register

All online checks below were made on 6 September 2026. PDF page numbers are one-based physical PDF pages; printed page numbers are specified separately.

- **GZ-01 — Official Gazette Help & Support:** sections “How to Read”, “How to Search”, and “How to Subscribe”; free basic account, two-month window, archived access rule, advertised enhanced price. https://eservices.gov.vg/gazette/content/help-support
- **GZ-02 — Official Gazette FAQ:** full-text parts, free access, attachments, hard-copy routes, account registration and stale 2007 wording. https://eservices.gov.vg/gazette/content/faqs
- **GZ-03 — Official Gazette History:** physical 1967–present holding statement. https://eservices.gov.vg/gazette/history-official-gazette
- **GZ-04 — Cabinet Office, Gazette No. 29 available for public review:** 26 March 2026 bulletin and direct attachment. https://gov.vg/news/gazette-no-29-2026-available-public-review
- **GZ-05 — Cabinet Office, Gazette No. 80 available for public review:** 31 July 2026 bulletin and direct attachment. https://gov.vg/news/gazette-no-80-2026-available-public-review
- **GZ-06 — Recent Publications access test:** anonymous HTTP 403 on the link published by Help; no content obtained. https://eservices.gov.vg/gazette/content/recent-gazettes
- **GZ-07 — Gazette registration link:** official registration destination; account not created. https://eservices.gov.vg/gazette/user/register

- **GZ-P01 — 6 May 2021 / 42, Part 2; access example before reported incorporation:** 88 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/LiquidationandOtherNotices/%2342%206th%20May%2C%202021%20Part%202.pdf

- **GZ-P02 — 3 March 2022 / 14, Part 2:** 41 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/LiquidationandOtherNotices/%2314%203rd%20March%2C%202022%20Part%202_0.pdf

- **GZ-P03 — 16 June 2022 / 47, Part 1:** 66 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/governmentandstatutorynotices/%2347%2016th%20June%2C%202022%20Part%201.pdf

- **GZ-P04 — 14 July 2022 / 60, Part 2:** 29 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/LiquidationandOtherNotices/%2360%2014th%20July%2C%202022%20Part%202.pdf

- **GZ-P05 — 15 September 2022 / 84, Part 2:** 35 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/LiquidationandOtherNotices/%2384%2015th%20September%2C%202022%20Part%202.pdf

- **GZ-P06 — 15 December 2022 / 115, Part 1:** 46 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/governmentandstatutorynotices/%23115%2015th%20December%2C%202022%20Part%201.pdf

- **GZ-P07 — 2 February 2023 / 12, Part 2:** 59 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/LiquidationandOtherNotices/%2312%202nd%20February%2C%202023%20Part%202.pdf

- **GZ-P08 — 23 February 2023 / 21, Part 2:** 51 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/LiquidationandOtherNotices/%2321%2023rd%20February%2C%202023%20Part%202.pdf

- **GZ-P09 — 11 April 2024 / 35, 34-page republished extract:** 34 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://www.europeanmet.com/wp-content/uploads/Virgin-Islands-Official-Gazette-Vol-LV111-No-35-11April2024.pdf

- **GZ-P10 — 26 March 2026 / 29, Complete issue:** 72 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://gov.vg/sites/default/files/2026-03/no_29_26th_march%2C_2026.pdf

- **GZ-P11 — 30 July 2026 / 80, Complete issue:** 78 physical PDF pages; successful ordinary HTTP 200 retrieval; zero target text matches. Source: https://gov.vg/sites/default/files/2026-07/no_80_30th_july%2C_2026_1.pdf
