# Research Paper — Tornado Cash — April batch root significance — follow-up

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

**All ten April 100-BNB candidate withdrawals used the latest pool root as of the immediately preceding block.** In every case, `nextIndex()` confirms that no additional commitment had entered the pool since the d676 deposit batch that created the matching root.

This makes the exact root matches compatible with normal proof construction in a quiet pool. Any holder of an eligible older note could use the same latest root. The matches do not independently identify the source note, common wallet control, or a GamiFi exit to Binance.

The ten tracked d676 deposits have consecutive leaf indices **7911–7920**. Thus no other 100-BNB pool commitment was inserted between the first and last of those ten deposits. This statement concerns that pool and bounded interval only.

| Deposit batch end (UTC) | First candidate using its root (UTC) | Interval |
|---|---|---:|
| April 27, 23:57:24 — fifth deposit | April 28, 00:55:40 — cb18021c… | 58m 16s |
| April 28, 01:04:34 — eighth deposit | April 28, 01:17:46 — 18b59cf0… | 13m 12s |
| April 28, 01:20:58 — tenth deposit | April 28, 01:36:28 — cb3110b9… | 15m 30s |

All ten individual timing intervals were checked against retained deposit and withdrawal block headers. Twenty new historical calls were made: `getLastRoot()` and `nextIndex()` at the block immediately preceding each withdrawal. That boundary does not resolve ordering of any other transactions inside the withdrawal block.

The official client's `buildTree()` refreshes deposit events, appends missing commitments, and takes the resulting `tree.root` for proof construction. `createSnarkProof()` constructs the private note's membership path inside that tree. This supports the normal-client explanation; it does not establish which client these withdrawers used. The source is pinned to an August 2022 revision and is not asserted to be their April software version.

Source: https://github.com/tornadocash/tornado-classic-ui/blob/a83fae0772c8da084c0e76b3a756b456f5b9f5bb/store/application.js

The prior partial exclusions remain valid: cb18021c… cannot spend d676's last five 100-BNB notes; 18b59cf0… cannot spend its last two. Those restrictions exclude later commitments from older tree states and do not identify an earlier spent note. No attribution probability is calculated.

Files: `batch_root_context.json`, `batch_context_request_manifest.json`, `batch_context_header_manifest.json`, `retained_batch_end_headers.json`, `batch_context_QA.json`, and the retained raw captures and official client sources. Prior result files were not overwritten.
