# Research Paper — Secondary address public attribution — 5 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

**No public project, operator or service attribution was recovered for the three queried addresses.** Exact quoted web searches returned no results. All 94 UTF-8 text files in the pinned public Kidlet source snapshot were also searched, including after removing spaces/hyphens: zero matches.

| Address | Public attribution result | Suitable graph label |
|---|---|---|
| `NBGTCBEUP2YW4Y47Q2ACZYCDME6VV6OVVBN7PSS3` | No indexed exact-address result or source-code match | Project control key; human identity unverified |
| `NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE` | No indexed exact-address result or source-code match | Project control key; human identity unverified |
| `NAYIOJM4JXMZXX4QLKROYKTIRGS66244RT6W6PH3` | No indexed exact-address result or source-code match | Unattributed linked counterparty |

The parent investigation reports that the first two keys each received 10 XEM from NBDCOH on 28 May 2019, two seconds apart, and occur in the project control structure. Those observations support recording a shared initial funding source and control membership, with the exact on-chain timestamps and hashes supplied by the parent ledger. They do not provide a published occupational role or human owner. This public-source subtask did not independently replay those transactions.

The parent reports NAYIOJ's payments are linked to NCIT7A. No public service declaration, exchange label or project fee purpose was recovered for that counterparty. A fee or exchange label would currently be unsupported.

Reviewed repository: [Pinned Kidlet source](https://github.com/baconbkk/Kidlet/tree/d8c2e9b3a364734a17bead61f5549672dfb73de6). The source scan is a bounded text check and does not decode image assets. Empty indexed searches are not proof that no off-chain attribution exists. Search/scope details are preserved in `secondary_public_attribution.json`. No minor or private person was identified or associated with any of these addresses.
