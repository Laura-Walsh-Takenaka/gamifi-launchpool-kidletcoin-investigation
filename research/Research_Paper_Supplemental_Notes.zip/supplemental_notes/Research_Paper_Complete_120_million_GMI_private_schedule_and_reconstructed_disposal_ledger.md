# Research Paper — Complete 120-million-GMI private schedule and reconstructed disposal ledger

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research date:6 September 2026. BNB Smart Chain (chain 56). All chain operations were read-only. Exact decimal token amounts below are quantities, not dollar amounts. The separate valuation lane supplies historical asset marks and Bank of Canada daily CAD conversions.

## Principal closure

The previously untraced 107,869,402.006172839506172839 GMI is accounted for by three newly recovered successful claim receipts. Combined with the two earlier selected claims, five actual payouts total exactly 120,000,000 GMI from private vesting contract`0x74e0ddf89807107378beb02e6bc504243e0cdf6c` to beneficiary`0x36048413c4edf0cf3e633aab317fcd9824dfb4d4`.

| UTC | Exact GMI | Transaction |
|---|---:|---|
|2022-11-04 14:25:40|96,645,563.271604938271604938|`0x6f2c3e43f94de965feaf666ad8a35a6951c72a9367360d9dc138d236902e787f`|
|2022-12-06 10:46:01|10,615,821.759259259259259259|`0xf692b324a95a159bd4c5142cd7eed711211ac0b4e85912fa336cfde0ca961453`|
|2022-12-08 06:32:39|608,016.975308641975308642|`0x325e3df49c8f81d74d5343bff786dd8d08f4996d798cefff4a31dcbf8e4b1078`|
|2022-12-14 16:01:19|2,131,635.802469135802469136|`0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639`|
|2023-01-20 05:38:45|9,998,962.191358024691358025|`0x8657b3b3182771a12734fa434536f6f2a667246a2f94998546da301f7e464f3d`|

`full_schedule_claims.json` retains the exact integer equality. A historical`getVest`call immediately before the first November 4 claim records zero claimed. These receipts close this particular schedule without relying solely on its present-day claimed counter. The first claim precedes the separately investigated November 5 Launchpool withdrawals by about 16 hours 20 minutes; timing alone does not establish common human control or a common purpose.

## Complete asset reconciliation for the reconstructed period

The beneficiary held 0 GMI at block 22767132, immediately before the November 4 claim. Its balance was 0 GMI after the final February 26,2023 GMI disposal (block 25994159).

| Movement | Exact GMI |
|---|---:|
|Opening balance|0|
|Five private schedule claims|120,000,000|
|Tokens returned by two liquidity redemptions|29,574,727.895903672410206412|
|Other incoming transfer onDecember 6|9,900|
|Tokens sold in 42 swaps|103,642,447.956409389183293472|
|Tokens deposited in three liquidity additions|27,942,179.939494283226912940|
|Tokens forwarded through`0x9564…d464`|18,000,000|
|Closing balance|0|

Both sides total 149,584,627.895903672410206412 GMI. This is a balance reconciliation; repeated use of fungible tokens in pools is not additional money raised. The reconstructed transfers and sampled balances reconcile exactly, but a net equality alone cannot rule out every hypothetical offsetting transfer outside the retrieved windows. The underlying normal-account history audit and historical logs supply the transaction evidence.

The 9,900 GMI came from`0x391a51d884b240908a88e1e757ec42189d294423` in transaction`0x782a3cb1e15038899222d883a233bcf031c20236ba0b8a3f8584052d799de7ae`, block 23670820. It was discovered by comparing historical end balances, then retrieving all incoming GMI events over the 21,154-block discrepancy interval. It is a separate receipt, not part of the 120-million-token vesting schedule.

## Actual exchange outputs and liquidity activity

The 42 GMI swaps produced exactly:

- 5,361.649777056501864007 BUSD.
- 12.733084792018608967 native BNB.
- 2.296091425541797281 WBNB.
- 13.065639141470576526 CAKE.

These are actual received assets before gas fees. Their historical dollar marks are distinct from dollar cash in a bank. The receipts establish ERC 20 outputs; successful call traces establish native BNB outputs. Dollar marks of swapped-in GMI and swapped-out assets must not be added together.

The liquidity operations are a separate use of assets. Three additions supplied 27,942,179.939494283226912940 GMI and a gross 11.779827980541797281 BNB, receiving 9,177.891351247917090180 LP tokens. Call traces show a 1 wei refund on each addition, so netBNB supplied was 11.779827980541797278. Two removals returned 29,574,727.895903672410206412 GMI and 11.149287235974376070 BNB, consuming the same 9,177.891351247917090180 LP tokens. LP tokens represent positions in a pool and must not be counted as a new sale payment or added to their underlying assets.

## Correction to the earlier CAKE classification

The earlier report excluded a December 14 CAKE sale as unrelated. The expanded receipt history now shows that the beneficiary first received 13.065639141470576526 CAKE in a GMI swap, and subsequently sold exactly that quantity for 49.354088681602483584 BUSD in transaction`0x30c5e3af5fa69cf54e59ec46a3cf3c74ffea59cd3e795cf6aa8923b6482aca71`.

This is an amount-matched asset-conversion sequence. The new ledger includes the later CAKE input and BUSD output as conversion legs. Their value must not be added again to the earlier marked CAKE sale output when summarizing gross GMI exchange proceeds. The new evidence supersedes the earlier 'unrelated CAKE' label.

## Exchange forwarding routes

Three 5-million-GMI transfers went from the beneficiary to`0x9564f530d9f270a48c510a92c97b59248cefd464`, then promptly to`0x2e8f79ad740de90dc5f5a9f0d8d9661a60725e64`:

| Onward block | Exact GMI | Transaction |
|---|---:|---|
|22767814|5,000,000|`0x7f8323049c6585d0dee94b8ba6b7dcb96d9bd0f2ac11617a00ca2299cb7ae3a8`|
|22884854|5,000,000|`0xb0b3bf6768b4cb92820c90c4aca9a2103e3b49c753b31bf6258916b3dab5855c`|
|23716226|5,000,000|`0xff3ac1adab98247b4a1c468612618e00f322c6a7ab66b3b9825150a7f7aa4d8f`|

A fourth 3-million-GMI transfer onJanuary 21,2023 went through the same intermediate address to`0x4982085c9e2f89f2ecb8131eca71afad896e89cb` in transaction`0x2e371d5d37cc3deaef36f8c4798f0a18256257304d8eb4db697e6b4414cec02e`. MEXC's own previously retrieved wallet disclosures identify this latter wallet. The parent attribution lane supplies independent source evaluation for the earlier`0x2e8f…5e64` wallet.

Total forwarded is 18 million GMI, counted once despite two transfer legs per route. The chain does not disclose the exchange customer credited, an off-chain sale, any fiat withdrawal or a bank account. Identifying a service wallet is not identifying a human beneficiary.

## Earlier separate smaller transfers and scope

The beneficiary also sent smaller GMI quantities before November 4. They are preserved as separate early activity, outside the opening-zero balance reconciliation above. Two recipients also occur elsewhere in the investigation:`0xe5d5245dce768ef43f1c5fa9c96b7e1520d96dc8`(additional April funding sender) and`0x35b119730f79881dac623dc51c831c6a04cab5f3`(project withdrawal recipient). Those are observable public wallet links. They do not identify who controlled a key.

The final `material_transfer_ledger.json` contains 148 material asset legs supported by 106 checked transactions: all 100 normal sender transactions and six additional inbound or intermediate-forwarding transactions. `complete_sender_nonce_audit.json` contains every nonce from 0 through 99 and every corresponding receipt. Nine failed transactions (nonces 14, 17, 19, 50, 54, 64, 67, 71 and 92) contribute no completed asset movement. The current sampled nonce remains 100 at block 120238607. This closes the normal sender-transaction inventory through that sample; incoming transactions initiated by other accounts and internal native funding are a separate coverage question.

The normal transactions span February 1, 2022 through April 4, 2023. All 5,361.649777056501864007 BUSD obtained in GMI swaps plus the later 49.354088681602483584 BUSD from the linked CAKE conversion total exactly 5,411.003865738104347591 BUSD, matching the aggregate BUSD forwarded to `0xf4f86e37815217ed73ae817a4e5164d56315b1d7`. An earlier separate 2,000-BUSD transfer on March 11, 2022 went to `0x391a51d884b240908a88e1e757ec42189d294423`. The amount equality is an aggregate flow reconciliation, not a bank receipt or attribution of a human owner.

Seven normal native transfers between September 23, 2022 and April 4, 2023 sent a combined 27.336801380291603498 BNB to the same `0xf4f8…b1d7` recipient. These native funds were commingled, including liquidity-related activity and external funding; the complete third-party native funding history has not been reconstructed here. This full forwarding amount must not be labeled additional GMI sale income.

The 2.296091425541797281 WBNB received in GMI swaps was subsequently unwrapped into exactly the same quantity of native BNB. Both conversion legs are retained separately and are not additional income.

No named individual is assigned ownership of any beneficiary, recipient or exchange account. No Cayman bank account or Laura's personal receipt is established by these records.
