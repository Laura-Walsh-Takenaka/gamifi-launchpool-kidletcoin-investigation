# Research Paper — Launchpool: ownership records and the Laura connection

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Research date: 6 September 2026. Scope: Launchpool.xyz, the Launch Pool Limited identity in its historical terms, the related UK corporate records, Alphabit and Laura Walsh / Takenaka. This is a public-source research memorandum, with documentary findings and unresolved questions identified separately.

The original shareholder schedule of **LAUNCH POOL LTD, England and Wales company 12992979** identifies five subscribers. Contemporary Launchpool materials identify several of the same people as founders, and identify Laura as COO. Further work recovered Launchpool's own GamiFi offering data naming Laura as CEO, and an official Panama resident-agent record for Asociados Carajo Inc. The latest number search found a secondary-directory candidate, **BVI Launchpool Ltd 2054898**, plus two Linford BVI numbers now explicitly confirmed in the supplied Panama incorporation deed. The two requested deeds have been received and reviewed; they identify the subscribers and the 2025 appointments, while leaving ultimate ownership unresolved. The archived website's description of a Virgin Islands company remains unbound to a verified incorporation record. The UK schedule must therefore be attributed to the UK company.

**The January 2022 source is now recovered directly.**

The Wayback capture is 28 January 2022 at 06:33:58 UTC. Its displayed revision date is 10 November 2021. The heading uses Launchpool Limited; the introduction uses Launch Pool Limited and describes registration under Virgin Islands law. The definitions also attribute creation and release of LPOOL to Launch Pool Limited. No company number or named registered agent was identified in that text. The wording does not specify British. [S01]

An earlier 19 May 2021 capture contains the same legal-name pattern. These are statements published by the website; incorporation and jurisdiction still require registry identification. [S02]

| Record | What is established | Identity question |
|---|---|---|
| Launch Pool Limited in historical terms | Website's stated contracting party and LPOOL issuer | Exact jurisdiction, company number and relationship to UK company |
| LAUNCH POOL LTD, 12992979 | Registered England and Wales company, incorporated 3 November 2020 | Its role in operating the platform and any offshore relationship |
| Asociados Carajo Inc. in 2024 terms | Later website's stated Panama contracting party; official resident-agent portal matches name and folio 155733022 | Certified governance/ownership records and any transfer of contracts/assets |
| Alphabit Digital Currency Fund | Cayman entity identified in a 2018 SEC filing | Its exact ownership interests in each Launchpool entity |

The evidence supports a connected business network. It does not yet resolve whether the earlier offshore wording described another corporation, a continuation/reorganisation, or an inaccurate legal description.

**The UK company's initial owners are documented.**

The incorporation PDF's initial shareholdings, pages 7-8, total 100 ordinary shares. [S03]

| Subscriber on 3 November 2020 | Shares | Initial percentage |
|---|---:|---:|
| Liam David Robertson | 26 | 26% |
| Andrew Ivison | 26 | 26% |
| Saeed Hareb Masood Hamad Aldarmaki | 26 | 26% |
| Oscar James Lindley-Smith | 11 | 11% |
| SCR Advisors Limited | 11 | 11% |
| Total | 100 | 100% |

SCR Advisors Limited is listed at a Gibraltar address. Its beneficial owners were not established. Richard Simpson's director entry uses the same service address, which provides a search lead but no ownership attribution. Laura is absent from this initial shareholder schedule and the reviewed UK officer/PSC lists. [S03-S05]

The PSC register records Robertson, Ivison and Aldarmaki in the more-than-25%-through-50% shares/votes band. Aldarmaki's PSC cessation is dated 11 October 2021; Ivison's 25 November 2022. Robertson's entry has no cessation date on the dissolved-company record. A PSC cessation does not supply a replacement shareholder allocation. [S04]

The officer register lists Robertson, Ivison, Richard James Simpson, Oscar James Lindley-Smith and Aldarmaki. It records the latter three as appointed and resigned on 3 November 2020, with termination forms filed 16 April 2021. Ivison's resignation is 25 November 2022; Robertson's is 18 April 2023. [S05-S06]

The 2021 and 2022 confirmation statements are marked as having no updates. They do not provide a new share-transfer schedule. The initial percentages should not be presented as current beneficial ownership. [S07-S08]

**The ownership names connect to the operating business and Alphabit.**

Launchpool's FAQ captured on 28 January 2022 identifies Rich Simpson as founder/CEO, Liam Robertson and Oscar Lindley-Smith as founders, Laura Walsh as COO, and Eleanor Rooney as analyst. Its displayed revision is 16 July 2021. This establishes the team's public presentation around the relevant terms period. [S09]

Andrew Ivison separately described himself as a Launchpool co-founder and shareholder in a November 2021 AMA published by Launchpool Labs. That statement corroborates the ownership connection at brand level; it does not specify which legal entity he meant. [S10]

Techstars' June 2021 announcement says Alphabit Digital Currency Fund started Launchpool in 2020. It documents the accelerator partnership, but supplies no shareholder percentages. [S11]

The SEC-hosted Form D signed 1 February 2018 identifies Alphabit Digital Currency Fund as a Cayman exempted company formed in 2017, with Dalma Capital Management as investment manager. It lists Andrew Ivison, Liam Robertson, Saeed Al Darmaki and Christopher Allin Kitze as directors. Thus three names in the UK Launchpool subscriber schedule also appear in the earlier Alphabit filing. The SEC hosts this issuer-filed notice; that is not an SEC finding about Launchpool ownership. [S12]

CIMA's 30 June 2021 mutual-fund list separately records Alphabit Fund I, licence 1449685, and Alphabit Fund II, licence 1450105. These are historical fund registrations. They identify neither a Laura bank account nor a Launchpool bank account. [S13]

**Laura's connection is direct, dated and operational.**

| Date | Documentary finding | Source |
|---|---|---|
| May 2021 | Nativz later dates Laura's appointment as LaunchpoolXYZ COO to this month. | S14 |
| 8 October 2021 | MoneyNeverSleeps presents Laura Walsh as Launchpool COO; she explains the Alphabit/Launchpool investment-allocation model. | S15 |
| 28 January 2022 archive | Launchpool's own FAQ lists Laura Walsh as COO. | S09 |
| 23 February 2022 | MEXC's published AMA attributes to Laura the statement that GamiFi had a private raise, a strategic raise through Launchpool, and a January public IDO. | S16 |
| 2022 accelerator launch | Liam Robertson thanks Laura Walsh and Shane McQuillan as members of his team in a public post about the Alphabit ecosystem. Exact post date was not independently established. | S17 |
| 9 July 2022 | Nativz identifies Laura as GamiFi CEO, credits her with establishing GamiFi within Alphabit's ecosystem, and identifies her Techstars programme liaison role. | S14 |
| 1 September 2022 | GamiFi announces Eleanor Rooney as new CEO, thanks Laura for her prior leadership, and describes Rooney's former Head of Analysis roles at Alphabit and Launchpool. | S18 |

The October 2021 interview also supplies a professional identity bridge: its link labelled Laura Walsh points directly to LinkedIn's `/in/lauratakenaka/` profile. The raw page's link was inspected. This is a documentary cross-reference between the names; no inference about the reason for a surname change is needed. [S15]

These sources identify Laura's management, representation and fundraising connections. They do not provide her employment contract, corporate signing mandate, equity award, bank authority or wallet-key attribution. Those are distinct records to obtain.

**The UK filings contain specific follow-up questions.**

The 2021 accounts show £100 debtors, £19 cash, £19 creditors and £100 net assets. These are balances of company 12992979, not a consolidated balance sheet for Launchpool's projects or token sales. [S19]

The 2022 accounts claim the dormant-company audit exemption and report £119 assets, £19 creditors and £100 net assets. They state approval on 2 August 2023 and name L Robertson as director. Companies House records his resignation effective 18 April 2023. The approval capacity/date should be reconciled against the resignation and any subsequent mandate. [S20, S05]

Companies House records compulsory strike-off and dissolution on 27 February 2024. The filing history alone does not explain all underlying circumstances. [S06]

These records create a concrete accounting question: which entity booked the operating revenues, payroll, project allocations, platform fees and token-sale proceeds? The small UK balances cannot answer that question for other entities.

**The later Panama identity is supported by recovered archive pages.**

Terms captured 24 April 2024, displaying a revision date of 8 February 2024, identify Asociados Carajo Inc. under Panama law and attribute the LPOOL token to that company. [S21]

The token-migration FAQ was recovered from 20 March 2024 and 28 May 2024 captures. Launchpool says regulatory issues in the previous jurisdiction prompted a new company, and says it appointed a new director and changed core management. It also describes re-KYC through Sumsub and migration of LPOOL to Arbitrum. These are the company's explanations; they identify no specific enforcement order, former jurisdiction, successor director or corporate-transfer agreement. [S22-S23]

The February 2024 terms revision and UK dissolution occurred in the same month. Their legal relationship is unresolved. The 2024 change is not attributed to Laura by the records reviewed.

**Additional record holders and unresolved leads.**

Cavenwell's own website publishes a Launchpool CEO testimonial describing it as a provider for projects raising through Launchpool and incubated by Launchpool Labs. Its advertised services include company structuring and directorship services. This is a business-service connection, not proof that it incorporated or served as registered agent for either Launchpool entity. [S24]

A secondary Panama directory supplies Asociados Carajo Inc. folio 155733022 and RUC 155733022-2-2023. The company name and folio were subsequently matched on Panama's official resident-agent portal; the company-specific RUC remains secondary. No associated individual is treated here as a beneficial owner on the directory's authority. [S25, S32]

| Unresolved question | Specific record to obtain |
|---|---|
| What was the Virgin Islands entity? | Search Launch Pool Limited and Launchpool Limited, including historical names; obtain company number, incorporation certificate, registered agent and status history. |
| Who ultimately owned it? | Dated register of members, share transfers, beneficial-ownership information and nominee/trust declarations through the lawful access route. |
| How does UK company 12992979 fit? | Group structure, intercompany agreements, IP assignments, service agreements and accounting ledgers. |
| Who owns SCR Advisors Limited? | Gibraltar incorporation/registry identification and shareholder/controller records. |
| What transferred to Panama? | Asset, IP and customer-contract assignments; liability assumptions; director/member registers; transaction documents. |
| What authority did Laura hold? | Appointment/employment records, board delegations, bank/custody mandates, approved communications and the GamiFi allocation agreement. |
| Where did the fundraising money go? | Subscription/allocation agreements and reconciled bank, exchange and wallet ledgers by entity and round. |

The BVI FSC currently describes a fee-based company search returning incorporation, agent, status, capital and history information, with a process to request further documents. Its public/beneficial-ownership portal offers separate access routes. No paid registry report or certified BVI result was obtained in this review. The live browser encountered an explicit security block before search; no registry query result was obtained. This is not evidence of non-registration. [S26-S27]

**Further investigation completed on 6 September 2026.**

The public archive and related-company checks below were performed during this investigation, rather than deferred for later monitoring.

**Panama: an official company and resident-agent match.**

The public resident-agent portal was searched for QUIJANO and its rendered results filtered to CARAJO. The exact row was independently inspected and a screenshot preserved. [S32]

| Official column | Displayed value |
|---|---|
| Agente Residente | QUIJANO & ASOCIADOS |
| Estado agente | Renuncia |
| Nombre de la Sociedad | ASOCIADOS CARAJO INC |
| Tipo de Organización | SOCIEDAD ANONIMA |
| Folio | 155733022 |
| Estatus del Folio | Vigente |
| Fecha de Inscripción | 02/02/2023 |

This confirms a registered company/folio match and a recorded Quijano relationship. The agent status indicates resignation; the folio status is separately shown as current. That row gives no resignation date or successor. The supplied folio printout subsequently inspected separately identifies a resident agent and directors, as detailed in the number-search update below. Neither record identifies ultimate beneficial owners.

The full corporate-services portal required sign-in and reCAPTCHA in this research browser. supplied printouts were subsequently retrieved and read; they supply governance fields and exact deed download references. The underlying founding and amendment deed copies have now also been supplied and reviewed. A current certified extract and ownership register remain outstanding. The official Gazette's title-only search returned no matching title; that limited outcome does not contradict the positive registry records.

**GamiFi: Laura is named in the actual Launchpool offer data.**

Two archived Launchpool project pages advertise GamiFi fundraising targets: 250,000 BUSD in December 2021 and 150,000 BUSD for the January 2022 IDO. Both snapshots describe forthcoming offerings; they do not show funds received. [S29-S30]

The IDO page's archived application data names Laura Walsh as CEO and Liam Robertson as adviser, identifying him with Alphabit. The same data records these offer terms. [S31]

| Published offer | Token price | Release terms |
|---|---:|---|
| GamiFi strategic offer | $0.015 | 5% at token generation; three-month cliff; linear release over nine months |
| GamiFi IDO | $0.03 | Fully unlocked |

This strengthens the direct management and fundraising connection. It supplies no share register, proof of money received or personal control of proceeds. The source's two Laura biography fields differ, so their career claims are not relied on here.

**Related UK companies: shared principals, but no offshore transfer instrument.**

| Entity | Dated ownership finding | Limit |
|---|---|---|
| Alphabit Projects UK Ltd, 12327183 | On 21 November 2019, Richard Simpson, Andrew Ivison, Oscar Lindley-Smith and Liam Robertson each subscribed 25 of 100 ordinary shares. | Establishes an earlier company shared by these principals. [S35] |
| Launch Horizons Ltd, 13672315 | On 11 October 2021, Richard Simpson subscribed the sole ordinary share. | Its name and common principal do not prove it owns Launchpool. [S36] |
| Alphabit Consultancy Ltd, 13482392 | The 18 October 2021 statement records the sole share transferred from Liam Robertson to Felix Oram on 13 October 2021. | A transfer of this company's share, not a documented Launchpool transfer. [S37] |

Alphabit Consultancy's 2023 accounts state it was being wound up and describe equipment disposals without naming a Launchpool buyer or business transfer. Reviewed Launch Horizons accounts likewise disclose no named offshore Launchpool investment or assignment. The reviewed filings do not supply a merger, continuation or asset/contract transfer linking UK Launch Pool Ltd to either website contracting identity. This is a bounded negative search result. [S38; related-company appendix in evidence package]

**SCR Advisors: the exact registry record and access limit.**

No reviewed public document identifies SCR Advisors Limited's owners or proves Richard Simpson owns it. The Gibraltar registry's official profile procedure can supply recorded shareholders and directors. A corporate or nominee shareholder may require another ownership step. [S33]

The prepared record selection is: **SCR Advisors Limited; registration number unknown; standard, non-certified company profile; email delivery**. The official form accepts the full company name without a known number. Its listed fee is £20.50, with normal issue the following working day; a credit-card surcharge may apply. Requester contact and payment details would be required to submit it. No order or message has been sent. A current profile also would not substitute for the annual return/shareholding records covering November 2020 through January 2022. [S33-S34]

**Archive search coverage and remaining gap.**

The January 2022 privacy policy uses Launchpool Limited, with a displayed revision of 13 January 2021. It provides no incorporation number or named registered agent. Its generic affiliate and business-sale clauses identify no actual affiliate or completed sale. [S28]

The follow-up inspected an inventory of 1,520 distinct successful archived URLs, the relevant privacy and offer pages, nine referenced application bundles and the public Launchpool repository inventory. No exact offshore incorporation identifier or signed transfer instrument was recovered. This establishes the limits of the material reviewed, not the nonexistence of additional private or unarchived documents.

**Number-search update: exact targets and supplied public-record copies.**

Three supplied Panama registry printouts were located and independently read, including visual inspection of the two document-download lists. These are registry-page printouts with some translated text; they are not the underlying deeds or certified extracts. [S39-S41]

| Target | Number or reference | Evidence status |
|---|---|---|
| Launchpool Ltd, BVI | 2054898 | Commercial-directory candidate; official extract and identity link to launchpool.xyz still required. [S43] |
| LINFORD CORPORATE SERVICES INC., BVI | 1943018 | Exact BVI number and subscriber identity confirmed by the incorporation deed. [S44, pp.2–3] |
| LINFORD MANAGEMENT SERVICES INC., BVI | 1943021 | Exact BVI number and subscriber identity confirmed by the incorporation deed. [S44, pp.2–3] |
| ASOCIADOS CARAJO INC, Panama | Folio 155733022 | Official public portal and supplied folio printout agree. [S32, S39] |
| Panama incorporation entry | 44706/2023 (0) | Printout lists public deed 769, dated 31 January 2023. [S40] |
| Panama amendment entry | 187609/2025 (0) | Printout lists public deed 10116, dated 7 May 2025. [S41] |
| SCR ADVISORS LIMITED, Gibraltar | Not verified | Official company-profile request accepts the full name without a known number. [S33-S34] |

The i-BVI directory displays Launchpool Ltd's registration date as 12.02.2021. This is a candidate registry identity rather than a confirmed match to the archived contracting party. The terms' earlier displayed January 2021 revision does not independently establish when their text was first published. No official certificate, former-name history or ownership record for 2054898 has been obtained. The trailing 1123236 in the directory URL is a site identifier, not the displayed company number. [S43]

The Linford entries appear on printed Gazette page 6680 (PDF page 238). The notice states that listed companies were struck off on 1 November 2018 for unpaid annual fees. This is a historical status event, not a current-status determination. The supplied incorporation deed explicitly repeats both names and BVI numbers, establishing that identity match. Their restoration/status history after the 2018 notice remains unverified; the 2023 deed does not supply that history. [S42, S44]

The Carajo folio printout records opening entry 44706/2023 on 2 February 2023 and amendment entry 187609/2025 on 9 May 2025. It lists the two Linford companies as subscribers; Mario Ernesto Garcia de Paredes Estripeaut as resident agent; Persis Manfred Sarmiento as director/president; Omar Camargo as director/secretary; and Miriam Camargo as director/treasurer. These are the displayed roles, not shareholder or beneficial-owner findings. It states US$1,000 share capital, which is not evidence of Launchpool fundraising proceeds. [S39]

The later entry names public deed 10116 dated 7 May 2025, presented on 8 May and completed on 9 May. The supplied deed now identifies the appointments and dates its underlying meeting to 7 February 2025, distinct from the 7 May deed and 9 May registration. [S45] The original entry identifies deed 769 dated 31 January 2023. The native Spanish download descriptions resolve the dates despite mixed date formatting elsewhere in the translated printouts. [S40-S41]

The manual deed-download task is complete. The supplied Asociados Carajo deed 769, the 11-page incorporation-deed copy, and Asociados Carajo deed 10116, the five-page 2025 deed copy. Both were read and relevant pages visually checked. [S44-S45]

For a BVI lookup, the exact candidate to submit is 2054898 / Launchpool Ltd. The requested result should state legal and former names, incorporation date, registered agent and status history; director records can then be requested through the applicable access process. Official guidance describes a paid search route, so free access or an immediate downloadable extract is not assumed. [S26, S43]

**Deeds received: confirmed subscriber identities and the 2025 appointments.**

Deed 769, dated 31 January 2023, records the formation of Asociados Carajo Inc. The Spanish text is accompanied by an English charter. Its explicit company identifiers close the earlier Linford name-match gap. [S44]

| Subscriber | Jurisdiction / number stated | Representative and stated capacity |
|---|---|---|
| LINFORD CORPORATE SERVICES INC. | British Virgin Islands, BC 1943018 | Katia Jannette Smith Chávez, sole director |
| LINFORD MANAGEMENT SERVICES INC. | British Virgin Islands, BC 1943021 | Fernando Menéndez Montes, sole director |

Both are described as registered on 21 April 2017. These details appear on PDF pages 2–3, with the English subscriber recitals on page 7. The deed identifies Quijano & Asociados as the submitting law firm and original resident agent. [S44, pp.2–3, 6–7, 10]

Article 14 says each subscriber agrees to take one share. Article 3 authorizes US$1,000 divided into 1,000 common shares of US$1 each, issued only in registered form. Authorized capital is distinct from the number actually issued or paid; the deed does not provide a subsequent shareholder ledger. No present-day ownership percentages are assigned from these clauses. Article 10 says the stock register is kept at a location determined by the board. That register, together with allotments and transfers, is the precise missing ownership record. [S44, Spanish pp.4, 6–7; English pp.8, 10]

| Role | Initial charter, 31 January 2023 | Appointments resolved at meeting dated 7 February 2025 |
|---|---|---|
| Director / president | Katia Jannette Smith Chávez | Persis Manfred Sarmiento |
| Director / secretary | Nereida Esther Moreno Cerrud de Serrano | Omar Camargo |
| Director / treasurer | Fernando Menéndez Montes | Miriam Camargo |
| Resident agent | Quijano & Asociados | Mario Ernesto García de Paredes Estripeaut |

The table compares the original charter with the later resolutions; it does not assert that no intervening appointment occurred. The 2025 deed appoints new officeholders without setting out the previous officeholders' individual resignation dates. [S44, pp.6/10; S45, pp.3–4]

Deed 10116 is dated 7 May 2025, but its transcribed extraordinary shareholders' meeting is expressly dated **7 February 2025**. It identifies Carajo folio 155733022, records electronic representation of all issued and outstanding voting shares, and says the resolutions were unanimous. It appoints the agent and officers listed above and authorizes Mario to formalize and register the minutes. The new directors/officers are to assume office at the meeting's close. The minutes do not name the voting shareholders or their holdings. [S45, pp.3–4]

Persis is named as meeting chair and Omar as meeting secretary. The signature recitals identify them in those roles; Omar also certifies the minutes as a faithful copy from the company's minute book. The document contains the new agent's statutory declaration. These statements identify capacities asserted in the instrument; they do not establish that those individuals own the shares. [S45, pp.4–5]

Neither supplied deed names Laura, Launchpool, SCR Advisors, a bank account, a wallet, or a transfer of the Launchpool business. The broad incorporation powers to open bank accounts or enter assignments describe permitted corporate activities, not completed transactions. Laura's documented operating roles remain supported by the separate contemporaneous sources above.

Both PDFs bear an information-only-copy watermark and reproduce notarial seals/signatures. Original uploaded bytes were preserved with SHA-256 hashes. This review identifies what the copies state; it does not independently certify their authenticity or current completeness against the registry. Personal identification numbers visible in the source deeds are not transcribed into this memorandum.

The earlier 2018 Gazette strike-off notice and the 2023 subscriber recitals now concern the same stated BVI numbers. A dated registry history covering 2018–2023 is needed to reconcile their intervening status. No conclusion about capacity or legal validity is drawn from the historical notice alone. [S42, S44]

**Source register and verification.**

Archived publication dates, displayed revision dates and today's retrieval date are distinct. Original UK filing PDFs were downloaded and relevant pages visually checked. The expanded research ZIP includes the original Launch Pool filings, related-company filings, official Gibraltar forms, the Panama result screenshot, and source locations and hashes. Website research is documented through links, concise findings and capture metadata; third-party articles and application bundles are not republished in full.

No person or organisation was contacted, no financial transaction was made, and no finding of criminal conduct is made. Website descriptions, issuer-filed records, corporate-register entries and researcher inferences retain their distinct evidential status.

- **S01:** [Launchpool terms, capture 20220128063358](https://web.archive.org/web/20220128063358/https://launchpool.xyz/terms-conditions/). Direct archive bytes recovered.
- **S02:** [Launchpool terms, capture 20210519003035](https://web.archive.org/web/20210519003035/https://launchpool.xyz/terms-conditions/). Direct archive bytes recovered.
- **S03:** [UK incorporation PDF, 3 November 2020](https://find-and-update.company-information.service.gov.uk/company/12992979/filing-history/MzI4MjI5OTIzOGFkaXF6a2N4/document?download=0&format=pdf). Shareholdings pp.7-8.
- **S04:** [UK PSC register](https://find-and-update.company-information.service.gov.uk/company/12992979/persons-with-significant-control).
- **S05:** [UK officer register](https://find-and-update.company-information.service.gov.uk/company/12992979/officers).
- **S06:** [UK filing history](https://find-and-update.company-information.service.gov.uk/company/12992979/filing-history); [company overview](https://find-and-update.company-information.service.gov.uk/company/12992979).
- **S07:** [2021 confirmation statement](https://find-and-update.company-information.service.gov.uk/company/12992979/filing-history/MzMxOTExNzM0M2FkaXF6a2N4/document?download=0&format=pdf).
- **S08:** [2022 confirmation statement](https://find-and-update.company-information.service.gov.uk/company/12992979/filing-history/MzM1ODAyODQxOGFkaXF6a2N4/document?download=0&format=pdf).
- **S09:** [Launchpool FAQ, capture 20220128062112](https://web.archive.org/web/20220128062112/https://launchpool.xyz/faqs/). Direct archive bytes recovered.
- **S10:** [Launchpool Labs, Ivison AMA, 29 November 2021](https://launchpoollabs.medium.com/launchpool-ama-recap-nifty-football-3502e2ab370d?responsesOpen=true&sortBy=REVERSE_CHRON). Web retrieval successful; local request returned 403.
- **S11:** [Techstars announcement, June 2021](https://www.businesswire.com/newsTechstars-partners-with-Alphabit-Fund-and-Launchpool-to-bring-blockchain-focused-accelerator-to-London).
- **S12:** [Alphabit Form D, signed 1 February 2018](https://www.sec.gov/Archives/edgar/data/1729768/000094562118000060/xslFormDX01/primary_doc.xml).
- **S13:** [CIMA fund list, 30 June 2021](https://www.cima.ky/upimages/commonfiles/QuarterlyListofallMutualFundsregisteredandlicensedwiththeCaymanIslandsMonetaryAuthority-30June2021_1625765870.pdf), printed p.10. Historical registration evidence.
- **S14:** [Nativz newsletter, 9 July 2022](https://www.nativzgaming.com/p/newsletter-09-07-22).
- **S15:** [MoneyNeverSleeps, 8 October 2021](https://www.moneyneversleeps.ie/156-3-is-the-magic-number-laura-walsh-launchpool-and-techstars/). Episode numbered 158 despite URL slug; Laura Walsh link targets `/in/lauratakenaka/`.
- **S16:** [MEXC AMA, 23 February 2022](https://blog.mexc.com/mexc-ama-gamefi-session-with-laura-and-casey/). Interview recovered through search index; direct local retrieval did not succeed.
- **S17:** [Liam Robertson's team acknowledgement](https://www.linkedin.com/posts/liam-robertson-cfa-caia-008b69146_great-to-see-the-alphabit-ecosystem-help-activity-6918541794397827072-6LhT). Exact publication date unverified.
- **S18:** [GamiFi CEO succession, 1 September 2022](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147). Full article read through web retrieval.
- **S19:** [2021 UK accounts](https://find-and-update.company-information.service.gov.uk/company/12992979/filing-history/MzM1NzQ0OTgxN2FkaXF6a2N4/document?download=0&format=pdf), balance sheet p.4.
- **S20:** [2022 UK accounts](https://find-and-update.company-information.service.gov.uk/company/12992979/filing-history/MzM4ODgxMDc3NmFkaXF6a2N4/document?download=0&format=pdf), financial position and approval p.4.
- **S21:** [Launchpool Panama terms, capture 20240424044933](https://web.archive.org/web/20240424044933/https://launchpool.xyz/terms-conditions/). Direct archive bytes recovered.
- **S22:** [Migration FAQ, capture 20240320154301](https://web.archive.org/web/20240320154301/https://app.launchpool.xyz/token-migration/). Direct archive bytes recovered.
- **S23:** [Migration FAQ, capture 20240528125928](https://web.archive.org/web/20240528125928/https://app.launchpool.xyz/token-migration/). Direct archive bytes recovered.
- **S24:** [Cavenwell corporate website](https://cavenwell.io/). Current provider's own representation.
- **S25:** [Persono Panama company lead](https://persono.io/apps/profiles/892bdf35e500ae7597c4eb418de6a1ff). Secondary directory; name/folio subsequently corroborated through S32, without a certified extract.
- **S26:** [BVI FSC company-search guidance](https://www.bvifsc.vg/searches-bvi-registered-entities), revised 1 September 2025.
- **S27:** [BVI FSC public/beneficial-ownership search routes](https://www.bvifsc.vg/public-search).
- **S28:** [Privacy policy, capture 20220128063154](https://web.archive.org/web/20220128063154/https://launchpool.xyz/privacy-policy/). Original bytes recovered.
- **S29:** [GamiFi offering, capture 20211206104422](https://web.archive.org/web/20211206104422/https://app.launchpool.xyz/projects/gamifi/). Original bytes recovered.
- **S30:** [GamiFi IDO, capture 20220117101341](https://web.archive.org/web/20220117101341/https://app.launchpool.xyz/projects/gamifi-ido/). Original bytes recovered.
- **S31:** [Referenced application data, capture 20220117101433](https://web.archive.org/web/20220117101433id_/https://app.launchpool.xyz/_nuxt/786da7d.js). Public project data decoded without executing the archived code.
- **S32:** [Panama official resident-agent portal](https://registro-publico.gob.pa/aresidente/). Live rendered exact company row inspected 6 September 2026; screenshot included in evidence package. Company services portal: [rp.gob.pa](https://www.rp.gob.pa/).
- **S33:** [Gibraltar company-profile guidance, updated August 2025](https://www.companieshouse.gi/publications/C0008.pdf).
- **S34:** [Gibraltar official profile request form](https://www.companieshouse.gi/publications/Profiles.pdf).
- **S35:** [Alphabit Projects UK incorporation](https://find-and-update.company-information.service.gov.uk/company/12327183/filing-history/MzI0OTkwOTgzNWFkaXF6a2N4/document?format=pdf&download=0), p.5.
- **S36:** [Launch Horizons incorporation](https://find-and-update.company-information.service.gov.uk/company/13672315/filing-history/MzMxNjY1Nzc2OWFkaXF6a2N4/document?format=pdf&download=0), p.5.
- **S37:** [Alphabit Consultancy confirmation statement, 18 October 2021](https://find-and-update.company-information.service.gov.uk/company/13482392/filing-history/MzMxNzMyMDgxN2FkaXF6a2N4/document?format=pdf&download=0), p.2.
- **S38:** [Alphabit Consultancy accounts, year ended 30 June 2023](https://find-and-update.company-information.service.gov.uk/company/13482392/filing-history/MzM4NTkxNjMzM2FkaXF6a2N4/document?format=xhtml&download=1).
- **S39:** supplied `Panama folio summary`, both pages, retrieved and inspected 6 September 2026. Panama folio summary with related members and entry history. The folio summary is a historical source record; consult this edition’s inventory for included records.
- **S40:** supplied `Panama incorporation-entry summary`, both pages; incorporation-entry metadata and deed download list. Native download description names deed 769 and 31/ene./2023.
- **S41:** supplied `Panama amendment-entry summary`, both pages; amendment-entry metadata and deed download list. Native download description names deed 10116 and 07/may./2025.
- **S42:** [Virgin Islands Official Gazette, 11 December 2018, No.102](https://eservices.gov.vg/gazette/sites/eservices.gov.vg.gazette/files/governmentandstatutorynotices/%23102%2011th%20December%2C%202018%20EXTRA.pdf). Printed p.6444 states notice scope; printed p.6680 gives both Linford name/number pairs. Original PDF preserved.
- **S43:** [i-BVI commercial directory: Launchpool Ltd](https://i-bvi.com/company/launchpool-ltd_1123236). Independently read 6 September 2026; displays company number 2054898 and registration date 12.02.2021. Secondary lead, not a certified registry extract or verified website-company identity bridge.

- **S44:** supplied `Asociados Carajo deed 769`, 11 PDF pages: public deed 769 dated 31 January 2023, Asociados Carajo Inc. incorporation. Historical source title: `panama_deeds/ASOCIADOS_CARAJO_DEED_769_2023-01-31.pdf` in the ZIP.
- **S45:** supplied `Asociados Carajo deed 10116`, five PDF pages: public deed 10116 dated 7 May 2025, recording a shareholders’ meeting dated 7 February 2025. Historical source title: `panama_deeds/ASOCIADOS_CARAJO_DEED_10116_2025-05-07.pdf` in the ZIP.
