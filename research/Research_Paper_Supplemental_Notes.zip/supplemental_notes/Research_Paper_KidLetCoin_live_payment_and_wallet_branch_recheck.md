# Research Paper — KidLetCoin: live payment and wallet-branch recheck

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Collected 5 September 2026 UTC. Primary node collection began at 2026-09-05T08:00:47.151814+00:00; exact collection provenance is retained with every primary response. NEM NIS1 mainnet, asset `kidlet:kid`.

The live recheck confirms the historical token distribution and several XEM paths among the associated wallets. It also resolves the original token’s expiry. Wallet relationships and transaction purposes are separate findings: the issuer had substantial activity before KID and also registered `loyalcoin`. No graph total below represents proven KID revenue, profit, expenditure, fiat proceeds or criminal conduct.

## Coverage and verification

- 16 current wallet states and terminal-paginated histories; 2,275 unique transaction records after deduplication by outer hash. The 14-address prior project register was expanded with the old Foundation operating wallet and Southeast Asia regional wallet for screening.
- 28 KID transfers, 19 addresses and 25 directed pairs in the current explorer index. All 28 transfer payloads and sender keys were corroborated against exact historical blocks/account records.
- 936 positive explicit XEM transfers touch at least one of the 14 register wallets. These populate the XEM constellations. The two external destination centers show partial histories observed through those register wallets; their complete histories were not retrieved.
- 49 selected XEM transfers also match exact blocks on the second node: 22 upstream/shared-signer records, six staging/fund transfers, and 21 outgoing-branch records. Together with KID, 77 payment transfers received exact-block checks.
- Seven core-wallet control events and five namespace/definition transactions received separate exact-block checks. Replayed current control sets match both queried nodes.
- Both node hosts share an operator/domain family. This is a reproducible public-node/explorer consistency examination, not independent institutional attestations, a private-account audit, local signature verification or a locally operated consensus replay. Terminal pagination describes returned endpoint coverage, not every possible account or off-chain payment.

## Confirmed payment branches

| Observed branch | Transfers | Amount | What the records establish |
|---|---:|---:|---|
| Foundation SEA → shared signer NBDCOH… | 12 | 221,287.57 XEM | Confirmed receipts, April 2018–September 2019; accounting references do not identify a KID grant. |
| Shared signer → shared issuer NC7HKO… | 9 | 151,894 XEM | Confirmed onward wallet payments, April 2018–March 2019. This does not trace ownership of the same coins received from SEA. |
| Shared signer → NDMV5M… | 1 | 100 XEM | Transaction message “For KID”; nearby 50-KID transfer says “KID for demo.” |
| Issuer → levy/signing wallet NCEUKZ… → ND2JRP… | 2 | 500,000 XEM on each leg | Same amount, two blocks apart; confirms sequence, not the purpose or ultimate beneficiary. |
| Issuer → ND2JRP… later | 1 | 300,000 XEM | Same destination and same plaintext reference as the preceding 500,000-XEM outgoing leg. |
| Five register wallets → NC64UF… | 18 | 5,748,124 XEM | Shared destination across 2018–2022. The destination’s service/operator and customer ownership are unverified here. |

The 500,000-XEM sequence settled at 03:39:49 and 03:42:31 UTC on 6 March 2019: a 2-minute-42-second interval. The 300,000-XEM transfer settled on 6 June 2019 at 10:15:21 UTC. The latter two transactions share reference `37503ccaac214a018a2`. Do not add the two 500,000-XEM legs as one million XEM of fresh funding. [9e715ed554…](https://explorer.nemtool.com/#/s_tx?hash=9e715ed554f0830fc93d867f6a48e0b0aeaebaa61bdaadea73691f6b2b741baf); [905643ede8…](https://explorer.nemtool.com/#/s_tx?hash=905643ede8322b230f03f4b9cb36d0021e49dfdc7705af4d2d03e9a7ff69f1af); [fa86f51c3f…](https://explorer.nemtool.com/#/s_tx?hash=fa86f51c3f2a88197aeac376e0f445c3d3bb11ada66163fdcb56aede39825b25).

Eight of the nine shared-signer→issuer payments total 131,894 XEM and occur before the first indexed KID distribution on 9 December 2018; the remaining 20,000-XEM transfer occurs in March 2019. The original KID namespace already existed from April 2018. These dates help delimit the evidence; neither timing alone proves nor rules out project-related spending. Some messages refer to months or a USD calculation, without providing invoices or a KID purpose.

Multiple sending wallets reaching the same external address does not establish shared beneficial ownership; custodial services can pool receipts. The NC64UF… branch continues after the original token’s expiry, and cannot establish continued KID operations.

The old Foundation operating wallet has no direct positive-XEM recipient match to the 14-address register in the returned history. The regional→shared→issuer links are an indirect relationship not captured by that earlier direct-recipient screen. Their financial purpose remains unresolved. The SEA account’s institutional attribution comes from the contemporary [Foundation response](https://forum.nem.io/t/how-long-will-nf-fund-each-region/22488/2), not its address spelling.

## Dedicated distribution infrastructure

The staging wallet received 10 XEM from NCEUKZ… and 100 XEM from the issuer, then sent 108 XEM to the distributor on 9 December 2018. The development wallet received 100 XEM from each of NCEUKZ… and NBLIIT…; education received 100 XEM from NCEUKZ… on 4 May 2019. No positive explicit XEM outgoing transfer appears from distributor, development or education in their terminal histories. Network costs still occur; zero outgoing transfer rows do not mean zero spending. Such small XEM receipts can support NIS1 transaction costs and do not establish token-sale receipts.

| Confirmed UTC | From → to | XEM | Transaction |
|---|---|---:|---|
| 2018-12-09T07:12:14+00:00 | Definition initiator / levy / signer (NCEUKZ…37YQ4I) → Staging (NADLLJ…VVRB4X) | 10 | [f0e874f61b…](https://explorer.nemtool.com/#/s_tx?hash=f0e874f61bad93cabc03420deb317bfb74c04069074cafdfd6e87769b9a1ac0e) |
| 2018-12-09T07:14:37+00:00 | Issuer (NC7HKO…EFQHNZ) → Staging (NADLLJ…VVRB4X) | 100 | [cfe17b9328…](https://explorer.nemtool.com/#/s_tx?hash=cfe17b93284097aae90b437f27676733e2fd1c663dfaa17a3d98e29b283754db) |
| 2018-12-09T07:32:43+00:00 | Staging (NADLLJ…VVRB4X) → Distributor (NC6JT7…XG7TL4) | 108 | [94109e11c7…](https://explorer.nemtool.com/#/s_tx?hash=94109e11c700dd8a6669d7b8f2dbe80f1ea35aa6c4aca1b1c5d5c486fb6213cf) |
| 2019-05-04T07:24:34+00:00 | Definition initiator / levy / signer (NCEUKZ…37YQ4I) → Development fund (NA5JKI…VKG2PS) | 100 | [da1af718a1…](https://explorer.nemtool.com/#/s_tx?hash=da1af718a1119df5833d927930769ea4d64a3cb7c85908a256c503c2ea17d0d3) |
| 2019-05-04T07:29:30+00:00 | Definition cosigner (NBLIIT…KPNU6I) → Development fund (NA5JKI…VKG2PS) | 100 | [ace24ad9c3…](https://explorer.nemtool.com/#/s_tx?hash=ace24ad9c377427b9d54e14672c65af40c77cd7f347605af6de0b94bd4ec9a65) |
| 2019-05-04T08:59:09+00:00 | Definition initiator / levy / signer (NCEUKZ…37YQ4I) → Education fund (NDSTP4…NB7IRL) | 100 | [eabb63f690…](https://explorer.nemtool.com/#/s_tx?hash=eabb63f690db10f97a50e6594de617812448f3583262003e1a74e4ee56e0d9c6) |

## Historical KID distribution

The first two transfers each move the same 21 million KID: issuer→staging→distributor. The distributor later allocates 8.4 million to development and 6.3 million to education, alongside signer/allocation and small demonstration transfers. Gross repeated movement across the 28 rows is 60,901,115.523681 KID; it is not supply, sales or a fiat valuation. Historical closing positions from this returned ledger are not current spendable balances.

The two 20-KID records on 11 June 2019 form a transfer followed by forwarding. They do not establish two winners, a child’s identity or a contest payment purpose. Unknown small endpoints are given neutral labels in the visual.

| Confirmed UTC | From → to | KID | Transaction |
|---|---|---:|---|
| 2018-12-09T07:04:02+00:00 | Issuer (NC7HKO…EFQHNZ) → Staging (NADLLJ…VVRB4X) | 21,000,000 | [59050d1b06…](https://explorer.nemtool.com/#/s_tx?hash=59050d1b0674e290e04d7619faef8717284e3a08e38a9d08879accacec7df4a3) |
| 2018-12-09T07:29:35+00:00 | Staging (NADLLJ…VVRB4X) → Distributor (NC6JT7…XG7TL4) | 21,000,000 | [a907fa0b09…](https://explorer.nemtool.com/#/s_tx?hash=a907fa0b09a25f1899e7c96fbaa56bf38b780fce36626e4d0f7fcd4301e45eea) |
| 2019-01-08T01:36:14+00:00 | Distributor (NC6JT7…XG7TL4) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 1,000 | [63d14a3d3c…](https://explorer.nemtool.com/#/s_tx?hash=63d14a3d3c156527559048ed8d80a6fad23f018c3f32b3ef6e87211e6d1eef22) |
| 2019-01-09T03:41:52+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Signer / allocation (NDMV5M…GS4V2V) | 50 | [5cad79f8d1…](https://explorer.nemtool.com/#/s_tx?hash=5cad79f8d1452649ff06925e3a71dc007945b93ae8899e54975c63a584d963e7) |
| 2019-01-12T10:38:23+00:00 | Signer / allocation (NDMV5M…GS4V2V) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 10 | [b4904e890f…](https://explorer.nemtool.com/#/s_tx?hash=b4904e890f2dc46e215e9e4e2dceb44e35c87752b7a618e0b8484438b66f9f07) |
| 2019-05-04T06:53:28+00:00 | Distributor (NC6JT7…XG7TL4) → Signer / allocation (NDMV5M…GS4V2V) | 350,000 | [4cfc7be3b6…](https://explorer.nemtool.com/#/s_tx?hash=4cfc7be3b6f228cff84f975e597a537657b0d14a6bd649f99810d98e8d0223d4) |
| 2019-05-04T06:53:28+00:00 | Distributor (NC6JT7…XG7TL4) → Signer / allocation (NCJHET…4WPHJ5) | 350,000 | [a1737a7e42…](https://explorer.nemtool.com/#/s_tx?hash=a1737a7e42a3fda78421abc371b08563a681e5af1df778fd9f84cfa97b7bbf14) |
| 2019-05-04T06:53:28+00:00 | Distributor (NC6JT7…XG7TL4) → Signer / allocation (NCM2QK…R2E2PX) | 350,000 | [896975edd2…](https://explorer.nemtool.com/#/s_tx?hash=896975edd24249459a45c1d323e11372f45b3b125c1ebc590c02a85ccf244353) |
| 2019-05-04T06:53:28+00:00 | Distributor (NC6JT7…XG7TL4) → Definition initiator / levy / signer (NCEUKZ…37YQ4I) | 350,000 | [e212e8e8be…](https://explorer.nemtool.com/#/s_tx?hash=e212e8e8be7f58a99b47479c5015ce8410a582cc309f17198de9ff585e216ca5) |
| 2019-05-04T06:53:28+00:00 | Distributor (NC6JT7…XG7TL4) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 699,000 | [ecfc880d3f…](https://explorer.nemtool.com/#/s_tx?hash=ecfc880d3fbfaafdd156156aa377589c6620ad2629573cd5724d5e04a1e72024) |
| 2019-05-04T07:53:30+00:00 | Distributor (NC6JT7…XG7TL4) → Development fund (NA5JKI…VKG2PS) | 8,400,000 | [33c5a6822b…](https://explorer.nemtool.com/#/s_tx?hash=33c5a6822b730a3677bbec8337fce9ba72cdba83329ec49cb567883a34afdcb9) |
| 2019-05-04T08:35:22+00:00 | Distributor (NC6JT7…XG7TL4) → Education fund (NDSTP4…NB7IRL) | 6,300,000 | [f9eb7d56d4…](https://explorer.nemtool.com/#/s_tx?hash=f9eb7d56d483c16336cd445933ad32a3cd287b245207929dec8412430c340112) |
| 2019-06-11T01:57:19+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → External NCYKQW…BP2IRE (NCYKQW…BP2IRE) | 20 | [899d19b357…](https://explorer.nemtool.com/#/s_tx?hash=899d19b357b02601e7a834ec044df9555e0e25be97b4393c7876d66336be4a4b) |
| 2019-06-11T03:37:56+00:00 | External NCYKQW…BP2IRE (NCYKQW…BP2IRE) → External NBQVQ6…ITE4FP (NBQVQ6…ITE4FP) | 20 | [0cb985eff8…](https://explorer.nemtool.com/#/s_tx?hash=0cb985eff8d43358f2c91f0e7e05c4deeee897a024418f4ab257e42315ce3880) |
| 2019-06-11T03:56:24+00:00 | External NBQVQ6…ITE4FP (NBQVQ6…ITE4FP) → External ND6D4I…IMHWOS (ND6D4I…IMHWOS) | 10 | [e673145da9…](https://explorer.nemtool.com/#/s_tx?hash=e673145da9f1b112e5ea77d18fc677c5fcd44311c7a2cc5b1310f46550e7c4f2) |
| 2019-06-11T04:35:53+00:00 | External ND6D4I…IMHWOS (ND6D4I…IMHWOS) → External NCIT7A…C264CP (NCIT7A…C264CP) | 1 | [7366d75af6…](https://explorer.nemtool.com/#/s_tx?hash=7366d75af66b6a876f63bb39fa801b62931c6bc37e74cfc37c1896fdf3df7cfd) |
| 2019-06-12T03:54:16+00:00 | External ND6D4I…IMHWOS (ND6D4I…IMHWOS) → External NCIT7A…C264CP (NCIT7A…C264CP) | 1 | [d350b011d0…](https://explorer.nemtool.com/#/s_tx?hash=d350b011d013c9fa39a5dbbbeffb72d3a19ae493c988d685439c0d317e577e09) |
| 2019-06-12T04:01:29+00:00 | External ND6D4I…IMHWOS (ND6D4I…IMHWOS) → External NCIT7A…C264CP (NCIT7A…C264CP) | 1.073681 | [3cff7d284c…](https://explorer.nemtool.com/#/s_tx?hash=3cff7d284c437fdb4aeb3bee1c14a6d06d1acef87ac39b0be46450f89172b8a8) |
| 2019-06-14T09:34:02+00:00 | External NCIT7A…C264CP (NCIT7A…C264CP) → External ND6D4I…IMHWOS (ND6D4I…IMHWOS) | 1 | [26e17e569e…](https://explorer.nemtool.com/#/s_tx?hash=26e17e569e01511aa3d111f6bb6c55a13f286b5b113c2bd727c1cbd7f42434f0) |
| 2019-06-23T05:53:53+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → External NBXPW6…GHU6ZI (NBXPW6…GHU6ZI) | 1,000 | [9143808ab0…](https://explorer.nemtool.com/#/s_tx?hash=9143808ab06f768b87ec48e1238bc49aa0fe7383f3c1a414d4d5a4e7f6ad453e) |
| 2019-06-26T08:47:33+00:00 | Development fund (NA5JKI…VKG2PS) → Signer / allocation (NCM2QK…R2E2PX) | 700,000 | [277e86f048…](https://explorer.nemtool.com/#/s_tx?hash=277e86f0486b61633bcaa2723672ac998f9df7262af3619fdbfe838c588cee31) |
| 2019-06-26T08:48:08+00:00 | Development fund (NA5JKI…VKG2PS) → Definition cosigner (NBLIIT…KPNU6I) | 350,000 | [7ee2de0c36…](https://explorer.nemtool.com/#/s_tx?hash=7ee2de0c36c4da1d0e0ddfec77f85e3bae3e557606272b1d664bfafb90822cc6) |
| 2019-06-26T08:48:09+00:00 | Development fund (NA5JKI…VKG2PS) → Allocation wallet (NCDYOM…Z7T26J) | 350,000 | [137082b8ae…](https://explorer.nemtool.com/#/s_tx?hash=137082b8ae733de7d78b7ae3ba9e7423723033a9d9d3ed6510688df9a170e1f8) |
| 2019-06-26T09:13:06+00:00 | Signer / allocation (NCM2QK…R2E2PX) → Development fund (NA5JKI…VKG2PS) | 350,000 | [47bd8bbf7b…](https://explorer.nemtool.com/#/s_tx?hash=47bd8bbf7bef2ef5abec5f4456b523e5177bed4c82477f5723ff6e87ef058db3) |
| 2019-07-11T07:04:56+00:00 | External NCIT7A…C264CP (NCIT7A…C264CP) → External NBQVQ6…ITE4FP (NBQVQ6…ITE4FP) | 0.25 | [6b6787e3dc…](https://explorer.nemtool.com/#/s_tx?hash=6b6787e3dc932030c87a8cf07358347596424b5371d6bf5927e238c4621dcb7d) |
| 2019-07-12T04:48:48+00:00 | External NCIT7A…C264CP (NCIT7A…C264CP) → External NBYH5N…6JUEQK (NBYH5N…6JUEQK) | 1 | [76f7a6b77e…](https://explorer.nemtool.com/#/s_tx?hash=76f7a6b77e3c4b2defcac3f75c25e3c8fa2eb66a2ac96de83ffc262da48ecc7d) |
| 2019-07-12T06:14:40+00:00 | External NBYH5N…6JUEQK (NBYH5N…6JUEQK) → External NCIT7A…C264CP (NCIT7A…C264CP) | 0.2 | [640513d8ce…](https://explorer.nemtool.com/#/s_tx?hash=640513d8ce8d400b2ffb6fc49ba21f4160bb2127cd6f994b2cfdc950d8274eb3) |
| 2019-07-16T04:56:54+00:00 | Development fund (NA5JKI…VKG2PS) → Allocation wallet (NAHLQE…ZLR2ZS) | 350,000 | [668848f801…](https://explorer.nemtool.com/#/s_tx?hash=668848f801960ed636f3bd31cdface6b2b28018b463f09a52cbf990420d179a0) |

## Namespace lifecycle and signing control

Final namespace inactivity is derived at block **3,178,560 — 2 May 2021, 07:44:17 UTC**, from the last issuer renewal and the pinned NIS1 lease rules. The grace boundary is 1 June 2021. Both current nodes reject active namespace/mosaic queries. A successful historical “last definition” lookup does not mean the asset is active. The exact derived block timestamps agree on both nodes.

The April 2019 temporary lapse was restored by the same issuer within grace in May. The May 2019 description-only definition change removed a newline and preserved supply and balances under the applicable post-fork rules; it did not mint another 21 million KID. Full source links and exact transactions are in *Historical file: CONTROL_LIFECYCLE_RECHECK_2026-09-05.md*.

| Core wallet | June 2–11, 2019 | Current signer threshold |
|---|---|---|
| Issuer | 2 of 2 | 1 of 1, changed October 2021 after KID expiry |
| Staging | Ordinary single key | Ordinary single key |
| Distributor | 3 of 6 | 3 of 6 |
| Development | 3 of 6 | 3 of 6 |
| Education | 1 of 6 | 1 of 6 |

NBDCOH… is one of the shared six keys for distributor, development and education. The key explicitly cosigned five outgoing KID transfers; it initiated none of those five. Its technical authority over the education account is not an executed payment: that account has no outgoing transfer in its returned history. Key membership does not identify a human or demonstrate independent custodians. Signing-authority lines are separate from payment arrows in the visual.

## Decoding and financial limits

For multisig wrappers, the inner transaction signer determines the sending account. Initiators and cosigners remain authorization metadata; they are not automatically payers or beneficiaries. Public-key→NIS1 mainnet address derivation was checked against all retrieved nonempty account keys. Hash deduplication prevents the same transaction appearing twice because several signer histories return it.

Explicit XEM amounts are decoded with six decimals. With mosaics attached, the outer amount field is a multiplier, not an extra XEM payment; `nem:xem` quantity is decoded separately. KID also has six decimals. Other assets are retained in normalized raw evidence but not added to KID/XEM charts. [Official transaction examples](https://docs.nem.io/pages/Exchanges/integration/examples/docs.en.html).

Two later zero-signature transfer records were excluded from human-authorized payment totals. Exclusion does not establish forgery or wrongdoing. Zero-amount messages also do not count as positive payments. The source JSON retains these records.

Charts show explicit positive transfers, not a complete balance reconciliation: transaction fees, namespace/mosaic rental charges, automatic levies and harvesting are separate. Historical KID definitions specify a fixed **0.00001-XEM levy** to NCEUKZ… per transfer. It is not 10 XEM or a percentage. No CAD/USD market value or redemption guarantee is inferred.

Most broad XEM rows carry transaction creation UTC; selected exact-block-verified rows carry confirmed block UTC. Every displayed record identifies which timestamp is used. Node-generated signatures/blocks were compared as returned; no independent cryptographic verification of every signature was performed.

## Exact selected XEM ledger

| Confirmed UTC | From → to | XEM | Transaction |
|---|---|---:|---|
| 2018-04-02T01:01:15+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 18,741.15 | [c5a1f4ad90…](https://explorer.nemtool.com/#/s_tx?hash=c5a1f4ad908bc5369a94d8eb0b8c114ef23b7488891d0f4d2b8bc39b6e9d98ff) |
| 2018-04-05T06:24:27+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 17,237 | [3af266b71e…](https://explorer.nemtool.com/#/s_tx?hash=3af266b71effdc825d436ad3212bd6d1c0675d7f6e16612566888846c4485833) |
| 2018-05-02T20:57:12+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 18,669.21 | [2ed3f7641c…](https://explorer.nemtool.com/#/s_tx?hash=2ed3f7641c2b250411ace074f73a922fba5e0c977cecc83ad22f7d0b5914ff50) |
| 2018-05-03T10:47:42+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 16,000 | [acb192c08b…](https://explorer.nemtool.com/#/s_tx?hash=acb192c08b5ba0a4ac9c1cead2e2513d13307c2d2f476d7ed6e1b9a016748036) |
| 2018-05-04T16:40:21+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 9,440.73 | [eea5afcb38…](https://explorer.nemtool.com/#/s_tx?hash=eea5afcb38af846b23be953af89094bc045c88be795a2f2a823a4d4430ff38a7) |
| 2018-05-09T03:43:18+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 8,602 | [30e66565ba…](https://explorer.nemtool.com/#/s_tx?hash=30e66565ba38f30eb652b0c9727d6435bd8eb66297a92151643426e3c3134afb) |
| 2018-06-05T15:12:19+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 21,910.45 | [61ad8fb01c…](https://explorer.nemtool.com/#/s_tx?hash=61ad8fb01cf16baae8313bda9fbbe662298e705f2b6badee48dee83fc6ffef70) |
| 2018-06-06T00:39:26+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 20 | [3fe28026c7…](https://explorer.nemtool.com/#/s_tx?hash=3fe28026c74c7acd7b6dbd684a406847a58475feedd93a04dc9eae4dee82c750) |
| 2018-06-06T00:40:02+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 20,000 | [458626ca4b…](https://explorer.nemtool.com/#/s_tx?hash=458626ca4b91c359bb48001bdc1cea5375e3a65049e9eb8f4d5601dbd4700ea1) |
| 2018-07-08T19:50:59+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 35,388.31 | [49025cd0e4…](https://explorer.nemtool.com/#/s_tx?hash=49025cd0e4395158046b70ad795bbf4fa08a4fa4dbbf6b08243901925ec0bfde) |
| 2018-07-10T05:26:39+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 35 | [67938e13bb…](https://explorer.nemtool.com/#/s_tx?hash=67938e13bba37117f3026966309e1675e74f0956587ab4dd36b1d717bf8be513) |
| 2018-07-10T05:27:09+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 35,000 | [a570b1c7a5…](https://explorer.nemtool.com/#/s_tx?hash=a570b1c7a5186d69c317fb9035426d56ee00f3fcf5dd587f1e15619d22025285) |
| 2018-08-07T15:48:23+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 37,208.64 | [a776693d64…](https://explorer.nemtool.com/#/s_tx?hash=a776693d646f0fd382841995155469eeea88d575ee9e472e66332acfb236c8b5) |
| 2018-08-13T04:18:34+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 35,000 | [da3106f872…](https://explorer.nemtool.com/#/s_tx?hash=da3106f872d94a731f332f3ef7e340c5ed139de8236e1f1051463f8f9df245be) |
| 2018-09-11T18:13:13+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 55,996.8 | [1704d90c69…](https://explorer.nemtool.com/#/s_tx?hash=1704d90c693a14e21f84a405355981a19a5df63ad7e5b52f861ddbab0fdd1930) |
| 2018-09-12T11:58:16+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 40,000 | [30810e8f38…](https://explorer.nemtool.com/#/s_tx?hash=30810e8f381df87fc505a2a62dd83e8f7160e62db756d6bd350881eb38c37c36) |
| 2018-10-08T00:20:28+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 8,821.37 | [1e5710d2b5…](https://explorer.nemtool.com/#/s_tx?hash=1e5710d2b56ff65481b322415311a283e99fa1f71c40642a993c39a91789efe8) |
| 2018-11-12T08:55:21+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 8,865.08 | [a2acc94f4a…](https://explorer.nemtool.com/#/s_tx?hash=a2acc94f4a12a23f1eb1c63d12b21f2e9db8900e3dfcc54bcbc04b2c16f540ec) |
| 2018-12-14T08:13:35+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 1,871.3 | [f0fd899a5a…](https://explorer.nemtool.com/#/s_tx?hash=f0fd899a5ad729c24068ff5521fa7c589d537b1333190962b6e629bd88722114) |
| 2019-01-09T03:41:52+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Signer / allocation (NDMV5M…GS4V2V) | 100 | [e5c7ad5914…](https://explorer.nemtool.com/#/s_tx?hash=e5c7ad5914018167b6125fc31d6133d65667aae2771807c116d750d9be9a1e07) |
| 2019-02-13T07:15:46+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 601.3 | [b9b1e216d2…](https://explorer.nemtool.com/#/s_tx?hash=b9b1e216d270e216652d02eba9fc12f0cbce67689c96c4efd41c7778eaebb890) |
| 2019-03-06T03:39:49+00:00 | Issuer (NC7HKO…EFQHNZ) → Definition initiator / levy / signer (NCEUKZ…37YQ4I) | 500,000 | [9e715ed554…](https://explorer.nemtool.com/#/s_tx?hash=9e715ed554f0830fc93d867f6a48e0b0aeaebaa61bdaadea73691f6b2b741baf) |
| 2019-03-06T03:42:31+00:00 | Definition initiator / levy / signer (NCEUKZ…37YQ4I) → External ND2JRP…VU7HNR (ND2JRP…VU7HNR) | 500,000 | [905643ede8…](https://explorer.nemtool.com/#/s_tx?hash=905643ede8322b230f03f4b9cb36d0021e49dfdc7705af4d2d03e9a7ff69f1af) |
| 2019-03-20T04:36:50+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → Issuer (NC7HKO…EFQHNZ) | 20,000 | [d0d92edccc…](https://explorer.nemtool.com/#/s_tx?hash=d0d92edcccce440102022115588e7aaf67a63e8fbb0b578a0b3d616b19719a1e) |
| 2019-05-20T05:34:38+00:00 | Issuer (NC7HKO…EFQHNZ) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 200,000 | [2339ce0d92…](https://explorer.nemtool.com/#/s_tx?hash=2339ce0d9261990dd334a5a277db7560f0472135ddaa9205d36f1f70f600b4cd) |
| 2019-06-06T10:15:21+00:00 | Issuer (NC7HKO…EFQHNZ) → External ND2JRP…VU7HNR (ND2JRP…VU7HNR) | 300,000 | [fa86f51c3f…](https://explorer.nemtool.com/#/s_tx?hash=fa86f51c3f2a88197aeac376e0f445c3d3bb11ada66163fdcb56aede39825b25) |
| 2019-06-27T09:17:22+00:00 | Issuer (NC7HKO…EFQHNZ) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 10,000 | [e5edfda14a…](https://explorer.nemtool.com/#/s_tx?hash=e5edfda14a6a1491930ea54d1e13479e7c7388e2c974ef09b32d72d55f49c8a4) |
| 2019-09-06T17:42:22+00:00 | Foundation SEA regional (NASEAC…VUSLKH) → Shared project / Foundation signer (NBDCOH…IDVLU5) | 3,773.23 | [0137e3422d…](https://explorer.nemtool.com/#/s_tx?hash=0137e3422de11d75421bbc5fb04bac739d3aa81e3b9850a11b046e82942a36a5) |
| 2019-12-04T06:44:53+00:00 | Issuer (NC7HKO…EFQHNZ) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 1,000,000 | [05d1c5c203…](https://explorer.nemtool.com/#/s_tx?hash=05d1c5c2031619e9e027e51aabf12844fa4f56ddad6cace3503c6c31f2bdd28b) |
| 2020-03-05T04:11:14+00:00 | Issuer (NC7HKO…EFQHNZ) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 3,000,000 | [d497819f84…](https://explorer.nemtool.com/#/s_tx?hash=d497819f848b7c8e62ac89950d5ba8bd7bc9e950a1252bd20f840631bfcdbe06) |
| 2020-12-05T01:16:13+00:00 | Issuer (NC7HKO…EFQHNZ) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 90,000 | [252e38fb1b…](https://explorer.nemtool.com/#/s_tx?hash=252e38fb1b5b6f1483d13d8c5c419ca6724752ad2975af81e6fe7d4f806edf9e) |
| 2020-12-05T05:29:04+00:00 | Allocation wallet (NCDYOM…Z7T26J) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 300,000 | [8782976597…](https://explorer.nemtool.com/#/s_tx?hash=87829765979abe89fa3e1e397937e9c692ada9598d21dde43b126e1778d23461) |
| 2020-12-05T12:52:08+00:00 | Allocation wallet (NCDYOM…Z7T26J) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 77,500 | [e1007a287a…](https://explorer.nemtool.com/#/s_tx?hash=e1007a287abc49e5839de51fab3c6102ecc1bfc5266537afb3fb1fa0ea367f2b) |
| 2021-01-07T08:53:54+00:00 | Allocation wallet (NAHLQE…ZLR2ZS) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 2 | [4472861bae…](https://explorer.nemtool.com/#/s_tx?hash=4472861bae5a84fee7c3078c5de40a2f787e17afabf1915980aac269a8864c7d) |
| 2021-01-27T20:39:32+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 26,000 | [cf3fe0cd2d…](https://explorer.nemtool.com/#/s_tx?hash=cf3fe0cd2d78dc14cfe599583631505febd576f5153eee0d8c0d5ba100cb3d2d) |
| 2021-03-03T12:51:35+00:00 | Shared project / Foundation signer (NBDCOH…IDVLU5) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 364 | [bdfd3075c4…](https://explorer.nemtool.com/#/s_tx?hash=bdfd3075c4bcc5ad019bdf1b3b4a4c9e185952446642373dd5d16d2f7c5630bc) |
| 2021-03-22T04:17:57+00:00 | Signer / allocation (NCJHET…4WPHJ5) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 5,100 | [e1808af1e1…](https://explorer.nemtool.com/#/s_tx?hash=e1808af1e1d096c5eec06aadb81571df6b289463bffd021356dc00e59672262c) |
| 2021-03-22T12:31:39+00:00 | Allocation wallet (NCDYOM…Z7T26J) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 500,000 | [fabaf43d50…](https://explorer.nemtool.com/#/s_tx?hash=fabaf43d50d1dca62d0135b64df32e81054cd37c58da0f3f83ccc0b441e69b8b) |
| 2021-10-20T07:24:43+00:00 | Allocation wallet (NCDYOM…Z7T26J) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 250,000 | [e21ec34d82…](https://explorer.nemtool.com/#/s_tx?hash=e21ec34d82b0ef649f4e778a51bc7d3451ad8992ea229e221c2886dda2dea63e) |
| 2021-11-02T12:57:11+00:00 | Allocation wallet (NCDYOM…Z7T26J) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 50,000 | [63be1be427…](https://explorer.nemtool.com/#/s_tx?hash=63be1be4273c982c340ea1037c93ce00436fa4f2997694708cbbea89b7183ae1) |
| 2022-03-01T08:50:24+00:00 | Allocation wallet (NCDYOM…Z7T26J) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 158 | [bf446a6ebe…](https://explorer.nemtool.com/#/s_tx?hash=bf446a6ebef7125f6a97fd4057c4a531d7009b08d66eb71e428e9e59e8367432) |
| 2022-03-01T08:56:17+00:00 | Allocation wallet (NCDYOM…Z7T26J) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 99,000 | [bd9bed0b18…](https://explorer.nemtool.com/#/s_tx?hash=bd9bed0b180875d8122dfeac5b0ad8cf511a0f3616e1c45fb9d857e8881e9136) |
| 2022-03-24T12:42:54+00:00 | Allocation wallet (NCDYOM…Z7T26J) → External NC64UF…X6FFMZ (NC64UF…X6FFMZ) | 100,000 | [30ec45d51b…](https://explorer.nemtool.com/#/s_tx?hash=30ec45d51bfffd4aa6a3ac239522c3da154dd66178a27b40ccf05ded418e8c6e) |

## Address register

| Address | Retrieved role |
|---|---|
| `NC7HKOMA4N4ZCYJ7PXJPUGGQLSBLQL6S6LEFQHNZ` | Issuer |
| `NADLLJRTUU73OZ4MU5PY47PUMWQZUGG25GVVRB4X` | Staging |
| `NC6JT7YGYASHVZ2NNS4TK372PTDXBUS354XG7TL4` | Distributor |
| `NA5JKIQRYPQ6XB3BT2NQWY4SYH4L6Q43OKVKG2PS` | Development fund |
| `NDSTP4YZPMGACPKS26PV4U4VX63WZRD76UNB7IRL` | Education fund |
| `NCEUKZQJXJGQSTEWUIRURSQVX2MDTXU5ZW37YQ4I` | Definition initiator / levy / signer |
| `NBLIITQIUKQFK5NFB2L2TPE65B4N3HSHR7KPNU6I` | Definition cosigner |
| `NCM2QKZZ3AYMGYBMQSQ2ETCXDNDF33NDO2R2E2PX` | Signer / allocation |
| `NBDCOHCTOKI3RY46YK7EEPPQRG2UHPCNUQIDVLU5` | Shared project / Foundation signer |
| `NDMV5M4Y2GKQOJ3C4W6HYUK32PSEWLKRHPGS4V2V` | Signer / allocation |
| `NCJHETVLYHK5C3GGO27HNRMBHCLPBSXYRL4WPHJ5` | Signer / allocation |
| `NCDYOMFFNO5T567SBODMNGZAYBGWREFCIGZ7T26J` | Allocation wallet |
| `NAHLQEVQ6GI2P67GFRTNGSAKP35XC6WPBBZLR2ZS` | Allocation wallet |
| `NAWYC2U3JALUO26BU3FFI4A6U7J24Q2KCIBIMFYQ` | Later issuer signer |
| `NASEACHB4GDLNLC2EGU7KQB3T2WY23UWTNVUSLKH` | Foundation SEA regional |
| `NBFOUNDXB54PVVPG6AN4WJ7BAOYFBC2XLLHDU5YM` | Old Foundation operating |

## Evidence package

`live-chain/pages/` retains every primary history page, including terminal empty responses, with URL/time/hash sidecars. `histories/` holds combined per-account responses; `normalized-transfers.json` and `normalized-records.json` retain the decoded records. `visual-data.json` is the exact plotted dataset, including scope and provenance labels. `kidlet_live/source/` contains the token index, explorer transaction details, corroborating blocks and key checks. `kidlet_live/xem_selected/`, `xem_outgoing/` and `live-chain/core-xem-blocks/` contain the extra XEM block checks. The control-review directory preserves both-node comparisons and pinned protocol sources.

The top-level SHA256SUMS.txt fingerprints packaged bytes, not the truth or completeness of a remote endpoint. This package supplements the earlier investigation without modifying its original files.
