# Research Paper — November proceeds and May replenisher — bounded public attribution check

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Checked 2026-09-06. This supplements the existing master; it does not re-establish every underlying on-chain transfer.

## Result
No new verified human identity, business-owner declaration, dated key-custody assignment, historical FixedFloat order mapping, or payout-to-Laura link was recovered for the requested addresses.

The exact-address service attribution already in the master was independently rechecked:
- https://www.bestchange.ru/fixedfloat-exchanger-79.html
- Native retrieval reference: historical retrieval, lines 207–216.
- Dated 10 May 2025, 12:47, account label Administrator FixedFloat. The administrator identifies 0x4727250679294802377dd6ca6541b8e459077c95 as one of the service's main outgoing addresses.
- https://ff.io/ru/faq (historical retrieval) provides the existing service-to-listing provenance.
- Confidence: high that the displayed listing contains the dated statement; it is provider-attributed content on a third-party listing. Not independent authentication of the human poster and not a November 2022 custody attestation.

Etherscan currently labels the same address FixedFloat: Hot Wallet and explicitly attributes its tag to a hildobby compilation:
https://etherscan.io/address/0x4727250679294802377dd6ca6541b8e459077c95 (historical retrieval).
This is an explorer attribution, not a new customer or payout identification.

## Negative coverage and access limitations
Exact-address searches used both available search engines, with and without 0x and with shorter address prefixes or contextual terms:
- 0x35dc4a16db1e30036fee83e733ee065ad8535422 — the 44m-GMI recipient.
- 0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6 — the 5,174-BUSD intermediary.
- 0x949040eedb2abecc0b9d2558a6d22d9724eaea88 — the May 2023 pool replenisher.
- 0x36048413c4edf0cf3e633aab317fcd9824dfb4d4 — separate private-vesting beneficiary, not conflated with the November route.
- FixedFloat exact address with 2022 and GitHub terms.
- Laura Takenaka with wallet, 0x and eth terms.
- GamiFi-specific replenishment, treasury, wallet, refund and May-2023 staking searches.

No matching personal wallet declaration or independently verifiable identity surfaced. Searches about GamiFi often return unrelated GameFi/Gami/Gamium material; those results were excluded.

A search hit at https://eth.trusteeglobal.com/address/0x305D6286CA90436949E184a984920C7703AE2DFE contained the replenisher address in its snippet (historical retrieval), but the full page returned 403. The snippet does not establish the transaction direction, date, token, business identity or controller. It is excluded as affirmative identity evidence.

BscScan, Etherscan, Blockscan and OKLink target pages for the unidentified wallets were not readable through this environment (403 or non-retryable fetch failures). A Blockchair API request returned 430. These failures are not evidence of absent transactions or names. No login, private account, order enumeration or bypass was attempted.

## Investigative implication
The November route reaches a service-attributed address; following pooled hot-wallet outflows by similar amount or timing cannot identify the customer's payout. The decisive missing bridge remains a historical order/deposit-to-payout mapping and evidence identifying or authorizing the customer. The known 2025 statement does not fill the 2022 date gap. No personal receipt by Laura is established in this pass.
