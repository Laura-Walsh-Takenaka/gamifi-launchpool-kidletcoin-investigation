# Research Paper — GamiFi: corporate accounts, legal entities and contract-control links

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Public-source follow-up checked 6 September 2026. This supplements the existing GamiFi memorandum. Historical publication dates, archive captures and present blockchain observations are separate evidence dates.

The new evidence connects GamiFi more closely to the Alphabit/Launchpool business network and identifies a corporate custody service offered to Launchpool projects. No reviewed record identifies a Cayman bank account belonging to Laura or GamiFi. Whether GamiFi used the identified custody service remains unresolved.

## 1. A specific corporate-account offering

Yield App's 11 March 2021 announcement offered Launchpool fundraising projects a corporate account, 20,000 YLD tokens and advertised returns up to 20% APY. It names Alphabit as the partnership facilitator and describes treasury-management and custody functions. This establishes an available service in the network, not GamiFi's enrollment, account balance or a payment. [S1]

Yield App's December 2020 funding announcement also identifies Alphabit among its investors. [S2]

## 2. Stronger organizational links

| Connection | Verified public representation | Boundary |
|---|---|---|
| Alphabit to Launchpool | Techstars' June 2021 release states that Alphabit Digital Currency Fund started Launchpool in 2020. [S3] | A founding relationship; no shareholder percentages or account records. |
| Laura to Launchpool and GamiFi | Nativz's 9 July 2022 newsletter identifies Laura Walsh as GamiFi CEO, dates her Launchpool COO start to May 2021 and credits her with establishing GamiFi within Alphabit. [S4] | Professional roles and business establishment; no personal banking authority. |
| Alphabit leadership to GamiFi | GamiFi's litepaper identifies Liam Robertson as adviser and Alphabit Digital Currency Fund CEO. [S5] | Adviser status does not establish ownership or signing authority. |
| Successor to the same network | GamiFi's 1 September 2022 announcement names Eleanor Rooney as incoming CEO and describes her former Head of Analysis roles at Alphabit Digital Currency Fund and Launchpool. [S6] | A management connection, not an admission about fund use. |
| Ghaf Capital to GamiFi | Ghaf's own investment-portfolio page lists GamiFi. Primary indexed text was recovered; direct retrieval was intermittent. [S7] | Portfolio relationship; no subscription amount or ownership percentage verified. |

## 3. Correction to the weight of the managed-fund phrase

Clause 7.1.3 is identical in four examined documents after replacing provider names and normalizing typography. The coordinator independently repeated this comparison. Therefore the phrase is shared drafting, not standalone evidence that a separate GamiFi investment fund existed. Authorship and the direction of copying are unknown.

| Document | Displayed revision | Source observation |
|---|---|---|
| Launchpool | 13 January 2021 | Archive capture 19 May 2021. [S8] |
| Yield App | 8 February 2021 | Downloaded original PDF; the filename's February 10 wording differs from the displayed revision. [S9] |
| Launchpool | 10 November 2021 | Archive capture 28 January 2022. [S10] |
| GamiFi | 25 January 2022 | Archive capture 7 October 2022. [S11] |

Normalized clause SHA-256: `fa2ff2e930ab20bb26ce00786c90426cfaa94572abdf6542cc15201414b32d77`.

The compared Yield terms identify ETHpipe OU in Estonia as operator, YLD Limited in Seychelles, and BitGo as a digital-wallet custodian. These particulars belong to Yield; they must not be assigned to GamiFi. [S9]

## 4. Legal identities and a later counterparty change

| Business / record date | Name and jurisdiction stated in the document |
|---|---|
| GamiFi terms, revised January 2022 | GamiFi Limited; British Virgin Islands. [S11] |
| Launchpool terms, captured in 2021 and 2022 | Introduction: Launch Pool Limited; heading: Launchpool Limited. The text says Virgin Islands, without specifying British. [S8, S10] |
| Launchpool terms, revised 8 February 2024 and captured 24 April 2024 | Asociados Carajo Inc.; Republic of Panama. [S12] |
| Alphabit's SEC-hosted Form D, signed 1 February 2018 | Alphabit Digital Currency Fund; Cayman Islands exempted company formed in 2017; Dalma Capital Management listed as investment manager. [S13] |

The Launchpool records establish a changed published contracting party. The asset-transfer, liability-assumption and shareholder documents were not recovered. No evidence attributes the 2024 change to Laura.

Launchpool's migration FAQ gives regulatory difficulties as its explanation for establishing a new company. The current search index preserved that statement; direct retrieval returned an error. This is a company explanation with a retrieval limitation, not an adjudicated finding of unlawful conduct. [S14]

## 5. Financing terms versus money received

GamiFi's published financing schedule lists seed $450,000; strategic $525,000; private round one $850,000; private round two $1,080,000; and public $150,000: US$3,055,000 in total. Its litepaper also describes a 5% fee on hosted IDO allocations. These distinguish the issuer's own token financing from platform fees. They are published commercial terms, not reconciled receipts. The linked mirror carries a November 2021 cover but should not date every passage without the previously collected version history. [S5]

## 6. A new vesting and control link

Public repository deployment records led to another live GMI vesting proxy. At BNB Smart Chain block **120,220,302**, the coordinator independently verified:

| Field | Returned value |
|---|---|
| Vesting proxy | `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb` |
| `token()` | `0x93d8d25e3c9a847a5da79f79ecac89461feca846` — canonical GMI |
| `owner()` | `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b` |
| Owner of ProxyAdmin `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475` | `0x538a8b615e98e87d025c4336be44e4b8588277c7` |

The vesting owner is the address already identified in the prior GamiFi report as the GMI proxy administrator and owner of the examined Mystery/Duke NFTs. The separate ProxyAdmin owner is a different control role. No human holder is established.

The coordinator also re-read successful deployment receipt `0xe42d218340a4a53c8ed687bb8ac26a4cc9d07e4d0af061a6abd3b8f347ff4c66`. It creates the vesting proxy from `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`. Additional saved receipts show that deployer created the examined Mystery and Duke proxies and their ProxyAdmin. [S15-S17]

The repository labels its relevant contract VestingLaunchPool and describes its initialization task as being for Launch Pool investors. At block **120,220,233**, two selected repository CSV amounts matched live vesting records exactly: **587,755.519557566 GMI** and **17.2356392039306 GMI**, both with stored April 19, 2022 starts. This links two data rows to contract state. It does not validate the entire CSV, identify investors, prove deposited backing or establish payouts. No full deployed-bytecode match for this vesting implementation was performed in this pass. [S15-S17]

## 7. Records that would close the remaining gaps

| Question | Needed evidence |
|---|---|
| Did GamiFi use Yield's corporate service? | Corporate onboarding approval, account statement, an attributable deposit wallet, or a specifically documented corporate YLD allocation. |
| Who owned the relevant companies? | Certified incorporation records, shareholder and beneficial-ownership records, and the GamiFi/Alphabit/Launchpool agreements. |
| Where did token-sale proceeds go? | Round-level subscription records and reconciled receipts, transfers, custody balances and expenses. |
| Who could move assets or upgrade contracts? | Dated signing mandates, key-custody records, multisignature membership where applicable and attributable authorization records. |
| What happened to hosted-offering funds? | Offering agreements, fee invoices, private-allocation contracts and refund/distribution reconciliations. |
| What transferred to the Panama counterparty? | Corporate reorganization and asset/liability-transfer documents. |

Yield's official site identifies Cork Gully as its liquidators following a July 2024 appointment. If a GamiFi customer relationship is corroborated, the liquidation records become a specific evidence route. No GamiFi creditor or depositor entry was established in this review. No one was contacted. [S18]

## Sources and reproducibility

- **S1:** [Yield App / Launchpool corporate-account announcement, 11 March 2021](https://yieldapp.medium.com/yield-app-partners-with-launchpool-provides-corporate-accounts-for-defi-projects-b70a68293245).
- **S2:** [Yield App funding announcement, 14 December 2020](https://yield.app/blog/yld-trading-is-live-whats-next).
- **S3:** [Techstars / Alphabit / Launchpool release, June 2021](https://www.businesswire.com/news/home/20210630005204/en/Techstars-partners-with-Alphabit-Fund-and-Launchpool-to-bring-blockchain-focused-accelerator-to-London).
- **S4:** [Nativz newsletter, 9 July 2022](https://www.nativzgaming.com/p/newsletter-09-07-22).
- **S5:** [GamiFi litepaper mirror, pages 8, 14-15 and 19](https://www.cryptocompare.com/media/40411356/gamifi-litepaper-11.pdf).
- **S6:** [GamiFi CEO succession, 1 September 2022](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147).
- **S7:** [Ghaf Capital investment portfolio](https://ghafcapital.ae/investments.html).
- **S8:** [Launchpool terms, 19 May 2021 capture](https://web.archive.org/web/20210519003035/https://launchpool.xyz/terms-conditions/).
- **S9:** [Yield App February 2021 terms PDF](https://uploads-ssl.webflow.com/5f3b1e7e87a54051ee78b018/6023cb387c3551136db68ec2_YIELD%20-%20T%26C%20-%20FEB%2010.pdf).
- **S10:** [Launchpool terms, 28 January 2022 capture](https://web.archive.org/web/20220128063358/https://launchpool.xyz/terms-conditions/).
- **S11:** [GamiFi terms, 7 October 2022 capture](https://web.archive.org/web/20221007163947/https://app.gamifi.gg/terms-and-conditions/).
- **S12:** [Launchpool terms, 24 April 2024 capture](https://web.archive.org/web/20240424044933/https://launchpool.xyz/terms-conditions/).
- **S13:** [Alphabit Digital Currency Fund Form D](https://www.sec.gov/Archives/edgar/data/1729768/000094562118000060/xslFormDX01/primary_doc.xml).
- **S14:** [Launchpool token-migration FAQ](https://app.launchpool.xyz/token-migration/).
- **S15:** [Public GamiFi repository](https://github.com/sheandev/gamifiContracts), particularly *Historical file: unknown-56.json*, `contracts/VestingLaunchPool.sol`, `tasks/initVesting.js`, and `vesting.csva`; [vesting-addition commit, 19 April 2022](https://github.com/sheandev/gamifiContracts/commit/b5c2cd4aa396f65b45b8f3921ab068ee36e40ad4). Repository labels are distinct from proof of executed behavior.
- **S16:** [Vesting deployment transaction](https://bscscan.com/tx/0xe42d218340a4a53c8ed687bb8ac26a4cc9d07e4d0af061a6abd3b8f347ff4c66). Findings use raw RPC receipt data, not an unavailable explorer page.
- **S17:** BNB Chain read-only JSON-RPC at `https://bsc-dataseed.bnbchain.org`; exact requests, results and block numbers are in the companion verification ZIP. No wallet was connected or transaction broadcast.
- **S18:** [Yield App liquidation notice](https://yield.app/); [Cork Gully's dated public account](https://corkgully.com/cork-gully-achieves-rapid-crypto-asset-recovery-and-distribution-in-yield-app-liquidation/).

The companion ZIP contains this note, selected public blockchain requests/responses, source metadata and comparison fingerprints. Source hashes identify the retrieved bytes; they do not certify publication truth. Full private banking, treasury and ownership records remain outside the evidence obtained.
