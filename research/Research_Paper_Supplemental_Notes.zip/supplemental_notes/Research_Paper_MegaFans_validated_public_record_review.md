# Research Paper — MegaFans — validated public-record review

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Review date:** September 5, 2026 (UTC)  
**Scope:** MegaFans/Megafans Inc.; Megafans Ltd.; MBUCKS; publicly linked games and disclosures.

The strongest surviving findings concern unreconciled financial projections, inconsistent user targets, offering disclosures and product-policy clarity. Validation weakens broader theories of nonexistent tokens, an unexplained offshore entity, or an absence of contractual priority rules. Historical offering terms do not establish current finances or Laura Walsh/Takenaka's responsibility.

“Back-test” here means revisiting each lead against original documents, dates, independent records, arithmetic and plausible alternative explanations. It does not mean executing transactions or retrospectively testing investment returns.

## Finding taxonomy

- **Confirmed:** the stated observation is supported directly.
- **Downgraded:** a narrower issue survives after counterevidence.
- **Resolved:** the proposed adverse inference is explained or rejected.
- **Open:** necessary evidence is unavailable or inconclusive.

## Validated findings and lead dispositions

| ID | Lead | Disposition and evidence | Practical implication |
|---|---|---|---|
| MF01 | Offering amount | **Downgraded.** Campaign: USD 400,000; Reg D PPM: USD 40,000. Reg S terms remain unavailable. [S1](https://republic.com/megafans) [S2](https://republic.com/documents/9987?view=preview) | A scope/display inconsistency survives. Do not call it a proven tenfold fundraising misrepresentation. |
| MF02 | Delivery timing | **Downgraded.** PPM: 30 days; TPA: 3 days after final processing. TPA §7.1 supersedes contemporaneous disclosures. [S2](https://republic.com/documents/9987?view=preview) [S3](https://uploads.republic.com/p/offerings/security_attachments/original/000/010/004/10004-1719345900-f13c893d37d6ef54e9a1dedc70542cfa0fabe4f1.pdf) | Drafting differs; contractual hierarchy exists. Actual signed terms and processing date would determine any claim. |
| MF03 | Unlock trigger | **Downgraded.** TPA front: one year after release; Exhibit A: after purchase, with an express priority clause. [S3](https://uploads.republic.com/p/offerings/security_attachments/original/000/010/004/10004-1719345900-f13c893d37d6ef54e9a1dedc70542cfa0fabe4f1.pdf) | Retain editorial inconsistency; do not assume every clause has equal priority. |
| MF04 | Token allocations | **Confirmed disclosure gap; arithmetic resolved.** PPM reserve: 45%; detailed incentive allocation: 19m. [S2](https://republic.com/documents/9987?view=preview) | An explanation of category overlap is missing. The complete allocation nevertheless balances; see calculation. |
| MF05 | Corporate identity | **Resolved in part.** PPM explains common-owned California Inc./BVI Ltd.; campaign labels issuer Inc., legal name Ltd., form limited partnership. PPM calls Ltd. a business company. [S1](https://republic.com/megafans) [S2](https://republic.com/documents/9987?view=preview) | Multiple entities are explained; page labelling still needs correction. |
| MF06 | Withdrawn Republic campaign | **Confirmed.** Republic reports withdrawal and refunds. [S1](https://republic.com/megafans) | Exclude this campaign from completed-fundraising totals. Withdrawal motive remains open. |
| MF07 | Business viability | **Confirmed historical disclosure.** The campaign admits repeated pivots, unproven sustainability and funding-intensive operations. [S1](https://republic.com/megafans) | Relevant historical business risk; no current insolvency finding. |
| MF08 | Unminted-token statement | **Open chronology.** June 25, 2024 PPM says unminted. [S2](https://republic.com/documents/9987?view=preview) | Exact creation block is required to test that statement. |
| MF09 | Launch claim | **Downgraded.** May 29 company release announces a chain launch but also describes launch as upcoming; it predicts June exchange trading. [S4](https://www.prnewswire.com/news-releases/megafans-launches-and-lists-token-mbucks-on-binance-smart-chain-302158231.html) | Ambiguous promotional timing, not a demonstrated fabrication. |
| MF10 | Never launched | **Resolved as unsupported.** Exact-address index evidence and a dated explorer search result support subsequent token existence/activity. [S5](https://x.com/MegafansGaming/status/1806408017103175844) [S6](https://tradingstrategy.ai/trading-view/binance/tokens/0x3638fea0c645b1aa79db706fab6e8a761385c390) [S7](https://bscscan.com/tx/0x749751a2bf0609ab58228c9c2425f4ea3e90ab25486c33b2db7641ec93afa980) | Do not say the token never existed. Mint time, transfer history and actual liquidity remain open. |
| MF11 | Binance exchange listing | **Open/unverified.** The release's chain-related wording does not independently establish exchange admission. [S4](https://www.prnewswire.com/news-releases/megafans-launches-and-lists-token-mbucks-on-binance-smart-chain-302158231.html) | Exclude a Binance exchange listing from verified achievements. |
| MF12 | App maintenance | **Confirmed, bounded.** Three US app histories end in spring 2023; details below. [S8](https://apps.apple.com/us/app/candy-boo-esports-tournament/id1447419350) [S9](https://apps.apple.com/us/app/crash-n-win/id1503172280) [S10](https://apps.apple.com/us/app/tunnel-tournament/id1503582224) | Ask about mobile maintenance; do not infer whole-company abandonment or lack of backend updates. |
| MF13 | Privacy identity | **Confirmed disclosure-fit problem.** Game seller is Megafans Inc.; linked policy identifies Appic Studio without explaining the relationship. [S8](https://apps.apple.com/us/app/candy-boo-esports-tournament/id1447419350) [S9](https://apps.apple.com/us/app/crash-n-win/id1503172280) [S11](https://appicstudio.com/privacy-policy.html) | Controller/vendor responsibilities need clarification. Actual unlawful processing is not established. |
| MF14 | Child-targeting theory | **Downgraded.** Reviewed US apps carry 18+ ratings; policy includes an under 13 collection restriction. [S8](https://apps.apple.com/us/app/candy-boo-esports-tournament/id1447419350) [S9](https://apps.apple.com/us/app/crash-n-win/id1503172280) [S10](https://apps.apple.com/us/app/tunnel-tournament/id1503582224) [S11](https://appicstudio.com/privacy-policy.html) | This pass does not establish deliberate child-data collection or abuse. |
| MF15 | Traction/AI/SDK claims | **Open.** Current profile promotes 800k users, AI tournaments and Unity/Unreal support. [S12](https://www.linkedin.com/company/megafansesports) | Cohort definitions, dated technical documentation and independent usage evidence are still needed; claim changes are not automatically contradictions. |
| MF16 | Laura's control/ownership | **Resolved as unsupported inference.** PPM identifies two founder shareholders and founder control. [S2](https://republic.com/documents/9987?view=preview) | Advisory titles do not prove executive control, equity ownership, token receipts or authorship of defects. |
| MF17 | Old negative app reviews | **Downgraded.** Negative and positive historical comments coexist. [S9](https://apps.apple.com/us/app/crash-n-win/id1503172280) | Old anonymous reviews are leads, not verified current defects or unpaid-prize findings. |
| MF18 | Generic press links | **Confirmed weak substantiation.** Campaign press links include general crypto pages. [S1](https://republic.com/megafans) | A press-logo/link block does not demonstrate project-specific editorial coverage. |
| MF19 | Newer collateral | **Confirmed.** Forecast inconsistencies; see validation below. S14 (MegaFans forecast deck; source title retained) | Corrected forecasts needed. |
| MF20 | Registry/amendment evidence | **Open after targeted searches.** No reliably matched official filing or correcting supplement was located. | Search absence is not evidence of nonfiling, legal noncompliance or absence of an amendment. |

## Reproducible arithmetic

Sources: [S1](https://republic.com/megafans) page; [S2](https://republic.com/documents/9987?view=preview) printed pp.7–10; [S3](https://uploads.republic.com/p/offerings/security_attachments/original/000/010/004/10004-1719345900-f13c893d37d6ef54e9a1dedc70542cfa0fabe4f1.pdf) Exhibit A. All monetary results are USD. These calculations check declared figures, not actual receipts.

```python
from decimal import Decimal as D
reg_d = D(400000) * D("0.10")
display = D(400000)
reg_s_tokens = D(3000000)
assert reg_d == D(40000)
assert display / reg_d == D(10)
required_reg_s_price = (display - reg_d) / reg_s_tokens
assert required_reg_s_price == D("0.12")
# Hypothesis only: no Reg S price document was obtained.
assert reg_d + reg_s_tokens * D("0.10") == D(340000)

# Declared allocation categories, millions of tokens, in document order:
alloc = list(map(D, ["7","15","5","3","5","10","10","3.4",
                    "19","15","4","2.31","1.29"]))
assert sum(alloc) == D(100)
assert D(19) / sum(alloc) * 100 == D(19)
```

Executed successfully September 5, 2026. The combined-offering hypothesis is mathematically possible at 12¢; it is **not an identified Reg S term**. Neither mechanically applying the Reg D price to Reg S nor treating the display as a verified Reg D maximum is justified.

## Complete-deck validation

Visually checked PDF pp.6, 15, 18; figures in USD millions. S14 (MegaFans forecast deck; source title retained)

| Projection | Displayed components | Calculated | Printed |
|---|---|---:|---:|
| Year 3 net income | 15 − 13 | 2 | 4 |
| Year 3 ending cash | 0 − 13 + 13 | 0 | 17 |
| Year 4 ending cash | 17 − 25 + 25 | 17 | 47 |
| Year 5 ending cash | 47 − 45 + 0 | 2 | 50 |

Cash checks use displayed opening balance, operations and financing; dash financing is treated as zero. Missing lines might reconcile differences. These are forecast faults, not observed losses.

User targets conflict: p.6 places 100m in 2026; p.18 assigns 10m to 2026 and 100m to 2028. S14 (MegaFans forecast deck; source title retained)

## Dated chronology

| Date | Record and significance |
|---|---|
| 2023-03-24 | Candy Boo v24.0.7, last displayed US release. [S8](https://apps.apple.com/us/app/candy-boo-esports-tournament/id1447419350) |
| 2023-03-30 | Crash n Win v2.0.8, last displayed US release. [S9](https://apps.apple.com/us/app/crash-n-win/id1503172280) |
| 2023-04-05 | Tunnel Tournament v2.0.6, last displayed US release. [S10](https://apps.apple.com/us/app/tunnel-tournament/id1503582224) |
| 2024-05-29 | Company-issued launch publicity. [S4](https://www.prnewswire.com/news-releases/megafans-launches-and-lists-token-mbucks-on-binance-smart-chain-302158231.html) |
| 2024-06-25 | Dated PPM. [S2](https://republic.com/documents/9987?view=preview) |
| June 27, 2024 context | Indexed company/Launchpool posts announce token claiming at 19:30 UTC. Snippet evidence, not verified execution. [S15](https://x.com/MegafansGaming/status/1806401684668907988) [S16](https://x.com/LaunchPoolXYZ/status/1806405186212040798) |
| 2024-10-26 07:44:12 UTC | Indexed BscScan result describes a successful 956.63-MBUCKS approval. Full transaction view was inaccessible. [S7](https://bscscan.com/tx/0x749751a2bf0609ab58228c9c2425f4ea3e90ab25486c33b2db7641ec93afa980) |
| 2025-04-05 / 04-10 | Document-host creation/modification timestamps; cover says 2024. First publication remains unverified. S14 (MegaFans forecast deck; source title retained) |
| 2026-09-05 | This review; current listing/profile observations should not be retroactively substituted for 2024 conditions. |

The June claiming announcements are compatible with a June 25 unminted statement. Without the creation transaction, there is no proven mint-date contradiction. Token approval alone is not a transfer, purchase, prize payout or proof of beneficial ownership.

## App-policy validation and current-product limits

The examined US store pages name **Megafans Inc.** as seller. Candy Boo and Crash n Win link to **Appic Studio's** policy. The linked policy discusses advertising identifiers, location/IP, optional email and SDK operations, but does not identify MegaFans or explain tournament wallets, prize payouts or related KYC. Its generic contact route belongs to the policy provider; a working customer-support response was not tested. [S8](https://apps.apple.com/us/app/candy-boo-esports-tournament/id1447419350) [S9](https://apps.apple.com/us/app/crash-n-win/id1503172280) [S11](https://appicstudio.com/privacy-policy.html)

An Apple New Zealand developer catalogue includes **King Koin**, which was absent from the examined US catalogue. Its linked detail page could not be retrieved. This is a concrete reason to avoid turning three US histories into a claim covering every app or country. [S17](https://apps.apple.com/nz/developer/megafans-inc/id918762107)

No app was installed, no account created, and no money or token transaction performed. Store metadata cannot establish backend uptime, security quality, actual age-gate enforcement, redemption success or current data transmission.

## Exact-address chain check

Project-associated indexed post: [S5](https://x.com/MegafansGaming/status/1806408017103175844). Address:

`0x3638feA0C645B1aa79Db706Fab6E8a761385c390`

TradingStrategy indexes that exact address as Megabucks/MBUCKS, BEP-20, 100m supply and one pair. Its page displays approximately USD 9.06k liquidity and zero 24-hour volume, but supplies no independently checked observation block. Those figures are **index displays only**, not certified current balances or executable prices. [S6](https://tradingstrategy.ai/trading-view/binance/tokens/0x3638fea0c645b1aa79db706fab6e8a761385c390)

BscScan token, holder and transaction pages returned 403/tool errors. Indexed snippets were retained as limited corroboration; access was not circumvented. No chain-wide completeness, creator attribution, ownership concentration, launch-price return, vesting execution or misconduct finding is asserted.

## Search validation and rejected leads

Queries covered the exact contract, MBUCKS with June 2024 dates, MegaFans plus Reg S/PPM/amendment, and exact company variants plus SEC/Form D. The rendered Republic Updates control returned the same page; a direct updates path could not be retrieved. No distinct Reg S document or correcting supplement was recovered.

Name-only results included unrelated geological megafans, industrial fans, creator platforms and MEGA-ticker listings. They were excluded. A third-party “deadpooled” result had unresolved entity matching and inaccessible full content; it was not adopted as a company-status finding. Aggregator fundraising dates/amounts were not substituted for closing records.

## Priority evidence needed to close open findings

1. Full Reg S offering documents, dated amendments, final approved page copy and any executed agreements; these resolve scope, pricing and contractual dates.
2. Exact-contract creation transaction, first mint event, verified code and relevant vesting addresses; these test chronology and implementation.
3. Recent product changelogs, complete current terms/privacy notices and documented MegaFans–Appic roles.
4. Corrected, dated forecasts plus independently supported business metrics and financial information.
5. Any Laura-specific appointment, instruction, signed representation or payment record relevant to a concrete allegation.

This review supplies no independent basis to allege a crime, investor theft, insolvency or Laura's personal liability.

## Sources and access record

All sources were reviewed or attempted on **2026-09-05**. “Retrieved” means content available through the research tool; it does not guarantee live origin state or a preserved forensic capture. PDF page references above use printed numbers unless explicitly described otherwise.

- **S1 — Republic campaign:** https://republic.com/megafans — retrieved; historical 2024 offering page, current withdrawal notice; no accessible correction found.
- **S2 — PPM:** https://republic.com/documents/9987?view=preview — 35-page PDF, dated 2024-06-25; text retrieved. Image-only financial table was not successfully inspected, so no P&L finding is made.
- **S3 — TPA:** https://uploads.republic.com/p/offerings/security_attachments/original/000/010/004/10004-1719345900-f13c893d37d6ef54e9a1dedc70542cfa0fabe4f1.pdf — 21-page unsigned public form; text retrieved.
- **S4 — Company press release:** https://www.prnewswire.com/news-releases/megafans-launches-and-lists-token-mbucks-on-binance-smart-chain-302158231.html — retrieved; 2024-05-29; promotional primary source.
- **S5 — Project contract post:** https://x.com/MegafansGaming/status/1806408017103175844 — search-index excerpt; full post failed.
- **S6 — Exact-address index:** https://tradingstrategy.ai/trading-view/binance/tokens/0x3638fea0c645b1aa79db706fab6e8a761385c390 — retrieved; index methodology/block not verified.
- **S7 — Explorer transaction:** https://bscscan.com/tx/0x749751a2bf0609ab58228c9c2425f4ea3e90ab25486c33b2db7641ec93afa980 — indexed search result only; full view failed.
- **S8 — Candy Boo:** https://apps.apple.com/us/app/candy-boo-esports-tournament/id1447419350 — retrieved US store metadata/history.
- **S9 — Crash n Win:** https://apps.apple.com/us/app/crash-n-win/id1503172280 — retrieved US store metadata/history.
- **S10 — Tunnel Tournament:** https://apps.apple.com/us/app/tunnel-tournament/id1503582224 — retrieved US store metadata/history.
- **S11 — Appic policy:** https://appicstudio.com/privacy-policy.html — retrieved via developer privacy link; direct opens intermittent. No effective-date determination.
- **S12 — Company profile:** https://www.linkedin.com/company/megafansesports — retrieved public self-description; claims not independently audited.
- **S13 — Official Linktree:** https://linktr.ee/MegaFans_esports — retrieved; linked from company profile.
- **S14 — 2025 deck:** MegaFans forecast deck (source title retained) — complete PDF retrieved; key pages visually checked.
- **S15 — Company claim announcement:** https://x.com/MegafansGaming/status/1806401684668907988 — indexed excerpt; full view empty.
- **S16 — Launchpool claim announcement:** https://x.com/LaunchPoolXYZ/status/1806405186212040798 — indexed excerpt; full view failed.
- **S17 — Apple NZ catalogue:** https://apps.apple.com/nz/developer/megafans-inc/id918762107 — retrieved; linked King Koin detail unavailable.
