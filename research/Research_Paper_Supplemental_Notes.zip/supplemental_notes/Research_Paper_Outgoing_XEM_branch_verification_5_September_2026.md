# Research Paper — Outgoing XEM branch verification — 5 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

All 21 selected transactions matched their asserted historical blocks on nem02. Every outer signature appeared exactly once; every full inner transaction matched the original nem01 history; every normalized XEM amount agreed. This is record corroboration, not a cryptographic audit or identification of account owners.

## Common destination

`NC64UFOWRO6AVMWFV2BFX2NT6W2GURK2EOX6FFMZ` received 18 selected transfers totalling **5,748,124 XEM** from five addresses in the 14-address register. The register boundary excludes Foundation and regional accounts; the broader retrieved data also contains Foundation transfers to this destination. It is an unidentified common destination in this analysis. Shared destination alone does not establish a shared owner or common purpose.

| Sender | Transfers | XEM | First confirmed UTC | Last confirmed UTC |
|---|---:|---:|---|---|
| `NBDCOHCTOKI3RY46YK7EEPPQRG2UHPCNUQIDVLU5` | 3 | 66364 | 2018-09-12T11:58:16+00:00 | 2021-03-03T12:51:35+00:00 |
| `NC7HKOMA4N4ZCYJ7PXJPUGGQLSBLQL6S6LEFQHNZ` | 5 | 4300000 | 2019-05-20T05:34:38+00:00 | 2020-12-05T01:16:13+00:00 |
| `NCDYOMFFNO5T567SBODMNGZAYBGWREFCIGZ7T26J` | 8 | 1376658 | 2020-12-05T05:29:04+00:00 | 2022-03-24T12:42:54+00:00 |
| `NAHLQEVQ6GI2P67GFRTNGSAKP35XC6WPBBZLR2ZS` | 1 | 2 | 2021-01-07T08:53:54+00:00 | 2021-01-07T08:53:54+00:00 |
| `NCJHETVLYHK5C3GGO27HNRMBHCLPBSXYRL4WPHJ5` | 1 | 5100 | 2021-03-22T04:17:57+00:00 | 2021-03-22T04:17:57+00:00 |

This branch extends into March 2022. Later XEM payments by addresses that once interacted with KID do not establish later KID token transfers or continuing project activity.

## ND2JRP path

On 6 March 2019, the mixed-use issuer sent 500,000 XEM to the levy-designated address, confirmed at **03:39:49 UTC**. That recipient sent the same amount to `ND2JRPQIWXHKAA26INVGA7SREEUMX5QAI6VU7HNR`, confirmed at **03:42:31 UTC**, two blocks and two minutes forty-two seconds later. A direct 300,000-XEM issuer payment to that same destination confirmed **6 June 2019 at 10:15:21 UTC**. Both destination transfers carry the same plaintext reference `37503ccaac214a018a2`.

The destination receives **800,000 XEM** across these two selected payments. Adding the intermediate 500,000-XEM transfer would count that amount twice. The timing, equal amount, destination and reference are on-chain facts; beneficial ownership, exchange attribution and business purpose remain unverified.

| Confirmed UTC | From | To | XEM | Transaction |
|---|---|---|---:|---|
| 2019-03-06T03:39:49+00:00 | `NC7HKOMA4N4ZCYJ7PXJPUGGQLSBLQL6S6LEFQHNZ` | `NCEUKZQJXJGQSTEWUIRURSQVX2MDTXU5ZW37YQ4I` | 500000 | [9e715ed55…](https://explorer.nemtool.com/#/s_tx?hash=9e715ed554f0830fc93d867f6a48e0b0aeaebaa61bdaadea73691f6b2b741baf) |
| 2019-03-06T03:42:31+00:00 | `NCEUKZQJXJGQSTEWUIRURSQVX2MDTXU5ZW37YQ4I` | `ND2JRPQIWXHKAA26INVGA7SREEUMX5QAI6VU7HNR` | 500000 | [905643ede…](https://explorer.nemtool.com/#/s_tx?hash=905643ede8322b230f03f4b9cb36d0021e49dfdc7705af4d2d03e9a7ff69f1af) |
| 2019-06-06T10:15:21+00:00 | `NC7HKOMA4N4ZCYJ7PXJPUGGQLSBLQL6S6LEFQHNZ` | `ND2JRPQIWXHKAA26INVGA7SREEUMX5QAI6VU7HNR` | 300000 | [fa86f51c3…](https://explorer.nemtool.com/#/s_tx?hash=fa86f51c3f2a88197aeac376e0f445c3d3bb11ada66163fdcb56aede39825b25) |
