# Research Paper — GAMI original-offering delivery reconstruction

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research date: 7 September 2026 UTC. Scope: **GAMI**, token `0xf0dcf7ac48f8c745f2920d03dff83f879b80d438`, offered through original GamiFi project ID6. **GAMI is a different token from GamiFi's GMI.** This note does not resolve the separate November 44m-GMI withdrawal or identify a human signing-key holder.

## Principal result

The original offering's **127 funding addresses all received vesting allocations exactly equal to the token allocations recorded by their actual funding transactions**. Their 154 funding events total **28,421.141280969119319259 BUSD** and record **284,211.41280969119319259 GAMI** of token allocations. Every original funding address and its aggregate token allocation matches the distribution setup exactly; no original contribution address is omitted. The comparison uses each event's recorded allocation and does not assume that an advertised price constitutes the buyer's accepted legal terms.

At the pinned September 7, 2026 snapshot, all those allocations remain in the contract's records. **53 funding addresses have fully claimed, 62 have partially claimed, and 12 have no recorded claim.** The remaining **110,667.396436497796045799 GAMI** for this group is included in the contract's fully backed remaining obligations. An allocation placed in a claim contract is not the same as every token having reached the buyer's ordinary wallet; actual claim counters are reported separately below.

## Exact token route and allocation setup

1. On March 28, 2022 at 10:07:05 UTC, recipient `0x56aa83035aea8bfeb9e395a51607cc4621649aa2` sent **555,555 GAMI** to administrator `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`. Transaction `0x2b21af95699be3decd17d62c3c1d8da96a4d21b7f848d6d58ffd47769716c766`, block 16449700.
2. At 11:38:29 UTC that day, the administrator called `initiateVests` on **`0xf1adf471918b65006bf5d8505f6df976d9873d8b`**, the same GAMI distribution endpoint identified in archived application code. The successful transaction transferred all **555,555 GAMI** into that contract and created **157 distinct allocations**. Transaction `0x4a8ebee724b6bc76a07ce56c239f2f16b3f03361f558fe959dc86f55c96ffe5b`, block 16451528.
3. The transaction specifies **10% initial allocation, zero cliff and 23,328,000 seconds of linear vesting (270 days)**. Every current record retains a March 28 start of 11:38:29 UTC; scheduled maturity was December 23, 2022 at 11:38:29 UTC. The source's claimable calculation, rather than a marketing label, governs the precise release arithmetic.

Both route receipts were independently retrieved from Binance and Defibit endpoints and show successful status. Historical archive reads identify implementation `0x957e15b2fa377bfe35e6134411c65bd36dab9522` at the allocation block. The recovered Solidity source independently recompiles to the exact **4,895-byte runtime** returned by the archive at that block.

## Additional 30 allocations require an explanation

The setup also allocated **271,343.58719030880680741 GAMI** to **30 additional addresses absent from the complete original-ID6 funding census**. Their allocations are nearly equal: 29 receive 9,044.786239676960226913 GAMI and one receives 20 base units more to reconcile the total. These are separate allocations; they did not reduce the original 127 funders' recorded entitlements, which match exactly.

All 30 additional addresses have recorded partial claims. Their identity, entitlement, consideration and business purpose remain unresolved. The existing issuer/application/Telegram material reviewed by the archive lane contains no explanation specifically identifying these 30 allocations or this remainder. March 28 promotions about subsequent GAMI holding snapshots and 400% APY do not specify this allocation and must not be joined to it without further evidence. Missing entitlement documentation is an accounting lead, not proof of theft or common human ownership.

## Pinned remaining balances and claim counters

Snapshot: block **120402387**, **2026-09-07 00:57:54 UTC**. All 157 records, the token balance, owner, token pointer and pause flag were read together in one atomic Multicall3 `eth_call`. Defibit's subsequent latest-state call returned identical bytes for the complete set of views.

| Group | Addresses | Allocated GAMI | Recorded claimed GAMI | Remaining GAMI |
|---|---:|---:|---:|---:|
| Original-ID6 funding addresses |127|284211.41280969119319259|173544.016373193397146791|110667.396436497796045799|
| Additional addresses |30|271343.58719030880680741|91221.977804806657993183|180121.609385502148814227|
| Total |157|555555|264765.994178000055139974|290789.005821999944860026|

The contract's actual GAMI balance is **290,789.005821999944860026**, exactly equal to the remaining recorded amounts for all 157 original allocation records. All original allocation amounts remain unchanged and all schedules are mature. The GAMI token pause flag is false. The distribution owner is currently `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`; this is an address, not an identified human owner.

Claimed amounts above are direct contract counters, corroborated by the exact aggregate balance reconciliation and verified claim-function source. This pass has not reconstructed every individual Claim transaction or ultimate onward recipient. It does not value the tokens, establish purchasers' wallet access, prove a bank settlement for the associated BUSD proceeds, or resolve other product obligations.

## Evidence completeness and limits

- The final configured funding window held only 1,660 BUSD of the recorded contributions. Earlier funding was therefore recovered from preceding blocks. The complete queried range **16000000–16164960** yields 154 Funding events whose total exactly equals the withdrawal's recorded funded-total counter. All 154 receipts were independently verified through a second provider for successful status, matching block hash and Funding event, and actual BUSD transfer from the contributor to the project contract.
- No funding-window failures remain. The event record's token-allocation data, not an assumed advertised price, supplies the expected allocation for each address.
- Exact funding/vesting/claim-counter comparisons appear in `gami_buyer_delivery_reconciliation.csv` and its JSON counterpart. `initial_vest_allocations.json` preserves the decoded 157-address setup. `atomic_current_vests.json` is the authoritative current snapshot; earlier attempted individual pinned reads encountered pruned state and were superseded by the atomic read.
- `gami_funding_receipt_verification.json` records 154/154 successful crosschecks. `historical_live_code_match.json`, `vesting_source_match.json`, `route_independent_receipts.json` and `independent_snapshot_comparison.json` preserve the additional verification results. Raw requests retain endpoint, retrieval UTC, parameters and response.
- Remaining exact records: consideration and entitlement for the 30 extra allocations; the complete historical Claim and onward-token transaction census; accepted buyer terms and access/fulfilment records; ultimate business settlement of the original BUSD proceeds; and dated human custody/approval records. No chain transactions were broadcast, and no private account records were accessed.
