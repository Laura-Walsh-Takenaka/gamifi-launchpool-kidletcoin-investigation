# Research Paper — Laura Walsh / Takenaka: expanded public business record and Ottawa owner check

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

**Later Cardano correction.** The validated Cardano review resolves the apparent budget-allocation and cohort-size discrepancies through the approved milestone records. Payment tranches are not spending categories; twenty selected companies and eighteen graduates are reconciled. Earlier unresolved-budget or missing-delivery wording must be read with that correction.

Reviewed 5 September 2026 UTC. This follow-up extends the earlier project, trading and involvement reviews. It covers public professional activity and distinguishes corporate records, employer statements, personal representations and unresolved questions.

**The public record includes substantive NEM governance and communications roles, Launchpool allocation promotion, GamiFi leadership, investment/advisory relationships and startup mentoring.**

## 2. Expanded map of Laura's public roles

“Current listing” describes what the inspected organization publishes today. Historical dates are not proof that a role continues.

| Organization / activity | Documented role or act | Status and attribution |
|---|---|---|
| **NEM Thailand** | Country representative/manager; named MOU signatory in a 2018 blockchain-centre announcement. | Historical representative role and concrete signing act. [Regional issuer report](https://medium.com/nem-sea/nem-thailand-thoresen-thai-agencies-mou-open-bangkok-blockchain-centre-4c72ea09289f). |
| **NEM Foundation** | Interim secretary, followed by director and Honorary Secretary appointments in 2019; assigned communications work. | Formal governance role, supported by Secretariat records. Details below. |
| **NEM Group** | Senior Director, Channel and Content, March 2020–February 2021. | Exact title/months remain [professional-profile](https://ca.linkedin.com/in/lauralwalsh) evidence in this pass. Distinguish the Group from the Foundation and funding bodies. |
| **NEAR Protocol** | Publicly reported prior marketing work; profile gives February–May 2021. | Corroborated retrospectively by [Nativz](https://www.nativzgaming.com/p/newsletter-09-07-22) and the Syndika announcement; no employer appointment or personally assigned NEAR project recovered. |
| **Launchpool / Labs** | COO; named answers about token-holding thresholds, eligibility exceptions, allocation rules and vetting in July 2021. | Direct operational/promotional representations in the [company AMA](https://launchpoollabs.medium.com/launchpool-labs-community-ama-summary-546fc8b122a). A separate Alphabit officer appointment was not established. |
| **GamiFi.gg / GMI** | Publicly credited founder, CEO and named promoter of token/staking access and partner offerings. | Historical 2021–2022 leadership; successor announced September 2022. See the preceding involvement addendum and [named offering endorsement](https://via.tt.se/pressmeddelande/3317115/play-to-earn-company-gami-lists-gamifis-first-launchpad-ido?publisherId=259167). |
| **MegaFans** | Self-reported seed investor and adviser from May 2022, covering web3 strategy, marketing and business outlook. | Adviser/investor involvement; no verified executive, treasury or trading authority. Exact investment terms and current assignment are undisclosed in the reviewed records. [Profile](https://ca.linkedin.com/in/lauralwalsh). |
| **Nativz Gaming** | First angel investor announced July 2022; remains on the official adviser list. | Current public advisory listing plus historical investment confirmation. [Team](https://www.nativzgaming.com/our-team), [announcement](https://www.nativzgaming.com/p/newsletter-09-07-22). |
| **Syndika** | Syndicate membership and intended business/marketing/community advice announced in her own repost. | Historical appointment. No Laura entry on the inspected current syndicate roster; this alone does not establish departure. [Announcement](https://www.linkedin.com/posts/lauralwalsh_more-than-thrilled-to-be-a-member-of-syndika-activity-7087741668275208192-JAri), [roster](https://syndika.co/syndicate/). |
| **Techstars Web3** | Entrepreneur in Residence, cohort support and 2023 All-Star Mentor. | Program records and the former managing director corroborate the roles. The award was published **19 February 2024**. [Official award](https://www.techstars.com/blog/impact/2023-techstars-all-star-mentors-named). |
| **Techstars + Cardano Founder Catalyst** | Named mentor in the 2025 cohort's final report. | Report published February 2026; that publication date does not create a new 2026 teaching assignment. [Final report — publisher milestone record](https://milestones.projectcatalyst.io/projects/1300182/milestones/6), mentor roster p. 32. |
| **Kaskade Finance** | CMO and founding-team member, confirmed in a March 2024 interview. | Historical role; profile's November 2023–March 2024 dates do not establish an exact departure day. [Contemporaneous interview](https://www.moneyneversleeps.ie/farcaster-digital-identity-decentralized-social-media/). |
| **KIDLetCoin** | Her public post promotes a wallet demo and describes it as a NEMPay fork. | Direct promotional act; the retrieved post has only a relative date. It does not identify custody of all project wallets or responsibility for each data-processing operation. [Personal post](https://www.linkedin.com/posts/lauralwalsh_kidletcoin-wallet-demo-video-activity-6491593875063439360-Nte8?trk=public_profile_like_view). |
| **Public commentary** | Guest/co-host appearances about crypto, tokenization and digital identity. | The publisher's archive documents appearances through April 2025; discussion of another project does not establish a business appointment or paid promotion. [Publisher archive](https://www.moneyneversleeps.ie/guests/laura-walsh/). |

## 3. New personally attributable acts and specific issues

### NEM: appointment sequence and communications authority

Laura's own [2018 candidacy thread](https://forum.nem.io/t/laura-takenaka-for-secretary-council/20442?page=2) acknowledges that she did not win that election. The [May 2019 Secretariat update](https://forum.nem.io/t/nem-foundation-update-may-2019/22634) subsequently identifies her as interim Secretary and assigns her and Sharie Ingente global content-calendar, communications-policy and media-material work.

The [September 2019 update](https://forum.nem.io/t/nem-foundation-update-september-2019/23549) records the June 13 EGM's approval of her director appointment. It separately records the later Council appointment as Honorary Secretary following the August AGM and directorship paperwork. This provides a documented governance timeline; it should not be rewritten as an election victory in 2018.

### NEM: a financial-report representation that can be checked

On **12 March 2020**, her established `LauraBKK` account asserted in the [2019 ROI-report discussion](https://forum.nem.io/t/nem-foundation-2019-roi-report/24550) that expenses were fully reflected. She also invoked the Foundation's Singapore incorporation in responding to requests for salary disclosure. These are personally attributable representations. This pass did not audit the underlying expense ledger or validate her interpretation of privacy law.

The useful financial question is whether the published categories and totals reconcile to the relevant accounting records. A public claim of completeness is evidence of what she represented, not proof that records were complete or false. Comments promising investors future returns elsewhere in that thread were made by another account and must not be attributed to her.

### NEM: two identifiable publication issues, with their context

- **Entity description corrected:** On 27 March 2019 she described the Community Fund as effectively moved to NEM Ventures. A committee representative clarified that the organizations were independent; Laura explicitly accepted that clarification. Keep the original statement and correction together. [Full exchange](https://forum.nem.io/t/nem-community-fund-update-concluding-the-dao/22355).
- **Conflicting vote times:** The Symbol-ticker notice published by her account on 13 January 2020 states **3 PM PST** in its introduction and **1 PM PST** in its process list. That is a concrete inconsistency in the notice. The document is signed by the branding committee; publication by her account does not establish sole authorship. This review did not reconstruct actual vote opening or demonstrate an effect on the result. [Notice](https://forum.nem.io/t/community-poi-vote-symbol-ticker/24173).

The [2018 TTA announcement](https://medium.com/nem-sea/nem-thailand-thoresen-thai-agencies-mou-open-bangkok-blockchain-centre-4c72ea09289f) adds a named signatory role for the proposed Bangkok blockchain centre. It reports the MOU, but the executed instrument and delivery record were not recovered here.

### Launchpool: direct participation-policy and holding promotion

The **3 July 2021 company AMA**, covering the previous day's session, names Laura COO. Her answers defend the LPOOL holding threshold, explain eligibility treatment and project vetting, and encourage holding. The same record retains her investment-loss and early-project risk warnings. Those qualifications matter when describing the promotion. [Company transcript](https://launchpoollabs.medium.com/launchpool-labs-community-ama-summary-546fc8b122a).

This establishes a substantive role communicating and defending participation rules. It supplies no evidence that she fabricated exchange volume, instructed market makers or operated the trading wallets examined earlier. Statements by CEO Rich and Labs lead Roxana in the same AMA remain separately attributed.

## 4. Current work, credentials and corrections carried forward

Nativz still publicly lists her as an adviser. Syndika's historical announcement remains available, but current individual work there is unconfirmed.

Techstars' official award list verifies her mentor recognition. Pete Townsend's [23 July 2025 retrospective](https://www.linkedin.com/pulse/techstars-web3s-evolution-my-next-phase-pete-townsend-e6zpe) credits her with helping establish the program and years of EiR support; it also explains integration of the standalone Web3 accelerator into wider Techstars programs. His departure date is not Laura's departure date.

Chulalongkorn University's [thesis repository](https://digital.car.chula.ac.th/chulaetd/8679/) independently lists Laura Takenaka's 2019 MA thesis in International Development Studies. This supports the academic background reported in her professional biographies. Her earlier UNDP, Nova Scotia education-administration and Foreign Correspondents' Club work is described in her own 2018 forum answers; precise employment terms were not independently verified in this pass.

The later validated Cardano review already resolved the earlier apparent payment-allocation and cohort-size contradictions using approved milestone records. Those resolved suspicions are not reopened here. The 2026 final report confirms mentoring in the 2025 cohort; it does not establish Laura's control of the grant budget.

GamiFi's promotion of MegaFans during her reported overlapping roles remains a defined disclosure question. Individual authorship, approval and compensation for that company article remain unidentified. The previously reconstructed Kaskade April 2024 trading sequence still requires transaction-specific attribution; a broader career map does not supply it.

## 5. Verification record and scope

- Current team pages, old appointments, award years, publication dates and cohort dates were distinguished. Historical website availability is not treated as current operating status.
- Forum account identity was checked against Laura's own candidacy introduction. A misleading search excerpt associating her signature with an adjacent LATOKEN trading contest was rejected after checking the underlying message boundaries.
- No new ledger audit, full-chain reconstruction, legal determination or private-wallet identification was completed in this pass. The new contribution is stronger public attribution and entity/status verification, including findings that correct earlier leads.

The accompanying source register identifies the underlying pages and the preceding validated reviews used for continuity. This is an expanded public business record, not a claim to capture every engagement or private relationship.
