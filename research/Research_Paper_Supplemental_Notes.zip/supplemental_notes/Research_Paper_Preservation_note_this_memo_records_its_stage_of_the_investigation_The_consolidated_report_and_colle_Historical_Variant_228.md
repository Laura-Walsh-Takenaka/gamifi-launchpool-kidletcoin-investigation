# Research Paper — > Preservation note: this memo records its stage of the investigation. The consolidated report and collector supplements supersede former incoming-flow gaps and earlier coverage totals. The ETH-related counter identified in QA has been corrected. Exact continuity is not proof of exclusive balances or uniquely identified fungible token units.

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

# Kaskade LUSD campaign: complete identified-wallet swap and distribution expansion

Observed 5 September 2026. Ethereum mainnet events are April–May 2024. This memo supplements the earlier nine-swap sample and partner allegations with a wider transaction reconstruction. It does not identify a wallet's human owner or decide whether an offense occurred.

## Principal finding

**One exact-capital path comprises 66 swaps across all nine examined leaderboard wallets.** Between 18 April 17:32:47 UTC and 22 April 21:23:23 UTC, **30,500 USDC became 29,902.00513 USDC**, while the sum of each swap's input amount was **1,993,826.456664144632875365 nominal stablecoin units**. Every output is consumed exactly by the next swap, either within the same wallet or after verified token transfers. Eight transitions between successive trading wallets require ten token-transfer receipts, because two transitions relay through an earlier hub wallet.

At an explicit USDC=$1 and LUSD=$1 assumption, that is about **$1.994 million turnover from $30,500 initial principal**, a **65.371359×** turnover multiple. This is gross executed turnover, not new deposits, trader profit, company revenue, or an exact historical-dollar valuation. The two endpoint balances are both USDC, making the principal decrease **597.994870 USDC before gas** directly comparable. Swap gas totals **0.166844023287208029 ETH** and the ten connecting token transfers cost **0.006298926931151368 ETH**; neither includes all claims, approvals or native-ETH funding movements.

This demonstrates repeated reuse and inter-wallet movement of the same principal. The swaps took place against actual liquidity pools. These records alone do not establish literal exchange self-matching, deceptive statements, or an identified trader's purpose.

## Coverage: inventory is broader than campaign eligibility

All nine public normal-transaction lists displayed one complete page after selecting 100 records. Together they contained **480 address-list rows and 421 distinct hashes**; inter-wallet native transfers appear in more than one address list. Every visible normal transaction occurred between 11 April and 1 May 2024. Receipt decoding covered **235 of 235 swap-like calls**, **26 of 26 claims**, and **65 of 65 outgoing USDC/LUSD Transfer calls**. These are disjoint receipt categories totaling **326 distinct transactions**.

The 235 swap-like calls resolve into **231 USDC/LUSD swaps, three ETH-related swaps, and one bridge call**. All 235 displayed Success. A full method-name audit added two lowercase `Unoswap` calls that a case-sensitive initial filter missed. The bridge deposited 19,997.776955 USDC toward Solana via Allbridge, with another 2.223045 USDC transferred to the bridge; the receiving chain was not reconstructed in this subtask.

| Address | Normal list rows | Swap-like receipts / inventory | USDC/LUSD swaps | Claim receipts | Outgoing stablecoin transfers |
|---|---:|---:|---:|---:|---:|
| `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` | 54 | 25/25 | 24 | 3 | 7 |
| `0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D` | 61 | 35/35 | 34 | 3 | 7 |
| `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 67 | 29/29 | 29 | 2 | 11 |
| `0x52AfBA2412e94F8556D0895be7925aE95Fe92f5d` | 48 | 23/23 | 23 | 3 | 7 |
| `0x68d3D886643a0ABb6ab9B23006305260365F7F2f` | 48 | 22/22 | 22 | 3 | 7 |
| `0x9B0547b60FEe159e89E078Be824a76bCF5AfEbDA` | 40 | 17/17 | 16 | 3 | 6 |
| `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 62 | 34/34 | 34 | 3 | 7 |
| `0x7737E76f84107161735955e5B0596e1fF9D6d122` | 57 | 31/31 | 31 | 3 | 7 |
| `0x97592b48E20d40a69eA7C597354acf7ED1FdEd47` | 43 | 19/19 | 18 | 3 | 6 |

Public list provenance: `https://etherscan.io/txs?a=ADDRESS&ps=100`, with each exact verified URL preserved in `kaskade_history_expansion_inventory_full.json`. Individual receipt URLs, canonical UTC timestamps, blocks, exact token quantities and fees are preserved separately. No native-only funding/approval receipt completeness is claimed. Normal account lists omit incoming ERC20 transfers initiated by external addresses; they cannot establish complete inbound balances, all-chain history, or all Kaskade participants.

## The 66-swap path, in trading order

Each row's final amount becomes the following row's starting amount, through the transfer receipts below. Full token precision is retained.

| Trading wallet | Swaps | First → last UTC | Initial input | Final output | First / last swap receipt |
|---|---:|---|---|---|---|
| `0x68d3D886…5F7F2f` | 6 | 2024-04-18 17:32:47 → 2024-04-18 17:35:59 | 30500 USDC | 30445.154564 USDC | [0xbb69337c99…](https://etherscan.io/tx/0xbb69337c999f054cf88427b031e4a9e84a9977854f75d6608f07076609da2ebc) / [0x44ce205cc6…](https://etherscan.io/tx/0x44ce205cc6dfd0502a8316003fbaca2eadfd6b3c5b48f17c765ac6327a5dcec2) |
| `0x425e16a8…b46168` | 6 | 2024-04-18 17:39:47 → 2024-04-18 17:42:23 | 30445.154564 USDC | 30390.407716 USDC | [0xb5da5a9ea1…](https://etherscan.io/tx/0xb5da5a9ea154db35456408ae233c2195ce42ec7c43c05fee37dbe1c24b2412fa) / [0x5b9a06c604…](https://etherscan.io/tx/0x5b9a06c6049fdf53a25a29ae2e7652743ffc9fd1458436baa3db2553cca311a1) |
| `0x4E958Cb8…51C65b` | 12 | 2024-04-18 17:48:47 → 2024-04-19 17:04:35 | 30390.407716 USDC | 30281.192454 USDC | [0x0835a49c29…](https://etherscan.io/tx/0x0835a49c29a6901758b5e92e3da392563ea0678d58de2b7465e65d0ac464435f) / [0x937392d717…](https://etherscan.io/tx/0x937392d717f8b7becbaf3cd28abec17126d2753d35ee5b927f3044ebdd10f80d) |
| `0xcfC2F1b6…D7B455` | 9 | 2024-04-20 18:05:23 → 2024-04-20 18:10:35 | 30281.192454 USDC | 30207.867080991279108779 LUSD | [0x66e91ec001…](https://etherscan.io/tx/0x66e91ec0018193397cfd98a2e7ed941f61c90e2a76d11d8f1891e0ed635432dd) / [0x9e7b5b2f58…](https://etherscan.io/tx/0x9e7b5b2f587afb617704778508850dccd07d8cffdb18b990b368c98da562f63a) |
| `0x9D383C16…87A97D` | 13 | 2024-04-20 18:12:35 → 2024-04-20 18:21:35 | 30207.867080991279108779 LUSD | 30081.967794 USDC | [0x1e5aa69b42…](https://etherscan.io/tx/0x1e5aa69b42fe508eecd6e98595eb72cb2e50e9c544cade33dc4dff7335c6042d) / [0xf2d0270bcc…](https://etherscan.io/tx/0xf2d0270bcc965847ebffdc320aa1fbf44d31763298a409917cc68e3a005d1592) |
| `0x9B0547b6…AfEbDA` | 6 | 2024-04-20 18:25:59 → 2024-04-20 18:28:35 | 30081.967794 USDC | 30027.861638 USDC | [0x0a58ca44a1…](https://etherscan.io/tx/0x0a58ca44a17605889001c12108b4296ae867d5dd4276529f8296c94d23cb8ff5) / [0x57e628c3fb…](https://etherscan.io/tx/0x57e628c3fb0b2bbdb783256a2722dcf8aa15fe23dbd61b8ccd9700e9293e4b62) |
| `0x52AfBA24…e92f5d` | 8 | 2024-04-21 17:02:59 → 2024-04-21 17:10:47 | 30027.861638 USDC | 29955.871705 USDC | [0xeff2bd9e9b…](https://etherscan.io/tx/0xeff2bd9e9b1563ccb7321337d4ed79222fead47c984569fb82917cd79abd1af2) / [0x94eca0d747…](https://etherscan.io/tx/0x94eca0d747c091d55142f38d0c4b3718fe603b5a8f0a28fa342be094627eac4a) |
| `0x7737E76f…D6d122` | 4 | 2024-04-22 21:15:59 → 2024-04-22 21:17:35 | 29955.871705 USDC | 29919.949883 USDC | [0xe43fcb3a93…](https://etherscan.io/tx/0xe43fcb3a93b4361de66b173828c2c766731996932fbc968a3b0015d3075e8302) / [0xc6358bbcb4…](https://etherscan.io/tx/0xc6358bbcb41e7dba0bd2fa3a16c94a7e4441d8383983b520472f929ed976cb59) |
| `0x97592b48…FdEd47` | 2 | 2024-04-22 21:21:35 → 2024-04-22 21:23:23 | 29919.949883 USDC | 29902.00513 USDC | [0xb5a2a1ee71…](https://etherscan.io/tx/0xb5a2a1ee7131a0ca1e95f76ea1849f6b1e8c3053cd0e19689b6ec5cba6edaf65) / [0x3fc1f64fc1…](https://etherscan.io/tx/0x3fc1f64fc1d6413e2a4e60bb7bab65e91f9bc3590f59846ed6bbd64352ee8a38) |

| UTC transfer | From → recipient | Exact transferred quantity | Receipt |
|---|---|---|---|
| 2024-04-18T17:37:23Z | `0x68d3D886…5F7F2f` → `0x425e16a8…b46168` | 30445.154564 USDC | [0x1ec509dccc…](https://etherscan.io/tx/0x1ec509dccce7fabc3bfdc3a08e41eede99e88f658dff2c5374acf2fa8fd86bd9) |
| 2024-04-18T17:46:59Z | `0x425e16a8…b46168` → `0x4E958Cb8…51C65b` | 30390.407716 USDC | [0xe589e112e3…](https://etherscan.io/tx/0xe589e112e3c53aaad101dc19413a3947255059693cd9b10804a682d6ae247667) |
| 2024-04-20T18:04:11Z | `0x4E958Cb8…51C65b` → `0xcfC2F1b6…D7B455` | 30281.192454 USDC | [0xc8459c407b…](https://etherscan.io/tx/0xc8459c407bc059cd83b3f6803b0e004acb77897725cedcbd79ed4c3325d4eb85) |
| 2024-04-20T18:11:35Z | `0xcfC2F1b6…D7B455` → `0x9D383C16…87A97D` | 30207.867080991279108779 LUSD | [0xdfae4f391d…](https://etherscan.io/tx/0xdfae4f391d2451cf88237717943caaa0a73ac57c203e0258512f8ba1a73feb52) |
| 2024-04-20T18:24:23Z | `0x9D383C16…87A97D` → `0x9B0547b6…AfEbDA` | 30081.967794 USDC | [0x9a62b698de…](https://etherscan.io/tx/0x9a62b698ded21cb6da2caed7236a0d80f027e056a8ad5fefdf0ae5b2d20710b5) |
| 2024-04-20T18:31:11Z | `0x9B0547b6…AfEbDA` → `0x4E958Cb8…51C65b` | 30027.861638 USDC | [0x2c9d175764…](https://etherscan.io/tx/0x2c9d1757645af6da1900e65e89abe622e7acaaf67711b86ac6545d8b0a17c970) |
| 2024-04-21T17:01:11Z | `0x4E958Cb8…51C65b` → `0x52AfBA24…e92f5d` | 30027.861638 USDC | [0xd6faac5301…](https://etherscan.io/tx/0xd6faac5301d786c921ee2c5a1d6f93169cd8cfa3a89818335f8437dbfe05649d) |
| 2024-04-21T17:12:11Z | `0x52AfBA24…e92f5d` → `0x4E958Cb8…51C65b` | 29955.871705 USDC | [0xf03e7bdd78…](https://etherscan.io/tx/0xf03e7bdd78fc552f02031646af0f6fc203880ade4633c8b94d3e129988f0c3d5) |
| 2024-04-22T21:13:59Z | `0x4E958Cb8…51C65b` → `0x7737E76f…D6d122` | 29955.871705 USDC | [0x803cdae96e…](https://etherscan.io/tx/0x803cdae96e5f3a0d26ec9b3df8f9a601d3a6f983941e4530966fcd356eca0dbc) |
| 2024-04-22T21:20:11Z | `0x7737E76f…D6d122` → `0x97592b48…FdEd47` | 29919.949883 USDC | [0x23e2a53f64…](https://etherscan.io/tx/0x23e2a53f6463b52f9d7f7b253563d46d84f65fc7c6809a5454bdeaa3d43ef7ef) |

## Wider repeated-capital results

Across the 231 stablecoin swaps, the calculation finds **202 exact output-to-next-input links**: **184 within the same address and 18 through token transfers**. They form **24 maximal paths containing at least two swaps**, covering **226 swaps**. The longest is the 66-swap path above. Another path contains 32 swaps across three addresses on 12–14 April; 29,685.321565 USDC becomes 29,398.201973 USDC and produces 946,149.370125165889310389 nominal input units. These are deterministic amount-continuity findings, not a statistical classifier for criminal intent.

The full 231-swap nominal input sum is **8,435,475.413649440517362840 stablecoin units**. It includes reward conversions and routes whose platform attribution is unknown. It must not be divided by the campaign's reported $12.02 million to assert a proven manipulated-volume percentage. The five stablecoin swaps outside multi-swap paths include reward conversions and a 415.093407560649538203 LUSD conversion following an ETH-funded purchase.

The matching algorithm requires the next relevant outgoing action to consume the exact preceding output asset and quantity. A different quantity, intervening claim, bridge, or ETH swap breaks a path. Approvals and native-ETH sends are excluded from the stablecoin sequence because they do not move its principal. Multi-hop transfers are followed only when every hop preserves the exact asset and amount. No address-to-person inference is made. External incoming token transfers remain a coverage limitation; exact matched amounts do not prove exclusive wallet balances.

## Actual rewards and consolidation

| Distribution date | Verified claims | Actual LUSD receipts | Share of announced 10,000 LUSD epoch |
|---|---:|---:|---:|
| 2024-04-17 | 8 | 3968.390622853786468352 | 39.683906% |
| 2024-04-24 | 9 | 8285.027398394077806592 | 82.850274% |
| 2024-05-01 | 9 | 9691.360194245855019008 | 96.913602% |

The 26 actual receipts total **21,944.778215493719293952 LUSD**, or **73.1492607%** of the announced 30,000 LUSD campaign budget. All use distributor `0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B`. Weekly dates and the April 24 share match the published leaderboard; the original receipt alone has no campaign brand label. Retain the campaign/leaderboard sources when assigning these distributions to Kaskade.

**23 individual rewards were forwarded in exactly the amounts claimed**, converging at collectors; one additional collector transaction forwards the combined April 24 8,285.027398394077806592 LUSD total to an external address. These transfers support financial coordination beyond native-ETH funding links. All 65 stablecoin transfer receipts are decoded: 56 transfers stay within the nine-address group and nine leave it. Collector conversions are proceeds handling, not extra reward income.

On May 1 the hub converts 8,672.178100811423023104 LUSD and later 1,019.182093434431995904 LUSD. Their sum is exactly the nine wallets' 9,691.360194245855019008 LUSD claim total. Together the swaps return **9,677.173397 USDC**. The first claim-day collector's 5,585.449075373668532224 LUSD conversion exceeds the eight examined wallets' 3,968.390622853786468352 LUSD claims; its other incoming sources are not enumerated here. Do not attribute the excess to these nine wallets.

All claim gas totals **0.056352043156767145 ETH**. All 65 outgoing stablecoin-transfer fees total **0.045651376741191016 ETH**, including the separately tabulated reward-forward fees; do not count them twice. All 235 swap-like-call gas totals **0.560941811632096425 ETH**. ETH fees were not converted using the explorer's current dollar annotations. This is not a net-profit calculation.

## Published leaderboard mismatch retained

The partner's Week 2 image displays 65 transactions across these nine wallets. Our exact-principal path has 66 swaps. Eight wallets' per-wallet counts match the image; wallet425e executes six April18 swaps while the image displays five. A wider April17–23 calendar search finds another six early-April17 swaps and one reward conversion by425e. Epoch timing, routing attribution, exclusion rules and the screenshot's exact capture state are not reconstructed, so the mismatch does not itself establish erroneous or dishonest reporting. We do not force all on-chain swaps into the historical displayed65 count.

## Validation and reproducibility

All235 preserved swap-like pages contain the requested transaction hash; all are unique. Decimal arithmetic avoids floating-point rounding. The earlier nine-swap sample is retained within the 66-swap path. A separate reviewer independently recomputed the66swap/65link path and all ten connecting transfers, checking assets, exact amounts, sender/recipient direction, and block ordering. Coverage assertions compare all method-name candidates against decoded hashes.

Run from the evidence directory:

```sh
python3 decode_kaskade_history.py kaskade_history_expansion_receipts_full.json kaskade_history_expansion_decoded_full.json
python3 kaskade_decode_claims.py
python3 kaskade_decode_transfers.py
python3 calculate_kaskade_history.py
```

Primary data files: `kaskade_history_expansion_inventory_full.json`, `kaskade_history_expansion_receipts_full.json`, `kaskade_history_expansion_decoded_full.json`, `kaskade_history_expansion_calculations.json`, `kaskade_claims_expansion_raw.json`, `kaskade_claims_expansion_decoded.json`, `kaskade_all_stablecoin_transfers_raw.json`, and `kaskade_all_stablecoin_transfers_decoded.json`. Reproduction also requires `kaskade_claim_forward_raw.json` and `kaskade_principal_transfer_raw.json`; the transfer parser combines those raw source parts. Claim/transfer details are also in `KASKADE_CLAIMS_EXPANSION_NOTES.md`. Independent QA is in `KASKADE_HISTORY_INDEPENDENT_QA.md` and `kaskade_chain_independent_qa.json`.

The successful ordinary public browser reads required no account, wallet, signature, private API, challenge solving, or human identity mapping. Occasional browser-internal timeouts were recovered without changing network paths. Current explorer exchange-rate annotations were excluded. The investigation substantiates observable capital recycling and reward concentration; the main report must separately evaluate promotion claims, project operators, Laura's role dates and applicable law.
