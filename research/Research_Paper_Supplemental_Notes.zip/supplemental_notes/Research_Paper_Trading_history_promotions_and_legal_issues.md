# Research Paper — Trading history, promotions and legal issues

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

**Kaskade · MegaFans/MBUCKS · GamiFi/GMI**  
Research cutoff: 5 September 2026 UTC. This expands the earlier transaction and company reviews. It covers public evidence; it is not a finding of criminal liability or a complete record of every venue.

**The strongest finding is coordinated capital recycling in Kaskade's examined wallet group.** A reconstructed path contains 66 swaps across nine wallets, starting with a 30,500 USDC input and ending with a 29,902.00513 USDC output. It produces approximately $1.994 million of gross turnover if USDC and LUSD are each valued at $1. Separately, 26 verified distributions to those wallets total 21,944.778215493719293952 LUSD. Two additional claims from outside wallets, also forwarded to a collector, bring the explicitly combined reward trace to **23,561.836668013601357824 LUSD across 11 addresses: 78.539456% of the announced budget**. This does not expand the nine-wallet trading reconstruction or identify human owners.

The most concrete legal inquiry is whether actual, rewarded turnover was used to convey a materially misleading impression of independent demand. A statutory wash-trading or fraud finding needs additional evidence. No comparable repeating trading sequence was established for MBUCKS or GMI.

| Company / campaign | Historical coverage achieved | Finding and limit |
|---|---|---|
| Kaskade / Liquity | Nine normal-transaction inventories; 421 distinct hashes; 326 selected receipts plus five targeted follow-up receipts, April–May 2024 | Extensive exact amount continuity, inter-wallet transfers and concentrated rewards. Complete coverage of selected methods in these inventories, not every incoming token transfer or campaign participant. |
| Kaskade / Redacted | Exact WETH/BTRFLY V2 pool identity verified; issuer campaign aggregates reviewed | No March–April campaign swap tape reconstructed. Company-reported volume remains unverified at transaction level. |
| MegaFans / MBUCKS | Three purposively located swaps; fixed-block checks of 20 pool combinations and five staking addresses | Specific promotional and calculation issues. Insufficient history to measure wash trading or promotion-related returns. |
| GamiFi / GMI | Two swaps, two separately classified token payments, pool-state checks; 39 podcast descriptions and dated launch/promotional records | Direct Laura promotion established; repeated yield marketing documented. No complete DEX or MEXC trading series. |

## 1. Laura's connection: affiliations and acts must be dated separately

| Project | Supported connection | Attribution boundary |
|---|---|---|
| Kaskade | Her professional profile reports CMO/founding-team work from November 2023 through March 2024. A [8 March 2024 interview](https://www.moneyneversleeps.ie/farcaster-digital-identity-decentralized-social-media/) contemporaneously identifies her role. | The exact departure day is unknown. The Redacted campaign began in March; the reconstructed Liquity activity is in April–May. No reviewed record identifies her as a wallet controller, trading instructor or author of later company articles. |
| MegaFans | Her [professional profile](https://ca.linkedin.com/in/lauralwalsh) reports an advisory and early seed-investor association beginning May 2022. | This remains a self-reported association, not independently verified executive control, trade authorization or authorship of the promotions reviewed here. An open-ended profile entry does not establish current activity. |
| GamiFi | The [23 February 2022 MEXC AMA](https://blog.mexc.com/mexc-ama-gamefi-session-with-laura-and-casey/) directly attributes token-acquisition and staking promotion to Laura. The [1 September 2022 succession announcement](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147) names a new CEO. | Personal promotional involvement is established. Trading-wallet ownership and instructions are not. Successor-period retention campaigns require separate attribution. |

No verified public connection between Laura, these projects and Gotbit was established. Gotbit is an enforcement comparison in section 5, not an affiliation finding.

## 2. Kaskade: expanded transaction reconstruction

### A. The 66-swap path

The path runs from **18 April 2024, 17:32:47 UTC**, through **22 April, 21:23:23 UTC**. Each successive swap consumes the exact preceding output asset and quantity, either within one address or after documented transfers. Eight changes of trading wallet require ten transfer receipts because two transfers relay through an earlier hub.

| Trading order | Wallet prefix | Swaps | Input to this segment | Output from this segment |
|---|---|---:|---:|---:|
| 1 | `0x68d3D886` | 6 | 30,500 USDC | 30,445.154564 USDC |
| 2 | `0x425e16a8` | 6 | 30,445.154564 USDC | 30,390.407716 USDC |
| 3 | `0x4E958Cb8` | 12 | 30,390.407716 USDC | 30,281.192454 USDC |
| 4 | `0xcfC2F1b6` | 9 | 30,281.192454 USDC | 30,207.867080991279108779 LUSD |
| 5 | `0x9D383C16` | 13 | 30,207.867080991279108779 LUSD | 30,081.967794 USDC |
| 6 | `0x9B0547b6` | 6 | 30,081.967794 USDC | 30,027.861638 USDC |
| 7 | `0x52AfBA24` | 8 | 30,027.861638 USDC | 29,955.871705 USDC |
| 8 | `0x7737E76f` | 4 | 29,955.871705 USDC | 29,919.949883 USDC |
| 9 | `0x97592b48` | 2 | 29,919.949883 USDC | 29,902.00513 USDC |

Primary anchors: [first swap](https://etherscan.io/tx/0xbb69337c999f054cf88427b031e4a9e84a9977854f75d6608f07076609da2ebc), [first inter-wallet handoff](https://etherscan.io/tx/0x1ec509dccce7fabc3bfdc3a08e41eede99e88f658dff2c5374acf2fa8fd86bd9), [LUSD handoff after the original nine-swap example](https://etherscan.io/tx/0xdfae4f391d2451cf88237717943caaa0a73ac57c203e0258512f8ba1a73feb52), and [final swap](https://etherscan.io/tx/0x3fc1f64fc1d6413e2a4e60bb7bab65e91f9bc3590f59846ed6bbd64352ee8a38). The evidence bundle contains every constituent receipt, full addresses and the ten handoffs.

Own arithmetic:

- Sum of swap inputs: **1,993,826.456664144632875365 nominal stablecoin units**.
- Turnover divided by the initial input: **65.371359 times**, under the equal-$1 assumption.
- Difference between the USDC endpoints: **597.99487 USDC**, before gas.
- Swap gas: **0.166844023287208029 ETH**; ten connecting transfers: **0.006298926931151368 ETH**. These exclude other approvals, claims and funding actions.

This is strong evidence of repeated capital reuse and financial coordination. The swaps really executed against liquidity pools. Gross turnover is not new capital, business revenue or profit. Exact asset-and-amount continuity does not uniquely identify fungible token units or prove exclusive wallet balances; externally initiated incoming token history remains incomplete. The records also do not establish who controlled the AMM liquidity or that both sides of a statutory self-trade had the same beneficial owner.

### B. Broader coverage and actual reward concentration

The nine normal-history lists contain **480 displayed rows, representing 421 distinct transactions** after duplicates are removed. All visible dates fall between 11 April and 1 May 2024. The 326 decoded receipts comprise disjoint categories:

- **235 swap-like calls:** 231 USDC/LUSD swaps, three ETH-related swaps and one bridge.
- **26 claims.**
- **65 outgoing USDC/LUSD transfers:** 56 within the group and nine to outside addresses.

Across the 231 stablecoin swaps, deterministic matching finds 202 exact continuity links, forming 24 paths of at least two swaps and covering 226 swaps. Their full input total is **8,435,475.413649440517362840 nominal stablecoin units**. This includes reward conversions and routes whose Kaskade attribution is unknown. **It cannot be labelled entirely artificial or divided by the company's reported $12.02 million to produce a verified manipulation percentage.**

| Distribution day | Claim receipts | Actual LUSD received | Relative to announced 10,000-LUSD weekly budget |
|---|---:|---:|---:|
| 17 April 2024 | 8 | 3,968.390622853786468352 | 39.683906% |
| 24 April 2024 | 9 | 8,285.027398394077806592 | 82.850274% |
| 1 May 2024 | 9 | 9,691.360194245855019008 | 96.913602% |
| **Total** | **26** | **21,944.778215493719293952** | **73.149261% of 30,000 LUSD** |

All payouts came from [distributor `0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B`](https://etherscan.io/address/0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B). **Twenty-three individual reward transfers exactly equal the preceding claims** and converge at collector wallets. The distributor receipts do not carry a Kaskade brand label; weekly timing and the April 24 share's agreement with the published leaderboard corroborate campaign attribution. The denominator is the announced trader budget, not an independently reconstructed total paid to every participant. The separate 20,000-LUSD liquidity-provider incentive must not be added to trader rewards.

On May 1, two collector swaps consume precisely the group's 9,691.360194245855019008 LUSD rewards and return **9,677.173397 USDC**: [first conversion](https://etherscan.io/tx/0x184d34d6f7f4d76a6713178ddcd2a403fe6ddc38867a3bb2141e4adbe23c2019), [second conversion](https://etherscan.io/tx/0x3b8fc6f31ea2060012beb802a086a2efd232f7d833ce75a626ad5eae0a6f9e12). Collector transfers and conversions are proceeds handling, not additional reward income.

**A targeted incoming-transfer check resolved two apparent discrepancies.** On April 17, [807.403300464772513792 LUSD](https://etherscan.io/tx/0x601d0155d8edfcf11b7483b1035a4907001c1f9ba597c552a4e73dee2043e37f) and [809.65515205510955008 LUSD](https://etherscan.io/tx/0x5fdffda80dea1aff83585a26a5c9cfdbb69183162738b2166960fb255d30c54a) arrived from two wallets outside the original sample. Their sum exactly explains the collector conversion's excess over the selected eight rewards. On April 24, the outward payout [returned at 16:57:23 UTC](https://etherscan.io/tx/0xe537e084ff562ffe638015c9a1af38f5d911a9f914068b36a839cbfbfc5fee3a), 48 seconds before conversion. The resulting 8,280.806398 USDC was then forwarded to the same outside wallet. These three added receipts are separate from the original 326. Count the reward income once. Complete incoming histories, ultimate beneficiaries and overall net profit remain outside the verified coverage.

The two outside senders' immediately preceding claims were then verified: [first claim](https://etherscan.io/tx/0xe75a96480f9aa16c11951ac4b638535e5359c54eeaf14c95d6b7b3ffdda5d796), [second claim](https://etherscan.io/tx/0x0173429cbf2317bd73221846d0e2f5e4f2de5a3ab17041aa0e7791b58012dedd). Both received those exact amounts from the same distributor and forwarded them 60 and 36 seconds later. Thus the combined observed reward trace is **28 claims, 11 claimant addresses and 23,561.836668013601357824 LUSD**. This equals **78.539456% of the announced 30,000-LUSD budget**. Their earlier trades and eligibility were not reconstructed. The original nine-wallet table remains unchanged; combined receipt coverage is now **331 distinct transactions**.

The historical Week 2 leaderboard displays 65 transactions for the nine wallets; the exact path contains 66. Eight wallet counts agree, but `425e` has six April 18 swaps against five displayed. Epoch boundaries, routing eligibility and capture timing remain unresolved. This discrepancy is preserved rather than forcing the chain data to match the screenshot. The earlier **84.3%** calculation concerns only volume in the displayed **top ten**; it is not the campaign-wide share or reward percentage.

### C. Promotions, risk awareness and surviving weaknesses

| Date | Primary publication | Assessment |
|---|---|---|
| 10 April 2024 | [DeFi Collective launch](https://deficollective.org/blog/kaskade-campaign-launch/) | Publicly announces trader incentives, including arbitrage opportunities. This is counterevidence to treating every reward-seeking trade as concealed or prohibited. |
| 2 May 2024 | [Partner campaign report](https://deficollective.org/blog/kaskade-campaign-report/) | Criticizes farming and infers one operator behind nine wallets. Our receipts strengthen financial coordination, but do not independently identify that operator. The report says Kaskade reviewed its draft. |
| 17 May 2024 | [Cold-start article](https://medium.com/@KaskadeFinance/overcoming-the-cold-start-problem-with-kaskade-22f8c3ba440e) | Promotes demand-side incentives while criticizing transient liquidity. No independently measured post-incentive retention series was recovered. |
| 27 May 2024 | [Kaskade/Liquity retrospective](https://medium.com/@KaskadeFinance/kaskade-x-liquity-campaign-analysis-a0f0d48ee97f) | Reports $12.02m volume, 47 traders, $5,601 LP fees and $642,561 net LP inflows; acknowledges farmers. The article is the issuer's account, not an independent audit. |
| 10 July 2024 | [Demand or supply article](https://medium.com/@KaskadeFinance/demand-or-supply-which-comes-first-654d6f0c5fec) | Promotes incentives and habit formation. Increased turnover alone cannot validate retained, independent demand. |
| 31 July 2024 | [Airdrop article](https://medium.com/@KaskadeFinance/rethinking-airdrops-regular-issuance-events-69c9353fe364) | Explicitly recognizes that farming can distort apparent participation, while proposing its own points model as a remedy. This demonstrates corporate publication-level awareness of the risk, not Laura's knowledge or admission that specific figures were fabricated. |
| 14 August 2024 | [DeFi efficiency article](https://medium.com/@KaskadeFinance/making-defi-efficient-5ace876e7c20) | Promotes volume and retention over TVL. The unresolved measurement issue is whether retention was actually demonstrated after incentives ended. |

Using the retrospective's own figures, $5,601 LP fees recover **18.67%** of a $30,000 trader incentive budget. The $24,399 difference is not automatically a company loss: payer, beneficiary, liquidity effects and campaign purpose differ. The reported 47 traders do not independently establish 47 people.

Archived March 18 and May 6 homepages were recovered, along with a May 22 app shell and October homepage shell. They did not supply historical scoring rules or a branded distributor mapping. Three manifest-linked campaign/claim script captures were unavailable. Missing captures do not establish missing policies. Exact archive URLs, capture times and retrieval hashes are preserved; client code was not executed.

A social-media lead describing a Sushi campaign was explicitly framed as an imagined example in the [indexed original/reposted text](https://sg.linkedin.com/in/leonard-kwek-ys). It is excluded as evidence of an executed campaign. This prevents an illustrative $30,000 campaign from becoming a false transaction-history entry.

### D. Redacted campaign: earlier period, weaker transaction coverage

Kaskade's [26 April analysis](https://medium.com/@KaskadeFinance/kaskade-x-redacted-campaign-analysis-f169098f970f) describes a March 18–April 7 campaign with 72 BTRFLY in trader incentives, approximately $3.2m volume and $32,000 fees. It attributes 45% of trades and 26% of volume to 191 of 1,380 traders. On those reported aggregates, the subgroup is 13.84% of traders and trades about 5.09 times as frequently as the remainder, with about 42.94% of their average trade size. This suggests an incentive-response question; it does not prove wash trading.

The verified Uniswap V3 WETH/BTRFLY V2 1% pool is [`0x3e6e23198679419cd73bb6376518dcc5168c8260`](https://etherscan.io/address/0x3e6e23198679419cd73bb6376518dcc5168c8260), supported by its [creation event](https://etherscan.io/tx/0x6d666d1fd4e502da1704748dbaa687d8a85e47943c9452601d0436b9bd2a881b#eventlog). Campaign attribution is inferred from the matching pair and fee tier. **Zero campaign-period swaps were reconstructed.** A later May sample verifies pool activity only and is excluded from campaign conclusions. This March launch may overlap Laura's month-only reported tenure; it does not establish her responsibility for campaign design.

## 3. MegaFans/MBUCKS: promotional claims outrun verified execution records

Exact BSC token: `0x3638fea0c645b1aa79db706fab6e8a761385c390`. Verified pool: `0x5282c0ea15348dfa64a8a2690e0cb770e56a72dc`.

At BSC block **120150826**, 5 September 2026 at 17:30:16 UTC, twenty factory checks covered PancakeSwap V2/V3 against WBNB, USDT, USDC and BUSD, with four V3 fee tiers. Only the known V2 WBNB pair returned a pool. A V3 positive control succeeded. This narrows those specific combinations; it does not exhaust all exchanges, assets, chains or migrations.

The decoded history still consists of **three selected swaps**, dated July 29 and November 15, 2024, and August 20, 2026. One also contains a liquidity burn. The August transaction swaps 2,432 MBUCKS; adding its several token transfers produces 5,120, illustrating why Transfer events cannot be treated as volume. **No evidence shows MegaFans used that erroneous counting method.** Historical candle requests failed, so there is no defensible wash-volume percentage or promotion-event return calculation.

| Promotion / disclosure | Verified issue or useful counterevidence |
|---|---|
| [November 2021 Launchpool AMA](https://launchpoollabs.medium.com/launchpool-ama-recap-megafans-d826664eda5c) and subsequent game/prize promotions | Establish marketing of crypto-linked participation, not an executed MBUCKS volume total. NFT, PEPE and game rewards are distinct from token trades. |
| [29 May 2024 company-issued announcement](https://www.prnewswire.com/news-releases/megafans-launches-and-lists-token-mbucks-on-binance-smart-chain-302158231.html) | Mixes launch/listing language with upcoming June exchange availability. Deployment on BSC does not establish a Binance spot listing. A matched official MEXC listing notice was not recovered. |
| [Spores offering page](https://launchpad.spores.app/ido/megafans-ido) | Displays June 24–26 sale dates, June 27 listing, $0.14 price and a filled $150,000 target. These are UI assertions, not settlement or vesting receipts. |
| [Company staking page](https://www.megafans.io/staking/index.html) | Headline advertises up to 150% APY and describes guaranteed returns; individual token pools use 60%, 100% and 150% APR over 45, 90 and 180 days. Five linked staking addresses contain deployed code. Actual accrual, compounding, funding and payouts remain unverified. |
| [Republic offering](https://republic.com/megafans) | Advertises 45% of net profits for buybacks/rewards and possible burns. No completed buyback ledger was verified. The same page discloses dilution/price risk and reports withdrawal/refunds; those qualifications must remain in the assessment. |

**A new arithmetic-basis problem:** Spores displays 4,001,500 initially circulating tokens and a $259,910 initial market cap. At $0.14, multiplication gives **$560,210**. The printed cap instead implies **1,856,500 tokens**. An excluded allocation category could explain the denominator; unavailable tokenomics images prevent resolving it. This is an unexplained basis difference, not proof of deliberate deception.

**The earlier deck issue remains separate from trading volume.** The previously inspected 2025 deck (MegaFans forecast deck; source title retained), PDF pages 6, 15 and 18, displays Year 3 revenue of $15m, costs of $13m and income of $4m. Straight subtraction gives **$2m**. Its displayed cash rows also fail ordinary opening-cash-minus-outflows-plus-inflows reconciliation. These were previously checked projection defects; they do not establish falsified realized profits, exchange trading or Laura's authorship. A corrected model and explanations of all omitted cash lines are the evidentiary next step.

The staking page's APR/APY terminology requires clarification, but the difference alone does not prove an overstated payout. A promised token yield is not a guaranteed dollar gain. Page copyright year and active-looking buttons do not establish current deposits or solvency.

## 4. GamiFi/GMI: direct promotion and repeated return marketing

Exact BSC token: `0x93d8d25e3c9a847a5da79f79ecac89461feca846`. Verified pool: `0x58d4b61983ca0afe6e352e90719f403e24e016f4`.

The [17 January 2022 launch notice](https://gamifi-launchpad.medium.com/fair-launch-notice-a842e1bf320c?responsesOpen=true) planned PancakeSwap trading for January 18 and disclosed anti-bot blacklisting/freezing powers. This warrants checking actual deployment and use, but contradicts a blanket claim that no restriction was disclosed. It does not establish a honeypot or arbitrary confiscation.

MEXC's [January 23 Kickstarter terms](https://www.mexc.com/announcements/article/initial-listing-mexc-kickstarter-vote-to-win-free-1-000-000-gamifi-gg-gmi-airdrops-4415532646041) offered one million GMI for voting with temporarily locked MX. Its [January 24 result](https://www.mexc.com/announcements/article/voting-result-and-listing-arrangement-for-gamifi-gg-gmi-4415635423001) scheduled January 25 GMI/USDT trading. Voting totals were not GMI purchases, new capital or trading volume.

The **February 23 MEXC AMA** directly attributes to Laura directions to acquire GMI on PancakeSwap/MEXC and descriptions of staking and whitelist access. She characterizes it as “pure utility” and claims a PeckShield token-contract audit. A matching audit report/version/address remains unverified. She also expressly qualifies planned launches for market conditions. These statements establish named promotion, not a proven falsehood or direction of trades. [Primary indexed transcript](https://blog.mexc.com/mexc-ama-gamefi-session-with-laura-and-casey/).

The [official podcast feed](https://feeds.captivate.fm/gamifi/) contains 39 recovered episodes. **Eighteen descriptions advertise up to 225% APY**, with publication metadata spanning February 8–April 7, 2022; 22 mention MEXC and 26 PancakeSwap. These are company-written descriptions, not verified spoken endorsements by every guest or immutable historical copies. Factual episode flags and count checks are included in the evidence bundle.

The [May 4 staking announcement](https://gamifi-launchpad.medium.com/new-staking-pool-open-50dd1e1eb064) describes a 30-day NFT-holder pool at 225% APY, alongside other pools, caps and a risk warning. Annualized yield is not a 225% gain over 30 days. Actual reward formulas, reserves and paid returns remain unresolved.

Two further promotional threads now have precise targets:

- The [July 2 Mystery Box article](https://medium.com/@gamifi-launchpad/gamifi-mystery-box-nfts-2840e0eb885e), recovered in indexed excerpts, describes 25,000 GMI from the buyer plus a company match, with 50,000 GMI going to a burn address. [July 1 podcast notes](https://www.rageworksnetwork.com/show/gamifi-everything-beyond-the-metaverse/33-a-conversation-with-gamifis-laura-walsh-and-casey-mcquillan/) associate Laura and Casey with a forthcoming burn initiative. No mint/match/burn ledger was verified; show notes do not attribute each mechanic to Laura's spoken words.
- Later [official Telegram context](https://t.me/s/GamiFiAnnouncements/813) includes Casey's six-month restaking offer at 40% APR, a 21-day deadline and accelerated old-pool rewards. Its example **2.5m × 40% × half a year = 500,000 GMI** reconciles. The exact post date, deployed pool and payouts remain unverified. The same channel contains an explicit FOMO distribution announcement, improving the earlier coverage to a company-reported outcome. It is not independently reconciled settlement, but it prevents describing distribution as wholly unreported.

The available chain sample remains two small actual sales in April and August 2026, plus two 2022 token payments without Swap events. MEXC history requests timed out; no consecutive account history was obtained. There is no defensible measured GMI wash-trading rate, promotion-related price impact or complete investor-return series. A restaking offer alone does not establish a Ponzi scheme.

## 5. Criminal trading patterns and applicable law

**The conduct and the legal elements must be matched separately.** The table uses Canadian federal and Quebec provisions because those are the jurisdictional questions under review; application still requires the relevant Canadian/Quebec connection and instrument classification.

| Pattern / provision | Connection to the record | Evidence still needed |
|---|---|---|
| **Misleading trading appearance — Criminal Code s. 382** | Repeated reversals justify testing whether activity was intended to simulate market interest. The provision concerns a security and specified unchanged-beneficial-ownership or knowing matched-order conduct. [Historical text](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-382-20190919.html) | Security classification under this provision; beneficial ownership or qualifying matched orders; deceptive intent; jurisdiction. Shared control of trader wallets would not alone establish shared control of the actual AMM counterparties. |
| **Fraud — Criminal Code s. 380(1)** | Potentially relevant to dishonest reward eligibility or misleading claims that induce economic exposure. [Historical text](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-380-20111101.html) | Dishonest means, deprivation or economic risk, causation and required knowledge. Reward receipt alone does not show fraud; contemporaneous rules and representations are essential. |
| **Fraudulent public-price effect — s. 380(2)** | Addresses fraudulent means affecting public market prices with intent to defraud; its subject matter extends beyond securities. [Same official section](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-380-20111101.html) | Actual fraudulent price effect and intent. Stablecoin turnover and a large nominal total do not establish pumping or a coordinated dump. |
| **Criminal misleading promotion — Competition Act s. 52** | Particularly relevant if incentives, adoption, returns or projections were knowingly/recklessly presented in a materially misleading way. Literal wording and overall impression matter. [2024 text](https://laws-lois.justice.gc.ca/eng/acts/c-34/section-52-20220623.html) | Exact public claim, context and materiality; why misleading; maker or person permitting it; knowledge/recklessness; jurisdiction. Correctly contextualized gross turnover is not inherently false. |
| **Civil misleading promotion — Competition Act s. 74.01** | A separate reviewable-conduct route for material misrepresentations; specified performance claims also raise adequate-testing questions. [2024 text](https://laws-lois.justice.gc.ca/eng/acts/C-34/section-74.01-20220623.html) | Complete representation and applicable legal test. This route must not be described as a criminal conviction or as requiring s. 52's identical mental element. |
| **Quebec Securities Act s. 199.1** | Addresses participation in transactions/practices known, or reasonably knowable, to create misleading securities activity/artificial prices or fraud. The series of transactions deserves scrutiny. [Official Act](https://www.legisquebec.gouv.qc.ca/en/document/cs/v-1.1) | Covered instrument and Quebec connection; misleading effect and statutory fault. These are provincial securities penal provisions, distinct from federal criminal offences. |

Related Quebec provisions include **195.2** for improper/fraudulent price or value influence, **196–197** for specified misrepresentations, **205** for officer/employee authorization or permission, and **208** for assistance, inducement or orders. Their application depends on the particular act and responsible person. A blog is not automatically a statutory offering document, and a job title does not prove authorization. [Official Act](https://www.legisquebec.gouv.qc.ca/en/document/cs/v-1.1).

For fraud, [*R. v. Théroux*](https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/992/index.do) recognizes economic prejudice or its risk and the required subjective knowledge. Poor execution, arithmetic defects or disappointing returns alone do not establish these elements. [*Libman*](https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/79/index.do) requires a real and substantial Canadian connection to the offence. [*Sharp*, 2023 SCC 29](https://www.scc-csc.ca/judgments-jugements/cb/2023/39920/) illustrates Quebec regulatory jurisdiction over sufficiently connected out-of-province conduct; it is not a criminal-liability finding about these projects.

GMI's utility description does not settle classification: [CSA Staff Notice 46-308](https://www.osc.ca/en/securities-law/instruments-rules-policies/4/46-308/csa-staff-notice-46-308-securities-law-implications-offerings-tokens), published before the 2022 promotion, explains that utility functions do not necessarily prevent securities treatment. Nor does [CSA stablecoin guidance](https://www.securities-administrators.ca/news/canadian-securities-regulators-clarify-interim-approach-to-value-referenced-crypto-asset/) automatically classify every LUSD/USDC transaction under every statute.

**Comparators with verified outcomes:** The AMF's [Luc Desjardins case](https://lautorite.qc.ca/en/general-public/media-centre/news/fiche-dactualites/22450-fine-for-securities-manipulation-1) reports a February 2015 guilty plea and $22,450 fine for securities manipulation. Investigators established his control of both trading accounts. That missing ownership evidence is a useful distinction here; the case has no established link to Laura.

DOJ's [June 2025 Gotbit sentencing release](https://www.justice.gov/usao-ma/pr/cryptocurrency-financial-services-firm-gotbit-and-founder-sentenced-market-manipulation) describes admissions, paid client services and tactics intended to manufacture volume and avoid detection. Those facts cannot be imported into Kaskade. The separate [3 August 2026 SEC release](https://www.sec.gov/enforcement-litigation/litigation-releases/lr-26598) describes a proposed civil settlement awaiting approval as of that release and dismissed claims against Fedor Kedrov. No later approval was verified; this is not a full live-docket certification. United States outcomes are comparators, not Canadian precedents or proof of affiliation.

Historical checks used Criminal Code versions covering 2022/2024 and Competition Act versions covering [February 2022, s. 52](https://laws-lois.justice.gc.ca/eng/acts/c-34/section-52-20150309.html), [February 2022, s. 74.01](https://laws-lois.justice.gc.ca/eng/acts/C-34/section-74.01-20090312.html), and the April–May 2024 period linked above. Quebec's relevant amendment annotations predate the conduct; a date-specific consolidation could not be retrieved. Full Théroux/Libman pages were access-limited and their stated principles checked through official indexed passages; the Sharp overview is a court staff summary. This is issue mapping, not a complete case-law citator or token-classification opinion.

## 6. Validation, unresolved threads and evidence package

The Kaskade calculations use exact decimal amounts, receipt hashes, token identities and explicit UTC timestamps. Coverage was compared with all nine inventories. Independent review checked the 66 swaps, 65 continuity links, ten transfers, direction and ordering. It caught a counter that initially omitted one ETH-output swap; the final count is corrected to three ETH-related swaps. Transfer, claim, bridge and swap categories are kept separate. Current explorer dollar annotations were excluded from historical accounting. The legal section separately passed an independent review for statutory requirements, historical versions and personal-attribution limits.

MBUCKS factory checks and staking-code existence are reproducible at fixed blocks. GMI promotional counts and arithmetic are reproduced from factual flags extracted from the official feed; the source hash is recorded. These checks validate the stated data and calculations. They do not backtest an investment strategy or establish profitability, intent or unobserved conduct. Missing data prevents meaningful promotion-event return studies for MBUCKS/GMI.

The records most likely to resolve the remaining issues are:

1. **Historical campaign rules and scoring versions:** epoch boundaries, eligible routes, wallet/person restrictions, prohibited cycling and exclusions. These determine whether rewards were earned within the rules or dishonestly obtained.
2. **Complete execution and incentive records:** all relevant pool events, externally initiated token flows, reward entitlements, distributor funding and settlement. CEX matching-account records are a separate dataset.
3. **Promotion provenance and measurements:** original/edited posts and decks, metric definitions, post-incentive retention, intended audiences and approval histories. These connect an impression to its evidence and responsible person.
4. **Trading mandates:** market-maker agreements, invoices, target-volume requirements and communications. None linking the observed wallets to Laura or Gotbit was obtained.
5. **MegaFans accounting:** corrected deck, cash-flow bridge, initial-circulation denominator, net-profit calculation and actual buyback/burn/staking transactions.
6. **GamiFi fulfillment:** the claimed audit report, deployed pool parameters, reward funding, Mystery Box company matches/burns and dated MEXC decisions.
7. **Individual responsibility and jurisdiction:** authenticated role dates, actual approval/signing authority, relevant solicitation and economic exposure. Public token transfers are investigative leads, not personal identification.

The companion evidence ZIP contains factual source extracts, raw public chain responses, receipt text, exact decoded quantities, deterministic calculation scripts, archive retrieval logs and a SHA-256 manifest. Full promotional articles, podcast descriptions and archived application bundles are excluded. No outside messages, wallet connections, signatures or trades were made.

**Assessment at this cutoff:** Kaskade's examined group shows extensive repeated turnover and concentrated rewards; its measurement and promotion require explanation. MegaFans and GamiFi have specific, documented promotional or reconciliation questions. The public record does not establish a criminal offence, Laura's trading control, or a Gotbit connection for any of them.
