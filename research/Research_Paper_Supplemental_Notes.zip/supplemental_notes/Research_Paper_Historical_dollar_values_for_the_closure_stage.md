# Research Paper — Historical dollar values for the closure stage

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

The final private-wallet input contains 148 nonzero financial transfer legs across 91 unique financial transactions, derived from the separate 100-nonce history audit. Its valuation is in `final_private_valued.json`. Earlier 125-row and 130-row snapshots remain as checkpoints; the final file supersedes them for coverage. This pricing lane values the supplied records rather than independently establishing that every wallet interaction is complete.

## Three newly recovered private claims

| UTC date and time | GMI claimed | Historical USD mark | Historical CAD mark |
|---|---:|---:|---:|
| 2022-11-04 14:25:40 | 96,645,563.271604938271604938 | $21,061.17 | $28,468.38 |
| 2022-12-06 10:46:01 | 10,615,821.759259259259259259 | $756.09 | $1,031.99 |
| 2022-12-08 06:32:39 | 608,016.975308641975308642 | $59.66 | $81.03 |
| Total | 107,869,402.006172839506172839 | $21,876.92 | $29,581.40 |

The first claim's pool ratio was 8,135 seconds old, with a BNB/USD oracle answer 9 seconds old. The other two pool ratios were 2,158 and 293 seconds old, with oracle answers 3 seconds old. These marginal token marks do not represent cash proceeds or an executable quotation for selling an entire claim.

Including the previously examined December 14 and January 20 claims gives five claims totaling exactly 120,000,000 GMI. The sum of their individual claim-time marks is US$22,859.76 / C$30,902.87. This is separate from both the January 2022 funding-time mark and actual sale proceeds.

## Actual sale receipts in the combined supplied ledger

| Received asset | Exact received quantity | USD conversion | CAD conversion |
|---|---:|---:|---:|
| BNB | 12.733084792018608967 | $3,993.65 | $5,359.27 |
| WBNB | 2.296091425541797281 | $820.80 | $1,109.48 |
| BUSD | 5,361.649777056501864007 | $5,362.44 | $7,219.59 |
| CAKE | 13.065639141470576526 | $49.50 | $67.13 |
| Gross conversion value of 42 sale outputs | — | $10,226.39 | $13,755.46 |

Each output uses its transaction's historical price and dated FX rate. WBNB is retained as WBNB; a dollar conversion does not turn wrapped tokens into a proved native-BNB withdrawal. Gross receipts do not establish profit, ownership, bank cash, or customer identity. Liquidity deposits, LP-token receipts, LP redemptions, and forwarding legs are separate categories and are excluded from the sale-proceeds total.

The final audit separately identifies a later conversion of the 13.065639141470576526 CAKE into 49.354088681602483584 BUSD, and an unwrap of the 2.296091425541797281 WBNB into the same number of BNB. Both are conversions of previously received assets; neither is added again to the 42-sale gross total. The CAKE conversion output marks to US$49.35 / C$66.92. Three liquidity-add refunds of one wei each retain their exact positive quantities and calculated values, although money display rounds them to $0.00.

Four supplied exchange-hop transfers total 18,000,000 GMI. Their individual transaction-time marginal marks sum to US$2,153.25 / C$2,906.98. These marks do not prove an exchange credited or sold that quantity for those dollars.

## Launchpool coverage crossing

The January 24, 2023 15:45:16 UTC claim for 8,309.56763892731 GMI marks to US$0.746603669 / C$0.998209105, displayed as US$0.75 / C$1.00. The GMI unit mark was $0.00008984867823002007; its pool ratio was 13,519 seconds old and its BNB/USD answer 6 seconds old. Whether this transaction was the earliest applicable coverage crossing is determined by the separate history analysis, not by its price calculation.

## Checks and files

- `final_private_valued.json`: final 148-row material private ledger; all USD/CAD values present and final QA passed.
- `final_private_category_totals.json`: final category and asset totals without an across-hop grand total.
- `private_combined_valued.json`: earlier deduplicated 125-row checkpoint.
- `private_new_claims_valued.json`: the three newly recovered claims.
- `launchpool_crossing_valued.json`: the coverage-crossing claim.
- `valuation_inputs.json`: reused and newly retrieved historical price marks, including CAKE and five LP marks.
- `final_private_QA.json`: final arithmetic, timestamps, historical-block convention, duplicates, LP NAV checks and source/valuation SHA-256 values.
- `PRICE_METHOD.md`: limitations, methodology and primary sources.

Earlier `gamifi_valuation` files are unchanged. The large-batch provider rate-limit response is retained as a failed attempt; successful quotations come from the later small batches and historical Multicall responses. Placeholder quote-prefetch input quantities are not transaction quantities and are excluded from the combined ledger.
