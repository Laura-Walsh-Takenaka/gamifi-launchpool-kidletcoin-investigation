# Research Paper — Kaskade: additional public transaction reconstruction

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Research/access date: 5 September 2026. Historical events: April–May 2024. Temporary research notes for the combined review, supplementing rather than repeating the company report.

## Result

**Confirmed:** the published example extends to nine consecutive swaps by the same address, with the output of every swap becoming the exact input of the next. The first eight transactions complete four USDC→LUSD→USDC round trips. The address also received three LUSD distributions across 17 April–1 May, totaling **2,470.816261629075259392 LUSD**, and forwarded each distribution's entire token amount within 24–72 seconds.

These are stronger observations than a general incentive-design concern. They demonstrate rapid, repetitive turnover of the same capital and actual distributions to that address. They do not identify a human owner, establish that all linked addresses share one controller, or prove an offense. Swaps were executed against pools through a router: the record does not establish literal exchange self-matching.

## Address key and scope

| Key | Ethereum mainnet address |
|---|---|
| A, reconstructed trader | `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` |
| B, subsequent principal recipient | `0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D` |
| C, ETH funder and two distribution recipients | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` |
| D, first distribution recipient | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` |
| Distribution contract | `0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B` |
| Swap router | `0x1111111254EEB25477B68fb85Ed929f73A960582` |
| LUSD token | `0x5f98805A4E8be255a32880FDeC7F6728C6568bA0` |

Starting provenance: the [partner's 2 May 2024 report](https://deficollective.org/blog/kaskade-campaign-report/) links the first two swap transactions. Follow-on observations came from [A's public transaction list](https://etherscan.io/txs?a=0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455) and individual successful transaction receipts. The following tables and calculations are independently transcribed chain records, not an adoption of the report's ownership inference.

## Nine-swap sequence: exact amounts

All dates below are **20 April 2024, UTC**. All transactions succeeded and were sent by A. Amounts are token quantities; current explorer dollar annotations were excluded.

| # | UTC | Input | Output | Fee, ETH | Transaction / block |
|---:|---|---|---|---|---|
| 1 | 18:05:23 | 30281.192454 USDC | 30280.462242451578365788 LUSD | 0.002283486062268027 | [19698298](https://etherscan.io/tx/0x66e91ec0018193397cfd98a2e7ed941f61c90e2a76d11d8f1891e0ed635432dd) |
| 2 | 18:05:47 | 30280.462242451578365788 LUSD | 30263.026732 USDC | 0.00245394005425542 | [19698300](https://etherscan.io/tx/0xb41b25cef02424ec43c872307d746ba76b522f0c6d7bc7b46c97d53ca84e3d1a) |
| 3 | 18:06:11 | 30263.026732 USDC | 30262.297113408790291948 LUSD | 0.002422486093789433 | [19698302](https://etherscan.io/tx/0x792dc78057a2162787ac1f65bf717f515eb5e079ce9f7840ffae099a35571479) |
| 4 | 18:06:59 | 30262.297113408790291948 LUSD | 30244.871907 USDC | 0.002338115783018625 | [19698306](https://etherscan.io/tx/0x6c4d267ca5738b2cc5ba78a5c994fe4b9677b3a0c5c252fd555e06fc4e6eb32a) |
| 5 | 18:07:23 | 30244.871907 USDC | 30244.142880817444087124 LUSD | 0.002301754537563503 | [19698308](https://etherscan.io/tx/0x502a46d5fd2fd0c5d8f189756c2402cacc028a5d637cfcaee538263344cbe5b2) |
| 6 | 18:07:47 | 30244.142880817444087124 LUSD | 30226.727973 USDC | 0.002436353548199536 | [19698310](https://etherscan.io/tx/0x6c5cf50296546154fe3eef55dcda11a9a90303d91fc336efa96b2bc36a3f20e4) |
| 7 | 18:08:23 | 30226.727973 USDC | 30225.999538678090387769 LUSD | 0.002502595291478635 | [19698313](https://etherscan.io/tx/0xbebdfa1408cf7f403034f7079126ca6ddb34fb55d0456f9d6db674e21617b397) |
| 8 | 18:08:47 | 30225.999538678090387769 LUSD | 30208.594924 USDC | 0.00236705587013583 | [19698315](https://etherscan.io/tx/0xe67ac3a8c799d7c8013dfd7c4281890e5111e76fc1f36791305e25c1ad67bbd3) |
| 9 | 18:10:35 | 30208.594924 USDC | 30207.867080991279108779 LUSD | 0.002664728358422271 | [19698324](https://etherscan.io/tx/0x9e7b5b2f587afb617704778508850dccd07d8cffdb18b990b368c98da562f63a) |

**Reproducible calculations:**

- Every output from transactions 1–8 equals the next transaction's input, including all displayed token decimals.
- Four complete round trips: 18:05:23–18:08:47 = **204 seconds (3m24s)**.
- Starting balance deployed: **30,281.192454 USDC**. USDC returned after four loops: **30,208.594924 USDC**. Difference: **72.597530 USDC**, or **23.974462 basis points** of initial capital, before gas.
- Gas on those eight swaps: **0.019105787240709009 ETH**.
- Nine swaps span **312 seconds (5m12s)**, ending with **30,207.867080991279108779 LUSD**, a different asset from the starting USDC.
- Sum of the nine input quantities, counting each swap once: **272,237.315765355903132629 nominal stablecoin units**. If USDC and LUSD are both valued at $1, this is approximately **$272,237.32**, or **8.9903103×** initial capital. This assumption-based dollar total is not an exact historical USD valuation or a reconstruction of the platform's attribution formula.
- Total gas on nine swaps: **0.021770515599131280 ETH**.

The final LUSD amount cannot simply be subtracted from initial USDC to state an exact realized trading loss. Likewise, claim proceeds cover multiple campaign periods, so subtracting only this nine-swap sample's costs from all claims would overstate any sample-based profit calculation.

## Distributions and immediate forwarding

Every claim below succeeded, transferred LUSD from the same distribution contract to A, and was followed by A forwarding exactly the amount received. The forwarding transactions also succeeded.

| Claim UTC | LUSD received, exactly | Claim fee, ETH | Receipt | Forward UTC and recipient | Forward receipt |
|---|---|---|---|---|---|
| 2024-04-17 14:28:11 | 386.799056455249362944 | 0.004792304437044514 | [claim](https://etherscan.io/tx/0x100eabbf75e5dbbba6bbfb66dfeeb1a6fb3638fcd09371f71c115f507b597ed9) | 14:29:23 → D | [forward](https://etherscan.io/tx/0x4e3f0a9506fff2898f77c386785e8a03079ac07e647601db4858110bb47b76b1) |
| 2024-04-24 16:44:23 | 1170.2736549072093184 | 0.001407444441161432 | [claim](https://etherscan.io/tx/0x502e4215d33af4817f95b57ef2b0ee6aaf246c78384bc71b010e75e63755538b) | 16:44:47 → C | [forward](https://etherscan.io/tx/0xbd8d71aaddfdddb2edabaec1dd352facd630a2e92f8006855e797c480daf6538) |
| 2024-05-01 12:25:47 | 913.743550266616578048 | 0.001035995399298130 | [claim](https://etherscan.io/tx/0x98878c870617ac53d0670030fd7c87bac6057b827edd827e8b0212c220b84205) | 12:26:35 → C | [forward](https://etherscan.io/tx/0x9fa3ee4d4258d810d4a5b6b7f70430a3f5bac51f26cb9d6dd11499c21116ca11) |

Total across these three claims: **2,470.816261629075259392 LUSD**. The two amounts forwarded to C total **2,084.017205173825896448 LUSD**. Transfers establish public financial links, not beneficial ownership.

**Campaign attribution:** the weekly claim dates match the campaign's epochs, and the consolidated research independently recovered the Week 2 leaderboard: A's displayed 11.70% share is consistent, after rounding, with the 1,170.2736549072093184 LUSD payment from a 10,000 LUSD epoch. This is a strong correspondence; the transaction receipts alone do not contain the campaign's brand name. The parent should retain the leaderboard source when identifying these as Kaskade campaign rewards.

**Contract check:** the [public contract page](https://etherscan.io/address/0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B#code) displays a **MerkleDistributor** with verified *similar-match* source. That is evidence of a token distributor, not proof of a particular operator, a full security audit, or exact-source verification. No operator identity was inferred from the generic name. Only Code was opened; no wallet, signing, or write function was used.

## Capital and ETH links around the loop

All dates below are **20 April 2024, UTC**.

| UTC | Direction | Amount | Transaction fee, ETH | Transaction / block |
|---|---|---|---|---|
| 18:04:47 | C → A | 0.132104265292133462 ETH | 0.000246726399150000 | [19698295](https://etherscan.io/tx/0x5367a7efc46cfe3347446ec6b52d573b28dba1365e3360dc501e3f23f4238727) |
| 18:11:35 | A → B | 30207.867080991279108779 LUSD | 0.000568761284303240 | [19698329](https://etherscan.io/tx/0xdfae4f391d2451cf88237717943caaa0a73ac57c203e0258512f8ba1a73feb52) |
| 18:12:11 | A → B | 0.110505100023733828 ETH | 0.000376480178025000 | [19698332](https://etherscan.io/tx/0xb9093c9f721e0a5e7b3b8bfea6704e56066e01d30dd508f5f841052704b0aa7c) |

C sent ETH 36 seconds before A's first swap. A forwarded the ninth swap's exact LUSD output to B 60 seconds after receiving it, then sent B ETH another 36 seconds later. C also received the exact second and third distributions days later. This supports interconnected funding and proceeds movements. It does not alone prove who controlled any address.

## Lead disposition and access limits

| Lead | Disposition |
|---|---|
| Same-wallet repeated capital recycling | **Confirmed**, exact amounts across nine successful transactions. |
| Actual distributions to the example address | **Confirmed**, three receipts; campaign assignment has matching leaderboard corroboration. |
| Public transfer links to other leaderboard addresses | **Confirmed** for the specific transfers above; no extrapolation to all wallets. |
| Nine-swap duration described as under five minutes | **Corrected** for this exact sequence: 5m12s; first eight swaps took 3m24s. |
| Beneficial ownership or a named individual behind the address group | **Unresolved**; not investigated beyond public financial links. |
| Precise campaign-wide artificial-volume share or net trader profit | **Unresolved**; this is one reconstructed address and nine swaps, not an exhaustive campaign reconciliation. |
| Later implemented prevention or exclusion controls | **Not verified** in targeted public searches; absence of a retrieved implementation record does not establish that no remediation occurred. |

Browser access succeeded for the cited Etherscan pages through ordinary public navigation. A few navigations initially rendered incomplete text; reading again after rendering resolved this. No access-control workaround, authentication, transaction submission, hidden API, or address-to-person identification was used. No claim is made about inaccessible pages being down.

The dates fall after Laura's previously documented March 2024 tenure endpoint. Nothing in this reconstruction links her to the addresses, distribution decisions, or trading.

## Machine-readable record and reproduction

Exact strings and URLs are in `volume_kaskade_raw.json`. Minimal independent reproduction with Python's standard library:

```python
import json
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 60
r = json.loads(Path("volume_kaskade_raw.json").read_text())
D = Decimal
s = r["swaps"]
assert all(x["output_token"] == y["input_token"]
           and D(x["output_amount"]) == D(y["input_amount"])
           for x, y in zip(s, s[1:]))
print("Nine input units:", sum(D(x["input_amount"]) for x in s))
print("Four-loop USDC difference:",
      D(s[0]["input_amount"]) - D(s[7]["output_amount"]))
print("Eight-swap gas:", sum(D(x["transaction_fee_eth"]) for x in s[:8]))
print("Nine-swap gas:", sum(D(x["transaction_fee_eth"]) for x in s))
print("Three claims:", sum(D(x["amount_lusd"]) for x in r["claims"]))
```
