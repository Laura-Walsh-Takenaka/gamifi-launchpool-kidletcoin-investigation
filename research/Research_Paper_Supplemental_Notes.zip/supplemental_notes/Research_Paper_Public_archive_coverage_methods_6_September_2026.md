# Research Paper — Public archive coverage methods — 6 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

The documented QuickNode BNB demonstration endpoint remains usable for historical state, historical transaction receipts and tightly bounded event queries. No independently tested public endpoint supplied a wider archival event index in this pass. This is an access/coverage limitation, not evidence of absent transactions.

## Confirmed method boundaries

- `https://docs-demo.bsc.quiknode.pro/`: `eth_newFilter` for the single known withdrawal block 22,786,456 succeeded; `eth_getFilterLogs` returned the canonical GMI transfer of 14 million tokens from the Launchpool contract to `0x35dc4a16db1e30036fee83e733ee065ad8535422`. The temporary filter was uninstalled successfully. These records match the earlier direct-log/receipt evidence.
- A standard filter covering 100,000 blocks was explicitly rejected with HTTP 413, JSON-RPC error `-32614`: **“eth_newFilter is limited to a 10,000 range.”** The alternate standard filter workflow therefore does not expand the known `eth_getLogs` window. No limit bypass was attempted.
- The optional documented `qn_getWalletTokenTransactions` index returned HTTP 403 / `-32609`, stating the Token and NFT API add-on was not enabled. No activation, account creation or charge was attempted.
- `https://rpc.48.club`: confirmed chain ID 56 and a current block response, but block 22,786,456 returned `null`; a log query for that block returned “header not found.” This endpoint did not provide the required 2022 history.

All QuickNode filter calls used the shared *Historical file: rpc_gate.py* scheduling gate. Tests were read-only apart from temporary, explicitly removed RPC event filters; no blockchain transactions were submitted.

## Other documented endpoint results

| Endpoint | Small historical query result |
|---|---|
| `https://bsc-rpc.publicnode.com` | HTTP 403; separate chain-ID diagnostic returned Cloudflare error 1010 |
| `https://public.1rpc.io/bnb` | HTTP 403 |
| `https://bnb-mainnet.g.alchemy.com/v2/docs-demo` | HTTP 403 |
| `https://bsc.drpc.org` | HTTP 403 |
| `https://bsc-pokt.nodies.app` | HTTP 403 |
| `https://bsc.blockpi.network/v1/rpc/public` | HTTP 403 |
| `https://bnb.api.onfinality.io/public` | HTTP 429 |
| `https://bscrpc.com` | HTTP 401 |

One public Routescan chain-metadata request returned HTTP 400; it supplied no usable BNB coverage. BscScan filtered-token pages could not be retrieved by the web research service in this pass. Public Blast API documentation stated that the service had been deprecated; SubQuery's public BNB page said its RPC service had retired to OnFinality. No probes were made to retired Blast/SubQuery endpoints. Authentication or anti-abuse controls were not bypassed.

## What can be established without a full transfer census

Historical account nonces are monotonic. Binary-searching where an externally owned account's nonce advances, retrieving those blocks, and matching the account's sender and nonce can establish all of that account's **normal outgoing transactions** over a properly bounded interval. This does not automatically establish every incoming token transfer, internal payment, or third-party-initiated vesting claim.

Verified vesting records can establish recorded allocations and cumulative claimed values at specified blocks. Claim counters can guide retrieval toward likely payment intervals. A source-code or executable-code match establishes how that implementation works; completeness claims must also account for proxy upgrades and any alternative payment paths.

A receipt census must specify its start/end blocks, successful query windows, address/topic filters, and any failed or unqueried windows. Exact event sums should be reconciled to independently read opening/closing token balances. A successful reconciliation supports arithmetic consistency; **matching balances alone does not prove the absence of intervening transfers**. Equal and opposite flows can cancel, a third party can fund a contract between payments, and endpoint snapshots can miss entire cycles. A wallet's unchanged balance likewise does not establish that it was inactive.

Consequently, claim-record reconciliation, an account-nonce census, and a complete canonical-token transfer census are distinct coverage statements. Reports should name the achieved type instead of describing a partial reconstruction as full chain history.

## Reproduction records

This directory contains the exact JSON requests, responses or errors for the tests. Files prefixed `qn_filter_` document successful creation/read/uninstall and the rejected wider query; `qn_index_retry.json` records the explicit index add-on boundary; `48_followup.json` records chain ID, current block and missing historical block. Provider-specific `*_small.json` files preserve the other small probes. Python scripts are included for method review, but need not be rerun.

## Primary documentation consulted

- BNB Chain, JSON-RPC endpoints; explicitly states `eth_getLogs` is disabled on its listed mainnet endpoints: https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/json-rpc-endpoint/
- QuickNode, BNB `eth_getLogs`: https://www.quicknode.com/docs/bnb-smart-chain/eth_getLogs
- QuickNode, BNB `eth_getFilterLogs`: https://www.quicknode.com/docs/bnb-smart-chain/eth_getFilterLogs
- QuickNode, optional token index and add-on requirement: https://www.quicknode.com/docs/ethereum/qn_getWalletTokenTransactions_v2
- PublicNode: https://bsc.publicnode.com/
- 1RPC network list: https://docs.1rpc.io/using-the-web3-api/networks
- Alchemy BNB log method demonstration: https://www.alchemy.com/docs/chains/bnb-smart-chain/bnb-smart-chain-api-endpoints/eth-get-logs
- dRPC BNB infrastructure guide: https://blog.drpc.org/bnb-chain-rpc-infrastructure-guide/
- Nodies public endpoint documentation: https://docs.nodies.app/rpc-services/pokt-public-rpc-endpoints
- BlockPI BSC page: https://blockpi.io/chain/bsc/
- OnFinality BNB endpoint guide: https://www.onfinality.io/en/rpc-assistant/rpc-url-for-binance-smart-chain
- 48Club endpoint documentation: https://docs.48.club/privacy-rpc
- Onerpc BSC public endpoint landing page: https://bsc.landing.enterprise.onerpc.com/
- Routescan network metadata documentation: https://routescan.io/docs/api/network
- Blast retirement notice: https://blastapi.io/public-api/bnb-chain
- SubQuery BNB retirement notice: https://subquery.network/rpc/list/56
