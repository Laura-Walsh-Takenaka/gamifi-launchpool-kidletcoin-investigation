# Research Paper — Received deed 10116: analytical reading

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Source: supplied `Asociados Carajo deed 10116`, 5 PDF pages, 1,315,809 bytes.


Method: all five pages rendered and visually read; English-language OCR is retained in separate page text files as a search aid. Image and original text control where OCR differs. This note reports the contents of the supplied copy and does not authenticate the source or signatures.

## Exact document and dates

- Public deed / Escritura Publica No. **10,116**, dated **7 May 2025**, Notaria Duodecima del Circuito de Panama (PDF pp. 1-2).
- Notary identified as **Souhail Musbah Halwany Cigarruista** (PDF pp. 1-2 and 5).
- Purpose: protocolization of minutes of an extraordinary general shareholders' meeting of **ASOCIADOS CARAJO INC.** (PDF pp. 1-2).
- Underlying shareholders' meeting occurred **7 February 2025**, not 7 May (PDF p. 3, printed page 2, lines 2-3).
- Company is described as organized under Republic of Panama law, recorded at mercantile **folio 155733022** (PDF p. 3, lines 3-6; repeated p. 5, lines 1-2).
- No filing-entry number such as 187609/2025 is printed in this deed copy. That number must be sourced to the registry entry summary, not this deed.

## What the minutes say about shareholders and authority

PDF p. 3, lines 7-12: shareholders designated **Persis Manfred Sarmiento** to chair the meeting and **Omar Camargo** to act as meeting secretary. The secretary states that holders of all issued and outstanding shares carrying voice and voting rights were present by electronic communication, and waived prior notice. Article 203 of Panama's Commercial Code is cited by the document.

PDF p. 3, lines 24-25: resolutions approved unanimously.

**No shareholder names, beneficial-owner names, holdings or percentages are disclosed in the minutes.** The meeting chair and secretary are named in those functions; that wording does not itself identify them as shareholders. The recorded decisions demonstrate appointments approved by the shareholder meeting as described in the deed, rather than disclose the identity of the approving holders.

## Appointments approved

| Person | Appointment recorded | Precise page |
|---|---|---|
| Mario Ernesto Garcia de Paredes Estripeaut | New resident agent; text states he accepts the position | PDF p. 3, lines 26-29 |
| Persis Manfred Sarmiento | Director and president | PDF p. 4, lines 1-5 and 9 |
| Omar Camargo | Director and secretary | PDF p. 4, lines 1-5 and 10 |
| Miriam Camargo | Director and treasurer | PDF p. 4, lines 1-5 and 11 |

The new directors/officers take office at the close of the meeting (PDF p. 4, lines 3-5). The deed calls them new directors/officers. It does not identify outgoing directors or contain their resignation letters. The deed does not name Quijano & Asociados or specify Quijano's resignation date; any comparison to Quijano must use other records.

The same professional business location is listed for the resident agent and appointees (PDF pp. 3-4). Shared service premises are not proof of beneficial ownership or operational control of launchpool.xyz.

## Who presents, signs and certifies what

- **Mario Ernesto Garcia de Paredes Estripeaut** personally appears before the notary to present the shareholders' minutes for protocolization (PDF p. 2, lines 11-16). The meeting also authorizes him to protocolize and register the minutes (PDF p. 4, lines 12-14).
- The notarial recital names **Leydy Ioidsa Castillo Penalba** and **Carmelo Antonio Villarreal Nastasi** as instrumental witnesses (PDF p. 2, lines 18-23). Personal identity numbers have deliberately not been reproduced in this analytical note.
- The minutes' closing signature notation names **Persis Manfred Sarmiento**, meeting chair, and **Omar Camargo**, meeting secretary; each is preceded by '(Fdo.) Ilegible' in the typed copy (PDF p. 4, lines 16-18).
- **Omar Camargo**, expressly acting as company secretary, certifies the preceding minutes are a faithful copy of the original held in the company minute book (PDF p. 4, lines 19-24).
- The minuta is endorsed by lawyer **Mario Ernesto Garcia de Paredes Estripeaut**, professional qualification certificate **14028** (PDF p. 4, lines 25-27). This is a lawyer professional identifier, not a company registration number.
- A declaration by the new resident agent follows on PDF pp. 4-5. Mario declares compliance with **Article 18 of Law 254 of 11 November 2021** (PDF p. 5, lines 1-4). The deed contains that declaration, not the underlying compliance records. No independent legal conclusion is drawn here.
- PDF p. 5, lines 5-6 contains the notarial true-copy recital dated **7 May 2025**, with a visible signature and notarial seal image below. Source also says 'Esta escritura tiene un total de dos (2) paginas' at line 7, while the download contains one cover and four numbered body pages; no missing-page conclusion is warranted from that wording alone.

## Copy status and evidentiary limits

All visible pages carry **'Copia para propositos informativos solamente'** ('Copy for informational purposes only'). PDF p. 1 also says COPIA. The PDF contains a scanned notarial copy with true-copy language and signature/seal images; it must not be described as a newly obtained certified registry extract or independently verified original.

The document identifies a replacement resident agent and directors/officers in 2025. It supplies an important recorded succession event. It does **not** identify Laura Takenaka, Laura Walsh, Launchpool, Launch Pool Limited, either Linford company, SCR Advisors, bank accounts, wallet addresses, consideration paid, a business transfer, or beneficial owners. Ownership and connection to launchpool.xyz remain questions for other sources.

## Practical implication

The requested 2025 deed has now been supplied and read. It resolves the identity of the resident agent appointed by the 7 February 2025 shareholder meeting: Mario Ernesto Garcia de Paredes Estripeaut. Later changes or current status require the current record or later filings.
