# Research Paper — GamiFi contract/control follow-up — bounded findings

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

## New established links

1. Public repository `sheandev/gamifiContracts` contains `tasks/initVesting.js`, labelled “Init vesting for Launch Pool investors”, and `contracts/VestingLaunchPool.sol`. The committed vesting list was added in commit `b5c2cd4aa396f65b45b8f3921ab068ee36e40ad4`, dated 2022-04-19T13:50:54Z.
2. Repository BSC manifest identifies vesting proxy `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb`, original implementation `0xddfc12894e99a2058b974b7234242ac47e6812ed`, current manifest implementation `0x7ed8022c43ab08e79c79addd8a7e5427aaa52250`. Both implementation layouts explicitly name `VestingLaunchPool`.
3. Live read at BSC block 120220233 (`0x72a6a49`), via https://bsc-dataseed.bnbchain.org, independently returns canonical GMI as `token()`, owner `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`, proxy admin `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475`, and implementation `0x7ed8022c43ab08e79c79addd8a7e5427aaa52250`.
4. Two bounded beneficiary `getVest` reads match exact amounts in the committed CSV. Largest entry `0xe356fe28b7b6b015a3b2bb4419dbdf2777d7420b`: 587755.519557566 GMI, start 2022-04-19T17:14:29Z. First entry `0x000deef80c998e56cdb387392096d6109be0c283`: 17.2356392039306 GMI, start 2022-04-19T16:30:49Z. Both nonce 1, zero initial/cliff, 270-day linear period, claimed field zero at observation. This links these specific rows to stored live GMI vesting schedules; it does not validate all rows, funding, receipt of deposits or completed payments. The candidate source exposes public initiateVest() schedule creation without transferring funding; only initiateVests() batches transfer tokens afterward. A matching schedule alone therefore does not establish funded allocation. No vulnerability claim is made without deployed-runtime validation.
5. Deployment receipts show one original deployer/owner, `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`, created vesting, ProxyAdmin, and the live Duke/Mystery contracts.
6. ProxyAdmin `owner()` at earlier block 120219818 is `0x538a8b615e98e87d025c4336be44e4b8588277c7`. That is a separate control layer from the vesting/Mystery/Duke owner. A broad single-address ownership event query hit RPC limits; exact later control-transfer dates not obtained. No scan sweep was launched.

## Receipts verified

| Contract | Creation UTC | Transaction |
|---|---|---|
| ProxyAdmin 0x6ef… | 2022-04-19 13:10:27 | 0x528547faadbe40961e8a90e6506f6093d9271a1863824ab1885d26440e6e94e7 |
| Vesting 0xf504… | 2022-04-19 13:10:39 | 0xe42d218340a4a53c8ed687bb8ac26a4cc9d07e4d0af061a6abd3b8f347ff4c66 |
| Duke 0x3e5… | 2022-07-11 08:41:49 | 0x2b9e222090887d86df951f6cae0b32262443e1274cc9d2f94ca1e48298ad9038 |
| Mystery 0x016… | 2022-07-11 08:42:04 | 0xe0013edf1493f10bb1e3ab28ce5691f2ec45a09306f950c8ca49ea5b9836a6c2 |

## CSV scope

7493 rows, 7493 case-sensitive address strings, 7489 distinct addresses after case normalization. Exact sum 15456875882908530406846000 raw units (15456875.882908530406846 at18 decimals). There are four case-variant duplicate groups. The script's duplicate check compares exact strings, so do not say these cause rejection. These are list figures, NOT verified actual distributed totals or unique individual investor counts. No matches to the three control addresses surfaced in the list.

## Limits

The public repository self-describes GamiFi development. Manifest, canonical token identity, deployment receipts and matching beneficiary records strongly corroborate its relationship to the live project. No specific natural person or Cayman bank account is identified. Do not attribute any control address to Laura, Alphabit or a named investor without an independent label. This is a technical connection to GMI distribution activity and common contract deployment/control. Contract owner is not necessarily the beneficial asset owner; upgrade admin is a separate role.

No bytecode recompilation/reverification undertaken in this lane; proxy implementation identities and ABI return structures checked against manifest and exact beneficiary values. Both Sourcify metadata routes for the initial implementation returned404. The current implementation was not recompiled. An attempted stale fixed-block storage read returned missing-trie-node; all final vesting state reads succeeded at the fresh common block above.

## Public source URLs

- https://github.com/sheandev/gamifiContracts
- https://github.com/sheandev/gamifiContracts/blob/main/tasks/initVesting.js
- https://github.com/sheandev/gamifiContracts/blob/main/contracts/VestingLaunchPool.sol
- https://github.com/sheandev/gamifiContracts/blob/main/.openzeppelin/unknown-56.json
- https://github.com/sheandev/gamifiContracts/blob/main/vesting.csva
- https://github.com/sheandev/gamifiContracts/commit/b5c2cd4aa396f65b45b8f3921ab068ee36e40ad4

## Raw evidence

All `verified_*.json`, `vest_*.json`, `nonce_*.json`, and `receipt_*.json` preserve endpoint, retrieval time, exact RPC request and response. `beneficiary_decoded.json` records decoded fields and equality tests. `vesting_csv_summary.json` records list totals and duplicate groups. Fresh calls should pin to a new common block: this endpoint prunes historical state rapidly.
