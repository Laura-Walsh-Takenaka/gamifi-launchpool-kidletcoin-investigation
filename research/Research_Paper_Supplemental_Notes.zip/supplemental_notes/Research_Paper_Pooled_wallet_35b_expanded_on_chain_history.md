# Research Paper — Pooled wallet 35b: expanded on-chain history

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Verified 7September 2026 UTC. Address: `0x35b119730f79881dac623dc51c831c6a04cab5f3` (BNB Smart Chain).

## What changed

The bounded follow-up now has a **complete signed-transaction inventory through nonce 183**, a substantially reconciled stablecoin ledger, an August 2022 balance sweep to a known GamiFi administrative key, and earlier links to the 120m-GMI private-beneficiary route. It does not identify the humans controlling these keys or establish commercial entitlement, purpose, theft, or customer settlement.

## Coverage and independent checks

- BSCTrace's publicly accessible NodeReal index supplied 193 unique ordinary transaction rows:184 outgoing and9 incoming. Each hash was independently fetched with its receipt from the Binance public BSC RPC. All 184 signed nonces0–183 are present, all successful. The signed history runs29November 2021–7November 2022.
- Fresh pinned block 120,402,767 returns nonce 184, no deployed code, and zero BNB, zero BUSD and zero USDC.
- A separate public token index supplied 459 ERC20 event rows. This lane selected 301 events involving the exact BUSD, USDC, GMI and two SHF contract addresses. Every selected row matches a successful independently fetched receipt, including token contract, parties, integer amount and log index. Unsolicited unrelated tokens were not treated as project assets or evidence of endorsement.
- The BUSD event ledger agrees exactly with8 historical balance observations, including the project4 receipt, GAMI receipt, SHF receipt and final August 3 sweep. Both stablecoin ledgers net to their current zero balances. This is complete reconciliation of the selected indexed history at these checkpoints, **not an independent every-block census of all internal/allowance activity**.
-19 consequential block headers independently confirm indexed timestamps, including August 3–4 and the largest early stablecoin transfers.

## The August 3 balance sweep

| UTC date/time | Flow | Exact amount | Proof |
|---|---|---:|---|
|3Aug2022 15:50:04|35b→14cc, BNB|390.50307622 BNB|Signed nonce 175; successful receipt; historical balance390.503181225→0.000000005 BNB, difference reconciles transfer plus gas|
|3Aug2022 15:52:22|14cc→35b, BNB|3 BNB|Successful incoming transaction|
|3Aug2022 15:53:16|35b→14cc, BUSD|26,626.652848696482503518 BUSD|Nonce176; entire pre-transfer BUSD balance; post-transfer balance0|
|3Aug2022 15:53:34|35b→14cc, USDC|2,302 USDC|Nonce177; entire pre-transfer USDC balance; post-transfer balance0|
|4Aug2022 14:54:38|14cc→35b, BNB|200 BNB|Successful incoming transaction|
|4Aug2022 14:55:35|35b uses200 BNB and receivesUSDC|60,439.274293674825498827 USDC|Nonce178; attached native value200 BNB; swap/transfer receipt|
|4Aug2022 14:56:08|35b→14cc, USDC|60,439.274293674825498827 USDC|Nonce179; exact received amount forwarded; resultingUSDC balance0|

Full receiving address: `0x14ccacd699287c1b6ad07fd911394a05d802b412`. Prior verified work identifies this as original Project contract owner at the May/June withdrawals, an NFT administrator, and the September 14 sender of 100 BNB to the later staking-pool replenisher. Those are on-chain roles and relationships, not identification of Laura or another human.

The August 4 USDC must **not** be added as an independent diversion of GamiFi fundraising: it was generated from 200 BNB sent into35b by14cc immediately beforehand, and was returned to 14cc. No pooled-asset FIFO attribution is made.

Consequential transaction hashes:

- BNB sweep: `0x7d9b1d573aef0370c63c764df2c3325428238b6b0a53108957fb58cdebed167d`
- BUSD sweep: `0x4a0f5d61337a404788cab8d53d6e4702a2ee62cbc41142a1347965399e01f701`
- USDC2302 sweep: `0x202357295230d75ff4683405feb2fde8ab8ce9de177275d61bafe9c050b2d16a`
- Incoming200 BNB: `0xe3195050fc274cc6e176a82997f668fd796932c693297039e6fe1d36210b979e`
- Conversion: `0xc64dbd4a8322d5b5a4877095f1adb3e050a2ae3f7ba6cd68e141b2253ec817a1`
- ResultingUSDC return: `0x3f5359c3f405974a4b9e91705ecae180221c6c984bfeac800b1cde2f83f4f423`

## Broader stablecoin history

| Asset | External incoming | External outgoing | Other event | Closing net |
|---|---:|---:|---|---:|
|BUSD|634,245.652848696482503518|634,245.652848696482503518|One2,000 BUSD self-transfer, counted as both sides in gross Transfer totals636,245.652848696482503518|0|
|USDC|1,360,439.274293674825498827|1,360,439.274293674825498827|Includes the 200 BNB conversion described above|0|

These are token-unit flows through one pooled address, **not a loss calculation, valuation or verified GamiFi financing total**. Do not add them together as fresh fundraising without commercial records, and do not allocate a later payment to a particular incoming offering merely because dates follow one another.

Notable earlier entries, individually receipt-verified:

-29November 2021:650,000 USDC from `0x87055dd940a847592cd45239bae682a72315216d`, then650,000 USDC from `0xab2ebe2b463ae4b1ed697afa8a7dbe6202c1a477`. No investor identity or agreement is assigned.
- January 2022: four counterparties received 250,000 USDC each in test/main combinations or one payment; address 053f additionally received 20,000 USDC. Exact ledger distinguishes10-unit tests from their249,990-unit main payments.
-25January 2022:399,990 BUSD arrived from `0x93cfc2f90882123989fdf9ee69cb353dd56cf4ff`.
- Largest repeated stablecoin recipient `0xe6020805fd96142811cbfbc67627679f2c446d30` received 246,171 BUSD and185,750 USDC over the verified indexed history. Its actual account holder and settlement purpose remain unidentified.

Recurring payments to several addresses across multiple months are recorded in `repeated_counterparties.json`. That pattern supports asking for recurring vendor, compensation or other payment schedules; it does not establish payroll or services without records.

## New links to the private-allocation and project4 routes

1. **11March 2022 10:22:10 UTC:** private120m-GMI beneficiary `0x36048413c4edf0cf3e633aab317fcd9824dfb4d4` sent 10,000 GMI to 35b, tx `0xbe801f3b0e1fffdc58e884ad6359bf07ee93a0db6d5cc2c7a98a5d782fe2d39b`.
2. **10:25:19 UTC:**35b forwarded10,000 GMI to `0x391a51d884b240908a88e1e757ec42189d294423`, tx `0x16be6d6e38bf5db8dc321c7f3efe215d8886ab5c074476f0736beb7a3355aa98`. That address is the sole2,000 BUSD contributor identified for original project4. This connects its GMI funding to the private-beneficiary route without identifying its human controller or establishing an internal test.
3. **30May 2022 02:46:57 UTC:**35b sent 20,000 BUSD to `0xf4f86e37815217ed73ae817a4e5164d56315b1d7`, tx `0x825eb0e3cf1151e268c7e5d62d5ec5c3de917b351d908bdfef92327e53625d87`. Prior evidence identifiesf4f86 as an onward recipient of later private-allocation sale proceeds. This20,000 BUSD predates those later proceeds.
4. **23September 2022:**35b sent 2.99606819 BNB tof4f86. On7Novemberf4f86 sent 0.5 BNB back;35b then forwarded0.499895 BNB to `0x78d09e1435e1906878621bcb0aaa9d47561214c3`, with the remainder consumed by its21,000-gas transaction at5gwei. Prior work links78d09 to April Launchpool funding. No common human ownership is inferred.

## SHF delivery lead, separate from BUSD repayment

The selected receipts establish flows for two exact token contracts; similarly named tickers must not merge them:

- `0x96bad480691fee450598f3a6c144f09fa5df950d`:85,733.882037037 tokens arrived11 July, were sent to 3e0f, returned13 July, and forwarded25 August to `0x74f7a03ee449bbe36f2c8201348962657cf96ddc`.
- `0x2d4df8a0e975e15ea443933affb27afe9395e2a8`:9,259,259.2592 arrived24 August. One25 August transaction sent 9,166,666.666608 to 74f7 and92,592.592592 to `0x3643c5c1ac8a7ecf0011e174ec8f94c451f833c3`. The split is99%/1%; no fee purpose is assigned from arithmetic alone.

The parallel evidence lane reports neither destination among original project9's26 funding addresses. An intermediary/distribution route remains possible; this comparison is not proof of delivery failure or repayment. Both token contracts' decimals and the recipients' code at the pinned block are separately recorded in `shf_metadata_recipient_probe.json`.

## Remaining record targets

The most precise next questions concern dated custody and instructions for35b/14cc, the August 3 sweep and August 4 conversion, accounting/payment schedules for recurring recipients, entitlement of early large stablecoin recipients, and SHF distribution records for74f7. Crypto settlement may consist of refunds, token delivery or crypto-denominated invoices; a bank receipt is relevant only where an actual fiat settlement is claimed. The chain currently establishes addresses, actions and amounts—not the humans, business entitlement or cause of Laura's departure.

## Reproducibility and sources

Raw responses retain endpoint, request, retrieval time and response. Source indexes are under `account_index/`; independent chain records under `raw/`.

- Public index address page: https://bsctrace.com/address/0x35b119730f79881dac623dc51c831c6a04cab5f3
- Public account endpoint: https://bsc-explorer-api.nodereal.io/api/tx/getAssetTransferByAddress
- Parameters: address above; type=transaction for ordinary rows, type=20 for ERC20 rows; pageSize=100; page=N; order=desc.
- Independent ordinary transactions, receipts and pinned state: https://bsc-dataseed.binance.org/
- Historical state: https://docs-demo.bsc.quiknode.pro/

Source index metadata can contain third-party behavioral labels. They are preserved raw for provenance but were not used to identify human owners or justify misconduct allegations. Full indexed transaction input was sometimes truncated to a selector; analysis uses complete independently fetched RPC transaction input.
