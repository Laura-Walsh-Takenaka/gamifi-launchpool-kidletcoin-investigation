# Research Paper — What the BVI registry actually makes available

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The paid-record gap is real, but it consists of separate products and legal access rules. The ordinary **company search is US$50**. It gives an index of the company’s Registry filings; it does not purchase copies of every filing. A later statutory fee schedule adds **US$250 to inspect all qualifying documents** held for one company. Inspection and supply of copies are distinct services, and paying either fee does not override restrictions on private registers. [R1–R4]

For this investigation the target remains **Gamifi Limited, entity number 2082070**. The supplied registry screenshot establishes the returned name and number. It does not disclose status, incorporation date, registered agent, directors, shareholders or a bank account. The reported $50 portal price is corroborated by the official fee sources below; the screenshot itself does not show a price or currency.

### Confirmed access and fee matrix

All dollar amounts below are **US dollars**: section 2 of the BVI Business Companies Act defines the statutory dollar in that currency. These are government fees, excluding any intermediary charge. No order, payment or application was submitted. [R4]

| Record or action | Official access / fee | What it would answer for Gamifi Limited 2082070 |
|---|---|---|
| Basic entity-name lookup | Free identification stage shown in the supplied screenshot; official Public Search portal | Confirms the matching registry name and number. A hit alone is not a good-standing certificate. |
| Ordinary company Search Report | US$50; R820, p.1, and Schedule 1 inspection of registers | Incorporation, recorded status and status date, current agent and office, capital/share information, previous names, Registry transaction history and certificate history. [R1–R3] |
| Particular corporate filing | R820 routes additional document requests; general copy fee US$100 each unless a specific fee applies | The underlying instrument behind a filing-history entry, rather than its index description. [R1–R3] |
| Inspection of one other qualifying Registry document | US$100 | Read a particular accessible filing. This is the statutory inspection fee, not a promise of a free copy. [R3] |
| Inspection of all qualifying documents held for one company | US$250 | Broader file inspection, subject to statutory access limits; not automatically a certified evidence bundle. [R3] |
| Memorandum and articles | R820 lists certified or uncertified copy at US$100 each | The company’s constitutional rules and information recorded in the supplied version; original and subsequent versions must be distinguished. [R2] |
| Incorporation, restoration, merger, consolidation, arrangement, continuation, discontinuance or dissolution certificate copy/extract | Certified US$75; uncertified US$50 | The certified event/date in the document. [R3] |
| Fresh certificate of good standing | US$100 under section 235; distinct from a copy of an existing certificate | Current certificate result if the statutory conditions are met. An old incorporation certificate cannot supply this. [R2, R5] |
| Copy/extract of an existing good-standing certificate | Certified US$75; uncertified US$50 | Copies what that particular dated certificate said; does not update its date. [R3] |
| Public list of directors | US$75; R820 lists US$100 for certified; public list concerns current directors | A lead to current officeholders recorded with the Registry. It cannot establish who controlled a signing key during September–November 2022. [R2, R5–R7] |
| Full register of directors | Statutory copy rates US$75 uncertified / US$100 certified do not confer public entitlement | The Act distinguishes the public list from the full register, accessible to the company/agent and specified authorities. [R3, R8] |
| Register of members / shareholders | Generally restricted; public access if the company has opted in under section 43A(6) | Legal shareholding and associated information in the accessible filing, if any. We have not established a public-access election by GamiFi. [R8] |
| Annual financial return | Filed with the registered agent; not the ordinary public Registry search product | Summary financial statements from the applicable reporting year, obtainable through an entitled company source or competent authority process. [R9–R11] |
| Bank statements, exchange customer records, wallet-custody and signing instructions | Not among the promised contents of the US$50 search report | These remain separate evidential records. A company status report will not close the transaction-to-human attribution gap. [R1; investigative inference] |

### The precise meaning of “transaction history”

The FSC’s search guidance, revised **1 September 2025**, explains that this is the list of transactions **filed with the Registry**. It is corporate filing history, not a company bank ledger, token-transfer history, a history of revenue, or the accounting behind the GMI transactions. Copies of particular documents can then be requested separately using the entries in that list. [R1]

The **US$250 all-document inspection** category appears in S.I. 57/2024, section 2(d), pages 3–4. It commenced with the 2024 Amendment Act on **2 January 2025**, fixed by S.I. 75/2024. The still-linked R820 is dated March 2023 and omits this later inspection category. The fee table in that older form should therefore not be treated as the entire current statute. Later S.I. 70/2024, 62/2025 and 119/2025 were also reviewed; they concern beneficial ownership and transitional filings and do not replace the ordinary US$50 / US$100 / US$250 inspection entries. [R3, R12–R15]

### Director names and historical responsibility

There are two different record products. The FSC’s legislative circular describes the public list as **current directors**; its October 2023 newsletter gives the R811 certification function and **US$75** fee. The 2024 amendment to section 118B(4) expressly separates the full register, available to the company, its agent and specified authorities, from the list that other people may request. [R6–R8]

Consequently, purchasing the public list today would not by itself settle Laura’s formal authority in 2022. Investigators still need the dated director entries, appointment/resignation instruments, relevant corporate instructions and key-custody records for that period. This is an evidentiary conclusion about the records required, not an allegation about the identity of any signer.

### Shareholders and financial returns are not simply hidden behind the $50 button

Since the 2024 reform took effect, section 43A requires register-of-members filing subject to exceptions. It restricts public access unless the company elects public availability; the new filing concerns members as of filing and subsequent changes. It does not guarantee a backfilled, public 2021–2022 ownership history. Section 43A(5) identifies access for the company/registered agent, competent authorities and law-enforcement bodies acting within their legal functions. The existence of a paid copy fee does not override those restrictions. [R8, R12]

Annual financial returns follow another path. Section 98A sends them to the **registered agent**, who must provide a copy to the FSC or another competent authority on request. The prescribed form comprises a balance-sheet summary and income statement. The regime began on **1 January 2023**, with the earliest returns becoming due in 2024; it is not a promised 2021–2022 transaction ledger. Initial filing extensions were subsequently permitted, so a general deadline alone cannot establish GamiFi’s compliance or noncompliance. [R9–R11, R16]

### Lawful routes that do not require a researcher to buy the report

1. **Use already available primary corporate disclosures.** Preserve the supplied registry screenshot, archived GamiFi terms and litepaper as independent evidence of what was publicly stated. These sources provide company-identification leads; they do not substitute for missing certificates.
2. **Follow independently published records.** A company, counterparty or liquidator may publish a certificate, constitutional document, court exhibit or statutory notice on an openly accessible site. A legitimately published copy can supply the relevant record without buying a Registry search. No specific extra GamiFi filing was recovered in this registry-access lane.
3. **Use an existing entitled holder.** A company or its registered agent may lawfully provide its own records. Section 100 also grants directors inspection rights and gives members specified inspection rights subject to the Act and constitutional limits. Holding GMI tokens alone is not proof of being a company shareholder. [R4]
4. **Hand the identifiers to investigators.** Section 43A(5) and section 118B(4) identify authority routes for restricted registers; section 98A(3) identifies the route to the annual return. Those are targeted records to seek through appropriate powers, not a free public search, and no such request has been sent. [R8–R9]

The practical difference is clear: the paid Search Report can identify filing dates and the current registered agent, but the historical-control and money-receipt questions still require records from the company, its service providers and relevant authorities.

### Registry sources and locators

- **R1.** FSC, *Searches (BVI Registered Entities)*, revised 1 September 2025, “Search Report Content” and paragraph immediately after the report-field lists. https://www.bvifsc.vg/searches-bvi-registered-entities
- **R2.** FSC, *Company Search and Document Request*, Form R820, Rev.03/2023, p.1 “Services and Fees.” Current FSC search-guidance link still points to this form. https://www.bvifsc.vg/sites/default/files/international_searches_form_r820_form_rev_0323_fillable1.pdf
- **R3.** *BVI Business Companies (Amendment of Schedule 1) Order, 2024*, S.I.57/2024, s.2(d), pp.3–4. Gazetted 4 December 2024. https://www.bvifsc.vg/sites/default/files/bvi_business_companies_amendment_of_schedule_1_order_2024.pdf
- **R4.** *BVI Business Companies Act*, Revised Edition 2020, s.2 currency definition (printed p.16 / PDF p.18); s.100 inspection rights (printed pp.70–71 / PDF pp.72–73); s.233 Registry access (printed p.161 / PDF p.163), read with subsequent amendments. https://www.bvifsc.vg/sites/default/files/bvi_business_companies_act.pdf
- **R5.** *BVI Business Companies (Amendment of Schedule 1) (No.2) Order, 2022*, S.I.89/2022, s.2(a)(v), p.5 (directors list), and s.2(a)(xii), p.7 (good-standing certificate); in force 1 January 2023. https://www.bvifsc.vg/sites/default/files/bvi_business_companies_amendment_of_schedule_1_no_2_order_2022.pdf
- **R6.** FSC, *Industry Circular No.5 of 2022 – Legislative Updates*, 5 October 2022, “Access to List of Directors.” https://www.bvifsc.vg/news/industry-updates/industry-circular-no-5-2022-legislative-updates
- **R7.** FSC, *Newsletter: October 2023*, 6 October 2023, “Registry’s Corner,” item 3. https://www.bvifsc.vg/news/industry-updates/bvi-fsc-newsletter-october-2023
- **R8.** *BVI Business Companies (Amendment) Act, 2024*, Act15/2024, s.10 inserting s.43A, pp.6–7, and s.25 amending s.118B, p.12. https://www.bvifsc.vg/sites/default/files/bvi_business_companies_amendment_act_2024.pdf
- **R9.** *BVI Business Companies (Amendment) Act, 2022*, Act6/2022, s.17 inserting s.98A, pp.11–12; s.19(f), p.13, register date scope. https://www.bvifsc.vg/sites/default/files/act_no_6_of_2022-_bvi_business_companies_amendment_act_2022_1.pdf
- **R10.** *BVI Business Companies (Financial Return) Order, 2023*, S.I.18/2023, ss.1–3, pp.2–3, and Schedule pp.4–5. https://www.bvifsc.vg/sites/default/files/bvi_business_companies_financial_return_order_2023.pdf
- **R11.** *BVI Business Companies (Amendment) (No.2) Act, 2024*, Act30/2024, s.2, pp.2–3, initial-return extensions and notification deadline; deemed in force 1 September 2024. https://www.bvifsc.vg/sites/default/files/bvi_business_companies_amendment_no._2_act_2024.pdf
- **R12.** S.I.75/2024, commencement notice for Act15/2024, p.1; appoints 2 January 2025. https://www.bvifsc.vg/sites/default/files/si_no_75_of_2024-notice_to_bring_into_force_the_bvi_business_companies_amendment_act_2024.pdf
- **R13.** S.I.70/2024, *BVI Business Companies (Amendment of Schedule 1) (No.2) Order, 2024*, p.2. https://www.bvifsc.vg/sites/default/files/bvi_business_companies_amendment_of_schedule_1_no._2_order_2024.pdf
- **R14.** S.I.62/2025, *BVI Business Companies (Amendment of Schedule 1) Order, 2025*, pp.2–3. https://www.bvifsc.vg/sites/default/files/si_no_62_of_2025-bvi_business_companies_amendment_of_schedule_1_order_2025.pdf
- **R15.** S.I.119/2025, *BVI Business Companies (Amendment of Schedules) Order, 2025*, pp.2–4. https://www.bvifsc.vg/sites/default/files/si_no_119_of_2025-bvi_business_companies_amendment_of_schedules_order_2025.pdf
- **R16.** FSC, *Industry Circular 26 of 2025 – Filing Initial Annual Returns*, for latest observed initial-return instructions. https://www.bvifsc.vg/news/industry-updates/industry-circular-26-2025-filing-initial-annual-returns

Research date: 6 September 2026. Official PDF files, text extractions and SHA-256 hashes are retained in the historical evidence set. HTML guidance was read with the web retrieval service; direct-download failure for R1 is recorded rather than labelled a successful raw capture. No GamiFi status, directorship, shareholding, bank account or wrongdoing is inferred from access limitations.
