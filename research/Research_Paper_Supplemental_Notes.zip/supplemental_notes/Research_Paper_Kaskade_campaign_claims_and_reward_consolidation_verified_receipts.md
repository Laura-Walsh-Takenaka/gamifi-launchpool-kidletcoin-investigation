# Research Paper — Kaskade campaign claims and reward consolidation — verified receipts

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Prepared 2026-09-05. This extends the earlier nine-wallet investigation. All 26 `Claim` calls in the recovered nine-wallet normal-transaction inventory and all 65 outgoing LUSD/USDC `Transfer` calls were read on ordinary public Etherscan transaction pages. Exact amounts and timestamps were independently parsed from rendered receipt text and checked against transaction hashes, block numbers, success status and visible token-contract links.

## Findings

The nine examined wallets received **21,944.778215493719293952 LUSD** in 26 claims from distributor `0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B`. Relative to the announced 30,000 LUSD campaign budget, this is **73.1493%**. These are executed token receipts, not estimated leaderboard entitlements.

| Claim date (UTC) | Claims | Actual LUSD received | Share of announced 10,000 LUSD epoch | Collector |
|---|---:|---:|---:|---|
| 2024-04-17 | 8 | 3968.390622853786468352 | 39.6839% | `0x425e16a88a0dacc38424b7d1f60868d728b46168` |
| 2024-04-24 | 9 | 8285.027398394077806592 | 82.8503% | `0x4e958cb8760f57792310f85aacde8a09ee51c65b` |
| 2024-05-01 | 9 | 9691.360194245855019008 | 96.9136% | `0x4e958cb8760f57792310f85aacde8a09ee51c65b` |

All **23 claimant-to-collector forwards** matched the preceding individual reward to its exact token amount. The delays range from **24 seconds to 13 minutes 12 seconds**. On each date, the collector’s own claim plus the verified incoming forwards equals the daily reward sum exactly. These are cumulative collection totals, not necessarily simultaneous retained balances: on May 1 the collector converted the first seven rewards before the final two arrived. This supports coordinated reward collection. A common human owner and any involvement of Laura remain unverified.

On April 24, the collector forwarded the entire nine-wallet reward total of **8,285.027398394077806592 LUSD** to `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` at **16:55:35 UTC** ([receipt](https://etherscan.io/tx/0xfab7c4bf93deb33f611a6180eba41e03a9284029a7f98ef59645fcb35fdf0b18)). This is the one additional collector-to-external-wallet transfer among the 24 reward-related forwarding receipts.

The 26 claim transactions cost **0.056352043156767145 ETH** in gas. The 24 reward-related forwarding transactions cost **0.017782843288630924 ETH**. These costs exclude swaps, approvals and ETH funding/forwarding. No current explorer USD conversion was used as a historical gas valuation. Reward receipt totals are gross token payouts, not net trading profit.

## Scope and validation limits

The public partner report and company campaign analysis provide the announced budget and campaign context: [DeFi Collective campaign report](https://deficollective.org/blog/kaskade-campaign-report/) and [Kaskade campaign analysis](https://medium.com/@KaskadeFinance/kaskade-x-liquity-campaign-analysis-a0f0d48ee97f). The transaction facts below come from the separately inspected receipt URLs.

The claim dates, LUSD denomination, distribution contract continuity and exact April 24 agreement with the nine leaderboard entitlements support the campaign identification. This work did not independently inspect distributor administration or establish who controlled its keys. It does not identify the natural persons behind any wallet.

This covers every inventoried claim and outgoing stablecoin Transfer call for the selected nine wallets. It does not cover every campaign participant, every possible incoming ERC20 transfer from outside the cluster, internal transactions, all chains or every token. Account normal-transaction history alone does not enumerate ERC20 transfers sent to the wallet by external callers. The associated consolidated research handles swap receipts.

## All 26 claims

| UTC timestamp | Recipient | LUSD | Receipt |
|---|---|---:|---|
| 2024-04-17T14:25:11Z | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 1241.003985277064839168 | [0x11138bc1de…](https://etherscan.io/tx/0x11138bc1decf900708d398e84a58758dad64bd18b5828280c292e1eaee53daf7) |
| 2024-04-17T14:28:11Z | `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` | 386.799056455249362944 | [0x100eabbf75…](https://etherscan.io/tx/0x100eabbf75e5dbbba6bbfb66dfeeb1a6fb3638fcd09371f71c115f507b597ed9) |
| 2024-04-17T14:32:11Z | `0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D` | 156.153682279260585984 | [0x81e70e90f5…](https://etherscan.io/tx/0x81e70e90f5ebffd208f76c95e444a444d7a0c9aa700ae57e8a566188d5f0b1c6) |
| 2024-04-17T14:36:59Z | `0x9B0547b60FEe159e89E078Be824a76bCF5AfEbDA` | 190.983609369626345472 | [0x05c32e3f2b…](https://etherscan.io/tx/0x05c32e3f2b7847a1a2548389574632cfd97f2cb6fd12b8da68b823368a7efe9d) |
| 2024-04-17T14:40:47Z | `0x52AfBA2412e94F8556D0895be7925aE95Fe92f5d` | 184.404101275954511872 | [0x2d234dc6c6…](https://etherscan.io/tx/0x2d234dc6c66733923297900b79094e0f772f417fc8ec5824cb746e48290760c2) |
| 2024-04-17T14:47:35Z | `0x7737E76f84107161735955e5B0596e1fF9D6d122` | 436.948752670330650624 | [0x341ea5b690…](https://etherscan.io/tx/0x341ea5b69005ed1a3d1f8da81481c3f99f824b3540e59294ea3bc21a195bc0bc) |
| 2024-04-17T14:50:59Z | `0x97592b48E20d40a69eA7C597354acf7ED1FdEd47` | 643.546051125766914048 | [0xb2034515c4…](https://etherscan.io/tx/0xb2034515c4eafd96d8d23cb36e03d533f9e163fe2e1c4ae6f80cde525cb2094f) |
| 2024-04-17T14:58:59Z | `0x68d3D886643a0ABb6ab9B23006305260365F7F2f` | 728.55138440053325824 | [0x477f8db08d…](https://etherscan.io/tx/0x477f8db08dd74a614ad657b89a83146c5e11c726468e8e640f203ebf6be7bda8) |
| 2024-04-24T16:38:11Z | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 1493.023125078204219392 | [0xaa9219a39b…](https://etherscan.io/tx/0xaa9219a39b4fe7971043bcddbc447796fc94a7ebf0a1356996a7fe86bded4d92) |
| 2024-04-24T16:40:23Z | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 652.966274517348646912 | [0x9540d266e6…](https://etherscan.io/tx/0x9540d266e643db21b00e8ad01a93112ad338680c6fdc86a61dd710c688287688) |
| 2024-04-24T16:42:47Z | `0x68d3D886643a0ABb6ab9B23006305260365F7F2f` | 786.950998629660622848 | [0xf30bbfa644…](https://etherscan.io/tx/0xf30bbfa6443180b60340a7d1ae6347afdb583797ee7686d9df937551613c7ccd) |
| 2024-04-24T16:44:23Z | `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` | 1170.2736549072093184 | [0x502e4215d3…](https://etherscan.io/tx/0x502e4215d33af4817f95b57ef2b0ee6aaf246c78384bc71b010e75e63755538b) |
| 2024-04-24T16:45:59Z | `0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D` | 1673.901204330375446528 | [0x72153b8faf…](https://etherscan.io/tx/0x72153b8fafefa802c2f957c14c57c62d2444a6a6162de227f8ac7d86edcc19bb) |
| 2024-04-24T16:47:59Z | `0x9B0547b60FEe159e89E078Be824a76bCF5AfEbDA` | 774.521167663286255616 | [0x1efe6517d5…](https://etherscan.io/tx/0x1efe6517d5f37f0859334b1f119859cc084e73b2f4446832ed022f700a96f676) |
| 2024-04-24T16:49:59Z | `0x52AfBA2412e94F8556D0895be7925aE95Fe92f5d` | 961.89470044717940736 | [0x4231885154…](https://etherscan.io/tx/0x423188515436bf28837f7152ce18fc4a25dd5ef0cbc9b7bab9a21aeb48bb46cd) |
| 2024-04-24T16:51:23Z | `0x7737E76f84107161735955e5B0596e1fF9D6d122` | 514.368054341890277376 | [0xe96074a168…](https://etherscan.io/tx/0xe96074a168b89f07b8becb25e020433f36bd2ffdfaeb6ebcc9a9f815877086a1) |
| 2024-04-24T16:52:35Z | `0x97592b48E20d40a69eA7C597354acf7ED1FdEd47` | 257.12821847892361216 | [0xcdadb43d0e…](https://etherscan.io/tx/0xcdadb43d0e912bc8417a5bda11cbf92fdc30536a496b4b27ae1636534c480e7c) |
| 2024-05-01T12:24:23Z | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 1559.462885792425705472 | [0x653cba3106…](https://etherscan.io/tx/0x653cba3106379b4078e37825e83b2f6e4a03efe6b3b56f877b3f885a2b48112b) |
| 2024-05-01T12:25:47Z | `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` | 913.743550266616578048 | [0x98878c8706…](https://etherscan.io/tx/0x98878c870617ac53d0670030fd7c87bac6057b827edd827e8b0212c220b84205) |
| 2024-05-01T12:28:35Z | `0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D` | 1557.360440073788063744 | [0xb178e082c5…](https://etherscan.io/tx/0xb178e082c589da40435bdcda11e958f9e6a8b9f59c4933b1664008a6b6be434f) |
| 2024-05-01T12:29:59Z | `0x9B0547b60FEe159e89E078Be824a76bCF5AfEbDA` | 676.116675922589646848 | [0x0419fbe40c…](https://etherscan.io/tx/0x0419fbe40c1d219c5b139d71b5d594845e3d523b745508cff138a5479bc86946) |
| 2024-05-01T12:44:59Z | `0x52AfBA2412e94F8556D0895be7925aE95Fe92f5d` | 1190.838568173087752192 | [0xf642cd8691…](https://etherscan.io/tx/0xf642cd86917453a9edf04ae953d27624ba989b0127e53fc5d63fc43466448e49) |
| 2024-05-01T12:49:59Z | `0x7737E76f84107161735955e5B0596e1fF9D6d122` | 1989.248571837409656832 | [0x95801bd4d3…](https://etherscan.io/tx/0x95801bd4d343127a2a947c2c292d209039bb09a100320e8f772a5f8703980347) |
| 2024-05-01T12:53:47Z | `0x97592b48E20d40a69eA7C597354acf7ED1FdEd47` | 785.407408745505619968 | [0xf9f4bbff1f…](https://etherscan.io/tx/0xf9f4bbff1f921778117b3983919a685a09016352ffa35f290e2ead841296a23f) |
| 2024-05-01T14:44:59Z | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 566.138429357060784128 | [0x99beae6657…](https://etherscan.io/tx/0x99beae66575bd97db7e2aa54bb73b0df679a9157ab1766678088e7771c7b8949) |
| 2024-05-01T14:46:35Z | `0x68d3D886643a0ABb6ab9B23006305260365F7F2f` | 453.043664077371211776 | [0x1d9ef2e908…](https://etherscan.io/tx/0x1d9ef2e908777184da0e450f7e4d5b41f5013140dd5a0942ac52ffc6190fff05) |

## Reward forwarding

| UTC timestamp | Sender | Recipient | LUSD | Seconds after linked claim | Receipt |
|---|---|---|---:|---:|---|
| 2024-04-17T14:29:23Z | `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 386.799056455249362944 | 72 | [0x4e3f0a9506…](https://etherscan.io/tx/0x4e3f0a9506fff2898f77c386785e8a03079ac07e647601db4858110bb47b76b1) |
| 2024-04-17T14:32:59Z | `0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D` | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 156.153682279260585984 | 48 | [0xd6f6cb9c7c…](https://etherscan.io/tx/0xd6f6cb9c7c6d03266ee60bb188c45a1f70fb6d0b7ed38203ca4b10eed6a6d78a) |
| 2024-04-17T14:38:11Z | `0x9B0547b60FEe159e89E078Be824a76bCF5AfEbDA` | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 190.983609369626345472 | 72 | [0xac969e9319…](https://etherscan.io/tx/0xac969e9319a08d37dc3859cc024fde4354fd39258843da07d46afa9dc9c53b0e) |
| 2024-04-17T14:45:47Z | `0x52AfBA2412e94F8556D0895be7925aE95Fe92f5d` | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 184.404101275954511872 | 300 | [0xdab6e51c54…](https://etherscan.io/tx/0xdab6e51c54611db35405c9fdda4418af5155537547f10a5a386bed4e6e00963d) |
| 2024-04-17T14:48:23Z | `0x7737E76f84107161735955e5B0596e1fF9D6d122` | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 436.948752670330650624 | 48 | [0xee75d0829b…](https://etherscan.io/tx/0xee75d0829b731a91c40ef6b9b10e613f983996d8a06dd85274efdae7d42bd6af) |
| 2024-04-17T14:51:47Z | `0x97592b48E20d40a69eA7C597354acf7ED1FdEd47` | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 643.546051125766914048 | 48 | [0x40de1f2942…](https://etherscan.io/tx/0x40de1f2942b15335d0185504e5c54f0f7413e5f0e90ae865e1e323c5e64bd248) |
| 2024-04-17T14:59:35Z | `0x68d3D886643a0ABb6ab9B23006305260365F7F2f` | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | 728.55138440053325824 | 36 | [0xd54740d5df…](https://etherscan.io/tx/0xd54740d5dfb9c519c86f63d67e7a312810144c5c2939f48b5a6f8a18b55c797f) |
| 2024-04-24T16:41:11Z | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 652.966274517348646912 | 48 | [0x770b6908b3…](https://etherscan.io/tx/0x770b6908b393faad2cd84ee59c110dded4bfed1394a869819a40dbd2b5a99780) |
| 2024-04-24T16:43:11Z | `0x68d3D886643a0ABb6ab9B23006305260365F7F2f` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 786.950998629660622848 | 24 | [0x6438d15c6c…](https://etherscan.io/tx/0x6438d15c6c584b1dbc5ed8a03abffe8fc5fec698e570c2a30eaec939da338ac7) |
| 2024-04-24T16:44:47Z | `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 1170.2736549072093184 | 24 | [0xbd8d71aadd…](https://etherscan.io/tx/0xbd8d71aaddfdddb2edabaec1dd352facd630a2e92f8006855e797c480daf6538) |
| 2024-04-24T16:46:47Z | `0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 1673.901204330375446528 | 48 | [0x78a7ce6d2b…](https://etherscan.io/tx/0x78a7ce6d2b257336b22800142ff65ec7ad631f071527919e71382c2dac6ce6d8) |
| 2024-04-24T16:48:35Z | `0x9B0547b60FEe159e89E078Be824a76bCF5AfEbDA` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 774.521167663286255616 | 36 | [0xa62c94e5c7…](https://etherscan.io/tx/0xa62c94e5c725be4a023d3440b7e4d247031a0da0d1da10b26d31f29596b419f3) |
| 2024-04-24T16:50:23Z | `0x52AfBA2412e94F8556D0895be7925aE95Fe92f5d` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 961.89470044717940736 | 24 | [0x16a61a51b1…](https://etherscan.io/tx/0x16a61a51b14fd75a62a22e38876178c9a4343f090b6fe08a4447555cfd2660f9) |
| 2024-04-24T16:51:59Z | `0x7737E76f84107161735955e5B0596e1fF9D6d122` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 514.368054341890277376 | 36 | [0x58ad911c65…](https://etherscan.io/tx/0x58ad911c6516ebe7a6c90e5db7bb0b17efde8dcf415dd0239477b07593db2d94) |
| 2024-04-24T16:53:11Z | `0x97592b48E20d40a69eA7C597354acf7ED1FdEd47` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 257.12821847892361216 | 36 | [0xf31c59d5c1…](https://etherscan.io/tx/0xf31c59d5c157a1723864db6b00c15d975f58b1b72c57e6337b20df3496c74891) |
| 2024-04-24T16:55:35Z | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 8285.027398394077806592 | 1044 | [0xfab7c4bf93…](https://etherscan.io/tx/0xfab7c4bf93deb33f611a6180eba41e03a9284029a7f98ef59645fcb35fdf0b18) |
| 2024-05-01T12:26:35Z | `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 913.743550266616578048 | 48 | [0x9fa3ee4d42…](https://etherscan.io/tx/0x9fa3ee4d4258d810d4a5b6b7f70430a3f5bac51f26cb9d6dd11499c21116ca11) |
| 2024-05-01T12:28:59Z | `0x9D383C16F5645e9609FBf7ECD4b341CDFB87A97D` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 1557.360440073788063744 | 24 | [0x95b071cca2…](https://etherscan.io/tx/0x95b071cca246d333dd070e0989bd8e992ae14596f687f1f4fe69b24d9bfb859c) |
| 2024-05-01T12:43:11Z | `0x9B0547b60FEe159e89E078Be824a76bCF5AfEbDA` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 676.116675922589646848 | 792 | [0x67489f3b3d…](https://etherscan.io/tx/0x67489f3b3d75cc453f94c9b9709326f08b00499d9389f8664ed6f6829b5748c4) |
| 2024-05-01T12:45:59Z | `0x52AfBA2412e94F8556D0895be7925aE95Fe92f5d` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 1190.838568173087752192 | 60 | [0xeb8706b4b3…](https://etherscan.io/tx/0xeb8706b4b398446e7450bef2652c58179e5b66b31f81661edcb2af1f338357fc) |
| 2024-05-01T12:50:47Z | `0x7737E76f84107161735955e5B0596e1fF9D6d122` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 1989.248571837409656832 | 48 | [0x97cf7fa1f3…](https://etherscan.io/tx/0x97cf7fa1f3cbc2241288dbfbbed682c91808d5bbcb4db1b7c2d6cc27c434919a) |
| 2024-05-01T12:54:11Z | `0x97592b48E20d40a69eA7C597354acf7ED1FdEd47` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 785.407408745505619968 | 24 | [0x57c151f885…](https://etherscan.io/tx/0x57c151f8850f596ac493393d64a497e0019ce21d72fce0b030d438dcc011b174) |
| 2024-05-01T14:45:35Z | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 566.138429357060784128 | 36 | [0xfd5252cedf…](https://etherscan.io/tx/0xfd5252cedfb6e1807341b4dee7c4fed061311162e63f8dee9e5fa4765c309abf) |
| 2024-05-01T14:46:59Z | `0x68d3D886643a0ABb6ab9B23006305260365F7F2f` | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | 453.043664077371211776 | 24 | [0x3f1762fe61…](https://etherscan.io/tx/0x3f1762fe611a10807e76083317f922d78c83498215e87e55d425ff86f14dd34e) |

The April 24 collector onward transfer combines nine rewards; its interval is measured from the collector’s own claim and must not be described as a one-to-one forward of that individual claim.

## Complete outgoing stablecoin transfer extension

All **65** outgoing token Transfer calls in the normal-transaction inventory were inspected: **38 USDC and 27 LUSD**, spanning **2024-04-11 20:54:59 UTC to 2024-05-01 14:49:23 UTC**. There are **56 transfers within the nine-wallet set** and **9 transfers to outside addresses**. Total gas for all 65 is **0.045651376741191016 ETH**; this already includes the 24 reward-related forwarding transactions above.

| UTC timestamp | Sender | External recipient | Amount | Token | Receipt |
|---|---|---|---:|---|---|
| 2024-04-16T09:53:47Z | `0x97592b48E20d40a69eA7C597354acf7ED1FdEd47` | `0x64bc278b28DCdfC2F1cB2f90dc62e03e02D2f09a` | 39315.101548 | USDC | [0x5be5510ded…](https://etherscan.io/tx/0x5be5510ded619a15d5b8d8d12303e868716826e02b08cced24fe431342ffbaa5) |
| 2024-04-16T17:57:35Z | `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 19114.478439 | USDC | [0xfb8715163f…](https://etherscan.io/tx/0xfb8715163f381690b8e4958e3322cb3cedbc923820c4270b02e707a47ed9e0e8) |
| 2024-04-17T03:14:23Z | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 19063.269086 | USDC | [0x6a4a0565a7…](https://etherscan.io/tx/0x6a4a0565a7451a48699e579807a933fd4c4f5c622d9826434ca7310bb88db5d9) |
| 2024-04-17T15:05:35Z | `0x425e16a88a0dAcc38424B7d1F60868d728b46168` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 5577.847092 | USDC | [0xda3f14d416…](https://etherscan.io/tx/0xda3f14d41660d360519fc0926d4c032af8cb8213a16b086053d192131b4a6a72) |
| 2024-04-24T16:55:11Z | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 29902.00513 | USDC | [0x8635000d90…](https://etherscan.io/tx/0x8635000d9096eb112c75e06c61e593429b0e08305b036795542d61106e0e46d1) |
| 2024-04-24T16:55:35Z | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 8285.027398394077806592 | LUSD | [0xfab7c4bf93…](https://etherscan.io/tx/0xfab7c4bf93deb33f611a6180eba41e03a9284029a7f98ef59645fcb35fdf0b18) |
| 2024-04-24T16:58:47Z | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 8280.806398 | USDC | [0x26ccb436b5…](https://etherscan.io/tx/0x26ccb436b5e216974cabe40feec2acf2b4f0f656a9d3565d2ea7ae51482adca7) |
| 2024-05-01T14:00:35Z | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 31500 | USDC | [0x39f0f15bfb…](https://etherscan.io/tx/0x39f0f15bfb74755171f2ce6f8c31b4e7ad2deb45a32df93957b570bd76cff0f3) |
| 2024-05-01T14:49:23Z | `0x4E958Cb8760F57792310F85aacDE8A09Ee51C65b` | `0x3ac0030aAaef5962B94F5a0b0C2886CC810E8CAF` | 28684.929953 | USDC | [0x58c23da2f6…](https://etherscan.io/tx/0x58c23da2f6ce18843a67d08b8805b2a75e886d4ae466b63494019036e14bf773) |

The April 24 onward LUSD payment and subsequent 8,280.806398 USDC payment must not both be counted as fresh reward income without tracing the intervening incoming transfers/swaps. Outgoing transfer totals can contain the same capital multiple times.

## Reproducible evidence

- `kaskade_claims_expansion_raw.json`: rendered text and visible links for all 26 claims.
- `kaskade_claim_forward_raw.json`: rendered text and visible links for 24 reward-related forwards.
- `kaskade_claims_expansion_decoded.json`: exact decoded claims, forwards and Decimal arithmetic summaries.
- `kaskade_principal_transfer_raw.json`: remaining 41 outgoing stablecoin transfer receipts.
- `kaskade_all_stablecoin_transfers_raw.json`: combined 65 unique outgoing stablecoin transfer receipts.
- `kaskade_all_stablecoin_transfers_decoded.json`: all 65 exact decoded transfers.
- `kaskade_decode_claims.py` and `kaskade_decode_transfers.py`: deterministic parsers, transaction coverage checks, amount matching and reward consolidation assertions.

Run both parser scripts in this folder. Validation checks passed for 26 unique claims, 24 unique reward-related forwards, 23 exact individual reward matches, three exact collector reconciliations and complete coverage of all 65 inventoried outgoing stablecoin Transfer calls.
