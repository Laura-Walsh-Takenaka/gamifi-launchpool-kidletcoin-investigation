# Research Paper — RESEARCH-KID-NEM-2026-0905 — Verification Audit and Legal-Framework Addendum

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> This early legal working addendum contains provisional jurisdictional and app-participation framing. Read the later KidletCoin/NEM report and historical consent analysis for the corrected distinctions; no jurisdiction or requirement to use the Kidlet app is established merely by this early note.

**Subject:** KIDLETCOIN / NEM — Child Safeguarding, Adult Responsibility — Integrated Investigative Report (84 pp., 362 S-sources, L01–L29 legal register)
**Addendum date:** 5 September 2026
**Status:** Working addendum. Supersedes the legal framing of Chapters 4, 11 and 13 of the memorandum pending the edits in §9.

**Conventions.** The project's public "co-founder/CEO" was a child and is unnamed throughout. The adult subject is referred to by public professional role only. Nothing here asserts guilt; every legal statement is framed as *what a duty requires and what evidence would be needed to show it was breached*.

---

## 1. Bottom line

The memorandum's **factual backbone is sound; its legal superstructure is anchored in the wrong jurisdiction.** The documented facts — a Bangkok-based project fronting a ~10-year-old as CEO; the child's mother being the NEM Foundation Thailand Country Lead (later interim/Honorary Secretary and Council member); a June 2019 YouTube contest asking children aged 8–18 to install a crypto wallet and email name, age, email, location, wallet address and video link to the project's published submission mailbox for 20–30 KID and channel publication; a KID mosaic on NEM NIS1; a NEMPay-derived "Kidlet" wallet repo; the Foundation's wind-down — are all corroborated.

Three things are wrong or overbuilt:

1. **Jurisdiction.** The analysis leans on Quebec statutes and PIPEDA. The adult subject's own public statements place her origin in **Nova Scotia (Cape Breton)**, not Quebec, and her residence in Asia for ~13–14 years; the conduct occurred in **Thailand** under a **Singapore**-incorporated foundation. No Quebec nexus exists on the record. The Quebec Consumer Protection Act under-13 advertising ban and the one-year Quebec penal limitation are inapplicable; the PIPEDA "real and substantial connection" test is weak.
2. **"Collection is illegal."** No jurisdiction criminalises collecting children's information as such. Where rules exist they regulate *how* (notice, parental consent, necessity, security), attach to the operating organisation, and are enforced civilly or administratively. In Thailand in June 2019 there was **no data-protection statute in force at all.**
3. **Independence of the forensics.** The NIS1 on-chain findings, election tallies and wallet source-code defects could not be independently re-derived in this pass (NIS1 nodes/explorer JSON and raw GitHub files unreachable). They are *author-derived, not independently reconfirmed* — not false.

**Most important omission:** Thai and Singapore law, which are the actually applicable frameworks and which materially soften several of the report's theories.

**Honest characterisation of the case:** a child-targeted inducement; over-collection of identifying data with no parental step, no official rules and no privacy notice; run by adults who should have known better; promoting a token marketed as spendable that never was; promoted through a foundation whose officer had a disclosed family interest. That is a **serious safeguarding failure and a governance failure**. On the current record it is **not a provable crime**, and the one Thai criminal route that fits is petty and time-barred.

---

## 2. Verification of the memorandum's claims (A1–A10)

| # | Claim group | Status | Notes / discrepancy |
|---|---|---|---|
| A1 | Contest video 3ydvqwGaw0o, 2 Jun 2019; fields requested; 20–30 KID; 11 Jun deadline; six channel uploads | **Partly confirmed** | Child-fronted branding and contest concept corroborated. Verbatim description, exact video IDs/dates not re-opened (unverified, not contradicted). No winner/entrant publication located. |
| A2 | Curriculum PDF: GitLab project 18610512, created 6 May 2020, commit e9d3f30f by "D K"/@kln_nurv, 30 Jun 2020, SHA-256 9f81e9a9… | **Confirmed (project) / Partly (commit)** | Project live; "Created on May 06, 2020"; 2 commits, 3 branches. Commit hash, uploader, byte size and hash not re-pulled. |
| A3 | Origin/media: intro video 12 Oct 2018; THE STANDARD 14 Jun 2019; e27 interview; Techsauce 18 Jun 2019; NEM blog 28 Nov 2018; e27 "Singapore" tag | **Confirmed (substance)** | e27 URL slug indicates **20 June 2019**, not 21 June — correct. "Singapore" is a directory tag, not a registration. No ACRA or Thai DBD entity named KIDLET/KIDLetCoin located; Thai DBD check still incomplete. |
| A4 | Adult subject's roles: Thailand Country Lead; candidacy thread 20442; Reddit AMA; interim Secretary May 2019; director 13 Jun 2019 EGM; Honorary Secretary after 29 Aug 2019 AGM; ROI Council listing; IB article; @NEMofficial 11 Nov 2019; Techstars 2023 | **Confirmed, one correction** | She publicly states she is from **Cape Breton, Nova Scotia**, worked for the Nova Scotia Department of Education, speaks "some bad French". Foundation-update roles and Techstars listing plausible but not each re-opened. |
| A5 | 2018 election: 202 whitelisted, ≥148 voted; tallies; cutoff block 1,935,989; 32-wallet Binance cluster; 20-address slate; sensitivity tables | **Partly confirmed** | Candidate roster and mechanics confirmed via NEM's official candidate/voting guides. Tallies, cluster, cutoff hash and counterfactuals **not re-derived**. Label the "Laura would have won a Council seat" result as a modelled counterfactual. |
| A6 | Corporate/financial: UENs; wind-up dates; liquidators; 210M XEM vote; Q1-2019 and 2019 expense tables; 43% vs 27.3% | **Partly confirmed; arithmetic confirmed** | 1,848,635 / 6,770,159 = **27.3%**; 210,000,000 / 8,999,999,999 = **2.333%**; Q1 rows sum to 1,773,729.89; 2019 rows sum to 6,770,158 (US$1 rounding). Closure thread 25126 confirmed. UENs, liquidator names, ~$3.5M figure not re-opened. |
| A7 | On-chain NIS1: kidlet:kid parameters; 28 transfers; multisig configs; NBDCOH cosigning (358 actions, 5 KID transfers); twelve SEA payments; 210M tranches; name-bearing messages | **Not independently verifiable in this pass** | No NIS1 REST node or explorer JSON reachable (nem01.symbol-node.com:7890/7891, *.nem.ninja:7890, explorer.nemtool.com routes). Namespace-expiry arithmetic coherent: renewal at 2,652,960 + 525,600 blocks → expiry ~late Apr 2021. NIS1 mainnet still live (~5.77M height, Jul 2026). |
| A8 | Wallet: baconbkk/Kidlet at d8c2e9b3…; NEMPay fork; fingerprint password stored in Ionic Storage and console.logged; HTTP node list; com.kidletcoin.app 404 | **Partly confirmed** | Repo exists; NEMPay upstream (dgarcia360/NEMPay) confirmed, archived read-only Aug 2020. File-level defects not read in this pass. No public CVE/disclosure for NEMPay or Kidlet located. |
| A9 | Domain kidlet.io: created 17 Jun 2025; Namecheap; registrant country VN; pendingDelete; NXDOMAIN 5 Sep 2026; 2023 gambling subdomain | **Partly confirmed; live-state discrepancy** | A current fetch returned live project content, conflicting with "NXDOMAIN 5 Sep 2026". **Re-check DNS/RDAP before publication.** Original 2018 WHOIS not recovered. |
| A10 | Legal register L01–L29 | **Partly confirmed; framing wrong** | Instruments are real; Thai Digital Asset Decree (14 May 2018) confirmed with ready-to-use utility-token exemption. Quebec entries are of doubtful applicability (see §3). |

---

## 3. Gap findings (B1–B12)

**B1 — Jurisdiction premise (overreach confirmed).** Only Canadian tie on record: subject is Canadian, from Nova Scotia, long resident in Asia. No Quebec connection. Nova Scotia has no private-sector privacy statute; PIPEDA would apply only with commercial activity and a real and substantial Canadian connection, which the record does not show. **Action:** demote Canada to a conditional appendix; lead with Thailand and Singapore.

**B2 — Thai law (the report's "unassessed" gap).**
- *PDPA B.E. 2562*: published 27 May 2019; substantive Chapters deferred, then postponed by Royal Decrees (21 May 2020; 8 May 2021) to **1 June 2022**. No Thai data-protection duty applied to the June 2019 contest.
- *Child Protection Act B.E. 2546*: §§26–27 are the only Thai criminal provisions that fit the fact pattern (see §5). Penalties ≤3 months / ≤6 months → **five-year prescription → expired ~June 2024.**
- *Emergency Decree on Digital Asset Businesses B.E. 2561* (effective 14 May 2018): ready-to-use utility tokens not offered for fundraising are exempt from ICO-portal/SEC approval. KID was free, never sold → likely no breach.
- *Penal Code §§341–343 (fraud)*: see §5.2. Fails on the "property" element.
- *Labour Protection Act §44 / Civil & Commercial Code §§19–27*: unpaid child "CEO" title and token-rewarded contest are unlikely to constitute employment; the title has no legal effect if no juristic person exists.

**B3 — Singapore under-examined.** Companies Act s.156 (director's disclosure of interest) and s.157 (honesty/diligence) are the live governance questions for a Foundation officer whose family project the Foundation promoted. Charity/IPC status unverified — do not assume. Singapore PDPA 2012 and PDPC minors guidance apply only if a Singapore nexus beyond the e27 tag exists.

**B4 — Platform rules.** YouTube's contest policies (in force 2019) require Official Rules, a legally compliant privacy notice explaining use of personal data, compliance with applicable law, and a YouTube non-sponsorship statement. The recovered description had none. YouTube ToS age floor 13. Google Play Families policy tightened 29 May 2019 with a 1 Sep 2019 deadline for existing apps; YouTube "made for kids" followed the Sept 2019 FTC settlement. All platform-contract matters — takedown/strike, not offences.

**B5 — Twelve SEA payments.** Monthly `SEA/YYYY/MM/NN` references on a near-monthly cadence from the Foundation's SEA regional account are consistent with a **regional-lead stipend/expense stream**, not a KID grant. XEM amounts and fiat-at-date not retrieved. Absent an on-chain or documentary link to a KID transaction, reframe as ordinary regional payments; the current "reached the associated account" wording implies more than the evidence supports.

**B6 — Contest outcome.** No winner announcement, entrant video or cancellation notice located anywhere. State as "no evidence located", aggregate only.

**B7 — Regulatory/complaint record.** None found 2018–2026; contemporary coverage uniformly promotional.

**B8 — 2019 "Related parties" US$1,428,843.** No public breakdown; nothing ties it to Thailand or KIDLet. 43%-vs-27.3% discrepancy arithmetically confirmed.

**B9 — Wallet defect severity.** Unencrypted password in Ionic Storage + console.log is a real, well-understood 2018–19 Ionic/Cordova defect class (adb backup with allowBackup; rooted devices). Source not re-read here; no CVE; install counts unavailable. Credible but source-unverified in this pass.

**B10 — "D K / @kln_nurv".** No public professional identification located. Do not speculate.

**B11 — Market.** No exchange or aggregator ever listed NEM-based KID; the token had no market or fiat value. XEM ATH ~US$2.09 (Jan 2018); sub-cent by 2026. Per-date XEM/USD for the 210M tranches and SEA payments still to be tabulated.

**B12 — Internal-consistency items to reconcile.** NBDCOH KID position 698,940 vs inflows (699,000 + 1,000 + 10) minus outflows; "358 Foundation actions" vs 584 NBFOUND records; "545 outgoing" vs "354 cosigned after 27 Aug 2019"; education wallet "three-record history". Not shown wrong; show the arithmetic.

---

## 4. Is collecting children's information illegal "regardless of country"? — No.

There is no law, anywhere, that prohibits collecting information about children as such. Schools, clinics, sports clubs, toy companies and the platforms themselves collect children's names, ages, emails and locations lawfully every day. What is regulated — where it is regulated — is **how**: notice to the parent, parental consent, limiting fields to what is necessary, protecting the data.

- The rules are **national**, not global. COPPA (US) binds operators directed at US children or with actual knowledge of collecting from them; it requires parental consent and is enforced by the FTC through civil penalties (5-year limitation, 28 U.S.C. §2462). GDPR (EU) needs an EU establishment or targeting; UK DPA 2018 age 13; Singapore PDPA needs a Singapore organisation; PIPEDA needs Canadian commercial activity and connection.
- Where a rule applies, the breach is collecting **without the required notice/consent**, and the duty-bearer is the **operating organisation**, not the act of collection.
- **Thailand had no data-protection law in force in June 2019.** That is the absence of a rule, not a loophole.
- No evidence shows any entry was **received**. Every offence considered below requires a completed act against an identifiable child.

A report that states "illegal everywhere" will be dismissed by any regulator or counsel on the first page and will take the sound findings down with it.

### 4.1 Jurisdiction table — as at 2 June 2019 and as at 5 September 2026

| Jurisdiction / instrument | In force 2 Jun 2019? | Duty engaged by the fact pattern | Nature | Duty-bearer | Nexus on record | Status Sept 2026 |
|---|---|---|---|---|---|---|
| Thailand — PDPA B.E. 2562 | **No** (substantive chapters deferred to 1 Jun 2022) | None | — | — | Yes | N/A |
| Thailand — Child Protection Act §§26–27 | Yes | Inducing a child to act for another's benefit; disseminating child information for benefit/damage | Criminal (petty) | Any person | Yes | **Time-barred (~Jun 2024)** |
| Thailand — Penal Code §§341–343 (fraud) | Yes | Deception obtaining property; aggravated if victim is a child | Criminal | Any person | Yes | Fails "property" element; §341/342 compoundable (3-month complaint) |
| Thailand — Digital Asset Decree B.E. 2561 | Yes | Token issuance/ICO | Admin./criminal | Issuer | Yes | Likely exempt (free utility token, no sale) |
| Singapore — Companies Act ss.156–157 | Yes | Director conflict disclosure re Foundation promotion | Regulatory | Director | Yes (Foundation) | Governance question; not a child-data offence |
| Singapore — PDPA 2012 | Yes | Consent for minors' data | Administrative | Organisation | Weak (e27 tag only) | Unlikely to apply |
| US — COPPA 16 CFR 312 | Yes | Parental consent; §312.7 prize over-collection | Civil (FTC only) | Operator | None shown | 5-yr limit expired 2024 |
| Canada — PIPEDA | Yes | Consent, necessity | Civil | Organisation | None shown | Inapplicable on record |
| Quebec — CPA §§248–249; P-39.1; Code of Penal Procedure | Yes | Under-13 advertising; collection | Provincial penal | Enterprise | **None** | Inapplicable; 1-yr limit long expired |
| EU/UK — GDPR Art. 3/8; DPA 2018 | Yes | Child consent | Administrative | Controller | None shown | N/A |
| YouTube contest policies / ToS | Yes | Official Rules; privacy notice; age 13 | Platform contract | Channel owner | Yes | Likely breached; not a law |

---

## 5. Thailand — the applicable criminal provisions, tested against the record

### 5.1 Child Protection Act B.E. 2546 (2003)

Text (Council of State English translation): *"Section 26. Under the provisions of other laws, no person shall, irrespective of the consent of a child, act as follows: (1) act or omit to act in any manner which tortures the child physically or mentally; … (3) force, threaten, induce, encourage or allow a child to adopt behaviour and manners which are inappropriate or likely to be the cause of wrongdoing; … (6) use, employ or ask a child to work or act in such a way that might be physically or mentally harmful, affect the child's growth or hinder development; (7) force, threaten, induce, encourage, consent to or act in any other way that results in a child … performing any act for commercial purpose in a manner which hinders development or is cruel/exploitative …"*
*"Section 27. No person shall advertise or disseminate through the mass media or any information technology any information on a child or the child's guardian, with the intention to cause damage to the mind, reputation, prestige or other interests of the child, or for seeking benefits for oneself or others in an unlawful manner."*

Penalties: §26 — up to 3 months' imprisonment or 30,000 baht or both (§78); §27 — up to 6 months or 60,000 baht or both (§79).

**Fit.** Fronting a ten-year-old as a business "CEO" in media and events, and inviting children to make and submit videos for token rewards, are arguable §26(3)/(6)/(7) facts. Publishing entrants' videos for the project's benefit is an arguable §27 fact — but no publication has been found. Consent of the child is no defence (§26 opening words); the parent can be the actor.

**Prescription.** Penal Code §95(4): five years for offences punishable with imprisonment of over one month up to one year. Both §26 and §27 fall in that band. For conduct in June 2019, prosecution was **barred by approximately June 2024.** The child-CEO promotion (2018–2019) is barred on the same reasoning.

### 5.2 Penal Code §§341–343 (cheating and fraud) — the "token with promised value" theory

*§341:* whoever dishonestly deceives a person by asserting a falsehood or concealing facts that should be revealed, and **by that deception obtains property** from the deceived person or a third person, or causes them to execute/revoke/destroy a document of right — up to 3 years. *§342(2):* aggravated (up to 5 years) where the offender takes advantage of the lack of intelligence of a deceived person who is a child. *§343:* public fraud (assertion to the public) — up to 5 years, non-compoundable. *§348:* all other offences in the chapter are compoundable → complaint within 3 months of knowledge (§96).

**Why it fails on the current record:**
1. **Property.** A video file, a name, an email address and a location are not "property" obtained by deception in the Thai sense; no child or parent paid money; no KID was ever sold for money.
2. **Knowing falsehood at the time.** The contest promised 20–30 KID, not baht. The broader "1 KID = one hour of work, store to follow" marketing was a statement of intention. Fraud requires proof the maker knew redemption would never exist; a failed startup is not fraud without that proof.
3. **Procedure.** §341/342 are compoundable; a complaint was required within three months of an injured person learning of the offence and offender.

### 5.3 What is *not* engaged
- Computer Crimes Act B.E. 2550 — targets unauthorised access, false data entry, etc.; nothing in the fact pattern.
- Labour Protection Act §44 — no employment relationship shown.
- Digital Asset Decree — free, never-sold utility token; SEC approval regime not triggered on the record.

---

## 6. The COPPA fit — and its limits

16 CFR §312.7 prohibits conditioning a child's participation in a prize or activity on disclosing more personal information than is reasonably necessary. That rule describes the KIDLet contest almost exactly (name, age, email, **location**, wallet address and video demanded from all entrants before selection). But COPPA (i) binds only operators directed at US children or with actual knowledge of US child users — none shown; (ii) is enforced civilly by the FTC, with no private right of action and no criminal liability; (iii) has a five-year limitation that closed in June 2024. YouTube's own COPPA duties (Sept 2019 FTC settlement) do not extend to a channel owner's off-platform email solicitation.

---

## 7. What would change the analysis (evidence thresholds)

Any one of the following moves this from "reckless design" to a live claim:

1. **A verified entrant** — especially in the US, EU or Singapore — with evidence the video or details were received, stored or published.
2. **Publication of any child entrant's video** on the project channel or elsewhere (→ Thai §27 facts; image-rights claims; though §27 is time-barred, civil claims by the child/parent may not be).
3. **Any sale of KID for money** to parents or others (→ "property" element for §§341–343; Digital Asset Decree re-analysis).
4. **A contemporaneous representation that KID was redeemable for cash or goods at the time of the contest**, coupled with evidence no redemption capability existed or was intended.
5. **Continuing or later conduct** (post-2021) that restarts a prescription clock.

Absent these, the accurate characterisation is: serious safeguarding and governance failure; no provable offence on the current record; the one fitting Thai criminal route is petty and time-barred.

---

## 8. Attribution

The public record establishes the adult subject's **involvement** in the project (business-logic work, recruiting helpers, wallet-release discussion, curriculum planning, promotional appearances) and, as the parent, an evident role in the child's public appearances. It does **not** establish who authored the contest terms, controlled the project's published submission mailbox, selected the requested fields, approved publication, or received any entry. Parental status, project involvement and a Foundation title do not, alone, prove any of those acts. The memorandum's own §12 lists the records that would; none is public. **No attribution of an offence to a named individual should be made or implied without them.**

---

## 9. Required edits to the memorandum

1. **Retitle and re-anchor Chapter 11** as a Thai-primary analysis (§§26–27 CPA; §§341–343 Penal Code; PDPA timing; Digital Asset Decree), with Singapore Companies Act ss.156–157 for the Foundation. Move Canada/Quebec to a conditional appendix ("if a Canadian nexus were established") and delete Quebec-specific exposure.
2. **Correct the subject's origin** to Nova Scotia (Cape Breton) per her own public statements; remove any Quebec inference.
3. **Add the prescription findings**: Thai CPA §§26–27 barred ~June 2024; COPPA barred June 2024; Quebec one-year rule long expired and inapplicable.
4. **Executive assessment**: state plainly that no evidence shows any child's data was received, stored or misused, that no winner was published, and that KID had no market value; frame the concern as *design and exposure*, not demonstrated harm.
5. **Chapter 8 (SEA payments)**: reframe as ordinary regional-lead payments unless a KID link is shown; add XEM amounts and fiat-at-date.
6. **Chapters 6–7 (NIS1 forensics, election)**: label "author-derived, not independently reconfirmed" until raw node JSON is appended; publish the reconciling arithmetic for B12 items.
7. **Chapter 9**: quote the offending source lines verbatim from the pinned commit or mark as unverified.
8. **Chapter 10**: re-verify kidlet.io DNS/RDAP and reconcile with the live-content fetch.
9. **Chapter 5**: replace any concealment/self-dealing connotation with "disclosed family-linked conflict of interest"; route the governance critique through s.156.
10. **e27 date**: 20 June 2019.
11. **Keep the child unnamed and unidentifiable** in every version.

---

## 10. Limits of this addendum

- NIS1 node/explorer JSON, raw GitHub source at the pinned commit, RDAP endpoints, and the nem-anz election-results article were unreachable in this pass. Claims depending on them are "unverified", not "false".
- Thai statutory text is taken from Council of State / Ministry of Education English translations; the Thai text is authoritative.
- Prescription conclusions assume no interrupting event (no complaint, no prosecution) — none is on record.
- No child was identified or sought; no contact was made with any person or account.

---

## 11. Sources consulted in this addendum (retrieved 5 September 2026)

**Thailand**
- Child Protection Act B.E. 2546, Council of State translation — http://www.mekongmigration.org/labourlaw/images/labourlaw/pdf/thailand/51%20Child%20Protection%20Act.pdf ; MOE copy — https://www.moe.go.th/backend/wp-content/uploads/2021/02/809775_0001.pdf ; Childline Thailand copy — https://www.childlinethailand.org/wp-content/uploads/2019/09/Child-Protection-Act-BE-2546.pdf ; NATLEX record — https://natlex.ilo.org/dyn/natlex2/r/natlex/fe/details?p3_isn=82834
- CPA §§26–27 penalties (§§78–79) — https://wsrlawgroup.com/publications/law-library/thailand-civil-and-commercial-code/child-protection-act/
- Penal Code §95 prescription — https://library.siam-legal.com/thai-law/criminal-code-prescription-sections-95-101/ ; https://www.legal.co.th/resources/thailand-criminal-code/book1/general-provisions-title-i-provisions-applicable-general-offences-chapter-9-prescription/
- Penal Code §§341–348 fraud — https://library.siam-legal.com/thai-law/criminal-code-fraud-sections-341-348/ ; https://ptlegalconsult.co.th/en/law-en/criminal-case-en/
- PDPA B.E. 2562 (MDES) — https://www.mdes.go.th/law/detail/3577-Personal-Data-Protection-Act-B-E--2562--2019- ; 2021 postponement decree (ETDA) — https://www.etda.or.th/getattachment/33f1c767-6339-41da-8309-97569ed4ef4a/PDPA-2021.aspx
- Emergency Decree on Digital Asset Businesses B.E. 2561 — Thai SEC (confirmed effective 14 May 2018 in research pass; pin official URL before publication)

**Platforms**
- YouTube contest policies and guidelines — https://support.google.com/youtube/answer/1620498
- Google Play Families policy announcement (29 May 2019) and YouTube "made for kids" (Sept–Nov 2019) — as cited in memo S295, S297

**Project / subject public record (as cited in memo)**
- NEM forum candidacy — https://forum.nem.io/t/laura-takenaka-for-secretary-council/20442
- NEM official blog interview stating Cape Breton / Nova Scotia origin — retrieved in research pass; **pin exact URL before publication**
- NEM Foundation updates May/Jun/Sep 2019 — forum.nem.io threads 22634, 22980, 23549; 2019 ROI — 24550; closure — 25126
- e27 interview (20 Jun 2019), Wayback 21 Jul 2019 — memo S003
- GitLab curriculum project — https://gitlab.com/api/v4/projects/18610512
- Kidlet wallet repo — https://github.com/baconbkk/Kidlet ; upstream — https://github.com/dgarcia360/NEMPay
- NIS1 API reference — https://nemproject.github.io/ ; node list — https://nemnodes.org/

**Other**
- 16 CFR Part 312 (COPPA, 2013 rule) — memo S327; 28 U.S.C. §2462
- Singapore Companies Act ss.156–157 — Singapore Statutes Online (pin URL)
