# Research Paper — Full returned-history XEM link screen

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

This analysis screened all **2,126 normalized transfer rows and 2,275 unique normalized records** already collected on September 5, 2026. It selected **936 positive explicit XEM transfers** touching the 14-wallet project register, including **42 transfers between register wallets**. It did not merely re-read the 49 previously selected block checks. It is an analysis of that preserved collection, not a fresh node refresh.

This register contains dedicated KID infrastructure and mixed-use signer/issuer accounts. Its historical XEM activity is not a KidLetCoin income statement. External destinations below are observed through register wallets, not fully traced recipient histories.

## New findings relative to the earlier live-recheck report

1. **A second explicit operational XEM link:** the shared signer sent **1,000 KID to NBXPW6… on June 23, 2019**, then **5 XEM to the same wallet on June 30**, message **“xem for transactions.”** The XEM message supports transaction-cost assistance to a KID recipient. There is no label identifying a child, contest prize, purchase or investor.

| UTC and basis | From → to | Amount | Public message | Transaction |
|---|---|---:|---|---|
| 2019-06-23T05:50:36+00:00 (created) | NBDCOH… → NBXPW6… | 1000 KID |  | [9143808ab06f…](https://explorer.nemtool.com/#/s_tx?hash=9143808ab06f768b87ec48e1238bc49aa0fe7383f3c1a414d4d5a4e7f6ad453e) |
| 2019-06-30T09:38:56+00:00 (created) | NBDCOH… → NBXPW6… | 5 XEM | xem for transactions | [fc2429fe7434…](https://explorer.nemtool.com/#/s_tx?hash=fc2429fe7434ddc0b1df92de7754a8cdc1312997cd5504035c744c587a9ad5dc) |

2. **Contemporaneous name wording strengthens the existing address association:** an April 22, 2019 outgoing transaction from NBDCOH… says **“for necklaces L Takenaka.”** This is more specific than the generic later “Laura” messages used in the earlier discussion. It remains a wallet-authored statement; it does not identify the keyboard user, prove exclusive wallet ownership or assign contest administration. A different November 2021 outgoing LYL message references **“Laura Walsh BSC”**, which also warns against treating every named message as a verified wallet-owner record. The unrelated purchase amount and later cross-chain address should not be presented as KID spending or investigated personal holdings.

Contemporaneous reference: [450986a4ebff…](https://explorer.nemtool.com/#/s_tx?hash=450986a4ebff4b6bdf3ec870d208e341404dc32b97767b55f38d711bfb983a14); creation UTC 2019-04-22T06:06:26+00:00, block height 2120120. Later reference: [095db539eeab…](https://explorer.nemtool.com/#/s_tx?hash=095db539eeaba5c0e4c75d838e8a0a84062dbdb4bcfaab176df612b7690ceaf0).

3. **An additional exact shared-reference link:** on October 4, 2018, the issuer sent **20,000 XEM** and its cosigner NBLIIT… sent **4 XEM** to NDOYB… with the same reference **166NEMCHANGEDOTCOM166**. This links two sending accounts to one destination/reference before the first KID distribution. Service identity and common beneficial ownership remain unresolved.

| UTC and basis | From → to | Amount | Public message | Transaction |
|---|---|---:|---|---|
| 2018-10-04T04:25:49+00:00 (created) | NC7HKO… → NDOYB2… | 20000 XEM | 166NEMCHANGEDOTCOM166 | [6b952ff29079…](https://explorer.nemtool.com/#/s_tx?hash=6b952ff29079baf2b584892e6c20fdcd2a6c8daa2891c4eb4c2f55259795d050) |
| 2018-10-04T04:33:58+00:00 (created) | NBLIIT… → NDOYB2… | 4 XEM | 166NEMCHANGEDOTCOM166 | [8127d29f7363…](https://explorer.nemtool.com/#/s_tx?hash=8127d29f736394a6e208824e1f2f211151d27a9d74dd3e3de3265c9a2c680a1f) |

4. **The ND2JRP… branch is broader:** all register histories contain **12 payments from four register wallets, totaling 1,463,032 XEM**, from 2018 through 2021. The earlier report highlighted only the 500,000/300,000-XEM pair at this destination. Different sending accounts also use distinct references; these are useful reconciliation leads, not proof of a single beneficial owner.

| UTC and basis | From → to | Amount | Public message | Transaction |
|---|---|---:|---|---|
| 2018-06-29T07:04:58+00:00 (created) | NCJHET… → ND2JRP… | 20000 XEM | f1b5d494fa99453fbd1 | [afa10d5b1439…](https://explorer.nemtool.com/#/s_tx?hash=afa10d5b1439f41ebc436751d60974a1d65feb44aa2999ea133ce1b434c509b0) |
| 2018-07-05T02:36:22+00:00 (created) | NCJHET… → ND2JRP… | 23000 XEM | f1b5d494fa99453fbd1 | [d91c6065a634…](https://explorer.nemtool.com/#/s_tx?hash=d91c6065a634085f2c947d585a11aaca76d96d3be0983b92e162ff61a6a08ba6) |
| 2018-08-29T10:37:12+00:00 (created) | NCJHET… → ND2JRP… | 10000 XEM | f1b5d494fa99453fbd1 | [f20ae6730270…](https://explorer.nemtool.com/#/s_tx?hash=f20ae67302702ea5ef4ef1586956c52279a7e7e68f776bfbfed02ae9e10dca40) |
| 2018-09-03T15:16:35+00:00 (created) | NCJHET… → ND2JRP… | 20000 XEM | f1b5d494fa99453fbd1 | [0b36cf65a666…](https://explorer.nemtool.com/#/s_tx?hash=0b36cf65a6660bcd073cc17d8fee454cc10bfaaa9599bfea98fa42bac6806f5a) |
| 2018-09-13T03:59:21+00:00 (created) | NCJHET… → ND2JRP… | 23000 XEM | f1b5d494fa99453fbd1 | [9656d6f8e3bb…](https://explorer.nemtool.com/#/s_tx?hash=9656d6f8e3bb0bd2b36facce4eb542787fbd2c104731d364a0cf24e56006a835) |
| 2019-03-06T03:42:31+00:00 (block) | NCEUKZ… → ND2JRP… | 500000 XEM | 37503ccaac214a018a2 | [905643ede832…](https://explorer.nemtool.com/#/s_tx?hash=905643ede8322b230f03f4b9cb36d0021e49dfdc7705af4d2d03e9a7ff69f1af) |
| 2019-06-06T10:15:21+00:00 (block) | NC7HKO… → ND2JRP… | 300000 XEM | 37503ccaac214a018a2 | [fa86f51c3f2a…](https://explorer.nemtool.com/#/s_tx?hash=fa86f51c3f2a88197aeac376e0f445c3d3bb11ada66163fdcb56aede39825b25) |
| 2020-09-02T04:43:00+00:00 (created) | NC7HKO… → ND2JRP… | 269903 XEM | 997c24d8d8d2475ca7e | [64a1ee070551…](https://explorer.nemtool.com/#/s_tx?hash=64a1ee070551457ee1498d2c17c4c29a0c4dc3c2099171231f7073ab12898e1a) |
| 2020-10-13T02:40:47+00:00 (created) | NC7HKO… → ND2JRP… | 287129 XEM | 997c24d8d8d2475ca7e | [b67702282e6f…](https://explorer.nemtool.com/#/s_tx?hash=b67702282e6f1180b4bbd965c1af05c34762df229b7c96f00a891bd5bd1f2337) |
| 2021-02-15T06:41:07+00:00 (created) | NCM2QK… → ND2JRP… | 100 XEM | 35f23a8d1ece435b9ff | [eb9426829922…](https://explorer.nemtool.com/#/s_tx?hash=eb94268299220ed2488f0dce0a8951da2a6487f776b8306c3d3c1fb216b04cd8) |
| 2021-02-15T06:56:54+00:00 (created) | NCM2QK… → ND2JRP… | 2900 XEM | 35f23a8d1ece435b9ff | [d1cf45224bb1…](https://explorer.nemtool.com/#/s_tx?hash=d1cf45224bb169fa282730465fba2d9eec63c6737fca0ab46f0672369e4a1299) |
| 2021-02-17T03:56:42+00:00 (created) | NC7HKO… → ND2JRP… | 7000 XEM | 997c24d8d8d2475ca7e | [591609c430d6…](https://explorer.nemtool.com/#/s_tx?hash=591609c430d6f462918eb0a3feb041fa05998447c04236d69838786ca09c8611) |

5. **Mixed-use receipts are directly visible:** **460 of the 936 XEM transfers** are issuer receipts explicitly labelled **“Node rewards payout”**, totaling **183,273 XEM**, from NCPAYOUTH2BGEGT3Q7K75PV27QKMVNN2IZRVZWMD. Their creation dates run from November 30, 2017 to February 25, 2020. Classification here follows the public message; the sender’s institutional identity and reward program are not independently authenticated in this subanalysis. The messages give a concrete reason not to describe every issuer receipt as KID financing.

First: [22cee1eedd69…](https://explorer.nemtool.com/#/s_tx?hash=22cee1eedd697a9d6995c1fd99b2b15aa8b7ebb400c7723d3c287345f896eef5). Last: [35e63395c541…](https://explorer.nemtool.com/#/s_tx?hash=35e63395c54112bbbd52ec798ba43a0f98dd9064f321f6138f1bf22ce54244f7).

## Regional receipts versus onward issuer payments

The 12 Foundation SEA→NBDCOH receipts total **221,287.57 XEM**. The nine NBDCOH→issuer payments total **151,894 XEM**. All these amounts and block timestamps were already corroborated in the earlier selected-block dataset.

The first eight onward payments, totaling **131,894 XEM**, follow six regional receipts between April and August 2018. The table matches each onward payment only to its nearest earlier regional receipt. That is a chronological match, not tracing of identical funds. Month descriptions and repeated low/high transfers are retained exactly.

| Earlier regional receipt, confirmed UTC | XEM in | Subsequent issuer payment, confirmed UTC | XEM out | Elapsed | Outgoing message |
|---|---:|---|---:|---|---|
| 2018-04-02T01:01:15+00:00 [c5a1f4ad908b…](https://explorer.nemtool.com/#/s_tx?hash=c5a1f4ad908bc5369a94d8eb0b8c114ef23b7488891d0f4d2b8bc39b6e9d98ff) | 18741.15 | 2018-04-05T06:24:27+00:00 [3af266b71eff…](https://explorer.nemtool.com/#/s_tx?hash=3af266b71effdc825d436ad3212bd6d1c0675d7f6e16612566888846c4485833) | 17237 | 3 days, 5:23:12 | calculated at .23 for 4000 USD |
| 2018-05-02T20:57:12+00:00 [2ed3f7641c2b…](https://explorer.nemtool.com/#/s_tx?hash=2ed3f7641c2b250411ace074f73a922fba5e0c977cecc83ad22f7d0b5914ff50) | 18669.21 | 2018-05-03T10:47:42+00:00 [acb192c08b5b…](https://explorer.nemtool.com/#/s_tx?hash=acb192c08b5ba0a4ac9c1cead2e2513d13307c2d2f476d7ed6e1b9a016748036) | 16000 | 13:50:30 | For April |
| 2018-05-04T16:40:21+00:00 [eea5afcb38af…](https://explorer.nemtool.com/#/s_tx?hash=eea5afcb38af846b23be953af89094bc045c88be795a2f2a823a4d4430ff38a7) | 9440.73 | 2018-05-09T03:43:18+00:00 [30e66565ba38…](https://explorer.nemtool.com/#/s_tx?hash=30e66565ba38f30eb652b0c9727d6435bd8eb66297a92151643426e3c3134afb) | 8602 | 4 days, 11:02:57 |  |
| 2018-06-05T15:12:19+00:00 [61ad8fb01cf1…](https://explorer.nemtool.com/#/s_tx?hash=61ad8fb01cf16baae8313bda9fbbe662298e705f2b6badee48dee83fc6ffef70) | 21910.45 | 2018-06-06T00:39:26+00:00 [3fe28026c74c…](https://explorer.nemtool.com/#/s_tx?hash=3fe28026c74c7acd7b6dbd684a406847a58475feedd93a04dc9eae4dee82c750) | 20 | 9:27:07 | May |
| 2018-06-05T15:12:19+00:00 [61ad8fb01cf1…](https://explorer.nemtool.com/#/s_tx?hash=61ad8fb01cf16baae8313bda9fbbe662298e705f2b6badee48dee83fc6ffef70) | 21910.45 | 2018-06-06T00:40:02+00:00 [458626ca4b91…](https://explorer.nemtool.com/#/s_tx?hash=458626ca4b91c359bb48001bdc1cea5375e3a65049e9eb8f4d5601dbd4700ea1) | 20000 | 9:27:43 | try try again |
| 2018-07-08T19:50:59+00:00 [49025cd0e439…](https://explorer.nemtool.com/#/s_tx?hash=49025cd0e4395158046b70ad795bbf4fa08a4fa4dbbf6b08243901925ec0bfde) | 35388.31 | 2018-07-10T05:26:39+00:00 [67938e13bba3…](https://explorer.nemtool.com/#/s_tx?hash=67938e13bba37117f3026966309e1675e74f0956587ab4dd36b1d717bf8be513) | 35 | 1 day, 9:35:40 | June |
| 2018-07-08T19:50:59+00:00 [49025cd0e439…](https://explorer.nemtool.com/#/s_tx?hash=49025cd0e4395158046b70ad795bbf4fa08a4fa4dbbf6b08243901925ec0bfde) | 35388.31 | 2018-07-10T05:27:09+00:00 [a570b1c7a518…](https://explorer.nemtool.com/#/s_tx?hash=a570b1c7a5186d69c317fb9035426d56ee00f3fcf5dd587f1e15619d22025285) | 35000 | 1 day, 9:36:10 |  |
| 2018-08-07T15:48:23+00:00 [a776693d646f…](https://explorer.nemtool.com/#/s_tx?hash=a776693d646f0fd382841995155469eeea88d575ee9e472e66332acfb236c8b5) | 37208.64 | 2018-08-13T04:18:34+00:00 [da3106f872d9…](https://explorer.nemtool.com/#/s_tx?hash=da3106f872d94a731f332f3ef7e340c5ed139de8236e1f1051463f8f9df245be) | 35000 | 5 days, 12:30:11 |  |
| 2019-02-13T07:15:46+00:00 [b9b1e216d270…](https://explorer.nemtool.com/#/s_tx?hash=b9b1e216d270e216652d02eba9fc12f0cbce67689c96c4efd41c7778eaebb890) | 601.3 | 2019-03-20T04:36:50+00:00 [d0d92edcccce…](https://explorer.nemtool.com/#/s_tx?hash=d0d92edcccce440102022115588e7aaf67a63e8fbb0b578a0b3d616b19719a1e) | 20000 | 34 days, 21:21:04 |  |

June 6 has a 20-XEM transfer followed **36 seconds later** by 20,000 XEM; July 10 has a 35-XEM transfer followed **30 seconds later** by 35,000 XEM, using confirmed block times. Both transfers in each pair remain genuine separate ledger entries; the amounts have not been silently corrected or multiplied.

The last 20,000-XEM issuer payment on March 20, 2019 follows a nearest regional receipt of only 601.3 XEM more than 34 days earlier. That pair must not be portrayed as a matched 20,000-XEM Foundation remittance.

A different branch follows the September 11, 2018 regional receipt of 55,996.8 XEM: the shared signer sends 40,000 XEM to NC64UF… on September 12. That outward transfer was in the previous selected ledger. It is another temporal branch to reconcile, not a KidLetCoin grant or proven cash-out.

## Dedicated KID wallets

The staging/distributor/development/education group has six positive explicit XEM transfers in total: 10 and 100 XEM into staging; 108 XEM staging→distributor; 100+100 XEM into development; 100 XEM into education. All senders are register wallets. There are no direct external positive-XEM receipts into those four dedicated wallets in the collected histories. This does not include off-chain payments or establish the absence of financing through the mixed-use issuer.

## Data and provenance

`xem_links.json` retains every internal XEM transfer, 14 shared external destinations with sender/reference splits, both exact shared-destination/reference groups, the nine regional/issuer chronological pairings, full expanded ND2JRP records, operational/name message references, and all 936 selected hashes. `xem_links_verification_targets.json` lists the new high-priority exact-block checks.

Amounts use Decimal arithmetic and exclude zero-amount messages, zero-signature protocol records, fees and levies. Non-XEM asset quantities lacking verified decimal metadata are not silently valued. All dates state confirmed-block versus creation-time provenance. Public names and references are message contents, not identity findings.
