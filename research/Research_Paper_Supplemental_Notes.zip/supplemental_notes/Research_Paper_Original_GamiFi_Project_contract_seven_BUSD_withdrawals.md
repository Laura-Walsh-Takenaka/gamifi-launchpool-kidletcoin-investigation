# Research Paper — Original GamiFi Project contract: seven BUSD withdrawals

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Verified 7 September 2026 UTC. Scope: original BSC Project proxy `0x56c0cb2d047b69278f49b4759c1718436a546c7f`, seven selected March–June 2022 payments totaling **63,001.817377359365034843 BUSD**. This is a technical/payment-purpose evidence lane; named human authority and commercial entitlement require additional evidence.

## Firm result

All seven payments used the contract's implemented `withdrawFunding(uint256)` function. Historical calls at the preceding block and withdrawal block show the full recorded funded amount going to the configured recipient, after the configured funding end, while `isWithdrawnFund` changes from false to true. The implementation address is unchanged across each adjacent-block pair. These results support normal designed withdrawal mechanics; they do not establish that the receiving party was commercially entitled to retain the funds, fulfilled customer obligations, or had a particular human controller.

The March source uses **onlyOwner**. The later source permits **owner or enabled admin**. Current GitHub main source is a different revision and must not be used as the original contract's exact ABI.

## Historical authority and receiver results

| Project | Withdrawal date UTC | BUSD | Caller authority at preceding block | Owner at preceding block | Configured recipient |
|---|---|---:|---|---|---|
| 1 | 10 March 2022 | 252.5 | Owner: 8fea…c2a0 | 8fea…c2a0 | 8fea…c2a0 |
| 3 | 11 March 2022 | 110 | Owner: 8fea…c2a0 | 8fea…c2a0 | 8fea…c2a0 |
| 7, Time Raiders | 18 March 2022 | 23,722.715761539594859905 | Owner: 3e0f…7199 | 3e0f…7199 | d2b8…6171 |
| 6, GAMI | 18 March 2022 | 28,421.141280969119319259 | Owner: 3e0f…7199 | 3e0f…7199 | 56aa…9aa2 |
| 4 | 23 March 2022 | 2,000 | Owner: 3e0f…7199 | 3e0f…7199 | 35b1…b5f3 |
| 8, original FOMO | 23 May 2022 | 3,775.228767123287671432 | Enabled admin: 3e0f…7199 | 14cc…b412 | 56aa…9aa2 |
| 9, ShibaFriend | 22 June 2022 | 4,720.231567727363184247 | Enabled admin: 3e0f…7199 | 14cc…b412 | 56aa…9aa2 |

Full addresses, transaction hashes, exact sampled blocks and decoded state are in `funding_state_verified.json`; parent evidence `seven_withdrawals_verified.json` contains successful receipts and actual BUSD Transfer logs. Technical owner/admin status is not a business mandate, signed instruction, identity attribution or finding of wrongdoing.

## Independently verified deployed source

The two implementations were obtained from Sourcify, compiled locally using official Solidity 0.8.4 (`0.8.4+commit.c7e474f2`), optimizer enabled with 200 runs, and compared with RPC bytecode. **Every runtime byte, including compiler metadata, matches**:

| Implementation | Relevant payments | Runtime bytes | Historical code independently checked |
|---|---|---:|---|
| `0xfa83e6a35d98e5243cd3e5740b6f52daa316c075` | All five March payments | 14,983 | Block 15,940,531 |
| `0xed2f3357813fb4796ce5da11ea8054ae0f2d22c8` | May and June payments | 15,877 | Block 18,051,155 |

Both also match freshly fetched current code. `code_match.json`, `funding_start_configuration.json`, exact compiler inputs/outputs, source records, and raw RPC envelopes preserve this validation. The compiler's SHA-256 was verified against the Solidity project's official build list before execution. No on-chain transaction was submitted.

Primary source URLs:

- https://sourcify.dev/server/v2/contract/56/0xfa83e6a35d98e5243cd3e5740b6f52daa316c075?fields=all
- https://sourcify.dev/server/v2/contract/56/0xed2f3357813fb4796ce5da11ea8054ae0f2d22c8?fields=all

The independently compiled code has three consequences for reading payments correctly:

1. `withdrawFunding` transfers recorded BUSD financing to the stored project recipient; it has no receipt/invoice/bank-account validation or customer-delivery condition.
2. `setFundingReceiver` lets the authorized contract controller change a project's recipient. That is a designed power, whose business authorization is a separate question.
3. `claimBack` pays a participant's recorded **staked GMI**, not a BUSD financing refund. A GMI `ClaimBack` event must not be counted as customer BUSD repayment.

## Configuration at each sampled funding start

Six recipients match the configuration at the start block stored immediately before withdrawal. **Project4 differs:** its recipient at block15,963,600 was8fea…c2a0, while its pre-withdrawal recipient was35b1…b5f3. The controller `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199` successfully called `setFundingReceiver(4, 0x35b119730f79881dac623dc51c831c6a04cab5f3)` on23March2022 at14:56:37UTC, transaction `0x39f7777f43b5155f7238fa822d796206ddcd74e0b27481c78f33b7debf00f8cc`, block16,311,897, sender nonce117. **Exactly90seconds later**, the same key used nonce118 to withdraw the2,000BUSD to that new recipient. Raw event, independent successful receipt and calldata are in `id4_receiver_change.json`. This proves an intentional recipient reassignment, but does not identify its human authorizer or commercial purpose.

For projects1,3,4,7,8,9 the sampled start state had zero recorded funding. Project6 already recorded26,761.141280969119319108BUSD at its sampled configured start block16,135,649; therefore do not call this sample the first time funding opened. Its schedule could be reconfigured through the owner function. No all-history schedule census was performed here.

These are snapshots, not proof no intermediate receiver change ever occurred. They are useful for testing last-minute diversion theories; full commercial instructions remain separate evidence.

## Unidentified small offerings: funding events

Projects1,3,4 each had a300-block funding window in the verified historical configuration, unlike the longer named campaigns. This is an observation, not proof they were internal tests.

- Project3:2 funding events totaling110BUSD. `0xd697c0eda3bde7fd89f897baf1f5b1cc7a2fc895` supplied100BUSD; `0x9f3cbb6fd7d9583db18f41addd6e12e84d10ee00` supplied10BUSD. Both also appear in the parent's project1 funding-event set.
- Project4:1 funding event totaling2,000BUSD from `0x391a51d884b240908a88e1e757ec42189d294423`, tx `0x553cf2385ef6d40f35e589accd89be0129ee78ff4e1ce3edae423700ce27a288`, block15,963,753. All three project3/4 contribution receipts were independently re-fetched fromBinance; status, full event and block hash match the archive results. See `small_funding_receipt_crosscheck.json`.
- Project1: parent independently recovered6 events from4 distinct funding addresses totaling252.5BUSD in *Historical file: id1_funding_logs.json*.

`small_funding_events.json` preserves the complete two narrow queries, events and sums. Contribution size, brief windows and shared funders do not identify their humans or establish testing, genuine outside investment, self-dealing, or a refund.

## ABI corrections useful to other evidence lanes

The original `getUserInfo(uint256,address)` selector is `0x1069f3b5`. The seven returned words are: whitelist flag; GMI claim-back flag; staked GMI amount; **funded BUSD amount at zero-based index3**; token allocation amount; allocated portion; used membership card.

The original `CreateProject` event omits the later `tokenDecimals` field. Correct event topic: `0x61c5ab964c146422bc580b997f568d2f635183d40c9780499fdf591db709c1fb`. Correct `SetFundingReceiver(uint256,address)` topic: `0xbfcc5f1dcfe8a26eada10c8163c41f27b60fdd5b9054a1a56420226201273443`. Funding topic is unchanged from the parent selector file.

## Access limitation in ancillary batch-contract check

The later transfer contract `0x4867171d50f734c34b020c45df23133cab5793a6` had no Sourcify entry at the queried endpoint (404). Direct BscScan source retrieval returned403; web open also failed. No source/ABI match for that address is claimed. Successful token Transfer receipts and exact historical depositor/repayment reconciliation are independently useful without guessing that contract's method name.

## Packaging note

Include JSON/Solidity/Markdown/Python records and raw RPC envelopes. The downloaded `solc-0.8.4` executable is only a local tool and can be excluded; `compiler_provenance.json` preserves its official URL and verified SHA-256. Do not substitute this lane's in-progress scripts or partial query outputs for the verified result files named above.
