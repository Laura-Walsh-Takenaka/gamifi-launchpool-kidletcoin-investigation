# Research Paper — Final bounded extension: secondary signer and parallel-payment recipient

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

**Both requested histories are now fully returned through terminal empty pages.** NBGTCB… has 31 returned records, NAYIOJ… 7. Their combined 38 returned rows represent 32 unique transactions. **Only one transaction is new** relative to the previous 2,313-record collection: a zero-XEM self-transfer by NBGTCB… on May 28. The expanded union is 2,314 unique records. This extension supersedes the request in the secondary report to fetch these two histories.

## Both common control keys trace to the same initial funder

**NBDCOH… sent 10 XEM each to NCYKQW… and NBGTCB… on May 28, 2019, in adjacent blocks.** Their creation times are only two seconds apart. These later became the two common signing keys across the five 2-of-3 secondary conversions. This connects initial operational funding, control structure and the onward KID/XEM activity. It identifies accounts and key authority, not the humans holding keys.

| Time and basis | Recipient | XEM | Block | Transaction |
|---|---|---:|---:|---|
| 2019-05-28T08:41:33+00:00 (confirmed block UTC) | NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE | 10 | 2171718 | [5a096a6ad1f4…](https://explorer.nemtool.com/#/s_tx?hash=5a096a6ad1f4996f606d6d4425f814044cc4051cd273d626f9624cffea62748b) |
| 2019-05-28T08:41:50+00:00 (confirmed block UTC) | NBGTCBEUP2YW4Y47Q2ACZYCDME6VV6OVVBN7PSS3 | 10 | 2171719 | [f3c93bebf8da…](https://explorer.nemtool.com/#/s_tx?hash=f3c93bebf8da258b8b91f6c01410ad325f4da14d5be479e70e73688752c78fec) |

## NBGTCB complete direct XEM activity

Its 31 returned records contain seven direct XEM records: three positive incoming transfers, three positive outgoing transfers and one zero-XEM self-transfer. Its other records concern multisig authorizations/control, so they must not be counted as money paid by or received by NBGTCB.

| Direction | Counterparty | XEM | Transaction |
|---|---|---:|---|
| Incoming | NBDCOHCTOKI3RY46YK7EEPPQRG2UHPCNUQIDVLU5 | 10 | [f3c93bebf8da…](https://explorer.nemtool.com/#/s_tx?hash=f3c93bebf8da258b8b91f6c01410ad325f4da14d5be479e70e73688752c78fec) |
| Incoming | NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE | 1 | [3ef30d185a4a…](https://explorer.nemtool.com/#/s_tx?hash=3ef30d185a4ae8b96fb72cd9349a1402d6cdb374774392903e2aa9a4b0222466) |
| Outgoing | NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE | 1 | [c3cc8b2544b7…](https://explorer.nemtool.com/#/s_tx?hash=c3cc8b2544b7d7c5d066a9b82a7d4d3736491c67292e2b6c8058363ef6da2a40) |
| Outgoing | NCIT7ATTMW67VKKSD5DKIWZVKITN5GSHNSC264CP | 1.5 | [202e1a3c3d8a…](https://explorer.nemtool.com/#/s_tx?hash=202e1a3c3d8a2fb1b79c5c3f159e6af61cd967dcdae6137f932b3938e9b7d934) |
| Incoming | NB3RVCUTXBD7D775SUACUBPDHZFXTEX3SMRMLN3C | 0.6 | [324f9175ad52…](https://explorer.nemtool.com/#/s_tx?hash=324f9175ad52ff86752921f6cb1d46a734c413b802c246fdfe25991aa7718e3f) |
| Outgoing | NCIT7ATTMW67VKKSD5DKIWZVKITN5GSHNSC264CP | 8.9 | [aeb0f852f826…](https://explorer.nemtool.com/#/s_tx?hash=aeb0f852f826f1f7002e257bbb39450e33acab9ee14499a25da5aa5f119b61a2) |

**Positive receipts total 11.6 XEM; positive outgoing transfers total 11.4 XEM.** This is a transfer summary, not a fee-inclusive balance. NBDCOH… is the only observed funder outside the already identified secondary setup cluster. No further upstream address expansion is required by this history.

## NAYIOJ complete direct activity

**All six positive receipts come from NCIT7A… and total 2.137836 XEM. Its sole positive outgoing transfer returns 1.98117 XEM to NCIT7A… on July 12.** The complete returned history adds no external onward payment.

| Time and basis | Direction | XEM | Transaction |
|---|---|---:|---|
| 2019-06-11T04:35:53+00:00 (confirmed block UTC) | NCIT7A… → NAYIOJ… | 0.484293 | [2ad6b0b83c17…](https://explorer.nemtool.com/#/s_tx?hash=2ad6b0b83c1769d540c8892cf660df16ffc82bbb9fdeeb988e5b074f9f80c2b0) |
| 2019-06-12T03:53:10+00:00 (transaction creation UTC) | NCIT7A… → NAYIOJ… | 0.0408 | [a7f7f62dece1…](https://explorer.nemtool.com/#/s_tx?hash=a7f7f62dece1ed252f3813066fa228a065dfa84728fa38adc403a09dca160027) |
| 2019-06-12T04:01:29+00:00 (confirmed block UTC) | NCIT7A… → NAYIOJ… | 0.5 | [69c9503f5256…](https://explorer.nemtool.com/#/s_tx?hash=69c9503f52565247be4d633d4eb6d9fc0e9ba94da35e115d0582da8dd004b281) |
| 2019-06-14T09:32:38+00:00 (transaction creation UTC) | NCIT7A… → NAYIOJ… | 0.470419 | [48c7c0c93a27…](https://explorer.nemtool.com/#/s_tx?hash=48c7c0c93a27646d504b8b09a9c07a133e85ea556f42db1c9c00e44e222e25e8) |
| 2019-07-12T04:41:41+00:00 (transaction creation UTC) | NCIT7A… → NAYIOJ… | 0.535658 | [57284e8af8b7…](https://explorer.nemtool.com/#/s_tx?hash=57284e8af8b76c35d2421889087ec3a0f09b0413de0f8629bbdb5c3769f119ef) |
| 2019-07-12T05:58:41+00:00 (confirmed block UTC) | NAYIOJ… → NCIT7A… | 1.98117 | [c2615d867ffd…](https://explorer.nemtool.com/#/s_tx?hash=c2615d867ffdaaa2ef9d2bb35329c635d6fd35ea5ba2a24b90a268851fdd5fc9) |
| 2019-07-12T06:14:40+00:00 (confirmed block UTC) | NCIT7A… → NAYIOJ… | 0.106666 | [0d824bf3c68d…](https://explorer.nemtool.com/#/s_tx?hash=0d824bf3c68d6227bbbc6ac533318c0e7b36e5c0d8dcbe1d74f48359f30c4ad8) |

Three of these incoming amounts accompany the reciprocal KID/XEM groups documented in secondary_xem_links.json, near 20% of the corresponding outgoing XEM leg. Other receipts accompany KID events without an equivalent two-sided XEM match. The return to the same pool is a concrete accounting link; calling these service fees, profits or cash-outs would add an unsupported purpose. These explicit payments are distinct from the original KID levy.

## Verification handoff

The three reciprocal groups and 17 secondary targets remain in secondary_xem_links.json and secondary_xem_verification_targets.json. The five-row tertiary target file adds the second 10 XEM seed, the three remaining parallel recipient receipts and its return payment, so the recipient’s complete seven-record history can be corroborated. The one genuinely new zero-value self-transfer carries no message and adds no substantive payment or identity link.

No new merchant reference, contest entry label, real name, exchange terms or KID transfer appears in these two histories. The strongest supported result is a common funder and common control structure around small reciprocal KID/XEM activity.
