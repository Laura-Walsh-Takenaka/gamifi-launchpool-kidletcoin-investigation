# Research Paper — GamiFi BVI-number follow-up: project and counterparty disclosures

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research completed 6 September 2026 UTC. This is a bounded free public-source pass. No paid reports, contacts or private accounts were accessed.

## Result

The supplied official-registry screenshot reports **Gamifi Limited / 2082070**. This lane did not independently retrieve that registry result. No additional first-party project document located in this pass supplies its company number, incorporation date, registered agent or registered business address. This is a search result, not proof that no such disclosure exists.

The already-preserved GamiFi terms are the strongest project-to-entity bridge. Root inspected sections 1 and 2: they identify GamiFi Limited as the platform operator and the company releasing $GMI. The archive capture is `20221007163947` and the displayed revision date is 25 January 2022. Neither date establishes incorporation. The terms do not supply 2082070; pairing the number with that business remains an attribution based on the matching company name and jurisdiction, to be distinguished from a document expressly printing both identifiers.

## New primary counterparty lead: Avark

Avark's own GamiFi case study says the agency created its branding, website and launchpad app, including staking pools and utility NFTs; it also describes subsequent mystery-box and mini-game work. The page directly links the public `gamifi.avarkdev.link` development-host landing page.

This identifies a documented project service provider. It creates a concrete lead for any retained engagement agreements, invoices and client-approval correspondence. Those records could identify the contracting entity and authorised contact. Their existence, retention and contents have not been confirmed, and the case study does not establish that BVI company 2082070 was the client or that Avark held signing keys.

- Primary URL: https://avark.agency/case-studies/gamifi
- Web retrieval ref: `historical retrieval` (root separately opened as `historical retrieval`). Relevant locators: lines 37–40, 110–138.
- Linked privacy policy: https://avark.agency/privacy-policy ; ref `historical retrieval`. The retrieved Owner and Data Controller section supplies a contact email only; no legal company name or registration number was located. Displayed update: 11 June 2025.
- Direct archive-preservation fetches for the Avark pages returned HTTP403. Their local HTML filenames are error bodies, **not successful page captures**, and are excluded from the deliverable manifest. Successful web-tool retrievals support the statements above.
- The development-host landing returned HTTP502 via the direct fetch and failed the web opener. No infrastructure probing was performed.

## Archived official litepaper

Exact Wayback CDX lookup returned two distinct archived records for `https://gamifi.gg/gamifi-litepaper-1.1.pdf`:

| Capture | Retrieval result | Use |
|---|---|---|
| 2022-02-21 19:38:50 | Complete 6,628,803-byte PDF; 20 pages; valid Poppler extraction | Reviewed for corporate identifiers |
| 2022-05-26 02:16:04 | 1,048,576-byte PDF-like response; invalid cross-reference and page tree | Structurally incomplete; no substantive conclusion drawn |

The complete PDF's cover displays **November 2021**. It names GamiFi.gg and GMI in the project and token sections (pages5 and7–8); page14 begins the team descriptions. Across the extracted text no entity number2082070, BVI jurisdiction, registered agent, legal company address or incorporation date was located. Pages1 and20 were also rendered and visually inspected; the last page contains only the logo. A cover date describes the document, **not a registration date**.

Full valid PDF source: https://web.archive.org/web/20220221193850id_/https://gamifi.gg/gamifi-litepaper-1.1.pdf

SHA-256: `7f0097e1969efbf2f416f04383b134a5fe44876caee5b9be80f8f1a4864fb6c2`

See `litepaper_provenance.json`, `pdf_extraction.json` and the source PDF. The incomplete May record is retained locally for retrieval provenance but excluded from the deliverable manifest.

## Counterparty cross-check

MEXC's 23 January 2022 listing-campaign announcement identifies GamiFi.gg's website and the exact GMI contract `0x93d8d25e3c9a847a5da79f79ecac89461feca846`. It says the project information was supplied by the project team. It supplies no BVI company number or registered-agent data. This reinforces the project/domain/token mapping already established; it does not add a legal-entity identifier or prove which later account received transferred tokens.

Primary URL: https://www.mexc.com/announcements/article/initial-listing-mexc-kickstarter-vote-to-win-free-1-000-000-gamifi-gg-gmi-airdrops-4415532646041

Web ref: `historical retrieval`, lines43 and54–71.

## Scope and limitations

Both search engines were used for exact company-number/name variants and project-domain combinations with terms, privacy, BVI, British Virgin Islands, incorporation, registered office and litepaper. No exact2082070/project result surfaced in this lane's queries. Other team lanes independently pursued registry/gazette material, including the free i-BVI exact match; this note does not supersede their evidence.

Name collisions involving Indian recruiting, British Gamifi Solutions, Canadian Gamifi Inc., Kentucky apps and generic GameFi-sector text were excluded. A shared Avark portfolio entry for another client is not evidence of a relationship between those clients. Wayback privacy-path queries returned empty lists for the exact queried patterns, not a complete legal-page census. No bank account, beneficial owner or personal receipt has been established through these sources.
