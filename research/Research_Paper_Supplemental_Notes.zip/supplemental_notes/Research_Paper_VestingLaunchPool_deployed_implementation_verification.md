# Research Paper — VestingLaunchPool deployed implementation verification

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Retrieved 6 September 2026. Read-only public-chain and public-source verification; no signed transaction, mutation or exploit test.

## Result

At BNB Smart Chain block **120,222,549**, proxy `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb` selected implementation `0x7ed8022c43ab08e79c79addd8a7e5427aaa52250` through its EIP-1967 implementation slot.

Compiling the public `contracts/VestingLaunchPool.sol` from repository commit `4e7c1c6f68466bb62c68e77ed3beafeb0bbe65b6` with Solidity **0.8.4+commit.c7e474f2**, optimizer enabled / 200 runs, and OpenZeppelin upgradeable **4.5.2**, reproduces **all 5,065 executable runtime bytes**. The deployed runtime is 5,118 bytes total. The remaining 53 bytes are Solidity compiler metadata and differ. This is an executable-bytecode match, not a whole-bytecode or original-build-configuration identity claim.

Deployed complete-runtime SHA-256: `5fa78bd91cad007618fb55ddadd982e7d3a5b5609f81fc31fd34cab8c9a2f0a8`.

## Confirmed current callable behavior

- `initiateVest` stores a new schedule and increases the beneficiary's nonce. It is public, has no ownership/access restriction, and does not transfer or reserve tokens. A stored schedule alone cannot prove a deposit or a genuine allocation by the project.
- `initiateVests` processes a batch, verifies that the sum equals `totalAmount`, and transfers that total from the transaction caller into the contract. Its `InitiateVests` event occurs after that transfer; failure reverts the whole transaction. Independent GMI Transfer receipt logs remain the most direct funding evidence.
- `claim` can be called by anyone but transfers to the beneficiary supplied to the schedule lookup. It computes claimable tokens, increments the schedule's claimed amount, transfers tokens, then emits `Claim`. If the token transfer reverts, the claimed increment and event revert as well.
- `getClaimable` computes a schedule-based amount. It does not check that the contract holds enough tokens to pay it.
- This implementation contains no separate owner-only token-withdrawal function. Its inherited ownership functions do not by themselves identify a person or bank account. Proxy upgrade control is a separate matter.

These are source semantics established by the executable match. They do not prove exploitation, misappropriation, a genuine allocation for every stored record, or a complete funding/claim history. No attack workflow was tested or provided.

## Time limit

This lane directly verified the current implementation pointer and current executable. The separate control lane reports a successful upgrade to this same implementation on 19 April 2022 at 13:16:42 UTC (block 17,082,306, transaction `0x963741dcdeacc8a278325816da43502af75025b91478554781de533b501cf46e`), before the two sampled funding receipts. That receipt must be combined with these findings when explaining historical behavior. Neither this lane nor a single upgrade receipt establishes an uninterrupted implementation history.

## Reproducibility and primary sources

- Pinned source: https://raw.githubusercontent.com/sheandev/gamifiContracts/4e7c1c6f68466bb62c68e77ed3beafeb0bbe65b6/contracts/VestingLaunchPool.sol
- Source history: https://api.github.com/repos/sheandev/gamifiContracts/commits?path=contracts/VestingLaunchPool.sol&per_page=100
- Source was added in commit `3d2f970b3533e98dd39a0198dfe607b623946159`, timestamp 19 April 2022 13:44:55 UTC. Git author data is repository metadata and is not verification of human ownership of a blockchain key.
- Dependency source template: https://raw.githubusercontent.com/OpenZeppelin/openzeppelin-contracts-upgradeable/v4.5.2/contracts/
- Compiler: https://raw.githubusercontent.com/ethereum/solc-bin/gh-pages/linux-amd64/solc-linux-amd64-v0.8.4+commit.c7e474f2
- RPC: https://bsc-dataseed.bnbchain.org
- `fixed_block_verification.json`: exact RPC requests, responses, fixed block, current slot and code, and independently repeated executable match.
- `compiler_input.json`: exact standard JSON input with all source dependencies embedded; sufficient to reproduce using the documented compiler.
- `compiler_output.json`: compiler output, ABI, storage layout, metadata and runtime object.
- `compiler_provenance.json`: compiler URL, version and SHA-256; repository commit and pinned source URL.
- `match_result.json`, `source_commit_history.json`, `implementation_code.json`, `head.json`: initial match and retrieval evidence.
- `verify.py` / `fixed_block.py`: reproducible retrieval and comparison code. The initial retriever uses the repository's current main before pinning its resolved commit; the exact original build input is preserved separately for immutable reproduction.

Useful decoded selectors from matched compiler output: `claim(address,uint256)` = `aad3ec96`; `getClaimable(address,uint256)` = `6f5244b1`; bulk `initiateVests(address[],uint256[],uint256[],uint256,uint256,uint256,uint256)` = `872e8f27`. No transaction calldata was generated or submitted.
