# Research Paper — Pooled 35b1 ordinary transaction index

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

BSCTrace public explorer account API returned 193 unique ordinary transaction rows in two pages (100 and 93), including 184 outgoing signed transactions and 9 incoming ordinary transactions. No credentials or API keys were supplied. No human identity is inferred.

The public address page returned HTTP 200. Its publicly linked JavaScript chunk `1691-fe6235dad4e61e7b.js` identifies `useAddressTx` and the keyless endpoint `https://bsc-explorer-api.nodereal.io/api/tx/getAssetTransferByAddress` with `type=transaction`, `pageSize`, `page`, and `order` parameters. The same public listing endpoint returned both preserved pages successfully.

`ordinary_inventory_index.json` provides hash, block, timestamp, sender, recipient, value, and input for all 193 rows. `outgoing_hashes.json` provides 184 hashes for independent RPC checking. The index does not contain nonce. Parent is fetching independent Binance RPC transactions/receipts to assign nonces and verify protocol records. Indexed rows are leads until those checks are complete; matching count alone is not verification of nonce coverage.

The two pages report the same total193. Latest indexed transaction is dated 7November2022. This ordinary index does not cover internal transfers or ERC20 events unless also present as a sender/recipient ordinary transaction. It cannot establish bank settlement, business purpose, entitlement, key holder, or human identity. Third-party behavior labels in raw metadata were not used for attribution.

Other bounded attempts: Routescan's keyless txlist endpoint responded HTTP200 with chain not supported for chain56; its chain listing returned no supported blockchain. BscScan ordinary txs page returned HTTP403. No challenge bypass, credential use, account creation, paid record retrieval, or QuickNode call occurred.

Raw page bodies, public address HTML, relevant public JavaScript, and URL/time/status/SHA256 provenance are preserved alongside this note. Unrelated framework JS can be omitted from a compact final evidence package while retaining the address page and1691chunk that show endpoint provenance.
