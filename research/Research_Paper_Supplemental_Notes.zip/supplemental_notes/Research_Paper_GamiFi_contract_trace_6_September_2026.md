# Research Paper — GamiFi contract trace — 6 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

**Finding:** GamiFi’s Launchpool claim contract received identifiable GMI deposits in April 2022. On 6 September 2026, a documented allocation still returned 587,755.519557566 GMI as claimable, while the contract held only 207.412329404181026961 GMI. A read-only simulation of that claim failed for insufficient token balance. This establishes a present execution failure for that allocation. The cause, outgoing transfer history, any alternative settlement and the responsible individual remain unestablished.

Amounts below are **GMI tokens, not US dollars**. Research used public sources and read-only BNB Smart Chain queries; no transaction was broadcast and no one was contacted.

**The official product-to-contract link**

Launchpool’s announcement 1254, dated 19 April 2022 at 21:12:55 UTC in its page metadata, directed users to `app.gamifi.gg/launchpool-claim/`, identified the canonical GMI token and described nine months of linear distribution. GamiFi’s claim page captured on 20 April references a JavaScript asset that explicitly configures `launchpoolVesting` as `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb`. Its route-selection function chooses a different contract for the `private-claim` path. This corroborates the public repository and live contract through the project’s own customer interface. [1–3]

**Funding transactions actually verified**

Both transactions below succeeded. Their canonical GMI Transfer logs debit `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199` and credit the Launchpool vesting contract. Each transaction creates 200 vesting entries; the decoded amount sum equals the transferred total. All 400 address-and-amount pairs match the corresponding public repository CSV rows. [4–6]

| UTC, 19 April 2022 | Block | Deposit, GMI | Transaction |
|---|---:|---:|---|
| 16:30:49 | 17,086,174 | 458,882.5934562736916 | `0x8a5f1c2ac6bd2a1f8ff17d16c55a64ac384401a27c15a1c1899c6c10d8e237bd` |
| 17:14:29 | 17,087,043 | 887,877.3822482400862 | `0x854f39b52c34c65f6e2229ade8b2d6d26226fd20323d30703241de9b4c82dd38` |
| **Verified subtotal** | | **1,346,759.9757045137778** | Two sampled batches |

The first batch matches CSV rows 0–199 and the second rows 5800–5999, using zero-based indexing. This is not a complete funding total. The CSV’s full 15.457 million-token sum remains a list figure; this follow-up verified execution for these two batches only. Addresses represent blockchain accounts, not independently identified people.

**The present payment discrepancy**

At block **120,222,455**, timestamp **6 September 2026 02:27:39 UTC**, independently retrieved contract state showed:

| Observation | GMI |
|---|---:|
| Entire Launchpool vesting contract token balance | 207.412329404181026961 |
| Claimable for beneficiary `0xe356fe28b7b6b015a3b2bb4419dbdf2777d7420b`, nonce 0 | 587,755.519557566 |
| Balance deficit against that single allocation | 587,548.107228161818973039 |
| Claimable for second sampled beneficiary `0x000deef80c998e56cdb387392096d6109be0c283`, nonce 0 | 17.2356392039306 |

Both sampled records have zero in their `claimed` field. The larger allocation appears in the historically funded second batch above. A second check at block **120,222,610** reproduced the balances and claimable amounts. A read-only simulation of the larger beneficiary’s normal `claim` call reverted with **“ERC20: transfer amount exceeds balance”**; the smaller claim simulation succeeded. A simulation creates no payout. [7]

This evidence supports the narrow conclusion that the contract could not execute the larger recorded claim at the observed state. It does not establish aggregate outstanding obligations, net losses, who received outgoing tokens, or whether an investor was compensated elsewhere. GamiFi’s archived interface refers users to their Token Agreement; contractual entitlement and alternative settlement require those records.

Launchpool’s 29 February 2024 status post lists GamiFi under **“Completed Vesting.”** That description may refer to the end of the release schedule. It does not prove every beneficiary withdrew or was paid, and the current records do not establish that the 2024 statement was false when made. [8]

**A separate private-investor payment**

The archived app assigns `0x74e0ddf89807107378beb02e6bc504243e0cdf6c` to its private-claim route. A successful transaction on **14 December 2022 at 16:01:19 UTC**, block **23,901,241**, transferred **2,131,635.802469135802469136 GMI** from that contract to `0x36048413c4edf0cf3e633aab317fcd9824dfb4d4`. The caller and token recipient are the same address. The receipt was independently re-fetched. [3,9]

Transaction: `0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639`.

This is a verified private-vesting payout. It is not an outgoing transfer from the Launchpool vesting contract, and the recipient has not been identified as Laura, Launchpool, Alphabit or any other person or organization.

**Identifiers and verified roles**

All addresses are on BNB Smart Chain, chain ID 56. Historical frontend labels and current control readings are distinguished below.

| Identifier | Address | Evidence and scope |
|---|---|---|
| Canonical GMI token proxy | `0x93d8d25e3c9a847a5da79f79ecac89461feca846` | Official announcement, frontend and transfer receipts |
| Launchpool vesting proxy | `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb` | Official claim route; verified deposits and current claim failure |
| Private vesting contract | `0x74e0ddf89807107378beb02e6bc504243e0cdf6c` | Official private-claim route; verified December payout |
| Vesting/NFT deployer and sampled deposit payer | `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199` | Deployment, upgrade and deposit receipts; no human attribution |
| Current vesting/NFT owner and GMI direct proxy administrator | `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b` | Contract ownership and proxy storage readings |
| Vesting/NFT ProxyAdmin contract | `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475` | A contract controlling upgrades, separate from application ownership |
| Current owner of that ProxyAdmin | `0x538a8b615e98e87d025c4336be44e4b8588277c7` | `owner()` reading; no human attribution |
| Current Launchpool vesting implementation | `0x7ed8022c43ab08e79c79addd8a7e5427aaa52250` | Proxy storage and executable-bytecode match |
| Historical IDO project contract | `0x56c0cb2d047b69278f49b4759c1718436a546c7f` | Archived app uses it for project, funding and staking actions; current receiver and payment history unverified |

The last identifier is a concrete next lead for tracing hosted-project fundraising. A hardcoded funding-receiver helper in frontend code is not proof that the receiver was set or paid.

**Dated control actions**

The Launchpool vesting proxy was deployed on 19 April 2022 at 13:10:39 UTC. At **13:16:42 UTC**, transaction `0x963741dcdeacc8a278325816da43502af75025b91478554781de533b501cf46e`, block **17,082,306**, upgraded it to `0x7ed802…`. The sender was `0x3e0f…`; it called ProxyAdmin `0x6ef…`. The successful receipt emits the upgrade event from the vesting proxy. This precedes both verified funding batches. [10]

The same sender also upgraded Duke and Mystery NFT proxies on **25 August 2022**, through the same ProxyAdmin. The two transaction identifiers are included in the evidence archive’s control findings. This establishes technical control at those specific times. Later ownership-transfer dates have not been recovered, and no transaction has been attributed to Laura personally.

An important scope correction: **the original GMI token used a different deployer**, `0x0d2c8df71c846d0dbc9c8bc75ea39c45d5197dca`, and original ProxyAdmin `0xd3b3024bc9059d630e1058154b1d02412143a412`. The shared `0x3e0f…` deployment pattern applies to vesting/NFT contracts; it does not establish that address created the original GMI token. The legacy GMI ProxyAdmin now returns `0xf27…` as owner, but it is no longer the token’s direct administrator in the sampled state.

**Source-code verification and its limits**

The currently selected vesting implementation matches **all 5,065 executable bytes** compiled from the public repository using Solidity 0.8.4, OpenZeppelin upgradeable 4.5.2 and optimizer setting 200. Only 53 compiler-metadata bytes differ. The proxy pointer and bytecode were checked together at block **120,222,549**. [11]

The matching code explains why `getClaimable` can report an amount the contract cannot pay: that view does not test token balance. A failed transfer rolls back the claimed update. Individual schedule creation does not itself move funding; batch creation does. The two deposit receipts above resolve that funding ambiguity for the sampled batches. This implementation has no separate owner-withdrawal function. Upgrade authority is a distinct control surface. These facts do not establish exploitation, a drain mechanism or continuous implementation history since deployment.

**What remains unresolved**

The main missing record is the complete GMI transfer and claim history for `0xf504…`, reconciled with its funded schedules and any intervening upgrades. That would identify when its balance ceased covering the sampled outstanding allocation and where the tokens went. The current state alone cannot answer those questions.

The other material gaps are the payer’s upstream token source, the identities and authority behind the control addresses, the private-payout recipient’s contractual allocation, the IDO project’s executed funding-receiver settings, and investor Token Agreements or alternative-settlement records. **No Cayman bank account, bank beneficiary, personal Laura wallet or personal receipt by Laura has been established.**

Bounded historical block and receipt queries worked. Public explorer retrievals failed, the official BNB endpoint disables `eth_getLogs`, and tested alternative public log endpoints returned access or rate errors. Those failures are preserved; they are not empty histories. No all-chain scan or complete outflow reconstruction is claimed. [12]

**Sources and evidence index**

1. [Launchpool claims announcement](https://t.me/s/launchpoolannouncements/1254), also visible in the [official channel’s gaming search](https://t.me/s/launchpoolannouncements?q=%23Gaming). Exact timestamp and page hash: *Historical file: launchpool_claim_message.json*.
2. [Archived official claim page, 20 April 2022](https://web.archive.org/web/20220420121048id_/https://app.gamifi.gg/launchpool-claim/).
3. [Referenced official application asset](https://web.archive.org/web/20220420121112id_/https://app.gamifi.gg/_nuxt/f76e883.js). Address excerpts, route selector and SHA-256: *Historical file: official_frontend_identifiers.json*.
4. [First funding transaction](https://bscscan.com/tx/0x8a5f1c2ac6bd2a1f8ff17d16c55a64ac384401a27c15a1c1899c6c10d8e237bd). Primary evidence is the saved BNB RPC receipt and transaction data, not an unavailable explorer page.
5. [Second funding transaction](https://bscscan.com/tx/0x854f39b52c34c65f6e2229ade8b2d6d26226fd20323d30703241de9b4c82dd38). Same receipt-based verification; *Historical file: decoded_funding.json* contains comparisons.
6. [Public repository](https://github.com/sheandev/gamifiContracts), [vesting list commit](https://github.com/sheandev/gamifiContracts/commit/b5c2cd4aa396f65b45b8f3921ab068ee36e40ad4), [vesting initialization task](https://github.com/sheandev/gamifiContracts/blob/main/tasks/initVesting.js).
7. *Historical file: coverage_*.json* and *Historical file: independent_*.json*: exact requests, endpoint, observation time, fixed blocks and returned state or revert data. *Historical file: decoded_current_verification.json* summarizes the second check.
8. [Launchpool project status post](https://t.me/s/launchpoolannouncements/1506), also visible on the [nearby channel page](https://t.me/s/launchpoolannouncements/1500). Exact Telegram timestamp: *Historical file: completed_vesting_message.json*.
9. [Private-vesting payout](https://bscscan.com/tx/0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639). Primary confirmation: saved RPC receipt; *Historical file: decoded_private_claim.json*.
10. [Vesting upgrade transaction](https://bscscan.com/tx/0x963741dcdeacc8a278325816da43502af75025b91478554781de533b501cf46e). Independently retrieved receipt: *Historical file: verified_receipt_upgrade.json*.
11. [Vesting source](https://github.com/sheandev/gamifiContracts/blob/main/contracts/VestingLaunchPool.sol). Compiler provenance, exact input/output and fixed-block runtime verification are in `runtime/`.
12. [BNB Chain’s official RPC documentation](https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/json-rpc-endpoint/) confirms the public endpoint’s log restriction.

The companion evidence ZIP preserves selected public-chain responses, decoded comparisons, source identifiers and compiler reproduction material. Full archived web pages/vendor bundles and the compiler executable are omitted; source URLs and fingerprints are retained. Its SHA-256 manifest covers the enclosed files. This is a research update, not a legal finding or complete financial audit.
