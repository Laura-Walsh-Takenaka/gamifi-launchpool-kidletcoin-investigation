# Research Paper — KidLetCoin: complete returned token history and linked account review

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Evidence rechecked 5 September 2026. Amounts are native asset quantities unless explicitly marked CAD. Times in transaction tables are block inclusion times in UTC. Address abbreviations resolve to full addresses in the account register below.

## Main findings

The historical `kidlet:kid` asset is on the public NEM NIS1 mainnet. This review reconciles **all 28 indexed KID transfers across 19 participating addresses** against complete returned account histories and preserved block responses. Expanding to related signers and institutional accounts produced **24 complete returned histories and 2,314 unique records**.

The strongest new link combines funding and signing authority: **NBDCOH… funded both NCYKQW… and NBGTCB… with 10 XEM each, in adjacent blocks on 28 May 2019.** Those two keys subsequently shared authority over five 2-of-3 accounts, including three participants in the small KID branch. NBGTCB… actually cosigned seven outgoing KID transfers from those three accounts.

There are **three reciprocal KID/XEM groups in the same or adjacent blocks**, plus a fourth reverse-direction pair nine blocks apart. These are exchange-like movements. They make a categorical claim that KID never moved against something of value too strong. Their small size and shared signing authority leave commercial sales, independent customers, a public market price and merchant redemption unresolved.

The separate payment recipient NAYIOJ… returned its first five receipts to the originating pool, less its network fee. Its full history and current balance reconcile exactly; gross receipts must not be presented as retained fee revenue.

The regional Foundation-to-shared-account flow is real, but the earlier approximately CA$50,000 figure is **a historical valuation of 12 XEM transfers into a mixed-use account**, not a verified $50,000 KidLetCoin grant. The issuer and several signers have substantial history outside KID.

## Coverage and verification

| Measure | Result |
|---|---|
| Token history | 28 transfers; 19 participants; 25 unique directed address pairs |
| Expanded account history | 24 histories; 2,314 distinct records; 2,160 asset-transfer rows |
| Explicit positive XEM screen | 1,770 transfers across the expanded history union; includes institutional and non-KID activity |
| Account refresh window | 2026-09-05 13:50:10.550537 to 2026-09-05 13:59:40.940487 UTC |
| Live token index | 28 entries returned at 13:54 UTC on 5 September 2026; next page empty; unchanged from earlier capture |
| Token activity interval | 2018-12-09 07:04:02 to 2019-07-16 04:56:54 UTC |
| Completion criterion | Every collected account history reaches a terminal empty page; all indexed KID hashes, senders, recipients and amounts reconcile exactly |

The original 16 histories had already been fully paginated earlier on the same date. Each latest page was fetched again and matched exactly, including full transaction objects; the terminal baseline was reused. Eight additional accounts were fully retrieved to terminal pages in this extension. The live token index also returned its terminal empty page. The collection checkpoint height was 5,818,411 before the final two small account histories were added.

Account history was read from `https://nem01.symbol-node.com:7891`; selected transactions were matched as complete objects in blocks from `https://nem02.symbol-node.com:7891/block/at/public`. All 28 KID transfers and the report's selected reciprocal, initial funding, parallel-payment and ND2JRP transfers have block evidence. These endpoints are in the same operator family. This is a reconciliation of public node/explorer responses, not a local replay of every NEM block or a cryptographic audit of the entire chain.

“Complete” means the complete returned history of the identified KID asset and the 24 stated accounts. Shared exchange destinations are followed through these accounts' payments; the full exchange hubs and every unrelated asset or possible migration are outside this bounded collection. Raw account records retain creation timestamps separately from block inclusion timestamps.

## Token creation, allocations and expiry

| Confirmed UTC | Event | Height | Transaction |
|---|---|---|---|
| 2018-04-09 05:07:37 | Namespace registration / renewal | 1580133 | [5b318ecdc1d6…](https://explorer.nemtool.com/#/s_tx?hash=5b318ecdc1d6b79489174a2abcc8c64f208fd07d90b3ffbc2052bc1c4946835e) |
| 2018-04-09 05:35:06 | Mosaic definition | 1580152 | [7f8910e2fa04…](https://explorer.nemtool.com/#/s_tx?hash=7f8910e2fa04ef06ea233fd6d56f97a621095a3f0c225e6c813787d2007baddd) |
| 2019-05-04 05:38:06 | Namespace registration / renewal | 2137262 | [8e956d31acd8…](https://explorer.nemtool.com/#/s_tx?hash=8e956d31acd8b7d7d8a3ab2dcca098bf3e0471ad153eeca6c9d8345071428312) |
| 2019-05-04 05:59:47 | Mosaic definition | 2137280 | [250b0463c72b…](https://explorer.nemtool.com/#/s_tx?hash=250b0463c72bc6e1322d5e8bc3a5f726bc2094bebc5c9fb6d1a1635ad6b7610b) |
| 2020-04-29 06:33:31 | Namespace registration / renewal | 2652960 | [f014ae53b022…](https://explorer.nemtool.com/#/s_tx?hash=f014ae53b02234221dbf94bc63ef1cf56a49ddb051d912bb7a46a3ee2bd5628b) |

The original definition specifies **21,000,000 KID**, six decimal places, fixed supply and transferability. The May 2019 definition changes the description's newline; it does not mint a second 21 million. No KID supply-change transaction appears in the issuer's returned history. The fixed levy is **10 atomic XEM = 0.00001 XEM** per applicable KID transfer, payable to NCEUKZ…. It is neither 10 XEM nor a percentage.

The 2019 renewal occurred 31,529 blocks after the first expiry, within the protocol's 43,200-block grace period. The last renewal was 29 April 2020. Applying the preserved NIS1 rules yields final expiry at height **3,178,560**, confirmed **2 May 2021 at 07:44:17 UTC**; the grace boundary is height 3,221,760. No later renewal appears in the issuer history. The current record therefore supports an expired historical asset. A surviving explorer number is not proof of a currently usable or redeemable token.

On 9 December 2018, the entire supply moved issuer → staging → distributor. Those two 21-million transfers alone account for 42 million of gross transferred volume. On 4 May 2019, the distributor made the large allocations, including 8.4 million labelled “kid future development fund” and 6.3 million labelled “educational establishment fund.” In June and July, the development fund made further 350,000/700,000 allocations. The 700,000 transfer to NCM2QK… was followed by a 350,000 return 25 minutes 33 seconds later. A payment to NBLIIT… bears “BJ Founders”; that literal memo does not resolve who “BJ” was.

### Historical token positions after the last transfer

These are replayed positions after 16 July 2019, not current spendable balances. Incoming/outgoing counts in the underlying JSON include repeated movements. All prefixes conserve the initial supply and remain nonnegative.

| Address | Role | Historical KID | Supply share |
|---|---|---|---|
| NA5JKI… | Development fund | 7,000,000 | 33.333333% |
| NDSTP4… | Education fund | 6,300,000 | 30.000000% |
| NC6JT7… | Distributor | 4,200,000 | 20.000000% |
| NCM2QK… | Signer / allocation | 700,000 | 3.333333% |
| NBDCOH… | Shared project / Foundation signer | 698,940 | 3.328286% |
| NDMV5M… | Signer / allocation | 350,040 | 1.666857% |
| NAHLQE… | Allocation wallet | 350,000 | 1.666667% |
| NBLIIT… | Definition cosigner | 350,000 | 1.666667% |
| NCDYOM… | Allocation wallet | 350,000 | 1.666667% |
| NCEUKZ… | Definition initiator / levy / signer | 350,000 | 1.666667% |
| NCJHET… | Signer / allocation | 350,000 | 1.666667% |
| NBXPW6… | Secondary KID participant; identity unverified | 1,000 | 0.004762% |
| NBQVQ6… | Secondary KID participant; identity unverified | 10.25 | 0.000049% |
| ND6D4I… | Secondary KID participant; identity unverified | 7.926319 | 0.000038% |
| NCIT7A… | Secondary KID participant; identity unverified | 1.023681 | 0.000005% |
| NBYH5N… | Secondary KID participant; identity unverified | 0.8 | 0.000004% |
| NADLLJ… | Staging | 0 | 0.000000% |
| NC7HKO… | Issuer | 0 | 0.000000% |
| NCYKQW… | Secondary KID participant; identity unverified | 0 | 0.000000% |

The three largest positions total **17.5 million KID, or 83⅓%** of supply. The six secondary participants collectively retain **1,020 KID**: a 20-KID chain and a separate 1,000-KID recipient. Education has no outgoing KID transfer. Gross token volume is **60,901,115.523681 KID**, including forwarding and returns; it is not 60.9 million distinct tokens or a monetary value.

The captured explorer rich list sums to 17,501,020 KID and displays zero for eight allocation/signing accounts whose ledger positions total 3,498,980 KID. That discrepancy is preserved in `token_audit.json`; this report uses the transaction replay for historical positions and makes no current-balance inference from that rich list.

## Initial funding and shared signing authority in the small-transfer branch

| Confirmed UTC | From | To | XEM | Public message | Transaction |
|---|---|---|---|---|---|
| 2019-05-28 08:41:33 | NBDCOH… | NCYKQW… | 10 | — | [5a096a6ad1f4…](https://explorer.nemtool.com/#/s_tx?hash=5a096a6ad1f4996f606d6d4425f814044cc4051cd273d626f9624cffea62748b) |
| 2019-05-28 08:41:50 | NBDCOH… | NBGTCB… | 10 | — | [f3c93bebf8da…](https://explorer.nemtool.com/#/s_tx?hash=f3c93bebf8da258b8b91f6c01410ad325f4da14d5be479e70e73688752c78fec) |
| 2019-06-11 03:42:43 | NCYKQW… | NBQVQ6… | 8.29999 | — | [7dbec695d48e…](https://explorer.nemtool.com/#/s_tx?hash=7dbec695d48ed5982cd0730d1e6ae29831d21912932a4f6be5d77a0f3475898f) |
| 2019-06-11 03:53:37 | NBQVQ6… | ND6D4I… | 3 | — | [8ceb1ebb7a70…](https://explorer.nemtool.com/#/s_tx?hash=8ceb1ebb7a7045ac6a6f6fabac4e6bd710225cf0ec98eefa26ca7d110201be7e) |
| 2019-07-12 04:14:50 | NBQVQ6… | NBYH5N… | 2.14 | — | [6b99d369fd2c…](https://explorer.nemtool.com/#/s_tx?hash=6b99d369fd2c7b47c2e29650f402b7ad15672933e6108fb8c28af0af25ad4bce) |
| 2019-06-30 09:40:00 | NBDCOH… | NBXPW6… | 5 | xem for transactions | [fc2429fe7434…](https://explorer.nemtool.com/#/s_tx?hash=fc2429fe7434ddc0b1df92de7754a8cdc1312997cd5504035c744c587a9ad5dc) |

The first two transfers were created two seconds apart and confirmed **17 seconds apart**, in adjacent blocks. Both common control keys therefore have a directly observed initial funder in NBDCOH…. NBGTCB… later funded NCIT7A… with 1.5 and 8.9 XEM on 3 June. Its complete history shows 11.6 XEM in direct positive receipts and 11.4 XEM in direct outgoing transfers, excluding fees; its other records are mainly control and co-signing activity.

The initial KID route is **NBDCOH… → NCYKQW… → NBQVQ6… → ND6D4I…**: 20 KID, 20 KID and 10 KID respectively. The first two 20-KID entries forward the same amount. They are not two independently demonstrated contest awards. No small-branch KID memo identifies a contest winner, a child, a merchant or a purchase.

The separate NBXPW6… history contains just two records: 1,000 KID on 23 June and the 5-XEM follow-up on 30 June with “xem for transactions.” That message directly supports transaction-cost assistance.

| Confirmed UTC | Account converted | Threshold | Transaction |
|---|---|---|---|
| 2019-05-30 06:17:58 | NB3RVC… | 2 of 3 | [16c06041e753…](https://explorer.nemtool.com/#/s_tx?hash=16c06041e75352125941d8bffe00b98276596828ac388bb75a7404c543aac798) |
| 2019-06-03 03:17:38 | NCIT7A… | 2 of 3 | [510bb72a0f41…](https://explorer.nemtool.com/#/s_tx?hash=510bb72a0f4130ded8197f2d1f569435ee4689d670a407c29e78c2ad1d52df2b) |
| 2019-06-11 03:53:51 | ND6D4I… | 2 of 3 | [c21a21976937…](https://explorer.nemtool.com/#/s_tx?hash=c21a2197693750f484fdfdb98f5ea7f2b017a05796305985e1edb102054dabdc) |
| 2019-06-26 05:12:32 | NBQWPY… | 2 of 3 | [b71541e9aef8…](https://explorer.nemtool.com/#/s_tx?hash=b71541e9aef8cad413c816a6fef8dedadb5a01e3c9b48cb8f47e12498ac86baa) |
| 2019-07-12 04:17:57 | NBYH5N… | 2 of 3 | [3067b5e1a2c3…](https://explorer.nemtool.com/#/s_tx?hash=3067b5e1a2c36a09f4ea9e96b4336016ed4e5608d11bcd47da2541c21a719705) |

All five conversions share **NCYKQW… and NBGTCB…**, with one distinct third key for each account. These two common keys together meet the configured threshold. Three converted accounts—NCIT7A…, ND6D4I… and NBYH5N…—actually transfer KID; NB3RVC… and NBQWPY… are related control neighbors without an observed KID holding.

In the seven outgoing multisig KID transfers from the three participating accounts, the distinct third key initiates the transaction and **NBGTCB… supplies the explicit additional signature**. NCYKQW… is assigned a shared membership but is not the observed cosigner on those seven. This proves a shared authorization structure; it does not count independent people or assign a real name to either key.

## Reciprocal KID and XEM movements

| KID confirmed UTC | KID leg | Reciprocal XEM leg | Separate NCIT7A → NAYIOJ payment |
|---|---|---|---|
| 2019-06-11 04:35:53 | ND6D4I… → NCIT7A…: 1 KID [7366d75af66b…](https://explorer.nemtool.com/#/s_tx?hash=7366d75af66b6a876f63bb39fa801b62931c6bc37e74cfc37c1896fdf3df7cfd) | 2019-06-11 04:31:39; 2.421466 XEM back [3b52186f73bf…](https://explorer.nemtool.com/#/s_tx?hash=3b52186f73bfb32e47eed684df599fbc5d6dedb9445b7e8d912c88afaebed5a1) | 2019-06-11 04:35:53; 0.484293 XEM [2ad6b0b83c17…](https://explorer.nemtool.com/#/s_tx?hash=2ad6b0b83c1769d540c8892cf660df16ffc82bbb9fdeeb988e5b074f9f80c2b0) |
| 2019-06-12 04:01:29 | ND6D4I… → NCIT7A…: 1.073681 KID [3cff7d284c43…](https://explorer.nemtool.com/#/s_tx?hash=3cff7d284c437fdb4aeb3bee1c14a6d06d1acef87ac39b0be46450f89172b8a8) | 2019-06-12 04:01:29; 2.5 XEM back [cb8c0f41bf6f…](https://explorer.nemtool.com/#/s_tx?hash=cb8c0f41bf6f99e6eede43e0f4c49980abb36ef6937ea6f12efb925d3415ddb8) | 2019-06-12 04:01:29; 0.5 XEM [69c9503f5256…](https://explorer.nemtool.com/#/s_tx?hash=69c9503f52565247be4d633d4eb6d9fc0e9ba94da35e115d0582da8dd004b281) |
| 2019-07-12 06:14:40 | NBYH5N… → NCIT7A…: 0.2 KID [640513d8ce8d…](https://explorer.nemtool.com/#/s_tx?hash=640513d8ce8d400b2ffb6fc49ba21f4160bb2127cd6f994b2cfdc950d8274eb3) | 2019-07-12 06:14:40; 0.533328 XEM back [3e051740aa3e…](https://explorer.nemtool.com/#/s_tx?hash=3e051740aa3ef45f3e0477d7dd8db2940ad43dcdca2d8412ed10f46ae008b317) | 2019-07-12 06:14:40; 0.106666 XEM [0d824bf3c68d…](https://explorer.nemtool.com/#/s_tx?hash=0d824bf3c68d6227bbbc6ac533318c0e7b36e5c0d8dcbe1d74f48359f30c4ad8) |

The 11 June XEM leg confirms **before** the KID leg, one block earlier; the other two groups share a block. Consequently the rows describe paired movements, not a claim that every XEM payment was made after receiving KID. The separate NAYIOJ amounts are approximately 20% of the corresponding reciprocal XEM amount, with atomic-unit rounding. They are separately signed transactions, distinct from the 0.00001-XEM protocol levy and network fees.

On **11 July at 06:53:39 UTC**, NBQVQ6… sent **1 XEM** to NCIT7A…. At **07:04:56 UTC**, nine blocks later, NCIT7A… sent **0.25 KID back**. These are observed amounts in the reverse direction, equivalent arithmetically to 4 XEM per KID for that pair; they are not a verified public price quotation.

| Confirmed UTC | From | To | XEM | Public message | Transaction |
|---|---|---|---|---|---|
| 2019-07-11 06:53:39 | NBQVQ6… | NCIT7A… | 1 | — | [217dc9cc91df…](https://explorer.nemtool.com/#/s_tx?hash=217dc9cc91df4ad0aa87948aba65c72ecf0e4427c74ba1e7b5a4dffcb569c211) |

| Confirmed UTC | From | To | KID | Public message | Transaction |
|---|---|---|---|---|---|
| 2019-07-11 07:04:56 | NCIT7A… | NBQVQ6… | 0.25 | — | [6b6787e3dc93…](https://explorer.nemtool.com/#/s_tx?hash=6b6787e3dc932030c87a8cf07358347596424b5371d6bf5927e238c4621dcb7d) |

Other movements do not fit a uniform two-way rule. A separate 1-KID incoming transfer on 12 June has a 0.0408-XEM payment to NAYIOJ… without a corresponding direct XEM payment back to that KID sender. Later outgoing KID events also have parallel payments. Together with common signing authority on both sides of the three strongest pairs, these exceptions prevent treating the pattern as proof of an independent commercial marketplace. The observed evidence supports exchange-like operation or testing; operating terms and merchant records would distinguish those possibilities.

### Complete parallel-recipient reconciliation

| Confirmed UTC | From | To | XEM | Public message | Transaction |
|---|---|---|---|---|---|
| 2019-06-11 04:35:53 | NCIT7A… | NAYIOJ… | 0.484293 | — | [2ad6b0b83c17…](https://explorer.nemtool.com/#/s_tx?hash=2ad6b0b83c1769d540c8892cf660df16ffc82bbb9fdeeb988e5b074f9f80c2b0) |
| 2019-06-12 03:54:16 | NCIT7A… | NAYIOJ… | 0.0408 | — | [a7f7f62dece1…](https://explorer.nemtool.com/#/s_tx?hash=a7f7f62dece1ed252f3813066fa228a065dfa84728fa38adc403a09dca160027) |
| 2019-06-12 04:01:29 | NCIT7A… | NAYIOJ… | 0.5 | — | [69c9503f5256…](https://explorer.nemtool.com/#/s_tx?hash=69c9503f52565247be4d633d4eb6d9fc0e9ba94da35e115d0582da8dd004b281) |
| 2019-06-14 09:34:02 | NCIT7A… | NAYIOJ… | 0.470419 | — | [48c7c0c93a27…](https://explorer.nemtool.com/#/s_tx?hash=48c7c0c93a27646d504b8b09a9c07a133e85ea556f42db1c9c00e44e222e25e8) |
| 2019-07-12 04:48:48 | NCIT7A… | NAYIOJ… | 0.535658 | — | [57284e8af8b7…](https://explorer.nemtool.com/#/s_tx?hash=57284e8af8b76c35d2421889087ec3a0f09b0413de0f8629bbdb5c3769f119ef) |
| 2019-07-12 05:58:41 | NAYIOJ… | NCIT7A… | 1.98117 | — | [c2615d867ffd…](https://explorer.nemtool.com/#/s_tx?hash=c2615d867ffdaaa2ef9d2bb35329c635d6fd35ea5ba2a24b90a268851fdd5fc9) |
| 2019-07-12 06:14:40 | NCIT7A… | NAYIOJ… | 0.106666 | — | [0d824bf3c68d…](https://explorer.nemtool.com/#/s_tx?hash=0d824bf3c68d6227bbbc6ac533318c0e7b36e5c0d8dcbe1d74f48359f30c4ad8) |

The first five receipts total **2.031170 XEM**. The return on **12 July 2019 at 05:58:41 UTC** is **1.981170 XEM**, and its raw sender fee is **0.050000 XEM**. Those two amounts exactly exhaust the first five receipts. A sixth receipt of 0.106666 XEM follows at 06:14:40 UTC.

The full reconciliation is **2.137836 received − 1.981170 returned − 0.050000 network fee = 0.106666 XEM**, matching the account balance fetched on 5 September 2026. Every receipt comes from NCIT7A… and the sole outgoing transfer returns to NCIT7A…. The returned record contains no external onward payment. Payment purpose and recipient identity remain unassigned.

## Foundation receipts, the approximately CA$50,000 figure, and issuer funding

| Flow | Payments | XEM | Historical CAD estimate | Confirmed UTC interval |
|---|---|---|---|---|
| Foundation SEA → NBDCOH | 12 | 221,287.57 | CA$52,553.72 | 2018-04-02 01:01:15 to 2019-09-06 17:42:22 |
| NBDCOH → issuer NC7HKO | 9 | 151,894 | CA$38,339.17 | 2018-04-05 06:24:27 to 2019-03-20 04:36:50 |

The Foundation's own contemporary explanation identifies NASEACH… as the former Southeast Asia account. Its 12 payments into NBDCOH… use regional reference messages, not a KidLetCoin grant description. The approximately CA$52,553.72 value is the sum of each transfer multiplied by that date's XEM/CAD daily close. It is not an exact execution price, bank receipt, approved project budget or present-day balance. [Foundation account explanation](https://forum.nem.io/t/how-long-will-nf-fund-each-region/22488/2); [date-matched price series](https://query1.finance.yahoo.com/v8/finance/chart/XEM-CAD?period1=1522540800&period2=1648252800&interval=1d).

The nine payments onward to the issuer are a separate, overlapping flow. Adding the two totals would double-count possible movement through the same accounts; chronology alone cannot trace identical funds in a mixed balance. Their messages include “calculated at .23 for 4000 USD,” “For April,” “May” and “June.” The last 20,000-XEM onward payment is more than 34 days after the nearest regional receipt of only 601.3 XEM. It cannot simply be labelled a matched Foundation remittance.

### All 12 regional receipts

| Confirmed UTC | From | To | XEM | Public message | Transaction |
|---|---|---|---|---|---|
| 2018-04-02 01:01:15 | NASEAC… | NBDCOH… | 18,741.15 | SEA/2018/04/04 | [c5a1f4ad908b…](https://explorer.nemtool.com/#/s_tx?hash=c5a1f4ad908bc5369a94d8eb0b8c114ef23b7488891d0f4d2b8bc39b6e9d98ff) |
| 2018-05-02 20:57:12 | NASEAC… | NBDCOH… | 18,669.21 | SEA/2018/05/04 | [2ed3f7641c2b…](https://explorer.nemtool.com/#/s_tx?hash=2ed3f7641c2b250411ace074f73a922fba5e0c977cecc83ad22f7d0b5914ff50) |
| 2018-05-04 16:40:21 | NASEAC… | NBDCOH… | 9,440.73 | SEA/2018/05/07 | [eea5afcb38af…](https://explorer.nemtool.com/#/s_tx?hash=eea5afcb38af846b23be953af89094bc045c88be795a2f2a823a4d4430ff38a7) |
| 2018-06-05 15:12:19 | NASEAC… | NBDCOH… | 21,910.45 | SEA/2018/06/04 | [61ad8fb01cf1…](https://explorer.nemtool.com/#/s_tx?hash=61ad8fb01cf16baae8313bda9fbbe662298e705f2b6badee48dee83fc6ffef70) |
| 2018-07-08 19:50:59 | NASEAC… | NBDCOH… | 35,388.31 | SEA/2018/07/03 | [49025cd0e439…](https://explorer.nemtool.com/#/s_tx?hash=49025cd0e4395158046b70ad795bbf4fa08a4fa4dbbf6b08243901925ec0bfde) |
| 2018-08-07 15:48:23 | NASEAC… | NBDCOH… | 37,208.64 | SEA/2018/08/04 | [a776693d646f…](https://explorer.nemtool.com/#/s_tx?hash=a776693d646f0fd382841995155469eeea88d575ee9e472e66332acfb236c8b5) |
| 2018-09-11 18:13:13 | NASEAC… | NBDCOH… | 55,996.8 | SEA/2018/09/03 | [1704d90c693a…](https://explorer.nemtool.com/#/s_tx?hash=1704d90c693a14e21f84a405355981a19a5df63ad7e5b52f861ddbab0fdd1930) |
| 2018-10-08 00:20:28 | NASEAC… | NBDCOH… | 8,821.37 | SEA/2018/10/02 | [1e5710d2b56f…](https://explorer.nemtool.com/#/s_tx?hash=1e5710d2b56ff65481b322415311a283e99fa1f71c40642a993c39a91789efe8) |
| 2018-11-12 08:55:21 | NASEAC… | NBDCOH… | 8,865.08 | SEA/2018/11/02 | [a2acc94f4a12…](https://explorer.nemtool.com/#/s_tx?hash=a2acc94f4a12a23f1eb1c63d12b21f2e9db8900e3dfcc54bcbc04b2c16f540ec) |
| 2018-12-14 08:13:35 | NASEAC… | NBDCOH… | 1,871.3 | SEA/2018/12/05 | [f0fd899a5ad7…](https://explorer.nemtool.com/#/s_tx?hash=f0fd899a5ad729c24068ff5521fa7c589d537b1333190962b6e629bd88722114) |
| 2019-02-13 07:15:46 | NASEAC… | NBDCOH… | 601.3 | SEA/2019/02/01 | [b9b1e216d270…](https://explorer.nemtool.com/#/s_tx?hash=b9b1e216d270e216652d02eba9fc12f0cbce67689c96c4efd41c7778eaebb890) |
| 2019-09-06 17:42:22 | NASEAC… | NBDCOH… | 3,773.23 | SEA/2019/09/01 | [0137e3422de1…](https://explorer.nemtool.com/#/s_tx?hash=0137e3422de11d75421bbc5fb04bac739d3aa81e3b9850a11b046e82942a36a5) |

### All nine shared-account payments to the issuer

| Confirmed UTC | From | To | XEM | Public message | Transaction |
|---|---|---|---|---|---|
| 2018-04-05 06:24:27 | NBDCOH… | NC7HKO… | 17,237 | calculated at .23 for 4000 USD | [3af266b71eff…](https://explorer.nemtool.com/#/s_tx?hash=3af266b71effdc825d436ad3212bd6d1c0675d7f6e16612566888846c4485833) |
| 2018-05-03 10:47:42 | NBDCOH… | NC7HKO… | 16,000 | For April | [acb192c08b5b…](https://explorer.nemtool.com/#/s_tx?hash=acb192c08b5ba0a4ac9c1cead2e2513d13307c2d2f476d7ed6e1b9a016748036) |
| 2018-05-09 03:43:18 | NBDCOH… | NC7HKO… | 8,602 | — | [30e66565ba38…](https://explorer.nemtool.com/#/s_tx?hash=30e66565ba38f30eb652b0c9727d6435bd8eb66297a92151643426e3c3134afb) |
| 2018-06-06 00:39:26 | NBDCOH… | NC7HKO… | 20 | May | [3fe28026c74c…](https://explorer.nemtool.com/#/s_tx?hash=3fe28026c74c7acd7b6dbd684a406847a58475feedd93a04dc9eae4dee82c750) |
| 2018-06-06 00:40:02 | NBDCOH… | NC7HKO… | 20,000 | try try again | [458626ca4b91…](https://explorer.nemtool.com/#/s_tx?hash=458626ca4b91c359bb48001bdc1cea5375e3a65049e9eb8f4d5601dbd4700ea1) |
| 2018-07-10 05:26:39 | NBDCOH… | NC7HKO… | 35 | June | [67938e13bba3…](https://explorer.nemtool.com/#/s_tx?hash=67938e13bba37117f3026966309e1675e74f0956587ab4dd36b1d717bf8be513) |
| 2018-07-10 05:27:09 | NBDCOH… | NC7HKO… | 35,000 | — | [a570b1c7a518…](https://explorer.nemtool.com/#/s_tx?hash=a570b1c7a5186d69c317fb9035426d56ee00f3fcf5dd587f1e15619d22025285) |
| 2018-08-13 04:18:34 | NBDCOH… | NC7HKO… | 35,000 | — | [da3106f872d9…](https://explorer.nemtool.com/#/s_tx?hash=da3106f872d94a731f332f3ef7e340c5ed139de8236e1f1051463f8f9df245be) |
| 2019-03-20 04:36:50 | NBDCOH… | NC7HKO… | 20,000 | — | [d0d92edcccce…](https://explorer.nemtool.com/#/s_tx?hash=d0d92edcccce440102022115588e7aaf67a63e8fbb0b578a0b3d616b19719a1e) |

The four dedicated staging/distributor/development/education accounts have six positive explicit XEM transfers in total, gross 518 XEM including an internal 108-XEM transfer. All senders are in the project register. That narrow finding does not capture financing through the mixed-use issuer or off-chain accounts.

The issuer also received **460 transfers totalling 183,273 XEM** with the public message “Node rewards payout,” from November 2017 through February 2020, and has other non-KID asset activity. These messages establish a distinct category of receipts, with the sender's reward-program identity unverified here. The issuer account's entire financial history should not be described as KID revenue or spending. Full source hashes and classifications are retained in *Historical file: xem_links.json*.

## Shared external destinations and reference links

The complete register screen finds 14 shared external destinations. Their full sender splits, literal reference strings and hashes are retained in *Historical file: xem_links.json*. The three most useful attributable or corroborated leads are below. A shared service address can receive for many customers; matching the address alone does not identify one beneficial owner.

| Address | Observed flow from register accounts | Public attribution and strength |
|---|---|---|
| ND2JRP… | 12 payments; 1,463,032 XEM; four senders; 2018–2021 | Historically corroborated as Bittrex by a DIMCOIN payout statement and a published developer Bittrex API response; no authenticated Bittrex account record obtained |
| NC64UF… | 18 payments; 5,748,124 XEM; five senders; 2018–2022 | Customer forum reports label Binance; official NEM integration examples include the address but do not name its operator |
| NDOYB2… | Issuer 20,000 XEM and NBLIIT 4 XEM on 4 October 2018; identical reference | Possible NEMChange association from memo and third-party label; operator materials explain required deposit messages but do not authenticate this exact address |

Sources: [DIMCOIN payout announcement](https://medium.com/welcome-to-dimcoin/dim-announcement-dd38006e5e59), [published API response](https://github.com/ccxt/ccxt/issues/3511), [NEM integration example](https://docs.nem.io/pages/Exchanges/integration/examples/docs.en.html), [customer report naming Binance](https://forum.nem.io/t/i-didn-t-get-xem-on-binance-when-i-sent-coins/28611), [NEMChange operator announcement](https://forum.nem.io/t/nemchange-com-mosaic-exchange-ico-platform-open-beta/13368), [operator deposit tutorial](https://forum.nem.io/t/how-to-exchange-cache-and-other-mosaics-on-nemchange/17293). These labels are historical leads of differing strength, not live service or customer-account confirmations.

### Complete observed ND2JRP payments from the register

| Confirmed UTC | From | To | XEM | Public message | Transaction |
|---|---|---|---|---|---|
| 2018-06-29 07:06:56 | NCJHET… | ND2JRP… | 20,000 | f1b5d494fa99453fbd1 | [afa10d5b1439…](https://explorer.nemtool.com/#/s_tx?hash=afa10d5b1439f41ebc436751d60974a1d65feb44aa2999ea133ce1b434c509b0) |
| 2018-07-05 02:37:49 | NCJHET… | ND2JRP… | 23,000 | f1b5d494fa99453fbd1 | [d91c6065a634…](https://explorer.nemtool.com/#/s_tx?hash=d91c6065a634085f2c947d585a11aaca76d96d3be0983b92e162ff61a6a08ba6) |
| 2018-08-29 10:37:40 | NCJHET… | ND2JRP… | 10,000 | f1b5d494fa99453fbd1 | [f20ae6730270…](https://explorer.nemtool.com/#/s_tx?hash=f20ae67302702ea5ef4ef1586956c52279a7e7e68f776bfbfed02ae9e10dca40) |
| 2018-09-03 15:17:01 | NCJHET… | ND2JRP… | 20,000 | f1b5d494fa99453fbd1 | [0b36cf65a666…](https://explorer.nemtool.com/#/s_tx?hash=0b36cf65a6660bcd073cc17d8fee454cc10bfaaa9599bfea98fa42bac6806f5a) |
| 2018-09-13 04:00:30 | NCJHET… | ND2JRP… | 23,000 | f1b5d494fa99453fbd1 | [9656d6f8e3bb…](https://explorer.nemtool.com/#/s_tx?hash=9656d6f8e3bb0bd2b36facce4eb542787fbd2c104731d364a0cf24e56006a835) |
| 2019-03-06 03:42:31 | NCEUKZ… | ND2JRP… | 500,000 | 37503ccaac214a018a2 | [905643ede832…](https://explorer.nemtool.com/#/s_tx?hash=905643ede8322b230f03f4b9cb36d0021e49dfdc7705af4d2d03e9a7ff69f1af) |
| 2019-06-06 10:15:21 | NC7HKO… | ND2JRP… | 300,000 | 37503ccaac214a018a2 | [fa86f51c3f2a…](https://explorer.nemtool.com/#/s_tx?hash=fa86f51c3f2a88197aeac376e0f445c3d3bb11ada66163fdcb56aede39825b25) |
| 2020-09-02 04:45:59 | NC7HKO… | ND2JRP… | 269,903 | 997c24d8d8d2475ca7e | [64a1ee070551…](https://explorer.nemtool.com/#/s_tx?hash=64a1ee070551457ee1498d2c17c4c29a0c4dc3c2099171231f7073ab12898e1a) |
| 2020-10-13 02:44:42 | NC7HKO… | ND2JRP… | 287,129 | 997c24d8d8d2475ca7e | [b67702282e6f…](https://explorer.nemtool.com/#/s_tx?hash=b67702282e6f1180b4bbd965c1af05c34762df229b7c96f00a891bd5bd1f2337) |
| 2021-02-15 06:42:09 | NCM2QK… | ND2JRP… | 100 | 35f23a8d1ece435b9ff | [eb9426829922…](https://explorer.nemtool.com/#/s_tx?hash=eb94268299220ed2488f0dce0a8951da2a6487f776b8306c3d3c1fb216b04cd8) |
| 2021-02-15 06:57:48 | NCM2QK… | ND2JRP… | 2,900 | 35f23a8d1ece435b9ff | [d1cf45224bb1…](https://explorer.nemtool.com/#/s_tx?hash=d1cf45224bb169fa282730465fba2d9eec63c6737fca0ab46f0672369e4a1299) |
| 2021-02-17 04:00:29 | NC7HKO… | ND2JRP… | 7,000 | 997c24d8d8d2475ca7e | [591609c430d6…](https://explorer.nemtool.com/#/s_tx?hash=591609c430d6f462918eb0a3feb041fa05998447c04236d69838786ca09c8611) |

The 500,000-XEM transfer from NCEUKZ… on 6 March 2019 follows a 500,000-XEM receipt from the issuer **2 minutes 42 seconds earlier**. The later 300,000-XEM issuer transfer to ND2JRP… carries the same reference `37503ccaac214a018a2`. This gives a useful address-plus-reference reconciliation lead. The larger 1,463,032-XEM total includes other senders, references and dates, and is not assigned to one exchange customer or to KidLetCoin business costs.

| Confirmed UTC | From | To | XEM | Public message | Transaction |
|---|---|---|---|---|---|
| 2018-10-04 04:27:23 | NC7HKO… | NDOYB2… | 20,000 | 166NEMCHANGEDOTCOM166 | [6b952ff29079…](https://explorer.nemtool.com/#/s_tx?hash=6b952ff29079baf2b584892e6c20fdcd2a6c8daa2891c4eb4c2f55259795d050) |
| 2018-10-04 04:34:45 | NBLIIT… | NDOYB2… | 4 | 166NEMCHANGEDOTCOM166 | [8127d29f7363…](https://explorer.nemtool.com/#/s_tx?hash=8127d29f736394a6e208824e1f2f211151d27a9d74dd3e3de3265c9a2c680a1f) |

Both last-table payments use `166NEMCHANGEDOTCOM166` and confirm 7 minutes 22 seconds apart. This links the issuer and its cosigner to the same destination/reference. It establishes neither a KID listing nor a completed sale or cash withdrawal.

## Project control, public names and software links

During all observed KID transfers, the issuer was **2-of-2**, with NCEUKZ… and NBLIIT… as members. NBDCOH… was not an issuer member. The distributor and development fund were **3-of-6**, and education **1-of-6**, sharing NBDCOH…, NBLIIT…, NCEUKZ…, NCJHET…, NCM2QK… and NDMV5M…. Staging remained ordinary. The distributor and education received their initial KID before their respective multisig conversions; development converted before its allocation.

NBDCOH… supplied five actual KID co-signatures in January–July 2019. Its addition to the old Foundation operating account occurred on **26 August 2019**, after those five actions. This is a historical shared-key link, not evidence that it held both roles at every earlier transaction. The issuer moved to a different 1-of-1 signer through October 2021 changes, after the KID expiry.

The public wallet-demo post directly links the names **Laura Takenaka and Laura Walsh** to the same LinkedIn profile path. A first-person 2021 interview under Laura Walsh describes opening NEM's Thailand office and the daughter's token project; the earlier Laura Takenaka candidacy describes involvement in that project. These primary records strongly support continuity of the public professional identity and project involvement. They do not identify every keyboard user or establish exclusive control of a wallet. [Wallet-demo post](https://www.linkedin.com/posts/lauralwalsh_kidletcoin-wallet-demo-video-activity-6491593875063439360-Nte8?trk=public_profile_like_view); [first-person interview](https://www.moneyneversleeps.ie/156-3-is-the-magic-number-laura-walsh-launchpool-and-techstars/); [candidate's forum thread](https://forum.nem.io/t/laura-takenaka-for-secretary-council/20442).

The public source snapshot at commit `d8c2e9b3a364734a17bead61f5549672dfb73de6` describes a customized NEMPay wallet for XEM and KID and explicitly selects **mainnet**. A scan of 94 UTF-8 source files found no fixed matching operational address. Exact public searches for the two secondary common keys and NAYIOJ… returned no attributable names. [Project README](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/README.md); [network initialization](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/providers/nem/nem.provider.ts).

The source's balance/login display paths check the short mosaic name `kid` without requiring the `kidlet` namespace. Transfer confirmation and selected transfer data include the full mosaic ID. This makes a short wallet-display label weaker evidence than the full on-chain `kidlet:kid` identifier; no counterfeit incident is established. The snapshot's app identifier differs from the later contest-linked Google Play package, and no authenticated binary/source match was obtained. [Balance code](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/balance/balance.ts); [transfer code](https://github.com/baconbkk/Kidlet/blob/d8c2e9b3a364734a17bead61f5549672dfb73de6/src/pages/transfer/transfer.ts).

Linking this chain history to a particular contest entrant or collection of children's information would require the actual submission/payment records. The recovered contest deadline coincides with the first 20-KID transfer, but timing and quantity alone cannot identify the recipient or prove the reason for payment. No child identity is assigned in this report. Similarly, exchange-like activity is relevant to investigating how the project operated; a securities or exchange-law conclusion would require jurisdiction, offer terms, operator conduct and customer evidence.

## Every observed KID transfer

| Confirmed UTC | From | To | KID | Public message | Transaction |
|---|---|---|---|---|---|
| 2018-12-09 07:04:02 | NC7HKO… | NADLLJ… | 21,000,000 | — | [59050d1b0674…](https://explorer.nemtool.com/#/s_tx?hash=59050d1b0674e290e04d7619faef8717284e3a08e38a9d08879accacec7df4a3) |
| 2018-12-09 07:29:35 | NADLLJ… | NC6JT7… | 21,000,000 | — | [a907fa0b09a2…](https://explorer.nemtool.com/#/s_tx?hash=a907fa0b09a25f1899e7c96fbaa56bf38b780fce36626e4d0f7fcd4301e45eea) |
| 2019-01-08 01:36:14 | NC6JT7… | NBDCOH… | 1,000 | Give away KID | [63d14a3d3c15…](https://explorer.nemtool.com/#/s_tx?hash=63d14a3d3c156527559048ed8d80a6fad23f018c3f32b3ef6e87211e6d1eef22) |
| 2019-01-09 03:41:52 | NBDCOH… | NDMV5M… | 50 | KID for demo | [5cad79f8d145…](https://explorer.nemtool.com/#/s_tx?hash=5cad79f8d1452649ff06925e3a71dc007945b93ae8899e54975c63a584d963e7) |
| 2019-01-12 10:38:23 | NDMV5M… | NBDCOH… | 10 | KID for demo | [b4904e890f2d…](https://explorer.nemtool.com/#/s_tx?hash=b4904e890f2dc46e215e9e4e2dceb44e35c87752b7a618e0b8484438b66f9f07) |
| 2019-05-04 06:53:28 | NC6JT7… | NDMV5M… | 350,000 | — | [4cfc7be3b6f2…](https://explorer.nemtool.com/#/s_tx?hash=4cfc7be3b6f228cff84f975e597a537657b0d14a6bd649f99810d98e8d0223d4) |
| 2019-05-04 06:53:28 | NC6JT7… | NCM2QK… | 350,000 | — | [896975edd242…](https://explorer.nemtool.com/#/s_tx?hash=896975edd24249459a45c1d323e11372f45b3b125c1ebc590c02a85ccf244353) |
| 2019-05-04 06:53:28 | NC6JT7… | NCJHET… | 350,000 | — | [a1737a7e42a3…](https://explorer.nemtool.com/#/s_tx?hash=a1737a7e42a3fda78421abc371b08563a681e5af1df778fd9f84cfa97b7bbf14) |
| 2019-05-04 06:53:28 | NC6JT7… | NCEUKZ… | 350,000 | — | [e212e8e8be7f…](https://explorer.nemtool.com/#/s_tx?hash=e212e8e8be7f58a99b47479c5015ce8410a582cc309f17198de9ff585e216ca5) |
| 2019-05-04 06:53:28 | NC6JT7… | NBDCOH… | 699,000 | — | [ecfc880d3fbf…](https://explorer.nemtool.com/#/s_tx?hash=ecfc880d3fbfaafdd156156aa377589c6620ad2629573cd5724d5e04a1e72024) |
| 2019-05-04 07:53:30 | NC6JT7… | NA5JKI… | 8,400,000 | kid future development fund | [33c5a6822b73…](https://explorer.nemtool.com/#/s_tx?hash=33c5a6822b730a3677bbec8337fce9ba72cdba83329ec49cb567883a34afdcb9) |
| 2019-05-04 08:35:22 | NC6JT7… | NDSTP4… | 6,300,000 | educational establishment fund | [f9eb7d56d483…](https://explorer.nemtool.com/#/s_tx?hash=f9eb7d56d483c16336cd445933ad32a3cd287b245207929dec8412430c340112) |
| 2019-06-11 01:57:19 | NBDCOH… | NCYKQW… | 20 | — | [899d19b357b0…](https://explorer.nemtool.com/#/s_tx?hash=899d19b357b02601e7a834ec044df9555e0e25be97b4393c7876d66336be4a4b) |
| 2019-06-11 03:37:56 | NCYKQW… | NBQVQ6… | 20 | — | [0cb985eff8d4…](https://explorer.nemtool.com/#/s_tx?hash=0cb985eff8d43358f2c91f0e7e05c4deeee897a024418f4ab257e42315ce3880) |
| 2019-06-11 03:56:24 | NBQVQ6… | ND6D4I… | 10 | — | [e673145da9f1…](https://explorer.nemtool.com/#/s_tx?hash=e673145da9f1b112e5ea77d18fc677c5fcd44311c7a2cc5b1310f46550e7c4f2) |
| 2019-06-11 04:35:53 | ND6D4I… | NCIT7A… | 1 | — | [7366d75af66b…](https://explorer.nemtool.com/#/s_tx?hash=7366d75af66b6a876f63bb39fa801b62931c6bc37e74cfc37c1896fdf3df7cfd) |
| 2019-06-12 03:54:16 | ND6D4I… | NCIT7A… | 1 | — | [d350b011d013…](https://explorer.nemtool.com/#/s_tx?hash=d350b011d013c9fa39a5dbbbeffb72d3a19ae493c988d685439c0d317e577e09) |
| 2019-06-12 04:01:29 | ND6D4I… | NCIT7A… | 1.073681 | — | [3cff7d284c43…](https://explorer.nemtool.com/#/s_tx?hash=3cff7d284c437fdb4aeb3bee1c14a6d06d1acef87ac39b0be46450f89172b8a8) |
| 2019-06-14 09:34:02 | NCIT7A… | ND6D4I… | 1 | — | [26e17e569e01…](https://explorer.nemtool.com/#/s_tx?hash=26e17e569e01511aa3d111f6bb6c55a13f286b5b113c2bd727c1cbd7f42434f0) |
| 2019-06-23 05:53:53 | NBDCOH… | NBXPW6… | 1,000 | — | [9143808ab06f…](https://explorer.nemtool.com/#/s_tx?hash=9143808ab06f768b87ec48e1238bc49aa0fe7383f3c1a414d4d5a4e7f6ad453e) |
| 2019-06-26 08:47:33 | NA5JKI… | NCM2QK… | 700,000 | — | [277e86f0486b…](https://explorer.nemtool.com/#/s_tx?hash=277e86f0486b61633bcaa2723672ac998f9df7262af3619fdbfe838c588cee31) |
| 2019-06-26 08:48:08 | NA5JKI… | NBLIIT… | 350,000 | BJ Founders | [7ee2de0c36c4…](https://explorer.nemtool.com/#/s_tx?hash=7ee2de0c36c4da1d0e0ddfec77f85e3bae3e557606272b1d664bfafb90822cc6) |
| 2019-06-26 08:48:09 | NA5JKI… | NCDYOM… | 350,000 | — | [137082b8ae73…](https://explorer.nemtool.com/#/s_tx?hash=137082b8ae733de7d78b7ae3ba9e7423723033a9d9d3ed6510688df9a170e1f8) |
| 2019-06-26 09:13:06 | NCM2QK… | NA5JKI… | 350,000 | — | [47bd8bbf7bef…](https://explorer.nemtool.com/#/s_tx?hash=47bd8bbf7bef2ef5abec5f4456b523e5177bed4c82477f5723ff6e87ef058db3) |
| 2019-07-11 07:04:56 | NCIT7A… | NBQVQ6… | 0.25 | — | [6b6787e3dc93…](https://explorer.nemtool.com/#/s_tx?hash=6b6787e3dc932030c87a8cf07358347596424b5371d6bf5927e238c4621dcb7d) |
| 2019-07-12 04:48:48 | NCIT7A… | NBYH5N… | 1 | — | [76f7a6b77e3c…](https://explorer.nemtool.com/#/s_tx?hash=76f7a6b77e3c4b2defcac3f75c25e3c8fa2eb66a2ac96de83ffc262da48ecc7d) |
| 2019-07-12 06:14:40 | NBYH5N… | NCIT7A… | 0.2 | — | [640513d8ce8d…](https://explorer.nemtool.com/#/s_tx?hash=640513d8ce8d400b2ffb6fc49ba21f4160bb2127cd6f994b2cfdc950d8274eb3) |
| 2019-07-16 04:56:54 | NA5JKI… | NAHLQE… | 350,000 | — | [668848f80196…](https://explorer.nemtool.com/#/s_tx?hash=668848f801960ed636f3bd31cdface6b2b28018b463f09a52cbf990420d179a0) |

## Full account register and current native-XEM snapshots

| Full NEM address | Observed role / scope | Returned records | XEM balance at dated refresh |
|---|---|---|---|
| NADLLJRTUU73OZ4MU5PY47PUMWQZUGG25GVVRB4X | Staging | 5 | 0.89999 |
| NA5JKIQRYPQ6XB3BT2NQWY4SYH4L6Q43OKVKG2PS | Development fund | 9 | 193.44996 |
| NC6JT7YGYASHVZ2NNS4TK372PTDXBUS354XG7TL4 | Distributor | 12 | 95.34992 |
| NC7HKOMA4N4ZCYJ7PXJPUGGQLSBLQL6S6LEFQHNZ | Issuer | 780 | 1,285.451439 |
| NDSTP4YZPMGACPKS26PV4U4VX63WZRD76UNB7IRL | Education fund | 3 | 99.5 |
| NCM2QKZZ3AYMGYBMQSQ2ETCXDNDF33NDO2R2E2PX | Signer / allocation | 64 | 151,678.296476 |
| NCEUKZQJXJGQSTEWUIRURSQVX2MDTXU5ZW37YQ4I | Definition initiator / levy / signer | 146 | 408.30028 |
| NBLIITQIUKQFK5NFB2L2TPE65B4N3HSHR7KPNU6I | Definition cosigner | 145 | 176.75005 |
| NDMV5M4Y2GKQOJ3C4W6HYUK32PSEWLKRHPGS4V2V | Signer / allocation | 25 | 99.59999 |
| NCDYOMFFNO5T567SBODMNGZAYBGWREFCIGZ7T26J | Allocation wallet | 75 | 999.362201 |
| NCJHETVLYHK5C3GGO27HNRMBHCLPBSXYRL4WPHJ5 | Signer / allocation | 93 | 237.977952 |
| NBDCOHCTOKI3RY46YK7EEPPQRG2UHPCNUQIDVLU5 | Shared project / Foundation signer | 788 | 102.817815 |
| NAWYC2U3JALUO26BU3FFI4A6U7J24Q2KCIBIMFYQ | Later issuer signer | 32 | 31.95 |
| NAHLQEVQ6GI2P67GFRTNGSAKP35XC6WPBBZLR2ZS | Allocation wallet | 13 | 145.239588 |
| NBFOUNDXB54PVVPG6AN4WJ7BAOYFBC2XLLHDU5YM | Old Foundation operating | 584 | 0 |
| NASEACHB4GDLNLC2EGU7KQB3T2WY23UWTNVUSLKH | Foundation SEA regional | 276 | 0 |
| NBXPW6HJ4UFHPOWMFRKI2Q4KOL7PIA6YAOGHU6ZI | KID transfer participant; public identity unassigned | 2 | 5 |
| NBQVQ64MHCOXTFSNQNZOX2JQE4W2LCI6YCITE4FP | KID transfer participant; public identity unassigned | 8 | 1.30998 |
| NCIT7ATTMW67VKKSD5DKIWZVKITN5GSHNSC264CP | KID transfer participant; public identity unassigned | 24 | 0.68851 |
| NBYH5NYA4GOH4V6HEQQKVWCRZBTMRY7L356JUEQK | KID transfer participant; public identity unassigned | 5 | 1.823318 |
| ND6D4I6T2UD2ZVFR5UWLW6PAIEXMFCNN5BIMHWOS | KID transfer participant; public identity unassigned | 9 | 6.371436 |
| NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE | KID transfer participant; public identity unassigned | 32 | 0 |
| NBGTCBEUP2YW4Y47Q2ACZYCDME6VV6OVVBN7PSS3 | Shared secondary-wallet cosigner | 31 | 0 |
| NAYIOJM4JXMZXX4QLKROYKTIRGS66244RT6W6PH3 | Recipient of parallel XEM payments | 7 | 0.106666 |

Native-XEM balances above come directly from the dated account-state refresh; they are not KID balances, project-owned cash totals or current dollar valuations. The reports preserve retrieval timestamps per account. Some accounts are multisig signers or institutional accounts with broader activity.

| Additional referenced address | Role in this review |
|---|---|
| NB3RVCUTXBD7D775SUACUBPDHZFXTEX3SMRMLN3C | Secondary shared-control neighbor; full standalone history not collected |
| NBQWPYOIRII6MWE4MPPM2WZMVN24QWFUFL7H2YXH | Secondary shared-control neighbor; full standalone history not collected |
| ND2JRPQIWXHKAA26INVGA7SREEUMX5QAI6VU7HNR | Shared external destination; historical Bittrex attribution corroborated |
| NC64UFOWRO6AVMWFV2BFX2NT6W2GURK2EOX6FFMZ | Shared external destination; Binance label unverified directly |
| NDOYB24G46N53HYTCP66Q5K4RYT4XFWKDW4CM3DI | Shared external destination/reference; possible NEMChange |
| NCPAYOUTH2BGEGT3Q7K75PV27QKMVNN2IZRVZWMD | Sender of issuer receipts labelled Node rewards payout |

## Evidence package and what would resolve the remaining questions

The companion ZIP includes this report, full normalized and raw account histories, terminal-page provenance, the complete KID index, selected blocks, lifecycle/control replay, public-source captures, calculations and SHA-256 manifests. The earlier baseline evidence and CAD valuation package are included as clearly named dependencies. Analysis notes preserve their original staged scope; this report and `normalized-summary.json` give the final 24-account scope.

The most useful outstanding records are: grant approvals and invoices for the regional payments; declarations or custodial records assigning the operational keys; account records matching the exact exchange destination/reference pairs; the reciprocal-transfer software/terms and any merchant invoices; and contest submission, consent and payout records. Each would resolve a specific observed link. The public blockchain supplies amounts, ordering and signing authority; those business records supply purpose and named counterparties.
