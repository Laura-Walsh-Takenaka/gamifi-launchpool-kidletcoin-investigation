# Research Paper — Related UK companies: ownership and transfer-document check

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Research date: 2026-09-06 UTC. These findings derive from Companies House issuer filings, including original PDFs and separately downloadable iXBRL accounts. Ownership figures are date-specific. No contact or paid order was made.

## Outcome

The reviewed related-company filings did not disclose a merger, continuation, parent/subsidiary relationship, or named sale/assignment of Launchpool shares, website, contracts, token business, or assets between UK LAUNCH POOL LTD (12992979), the Virgin Islands Launch Pool Limited named in historical terms, and Asociados Carajo Inc. This is a bounded negative search result, not proof that no transaction occurred. The site migration FAQ is evidence of an announced new company; it is not the missing conveyance or corporate-identity instrument.

## 1. ALPHABIT PROJECTS UK LTD — 12327183

Incorporation dated 21 November 2019. PDF page 5, Initial Shareholdings, visually verified. One class of 100 ordinary shares, nominal £0.04 each, total nominal capital £4:

| Named subscriber | Shares | Fraction of issued shares |
|---|---:|---:|
| RICHARD SIMPSON | 25 | 25% |
| ANDREW IVISON | 25 | 25% |
| OSCAR LINDLEY-SMITH | 25 | 25% |
| LIAM ROBERTSON | 25 | 25% |

This documents earlier common ownership by the Launchpool/Alphabit principals. It does not name SCR Advisors, the Virgin Islands entity, or Asociados Carajo. Filing history contains incorporation and compulsory strike-off notices, with dissolution dated 6 July 2021; no accounts or asset-transfer document appears in that filing list.

Source: https://find-and-update.company-information.service.gov.uk/company/12327183/filing-history/MzI0OTkwOTgzNWFkaXF6a2N4/document?format=pdf&download=0

SHA-256: 3b95be143b458919e5389d7e95f7252ca4fb28a0bd2649292fdf6c48823a5c8b

## 2. LAUNCH HORIZONS LTD — 13672315

Incorporation dated 11 October 2021. Initial Shareholdings section, PDF page 5: RICHARD SIMPSON subscribed the sole ordinary share, nominal £1 (100% of issued shares). PSC section identifies MR RICHARD JAMES SIMPSON. The 2025 confirmation statement still reports one ordinary £1 share but does not independently restate a current shareholder schedule.

Accounts for periods ending 31 October 2022 and 31 October 2023 report one employee, computer equipment, cash and director loans. No named Launchpool investment, subsidiary, offshore operator, intellectual-property asset, or related transfer is disclosed. Do not treat similarly named Launch Horizons as a Launchpool parent or successor from these records.

Source: https://find-and-update.company-information.service.gov.uk/company/13672315/filing-history/MzMxNjY1Nzc2OWFkaXF6a2N4/document?format=pdf&download=0

SHA-256: 41f909dc3b1399738f2c08c2b395d52ef7c18cb7e5c70c7a568cd5912be0343e

Source: https://find-and-update.company-information.service.gov.uk/company/13672315/filing-history/MzM5MTYxMTI2NmFkaXF6a2N4/document?format=xhtml&download=1

SHA-256: f35dd5c7816ceb42a1b153c7d7dda9d788ff95df347505a8d9c86ae5ec938004

Source: https://find-and-update.company-information.service.gov.uk/company/13672315/filing-history/MzQ0MTI1MDM2MWFkaXF6a2N4/document?format=xhtml&download=1

SHA-256: 405b90ca8ca6c1b3e4ddd3f82d7d7a3cbfebc016ee601e241cdf1797b321f651

## 3. ALPHABIT CONSULTANCY LTD — 13482392

Confirmation statement dated 18 October 2021, PDF page 2: sole ordinary share transferred from LIAM ROBERTSON on 13 October 2021; FELIX ORAM holds one ordinary share at the statement date. Separate director/PSC entries give 12 October 2021, so do not conflate the two dates.

Accounts for year ended 30 June 2023, page 5 (Statutory Information), expressly state the company is in the process of being wound up; page visually verified. Pages 6-7 list disposal of fixtures/computer equipment. No purchaser or transferred Launchpool business is named. Filing history records compulsory strike-off dissolution on 26 March 2024. This is a separate documented closure branch, not proof of the Launchpool offshore reorganisation.

Source: https://find-and-update.company-information.service.gov.uk/company/13482392/filing-history/MzMxNzMyMDgxN2FkaXF6a2N4/document?format=pdf&download=0

SHA-256: d2f4852089091f2c17ad77951c3c5335d794ae87f0bae0ac5bacd53fb0b136c0

Source: https://find-and-update.company-information.service.gov.uk/company/13482392/filing-history/MzM4NTkxNjMzM2FkaXF6a2N4/document?format=xhtml&download=1

SHA-256: 4ec8dc6f3ba17d4623e68594d0d123a38638e457a501a742ac00e8a54c2f9efc

## Preservation and limits

Original raw documents, derivative text, rendered PNGs and retrieval receipts are adjacent. SOURCE_MANIFEST.json includes original/final URLs, retrieval timestamps, hashes and verification. Current launchpool.xyz terms returned HTTP 502 to direct fetching; that failure receipt is retained. Historical terms/migration snapshots were preserved separately by the parallel research.

Searches for exact Launchpool legal names combined with acquisition, restructuring and new-director language produced the already-known terms/migration pages, but no additional corporate transfer document. Raw registry filings are publicly submitted records; their presence does not independently verify every underlying assertion.
