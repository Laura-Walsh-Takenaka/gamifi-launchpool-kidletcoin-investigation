# Research Paper — Techstars / Cardano audit notes

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later Cardano correction.** The validated Cardano review resolves the apparent budget-allocation and cohort-size discrepancies through the approved milestone records. Payment tranches are not spending categories; twenty selected companies and eighteen graduates are reconciled. Earlier unresolved-budget or missing-delivery wording must be read with that correction.

Checked 2026-09-05. Passive public-source research. These are intermediate analyst notes, not a finding of illegality or individual culpability. All source-derived summaries below stay under 200 words per source; direct quotes under 25 words per source.

## CORRECTION AFTER FINAL REPORT RECOVERY

The research recovered the official final report; it is dated February 27, 2026. Local extraction: `techstars_2025_final_report_extracted.txt`. Source: https://milestones.projectcatalyst.io/projects/1300182/milestones/6 (publisher milestone links to the final report)

The report explicitly records twenty selected companies and eighteen graduates. That explains the eighteen presenters; remove any suggestion that differing selection/presentation totals are unexplained. Its mentor roster names Laura Walsh, independently corroborating her 2025 Cardano mentoring role. No specific September 2026 assignment was verified.

The report documents ten weeks of instruction, twelve masterclasses, 447 mentor meetings scheduled, 92.83% average masterclass attendance, and twelve accelerator applications. It distinguishes 230 showcase RSVPs from 186 live viewers: do not describe Luma's 230 Went figure as actual attendance. Post-program coaching and continuing resources are documented. Commercial highlights and pitch-competency changes are founder-reported; they establish reported activity, not audited program-level investment returns. The recovered extraction contains no budget reconciliation or detailed cost schedule. Original-versus-current grant allocation differences remain a public reconciliation question, not evidence of unauthorized spending.

Ignore draft instructions extracted from speaker notes as visible slide defects unless rendering independently establishes visibility.

**Correction applied:** the earlier access failure was a tool-route limitation, not a finding that the report was unavailable to the public; earlier self-report-only and unexplained-presentation-count findings have been removed.

## Recommended finding

The substantive issue is an unreconciled public presentation of cohort scope, program duration, and spending categories. The evidence also establishes that the program actually operated and its grant was marked complete. Laura's 2025 Cardano mentoring role is corroborated by the official final report; her prior Techstars Web3 involvement has independent first-person corroboration. No specific September 2026 assignment or individual responsibility for program budgets was established.

## A. Catalyst grant record — strongest documentation discrepancy

Source: https://projectcatalyst.io/funds/13/cardano-partners-growth-and-acceleration/techstars-will-help-cardano-builders-grow-their-businesses-to-drive-cardanos-adoption

Official record #1300182 reports complete; 1,300,000 ADA distributed, zero remaining. Main applicant is Techstars / Piotr Godzinski. Original proposal says six months and up to 30 startups (another milestone paragraph says 30). Current schedule spans May 2025–February 2026, ten months. Original narrative versus current milestone allocations:

| Category | Proposal narrative | Current completed schedule |
|---|---:|---:|
| Initiation/foundation | 5% | 5% / 65,000 ADA |
| Sourcing/application/marketing | bundled | 20% / 260,000 ADA |
| Selection/setup | 5% | 20% / 260,000 ADA |
| Core delivery | 80% | 30% / 390,000 ADA |
| Pitch showcase | 5% | 10% / 130,000 ADA |
| Post-support/report/video | 5% plus final reporting 0% | 15% / 195,000 ADA |

Detailed operational costs are expressly withheld as proprietary. The page uses broad accelerator fundraising statistics to support this pre-accelerator's value proposition. Neither provides this cohort's investment outcomes. The official final report was recovered through Drive. **Interpretation:** scope/category differences warrant reconciliation; amended milestones can explain changes. The record supports completion, not misuse. No Laura budget authority appears.

## B. Actual cohort delivered; small roster discrepancy

Source, published 2025-10-10: https://www.techstars.com/blog/program-news/introducing-the-2025-techstars-cardano-founder-catalyst-cohort

Official announcement states 20 companies from 16 countries started October 6, 2025; pitch showcase planned December 9. Its visible named list contains 19: Andamio, Atrium, Bloccpay, Blockera, GENGHIS, GenWealth, Kwikpik, NOTARIFY, Rentity, SmarTrust, Synthwave, TAGBASE, Terralima, Chaincademy, Thellex, UTXOS, UzimaNexus, WineOpSys, Winks.fun. This is a low-severity publication/roster discrepancy, not proof that twenty were not admitted. Announced twenty meets the later published 15–20 selection range. Audra Gibson is named program lead.

## C. End-of-program event and team

Source, event dated 2025-12-09: https://luma.com/wj302xak

Public event page is marked past and shows 230 Went; that platform figure is not independently verified attendance. It lists eighteen presenting companies, matching the final report's eighteen graduates from twenty selected companies. Event team names Audra Gibson, Prince Conley, Mike Sotirakos (entrepreneur in residence), Alex Cottingham, Sara Lila Cordero Porta, Abhishek Bhattacharya, Piotr Godzinski and Katie Smith. Laura is omitted from that operational team list but appears among mentors in the final report. Selection/graduation totals are reconciled by the final report. Generic participation text references Techstars Startup Weekend although this is a Founder Catalyst virtual showcase: minor template hygiene fault.

## D. Program type / current status

Source, current: https://www.techstars.com/founder-catalyst

Current official description is a ten-week, part-time, mainly virtual pre-accelerator. It expressly has no equity exchange. Listed current programs include Alabama, Global Fall 2026, EIT Urban Mobility and USC; Cardano is absent. This helps distinguish Founder Catalyst education/mentoring from Techstars investment accelerators. It does not prove Laura stopped mentoring elsewhere.

Source, published 2025-06-23: https://www.techstars.com/blog/program-news/techstars-and-cardano-foundation-launch-new-founder-catalyst-program

Cardano partnership announcement selected a planned 15–20 companies for October–December 2025. Its dedicated program-information link https://www.techstars.com/techstars-cardano-founder-catalyst returned 404 on this review. Treat as website maintenance/currentness weakness, not proof of a nonexistent program. The $150 million figure in the announcement concerns Project Catalyst's entire grant history, not money raised by Laura or this cohort.

## E. Laura role evidence and corroboration

Source, current search-indexed public profile: https://ca.linkedin.com/in/lauralwalsh

Indexed experience says Business Mentor, Techstars Founders' Catalyst Cardano, September 2025–Present. Direct page fetch failed. The continuing status is self-reported; the 2025 Cardano mentoring role is independently confirmed in the official final report. No current named September 2026 assignment was found in targeted searches. Do not turn absence of named assignment into proof of false credentials.

Source, published 2025-07-23: https://www.linkedin.com/pulse/techstars-web3s-evolution-my-next-phase-pete-townsend-e6zpe

Former program managing director Pete Townsend describes Techstars Web3 evolving into support across Techstars, and his own departure from that role. He expressly credits Laura for helping start the program and years as entrepreneur in residence and All-Star Mentor. This is independent corroboration of historical involvement; it does not validate every self-reported current title. It also predates the Cardano cohort and should not be used to conflate that cohort's EIR position with Laura's earlier Web3 role.

## F. Final report recovered

The research recovered and inspected the official final report. Do not include an access/absence finding based on the web tool's failed copy/preview/export routes. The report independently confirms Laura as a program mentor and twenty selected/eighteen graduated companies. It explains why eighteen founders presented. Its operational outputs are material counterevidence to suggestions that this was a nonexistent or undelivered project.

Milestone amendment history was not inspected; budget-category changes cannot be labeled unauthorized.

## Interpretation boundaries

- Supported finding: dated 2025 program; meaningful public budget/scope reconciliation gap, with verified grant completion and actual cohort activity as counterevidence.
- Only minor issue: the launch article names19 while announcing20. The final report confirms20 selected and18 graduated, reconciling the18 presenters. This editorial issue has little investigative weight.
- No evidence found connecting Laura to grant control, personal receipts of ADA, grant misappropriation, or participant misconduct.
- The earlier assessment was incomplete in describing cohort delivery as unverified/planned: new official records substantiate execution and completion.
