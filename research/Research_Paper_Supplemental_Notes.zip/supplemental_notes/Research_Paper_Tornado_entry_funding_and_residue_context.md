# Research Paper — Tornado entry, funding and residue context

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The two already identified BSC depositors made **22 successful deposits totaling 1,210 BNB**: 1,050 BNB from `0xd676f7588eecd619966d76e91b2a98afb86dbe17` in April 2022 and 160 BNB from `0x3f96363354505c8b95108b1cd80be84cc960559d` in July 2022. This review independently re-decodes their preserved transaction inputs and deposit logs, checks every sender nonce, and recomputes gas and native balances. It does not retrieve new wallet histories or identify corresponding Tornado withdrawals.

The on-chain sequence supports scrutiny of privacy-pool use after GMI sales and liquidity redemption. **It does not establish why privacy was selected, who ultimately received the deposited funds, or whether the use was improper.** The common upstream address, `82f779…23b0`, links the two entry episodes through explicit public transactions. It is not a deposit-to-withdrawal link or a human ownership finding.

## What this review adds

Previously established facts are the 15 April deposits, seven July deposits, underlying sales/liquidity transactions, and the transparent bridge branch. New analysis here comprises a unified 22-deposit register, exact timing comparisons, cross-episode funding/gas context, an independently recomputed native ledger, and separation of residual payments from any potential pool exits.

Canonical outputs:

- `entry_exit_context.json`: complete entry context, native ledgers, exact timings, source paths and SHA-256 manifest.
- `verified_deposit_register.json` and `VERIFIED_22_TORNADO_DEPOSITS.csv`: every deposit's full hash and public transaction URL, UTC, amount, nonce, pool, commitment, leaf index, and log index.

All **22 transaction hashes, commitments, and (pool, leaf-index) pairs are unique**. There are 11 deposits of 100 BNB and 11 deposits of 10 BNB. These are public deposit identifiers; neither a commitment nor its leaf position supplies a public withdrawal mapping.

| Pool | Denomination | Deposits | Total |
|---|---:|---:|---:|
| `0x1e34a77868e19a6647b1f2f47b51ed72dede95dd` | 100 BNB | 11 | 1,100 BNB |
| `0x330bdfade01ee9bf63c209ee33102dd334618e0a` | 10 BNB | 11 | 110 BNB |

All 22 transactions call the same preserved official deployment proxy, `0x0d5550d52428e7e3175bfc9550207e4ad3859b17`, using selector `0x13d98d13`. The pool address, denomination and commitment agree between calldata, transaction value and the pool's emitted deposit log. July block timestamps and April emitted deposit timestamps were independently checked against the preserved records; sale and funding timestamps also agree with preserved block headers.

## April: sale-to-entry gaps of minutes

The complete examined `d676` history contains three normal funding inputs and 15 sent transactions. Every sent nonce, 0–14, is a successful Tornado deposit. There is no other normal outgoing payment.

| UTC | Funding source | BNB received | Verified transaction |
|---|---|---:|---|
| 2022-04-27 23:53:42 | `82f779…23b0` | 537.354950490763970008 | [ae4eb62f…3874](https://bscscan.com/tx/0xae4eb62f219644855bffc96d4a1ef845353bc7d342ffb8028f613c0e91b73874) |
| 2022-04-28 01:03:25 | `e696c9…63c9` | 355.635757037430744678 | [b4083e4e…0dd1](https://bscscan.com/tx/0xb4083e4efa7951ddddd9215368a26fb2a5cbbc0551d8e5ba27c912a355340dd1) |
| 2022-04-28 01:20:28 | `e696c9…63c9` | 157.372532010714716603 | [2e43fccd…2348](https://bscscan.com/tx/0x2e43fccdd1ceaacc8e4294a3c1817a2c1246070928be63450441ba4065802348) |

The first funding transaction follows `82f`'s sale of 28,333,333.33 GMI for 536.357104816631222167 BNB by **18 seconds**. The [first 100 BNB deposit](https://bscscan.com/tx/0x225385ec5f3ca3d0df75d0b425d60edb5826be7f6640b395fada36b80cf893b9) follows that [sale](https://bscscan.com/tx/0xa252c8aea7a8998cd2b9a747fdedee2ba701ef82618cfb652374d23dfbc745a2) by **216 seconds**, or 3 minutes 36 seconds. The first five 100 BNB deposits finish within 24 seconds of the first deposit.

Two later sale/entry sequences recur in the same episode:

| Last relevant GMI sale | Next deposit | Gap |
|---|---|---:|
| [2022-04-28 01:01:46](https://bscscan.com/tx/0x909a4c45c9fa545b6cbcbc04928a3cac54fba2865790b40b048b57f325a1cf9b) | [01:04:04, 100 BNB](https://bscscan.com/tx/0xcfb23dcb794055aa7a371cd070fe0dd52bdcddee2acbe2bac5fc157e0c73200d) | 138 seconds |
| [2022-04-28 01:19:40](https://bscscan.com/tx/0x2be4993e5eed5b66c375ec1b123597470c67fae2b5b9ba8750a4ea1a2656ac9c) | [01:20:49, 100 BNB](https://bscscan.com/tx/0xd315369202558e5ec61e064b30fa6d4aa8b7bfc426c3d30e1106278cd554b32c) | 69 seconds |

All ten April 100 BNB deposit leaves are consecutive, 7911–7920; the five later 10 BNB leaves are 27484–27488. Their adjacency establishes entry order, not a common withdrawal recipient.

Four successful sales by `82f` and `e696` produced **1,048.456700160480855245 BNB** from **102,344,817.930000000000393216 GMI**. The upstream wallets also contained native funding. Consequently, **do not describe all 1,050 deposited BNB as exclusively GMI sale proceeds**. The exact already verified bound is that at least 512.667963964236029992 BNB of the later 550 BNB deposits came from `e696`'s native inputs. That bound applies to its aggregate native inputs, not solely its GMI sale output.

`d676`'s exact reconciliation is:

`1,050.363239538909431289 received − 1,050 deposited − 0.068667195 gas = 0.294572343909431289 BNB remaining`.

The residual agrees at the final deposit block and preserved snapshot block 120438009, when its sender nonce remained 15. No separate gas sponsor or final dust recipient appears in this complete normal history. Two unsolicited, noncanonical token-index receipts do not supply BNB and were excluded from the funding account.

## July: liquidity redemption, sales, and a precisely sized conversion

The July depositor's sole normal native input was **0.086571505 BNB from the same `82f` address**, [2022-07-26 19:12:58](https://bscscan.com/tx/0xa259ba0f28f2c7c09f02e94d9fad0467b34e2036a616ee424679acf885f2b300). It had received **40,373.258476372699138973 GMI/WBNB LP tokens from `82f`** [22 seconds earlier](https://bscscan.com/tx/0x93dde2523a170de4141d1d85b17cbf3ff51e492c3a9f4b9bd1aba467721cc5d3). The original deployer had sent `82f` **0.08707584 BNB** at [19:11:43](https://bscscan.com/tx/0x3dd6c7750e096ee819604dce140b35723781e9658dea701c14fe963d588e5d82), 28 seconds before the LP returned from its holding contract.

The [liquidity redemption at 19:16:15](https://bscscan.com/tx/0x05825745ee139617c9556b736d683c9be6c58f8706e4c9376349852a727bc0db) returned 149.416984524612079818 BNB and 37,905,741.088307672990198554 GMI. Seven successful sales then converted all that GMI into 104.818395856200820155 BNB. The last sale completed on July 26 at 19:25:00; the [first Tornado deposit](https://bscscan.com/tx/0xd6875407f8ee64a3c24ac16c0a72d5c760e46f747b01955df83a5d27a5bb8c64) occurred July 27 at 06:19:00, **10 hours 54 minutes later**. This was not the same immediate sequence as the first April sale.

The native BNB returned by liquidity redemption and the seven GMI sales sum to **254.235380380812899973 BNB**, before gas and the small native input. The 160 BNB of Tornado deposits therefore cannot be attributed exclusively to GMI-token sales: liquidity redemption itself also returned BNB.

After four 10 BNB deposits, the wallet [converted 213 BNB into 53,819.561154174143476044 USDT](https://bscscan.com/tx/0xed7441945b837947df750d80b2ab7eca9f1310d13e1c1e695421da076eb41cce) at July 27 06:44:45. It then converted **30,355.429158167946184413 USDT back to exactly 120 BNB** at [08:47:14](https://bscscan.com/tx/0x05e8298159db88082c8d4c0cf527f5ac1ec3f71387b8097f453635e892906506).

The following deposits total the same 120 BNB:

| UTC on July 27 | BNB | Transaction |
|---|---:|---|
| 08:48:29 | 100 | [080d35c4…c0f9](https://bscscan.com/tx/0x080d35c43a1235b8bdda69eeb687a7dee748c77e0e4d15514f370114973ac0f9) |
| 08:48:50 | 10 | [f54f5151…4303](https://bscscan.com/tx/0xf54f5151e5b8cf18344ca35f114620bed8f5fb21af2d50f7682d70db00254303) |
| 08:49:14 | 10 | [97e776ec…03ff](https://bscscan.com/tx/0x97e776ec95f06406ed824859697a087bf6029dc4b5857456c9281c2ae25903ff) |

The first follows the conversion by **75 seconds**, and the entire 120 BNB batch finishes **120 seconds** after the conversion. This is a stronger entry-context observation than a generic same-day timing resemblance: the same wallet executes the conversion and then the deposits in its next three transactions. It still does not identify any withdrawal or demonstrate a motive. The converted BNB commingled with the wallet's existing balance; reconversion is not additional fresh proceeds.

## Outside-pool money and residue remain separate

After its final deposit, `3f963` retained USDT and a small BNB balance. Its subsequent transparent branch is already supported by preserved evidence:

1. [July 27 17:42:27](https://bscscan.com/tx/0x516c42eee0e4d998713a57769f25be972d78384355b079da7d0dc1423ec66320): remaining 23,464.131996006197291631 USDT converted into 90.889264512977146964 BNB.
2. [17:54:39](https://bscscan.com/tx/0xed40dcd423c79e1cde8cd73f15cd1e37758209e2ed01ac64215b79bba39e9598): 92.138285049790046937 BNB converted into 15.726561608181446966 Binance-pegged ETH.
3. [18:21:09 BSC transaction](https://bscscan.com/tx/0xa8e1d7800e5c2816168646971fa0e2d150ac06980fa8fbedbddeaa03b70392f0): 15.7265 pegged ETH bridged to Ethereum, with the same `3f963` recipient in calldata. The [Ethereum receipt at 18:22:13](https://etherscan.io/tx/0x3eb89d6f7342d39d673190e582a5b9cddfbcbc813c0f72018bca575f6dc44cac) explicitly references the BSC source hash and delivers 15.7105 ETH. This linkage is supported by the explicit source hash, not an amount/time guess.
4. Existing Ethereum records then show `3f963 → f731087…25d → dd5217…07b`. The last wallet commingles other inputs before forwarding USDC to `525a234…494`, a GnosisSafeProxy. No exchange attribution is established for this endpoint in that evidence lane.

**This transparent branch does not pass through Tornado and is not a Tornado exit.** Ethereum verification remains limited to preserved Blockscout transaction input, logs and native internal-index evidence; the earlier independent Ethereum archive-node attempts did not succeed.

A later ordinary BSC residual payment is also explicit: on **2022-10-04 14:05:11**, final sender nonce 25 transfers **0.008380045 BNB** to **`0xad11dd979ce35912e8510e1bc84ba94326aa5b58`**, [transaction 3380b57c…d8e1](https://bscscan.com/tx/0x3380b57cfaa07755264e207a7c99116848cad17a3a9bc9e31063520fb82fd8e1). The 0.000105 BNB gas fee uses the remaining native balance, leaving zero BNB. The preserved snapshot at block 120445122 has nonce 26 and retains only 0.000061608181446966 pegged ETH among the tracked nonzero token balances.

An exact-address search of existing research JSON/CSV/Markdown outside raw files found `ad11` only in the four preserved `3f963` history/ledger files. No additional established edge was found in that bounded local corpus. Its wider history was not scanned. It should be retained as a future lead, with no exchange, ownership or Tornado-withdrawal attribution.

## Gas and coverage

| Depositor | Verified records | Complete sender nonces | Successful / failed sent | Tornado gas | All sender gas | Final BNB |
|---|---:|---|---|---:|---:|---:|
| `d676` | 18 | 0–14 | 15 / 0 | 0.068667195 | 0.068667195 | 0.294572343909431289 |
| `3f963` | 28 | 0–25 | 24 / 2 | 0.032496925 | 0.064551304 | 0 |

`3f963`'s two failed calls incurred gas but no successful token/native movement. Every verified native ledger step remains nonnegative, every sent nonce is present, and both final native balances reconcile exactly with their preserved account snapshots. The July ledger includes 465.124644893790046937 BNB of router native outputs; that accounting total includes USDT reconversions and must not be reported as new proceeds.

The parent investigation's pool withdrawal-window review is a separate evidence lane. This file establishes funding, deposits, timing and transparent residual branches only. A withdrawal recipient, relayer or exchange link must be supported independently; shared denomination, proximity in time, common infrastructure or the existence of a connected pre-deposit wallet is insufficient by itself.
