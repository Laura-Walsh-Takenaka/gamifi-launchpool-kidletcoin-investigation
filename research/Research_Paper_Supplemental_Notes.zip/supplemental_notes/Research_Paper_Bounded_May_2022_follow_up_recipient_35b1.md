# Research Paper — Bounded May 2022 follow-up: recipient 35b1

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Scope: first two ordinary signed transactions after the May 17 GAMI-associated receipt. This is a bounded inventory, not the wallet's complete historical accounting.

**The GAMI-associated receipt entered a substantial pre-existing BUSD balance.** At block 17,878,871 the address `0x35b119730f79881dac623dc51c831c6a04cab5f3` held **183,169.280000000000000012 BUSD**. At receipt block 17,878,872 it held **211,590.421280969119319271 BUSD**, a difference of exactly **28,421.141280969119319259 BUSD**. Incoming receipt from 56aa is documented in the companion lane, transaction `0x9339942839aa8aa7e023b41b91c536b466f34fc32ced0ac9810ca21ba70eef04`.

Historical nonce is **122 both immediately before and immediately after that receipt**. Thus the two located transactions, with actual signed nonces 122 and 123, really are the first two ordinary signed outgoing transactions after receipt; there is no unexamined intervening ordinary signed nonce.

| UTC | Signed nonce | Token/amount | Recipient | Transaction |
|---|---|---|---|---|
| 20 May 2022 07:16:05 | 122 | 4,850 USDC | 0xe6020805fd96142811cbfbc67627679f2c446d30 | 0x4def1582d5e6df2f5c0dd026813c9190c4757b7ee0e67999929893c78bf31b30 |
| 20 May 2022 15:54:40 | 123 | 1,100 USDC | 0xe6020805fd96142811cbfbc67627679f2c446d30 | 0x526be9537193968a127c7b35255778697cc6568725d5da4e83fa8d8dd5e62e82 |

Both receipts succeeded and show a direct `transfer` of token `0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d`. Live token calls confirm symbol USDC and 18 decimals. Neither transaction contains a BUSD transfer or approval. They total **5,950 USDC**. **These are not established as spending of the GAMI BUSD receipt**: a different asset was transferred and a large pre-existing BUSD balance was present. No conversion of the incoming GAMI BUSD into these USDC payments was established.

The public source repository designates 35b1 as a MemberCard treasury, but the master investigation treats that as a source-only association unless the historical implementation is independently matched. It does not name the controller of the signing key or prove entitlement.

An exact-recipient web search returned unrelated low-value token distribution records; no personal or corporate owner was identified. The Etherscan same-address public page was preserved but supplies no verified ownership of the BSC recipient. No service or banking settlement is assigned.

Evidence: `may_receipt_balances.json`, `may_receipt_nonces.json`, `nonce_123.json`, `nonce_124.json`, `usdc_metadata.json`, and original cached RPC request/response envelopes in `chain_raw/`. File numbering uses the count-crossing target (123/124); actual signed nonces are 122/123, explicitly encoded in transaction data. Historical state came from QuickNode; complete blocks and receipts from Binance RPC. No all-period BUSD event scan or delegated-transfer inventory was performed.
