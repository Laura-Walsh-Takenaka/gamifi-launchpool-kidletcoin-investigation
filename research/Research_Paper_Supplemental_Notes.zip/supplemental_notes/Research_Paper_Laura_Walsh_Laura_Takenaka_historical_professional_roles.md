# Research Paper — Laura Walsh / Laura Takenaka — historical professional roles

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Reviewed 2026-09-05. Public business records only. Historical titles below do not establish current employment. These notes complement the completed GamiFi review and exclude private biographical or financial identification.

## NEM Thailand, NEM Foundation and NEM Group

**Actual signing role, 2018:** NEM Southeast Asia’s official August9 2018 report names Laura as Thailand Chief Representative/Country Manager and identifies her as the signatory to an MOU with Thoresen Thai Agencies PCL for a planned Bangkok blockchain centre; Stephen Chia was counter-signatory. It includes a named statement promoting education/adoption. This establishes a concrete representative act, not merely a title. The document reviewed is the issuer’s report, not the signed MOU or proof the proposed centre opened on schedule. [N1]

**Candidacy then appointment, not a 2018 electoral victory:** The LauraBKK forum account identifies itself as Laura Takenaka/Country Lead in her November10 2018 candidate thread. On December18 she explicitly acknowledges she did not win. A May7 update, posted May8 2019, then lists her as interim Secretary and says new invitees/appointees lacked additional remuneration and voting rights. The September25 2019 Secretariat update reports that the June13 EGM approved Laura as Foundation director and that, after the August29 AGM and paperwork, the Council appointed her Honorary Secretary under bylaw33. This sequence supports a later formal appointment; the 2018 voting guide alone cannot establish election success. [N2,N3,N4]

**Named communications responsibility:** The May2019 Secretariat update expressly assigns Laura and Sharie Ingente oversight of the global content calendar, communications policies and media materials. Thus there is employer-published evidence of substantive communications management, although it cannot assign every later corporate post to her personally. [N3]

**Governance communication, January2020:** LauraBKK published the January13 2020 community-vote notice for the Symbol ticker, explaining proposed names and the process. This links her to public administration/communication of the branding decision. The source gives inconsistent start times within the same post (3PM and 1PM PST); the actual opening time and impact were not independently reconstructed. This is a specific publication inconsistency, not a finding of a rigged vote. [N5]

**Public financial-report defense, March2020:** On March12 in the 2019 ROI report thread, LauraBKK asserted that all expenses were reflected and invoked the Foundation’s Singapore incorporation/privacy obligations in the salary-disclosure discussion. The comments prove her public representation, not independently audited expense completeness or the correctness of her legal interpretation. Positive investor-return language elsewhere in that thread was written by `leidong`, not Laura. [N6]

**A corrected entity description:** In March27 2019 comments about winding down the Community Fund, Laura initially described it as effectively moved to NEM Ventures. A committee representative explained the entities were independent and referring projects onward; she expressly accepted the clarification. The correction and acceptance belong together. It is not evidence she transferred or controlled Community Fund assets. [N7]

**NEM Group later job title:** A current professional-profile snippet lists Senior Director, Channel and Content, March2020-February2021. This remains self-reported exact-title/date evidence in this pass; no employer appointment document was recovered. Public NEM Telegram signatures identify her on later corporate posts, consistent with communications work, but do not independently establish the complete job contract. [N8,N9]

## NEAR Protocol

Laura’s February23 2022 MEXC introduction says she previously worked at NEAR. Her profile snippet gives February-May2021; Syndika’s later announcement describes marketing experience. Nativz’s July2022 newsletter also mentions prior NEAR experience. No NEAR employer-authored appointment, assigned project, specific campaign decision or exact role title was recovered. State the relationship as publicly reported prior work, with the month range attributed to her profile. Unrelated Laura names in NEAR community proposals were excluded. [N8,N10,N11]

## Attribution and contradiction checks

- The 2018 candidacy already reserved privacy-sensitive information when proposing transparency. Her 2020 privacy argument therefore does not by itself contradict a promise of unrestricted disclosure.
- Her December2018 supernode-funding answer expressly says she could not decide unilaterally; do not recast a proposal as an executed transfer.
- A search snippet incorrectly appeared to connect Laura’s Telegram signature to a LATOKEN trading contest. Opening the underlying page assigns the contest to `nemnews`; Laura’s signature belongs to an adjacent iOS opt-in post. That trading-promotion attribution is excluded.
- NEM Foundation, NEM Community Fund, NEM Ventures and NEM Group are distinct labels/entities in these records; do not collapse their assets or decision-making structures.
- No new public record establishes personal wallet custody, market-making instructions or misuse of funds in these historical-role sources.

## Source register

| ID | Primary source URL | Publication / retrieval detail | Source ref |
|---|---|---|---|
| N1 | https://medium.com/nem-sea/nem-thailand-thoresen-thai-agencies-mou-open-bangkok-blockchain-centre-4c72ea09289f | Official regional team, Aug9 2018; full text | historical retrieval |
| N2 | https://forum.nem.io/t/laura-takenaka-for-secretary-council/20442 and https://forum.nem.io/t/laura-takenaka-for-secretary-council/20442?page=2 | Candidate’s own posts Nov10-Dec18 2018; account provenance and election outcome | historical retrieval; historical retrieval |
| N3 | https://forum.nem.io/t/nem-foundation-update-may-2019/22634 | Official Secretariat; text May7, forum timestamp May8 2019; full text | historical retrieval |
| N4 | https://forum.nem.io/t/nem-foundation-update-september-2019/23549 | Official Secretariat Sep25 2019; June13 EGM/Aug29 AGM events separately stated | historical retrieval |
| N5 | https://forum.nem.io/t/community-poi-vote-symbol-ticker/24173 | LauraBKK Jan13 2020; full notice | historical retrieval |
| N6 | https://forum.nem.io/t/nem-foundation-2019-roi-report/24550 | LauraBKK comments7/9 dated March12 2020; main-post displayed date later than comments | historical retrieval |
| N7 | https://forum.nem.io/t/nem-community-fund-update-concluding-the-dao/22355 | Committee announcement March25 2019; correction/acceptance comments7-9 March27 | historical retrieval |
| N8 | https://ca.linkedin.com/in/lauralwalsh | Self-profile; search-indexed month ranges; live profile retrieval999 earlier | historical retrieval; historical retrieval |
| N9 | https://t.me/s/newsonnem?q=%23opt | Official-branded channel; source contains separate signatures for each message | historical retrieval |
| N10 | https://blog.mexc.com/mexc-ama-gamefi-session-with-laura-and-casey/ | Host-published direct answers Feb23 2022; Laura says prior NEAR work | historical retrieval |
| N11 | https://www.nativzgaming.com/p/newsletter-09-07-22 and https://www.linkedin.com/posts/lauralwalsh_more-than-thrilled-to-be-a-member-of-syndika-activity-7087741668275208192-JAri | Nativz dated July9 2022; Syndika relative date only; professional corroboration | historical retrieval; historical retrieval |

Only short factual paraphrases are intended for redistribution. Underlying full forum threads were not copied into these notes. Citation word budgets also apply when these findings are combined into another report.

## Launchpool / Alphabit / Techstars extension

Related research is preserved in `laura_gmi_involvement/LAUNCHPOOL_TECHSTARS_NOTES.md`; the key company AMA, official mentor award and programme-director transcript were re-opened in this research pass.

**Launchpool COO, operational and promotional acts:** The July3 2021 company summary of its July2 AMA names Laura COO and attributes answers on LPOOL eligibility thresholds, bridge-fee exceptions, allocation preferences and project vetting to her. She encourages holding rather than selling, while expressly warning about investment loss and incubation risk. This directly documents participation-policy representations; it is not evidence of manipulation or wallet control. The source itself distinguishes Launchpool, Labs and the Techstars initiative. [L1]

**Allocation marketing / partnership:** September27 and October2021 named interviews connect her as COO to the Dublin accelerator rollout and to claims of retail project allocations on fund-equivalent pricing terms. Nativz’s July9 2022 newsletter identifies her as Corporate Liaison for the Launchpool Web3 Techstars programme and dates her COO commencement to May2021. A separate Alphabit director/officer appointment was not recovered. [L2-L4]

**Active Techstars support:** A programme-director transcript recorded July4 and published August4 2023 calls her EIR and describes her accompanying the cohort on Canada/New York investor events. Techstars itself names Laura as its Web3 2023 All-Star Mentor in a February19 2024 announcement. A July23 2025 programme-leader retrospective credits her with helping establish the programme and says the standalone accelerator was being integrated into wider Techstars programmes. These historical records do not establish current salaried employment. [L5-L7]

| ID | Primary / interview source | Reference |
|---|---|---|
| L1 | https://launchpoollabs.medium.com/launchpool-labs-community-ama-summary-546fc8b122a | Re-opened historical retrieval; company July3 2021 |
| L2 | https://www.irishtimes.com/business/technology/techstars-to-hold-blockchain-focused-accelerator-in-dublin-1.4684207 | historical retrieval; named interview Sep27 2021 |
| L3 | https://irishtechnews.ie/moneyneversleeps-laura-walsh-launchpool-techstars/ | historical retrieval; named producer/interview Oct11 2021 |
| L4 | https://www.nativzgaming.com/p/newsletter-09-07-22 | Company-counterparty biography, July9 2022; already inspected |
| L5 | https://www.moneyneversleeps.ie/227-encore-eoin-fitzgeralds-last-dance-techstars-web3-recap/ | Re-opened historical retrieval; transcript05:33,08:54,10:55 |
| L6 | https://www.techstars.com/blog/impact/2023-techstars-all-star-mentors-named | Re-opened historical retrieval; award year2023,publicationFeb19 2024 |
| L7 | https://www.linkedin.com/pulse/techstars-web3s-evolution-my-next-phase-pete-townsend-e6zpe | historical retrieval/historical retrieval/historical retrieval; July23 2025 |

A further NEM Telegram source at https://t.me/s/newsonnem/3794 (historical retrieval) displays Laura’s signature on a ChangeNOW BlackFriday swap promotion and an exchange-listing update. It establishes named corporate-channel publication, not authorship of every adjacent message. Exact posting-date metadata was not recovered: two ordinary public HTTP reads timed out. The LATOKEN contest at message3758 remains signed `nemnews` and must not be assigned to Laura. This ancillary record is not needed to prove the already-established governance and communications roles.
