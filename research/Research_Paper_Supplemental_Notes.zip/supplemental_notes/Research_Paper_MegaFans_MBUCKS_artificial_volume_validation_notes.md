# Research Paper — MegaFans / MBUCKS — artificial-volume validation notes

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Review: 2026-09-05 UTC. Passive public reads only. Completed public-record pass; conclusions are bounded by the access limits below.

## Current disposition
Artificial volume is **not established**. A real pair and successful swaps are verified. A complete trade sequence, counterparties and beneficial-owner evidence were unavailable; no wash-trade percentage or current holder-concentration conclusion can be supported. Low liquidity, zero index volume, repeated router addresses or adviser affiliation do not establish manipulation.

## Exact identity and current chain state
Token: `0x3638fea0c645b1aa79db706fab6e8a761385c390`.
Pool: `0x5282c0ea15348dfa64a8a2690e0cb770e56a72dc`.
Quote token: `0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c` (WBNB).
Factory: `0xca143ce32fe78f1f7019d7d551a6402fc5350c73`.

[Official PancakeSwap v2 address list](https://developer.pancakeswap.finance/contracts/v2/addresses) matches the queried factory. Its `getPair` returned the pool above. [Factory read-function documentation](https://developer.pancakeswap.finance/contracts/v2/factory-v2) explains this lookup. Factory validation used `latest`; the first fixed-block repeat failed because historical state was pruned.

| Direct RPC field | Observed value |
|---|---|
| Chain ID | 56 |
| Snapshot block | 120142920 / `0x7293c48` |
| Block UTC | 2026-09-05 16:30:56 |
| Block hash | `0xf494c5960ea7e16a9e3dd1a90e2160599ae9cde1a82085e86050118cc38865c9` |
| Decimals / total supply | 18 / 100000000 |
| MBUCKS reserve | 7834273.576714409690377211 |
| WBNB reserve | 9.522022016902965212 |
| Reserve-update timestamp | 1787206315 / 2026-08-20 06:11:55 UTC |
| Pool token balance / supply | 7.834273576714409690377211% |

Pool `token0`, `token1`, `factory`, `getReserves` and MBUCKS `balanceOf(pool)` were checked. This pool balance is **not beneficial-owner concentration**. No dollar valuation or executable quote is inferred.

## Indexed examples validated against receipts
These are purposively located examples, not a random or complete sample.

| Transaction | Block / UTC | Decoded MBUCKS-pool activity |
|---|---|---|
| [0x7a6fa704…43054](https://bscscan.com/tx/0x7a6fa7044e1279088e5e2a66336ffb6baeaa6944383951afda6802a0bcb43054) | 40902560 / 2024-07-29 17:34:27 | Successful swap: 7628 MBUCKS in; 0.376772720651555410 WBNB out. |
| [0x7b0b2cb8…bf7e](https://binplorer.com/tx/0x7b0b2cb8751d406444580cef5a1f653354c64c35d7ecb231a94dfbd234e7bf7e) | 44021732 / 2024-11-15 04:45:32 | Liquidity burn: 1337.918645472415402387 MBUCKS and 0.007604868996919220 WBNB; separate swap: 1271.022713198794632268 MBUCKS in, 0.007204040848838447 WBNB out. |

July transaction origin: `0x87d5da08da4f0553c1bb362fd379f6e7383cf1fd`; destination: `0x1a0a18ac4becddbd6389559687d1a73d8927e416`, matching the [official PancakeSwap Universal Router list](https://developer.pancakeswap.finance/contracts/universal-router/addresses). Its identical router sender/recipient fields in a swap log are not evidence of a buyer trading with themself. November transaction origin: `0xf4c21a1cb819e5f7abe6defde3d118d8f3d61fa7`; destination `0x0ed943ce24baebf257488771759f9bf482c39706`. No attribution to MegaFans, Laura or a common owner is made.

## Latest reserve update located directly

Header interpolation located block **116990020**, **2026-08-20 06:11:55 UTC**. Ordinary `eth_getBlockReceipts` identified successful transaction `0xb8b46f88394e8f77e86363c691e6cdec73e493523f6999b35552a96b2b4d36d9`. Its single MBUCKS-pool Swap records **2432 MBUCKS in / 0.002949454917464755 WBNB out**; its Sync equals the September 5 snapshot reserves.

Three MBUCKS transfers are **2560 → intermediary**, **2432 → pool**, **128 → another address**. Their sum is **5120**, or **2.105263×** the actual swapped token amount. Counting every transfer would overstate swap volume. This does not show that a company or index actually used that method. The 128 allocation's purpose and address ownership remain unverified. No buy-and-sell loop appears within this pool's events in this transaction. A full historical sequence remains unavailable.

Evidence: `last_update_block.json`, `last_update_selected.json`, and complete `last_update_receipts.json`; all obtained from the documented public BNB RPC. This improves the latest-activity check without establishing absence of historical manipulation.

## Index freshness
[TradingStrategy pair page](https://tradingstrategy.ai/trading-view/binance/pancakeswap-v2/mbucks-bnb) identifies the exact pair. Its search/text view showed an explicit 2025-11-19 19:14 UTC update, $0.00176 price, $24.35k TVL and $0 24-hour volume. Browser inspection on the review date instead showed $0.00123, 0.00000138 BNB/token, $18.12k TVL, $9.06k quoted-side liquidity, $0 volume, age 800 days and last trade under six months ago; no observation block appeared. Direct reserve ratio was approximately 0.000001215431389 BNB/token. These displays have different freshness; neither index view certifies current volume. TVL versus one-side liquidity is not itself a contradiction.

## Role and exchange boundaries
[Laura’s LinkedIn](https://ca.linkedin.com/in/lauralwalsh) search result self-reports MegaFans advising/early seed investment, May 2022–Present. Full read failed; no independent appointment or departure record surfaced. This period overlaps the sampled activity, but establishes no wallet ownership, transaction instruction or knowledge.

Official-domain searches for MEXC/Binance listings or delistings using MBUCKS, MegaFans, Megabucks and the exact address found no relevant notice. The [company-issued 2024-05-29 announcement](https://www.prnewswire.com/news-releases/megafans-launches-and-lists-token-mbucks-on-binance-smart-chain-302158231.html) anticipated June MEXC/PancakeSwap trading and referred to Binance Smart Chain. This is not confirmation of exchange admission. CEX internal trades would require exchange data; blockchain deposits/withdrawals do not measure them.

## Access and reproducibility
Successful ordinary read-only endpoint: [BNB Chain public RPC](https://bsc-dataseed.bnbchain.org), documented in [official wallet configuration](https://docs.bnbchain.org/bnb-smart-chain/developers/wallet-configuration/). Standard HTTPS POST JSON-RPC; only Content-Type application/json; no authentication or secrets. `eth_call`, headers and exact transaction receipts worked. Historical code at blocks 39000000/40000000 returned missing-trie-node. [BNB RPC documentation](https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/json-rpc-endpoint/) says mainnet log queries are disabled on its listed endpoints.

BscScan and DEX Screener browser pages showed Cloudflare security verification after one reload; attempts stopped and blocks were reported. No CAPTCHA was solved. Their text/API views also failed. [PublicNode](https://bsc-rpc.publicnode.com/) and [dRPC’s documented public BSC endpoint](https://drpc.org/docs/bsc-api), tested with ordinary JSON-RPC POST, returned 403. These are access limitations, not evidence about MegaFans. No alternative authentication, fingerprint changes or access-control circumvention was attempted.

Files in `volume_megafans_raw/` preserve standard requests, endpoint, retrieval UTC and responses where obtained: `state_snapshot.json`, `factory_latest.json`, `indexed_tx_receipts.json`, initial RPC probe and header-bracketing records. `read_rpc.py` is a reusable read-only helper; `validate_records.py` reproduces the arithmetic and checks matching pool events. State and receipt decoding divides ABI integers by 10**18, maps token0/token1 before assigning swap amounts, and separates Swap, Burn and Transfer events.

## Open tests
- Exact deployment/first mint: unresolved; July 29, 2024 proves existence by then, not launch date.
- Complete pools/trades: one genuine pool verified; other versions, venues and pairs not exhaustively excluded.
- Same-wallet loops: incomplete sequence; no repeat-cycle statistics computed.
- Ownership concentration: no complete holder ledger or beneficial-owner mapping.
- Artificial CEX volume: no matched official trade tape or account-level exchange records.

## Reproduction status

`python volume_megafans_raw/validate_records.py` passed on September 5, 2026. It checks supplied raw records, supply/decimals, exact reserve integers, pool balance, event types, the latest matched Swap/Sync and the transfer-sum ratio. It does not assume unidentified addresses belong to the same person. It does not execute network writes or transactions.

No API keys, signed messages, accounts, contact, purchases, software installation or chain-state changes were used. Review complete; the artificial-volume allegation remains **unproven**, with documented gaps rather than an inferred exoneration.
