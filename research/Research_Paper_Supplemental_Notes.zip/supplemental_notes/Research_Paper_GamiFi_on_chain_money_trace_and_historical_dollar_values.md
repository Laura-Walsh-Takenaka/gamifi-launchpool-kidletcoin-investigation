# Research Paper — GamiFi: on-chain money trace and historical dollar values

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research date: **6 September 2026**. Network: **BNB Smart Chain, chain ID 56**. All dates below are UTC. This follow-up accompanies a 75-row ledger covering 67 distinct transactions and raw evidence. It extends the earlier contract investigation; it is not a full audit of every GamiFi account.

**The largest missing link is now established:** on 5 November 2022, 14 million GMI left the Launchpool vesting contract, joined 30 million GMI from two other contracts, and all 44 million were sold for **5,174.293394005109506048 BUSD**, approximately **US$5,174.14 / C$6,993.89** at the historical conversion rates. Most proceeds then passed through an intermediate wallet to an address currently labeled FixedFloat by an explorer. The transfer route is verified; the service label and ultimate customer identity have different evidence limits.

A separate private-vesting recipient sold 9.130598 million GMI for actual proceeds worth approximately **US$756.14 / C$1,021.91**, and sent another 3 million GMI through an intermediary to a wallet MEXC publicly identified as its own. Neither route establishes a bank payment or Laura's personal receipt.

**Read the dollar figures carefully.** A token market mark is quantity multiplied by a historical marginal price; it is not money invested, money received, or a guaranteed price for selling the whole position. Sale proceeds are actual BUSD/BNB received on-chain, converted to dollars. Successive hops of the same assets overlap and must never be added into a loss total. Dollar estimates are gross of transaction gas costs; neither profits nor investor losses are calculated.

| Date / item | Asset amount | Historical US$ | Historical C$ | Meaning |
|---|---|---|---|---|
| 19 Apr 2022 — 39 Launchpool deposits | 15,456,885.882909 GMI | 213,274.65 | 269,237.92 | Sum of individual market marks; not cash raised |
| 5 Nov 2022 — Launchpool portion removed | 14,000,000 GMI | 2,675.88 | 3,616.99 | Marginal mark; pool ratio over four hours old |
| 5 Nov 2022 — combined 44m sale | 5,174.293394 BUSD | 5,174.14 | 6,993.89 | Actual stablecoin proceeds from all three sources |
| Mar–Jun 2022 — project IDs 6–9 | 60,639.317377 BUSD | 60,656.66 | 76,763.97 | Four actual project-contract withdrawals |
| Mar 2022 — project IDs 1, 3, 4 | 2,362.5 BUSD | 2,362.50 | 2,976.72 | Three earlier withdrawals; purposes unconfirmed |
| Jan–Feb 2023 — private sales | 578.555338 BUSD + 0.582235106 BNB | 756.14 | 1,021.91 | Five sales; each converted at its own date |
| 21 Jan 2023 — MEXC wallet arrival | 3,000,000 GMI | 231.98 | 311.33 | Token market mark; exchange sale not established |

**How the November tokens left the vesting contracts**

The Launchpool vesting implementation active before the November changes had no ordinary owner-withdrawal function. The historical transaction shows a different mechanism: administrative control temporarily changed the implementation, granted a spending allowance, and restored the original implementation. A later transaction used that allowance to transfer tokens out. Restored code alone would not reveal the earlier permission grant.

| 5 Nov UTC | Verified action | Evidence |
|---|---|---|
| 06:14:38 | Three proxies temporarily upgraded to 0x1ee3…e6fb; each grants maximum GMI allowance to Safe 0x9362…25f3; original implementations restored. | [transaction](https://bscscan.com/tx/0x4af5d1dccd4008191749c6f193b552edd4e2d10d96028661eed4d508b8901a63) |
| 06:45:09 | 23m + 14m + 7m GMI transferred from three contracts into 0x35dc…5422 using transferFrom. | [transaction](https://bscscan.com/tx/0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48) |
| 06:45:39 | Withdrawal executor 0x343c…235e sends 0.019849782233850894 BNB to 0x35dc…5422 for subsequent activity. | [transaction](https://bscscan.com/tx/0xb954f172ba0faed75a15967fce0e72a52ee674fd585d9d1e5385199c72f82a17) |
| 06:51:21 | All 44m GMI sold through router 0x1111…097d; 5,174.293394005109506048 BUSD received by 0x35dc…5422. | [transaction](https://bscscan.com/tx/0x7096720b8dc95afac5ad1029a489ce8dd2b2dcb5ff78e960fcb5e10d03acd8aa) |
| 07:15:11 | 5,174 BUSD sent from 0x35dc…5422 to 0x96f0…aeb6. | [transaction](https://bscscan.com/tx/0x34bfa37b43fc0426e45ffcd3af9927be6495d4710f340f7f80e09d2fc41fe1b4) |
| 07:15:20 | 0x4727…7c95 funds 0x96f0…aeb6 with 0.00084 BNB. | [transaction](https://bscscan.com/tx/0xfce9f602e9b578c45f056eaa29343e0932d46f796d3fcb9a9b2dc326e1367a7a) |
| 07:15:32 | The same 5,174 BUSD moves from 0x96f0…aeb6 to 0x4727…7c95. | [transaction](https://bscscan.com/tx/0x7702b5e67906c5eb1dea5d1fdde0f7ade3e37cb5cd657944bd539ed460791e48) |
| 07:15:41 | Remaining 0.000502984 BNB swept from 0x96f0…aeb6 back to 0x4727…7c95. | [transaction](https://bscscan.com/tx/0xfc4c26165b9fad6ae7aa5c69b0763f4bed1af11f97ecebb9112793ca121303c4) |

The original receiving wallet retained 0.293394005109506048 BUSD and no GMI at the checked later state. The two intermediary wallets' subsequent top-level transactions were accounted for using their nonces and receipts. Swap-routing intermediate WBNB/BUSD legs are preserved in the evidence but excluded from ledger endpoint totals to avoid repeated counting.

[Etherscan's current label](https://etherscan.io/address/0x4727250679294802377dd6ca6541b8e459077c95) calls the final address “FixedFloat: Hot Wallet” and attributes the label to the hildobby compilation. That is an Ethereum explorer label for the same address, not first-party confirmation of its November 2022 BSC role. The gas-funding and immediate-sweep sequence is consistent with a service collection process; that is an inference. A specific customer, conversion order, payout asset, destination chain, final withdrawal and bank account remain unknown.

The Launchpool contract's GMI balance fell from **14,923,065.568267084392219941** to **923,065.568267084392219941** in the 14m transfer. The selected beneficiary's vesting record did not change across the allowance grant or transfer. Immediately afterward the remaining balance still exceeded that one beneficiary's 587,755.519557566 GMI allocation. Therefore this transaction alone did not immediately make that single claim impossible. The earlier investigation's much later balance/claim-failure check establishes a later shortage; a complete intervening outflow reconciliation is still needed to explain its full timing.

**Which keys authorized it**

Historical Safe owner/threshold calls and cryptographic recovery of the transaction signatures agree:

| Role | Safe / administrator | Signing address | Required signatures |
|---|---|---|---|
| Permission grant | 0x6bf55810ab061a016a968016818a6e1246aa8b5a | 0x538a8b615e98e87d025c4336be44e4b8588277c7 | 1 of 1 |
| Three token withdrawals | 0x9362ced428b4179650252ad87731240b32ef25f3 | 0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9 | 1 of 1 |

The approval signer authorized two Safe calls; the withdrawal signer authorized three. Both Safes pointed to the Safe 1.3.0 L2 singleton whose runtime matched the official deployment artifact. These were single-owner smart accounts at the relevant blocks; the word “Safe” does not establish approval by several people. The transaction submitter paying gas was a separate address, not automatically the owner of the signing key.

Safe 0x9362…25f3 changed its sole owner from 0x7e01…7445 to 0xafd9…c3f9 on **19 September 2022**, transaction [0x958512…](https://bscscan.com/tx/0x958512439479d367fc0afd13e8928f810dfe40b4945b084bc51fffedc5b9627b). The approval Safe was created by its sole owner 0x538a…7c7 on **4 November 2022**, transaction [0x2ecfae…](https://bscscan.com/tx/0x2ecfaeb4b20fedb2a1d0fd838c01cc9e26e898c48284d74062898861eab1bda5). No verified public evidence identifies the humans controlling these keys.

GamiFi [announced Eleanor Rooney as CEO on 1 September 2022](https://gamifi-launchpad.medium.com/new-ceo-for-gamifi-451f0e5a2147), thanking Laura for her prior leadership. That announcement precedes the September owner change and November transactions. Neither Laura's earlier role nor Eleanor's later title identifies either person as a signer or establishes personal responsibility for these transfers.

**The separate private-vesting route**

On **18 January 2022 at 15:56:50**, the original GMI deployer funded a 120,000,000 GMI vesting schedule for 0x3604…b4d4 in contract 0x74e0…df6c. The [funding receipt](https://bscscan.com/tx/0xac39350f0f652c95dfb73e0cd8f2028a2c8aa34a51d081374a6c850647625787) verifies the token deposit; calldata sets zero initial release, zero cliff and 360 days of linear vesting. Category number 5 has no human-readable category definition in the verified implementation, so it does not identify a team or investor allocation.

At the preceding-block marginal price, 120m GMI multiplies to approximately **US$5,769,088.34 / C$7,228,090.79**. This is a highly theoretical mark: that pool held only about **3.983m GMI and 413.8 WBNB**. It cannot be presented as a multi-million-dollar payment, capital raised or realizable sale value.

The December and January claims paid 12,130,597.993827160493827161 GMI in total. Their later disposal reconciles exactly in aggregate: 9,130,597.993827160493827161 GMI across five sales plus 3,000,000 GMI forwarded. Fungible token units are not individually identifiable after mixing.

| UTC | Action / actual asset | US$ mark | C$ mark | Transaction |
|---|---|---|---|---|
| 2022-12-14 16:01:19 | Private selected claims — 2131635.802469135802469136 GMI | 171.20 | 232.17 | [T060](https://bscscan.com/tx/0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639) |
| 2023-01-20 05:38:45 | Private selected claims — 9998962.191358024691358025 GMI | 811.64 | 1,089.31 | [T061](https://bscscan.com/tx/0x8657b3b3182771a12734fa434536f6f2a667246a2f94998546da301f7e464f3d) |
| 2023-01-20 05:40:30 | Private sale proceeds BUSD — 225.410169579752827331 BUSD | 225.41 | 302.52 | [T063](https://bscscan.com/tx/0x411c9e992b80d6bb8a0f88127c51f9428c5f78950f5eb527ca99e2521e618dd8) |
| 2023-01-21 02:29:17 | Private sale proceeds BNB — 0.582235106329889742 BNB | 177.60 | 238.35 | [T065](https://bscscan.com/tx/0xa599f04b0cc1343b3c1048b5d4275ba1bdd587a960f37b95368bc8b04463b095) |
| 2023-01-21 02:34:05 | Private MEXC sweep — 3000000 GMI | 231.98 | 311.33 | [T067](https://bscscan.com/tx/0x2e371d5d37cc3deaef36f8c4798f0a18256257304d8eb4db697e6b4414cec02e) |
| 2023-02-25 12:49:01 | Private sale proceeds BUSD — 89.301011917324055514 BUSD | 89.30 | 121.65 | [T069](https://bscscan.com/tx/0x56da94a4b0cf7b380063929853763a2fa81aaf548b9e9a2e3f4d477688a7e0a5) |
| 2023-02-25 12:49:28 | Private sale proceeds BUSD — 124.564682082873742182 BUSD | 124.56 | 169.68 | [T071](https://bscscan.com/tx/0x776d2561d6329ba685647cc04cc2b4d42465c597be0cd1ae3a196c4df2d13d96) |
| 2023-02-26 06:07:24 | Private sale proceeds BUSD — 139.279474641857817825 BUSD | 139.27 | 189.71 | [T073](https://bscscan.com/tx/0xd505ac7b81c6f1f2724eed8faafee4650ab6e70168f6d5ad2225e982dce560ff) |
| 2023-04-04 10:56:48 | Private April BUSD forward — 789.821799959045630101 BUSD | 789.67 | 1,061.87 | [T074](https://bscscan.com/tx/0xab1707a54f5d665be52be7c7f6e1a40f85575e835c884c92a69381dc6f730334) |
| 2023-04-04 10:57:48 | Private April BNB forward — 0.840230960291603498 BNB | 260.48 | 350.27 | [T075](https://bscscan.com/tx/0xd9e76558654e142eb8355e18842c16e4985a0be2f03dd0e4b4e596bf713e9d58) |

MEXC's [own July 2021 disclosure](https://mexcglobal.medium.com/recent-rumors-against-mexc-global-clarified-7205e6828907), section 5, identifies the exact destination 0x4982085c9e2f89f2ecb8131eca71afad896e89cb as its BSC wallet. This is stronger attribution than an explorer tag. The selected 3m GMI arrived there on 21 January 2023, two minutes thirty seconds after the intermediary received it. No exchange customer identity, credit, off-chain sale or bank withdrawal has been established.

The April BUSD and BNB transfers came from commingled balances and exceeded the selected GMI sale proceeds in those assets. They must not all be described as the proceeds of those five GMI sales. All 12 beneficiary-account transactions after the December claim, nonces 88–99, were identified and receipt-checked; two unrelated CAKE transactions and one failed GMI swap are excluded from financial totals.

The current schedule counter records all 120m GMI claimed. The implementation's 7,847 executable bytes were reproduced from source, with compiler metadata differing. This corroborates current field meanings; it does not prove all historical payouts or an uninterrupted implementation history. **The remaining approximately 107.87m GMI outside the two selected claims has not been individually traced.**

**Project-contract stablecoin withdrawals and shared operational links**

The archived official application identifies project contract 0x56c0…46c7f. Seven successful receipts show withdrawals totaling **63,001.817377359365034843 BUSD**, historically marked at **US$63,019.16 / C$79,740.69**. Their sum reconciles to the nine current project records' funded-total counters. That is not a lifetime audit of investor deposits or company revenue.

| Project ID | UTC | BUSD | US$ mark | C$ mark | Recipient | Receipt |
|---|---|---|---|---|---|---|
| 1 | 2022-03-10 15:25:05 | 252.5 | 252.51 | 322.61 | 0x8fea0bb760218398d32d4a9ef18553c403e3c2a0 | [T002](https://bscscan.com/tx/0x4b0b66e2f020479b6381a1b31be240bfb86347cf1813ddb520c094576e6158df) |
| 3 | 2022-03-11 09:35:55 | 110 | 109.99 | 139.91 | 0x8fea0bb760218398d32d4a9ef18553c403e3c2a0 | [T003](https://bscscan.com/tx/0x4389510604c93f928c4e1a2f6fda07979d792228de1b6bb66a8242a7a7ee05b5) |
| 7 | 2022-03-18 06:58:39 | 23722.715761539594859905 | 23,730.18 | 29,940.37 | 0xd2b806f9c0352a267ce7ccf33e74d68c070d6171 | [T004](https://bscscan.com/tx/0xa68d28501388dd1939659be1a24f6fbed8c0c22d6df5bbe43196ff408b3ffba4) |
| 6 | 2022-03-18 12:23:52 | 28421.141280969119319259 | 28,430.09 | 35,870.24 | 0x56aa83035aea8bfeb9e395a51607cc4621649aa2 | [T005](https://bscscan.com/tx/0x4e2b2cebb9895bb8ed1ffa817e730273d9271e97e559a2fdd7ba2d4e86fd5299) |
| 4 | 2022-03-23 14:58:07 | 2000 | 2,000.00 | 2,514.20 | 0x35b119730f79881dac623dc51c831c6a04cab5f3 | [T006](https://bscscan.com/tx/0x33f6c2ae7893cf8763b5306d4220780592390cc22ab9399034f4b3ac6ee09683) |
| 8 | 2022-05-23 11:50:16 | 3775.228767123287671432 | 3,775.69 | 4,843.83 | 0x56aa83035aea8bfeb9e395a51607cc4621649aa2 | [T048](https://bscscan.com/tx/0xfb51cbbf265af6b604ba3499d1608f36ab04a57eb3a71a4d5cbe3c6fe807d780) |
| 9 | 2022-06-22 08:29:58 | 4720.231567727363184247 | 4,720.69 | 6,109.52 | 0x56aa83035aea8bfeb9e395a51607cc4621649aa2 | [T049](https://bscscan.com/tx/0x757fe0ce1d898fff34b0d4c4f58f2fc7610d3821eacc51c43d7e7e6ac0edcf63) |

IDs 6–9 account for 60,639.317377359365034843 BUSD. The earlier IDs 1, 3 and 4 account for 2,362.5 BUSD and should stay separate until their purposes are documented. Project names, commercial purpose, contractual entitlement and recipient ownership have not been independently established.

The same address **0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199** initiated withdrawals for IDs 4, 6, 7, 8 and 9 and funded the Launchpool vesting contract. It received **15,456,876 GMI** from **0x78d09e1435e1906878621bcb0aaa9d47561214c3** at 13:32:12 on 19 April, [receipt](https://bscscan.com/tx/0x00f1ad6f5d7560d5325d08d0afcf253a99b46d588a6509abb37349bacdea965f). Later that day, 39 deposits moved 15,456,885.882908530406846 GMI into Launchpool, including an initial 10 GMI transfer. The bounded upstream history also contains a 5 GMI transfer; these are not a full funding-wallet balance reconciliation.

Recipient **0x56aa…9aa2** received 36,916.601615819770174938 BUSD across IDs 6, 8 and 9. This repeated recipient and **0xd2b8…6171**, which received project 7's 23,722.715761539594859905 BUSD, are concrete accounting leads. No personal or corporate key ownership has been proved for them.

At the sampled current September 2026 blocks, the project contract owner and the private vesting owner/proxy administrator equal **0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b**, also seen in prior GMI/NFT/Launchpool control checks. Current common control does not prove control by that address throughout 2022–23, and it does not identify a human.

**Contract and address directory**

| Role | Full BSC address |
|---|---|
| Canonical GMI token | [0x93d8d25e3c9a847a5da79f79ecac89461feca846](https://bscscan.com/address/0x93d8d25e3c9a847a5da79f79ecac89461feca846) |
| Launchpool vesting proxy | [0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb](https://bscscan.com/address/0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb) |
| Other November source: 23m | [0xee57b1241f243a1a794f60ffa643d202188d31d9](https://bscscan.com/address/0xee57b1241f243a1a794f60ffa643d202188d31d9) |
| Other November source: 7m | [0xba306306b117a25145d58c67a03deb7f22ee2a3a](https://bscscan.com/address/0xba306306b117a25145d58c67a03deb7f22ee2a3a) |
| ProxyAdmin used in November | [0x6ef316a4e3d378e5b75599daeca94c86d5ce4475](https://bscscan.com/address/0x6ef316a4e3d378e5b75599daeca94c86d5ce4475) |
| Temporary implementation / withdrawal helper | [0x1ee38d535d541c55c9dae27b12edf090c608e6fb](https://bscscan.com/address/0x1ee38d535d541c55c9dae27b12edf090c608e6fb) |
| Combined 44m recipient | [0x35dc4a16db1e30036fee83e733ee065ad8535422](https://bscscan.com/address/0x35dc4a16db1e30036fee83e733ee065ad8535422) |
| November stablecoin intermediary | [0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6](https://bscscan.com/address/0x96f0ae9dc91983d87379cf7bbe2cebc69123aeb6) |
| Currently FixedFloat-labeled address | [0x4727250679294802377dd6ca6541b8e459077c95](https://bscscan.com/address/0x4727250679294802377dd6ca6541b8e459077c95) |
| Private vesting proxy | [0x74e0ddf89807107378beb02e6bc504243e0cdf6c](https://bscscan.com/address/0x74e0ddf89807107378beb02e6bc504243e0cdf6c) |
| Selected private beneficiary | [0x36048413c4edf0cf3e633aab317fcd9824dfb4d4](https://bscscan.com/address/0x36048413c4edf0cf3e633aab317fcd9824dfb4d4) |
| Private token intermediary | [0x9564f530d9f270a48c510a92c97b59248cefd464](https://bscscan.com/address/0x9564f530d9f270a48c510a92c97b59248cefd464) |
| MEXC-disclosed wallet | [0x4982085c9e2f89f2ecb8131eca71afad896e89cb](https://bscscan.com/address/0x4982085c9e2f89f2ecb8131eca71afad896e89cb) |
| April onward recipient | [0xf4f86e37815217ed73ae817a4e5164d56315b1d7](https://bscscan.com/address/0xf4f86e37815217ed73ae817a4e5164d56315b1d7) |
| Project contract | [0x56c0cb2d047b69278f49b4759c1718436a546c7f](https://bscscan.com/address/0x56c0cb2d047b69278f49b4759c1718436a546c7f) |

**Valuation method and reproducibility**

For a transaction in block N, GMI marks use the GMI/WBNB pool reserves at block N−1 multiplied by the Chainlink BNB/USD answer available at that same historical block. This is the previous completed block, not necessarily the state immediately before a transaction within block N. Each row preserves its block, exact token quantity, price and source age. BUSD and BNB proceeds use their own historical USD oracle answers. BUSD is not silently treated as exactly one US dollar.

The main pool is 0x58d4b61983ca0afe6e352e90719f403e24e016f4; BNB/USD feed is 0x0567f2323251f0aab15c8dfb1967e4e8a7d42aee; BUSD/USD feed is 0xcbb98864ef56e9042e7d2efef76141f15731b82f. The [Chainlink API documentation](https://docs.chain.link/data-feeds/api-reference) defines the decimals and historical observation timestamps used. Successful feed-identity responses and compact official-document excerpts are retained.

Canadian-dollar equivalents use [Bank of Canada daily USD/CAD averages](https://www.bankofcanada.ca/rates/exchange/daily-exchange-rates/), taking the previous available business-day observation on weekends and holidays. These are dated daily averages, not transaction-time FX quotes. For example, April 19 uses 1.2624 CAD/USD; November 5 uses November 4's 1.3517; December 14 uses 1.3561. The workbook shows the FX observation date separately.

Price-age limitations matter. The November withdrawal's GMI pool ratio was 15,764 seconds old; the January 20 private claim's ratio was 17,222 seconds old. One June 22 BUSD oracle answer was 79,865 seconds old. They are explicitly identified as then-available marks, not exact contemporaneous exchange fills. A large position can move a shallow pool substantially, explaining why multiplying a marginal quote can exceed actual sale proceeds. The 44m sale's actual BUSD output is therefore the relevant realized on-chain amount.

The workbook preserves exact decimal quantities in text and uses formulas for dollar columns. Spreadsheet numeric precision is limited; JSON/raw integer evidence remains authoritative for exact token units. No total adds across overlapping transfer categories. Each transaction links to its explorer page, while primary RPC receipts and historical calls are preserved in the evidence archive. Some exploratory downloads failed; error responses are not proof of missing transactions.

**What remains unresolved**

- Who controlled signing addresses 0x538a…7c7 and 0xafd9…c3f9, and the business purpose and authorization documents for the November sequence.
- Confirmation of the November 2022 service role of 0x4727…7c95, plus any corresponding order, customer credit and payout. The current explorer label is a lead.
- The customer account and any subsequent trade or withdrawal associated with the January MEXC receipt. Public blockchain data alone does not disclose those exchange records.
- The full private-vesting payout/disposal history outside the selected 12.13m GMI, and the complete intervening Launchpool outflows that led to its later shortage.
- Project-ID names, recipient ownership, invoices/funding agreements, changes in project receivers, and further history of the upstream 0x78d0…14c3 wallet.
- Any actual Cayman bank account, account holder, bank transfer or Laura-specific receipt. **None has been established.**

These are specific evidence gaps, not findings of theft, laundering or fraud. The current results establish transfers, code changes, key-level authorization and historical valuations. They do not establish legal entitlement, intent, wrongdoing, final human beneficiaries or fiat withdrawal.

The evidence package includes this report, ledger inputs, calculation scripts, selected prior evidence needed for provenance, lane findings, historical RPC responses, source manifests and a SHA-256 file manifest. Large third-party webpage captures and a reproducible compiler binary are excluded; their compact provenance and calculation inputs are retained.
