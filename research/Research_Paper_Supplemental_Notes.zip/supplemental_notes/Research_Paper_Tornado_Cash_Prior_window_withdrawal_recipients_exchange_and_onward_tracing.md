# Research Paper — Tornado Cash — Prior-window withdrawal recipients: exchange and onward tracing

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

All routes here start at **pool-wide Tornado withdrawal recipients**, drawn from the prior 444-event April/July windows. **No withdrawal is paired with a GamiFi deposit note.** The address-level routes below are verified; their relationship to GamiFi's notes remains unassigned. Any separate historical-root exclusions must be applied before treating a route as a surviving candidate.

## Coverage

- Scanned all **206 unique recipients**; no recipient address appears in both the April and July windows.
- Captured **300 normal-transaction index pages**, representing **13,240 address-row records / 13,230 distinct transaction hashes**. All 300 recorded index attempts succeeded; no failed index scan remains to retry.
- **185 below-cap normal indexes are complete** according to the index response. **202 histories are either complete or their ascending pages reach seven days after the last sampled withdrawal.** This is an index scope, not an independently established lifetime/internal-transfer census.
- Eleven histories reported the index's 500-row ceiling. They were explicitly marked incomplete and supplemented with the latest 500 rows. Four still lack continuous coverage through the chosen follow-up target: `57dd3f`, `58ef0d`, `69b405`, and `e64e84` (full addresses in `scan_coverage.json`). Ascending/descending pages may leave an intervening gap.
- The analytic follow-up interval runs **from each recipient's first sampled withdrawal through seven days after its last sampled withdrawal**. It contains **881 successful positive-value normal BNB outputs**. Of 426 exact matches against the prior 116-address register, 386 are PancakeSwap router calls and 40 are Tornado proxy calls. **None is a direct native transfer to a project/control address.** Shared service use does not establish common ownership.
- Supplementary all-date indexed matches show 35 incoming normal payments into eight candidate recipients from addresses in Binance's official BSC disclosure; 28 precede the recipient's first sampled withdrawal. These are index-level observations, not among the 30 fresh receipt checks. No customer identity or common-customer inference follows.
- Full token/internal histories, arbitrary-hop searches, and all exchange addresses are outside this bounded scan. Six repeated plain-transfer destinations received additional first/latest index pages, documented under `endpoints/`.

## 1. Five April recipients converge into a collector that pays Binance

Ten successful withdrawals from the **100-BNB Tornado pool** paid five recipients **1,000 BNB gross / 999.5605 BNB after relay fees**. Their five subsequent ordinary payments are:

| Recipient | Withdrawal count | Sent to `a6cdd53…` BNB | UTC, April 28 2022 | Transaction |
|---|---:|---:|---|---|
| `0x17586f235ba5531ba739f44672af385f7921d3fb` | 1 | 99.987945 | 02:03:17 | [3302c7bb](https://bscscan.com/tx/0x3302c7bb918699bef307838509a2cb36f3fb848898a18f1da87bfc6a35903b86) |
| `0x9fa84706108f54bc446eb6b2682301ec300d1c4a` | 1 | 99.987945 | 02:03:20 | [a9e38fd5](https://bscscan.com/tx/0xa9e38fd52ff5c59ba58cfd794030b944ad6b2c53bdf7235bfdf1c2e22516a2f0) |
| `0x471c6435334f90898a2a49853bc847044459a535` | 1 | 99.947945 | 02:03:27 | [f4fed44a](https://bscscan.com/tx/0xf4fed44acc0c12ab8fc20399f18360f85c72dca0dfede63e908be2a577f992b2) |
| `0x38d3d39fded62273296f4eabfd03adfe81d6462e` | 1 | 99.947945 | 02:03:36 | [825f8c53](https://bscscan.com/tx/0x825f8c53f5ffdfc3e1626aee6f99e1ffbb9c9beff3406b5458a77f6a04e7a57e) |
| `0x7eb9e0a01a470b2c8f47f72e3b1bde580e3f5a0e` | 6 | 599.688195 | 02:10:59 | [45ae383f](https://bscscan.com/tx/0x45ae383ff8d24b3d52e17cb6c465510b15a298b16915e67c4a35b070687205e3) |

All five sender balances were independently zero immediately after their sends; their pre-send balances equal their sampled net Tornado withdrawals. The combined recipient gas was 0.000525 BNB. The collector is [0xa6cdd53b4959b17a86f0507cb53d2712221f133b](https://bscscan.com/address/0xa6cdd53b4959b17a86f0507cb53d2712221f133b).

At **02:30:08 UTC**, it sent **999.559689 BNB** directly to [0x8894e0a0c962cb723c1976a4421c95949be2d4e3](https://bscscan.com/address/0x8894e0a0c962cb723c1976a4421c95949be2d4e3), an exact address in [Binance's own wallet disclosure](https://www.binance.com/en/blog/community/2895840147147652626), in [transaction 3b0f1168](https://bscscan.com/tx/0x3b0f1168bfd44962b521b5a871d81b2519753044215c9c04394352e7ed67468b).

Archive balance equation, blocks 17,326,746–17,327,282:

`0.006214365 opening + 999.559975 inputs - 999.559689 payment - 0.000105 gas = 0.006395365 closing BNB`.

This was **not a complete collector sweep**. A conservative contribution interval from these five recipient inputs to that Binance payment is **999.553474635–999.559689 BNB**, allowing the prior collector balance to supply some of the payment. The index also contains earlier and later collector→Binance payments, but these are not added to this window's flow.

This is a concrete exchange records lead: collector, receiving exchange wallet, transaction, timestamp and amount are known. It is **not proof that any of GamiFi's ten 100-BNB notes was among these ten withdrawals**. Matching denomination/count is insufficient.

## 2. A second April collector reaches the same disclosed Binance wallet

Two sampled recipients sent **9.982945 BNB** (`5973aaa…`) and **10.979495 BNB** (`5c17b527…`) to [0x60450d80a24b9d33cf2330560075104d34f79a35](https://bscscan.com/address/0x60450d80a24b9d33cf2330560075104d34f79a35). The collector also received three other inputs totalling **3.674635 BNB**. At **2022-04-28 20:00:10 UTC**, it sent **24.630575 BNB** to the same disclosed Binance `8894` wallet: [transaction 8c4d0111](https://bscscan.com/tx/0x8c4d01111c4185cef3b070ae653b1b601e8f7fe1a6db7094fc177c8517b02c43).

Its independently checked balance equation is:

`0 opening + 24.637075 inputs - 24.630575 payment - 0.000105 gas = 0.006395 closing BNB`.

Both sampled recipients had one 10-BNB withdrawal in the original window. Their combined **20.96244 BNB** collector payments already include other funds; do not label the entire collector payment or that combined amount as exclusively Tornado-derived or GamiFi-derived. All five collector inputs, the collector output, and both sampled withdrawals were verified with full transactions and receipts.

## 3. Later direct Binance edge

[0x6f9f90f6a7f3fe611aecf41bc69f7cb87cf077fc](https://bscscan.com/address/0x6f9f90f6a7f3fe611aecf41bc69f7cb87cf077fc), another April-window recipient, sent **199.805845 BNB** directly to disclosed Binance `8894` on **2022-06-19 22:02:36 UTC**: [transaction f721f2b0](https://bscscan.com/tx/0xf721f2b0cb99625459b39c727df86f61c64516f8512f30c78e1620c85fc738de). Its full transaction and successful receipt were checked. Only **20 BNB gross** of its Tornado withdrawals is covered by the original window; other funding remains outside this analysis. The payment falls outside the seven-day follow-up interval. A later 0.567397-BNB Binance payment is an index-level supplementary observation only.

## 4. July consolidation reaches a Beacon Chain bridge request

July recipients `d304225…` and `2cb3056…` paid a combined **895.843292643575942356 BNB** to [0x165dec36f5468e5ca89c5804758491d488d03ec8](https://bscscan.com/address/0x165dec36f5468e5ca89c5804758491d488d03ec8). The amounts include activity beyond the sampled withdrawals; no exclusive pool provenance is claimed.

Its [successful TokenHub request](https://bscscan.com/tx/0x6c10184394ef98643836332ff8f5de707bcf81eeeea208f8053a0fa4ee14fe1d) supplied **895.83979264 BNB** and specified a transfer amount of **895.83779264 BNB**, with recipient bytes `0x64a0afd774180b7796c30197b8d105b04d9af21e`. BNB Chain's documented address encoding converts this to **`bnb1vjs2l4m5rq9h09krqxtm35g9kpxe4us7m505y6`**. It does not match any of the 25 BEP2 addresses in Binance's same historical disclosure. No Beacon completion record or exchange customer was recovered; the official explorer lookup was rejected by web retrieval. BSC request success does not itself verify destination-chain credit.

## Verification and source files

Thirty distinct selected transactions have full public-RPC transactions, receipts and block headers; all success checks and the 14 applicable prior Withdrawal-log comparisons pass. Fourteen archive balance calls establish the two collector equations and the five source-wallet final balances. No transaction was sent or signed.

Canonical files: `candidate_route_summary.json`, `verified_candidate_route_transactions.json`, `verified_extra_candidate_transactions.json`, `candidate_route_balances.json`, `extra_candidate_balances.json`, `beacon_request_decoded.json`, `scan_coverage.json`, `summary.json`, and the raw captures. `incoming_known_address_matches.json` and `primary_exchange_matches_all_dates.json` distinguish indexed leads from selected receipt-verified routes. `between_recipient_outputs.json` contains five indexed recipient-to-recipient outputs, including two self-transfers; the three non-self links are candidates, not ownership findings.

Endpoint attribution is based on an organizational disclosure for November 10, 2022; it does not identify an exchange customer or independently prove who held a signing key on a different date. Protocol references under `protocol/` include official historical TokenHub source and the BNB Chain JavaScript SDK address encoder. No deployed-bytecode equivalence claim is made for TokenHub in this continuation.
