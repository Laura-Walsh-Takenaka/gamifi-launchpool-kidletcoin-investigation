# Research Paper — Bounded check: first two administrator transactions after Shibafriend withdrawal

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Address: `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`, BNB Smart Chain (56).

The administrator's historical account transaction count is **344** at the end of block **18,905,894**, containing the original 22 June 2022 project 9 withdrawal. A binary nonce search shows its next ordinary signed transaction occurs only on **5 July 2022**, block **19,281,408**. The nonce was still 344 at block 19,281,407.

| Signed nonce | UTC 5 July 2022 | Block | Transaction | Created contract |
|---|---|---|---|---|
|344|09:57:49|19281408|`0x6a8963886daca08739b1b7043825c5060afe09bb7c14d592ae4ca6974080ba99`|`0x0c64d87defd1e21feb06fecc168aaeadece8309e`|
|345|10:00:19|19281458|`0x6a2bcd922241c3d7a5e457a281ac9f5fcfeb2fceb36ba32da80d6c3ad8b3923a`|`0x47d24bfa8b63d15b25de4ebc4308e5a2a39370be`|

**Both transactions deploy contracts, carry zero native BNB value, succeed, and emit no event logs. Neither receipt records a BUSD transfer or refund.** The first small contract's selector/opcodes resemble the repository's `contracts/dukeNFT/Rand.sol`; the second includes ERC721-related selectors and bytecode. No formal reproducible source-implementation match was attempted in this limited extension, so those functional associations remain investigative descriptions rather than exact deployment attestations.

The nonce boundary establishes no ordinary signed outgoing transaction by this administrator between the 22 June withdrawal block and the 5 July deployment. It does not exclude payments by another address, transfers under a prior token allowance, or refunds after the selected two transactions. In particular, the separate Shibafriend refund offer is not resolved by this negative two-transaction result. The original project 9 receipt was forwarded by 56aa to 35b1, not back to this administrator as original FOMO was; another payer or time range may be relevant.

Historical nonce queries were made through the QuickNode demo BSC endpoint, with one worker. Full blocks and successful receipts were retrieved through Binance's public BSC endpoint. Original requests, retrieval timestamps, endpoints and responses are in `chain_raw/`. `nonce_344.json`, `nonce_345.json` and `FACTS.json` provide compact extracts with full transaction hashes. The task stopped after the two selected transactions.
