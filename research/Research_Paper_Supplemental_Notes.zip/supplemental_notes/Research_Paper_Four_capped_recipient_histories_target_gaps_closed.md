# Research Paper — Four capped recipient histories: target gaps closed

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

**All four previously flagged normal-history target gaps are closed.** The continuation recovered **241 additional normal transactions**, with full transaction and receipt evidence for each. The accounting is 240 outgoing transactions plus one incoming transaction. Two of the four flags were overly conservative: their retained descending pages already covered the entire target.

| Recipient | Target UTC | Outgoing nonces | Outgoing count | Newly recovered normal transactions |
|---|---|---:|---:|---:|
| `0x57dd3ff4b4cda25a5a86097c977b3d3e18d4840c` | 2022-07-27T09:19:29+00:00 to 2022-08-03T09:19:29+00:00 | 3294–unchanged | 0 | 0 |
| `0x58ef0d569a1e6e90cb9098d635c71d672cdde760` | 2022-07-27T20:09:30+00:00 to 2022-08-03T20:09:30+00:00 | 647–651 | 5 | 0 |
| `0x69b4053398072f88dc6282326b1782c67dbe1d14` | 2022-04-28T23:16:03+00:00 to 2022-05-05T23:16:03+00:00 | 1761–2076 | 316 | 186 |
| `0xe64e84f76527985a03120591a5392e48461e6b4a` | 2022-04-28T05:34:02+00:00 to 2022-05-05T05:34:02+00:00 | 997–1051 | 55 | 55 |

## Coverage and method

- `57dd3f`: latest 500 rows begin May 5, 2022, before its July target; the target has no indexed normal transactions and archive nonce remains 3294 throughout.
- `58ef0d`: earliest/latest pages overlap by 231 identical hashes. Its five target transactions have contiguous verified nonces 647–651. Its retained descending pages already covered the target.
- `69b405`: a genuine supported `addressType=from/to` filter recovered ten missing outgoing rows plus one incoming row. Full block reconstruction recovered the remaining 175 missing sender transactions. The final outgoing set is exactly nonces 1761–2076 (316 transactions). The incoming normal index is exhausted at 48 rows, three inside target.
- `e64e84`: all 55 target sender transactions were missing from the initial first/latest combined index. All nonces 997–1051 were recovered. The incoming-direction ascending index reaches beyond target end, with zero normal incoming transactions inside target.

The archive search bisects block ranges using historical transaction counts and skips ranges with no nonce increase. It retrieves the full transaction block at every remaining nonce change, verifies the complete sender-nonce sequence, and fetches each recovered receipt. The four target upper block boundaries were checked against the next block timestamps. This proves outgoing normal-transaction completeness in the target intervals. Incoming coverage remains the public index scope; internal calls and token transfers initiated by other accounts are separate.

Fresh checks cover 379 full transactions across these four target windows, including all 376 sender transactions and three incoming transactions. 246 target transactions have fresh receipts: all 241 newly recovered transactions plus the five previously indexed `58ef0d` transactions. Newly recovered receipts include 12 reverted transaction(s); these are not counted as successful value transfers. Five additional ONUS-route output receipts are separately verified.

## New exchange records lead: five USDT payments reach an ONUS-labeled endpoint

The unassigned April 10-BNB-pool recipient `e64e84` sent five payments totaling **8,144 USDT** to `0x5f330ba134051d247a6700babed73b587b75b21b`. This intermediary made five matching payments to `0x893064ca1550c9ced53e85e24a72679f59385b07`, labeled **ONUS 1** by BscScan. All ten selected transfer logs and successful receipts were checked. The endpoint label is an explorer attribution; this lane did not find an exchange self-disclosure.

| Input UTC | Input USDT | Input transaction | Onward UTC | Onward transaction |
|---|---:|---|---|---|
| 2022-04-28T05:41:35+00:00 | 1098 | [0x642df8e3](https://bscscan.com/tx/0x642df8e3fa5f7a6f0a33d00299c2e1ac142dc2dc7fb2dd157e4a998bf153957d) | 2022-04-28T05:46:59+00:00 | [0xf1b72af8](https://bscscan.com/tx/0xf1b72af88260b841f4bb3c740089e9adbdb1103dd17f6c09587e5a119a864a01) |
| 2022-04-30T00:48:08+00:00 | 2000 | [0x1a1d8af5](https://bscscan.com/tx/0x1a1d8af510bd3e99f6bace01a184941d01a42767860977a06407e1390833e84e) | 2022-04-30T00:52:26+00:00 | [0x9aae1223](https://bscscan.com/tx/0x9aae12235ab19364957d3a5d6d46c06222ca73bc19f6885f048f8960f41cc1a2) |
| 2022-05-01T02:53:44+00:00 | 1000 | [0xf019349d](https://bscscan.com/tx/0xf019349dca61c3036ecd39de5bf7c11b77c1acfa4ee1009214b828efcd385dd3) | 2022-05-01T14:03:34+00:00 | [0x68050eff](https://bscscan.com/tx/0x68050effd2f028311b75ada6ab34aaa9b722f846f8ef2c70bc418dc215a74c30) |
| 2022-05-02T23:17:33+00:00 | 1959 | [0xce432ff8](https://bscscan.com/tx/0xce432ff8270a513c1904705cf312b3b6d5a8ffa82166bffdb2b67ec61e690e09) | 2022-05-02T23:20:42+00:00 | [0xd401014a](https://bscscan.com/tx/0xd401014a08c8f934762b069107853107cbf39433b10d2bb70716ff642353e12a) |
| 2022-05-05T00:38:57+00:00 | 2087 | [0xebdf1dc9](https://bscscan.com/tx/0xebdf1dc944f4930d37b6a164b26015c3844b75111a9e1718f048421dd51ef6c4) | 2022-05-05T00:42:33+00:00 | [0xfdf54a72](https://bscscan.com/tx/0xfdf54a729d2bdd3ba945d16e23f0ae35e7674eed75601054a286d30b068fd8da) |

Canonical USDT ledger for the intermediary, blocks 17,331,092–17,525,310: **0.000276077681813602 opening + 8,144 inputs − 8,144 outputs = 0.000276077681813602 closing USDT**. The captured token index includes exactly five positive canonical-USDT inputs and five outputs in that interval. A conservative contribution range from these five `e64e84` inputs to the combined ONUS-labeled payments is **8,143.999723922318186398–8,144 USDT**. The retained dust means these are not represented as five zero-balance sweeps.

**The GamiFi deposit note remains unassigned.** `e64e84` had substantial other assets and DeFi activity; the USDT payments are not attributed exclusively to its sampled 10-BNB withdrawal. No exchange customer or human wallet owner is identified.

An exact-address search also found an ImmuneBytes article naming `5f330` in a later RES-exploit route. This lane did not verify that article’s route. The observed repeated payments onward to an exchange-labeled address make shared-service explanations material. The article is preserved as a search lead in `source_notes.json`, not treated as a verified GamiFi/attacker connection.

## Other observations

`58ef0d` exchanged 9.9 BNB through PancakeSwap for 2656.113798148046711276 BUSD and made four canonical-BUSD transfers totaling 1,208 BUSD to `0x40cc5f86022c2fbb229db1e2f9d7c733b7ec68a7`. Those five transactions are fully verified. The next address’s first 500 normal/token index rows do not reach the July target, so no further endpoint is assigned.

Direct destination comparisons against the prior 116-address register find only the PancakeSwap router, Tornado proxy and canonical USDT contract in the four recovered target histories. These service/asset interactions do not create a new project-control-wallet link.

Canonical outputs: `findings.json`, `RECOVERED_241_NORMAL_TRANSACTIONS.csv`, `reconstructed_senders.json`, `coverage_probe.json`, `directional_coverage.json`, `verified_directional_transactions.json`, `verified_58ef_transactions.json`, `verified_onus_route.json`, and raw captures. Prior files were preserved unchanged.
