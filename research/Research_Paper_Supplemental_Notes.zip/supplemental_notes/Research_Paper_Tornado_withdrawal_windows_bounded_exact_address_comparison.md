# Research Paper — Tornado withdrawal windows: bounded exact-address comparison

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

**No exact recipient or relayer overlap was found with the 116-address comparison register.** All four requested windows completed, yielding 444 Withdrawal events, 206 unique recipient addresses and 33 relayer addresses. This result does not identify which deposits funded those withdrawals.

| Branch | Inclusive time window, UTC | 10 BNB pool | 100 BNB pool |
|---|---|---:|---:|
| April | 2022-04-27T23:57:00+00:00 through 2022-04-29T02:11:32+00:00 | 194 | 59 |
| July | 2022-07-27T06:19:00+00:00 through 2022-07-28T08:49:14+00:00 | 162 | 29 |

The April window covers blocks 17,324,279–17,355,470; the next block is after the requested end time. The July window covers blocks 19,909,171–19,940,886. All ranges are contiguous. Both windows include the deposit-series interval plus 24 hours after the final deposit.

The116 unique comparison addresses come from eight separately recorded sets: current-report BSC address URLs; ten named BSC comparison addresses; 30 cohort recipients; the two direct deposit senders; both depositors’ verified normal counterparties, including the final dust recipient; prior-report addresses; Ethereum report address strings; and Ethereum Safe-owner address strings. These sets include infrastructure and counterparties and are not asserted to form one common-control cluster. Zero address is excluded from comparators.

April has 253 withdrawals and no zero-fee withdrawals. July has 191 withdrawals, including eight zero-fee withdrawals. No event in either branch names the zero address as relayer. Full transactions for all eight zero-fee cases show sender=recipient=relayer **0x1cf0eeeb39fe5c8316e505bdcb5f1c8252598661**. This sender is absent from every comparison set. These self-submitted withdrawals are not linked to the investigated deposits by the present evidence.

Earliest observed withdrawal examples:

| Branch | Transaction | Block | Pool denomination |
|---|---|---:|---:|
| april | [0x759f2b1ed2d2f5c90924eb652776dd273c67ddd75190bfe0e80d80af9053117d](https://bscscan.com/tx/0x759f2b1ed2d2f5c90924eb652776dd273c67ddd75190bfe0e80d80af9053117d) | 17324317 | 10BNB |
| april | [0xf825c76b180377b4ba33f85acdf95b199d2c111deffba167bc124ac902a3707c](https://bscscan.com/tx/0xf825c76b180377b4ba33f85acdf95b199d2c111deffba167bc124ac902a3707c) | 17324335 | 10BNB |
| april | [0x73fe9d93ae9e344aa2654d3915a77e3b4b0b9995c6621802d9ba3c81c5b9df1b](https://bscscan.com/tx/0x73fe9d93ae9e344aa2654d3915a77e3b4b0b9995c6621802d9ba3c81c5b9df1b) | 17324344 | 100BNB |
| july | [0xdca0b8905a11dac0c6879d43f882b213572490946f3c57c02a3eef51cd084303](https://bscscan.com/tx/0xdca0b8905a11dac0c6879d43f882b213572490946f3c57c02a3eef51cd084303) | 19909208 | 10BNB |
| july | [0xa6311b98fd9baf03b5c003d02b6fd32147d9e24d7aca9cc1d9083cc094c58fa5](https://bscscan.com/tx/0xa6311b98fd9baf03b5c003d02b6fd32147d9e24d7aca9cc1d9083cc094c58fa5) | 19909257 | 10BNB |
| july | [0xd456d1f991133b519fda7afecc8245e97e25946bd1b2681453e21c73645dfe48](https://bscscan.com/tx/0xd456d1f991133b519fda7afecc8245e97e25946bd1b2681453e21c73645dfe48) | 19909409 | 10BNB |

The official Instance ABI matches its pinned repository Git blob. Event decoding preserves recipient, nullifier hash, indexed relayer and fee. Eight failed Binance log requests are retained: batch transport was rejected, followed by limit errors on individual queries even at smaller ranges. All four complete windows subsequently succeeded through the working archive endpoint.

Primary files: withdrawal_window_findings.json, WITHDRAWAL_WINDOWS.csv, withdrawals_decoded.json, withdrawals_with_matches.json, comparison_register.json, sampled_zero_fee_senders.json, sample_and_start_headers.json, windows.json, window_boundary_headers.json, log_ranges.json and raw/. The earliest sender-funding follow-up is a separate bounded lane.

No match within these windows is a limited negative result, not proof that no relationship exists. Other times, denominations, chains and indirect transfers remain outside this scan. Individual UTC timestamps are included only where a block header was separately fetched; every event has its exact on-chain block and transaction reference.
