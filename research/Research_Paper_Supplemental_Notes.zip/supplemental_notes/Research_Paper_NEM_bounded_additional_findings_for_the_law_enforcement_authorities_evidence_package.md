# Research Paper — NEM: bounded additional findings for the law-enforcement authorities evidence package

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Research date: 7 September 2026. Read-only public research. No person, institution or exchange contacted; no paid report purchased. The following changes supplement the current KidletCoin/NEM masters. They do not establish a KID grant, theft, exclusive human key custody or a child-data offence.

## Priority changes for the master

### 1. Add a separate Malaysian appointment to the dated-role table

| Date | Documented act or role | Attribution and significance |
|---|---|---|
| 30 June 2019 publication | Foundation update states that Jason Lee and Laura Takenaka had been appointed directors of NEM Malaysia, with no remuneration for those roles. | A separate reported corporate office from the Singapore Foundation appointments. Obtain the Malaysian company register, resolutions, exact appointment/cessation dates and mandates; the update does not assign any of the twelve SEA payments to this role. [NP01] |

Add after the appointment discussion in section 13:

The 30 June 2019 Foundation update additionally reports Laura and Jason Lee as non-remunerated directors of NEM Malaysia. Native post 87164 was created at 08:37:36.812 UTC and updated at 08:41:19.926 UTC that day, version 1. This supplies an additional corporate-record custodian, not an authenticated filing or proof of particular wallet instructions. The exact appointment date and legal entity must be matched to the Malaysian register. [NP01]

### 2. Correct the contract-review statement date

Replace the current paragraph in section 13 beginning “The family project was publicly discussed” with:

The family project was publicly discussed on 20 November 2018; a participant's separate USD 2,000 salary statement concerns himself. On **3 July 2019**, `Inside_NEM` stated that bank-payment evidence had been supplied to the Core Team and that more than 70 worldwide Foundation MoUs/partner contracts had undergone review. The native post was created at 02:03:22.904 UTC and updated at 03:26:53.897 UTC that day, version 1. The underlying bank statements, agreements and approvals were not recovered. This statement neither classifies Laura's payments nor proves their purpose. [ND-11; ND-12; NP02]

The earlier wording “June 2019” describes the update being questioned, but is the wrong date for this reply. The current companion on-chain master cites ND-12 without the erroneous June date, so no matching date correction was located there.

### 3. Add the Trust's separate liquidation records

Add after the Foundation's liquidation paragraph in section 12:

Separate original-format Gazette notices for **NEM.IO Trust Limited, UEN 201632738Z**, now provide a more precise records trail. A notice first published 10 June 2021 records the 4 June members' resolution, chaired by Jeffrey Thomas McDonald, directing any post-liability surplus to a qualifying charity/Institute of Public Character under constitution regulation 60(2). A notice first published 10 August 2021 scheduled the final meeting for 10 September 2021 to receive the liquidators' account and decide disposal of company/liquidation records. Both identify Lo Wei Min @ Mrs Pearlyn Chong and Chan Tuck Chee. These mirror-hosted notices establish stated resolutions and scheduled business, not the actual surplus recipient, payment, meeting outcome or destruction of records. Obtain those schedules and resolutions separately from the Foundation's 2022 records. [NP03-NP04]

## Exact records these findings help law-enforcement authorities request

| Record holder or route to establish | Specific records | Question answered |
|---|---|---|
| Historical NEM Malaysia company secretary and finance custodian; exact entity first | Certified historical directors/member register; appointment and cessation instruments; board minutes; bank and wallet mandates; service agreements and payment ledger | What authority did Laura actually have, during which dates, and which entity authorized relevant work? |
| Singapore Foundation finance/secretariat and the identified liquidators | Native SEA ledger keyed by the twelve `SEA/YYYY/MM/NN` references; supporting invoices/contracts/approvals; counterparties and conversion/settlement records | Were the twelve transfers salary, expenses, project costs or something else? |
| Author/custodians of the 3 July 2019 statement and Core Team recipients | The specific Q1 bank-proof package, contract inventory, approval records and correspondence identifying each submitted attachment | Can the publicly claimed underlying records be recovered and reconciled? |
| NEM.IO Trust liquidators and former secretary | 10 September 2021 meeting notice/minutes/attendance; liquidators' final account; regulation 60(2) recipient decision; asset-transfer and recipient receipts; return of final meeting; records-disposal resolution and present custodian | Who actually received residual assets and where are the supporting records? |

No acquisition request has been sent. The presence of a lawful liquidation or a non-remunerated directorship is not itself suspicious. These are precise retrieval routes for already identified gaps.

## Other bounded results, kept separate from the law-enforcement authorities priority

**Malaysian entity search lead only.** Two commercial registry services list NEM Malaysia Sdn. Bhd. as **1233908-X / 201701019743**; CTOS lists incorporation on 5 June 2017. These are secondary search identifiers, not an official SSM extract, and must be matched before attributing the reported appointment to that exact corporation. Conflicting Singapore-directory identifiers were excluded rather than treated as extra proven companies. [NP05-NP06]

**Institutional delivery is not uniformly absent.** Bank of Lithuania records describe completed e-shop acceptance testing and an audit of private-NEM software on 3 June 2020, actual LBCOIN issue on 23 July 2020, and project closure on 23 January 2023 with exchange/public-NEM transfer extended to 2 May 2023. That is a specific institutional delivery/lifecycle record, distinct from a promise alone. It does not authenticate the technical audit report, show Laura's personal role, classify the 21 selected payments, or supply the Singapore Foundation's financial audit. No KID linkage is established. [NP07-NP09]

**Additional university record.** Universiti Malaysia Sabah's 2019 sustainability report, PDF page 31 (printed page 28), lists NEM Malaysia among ICT partners. Its group description does not attribute Huawei-lab or digital-forensics delivery individually to NEM, nor supply a NEM contract/payment. The currently hosted path contains 2025 dates; the report concerns 2019 and cites 20 August 2019 news, but this retrieval does not independently timestamp original publication. [NP10]

**Unresolved after this pass.** No executed contract/invoice approving any of the twelve SEA receipts or nine issuer transfers; no signed Singapore audited accounts or reconciliation of 43% versus 27.3%; no actual Trust/Foundation surplus recipient receipt; no new human signing mandate; no exchange customer mapping. No new NIS1 or Symbol replay was performed. The existing 125-address Symbol allocation table remains a separate allocation record, not downstream spending.

## Sources and bounded provenance

- **NP01:** NEM Foundation June update, post 1: https://forum.nem.io/t/nem-foundation-update-june-2019/22980 ; native metadata https://forum.nem.io/t/22980.json . Locator: “NEM Malaysia CEO Jasmine Ng Bids Farewell”, final paragraph.
- **NP02:** `Inside_NEM`, post 2: https://forum.nem.io/t/foundation-update-questions/22994/2 ; native metadata https://forum.nem.io/t/22994.json . Locator: answer to question 1. The reply is dated 3 July 2019, not June.
- **NP03:** Original-format Gazette notice, first published 10 June 2021, print header 11 June 2021: https://www.sgpbusiness.com/get-pdf/eg/5aad070a-8a7e-11ec-b068-f48e38c3a128 . Page 1, final resolution; secondary mirror of original notice.
- **NP04:** Original-format Gazette final-meeting notice, first published 10 August 2021, print header 13 August 2021: https://www.sgpbusiness.com/get-pdf/eg/5af04905-8a7e-11ec-b068-f48e38c3a128 . Page 1, scheduled 10 September meeting and numbered purposes; secondary mirror of original notice.
- **NP05:** Secondary CTOS company lead: https://businessreport.ctoscredit.com.my/oneoffreport_api/single-report/malaysia-company/1233908X/NEM-MALAYSIA-SDN-BHD- . No report purchased.
- **NP06:** Secondary D&B/CreditScan company lead: https://www.creditscan.com.my/Malaysia-Company/NEM-MALAYSIA-SDN-BHD/1233908-X . No report purchased.
- **NP07:** Bank of Lithuania, 3 June 2020: https://www.lb.lt/en/news/development-of-the-bank-of-lithuania-s-digital-collector-coin-has-entered-its-final-phase . Locator: testing/UAT paragraphs.
- **NP08:** Bank of Lithuania, 23 July 2020: https://www.lb.lt/en/news/bank-of-lithuania-issues-lbcoin-the-world-s-first-digital-collector-coin . Locator: issuance and public-NEM functionality.
- **NP09:** Bank of Lithuania, 2 February 2023: https://www.lb.lt/en/news/period-to-exchange-or-transfer-lbcoin-digital-tokens-is-extended-until-2-may . Locator: first substantive paragraph.
- **NP10:** UMS 2019 sustainability report: https://www.ums.edu.my/ecocampus/media/attachments/2025/10/31/ums-sustainability-report-2019.pdf . PDF page 31 / printed 28, SDG 9 table. The paragraph cites a news report; do not treat each grouped partnership benefit as individually verified NEM delivery.

`retrieval_manifest.json` records successful direct retrievals, UTC times, response lengths, SHA-256 and bounded native-post excerpts. Failed direct requests are expressly recorded; a response hash fixes retrieved bytes, not truth. Full copyrighted forum pages, bank news pages, commercial-directory pages and university reports are not redistributed in this lane. The two original-format public Gazette notices were readable through the web retrieval service, but direct byte downloads returned HTTP 403; the package therefore preserves their URLs, precise page locators and bounded factual notes, without claiming authenticated original PDF bytes.
