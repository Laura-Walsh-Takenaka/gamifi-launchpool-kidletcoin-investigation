# Research Paper — Techstars + Cardano Founder Catalyst — validated review

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Reviewed 5 September 2026. This report evaluates the specific 2025 program and grant #1300182. It does not attribute every Techstars or Cardano activity to Laura Walsh.

The deeper review resolves the earlier apparent budget and cohort discrepancies. The remaining issues concern how readers interpret operational metrics, what program participation validates, and whether a current assignment exists. No reviewed evidence establishes personal grant misuse by Laura.

## F01 — Grant amount and the difference between payments and spending

The official grant record names Techstars as the incorporated applicant, reports completion, and records **1,300,000 ADA distributed**. Its original narrative assigned 80% to core delivery; the completed milestone payment table assigns 30%. The proposal expected six months, while the final administration schedule extends through month ten. Those are distinct from the ten-week teaching period. The page does not disclose detailed operational expenditure. [Official grant record](https://projectcatalyst.io/funds/13/cardano-partners-growth-and-acceleration/techstars-will-help-cardano-builders-grow-their-businesses-to-drive-cardanos-adoption)

**Resolution:** a reviewer on 7 May 2025 approved after checking with Catalyst that the payment schedule could not be changed to match the proposal budget. The statement of milestones received administrative signoff on 19 May. This directly answers the apparent allocation contradiction: payment tranches are not an expenditure ledger. The earlier characterization as an unexplained changed spending budget is withdrawn. [Milestone 2 — open active reviews](https://milestones.projectcatalyst.io/projects/1300182/milestones/2)

## F02 — Cohort size, mentor status and what diligence covered

The approved selection milestone explicitly allowed **15–20 startups**, with up to 30 only for an exceptional applicant pool. It specified 25–30 interview finalists, a 30–50-expert mentor pool, volunteer mentors, and due diligence addressing legal considerations rather than technical evaluation. Administrative approval occurred 19 May 2025; achievement signoff followed on 9 October. Consequently, a twenty-company cohort meets the approved gate. The older thirty-company narrative is not evidence of underdelivery. **Practical limitation:** program admission should not be presented as a technical security audit, product certification or investment recommendation. This qualification is part of the program's own disclosed scope. [Milestone 3](https://milestones.projectcatalyst.io/projects/1300182/milestones/3)

## F03 — Teaching delivery and the meaning of mentor engagement

The approved delivery criteria required 7–10 masterclasses and 2–4 pitch practices. Achievement evidence reports twelve classes, four mandatory practices and one optional practice. Administrative signoff occurred 8 January 2026. The agreed monitoring method counted bookings and weekly engagement; it did not require recordings of confidential mentoring. Its attendance definition counts a company when a representative attends or consumes the material. The 70% attendance figure was a participation goal, not an absolute warranty for every company. **Remaining measurement limit:** booking totals establish scheduled engagement, not an independently reconciled count of completed meetings or hours. Describing this metric accurately is appropriate; alleging missing meetings from it is not. [Milestone 4](https://milestones.projectcatalyst.io/projects/1300182/milestones/4)

## F04 — Graduation, showcase and timing

The showcase achievement submission explains that two companies did not meet program requirements, leaving **eighteen final pitches**. Administrative approval followed on 5 February 2026. The approved milestone already allowed exclusion where requirements or submission deadlines were unmet. Its May 2025 revision also explained that surveys and compilation would follow the December event and holiday period. Thus the January/February administrative milestones do not indicate an extended teaching course or a missing showcase. [Milestone 5](https://milestones.projectcatalyst.io/projects/1300182/milestones/5)

The 10 October 2025 announcement independently records **twenty selected companies**, starting 6 October. Its visible roster has nineteen names, a minor editorial omission that has little investigative weight once the selection and completion records are read together. [Official cohort announcement](https://www.techstars.com/blog/program-news/introducing-the-2025-techstars-cardano-founder-catalyst-cohort)

Calculations from the above records:

| Measure | Arithmetic | Correct interpretation |
|---|---:|---|
| Graduation rate | 18 / 20 = **90%** | Program completion, not business survival |
| Grant per selected company | 1,300,000 / 20 = **65,000 ADA** | Whole-program funding divided by intake |
| Grant per graduate | 1,300,000 / 18 = **72,222.22 ADA** | Whole-program funding divided by graduates |

These ratios are neither individual company grants nor Laura's compensation. They cover project preparation and support as well as instruction. No speculative dollar conversion is used.

## F05 — Final reporting and survey requirements

The final milestone required a public report, public closeout video, and communication of continuing resources. Its survey target was 75% of companies, explicitly voluntary. It permitted withholding private, redundant or out-of-scope responses. The final evidence was submitted 27 February 2026 and approved 24 March. Evidence links include the recovered report and public video. No disclosure of confidential applicant or mentoring content is needed to assess these public requirements. **Remaining validation question:** anonymous question-level response counts and distinct-company coverage would establish whether the participation target was met; the target was not an unconditional completion requirement. [Final milestone](https://milestones.projectcatalyst.io/projects/1300182/milestones/6)

## F06 — What the final report proves and what it leaves open

The 27 February report names **Laura Walsh as a mentor** (p32). Its 51 mentors comprise 47 external mentors plus four staff. It reports **447 scheduled meetings**, **4.87/5 overall satisfaction**, **twelve accelerator applications**, continuing support, and **230 RSVPs versus 186 live viewers**. Charts on pp47/49 explicitly contain **sixteen responses**; pitch improvement is retrospective self-rating. Sixteen responses cannot automatically be treated as sixteen distinct companies or the denominator for every average. Page 17's partner score and page 49's founder ratings of that partner need distinct labels; they need not be the same measure. Commercial highlights are founder-reported and do not establish audited cohort-wide investment returns. Overall satisfaction's separate denominator, completed meeting count, subsequent financing, revenue and retention remain unverified. [Official final report — publisher milestone record](https://milestones.projectcatalyst.io/projects/1300182/milestones/6)

## F07 — Current program continuity

The current Founder Catalyst page lists other programs and describes a non-equity pre-accelerator; Cardano is absent. Its dedicated historical information URL returned 404 during the review. A specific September 2026 Laura assignment or replacement Cardano cohort was not verified. This is a current-status limit, not evidence that the completed program was fictitious or that ongoing alumni mentoring ceased. [Current program list](https://www.techstars.com/founder-catalyst)

Cardano's 1 December 2025 Venture Hub update describes continuing Techstars collaboration alongside other partners. Its separate Spring 2026 Cardano Accelerator Program should not be conflated with this Techstars cohort. [Cardano Venture Hub update](https://cardanofoundation.org/blog/venture-hub-expands-new-programs)

## Claim ledger

| Earlier assertion or review question | Disposition | Evidence and consequence |
|---|---|---|
| Apparent unauthorised spending reallocation | **Resolved / withdrawn** | F01: reviewed payment mechanics; actual expenditure cannot be inferred |
| Thirty promised, twenty selected proves underdelivery | **Resolved / withdrawn** | F02: approved selection range was met |
| Eighteen presenters contradict twenty participants | **Resolved / withdrawn** | F04: graduation requirements explain the difference |
| Ten-month administration contradicts ten-week instruction | **Resolved / withdrawn** | F01/F04/F05 distinguish phases |
| No final report was accessible | **Resolved / withdrawn** | F05/F06: official report recovered |
| Laura's relevant mentoring claim is self-report only | **Resolved / withdrawn** | F06: official corroboration |
| Program delivery did not occur | **Contradicted** | F03/F04/F05 document delivery and approvals |
| A mentoring role establishes receipt/control of grant funds | **Unsupported / removed** | F01/F02 establish different roles |
| Every booking was completed | **Open** | F03/F06: no completed-session reconciliation inspected |
| Satisfaction means independently measured commercial success | **Downgraded** | F05/F06: voluntary survey and reported outcomes |
| Current active cohort or assignment | **Open** | F07: no specific present assignment verified |

## Proportionate follow-up evidence

The useful remaining materials would be an anonymized survey methodology with unique-company coverage; aggregate booked/completed/cancelled mentoring counts; defined financing and revenue outcomes at a fixed follow-up date; and a public current-program or current-role statement. These would improve evaluation without exposing confidential applications, mentor calendars or private business discussions.

Method: official public pages, live milestone/review panels, recovered native report text and chart-image inspection. No account sign-in, third-party contact, document copying, private applicant-data access, or live-system probing was performed. Speaker notes were not treated as visible slide defects. Approval establishes acceptance under the milestone framework; it is not an independent financial audit.
