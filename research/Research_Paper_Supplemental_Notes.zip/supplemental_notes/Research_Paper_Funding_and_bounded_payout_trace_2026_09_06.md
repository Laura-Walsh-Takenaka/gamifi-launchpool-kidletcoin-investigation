# Research Paper — Funding and bounded payout trace — 2026-09-06

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

## 1. Two sampled Launchpool batches were actually funded

BNB Smart Chain canonical GMI: `0x93d8d25e3c9a847a5da79f79ecac89461feca846`.
VestingLaunchPool proxy: `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb`.

Both of the previously sampled stored schedule start timestamps lead to successful `initiateVests(address[],uint256[],uint256[],uint256,uint256,uint256,uint256)` calls, selector `0x872e8f27`. Each receipt contains an actual GMI Transfer from the common deployment sender `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199` into the vesting proxy; each transfer amount exactly equals the decoded calldata total and sum of its beneficiary amounts.

| UTC on 2022-04-19 | Block | GMI transferred | Beneficiary entries | Transaction |
|---|---:|---:|---:|---|
|16:30:49|17086174|458882.5934562736916|200|`0x8a5f1c2ac6bd2a1f8ff17d16c55a64ac384401a27c15a1c1899c6c10d8e237bd`|
|17:14:29|17087043|887877.3822482400862|200|`0x854f39b52c34c65f6e2229ade8b2d6d26226fd20323d30703241de9b4c82dd38`|

Combined actual funding in these two transactions is **1346759.9757045137778 GMI**. All 400 address-and-amount pairs exactly match the public repository CSV: first batch rows 0–199, second batch rows 5800–5999 (zero-based). There are 400 distinct case-normalized beneficiary addresses across these two batches. Both use stake type 0, initial amounts all zero, cliff zero, linear period 23328000 seconds (270 days).

The initial sampled smallest record (17.2356392039306 GMI) is in the first batch. The sampled largest record (587755.519557566 GMI) is in the second batch. This closes the funding question for these specific batches. It does not prove all 7493 CSV rows executed, all planned allocations were funded, or that beneficiaries received payment.

Evidence: `found_1650385849.json`, `found_1650388469.json`, the two `receipt_0x...json` files and `decoded_funding.json`. Full historical blocks and intermediate binary search block reads preserve how exact transactions were found. `sha3_initiateVests.json` independently confirms selector.

## 2. Current balance and actual read-only claim simulation

At fresh common block **120222610**, using `eth_call` through `https://bsc-dataseed.bnbchain.org`:

- Vesting proxy GMI balance: **207.412329404181026961 GMI**.
- Largest sampled beneficiary `getClaimable(address,0)`: **587755.519557566 GMI**.
- Smallest sampled beneficiary `getClaimable(address,0)`: **17.2356392039306 GMI**.
- Simulating the largest beneficiary's legitimate `claim(address,0)`, with that beneficiary as transaction sender, **reverted with `ERC20: transfer amount exceeds balance`**.
- Equivalent simulation for the smaller sampled claim **succeeded**, returning empty success data (`0x`).

These were **read-only eth_call simulations, not submitted transactions**. No wallet was connected, no signature produced, and no blockchain state changed. This independently corroborates the root investigator's earlier balance/claimable reads, and establishes an actual execution failure at the observed block for a specific historically funded schedule.

This is not a reconstruction of all outgoing payments, proof of diversion, or evidence naming anyone responsible. Migration or other contractual arrangements would require separate evidence. Neither snapshot nor simulation identifies who controls a key or who ultimately benefited from earlier transfers.

Evidence: `independent_current_head.json`, `independent_balance.json`, `independent_large_claimable.json`, `independent_small_claimable.json`, `independent_large_claim_simulation.json`, `independent_small_claim_simulation.json`, `decoded_current_verification.json`. Exact request parameters, endpoint and retrieval timestamps are preserved in each raw response record.

## 3. A separate private-vesting payout is confirmed

A targeted search (`"gamifi" "Claim" "bscscan"`) surfaced indexed explorer transaction `0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639`:
https://bscscan.com/tx/0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639

Direct explorer retrieval returned403, but primary RPC transaction and receipt independently establish:

- 2022-12-14 16:01:19 UTC, block23901241, status success.
- Called contract **`0x74e0ddf89807107378beb02e6bc504243e0cdf6c`**, a separate address from the Launchpool proxy.
- Caller and GMI recipient **`0x36048413c4edf0cf3e633aab317fcd9824dfb4d4`**.
- Input selector `0xaad3ec96`, matching `claim(address,uint256)`, with arguments recipient address and 0.
- Canonical GMI Transfer emitted from the called contract to the recipient for **2131635.802469135802469136 GMI** (raw2131635802469135802469136).

The root's attribution lane separately reports the official frontend maps this address to `/private-claim`. That frontend evidence is external to this lane. This successful private-vesting payment is **not an outgoing transfer from 0xf504... and does not close its outflow history**. No identity has been assigned to the recipient address.

Evidence: `eth_getTransactionReceipt_0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639.json`, matching `eth_getTransactionByHash_...json`, `decoded_private_claim.json`. Search reference available to root: `historical retrieval`; failed direct open `historical retrieval` must not be cited as supporting content.

## Scope and limits

Exact timestamps were found by two bounded binary block searches from the known deployment date (not a chainwide scan). Only matching vesting transactions in the two exact blocks had receipts fetched. BscScan's address and token transfer pages returned403; retrieval failure records are saved. No exhaustive outgoing-transfer history was obtained for 0xf504..., and no conclusion about the purpose or recipient of all funds can be drawn from its present low balance. No bank account, natural person, wrongdoing, or beneficial ownership is identified here.
