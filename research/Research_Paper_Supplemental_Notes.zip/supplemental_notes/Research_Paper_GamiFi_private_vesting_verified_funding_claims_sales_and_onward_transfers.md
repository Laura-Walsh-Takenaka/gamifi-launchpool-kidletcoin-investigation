# Research Paper — GamiFi private vesting: verified funding, claims, sales and onward transfers

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research date: 6 September 2026. Chain: BNB Smart Chain, chain ID 56. All actions were read-only. The raw transaction receipts and call traces accompany this note. Dollar valuations are supplied by the separate price-verification lane; token counts in this note are not dollar amounts.

## Established chain of transactions

The original GMI deployment sender `0x0d2c8df71c846d0dbc9c8bc75ea39c45d5197dca` funded a **120,000,000 GMI** allocation in private vesting contract `0x74e0ddf89807107378beb02e6bc504243e0cdf6c` for beneficiary `0x36048413c4edf0cf3e633aab317fcd9824dfb4d4`. This occurred on **18 January 2022 at 15:56:50 UTC**, block **14476742**, successful transaction `0xac39350f0f652c95dfb73e0cd8f2028a2c8aa34a51d081374a6c850647625787`. The transaction calls the explicit-beneficiary `initiateVest` overload, with type 5, zero initial release, zero cliff and 31,104,000 seconds (360 days) of linear vesting. Its receipt records the actual token deposit.

Current private-contract `getVest` state records 120,000,000 GMI allocated and 120,000,000 GMI claimed for this schedule. A separate executable match confirms the current code's field semantics, but the current counter does not replace individual historical payout receipts or an intervening implementation-history check. Type 5 has no category-name definition in the matched contract; it cannot by itself identify a team member, investor class or treasury beneficiary.

Two individually verified claims, on 14 December 2022 and 20 January 2023, paid this beneficiary a combined **12,130,597.993827160493827161 GMI**. Five later sales sent **9,130,597.993827160493827161 GMI** to the PancakeSwap GMI/WBNB pair and paid the same beneficiary **578.555338221808442852 BUSD plus 0.582235106329889742 BNB**. Another **3,000,000 GMI** went through `0x9564f530d9f270a48c510a92c97b59248cefd464` to the MEXC-associated wallet `0x4982085c9e2f89f2ecb8131eca71afad896e89cb`.

Thus, the selected two claims reconcile exactly to the five sales plus the 3,000,000-token forwarding transaction. This is an aggregate reconciliation of these selected transfers, not a claim that particular fungible token units remain separately identifiable.

## Dated transactions

| UTC | Action | Exact amount / proceeds | Transaction |
|---|---|---|---|
| 2022-12-14 16:01:19 | Private vesting claim | 2,131,635.802469135802469136 GMI | `0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639` |
| 2023-01-20 05:38:45 | Private vesting claim | 9,998,962.191358024691358025 GMI | `0x8657b3b3182771a12734fa434536f6f2a667246a2f94998546da301f7e464f3d` |
| 2023-01-20 05:40:30 | GMI sale to BUSD | 3,032,649.498456790123456790 GMI → 225.410169579752827331 BUSD | `0x411c9e992b80d6bb8a0f88127c51f9428c5f78950f5eb527ca99e2521e618dd8` |
| 2023-01-21 02:29:17 | GMI sale to native BNB | 2,274,487.123842592592592592 GMI → 0.582235106329889742 BNB | `0xa599f04b0cc1343b3c1048b5d4275ba1bdd587a960f37b95368bc8b04463b095` |
| 2023-01-21 02:31:35 | Forward to `0x9564…d464` | 3,000,000 GMI | `0x331197c814cfecdbb91b25a81097b2b1280e65842abeffaa997c2f34bee5b77a` |
| 2023-01-21 02:34:05 | Forward from `0x9564…d464` to `0x4982…89cb` | The same 3,000,000 GMI | `0x2e371d5d37cc3deaef36f8c4798f0a18256257304d8eb4db697e6b4414cec02e` |
| 2023-02-25 12:49:01 | GMI sale to BUSD | 955,865.342881944444444444 GMI → 89.301011917324055514 BUSD | `0x56da94a4b0cf7b380063929853763a2fa81aaf548b9e9a2e3f4d477688a7e0a5` |
| 2023-02-25 12:49:28 | GMI sale to BUSD | 1,433,798.014322916666666667 GMI → 124.564682082873742182 BUSD | `0x776d2561d6329ba685647cc04cc2b4d42465c597be0cd1ae3a196c4df2d13d96` |
| 2023-02-26 06:07:24 | GMI sale to BUSD | 1,433,798.014322916666666668 GMI → 139.279474641857817825 BUSD | `0xd505ac7b81c6f1f2724eed8faafee4650ab6e70168f6d5ad2225e982dce560ff` |
| 2023-04-04 10:56:48 | Forward BUSD to `0xf4f8…b1d7` | 789.821799959045630101 BUSD | `0xab1707a54f5d665be52be7c7f6e1a40f85575e835c884c92a69381dc6f730334` |
| 2023-04-04 10:57:48 | Forward native BNB to `0xf4f8…b1d7` | 0.840230960291603498 BNB | `0xd9e76558654e142eb8355e18842c16e4985a0be2f03dd0e4b4e596bf713e9d58` |

The native-BNB sale is corroborated by `debug_traceTransaction` using `callTracer`, showing the router's successful native payment to the beneficiary, in addition to GMI-transfer and WBNB-withdrawal receipt logs. Other sale proceeds are direct BUSD Transfer events back to the beneficiary in the same successful transaction. These are actual on-chain proceeds before transaction fees. BUSD quantities are not assumed to be exact US-dollar amounts; their historical dollar conversion belongs in the valuation ledger.

The April transfers sent commingled funds. Their amounts exceed the selected BUSD/BNB sale proceeds and must not all be attributed to these GMI sales. An unrelated December CAKE sale is visible and excluded from the GMI financial totals. The recipient of the April transfers is `0xf4f86e37815217ed73ae817a4e5164d56315b1d7`; no verified organizational or individual owner is assigned to it.

## MEXC attribution and the limit of the exchange link

BscScan and Blockscan label `0x4982085c9e2f89f2ecb8131eca71afad896e89cb` as MEXC 13. More strongly, the parent investigation located MEXC's own published wallet disclosures naming this exact BSC/BEP20 wallet:

- https://mexcglobal.medium.com/recent-rumors-against-mexc-global-clarified-7205e6828907 (section addressing rumor 5)
- https://support.mexc.com/hc/ja/articles/13459541357209-MEXC%E3%82%A6%E3%82%A9%E3%83%AC%E3%83%83%E3%83%88%E3%82%A2%E3%83%89%E3%83%AC%E3%82%B9 (MEXC wallet-address disclosure, 13 December 2022, according to the parent retrieval)
- https://blockscan.com/Address/0x4982085c9e2f89f2ecb8131eca71afad896e89cb

The receipt establishes delivery to that wallet. It does not establish an exchange customer's identity, account credit, a subsequent exchange sale, withdrawal, bank transfer or Laura's receipt. `0x9564…d464` is an intermediate forwarding address; do not call it a customer's deposit address without MEXC records. The exchange's records are the next source for any customer attribution or off-chain trade.

## Control link

At block **120224717**, pinned public RPC checks in `head.json`, `private_owner.json`, `private_admin.json` and `private_impl.json` show:

- Private vesting owner: `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`.
- Private vesting EIP-1967 proxy administrator: the same `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`.
- Implementation: `0x21ba8b5e4c07f937f4fe887af964581d79f6bb30`.

The owner/admin address is already independently linked to current GMI/NFT/Launchpool contract control. This is common on-chain control at the sampled state, not identification of a human key holder or proof of who controlled these contracts in 2022–23. The private contract is distinct from the underfunded Launchpool contract.

## Scope, evidence and unresolved history

`material_transfer_ledger.json` contains one row per material asset leg with exact integer quantity, decimal quantity, block, UTC, endpoints, category and source-receipt path. `material_transfer_aggregates.json` separates input tokens, sale proceeds and later forwarding. Do not sum sale input values with their proceeds, or count the two 3-million-GMI forwarding hops as six million newly received tokens.

The 120-million-token funding receipt and selected 12.13-million-token claims are verified. The complete payout and disposal history of the other approximately 107.87 million tokens reflected in the current claimed counter has not been reconstructed. The 65 private-contract incoming logs in the bounded January 18 window total 303,640,182.039999995011137536 GMI, but only the 120-million-token schedule from that batch was individually receipt-verified in this lane; the wider sum is a discovery result and is not used as an independently verified funding total here.

Historic account-nonce bisection and token-balance bisection identified narrow intervals for retrieval. Queries used the public QuickNode documentation demonstration endpoint, with at most 10,000 blocks per log request and shared request pacing. Historical transaction receipts were retained. Current state checks used BNB Chain's public endpoint. The secondary forwarding address currently has zero GMI; that alone would not have established the MEXC transfer without its actual historical receipt. The first 10,000 blocks after the April BUSD forwarding showed no BUSD outgoing event from `0xf4f8…b1d7`; that narrow result does not exclude later activity.

No wallet was connected, signed transaction submitted, third party contacted or nonpublic financial account accessed. No individual or bank-account ownership is inferred.

## Account-transaction coverage after the December claim

All 12 subsequent top-level transactions from the beneficiary account, nonces 88 through 99, have been identified and receipt-checked. The sampled current nonce is 100. Nonces 88 and 89 concern CAKE and are excluded from GMI financial totals. Nonce 92, transaction `0x01a4cbca1682c242bc6638552dedc34d90f9c73e50b340e8128e16b6e211f7a6`, is a failed GMI-to-BNB swap (receipt status 0, no logs); it is excluded from asset-movement totals. The remaining nine subsequent transactions form the material beneficiary flows listed above. This complete nonce sequence does not establish a complete inbound-transfer history or the account history before the December claim. The full audit is in `post_claim_nonce_audit.json`.

Direct local retrieval of the two MEXC primary pages was blocked (timeout and HTTP403 respectively); failed-attempt provenance is retained. Their substantive public-source attribution relies on the parent investigation's successful search/retrieval, not these failed local fetches.
