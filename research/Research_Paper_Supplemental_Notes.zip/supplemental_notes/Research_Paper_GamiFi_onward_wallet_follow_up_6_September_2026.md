# Research Paper — GamiFi onward-wallet follow-up — 6 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Wallet: `0xf4f86e37815217ed73ae817a4e5164d56315b1d7`. This is a bounded continuation of the public GamiFi transaction trace. It does not identify the wallet's human owner.

## Coverage and verified observations

- The archive records nonce 50 at block 21,573,554, immediately before the 23 September 2022 selected incoming GMI transfer; nonce 73 persists after the 4 April 2023 selected receipts. Binary archive-state searches and full block bodies recovered every nonce 50–72, followed by the first later outgoing nonce 73 at block 28,257,553 on 16 May 2023 at 09:55:56 UTC.
- The resulting inventory has 24 normal outgoing transactions: 23 successful, one failed swap (nonce 52). Every transaction has its receipt; successful swap paths requiring native output/refund checks have call traces. The failed transaction contributes its network fee only.
- First recovered outgoing transaction: 7 October 2022, 16:24:19 UTC. Last: 16 May 2023, 09:55:56 UTC. The wallet has empty deployed code in the current queried state and a current nonce of 214, which supplies no human attribution.
- All 54 ledger rows carry exact base units, timestamp, transaction identifier, source paths and category. Historical USD/CAD marks are supplied separately by the valuation integration. The audit recomputes native fees and verifies all exact token/native quantities against base units.

## New direct connections

1. Four direct transfers sent **12 BNB back to the private-beneficiary wallet** `0x36048413c4edf0cf3e633aab317fcd9824dfb4d4`: 1 BNB on 4 November 2022 at 14:25:04 UTC; 3 BNB and 5 BNB on 6 November at 13:24:00 and 13:29:30 UTC; 3 BNB on 7 November at 07:41:45 UTC. The 1 BNB transfer ([receipt](https://bscscan.com/tx/0x1d511630993eefca8a67f6a63e189a6e25054f340e0d8867a00c6b5fb67cfbf3)) preceded the previously verified 96,645,563.271604938271604938 GMI private claim by 36 seconds. This establishes a funding and counterparty link. It does not establish who controlled either key, the purpose of the BNB, or authorization for the claim.
2. A further **0.5 BNB** went to `0x35b119730f79881dac623dc51c831c6a04cab5f3`, an address already present in the project-side trace, on 7 November 2022 at 14:00:56 UTC ([receipt](https://bscscan.com/tx/0x2640f592d8b45f512e121a014b7de6b7293aaf8b06785bd388e66d9c13195520)). This is an address-to-address relationship, not a human attribution.
3. The wallet sent **6,590 BUSD and 25,906.285983337104699148 USDT** to `0xba4d665059c97d6baa42e097707a504aecafbf53` in four transfers. Exact-address searches did not locate a reliable business/service attribution. Its onward history was not traced in this bounded pass.
4. The first later transaction converted **11 BNB into 3,398.645844082231 USDT** on 16 May 2023 ([receipt](https://bscscan.com/tx/0xcad217ad6766e48d3ada3297272b3b1f441067ffde02334468447fde0b1b3e60)). The output returned to the same wallet. This is a cryptoasset conversion, not evidence of a bank withdrawal or an identified exchange account.

## Exact direct outward totals

These exclude swap inputs, swap returns and network fees. They are gross transfers from a wallet with commingled activity.

| Recipient | Asset | Amount | Transfers |
|---|---|---:|---:|
| `0x1f88a9bc6301cefe4ac696d69d13a02eded5a62b` | BNB | 0.017368951262722757 | 1 |
| `0x35b119730f79881dac623dc51c831c6a04cab5f3` | BNB | 0.5 | 1 |
| `0x36048413c4edf0cf3e633aab317fcd9824dfb4d4` | BNB | 12 | 4 |
| `0x391a51d884b240908a88e1e757ec42189d294423` | BNB | 0.006936496375680644 | 1 |
| `0x78d09e1435e1906878621bcb0aaa9d47561214c3` | BNB | 0.5 | 1 |
| `0xba4d665059c97d6baa42e097707a504aecafbf53` | BUSD | 6590 | 1 |
| `0xba4d665059c97d6baa42e097707a504aecafbf53` | USDT | 25906.285983337104699148 | 3 |

## Commingling and interpretation limits

The previously selected incoming transfers from the private beneficiary total 5,411.003865738104347591 BUSD, 27.336801380291603498 BNB and 161,278.104499999999787008 GMI. Those are gross incoming totals. The newly recovered 12 BNB in the reverse direction means the 27.33680138 BNB figure cannot be described as net receipt or personal income. Even a difference of the two selected direction totals is only a net bilateral movement in this bounded record, not profit or proceeds attribution.

The wallet sold 161,278.104499999999787008 GMI on 7 October, a quantity equal to the selected September incoming transfer. It also sold 3,749,332.57 GMI and 905,913.02 GMI on 21 October and sent a much larger existing USDT balance onward. Its ledger includes BNB/USDT/BUSD conversions and a 0.02 BTCB conversion. This shows activity beyond the selected private-claim proceeds. Do not add the outward USDT/BUSD totals to previously reported GMI-sale income or label them investor losses.

This pass inventories all normal outgoing transactions in the specified nonce interval. It does not inventory every inbound transaction, every third-party ERC20 transfer using an allowance, all earlier history or all activity after nonce 73. It does not establish customer account records, order mappings, retained KYC, human key custody, Cayman bank ownership or a personal receipt by Laura.

## Swap-contract attribution

PancakeSwap router calls use the already established BSC router `0x10ed43c718714eb63d5aa57b78b54704e256024e`. Other verified conversions call `0x1a1ec25dc08e98e5e93f1104b5e5cdd298707d31` with the `swap(string,address,uint256,bytes)` selector and route through `0xc590175e458b83680867afd273527ff58f74c02b`. No primary BSC deployment attribution for that contract was established in this pass; it is described as a swap contract. Generic selector associations and same-address labels on other chains do not identify its BSC operator.

## Evidence files

- `material_transfer_ledger.json`: frozen 54-row exact transfer/fee ledger.
- `transaction_audit.json`: every nonce, receipt status and gas calculation.
- `counterparty_totals.json`: exact gross outward counterparty totals and transaction identifiers.
- `known_incoming.json`: selected prior verified receipts from the private beneficiary.
- `evidence_qa.json`: all nine verification checks and the frozen ledger SHA-256.
- `btcb_metadata_raw.json` and `btcb_metadata.json`: historical token metadata confirming BTCB and 18 decimals.
- `nonce_*.json`, `block_*.json`, `receipt_*.json`, `trace_*.json`: primary archive responses and source requests.

No provider requests, account access or transactions were sent.
