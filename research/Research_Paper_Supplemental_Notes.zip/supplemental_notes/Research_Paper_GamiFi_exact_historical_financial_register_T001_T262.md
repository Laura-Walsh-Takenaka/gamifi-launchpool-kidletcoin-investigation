# Research Paper — GamiFi exact historical financial register — T001–T262

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Preservation edition: 7 September 2026. The original 262-row register follows unchanged, including every quantity, movement label, date, transaction link and historical dollar display. These are the original 6 September valuation rows, not a new whole-project loss total. Later refund, token-delivery, treasury and control findings are in the corrected master and their separate raw evidence. No historical dollar mark has been invented for the new discoveries.

Original record labels such as “F4F” are preserved literally; the updated master explains that an address prefix does not identify FixedFloat.

## Appendix C — Complete dated financial register

The following 262 transfer and fee records reproduce the previously validated financial ledger across 172 transactions. This register preserves its original IDs and dollar marks; the newly verified May replenishments and later selected swaps are separately quantified in the integrated staking/onward sections and have not been added to this valuation workbook. Record IDs match the workbook. Each linked record points to its full transaction hash in the printed source register. A transaction may produce several rows; different rows are not necessarily separate payments or income. The recorded movement label distinguishes funding, claims, swaps, liquidity, forwarding, conversions and fees. Exact quantities are preserved as text. Dollar marks are rounded to cents only for presentation; small nonzero amounts may display 0.00.

The estimates use each row’s preserved historical price and CAD conversion rate. CAD is C$ and USD is US$. Rows describing actual swap output still show a cryptoasset receipt, not bank cash or profit. Funding and claim marks are marginal values, not proof of money invested. The full workbook and raw JSON retain counterparties, blocks, valuation methods and source-age details. No grand total is calculated.

### 2022-01

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T001](https://bscscan.com/tx/0xac39350f0f652c95dfb73e0cd8f2028a2c8aa34a51d081374a6c850647625787) | 2022-01-18 15:56:50 | Private funding | 120000000 GMI | 5,769,088.34 | 7,228,090.79 |



### 2022-02

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T002](https://bscscan.com/tx/0xdb0e3d669432d65c6b3d8870ffcae8be05339c8895b69cb3ab5cbf8fab9495f5) | 2022-02-01 11:27:09 | Private other forwarding GMI | 10000 GMI | 508.75 | 645.81 |



### 2022-03

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T003](https://bscscan.com/tx/0xac69cf1d77454ccaa2b5e3331d317d89d7a89891da4865203d5551af6f6cbf38) | 2022-03-10 13:15:25 | Private other forwarding GMI | 10000 GMI | 236.82 | 302.56 |
| [T004](https://bscscan.com/tx/0x4a04b6856eae8a2ace67eed1d3fdaa5d14d934dc420cdf2c4eed8658696dac89) | 2022-03-10 13:16:43 | Private other forwarding GMI | 10000 GMI | 236.68 | 302.38 |
| [T005](https://bscscan.com/tx/0x76153356f5ce09e4e6913a335f84444ed3b9d380151ebbdd7214990e14d0df93) | 2022-03-10 13:31:47 | Private other forwarding GMI | 10000 GMI | 235.73 | 301.17 |
| [T006](https://bscscan.com/tx/0xe7858302265b4e9d6ad3b4e1545e35452c0725b5960bfed3ed79cdad48393f94) | 2022-03-10 13:33:32 | Private other forwarding GMI | 10000 GMI | 236.74 | 302.46 |
| [T007](https://bscscan.com/tx/0x4b0b66e2f020479b6381a1b31be240bfb86347cf1813ddb520c094576e6158df) | 2022-03-10 15:25:05 | Project IDs 1, 3, 4 withdrawals | 252.5 BUSD | 252.51 | 322.61 |
| [T008](https://bscscan.com/tx/0x4389510604c93f928c4e1a2f6fda07979d792228de1b6bb66a8242a7a7ee05b5) | 2022-03-11 09:35:55 | Project IDs 1, 3, 4 withdrawals | 110 BUSD | 109.99 | 139.91 |
| [T009](https://bscscan.com/tx/0x2bb55dffcc3ae56b0b81a68b277d2318e27438e3bacbe79cb12d94f0162228bb) | 2022-03-11 10:10:10 | Private earlier other incoming GMI | 10000 GMI | 168.35 | 214.15 |
| [T010](https://bscscan.com/tx/0x43060bbf502f7ae2d1c1db8cbf4e5bcdaef9c1d16356855c26f9c48aaaa0deb3) | 2022-03-11 10:21:43 | Private other forwarding GMI | 10000 GMI | 237.93 | 302.64 |
| [T011](https://bscscan.com/tx/0xbe801f3b0e1fffdc58e884ad6359bf07ee93a0db6d5cc2c7a98a5d782fe2d39b) | 2022-03-11 10:22:10 | Private other forwarding GMI | 10000 GMI | 236.23 | 300.48 |
| [T012](https://bscscan.com/tx/0x9397957fd74ccd8680e56b5c8734c1917efec4c57611bf4a59fa8705b5ce6a62) | 2022-03-11 10:54:34 | Private other forwarding BUSD | 2000 BUSD | 1,999.85 | 2,543.81 |
| [T013](https://bscscan.com/tx/0xa68d28501388dd1939659be1a24f6fbed8c0c22d6df5bbe43196ff408b3ffba4) | 2022-03-18 06:58:39 | Project IDs 6–9 withdrawals | 23722.715761539594859905 BUSD | 23,730.18 | 29,940.37 |
| [T014](https://bscscan.com/tx/0x4e2b2cebb9895bb8ed1ffa817e730273d9271e97e559a2fdd7ba2d4e86fd5299) | 2022-03-18 12:23:52 | Project IDs 6–9 withdrawals | 28421.141280969119319259 BUSD | 28,430.09 | 35,870.24 |
| [T015](https://bscscan.com/tx/0x33f6c2ae7893cf8763b5306d4220780592390cc22ab9399034f4b3ac6ee09683) | 2022-03-23 14:58:07 | Project IDs 1, 3, 4 withdrawals | 2000 BUSD | 2,000.00 | 2,514.20 |



### 2022-04

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T016](https://bscscan.com/tx/0x00f1ad6f5d7560d5325d08d0afcf253a99b46d588a6509abb37349bacdea965f) | 2022-04-19 13:32:12 | Launchpool upstream funding | 15456876 GMI | 216,583.61 | 273,415.15 |
| [T017](https://bscscan.com/tx/0x020b2a285f0c7f1bc3560d814e2d6a13358d35ee2a96b8b70e36ce2f0b840ccc) | 2022-04-19 15:22:53 | Launchpool opening deposits | 10 GMI | 0.14 | 0.18 |
| [T018](https://bscscan.com/tx/0x19d1cd7e49be9a4226dec5323cc5bc8c36a6e465dceec4fb70fa3f598b019bfd) | 2022-04-19 16:19:46 | Launchpool upstream funding | 5 GMI | 0.07 | 0.09 |
| [T019](https://bscscan.com/tx/0x8a5f1c2ac6bd2a1f8ff17d16c55a64ac384401a27c15a1c1899c6c10d8e237bd) | 2022-04-19 16:30:49 | Launchpool opening deposits | 458882.5934562736916 GMI | 6,361.87 | 8,031.22 |
| [T020](https://bscscan.com/tx/0xec5e3fa4180a89f6732e45f9be8b32dca79a4216d2fae9930bf364f294e2bd1b) | 2022-04-19 16:33:22 | Launchpool opening deposits | 366206.751525064626544 GMI | 5,075.13 | 6,406.84 |
| [T021](https://bscscan.com/tx/0x562dd1aec6bf5e91ff8fe33a907ddb4b2241aa672ee78cc75c46703f0a65fa1b) | 2022-04-19 16:34:43 | Launchpool opening deposits | 399040.53056674101 GMI | 5,529.22 | 6,980.08 |
| [T022](https://bscscan.com/tx/0xe958fb6a25e98a3807872140d8b086a3dbc1585c4fb3944c6f7a32b223cfa6ac) | 2022-04-19 16:36:22 | Launchpool opening deposits | 431061.7431797660877 GMI | 5,966.81 | 7,532.50 |
| [T023](https://bscscan.com/tx/0x5deafdf0447762c763f4ccf7f2ef72fff0eae8324c4af63e383581ce9cca40b4) | 2022-04-19 16:37:49 | Launchpool opening deposits | 337679.1659489148667 GMI | 4,674.67 | 5,901.30 |
| [T024](https://bscscan.com/tx/0x0597d21f73149ed14eaeec5422d3d5c8cda0a4ff71a292d33b79d0fd22a63d6f) | 2022-04-19 16:45:43 | Launchpool opening deposits | 331852.47089813748657 GMI | 4,555.10 | 5,750.36 |
| [T025](https://bscscan.com/tx/0xbf5e4cd1e23a6bef69ab109a42db1c20fd691d2b9a10b994133eb917b655b815) | 2022-04-19 16:47:58 | Launchpool opening deposits | 422884.66330513148782 GMI | 5,800.52 | 7,322.57 |
| [T026](https://bscscan.com/tx/0x5003a6a10ff422d40fa8ebbc1da4e8cc04951ec4b4ab6fe8b848f13efd414153) | 2022-04-19 16:49:04 | Launchpool opening deposits | 440485.85623327138017 GMI | 6,032.35 | 7,615.24 |
| [T027](https://bscscan.com/tx/0x50096f1e9322f81becdefcabd01fb4aefe14828adea24a45479677b1f853c788) | 2022-04-19 16:50:01 | Launchpool opening deposits | 288370.530186758633149 GMI | 3,957.06 | 4,995.40 |
| [T028](https://bscscan.com/tx/0xc730eafea349c136d8481096b4b8dbcd8b941321d946902f539badce1e3bd6d3) | 2022-04-19 16:51:10 | Launchpool opening deposits | 366971.6169596438259 GMI | 5,040.94 | 6,363.68 |
| [T029](https://bscscan.com/tx/0xf75ad88be4981de907e21b4b8b581c33d5a901a2a6a677b6b90c9d83aa83b228) | 2022-04-19 16:52:19 | Launchpool opening deposits | 359343.3683790981212 GMI | 4,951.17 | 6,250.36 |
| [T030](https://bscscan.com/tx/0xbd4fb2f379c2df3eee2c3658a8524df022ad5aadc16beeb93c018ae5676e5392) | 2022-04-19 16:53:37 | Launchpool opening deposits | 467106.443623012504 GMI | 6,433.14 | 8,121.20 |
| [T031](https://bscscan.com/tx/0xbd73d66bb89f452a8a3c1d6140c94dc57ec7017567498075c3530027d4fa9f38) | 2022-04-19 16:54:46 | Launchpool opening deposits | 488810.7314096476405 GMI | 6,741.79 | 8,510.83 |
| [T032](https://bscscan.com/tx/0x1887a310642ec35743719a96f2445eb546ffd401bd4e9e7565c4af8b502a5270) | 2022-04-19 16:55:49 | Launchpool opening deposits | 351362.3394890581639 GMI | 4,847.16 | 6,119.05 |
| [T033](https://bscscan.com/tx/0xa201472810893101c69f1b7ade2481f45e44813a42bfbe7faa2590f1c086b220) | 2022-04-19 16:56:52 | Launchpool opening deposits | 475436.8914711969995 GMI | 6,561.03 | 8,282.64 |
| [T034](https://bscscan.com/tx/0x8e9aa15452d47cbc6ed13157576862a7b74764fdd62e83a91ecfb97b510de9ea) | 2022-04-19 16:58:07 | Launchpool opening deposits | 328253.0673729666334 GMI | 4,532.01 | 5,721.21 |
| [T035](https://bscscan.com/tx/0x726ced6b9b1ea1d8e428ec398939170227b1e541b61e96ab73c1a19bc2363918) | 2022-04-19 16:59:01 | Launchpool opening deposits | 462044.7790815043877 GMI | 6,379.06 | 8,052.93 |
| [T036](https://bscscan.com/tx/0xa2f21fbeb96907cf74bccb95b2bc1ab8afe61d092399fe639295c3493ed0ae1a) | 2022-04-19 17:01:03 | Launchpool opening deposits | 380556.4634824556 GMI | 5,251.12 | 6,629.01 |
| [T037](https://bscscan.com/tx/0xe2240aefad7458e88c5e9b7bee673a2d63f7da6357abd132c8b46c23b6051bf4) | 2022-04-19 17:02:13 | Launchpool opening deposits | 354062.4986037318471 GMI | 4,880.78 | 6,161.49 |
| [T038](https://bscscan.com/tx/0x562536343c53d937828952778e59a84c1c94aa5af64e4d835cc0166833b0fff7) | 2022-04-19 17:03:19 | Launchpool opening deposits | 313382.0204564856549 GMI | 4,320.30 | 5,453.95 |
| [T039](https://bscscan.com/tx/0x5d7b2b12b68c299e0bfeebe67c4f914c38012cbf05e1aed7eeb6fd80482a529a) | 2022-04-19 17:04:28 | Launchpool opening deposits | 423206.14632237570352 GMI | 5,834.89 | 7,365.96 |
| [T040](https://bscscan.com/tx/0xff8ecb91421dafc810f693e04a84070c647e24bc2de708e10a59ec70a252f0e9) | 2022-04-19 17:05:34 | Launchpool opening deposits | 600036.3532744481064 GMI | 8,285.31 | 10,459.37 |
| [T041](https://bscscan.com/tx/0xaa80839f43b1e2c86097a92d54ebb471bf8b21fdf784a727784fd44d9d2ad066) | 2022-04-19 17:06:40 | Launchpool opening deposits | 376066.6970278263361 GMI | 5,202.09 | 6,567.12 |
| [T042](https://bscscan.com/tx/0x860dfc74cfb742e1b566830957ac8a39fd2f37b9a1573471aace3e4e414923dd) | 2022-04-19 17:07:43 | Launchpool opening deposits | 384448.6221635328328 GMI | 5,310.32 | 6,703.74 |
| [T043](https://bscscan.com/tx/0xbe98c1a56f9871f7ae97661c0eeff12d77abbd081c3ab423a6f48c12ee4cdb27) | 2022-04-19 17:08:52 | Launchpool opening deposits | 334065.716964341933 GMI | 4,606.78 | 5,815.60 |
| [T044](https://bscscan.com/tx/0x2312dc5173bf5bc8f152429d4641e542f091e80f1176606d5f4e7940a43171be) | 2022-04-19 17:09:55 | Launchpool opening deposits | 456941.0960645956783 GMI | 6,305.92 | 7,960.60 |
| [T045](https://bscscan.com/tx/0x0c7feeabec050bd7535cc141521781dce9dab619884076353ebb014a67f52e03) | 2022-04-19 17:10:58 | Launchpool opening deposits | 344753.2558957723187 GMI | 4,758.40 | 6,007.00 |
| [T046](https://bscscan.com/tx/0xefa983fcfceee834a72f7a7d715ba2b4d6517e9ec868bf6bb44352366ea9ecda) | 2022-04-19 17:12:34 | Launchpool opening deposits | 366612.8574825958087 GMI | 5,066.94 | 6,396.51 |
| [T047](https://bscscan.com/tx/0xe107685528296c810cd89f7cacf1c334eec0492189a7fc06f55e4c11aa7b9a51) | 2022-04-19 17:13:26 | Launchpool opening deposits | 576981.3866025976568 GMI | 7,974.74 | 10,067.31 |
| [T048](https://bscscan.com/tx/0x854f39b52c34c65f6e2229ade8b2d6d26226fd20323d30703241de9b4c82dd38) | 2022-04-19 17:14:29 | Launchpool opening deposits | 887877.3822482400862 GMI | 12,255.13 | 15,470.87 |
| [T049](https://bscscan.com/tx/0x946453c1f648db21aba304fe83607cd69dd00b22bff1e7bad184412d648dc6c6) | 2022-04-19 17:15:29 | Launchpool opening deposits | 427533.4783261787806 GMI | 5,901.64 | 7,450.22 |
| [T050](https://bscscan.com/tx/0x9821a0b12221f6b1be9f613866defc03a06e69c066ffbeb73ed694633f25e470) | 2022-04-19 17:16:20 | Launchpool opening deposits | 338506.3138068201254 GMI | 4,676.59 | 5,903.73 |
| [T051](https://bscscan.com/tx/0x40d015a2111036e56a123c75f3c1f3c9bb6505198523ccda63e019a3094c9919) | 2022-04-19 17:17:05 | Launchpool opening deposits | 343255.5148194810067 GMI | 4,739.25 | 5,982.82 |
| [T052](https://bscscan.com/tx/0x73c9d8ee6420ca6829a47558aac11498609ff48ae3786cd4dc8c9b975956edf9) | 2022-04-19 17:17:56 | Launchpool opening deposits | 385926.1212208234816 GMI | 5,325.35 | 6,722.73 |
| [T053](https://bscscan.com/tx/0x57b63c0580e9790f77eb641af77311a0e97ef7c3c595bec5838c4336ebbd3681) | 2022-04-19 17:18:41 | Launchpool opening deposits | 313371.426638854702168 GMI | 4,320.77 | 5,454.54 |
| [T054](https://bscscan.com/tx/0x10d7d069e1bc086aecf1433a214b5e70cd1a5b00b7a18dd29b679bc8f54dbbce) | 2022-04-19 17:19:26 | Launchpool opening deposits | 251644.68620389297602 GMI | 3,472.83 | 4,384.10 |
| [T055](https://bscscan.com/tx/0xd2a860e052d77f847e7517eb640815e59ed6d47dc3aba84e431998d6ba2c2969) | 2022-04-19 17:20:11 | Launchpool opening deposits | 622655.997352392143475 GMI | 8,598.14 | 10,854.29 |
| [T056](https://bscscan.com/tx/0x0b44c3c63f6f4ce4ff369632449fd50a7e58162bc7f102dc8a3ed37703138618) | 2022-04-19 17:29:53 | Launchpool opening deposits | 199198.30486490008201 GMI | 2,748.21 | 3,469.35 |



### 2022-05

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T057](https://bscscan.com/tx/0xfb51cbbf265af6b604ba3499d1608f36ab04a57eb3a71a4d5cbe3c6fe807d780) | 2022-05-23 11:50:16 | Project IDs 6–9 withdrawals | 3775.228767123287671432 BUSD | 3,775.69 | 4,843.83 |



### 2022-06

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T058](https://bscscan.com/tx/0x757fe0ce1d898fff34b0d4c4f58f2fc7610d3821eacc51c43d7e7e6ac0edcf63) | 2022-06-22 08:29:58 | Project IDs 6–9 withdrawals | 4720.231567727363184247 BUSD | 4,720.69 | 6,109.52 |



### 2022-07

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T059](https://bscscan.com/tx/0x162b4219c7ae0867465cfd21a13244f888672d19f9296e9c8bdfbf4d3baeacfe) | 2022-07-12 16:05:10 | Private other forwarding GMI | 13150 GMI | 11.56 | 15.05 |



### 2022-09

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T060](https://bscscan.com/tx/0x684835fae6b574a45be696151087cf039b173ca68c73cea92368401c49208dbf) | 2022-09-23 05:00:12 | Private other forwarding GMI | 161278.104499999999787008 GMI | 65.65 | 89.08 |
| [T061](https://bscscan.com/tx/0xb72e828b1c3fb94394837de4d71b685dfe57e00fbb0f320f24c68f0b95993659) | 2022-09-23 05:01:18 | Private onward transfers BNB | 0.99657042 BNB | 275.83 | 374.29 |



### 2022-10

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T209](https://bscscan.com/tx/0xc48640d0a9169672220d5ead2b7bd1f8e538b0f079e55720fb55424790572bce) | 2022-10-07 16:24:19 | Onward swap inputs GMI | 161278.104499999999787008 GMI | 51.26 | 70.28 |
| [T210](https://bscscan.com/tx/0xc48640d0a9169672220d5ead2b7bd1f8e538b0f079e55720fb55424790572bce) | 2022-10-07 16:24:19 | Onward swap outputs BNB | 0.180520799210431341 BNB | 50.96 | 69.88 |
| [T211](https://bscscan.com/tx/0xc48640d0a9169672220d5ead2b7bd1f8e538b0f079e55720fb55424790572bce) | 2022-10-07 16:24:19 | Onward network fees BNB | 0.000779105 BNB | 0.22 | 0.30 |
| [T212](https://bscscan.com/tx/0x75cce83e042249dafb69f42a7f4aeeea96ace1773c073e7b5ba31b268606f2ff) | 2022-10-21 09:34:22 | Onward swap inputs GMI | 3749332.57 GMI | 709.19 | 972.51 |
| [T213](https://bscscan.com/tx/0x75cce83e042249dafb69f42a7f4aeeea96ace1773c073e7b5ba31b268606f2ff) | 2022-10-21 09:34:22 | Onward swap outputs BNB | 2.49884041770721016 BNB | 667.22 | 914.95 |
| [T214](https://bscscan.com/tx/0x75cce83e042249dafb69f42a7f4aeeea96ace1773c073e7b5ba31b268606f2ff) | 2022-10-21 09:34:22 | Onward network fees BNB | 0.000779165 BNB | 0.21 | 0.29 |
| [T215](https://bscscan.com/tx/0xc0ad1912342b01317d0a964a4abe670d5c371a160dc9d18d14d264de8d8bf51e) | 2022-10-21 10:45:19 | Onward network fees BNB | 0.00019509 BNB | 0.05 | 0.07 |
| [T216](https://bscscan.com/tx/0xd87f246c4060bc8afa087f398774c9cefc8a0a8d74b8b9aa175b005fe3cad84e) | 2022-10-21 10:45:55 | Onward swap inputs GMI | 905913.02 GMI | 155.00 | 212.56 |
| [T217](https://bscscan.com/tx/0xd87f246c4060bc8afa087f398774c9cefc8a0a8d74b8b9aa175b005fe3cad84e) | 2022-10-21 10:45:55 | Onward swap outputs USDT | 152.258665477104699148 USDT | 152.26 | 208.79 |
| [T218](https://bscscan.com/tx/0xd87f246c4060bc8afa087f398774c9cefc8a0a8d74b8b9aa175b005fe3cad84e) | 2022-10-21 10:45:55 | Onward network fees BNB | 0.000986045 BNB | 0.26 | 0.36 |
| [T219](https://bscscan.com/tx/0xc5a6fd46be61e3fb2805daf822ebd9fa8e3669517ec44f1f000beef817acf0cd) | 2022-10-21 10:56:43 | Onward wallet transfers USDT | 19436.285983337104699148 USDT | 19,436.29 | 26,652.98 |
| [T220](https://bscscan.com/tx/0xc5a6fd46be61e3fb2805daf822ebd9fa8e3669517ec44f1f000beef817acf0cd) | 2022-10-21 10:56:43 | Onward network fees BNB | 0.000180755 BNB | 0.05 | 0.07 |
| [T221](https://bscscan.com/tx/0x925415a01c808aef0c868b7cc91155caae6fd48a6b9b5a88585b07f569b5e707) | 2022-10-21 10:59:31 | Onward swap outputs USDT | 264.6190099022113 USDT | 264.62 | 362.87 |
| [T222](https://bscscan.com/tx/0x925415a01c808aef0c868b7cc91155caae6fd48a6b9b5a88585b07f569b5e707) | 2022-10-21 10:59:31 | Onward swap inputs BNB | 1 BNB | 266.90 | 366.00 |
| [T223](https://bscscan.com/tx/0x925415a01c808aef0c868b7cc91155caae6fd48a6b9b5a88585b07f569b5e707) | 2022-10-21 10:59:31 | Onward network fees BNB | 0.00104583 BNB | 0.28 | 0.38 |
| [T224](https://bscscan.com/tx/0xc0049ad7c17a1de264056335791f2f6527256e2ecd4c2cca594d4bed475f8ade) | 2022-10-21 11:00:21 | Onward wallet transfers USDT | 60 USDT | 60.00 | 82.28 |
| [T225](https://bscscan.com/tx/0xc0049ad7c17a1de264056335791f2f6527256e2ecd4c2cca594d4bed475f8ade) | 2022-10-21 11:00:21 | Onward network fees BNB | 0.000255575 BNB | 0.07 | 0.09 |



### 2022-11

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T226](https://bscscan.com/tx/0x1d511630993eefca8a67f6a63e189a6e25054f340e0d8867a00c6b5fb67cfbf3) | 2022-11-04 14:25:04 | Onward returns to private wallet BNB | 1 BNB | 356.08 | 481.31 |
| [T227](https://bscscan.com/tx/0x1d511630993eefca8a67f6a63e189a6e25054f340e0d8867a00c6b5fb67cfbf3) | 2022-11-04 14:25:04 | Onward network fees BNB | 0.000105 BNB | 0.04 | 0.05 |
| [T062](https://bscscan.com/tx/0x6f2c3e43f94de965feaf666ad8a35a6951c72a9367360d9dc138d236902e787f) | 2022-11-04 14:25:40 | Private vesting claims | 96645563.271604938271604938 GMI | 21,061.17 | 28,468.38 |
| [T063](https://bscscan.com/tx/0x77aa71b436f968ef2c7845806036702b6b72947c57134bac12155b7adab445c0) | 2022-11-04 14:36:59 | Private sale inputs | 4000000 GMI | 872.69 | 1,179.62 |
| [T064](https://bscscan.com/tx/0x77aa71b436f968ef2c7845806036702b6b72947c57134bac12155b7adab445c0) | 2022-11-04 14:36:59 | Private sale proceeds WBNB | 2.296091425541797281 WBNB | 820.80 | 1,109.48 |
| [T065](https://bscscan.com/tx/0x203abb1c9c7dae34461bf67e753898d0671bbf25e13d80051745dd19344a32a5) | 2022-11-04 14:49:05 | Private sale inputs | 5000000 GMI | 994.83 | 1,344.72 |
| [T066](https://bscscan.com/tx/0x203abb1c9c7dae34461bf67e753898d0671bbf25e13d80051745dd19344a32a5) | 2022-11-04 14:49:05 | Private sale proceeds BUSD | 922.244231334011558017 BUSD | 922.24 | 1,246.60 |
| [T067](https://bscscan.com/tx/0xb92ef6cc144fc776ecc32cce28108f8903be0b1c17c669a788697a89f0e77d38) | 2022-11-04 14:50:32 | Private unwrap input WBNB | 2.296091425541797281 WBNB | 819.88 | 1,108.23 |
| [T068](https://bscscan.com/tx/0xb92ef6cc144fc776ecc32cce28108f8903be0b1c17c669a788697a89f0e77d38) | 2022-11-04 14:50:32 | Private unwrap output BNB | 2.296091425541797281 BNB | 819.88 | 1,108.23 |
| [T069](https://bscscan.com/tx/0x8a23f55933f775a0d1636fa9c8a791048fafc78838d8e708749938dea98b50f6) | 2022-11-04 14:52:40 | Private sale inputs | 2500000 GMI | 456.62 | 617.22 |
| [T070](https://bscscan.com/tx/0x8a23f55933f775a0d1636fa9c8a791048fafc78838d8e708749938dea98b50f6) | 2022-11-04 14:52:40 | Private sale proceeds BUSD | 437.046205300729306686 BUSD | 437.05 | 590.76 |
| [T071](https://bscscan.com/tx/0x0758105d02766f3730218abbc695e7eb890cd128b3798cf795c49a1069be0e0b) | 2022-11-04 14:54:38 | Private sale inputs | 2000000 GMI | 356.03 | 481.25 |
| [T072](https://bscscan.com/tx/0x0758105d02766f3730218abbc695e7eb890cd128b3798cf795c49a1069be0e0b) | 2022-11-04 14:54:38 | Private sale proceeds BUSD | 344.591362752858876366 BUSD | 344.59 | 465.78 |
| [T073](https://bscscan.com/tx/0x39ec8dffbd77f61914a2d5b30810ba69805d7fc9aec2af7fa64e1083e43fbe5c) | 2022-11-04 14:59:14 | Private exchange intermediary | 5000000 GMI | 877.18 | 1,185.68 |
| [T074](https://bscscan.com/tx/0x7f8323049c6585d0dee94b8ba6b7dcb96d9bd0f2ac11617a00ca2299cb7ae3a8) | 2022-11-04 15:00:29 | Private MEXC 2e8 receipt | 5000000 GMI | 877.32 | 1,185.87 |
| [T075](https://bscscan.com/tx/0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48) | 2022-11-05 06:45:09 | Launchpool November outflow | 14000000 GMI | 2,675.88 | 3,616.99 |
| [T076](https://bscscan.com/tx/0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48) | 2022-11-05 06:45:09 | Other November outflows | 23000000 GMI | 4,396.09 | 5,942.19 |
| [T077](https://bscscan.com/tx/0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48) | 2022-11-05 06:45:09 | Other November outflows | 7000000 GMI | 1,337.94 | 1,808.49 |
| [T078](https://bscscan.com/tx/0xb954f172ba0faed75a15967fce0e72a52ee674fd585d9d1e5385199c72f82a17) | 2022-11-05 06:45:39 | November gas links | 0.019849782233850894 BNB | 7.14 | 9.65 |
| [T079](https://bscscan.com/tx/0x7096720b8dc95afac5ad1029a489ce8dd2b2dcb5ff78e960fcb5e10d03acd8aa) | 2022-11-05 06:51:21 | November sale input | 44000000 GMI | 8,410.14 | 11,367.99 |
| [T080](https://bscscan.com/tx/0x7096720b8dc95afac5ad1029a489ce8dd2b2dcb5ff78e960fcb5e10d03acd8aa) | 2022-11-05 06:51:21 | November sale proceeds | 5174.293394005109506048 BUSD | 5,174.14 | 6,993.89 |
| [T081](https://bscscan.com/tx/0x34bfa37b43fc0426e45ffcd3af9927be6495d4710f340f7f80e09d2fc41fe1b4) | 2022-11-05 07:15:11 | November stablecoin forward | 5174 BUSD | 5,173.90 | 6,993.56 |
| [T082](https://bscscan.com/tx/0xfce9f602e9b578c45f056eaa29343e0932d46f796d3fcb9a9b2dc326e1367a7a) | 2022-11-05 07:15:20 | November gas links | 0.00084 BNB | 0.30 | 0.41 |
| [T083](https://bscscan.com/tx/0x7702b5e67906c5eb1dea5d1fdde0f7ade3e37cb5cd657944bd539ed460791e48) | 2022-11-05 07:15:32 | November service sweep | 5174 BUSD | 5,173.90 | 6,993.56 |
| [T084](https://bscscan.com/tx/0xfc4c26165b9fad6ae7aa5c69b0763f4bed1af11f97ecebb9112793ca121303c4) | 2022-11-05 07:15:41 | November gas links | 0.000502984 BNB | 0.18 | 0.24 |
| [T085](https://bscscan.com/tx/0x28335e5207a836dd8525191ff58c0b72331cff4d7e86f74c10eafd51dd4abc53) | 2022-11-06 12:45:06 | Private onward transfers BNB | 2 BNB | 702.72 | 949.87 |
| [T086](https://bscscan.com/tx/0x39658c447c0db971adf6459ea117ee8f656a3896d6a05de599b7bc8f0836de2a) | 2022-11-06 12:46:39 | Private BUSD forwarded to F4F | 1703.881799387599741069 BUSD | 1,704.14 | 2,303.48 |
| [T228](https://bscscan.com/tx/0x863e6939cdd3ba2bea57965a24a8a378960c4234406aa1dc63f1e1a3a5b896eb) | 2022-11-06 13:03:57 | Onward network fees BNB | 0.00022203 BNB | 0.08 | 0.11 |
| [T229](https://bscscan.com/tx/0x2330c9eb0faac11ab9e7fae7d82ec57606bfc71235c92f3d8c6d83e2c278d4bb) | 2022-11-06 13:03:57 | Onward swap inputs USDT | 204.6190099022113 USDT | 204.62 | 276.58 |
| [T230](https://bscscan.com/tx/0x2330c9eb0faac11ab9e7fae7d82ec57606bfc71235c92f3d8c6d83e2c278d4bb) | 2022-11-06 13:03:57 | Onward swap outputs BUSD | 203.007300309815295969 BUSD | 203.01 | 274.40 |
| [T231](https://bscscan.com/tx/0x2330c9eb0faac11ab9e7fae7d82ec57606bfc71235c92f3d8c6d83e2c278d4bb) | 2022-11-06 13:03:57 | Onward network fees BNB | 0.000976515 BNB | 0.34 | 0.46 |
| [T232](https://bscscan.com/tx/0x7c279e673b98372f0f6678500f17906b90d70cb7499b7822faba127eae7955df) | 2022-11-06 13:24:00 | Onward returns to private wallet BNB | 3 BNB | 1,056.33 | 1,427.84 |
| [T233](https://bscscan.com/tx/0x7c279e673b98372f0f6678500f17906b90d70cb7499b7822faba127eae7955df) | 2022-11-06 13:24:00 | Onward network fees BNB | 0.000105 BNB | 0.04 | 0.05 |
| [T087](https://bscscan.com/tx/0x1b6fb13de5737263b76277e7a24d22fd0b9a50fac9fc6931adb1c788ff1ffff9) | 2022-11-06 13:25:15 | Private liquidity add refund BNB | 1E-18 BNB | 0.00 | 0.00 |
| [T088](https://bscscan.com/tx/0x1b6fb13de5737263b76277e7a24d22fd0b9a50fac9fc6931adb1c788ff1ffff9) | 2022-11-06 13:25:15 | Private liquidity deposits BNB | 4.279827980541797281 BNB | 1,506.01 | 2,035.67 |
| [T089](https://bscscan.com/tx/0x1b6fb13de5737263b76277e7a24d22fd0b9a50fac9fc6931adb1c788ff1ffff9) | 2022-11-06 13:25:15 | Private liquidity deposits GMI | 10139294.126745140146790894 GMI | 1,506.01 | 2,035.67 |
| [T090](https://bscscan.com/tx/0x1b6fb13de5737263b76277e7a24d22fd0b9a50fac9fc6931adb1c788ff1ffff9) | 2022-11-06 13:25:15 | Private LP token receipts | 3332.459542883160311442 GMI-WBNB LP | 3,012.02 | 4,071.35 |
| [T234](https://bscscan.com/tx/0x2545cd928d92ca3a529f60d5e49479df9cc513ddce418aa39a9a0f81c0577c32) | 2022-11-06 13:29:30 | Onward returns to private wallet BNB | 5 BNB | 1,758.92 | 2,377.54 |
| [T235](https://bscscan.com/tx/0x2545cd928d92ca3a529f60d5e49479df9cc513ddce418aa39a9a0f81c0577c32) | 2022-11-06 13:29:30 | Onward network fees BNB | 0.000105 BNB | 0.04 | 0.05 |
| [T091](https://bscscan.com/tx/0x1448d738413857636ad78ff20f2eaa56c16fbf4800365b8e41f66e3bbe645a12) | 2022-11-06 13:30:48 | Private liquidity add refund BNB | 1E-18 BNB | 0.00 | 0.00 |
| [T092](https://bscscan.com/tx/0x1448d738413857636ad78ff20f2eaa56c16fbf4800365b8e41f66e3bbe645a12) | 2022-11-06 13:30:48 | Private liquidity deposits BNB | 4.5 BNB | 1,582.99 | 2,139.72 |
| [T093](https://bscscan.com/tx/0x1448d738413857636ad78ff20f2eaa56c16fbf4800365b8e41f66e3bbe645a12) | 2022-11-06 13:30:48 | Private liquidity deposits GMI | 10660901.274022018833217282 GMI | 1,582.99 | 2,139.72 |
| [T094](https://bscscan.com/tx/0x1448d738413857636ad78ff20f2eaa56c16fbf4800365b8e41f66e3bbe645a12) | 2022-11-06 13:30:48 | Private LP token receipts | 3503.895018947892528962 GMI-WBNB LP | 3,165.97 | 4,279.44 |
| [T236](https://bscscan.com/tx/0x1cf09021110c397c5262eb25a56c5d4a5478d738d3300038608dcb07adaa4f36) | 2022-11-07 07:41:45 | Onward returns to private wallet BNB | 3 BNB | 1,001.89 | 1,351.85 |
| [T237](https://bscscan.com/tx/0x1cf09021110c397c5262eb25a56c5d4a5478d738d3300038608dcb07adaa4f36) | 2022-11-07 07:41:45 | Onward network fees BNB | 0.000105 BNB | 0.04 | 0.05 |
| [T095](https://bscscan.com/tx/0x7c7a2fe044b574e5f8fd8e4eb585eeb094aa04ae2956d766c1463a2972962c93) | 2022-11-07 07:43:21 | Private liquidity add refund BNB | 1E-18 BNB | 0.00 | 0.00 |
| [T096](https://bscscan.com/tx/0x7c7a2fe044b574e5f8fd8e4eb585eeb094aa04ae2956d766c1463a2972962c93) | 2022-11-07 07:43:21 | Private liquidity deposits BNB | 3 BNB | 998.49 | 1,347.26 |
| [T097](https://bscscan.com/tx/0x7c7a2fe044b574e5f8fd8e4eb585eeb094aa04ae2956d766c1463a2972962c93) | 2022-11-07 07:43:21 | Private liquidity deposits GMI | 7141984.538727124246904764 GMI | 998.49 | 1,347.26 |
| [T098](https://bscscan.com/tx/0x7c7a2fe044b574e5f8fd8e4eb585eeb094aa04ae2956d766c1463a2972962c93) | 2022-11-07 07:43:21 | Private LP token receipts | 2341.536789416864249776 GMI-WBNB LP | 1,997.02 | 2,694.57 |
| [T238](https://bscscan.com/tx/0xdcd15c3761db237bf135a6733531ccbf8293f7c96197ea782c1cecb3d1822f72) | 2022-11-07 13:07:05 | Onward wallet transfers BNB | 0.5 BNB | 166.41 | 224.54 |
| [T239](https://bscscan.com/tx/0xdcd15c3761db237bf135a6733531ccbf8293f7c96197ea782c1cecb3d1822f72) | 2022-11-07 13:07:05 | Onward network fees BNB | 0.000105 BNB | 0.03 | 0.05 |
| [T240](https://bscscan.com/tx/0x2640f592d8b45f512e121a014b7de6b7293aaf8b06785bd388e66d9c13195520) | 2022-11-07 14:00:56 | Onward wallet transfers BNB | 0.5 BNB | 164.35 | 221.75 |
| [T241](https://bscscan.com/tx/0x2640f592d8b45f512e121a014b7de6b7293aaf8b06785bd388e66d9c13195520) | 2022-11-07 14:00:56 | Onward network fees BNB | 0.000105 BNB | 0.03 | 0.05 |
| [T099](https://bscscan.com/tx/0x90914bb510876debff2d9828706728765298905864d4450899c2372070283e89) | 2022-11-08 16:39:58 | Private liquidity returns BNB | 8.541343261253548134 BNB | 3,297.90 | 4,432.70 |
| [T100](https://bscscan.com/tx/0x90914bb510876debff2d9828706728765298905864d4450899c2372070283e89) | 2022-11-08 16:39:58 | Private LP tokens redeemed | 6883.418513435937817635 GMI-WBNB LP | 6,595.86 | 8,865.50 |
| [T101](https://bscscan.com/tx/0x90914bb510876debff2d9828706728765298905864d4450899c2372070283e89) | 2022-11-08 16:39:58 | Private liquidity returns GMI | 21680338.642683044091222143 GMI | 3,297.90 | 4,432.70 |
| [T102](https://bscscan.com/tx/0x88f61323abec9c4f7826fd90dad8d689f9461453c9906b0505923fcccd9affab) | 2022-11-08 16:40:47 | Private onward transfers BNB | 8 BNB | 3,088.88 | 4,151.76 |
| [T103](https://bscscan.com/tx/0xbb5706368c31e17c4fc0ec8b2faa93d57b707f6409c8ff217745856cc12a0f15) | 2022-11-08 16:42:56 | Private sale proceeds BNB | 0.387178971398081498 BNB | 150.47 | 202.25 |
| [T104](https://bscscan.com/tx/0xbb5706368c31e17c4fc0ec8b2faa93d57b707f6409c8ff217745856cc12a0f15) | 2022-11-08 16:42:56 | Private sale inputs | 1000000 GMI | 153.11 | 205.80 |
| [T105](https://bscscan.com/tx/0x4209ed260e5cb23946f75508fd2268bae46592f6224be8a310e44a4f58332fff) | 2022-11-08 16:44:00 | Private sale proceeds BNB | 0.378741246023242597 BNB | 147.88 | 198.76 |
| [T106](https://bscscan.com/tx/0x4209ed260e5cb23946f75508fd2268bae46592f6224be8a310e44a4f58332fff) | 2022-11-08 16:44:00 | Private sale inputs | 1000000 GMI | 149.88 | 201.45 |
| [T107](https://bscscan.com/tx/0x0220a34ba2222424e1a629ad6d9556f49de785400cace7942d4e35f7035f896a) | 2022-11-08 16:44:39 | Private sale proceeds BNB | 0.370576480579112181 BNB | 144.69 | 194.48 |
| [T108](https://bscscan.com/tx/0x0220a34ba2222424e1a629ad6d9556f49de785400cace7942d4e35f7035f896a) | 2022-11-08 16:44:39 | Private sale inputs | 1000000 GMI | 146.63 | 197.09 |
| [T109](https://bscscan.com/tx/0x3621e3c7b22846d2aea07991b80dcf5319160c46fb956c7cbbee56ec397b606f) | 2022-11-08 16:45:24 | Private sale proceeds BNB | 0.36267302469444156 BNB | 141.60 | 190.33 |
| [T110](https://bscscan.com/tx/0x3621e3c7b22846d2aea07991b80dcf5319160c46fb956c7cbbee56ec397b606f) | 2022-11-08 16:45:24 | Private sale inputs | 1000000 GMI | 143.49 | 192.86 |
| [T111](https://bscscan.com/tx/0x1f53047d22a56829dd1dd1f28ece71a5b7cae2c51492638e717eb7e2bfafd2c8) | 2022-11-08 16:46:18 | Private sale proceeds BNB | 0.355019843079312016 BNB | 137.66 | 185.04 |
| [T112](https://bscscan.com/tx/0x1f53047d22a56829dd1dd1f28ece71a5b7cae2c51492638e717eb7e2bfafd2c8) | 2022-11-08 16:46:18 | Private sale inputs | 1000000 GMI | 139.48 | 187.47 |
| [T113](https://bscscan.com/tx/0xdf15793fb1dfa7b3fce6ea540247630b85a3cadc5b24b420fdd94fc1c8b6a503) | 2022-11-08 16:47:04 | Private sale proceeds BNB | 0.174714172829105952 BNB | 67.64 | 90.91 |
| [T114](https://bscscan.com/tx/0xdf15793fb1dfa7b3fce6ea540247630b85a3cadc5b24b420fdd94fc1c8b6a503) | 2022-11-08 16:47:04 | Private sale inputs | 500000 GMI | 68.17 | 91.62 |
| [T115](https://bscscan.com/tx/0x614a22269124783eccee13db957b20c3f73312d8e4f22f73219c8f4595f17152) | 2022-11-08 16:47:46 | Private sale proceeds BNB | 0.234148918907064907 BNB | 90.65 | 121.84 |
| [T116](https://bscscan.com/tx/0x614a22269124783eccee13db957b20c3f73312d8e4f22f73219c8f4595f17152) | 2022-11-08 16:47:46 | Private sale inputs | 700000 GMI | 91.53 | 123.03 |
| [T117](https://bscscan.com/tx/0x586d19812d910a6a820c55aed37068ea4d1242eaf92ad6a30a5126ef92e4347b) | 2022-11-08 16:48:34 | Private sale proceeds BNB | 2.455484842171770585 BNB | 945.00 | 1,270.18 |
| [T118](https://bscscan.com/tx/0x586d19812d910a6a820c55aed37068ea4d1242eaf92ad6a30a5126ef92e4347b) | 2022-11-08 16:48:34 | Private sale inputs | 8000000 GMI | 1,025.02 | 1,377.73 |
| [T119](https://bscscan.com/tx/0x1d5dcc48c015a4a9c1cfffdd19f562c28b13d2ea862964db98bf9329223b6e2a) | 2022-11-08 16:49:34 | Private onward transfers BNB | 5 BNB | 1,924.27 | 2,586.41 |
| [T242](https://bscscan.com/tx/0x02fdf877c4901524ace8f5967a5422058d6b00d7fa6d56435de8ffbd5f6cdd1e) | 2022-11-08 17:18:38 | Onward swap outputs USDT | 4832.548709830717364662 USDT | 4,832.89 | 6,495.89 |
| [T243](https://bscscan.com/tx/0x02fdf877c4901524ace8f5967a5422058d6b00d7fa6d56435de8ffbd5f6cdd1e) | 2022-11-08 17:18:38 | Onward swap inputs BNB | 13 BNB | 4,884.04 | 6,564.64 |
| [T244](https://bscscan.com/tx/0x02fdf877c4901524ace8f5967a5422058d6b00d7fa6d56435de8ffbd5f6cdd1e) | 2022-11-08 17:18:38 | Onward network fees BNB | 0.002130935 BNB | 0.80 | 1.08 |
| [T120](https://bscscan.com/tx/0x17b757eede0f625d11d0306746682a4a32a1eaa00e1de64e8250c08b7e07f8f2) | 2022-11-08 17:45:18 | Private exchange intermediary | 5000000 GMI | 577.15 | 775.75 |
| [T121](https://bscscan.com/tx/0xb0b3bf6768b4cb92820c90c4aca9a2103e3b49c753b31bf6258916b3dab5855c) | 2022-11-08 17:48:21 | Private MEXC 2e8 receipt | 5000000 GMI | 576.08 | 774.31 |
| [T122](https://bscscan.com/tx/0xf12713c4fc0ab16c4ebeb52a5b195f62ba828ed1f484c1c2dc4b610192fdb5d3) | 2022-11-11 05:09:12 | Private sale inputs | 500000 GMI | 49.38 | 66.06 |
| [T123](https://bscscan.com/tx/0xf12713c4fc0ab16c4ebeb52a5b195f62ba828ed1f484c1c2dc4b610192fdb5d3) | 2022-11-11 05:09:12 | Private sale proceeds BUSD | 48.735073973554895612 BUSD | 48.79 | 65.28 |
| [T124](https://bscscan.com/tx/0x8787922cbe10a5e97d96e00db948bc4d98990fc90e4d15f7ba942fbd42b376b6) | 2022-11-11 05:09:39 | Private sale inputs | 550000 GMI | 53.72 | 71.87 |
| [T125](https://bscscan.com/tx/0x8787922cbe10a5e97d96e00db948bc4d98990fc90e4d15f7ba942fbd42b376b6) | 2022-11-11 05:09:39 | Private sale proceeds BUSD | 53.033274887508283565 BUSD | 53.10 | 71.03 |
| [T126](https://bscscan.com/tx/0x4c628980278e22d7747cbf7a573ae0bded7a90afc8f9594aab800c3babfd37a5) | 2022-11-11 05:31:52 | Private liquidity returns BNB | 2.607943974720827936 BNB | 768.37 | 1,027.93 |
| [T127](https://bscscan.com/tx/0x4c628980278e22d7747cbf7a573ae0bded7a90afc8f9594aab800c3babfd37a5) | 2022-11-11 05:31:52 | Private LP tokens redeemed | 2294.472837811979272545 GMI-WBNB LP | 1,536.81 | 2,055.94 |
| [T128](https://bscscan.com/tx/0x4c628980278e22d7747cbf7a573ae0bded7a90afc8f9594aab800c3babfd37a5) | 2022-11-11 05:31:52 | Private liquidity returns GMI | 7894389.253220628318984269 GMI | 768.37 | 1,027.93 |
| [T129](https://bscscan.com/tx/0x9f459055deac9f568871f6cd92077f03673958ab46184ef4dd8bacf911b92164) | 2022-11-11 05:33:28 | Private sale inputs | 1400000 GMI | 136.46 | 182.55 |
| [T130](https://bscscan.com/tx/0x9f459055deac9f568871f6cd92077f03673958ab46184ef4dd8bacf911b92164) | 2022-11-11 05:33:28 | Private sale proceeds BUSD | 133.365544435419768283 BUSD | 133.57 | 178.69 |
| [T131](https://bscscan.com/tx/0x0361272c59d8be9106aa8b64385d5366cd8579da22d3764281c01ed214e3b6f5) | 2022-11-11 05:37:47 | Private sale inputs | 100000 GMI | 9.47 | 12.67 |
| [T132](https://bscscan.com/tx/0x0361272c59d8be9106aa8b64385d5366cd8579da22d3764281c01ed214e3b6f5) | 2022-11-11 05:37:47 | Private sale proceeds BUSD | 9.38247695344865642 BUSD | 9.40 | 12.57 |
| [T133](https://bscscan.com/tx/0x3eb4a557e3cc88acc7e64dd9f66a4df9a383c106f999f5dbe19975432bcf8494) | 2022-11-19 09:48:03 | Private BUSD forwarded to F4F | 244.51637024993160388 BUSD | 244.53 | 327.31 |
| [T134](https://bscscan.com/tx/0x40871b477df601e7681470deaca31d58be0a4e2b1656f9f385c2268555074d9f) | 2022-11-19 09:51:51 | Private sale proceeds BNB | 4.285289686843634647 BNB | 1,159.42 | 1,551.88 |
| [T135](https://bscscan.com/tx/0x40871b477df601e7681470deaca31d58be0a4e2b1656f9f385c2268555074d9f) | 2022-11-19 09:51:51 | Private sale inputs | 14507027.807003581863724602 GMI | 1,354.37 | 1,812.83 |
| [T136](https://bscscan.com/tx/0xf9982e1d1a5043c22b7fbc3e7c0c005f40f18aa382c4004a21c0f35e3598af46) | 2022-11-19 09:53:15 | Private sale proceeds BNB | 0.390147523191066866 BNB | 105.54 | 141.27 |
| [T137](https://bscscan.com/tx/0xf9982e1d1a5043c22b7fbc3e7c0c005f40f18aa382c4004a21c0f35e3598af46) | 2022-11-19 09:53:15 | Private sale inputs | 1400000 GMI | 107.34 | 143.67 |
| [T138](https://bscscan.com/tx/0x5c12f503cfa66df55253faafb3d0c81972ca744ecfac296103b857a1607c256b) | 2022-11-19 09:54:06 | Private sale proceeds BNB | 0.691741985944504144 BNB | 187.07 | 250.40 |
| [T139](https://bscscan.com/tx/0x5c12f503cfa66df55253faafb3d0c81972ca744ecfac296103b857a1607c256b) | 2022-11-19 09:54:06 | Private sale inputs | 2500000 GMI | 192.39 | 257.51 |
| [T140](https://bscscan.com/tx/0x617019de109e31af87c9b84bf0f6c922693eee86f7db2598e252f49dd4cd8270) | 2022-11-19 09:58:45 | Private sale proceeds BNB | 0.388267052123310526 BNB | 105.03 | 140.58 |
| [T141](https://bscscan.com/tx/0x617019de109e31af87c9b84bf0f6c922693eee86f7db2598e252f49dd4cd8270) | 2022-11-19 09:58:45 | Private sale inputs | 1400000 GMI | 106.81 | 142.97 |
| [T142](https://bscscan.com/tx/0xf3fd8ec2971cfb10f8ddd36e5a1129d8a3770dfdcbf77efeeab9cf9ac7974b6b) | 2022-11-21 07:44:29 | Private sale proceeds BNB | 0.582129543392115814 BNB | 150.45 | 202.39 |
| [T143](https://bscscan.com/tx/0xf3fd8ec2971cfb10f8ddd36e5a1129d8a3770dfdcbf77efeeab9cf9ac7974b6b) | 2022-11-21 07:44:29 | Private sale inputs | 2000000 GMI | 154.02 | 207.19 |
| [T144](https://bscscan.com/tx/0xd26e3e5d5e5e3c8375e72b16196857d66e9b84c74bb5ebfeeca7ea3356926d7b) | 2022-11-21 07:44:59 | Private sale proceeds BNB | 1.094736394511955932 BNB | 282.93 | 380.60 |
| [T145](https://bscscan.com/tx/0xd26e3e5d5e5e3c8375e72b16196857d66e9b84c74bb5ebfeeca7ea3356926d7b) | 2022-11-21 07:44:59 | Private sale inputs | 4000000 GMI | 295.39 | 397.36 |
| [T146](https://bscscan.com/tx/0xc21c3c3ee62057ebe5f0bebbac78f48d7c16d24c81620f1461525c2005f95a19) | 2022-11-21 07:48:41 | Private sale inputs | 4000000 GMI | 275.63 | 370.78 |
| [T147](https://bscscan.com/tx/0xc21c3c3ee62057ebe5f0bebbac78f48d7c16d24c81620f1461525c2005f95a19) | 2022-11-21 07:48:41 | Private sale proceeds BUSD | 263.867721787667042029 BUSD | 263.99 | 355.12 |
| [T148](https://bscscan.com/tx/0xbb03bd0e65bb67fead14f138687283a1c167133570962c92f9614b0eef21df9b) | 2022-11-24 00:36:33 | Private BUSD forwarded to F4F | 263.867721787667042029 BUSD | 263.89 | 351.98 |
| [T149](https://bscscan.com/tx/0x5859779a769835115a1a080ad0c95721a81bcbc42365c98f584a57422caca8c1) | 2022-11-24 00:38:21 | Private sale inputs | 4000000 GMI | 336.87 | 449.32 |
| [T150](https://bscscan.com/tx/0x5859779a769835115a1a080ad0c95721a81bcbc42365c98f584a57422caca8c1) | 2022-11-24 00:38:21 | Private sale proceeds BUSD | 320.59479636055620389 BUSD | 320.63 | 427.65 |
| [T151](https://bscscan.com/tx/0x2c0841746c441de727842824780b6e09247f6fd6b49945cbe6a4e134615c5664) | 2022-11-24 00:39:00 | Private sale inputs | 950000 GMI | 73.37 | 97.86 |
| [T152](https://bscscan.com/tx/0x2c0841746c441de727842824780b6e09247f6fd6b49945cbe6a4e134615c5664) | 2022-11-24 00:39:00 | Private sale proceeds BUSD | 72.433061733286341383 BUSD | 72.44 | 96.62 |
| [T153](https://bscscan.com/tx/0x81a87dc87a1b3d6fc76b6c21d3b7290b0daa0a15a714015401631bee2ee8fbe4) | 2022-11-24 00:40:24 | Private sale inputs | 800000 GMI | 60.58 | 80.80 |
| [T154](https://bscscan.com/tx/0x81a87dc87a1b3d6fc76b6c21d3b7290b0daa0a15a714015401631bee2ee8fbe4) | 2022-11-24 00:40:24 | Private sale proceeds BUSD | 59.925453072850792848 BUSD | 59.93 | 79.94 |
| [T155](https://bscscan.com/tx/0x677dc2036fbb3fc31181eaefd5a9329e7dee8af63cc26ba341f03316b99a60e2) | 2022-11-24 00:41:06 | Private sale inputs | 650000 GMI | 48.46 | 64.64 |
| [T156](https://bscscan.com/tx/0x677dc2036fbb3fc31181eaefd5a9329e7dee8af63cc26ba341f03316b99a60e2) | 2022-11-24 00:41:06 | Private sale proceeds BUSD | 48.006999573725546959 BUSD | 48.01 | 64.04 |
| [T157](https://bscscan.com/tx/0x48f746263d74036dc34eba31e3bb83c45a64b4793fabe1e0188977b79c674074) | 2022-11-24 00:45:06 | Private BUSD forwarded to F4F | 500.96031074041888508 BUSD | 501.01 | 668.25 |
| [T158](https://bscscan.com/tx/0x7d8d9e6e8a7d9111c2f6bab0463afca7297e04aedc80a9f7ce31a2eef2d18cf7) | 2022-11-24 12:29:54 | Private sale inputs | 5000000 GMI | 397.98 | 530.83 |
| [T159](https://bscscan.com/tx/0x7d8d9e6e8a7d9111c2f6bab0463afca7297e04aedc80a9f7ce31a2eef2d18cf7) | 2022-11-24 12:29:54 | Private sale proceeds BUSD | 376.431633899894859871 BUSD | 376.48 | 502.15 |
| [T160](https://bscscan.com/tx/0x19b579dfe3278ba3ae20519200db7d1d910aa34191796ca59bc8c3cd07205066) | 2022-11-24 12:30:30 | Private BUSD forwarded to F4F | 376.431633899894859871 BUSD | 376.48 | 502.15 |
| [T161](https://bscscan.com/tx/0xb735822a5692dbbc3b9384993ba43cecd70ccc0e41b4755115ab12cfd0c35c61) | 2022-11-24 13:37:22 | Private sale inputs | 4205270.855252686397793452 GMI | 303.67 | 405.04 |
| [T162](https://bscscan.com/tx/0xb735822a5692dbbc3b9384993ba43cecd70ccc0e41b4755115ab12cfd0c35c61) | 2022-11-24 13:37:22 | Private sale proceeds BUSD | 290.463375480966450319 BUSD | 290.52 | 387.50 |
| [T163](https://bscscan.com/tx/0xc92cbef1aec7fd7153f85438f9f9b83b474b595abd51ab17a5bcef76aa2ee9ac) | 2022-11-24 13:38:28 | Private BUSD forwarded to F4F | 290.463375480966450319 BUSD | 290.52 | 387.50 |
| [T164](https://bscscan.com/tx/0xe3760121eaf73afc1d7762708678d9c723c321c4619cb1ff9a234a592b34ae0e) | 2022-11-24 13:40:16 | Private onward transfers BNB | 10 BNB | 2,980.40 | 3,975.26 |
| [T165](https://bscscan.com/tx/0x74c85c4ac133a120803d33610e6b74919252d5cbb5bd2d5e3ebdd80f68e85c6d) | 2022-11-24 23:07:41 | Private sale inputs | 3000000 GMI | 256.04 | 341.51 |
| [T166](https://bscscan.com/tx/0x74c85c4ac133a120803d33610e6b74919252d5cbb5bd2d5e3ebdd80f68e85c6d) | 2022-11-24 23:07:41 | Private sale proceeds BUSD | 247.652902915704154859 BUSD | 247.70 | 330.38 |
| [T167](https://bscscan.com/tx/0x2e34e8eaeca76264c88b3b8308157dfb94fc502a9ad13e76f94056a1bb909464) | 2022-11-24 23:08:08 | Private sale inputs | 2403953.141439514798345089 GMI | 193.02 | 257.45 |
| [T168](https://bscscan.com/tx/0x2e34e8eaeca76264c88b3b8308157dfb94fc502a9ad13e76f94056a1bb909464) | 2022-11-24 23:08:08 | Private sale proceeds BUSD | 187.949896569802101382 BUSD | 187.99 | 250.74 |



### 2022-12

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T169](https://bscscan.com/tx/0xe25596e34da89e1849546c452b5cb0be0bb6311e70a0a3b1f4e88779bbba936d) | 2022-12-01 07:39:37 | Private sale inputs | 1802964.856079636098758816 GMI | 155.66 | 209.09 |
| [T170](https://bscscan.com/tx/0xe25596e34da89e1849546c452b5cb0be0bb6311e70a0a3b1f4e88779bbba936d) | 2022-12-01 07:39:37 | Private sale proceeds BUSD | 152.291393923795278613 BUSD | 152.34 | 204.64 |
| [T171](https://bscscan.com/tx/0x0a1ece8d035e4618ea259b496a47504479800c3a4d5de45b3104551d2fb03df2) | 2022-12-01 07:40:16 | Private sale inputs | 2704447.284119454148138225 GMI | 225.00 | 302.24 |
| [T172](https://bscscan.com/tx/0x0a1ece8d035e4618ea259b496a47504479800c3a4d5de45b3104551d2fb03df2) | 2022-12-01 07:40:16 | Private sale proceeds BUSD | 218.180807448917693151 BUSD | 218.25 | 293.18 |
| [T173](https://bscscan.com/tx/0x4ba5c45e430bd415b2ea6b65ea28dc49019ea17ebf730c01d5ae2a0e1f9960aa) | 2022-12-01 08:32:39 | Private BUSD forwarded to F4F | 806.075000858219228005 BUSD | 806.08 | 1,082.80 |
| [T174](https://bscscan.com/tx/0x6c9b3728929c1cf686050facd603529eb903aa7117ea2d263df1a50b0e9fe960) | 2022-12-06 10:10:03 | Private sale inputs | 2704447.284119454148138226 GMI | 209.31 | 285.69 |
| [T175](https://bscscan.com/tx/0x6c9b3728929c1cf686050facd603529eb903aa7117ea2d263df1a50b0e9fe960) | 2022-12-06 10:10:03 | Private sale proceeds BUSD | 194.26331405038374757 BUSD | 194.24 | 265.12 |
| [T176](https://bscscan.com/tx/0x3fc4164a2c9e64085fcd617ef88e3d1d53f0b0bde6ad643ee162ccddfe48724f) | 2022-12-06 10:12:33 | Private BUSD forwarded to F4F | 194.26331405038374757 BUSD | 194.24 | 265.12 |
| [T177](https://bscscan.com/tx/0x8abf1eed9f657fc0dcffe1d0fad5f2ba8bd0dccbfcf669c85d9c5447e935271a) | 2022-12-06 10:13:03 | Private onward transfers BNB | 0.5 BNB | 144.18 | 196.79 |
| [T245](https://bscscan.com/tx/0xdbf3b266bfb488139b1a152794957a3c40f627bed7a643215179f696d7179728) | 2022-12-06 10:36:05 | Onward wallet transfers BNB | 0.017368951262722757 BNB | 5.00 | 6.82 |
| [T246](https://bscscan.com/tx/0xdbf3b266bfb488139b1a152794957a3c40f627bed7a643215179f696d7179728) | 2022-12-06 10:36:05 | Onward network fees BNB | 0.000105 BNB | 0.03 | 0.04 |
| [T178](https://bscscan.com/tx/0xf692b324a95a159bd4c5142cd7eed711211ac0b4e85912fa336cfde0ca961453) | 2022-12-06 10:46:01 | Private vesting claims | 10615821.759259259259259259 GMI | 756.09 | 1,031.99 |
| [T247](https://bscscan.com/tx/0xab06d2d16c2eafb08460e7f85fa8e845f817c67d333f926cbc9294b15f362ec4) | 2022-12-06 11:03:10 | Onward swap outputs BUSD | 1428.0263153399440365 BUSD | 1,427.89 | 1,948.92 |
| [T248](https://bscscan.com/tx/0xab06d2d16c2eafb08460e7f85fa8e845f817c67d333f926cbc9294b15f362ec4) | 2022-12-06 11:03:10 | Onward swap inputs BNB | 5 BNB | 1,440.25 | 1,965.80 |
| [T249](https://bscscan.com/tx/0xab06d2d16c2eafb08460e7f85fa8e845f817c67d333f926cbc9294b15f362ec4) | 2022-12-06 11:03:10 | Onward network fees BNB | 0.001056155 BNB | 0.30 | 0.42 |
| [T250](https://bscscan.com/tx/0x779bee4133176e6e6fed539e18560ace9650eab571189fa7bb2c2b2797709ea4) | 2022-12-06 11:30:05 | Onward wallet transfers BNB | 0.006936496375680644 BNB | 2.00 | 2.73 |
| [T251](https://bscscan.com/tx/0x779bee4133176e6e6fed539e18560ace9650eab571189fa7bb2c2b2797709ea4) | 2022-12-06 11:30:05 | Onward network fees BNB | 0.000105 BNB | 0.03 | 0.04 |
| [T179](https://bscscan.com/tx/0x782a3cb1e15038899222d883a233bcf031c20236ba0b8a3f8584052d799de7ae) | 2022-12-06 11:32:09 | Private other incoming GMI | 9900 GMI | 0.73 | 0.99 |
| [T252](https://bscscan.com/tx/0xdc043f84a9e460faaef01d94eafe7d9ceafa4f18d3d5184f3c455d83c9096c4b) | 2022-12-07 01:05:12 | Onward network fees BNB | 0.00022203 BNB | 0.06 | 0.09 |
| [T253](https://bscscan.com/tx/0x2fec8bc59c14e1fc77f5e16d00f3ecb10682e918f1ca8870e18676a5446d6931) | 2022-12-07 01:05:12 | Onward swap inputs BTCB | 0.02 BTCB | 341.12 | 465.29 |
| [T254](https://bscscan.com/tx/0x2fec8bc59c14e1fc77f5e16d00f3ecb10682e918f1ca8870e18676a5446d6931) | 2022-12-07 01:05:12 | Onward swap outputs BUSD | 337.75700890945698599 BUSD | 337.76 | 460.70 |
| [T255](https://bscscan.com/tx/0x2fec8bc59c14e1fc77f5e16d00f3ecb10682e918f1ca8870e18676a5446d6931) | 2022-12-07 01:05:12 | Onward network fees BNB | 0.000930075 BNB | 0.27 | 0.37 |
| [T180](https://bscscan.com/tx/0x3d8cf351398adcaf852da8181972129eae09e720015748b5a77ed011d2481035) | 2022-12-07 01:07:54 | Private sale inputs | 4000000 GMI | 265.75 | 362.49 |
| [T181](https://bscscan.com/tx/0x3d8cf351398adcaf852da8181972129eae09e720015748b5a77ed011d2481035) | 2022-12-07 01:07:54 | Private sale proceeds BUSD | 240.722539323977159667 BUSD | 240.72 | 328.35 |
| [T182](https://bscscan.com/tx/0xd46a5bc6611b3a72085c6f73a02eb33f23080c99b973633d84e1d16baf8ad2bd) | 2022-12-07 01:08:30 | Private BUSD forwarded to F4F | 240.722539323977159667 BUSD | 240.72 | 328.35 |
| [T256](https://bscscan.com/tx/0xe404938b865ac88a13af6129c79a0d5e034c4bf279f3102241d6bda76672196d) | 2022-12-07 02:32:02 | Onward wallet transfers BUSD | 6590 BUSD | 6,589.99 | 8,988.75 |
| [T257](https://bscscan.com/tx/0xe404938b865ac88a13af6129c79a0d5e034c4bf279f3102241d6bda76672196d) | 2022-12-07 02:32:02 | Onward network fees BNB | 0.000255575 BNB | 0.07 | 0.10 |
| [T258](https://bscscan.com/tx/0x68b04457378b7185c1a584699ef89eae0145337b78e7aad06e666d7c7e0c3369) | 2022-12-07 02:32:55 | Onward wallet transfers USDT | 6410 USDT | 6,410.00 | 8,743.24 |
| [T259](https://bscscan.com/tx/0x68b04457378b7185c1a584699ef89eae0145337b78e7aad06e666d7c7e0c3369) | 2022-12-07 02:32:55 | Onward network fees BNB | 0.000255635 BNB | 0.07 | 0.10 |
| [T183](https://bscscan.com/tx/0xbf14d9959df516b8d028ac4e89084ce160b47375f52dc92ad1a4b6a232fdb0e5) | 2022-12-08 02:24:42 | Private exchange intermediary | 5000000 GMI | 467.39 | 634.81 |
| [T184](https://bscscan.com/tx/0xff3ac1adab98247b4a1c468612618e00f322c6a7ab66b3b9825150a7f7aa4d8f) | 2022-12-08 02:27:14 | Private MEXC 2e8 receipt | 5000000 GMI | 467.87 | 635.46 |
| [T185](https://bscscan.com/tx/0x61380c2e3f616522cc8e9dbd0ace06a26738d159f74593153dab4eb810d9e7bb) | 2022-12-08 06:27:46 | Private sale inputs | 1625721.759259259259259259 GMI | 171.34 | 232.71 |
| [T186](https://bscscan.com/tx/0x61380c2e3f616522cc8e9dbd0ace06a26738d159f74593153dab4eb810d9e7bb) | 2022-12-08 06:27:46 | Private sale proceeds BUSD | 161.912373055634703665 BUSD | 161.91 | 219.91 |
| [T187](https://bscscan.com/tx/0x325e3df49c8f81d74d5343bff786dd8d08f4996d798cefff4a31dcbf8e4b1078) | 2022-12-08 06:32:39 | Private vesting claims | 608016.975308641975308642 GMI | 59.66 | 81.03 |
| [T188](https://bscscan.com/tx/0x227aa6faa58237f47a7dc3ccf0e6c0265d1cb8245acc35aacfdccbee6f3d95c8) | 2022-12-14 16:00:38 | Private sale inputs | 608016.975308641975308642 GMI | 50.51 | 68.49 |
| [T189](https://bscscan.com/tx/0x227aa6faa58237f47a7dc3ccf0e6c0265d1cb8245acc35aacfdccbee6f3d95c8) | 2022-12-14 16:00:38 | Private sale proceeds CAKE | 13.065639141470576526 CAKE | 49.50 | 67.13 |
| [T190](https://bscscan.com/tx/0x03aa7debf2d0fe654828d9b560902166f050f499d1be2cd20dadcf69c22e8639) | 2022-12-14 16:01:19 | Private vesting claims | 2131635.802469135802469136 GMI | 171.20 | 232.17 |
| [T191](https://bscscan.com/tx/0x30c5e3af5fa69cf54e59ec46a3cf3c74ffea59cd3e795cf6aa8923b6482aca71) | 2022-12-14 16:02:19 | Private asset conversion input CAKE | 13.065639141470576526 CAKE | 49.56 | 67.21 |
| [T192](https://bscscan.com/tx/0x30c5e3af5fa69cf54e59ec46a3cf3c74ffea59cd3e795cf6aa8923b6482aca71) | 2022-12-14 16:02:19 | Private asset conversion output BUSD | 49.354088681602483584 BUSD | 49.35 | 66.92 |



### 2023-01

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T193](https://bscscan.com/tx/0x8657b3b3182771a12734fa434536f6f2a667246a2f94998546da301f7e464f3d) | 2023-01-20 05:38:45 | Private vesting claims | 9998962.191358024691358025 GMI | 811.64 | 1,089.31 |
| [T194](https://bscscan.com/tx/0x411c9e992b80d6bb8a0f88127c51f9428c5f78950f5eb527ca99e2521e618dd8) | 2023-01-20 05:40:30 | Private sale inputs | 3032649.49845679012345679 GMI | 245.81 | 329.90 |
| [T195](https://bscscan.com/tx/0x411c9e992b80d6bb8a0f88127c51f9428c5f78950f5eb527ca99e2521e618dd8) | 2023-01-20 05:40:30 | Private sale proceeds BUSD | 225.410169579752827331 BUSD | 225.41 | 302.52 |
| [T196](https://bscscan.com/tx/0xa599f04b0cc1343b3c1048b5d4275ba1bdd587a960f37b95368bc8b04463b095) | 2023-01-21 02:29:17 | Private sale proceeds BNB | 0.582235106329889742 BNB | 177.60 | 238.35 |
| [T197](https://bscscan.com/tx/0xa599f04b0cc1343b3c1048b5d4275ba1bdd587a960f37b95368bc8b04463b095) | 2023-01-21 02:29:17 | Private sale inputs | 2274487.123842592592592592 GMI | 189.64 | 254.51 |
| [T198](https://bscscan.com/tx/0x331197c814cfecdbb91b25a81097b2b1280e65842abeffaa997c2f34bee5b77a) | 2023-01-21 02:31:35 | Private exchange intermediary | 3000000 GMI | 232.05 | 311.43 |
| [T199](https://bscscan.com/tx/0x2e371d5d37cc3deaef36f8c4798f0a18256257304d8eb4db697e6b4414cec02e) | 2023-01-21 02:34:05 | Private MEXC 4982 receipt | 3000000 GMI | 231.98 | 311.33 |
| [T200](https://bscscan.com/tx/0x7f556eb1d5da208355961506485c529d11ee850d5ebf136188a9a5e20dc202e5) | 2023-01-24 15:45:16 | Launchpool January coverage crossing | 8309.56763892731 GMI | 0.75 | 1.00 |



### 2023-02

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T201](https://bscscan.com/tx/0x56da94a4b0cf7b380063929853763a2fa81aaf548b9e9a2e3f4d477688a7e0a5) | 2023-02-25 12:49:01 | Private sale inputs | 955865.342881944444444444 GMI | 92.33 | 125.78 |
| [T202](https://bscscan.com/tx/0x56da94a4b0cf7b380063929853763a2fa81aaf548b9e9a2e3f4d477688a7e0a5) | 2023-02-25 12:49:01 | Private sale proceeds BUSD | 89.301011917324055514 BUSD | 89.30 | 121.65 |
| [T203](https://bscscan.com/tx/0x776d2561d6329ba685647cc04cc2b4d42465c597be0cd1ae3a196c4df2d13d96) | 2023-02-25 12:49:28 | Private sale inputs | 1433798.014322916666666667 GMI | 130.53 | 177.81 |
| [T204](https://bscscan.com/tx/0x776d2561d6329ba685647cc04cc2b4d42465c597be0cd1ae3a196c4df2d13d96) | 2023-02-25 12:49:28 | Private sale proceeds BUSD | 124.564682082873742182 BUSD | 124.56 | 169.68 |
| [T205](https://bscscan.com/tx/0xd505ac7b81c6f1f2724eed8faafee4650ab6e70168f6d5ad2225e982dce560ff) | 2023-02-26 06:07:24 | Private sale inputs | 1433798.014322916666666668 GMI | 146.33 | 199.33 |
| [T206](https://bscscan.com/tx/0xd505ac7b81c6f1f2724eed8faafee4650ab6e70168f6d5ad2225e982dce560ff) | 2023-02-26 06:07:24 | Private sale proceeds BUSD | 139.279474641857817825 BUSD | 139.27 | 189.71 |



### 2023-04

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T207](https://bscscan.com/tx/0xab1707a54f5d665be52be7c7f6e1a40f85575e835c884c92a69381dc6f730334) | 2023-04-04 10:56:48 | Private BUSD forwarded to F4F | 789.821799959045630101 BUSD | 789.67 | 1,061.87 |
| [T208](https://bscscan.com/tx/0xd9e76558654e142eb8355e18842c16e4985a0be2f03dd0e4b4e596bf713e9d58) | 2023-04-04 10:57:48 | Private onward transfers BNB | 0.840230960291603498 BNB | 260.48 | 350.27 |



### 2023-05

| Record | UTC | Recorded movement | Exact quantity | US$ | C$ |
|---|---|---|---:|---:|---:|
| [T260](https://bscscan.com/tx/0xcad217ad6766e48d3ada3297272b3b1f441067ffde02334468447fde0b1b3e60) | 2023-05-16 09:55:56 | Onward swap outputs USDT | 3398.645844082231 USDT | 3,399.33 | 4,574.14 |
| [T261](https://bscscan.com/tx/0xcad217ad6766e48d3ada3297272b3b1f441067ffde02334468447fde0b1b3e60) | 2023-05-16 09:55:56 | Onward swap inputs BNB | 11 BNB | 3,429.53 | 4,614.78 |
| [T262](https://bscscan.com/tx/0xcad217ad6766e48d3ada3297272b3b1f441067ffde02334468447fde0b1b3e60) | 2023-05-16 09:55:56 | Onward network fees BNB | 0.000582534 BNB | 0.18 | 0.24 |
