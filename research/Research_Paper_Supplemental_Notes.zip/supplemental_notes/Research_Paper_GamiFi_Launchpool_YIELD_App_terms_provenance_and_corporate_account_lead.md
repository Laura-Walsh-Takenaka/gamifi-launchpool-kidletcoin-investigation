# Research Paper — GamiFi / Launchpool / YIELD App: terms provenance and corporate-account lead

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Research date: 6 September 2026. Working notes for synthesis; public-source corporate research only.

## Findings

1. The managed-fund wording in GamiFi clause 7.1.3 is shared with Launchpool and YIELD App. Comparing four documents, that clause is identical after substituting provider names and normalizing typography. This establishes shared wording; it does not establish copying direction, document authorship, a separate GamiFi fund, or an account held by GamiFi with YIELD App.
2. GamiFi's terms display a revision date of 25 January 2022. They describe the contracting company as GamiFi Limited, British Virgin Islands. The document supplies no company registration number, named bank, bank account number, custodian identity, or fund prospectus.
3. The compared YIELD App terms display a revision date of 8 February 2021. The contracting operator is ETHpipe OU (Estonian limited liability corporation). They define YLD Limited as a Seychelles company, YLD tokens as licensed to ETHpipe, and the wallet as a BitGo digital custodian wallet. These are digital-asset investment/custody arrangements, not proof of a Cayman bank account.
4. The two compared Launchpool terms display revision dates of 13 January 2021 and 10 November 2021, respectively. They describe Launch Pool Limited as a Virgin Islands company. Do not silently expand this unspecific wording to BVI on the basis of the terms alone.
5. YIELD App's first-party announcement dated 11 March 2021 describes a Launchpool partnership that offered fundraising projects access to a YIELD App Corporate Account, with 20,000 YLD tokens to access the highest reward tier, advertised up to 20% APY. It says Alphabit facilitated the partnership. Launchpool CEO Richard Simpson describes the proposed service as custody and treasury management. This is a concrete corporate-account route within the ecosystem. GamiFi's actual onboarding or use remains unverified.
6. YIELD App's first-party blog post dated 14 December 2020 identifies Alphabit among investors in its funding. That supports the ecosystem relationship independently of the terms-text similarity.

## Matched clauses

| Topic | GamiFi clause | YIELD App clause | Comparison result |
|---|---:|---:|---|
| Deposits / managed fund AML representation | 7.1.3 | 7.1.3 | Identical after provider-name and typography normalization; also identical in both Launchpool versions |
| Prohibited sources of deposits | 6.5 | 6.1.4 | Identical after provider-name and typography normalization |
| Closing account with outstanding balance and interest | 12.3 | 13.3 | Identical after provider-name and typography normalization |
| No financial/legal advice; savings/investment wording | 14 | 15 | Identical after provider-name and typography normalization |

The YIELD document contains a Swaps section 10 addressing its own licensed operator/token relationship. GamiFi does not include that section, so later section numbers differ by one. Do not claim the two documents are wholly identical.

## Primary sources

- Archived GamiFi terms, capture 7 October 2022: https://web.archive.org/web/20221007163947/https://app.gamifi.gg/terms-and-conditions/ . Raw replay used for preservation: https://web.archive.org/web/20221007163947id_/https://app.gamifi.gg/terms-and-conditions/
- YIELD App terms, displayed revision 8 February 2021: https://uploads-ssl.webflow.com/5f3b1e7e87a54051ee78b018/6023cb387c3551136db68ec2_YIELD%20-%20T%26C%20-%20FEB%2010.pdf
- YIELD App / Launchpool corporate-account announcement, 11 March 2021: https://yieldapp.medium.com/yield-app-partners-with-launchpool-provides-corporate-accounts-for-defi-projects-b70a68293245 . Full text recovered through web search; direct download returned HTTP 403.
- Official Launchpool Telegram republishes the announcement: https://t.me/s/launchpoolannouncements?before=130 . Search retrieved the announcement; local direct download timed out.
- YIELD App funding and product announcement, 14 December 2020: https://yield.app/blog/yld-trading-is-live-whats-next
- Launchpool archival originals from the corporate research: corporate_funding/20210519003035.html and corporate_funding/20220128063358.html. Use the corporate source manifest for exact retrieval URLs.

## Preserved files in this working directory

- gamifi_terms_raw.html: raw replay HTML.
- gamifi_terms_text.txt: extracted visible text.
- yield_terms.pdf: original PDF bytes.
- yield_terms_text.txt: pdftotext extraction.
- launchpool_20210519003035_terms_text.txt and launchpool_20220128063358_terms_text.txt: extracted text from preserved corporate-source HTML.
- terms_source_manifest.json: URLs, byte sizes, SHA-256 digests for GamiFi HTML and YIELD PDF.
- terms_comparison.json: exact source clause pairs and normalization outcomes.
- three_provider_fund_clause_comparison.json: all four source clauses and all-identical result after explicit normalization.

## Remaining evidence needed

To connect the actual money, seek GamiFi's corporate account application/approval, account-holder confirmation, treasury statement, specific 20,000 YLD corporate allocation, wallet deposit mapping, or transaction records attributable to GamiFi. A partnership offered to Launchpool projects is insufficient to establish that a particular project took it up. No banking relationship or personal account belonging to Laura is established by these sources.
