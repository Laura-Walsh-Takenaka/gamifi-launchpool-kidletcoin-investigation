# Research Paper — Secondary-project research update — 7 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

This is a separate workstream from KidletCoin consent and GamiFi/Cayman. The material advance is a complete reconciliation of the known MegaFans Launchblock sale's successful claims and final inventory withdrawal. No finding identifies Laura as its wallet controller or proves personal theft. Nativz material sharpens specific records requests and corrects an overbroad date comparison.

## 1. MegaFans / MBUCKS: successful sale claims and final inventory now reconciled

Sale: `0x8d43bdd99db5a36ccb64f868f80aa51b53fbcf4c`; authenticated MBUCKS: `0x3638fea0c645b1aa79db706fab6e8a761385c390`; authenticated USDT: `0x55d398326f99059ff775485246999027b3197955`.

The public index returned 19 ordinary transactions and 20 token-transfer rows. All 23 distinct transaction hashes, receipts and corresponding block headers were verified using Binance BSC RPC. Eighteen token events concern the exact sale/payment tokens. Two other indexed tokens were excluded; one imitated a 1,025-USDT onward transfer but has a different contract address. Symbols or similar recipient addresses cannot authenticate that payment.

All five depositors match the earlier contiguous, immutable deposit-period census. Eight successful claim calls, their original signed-amount inputs, contract configuration and block timestamps reproduce each buyer's payment-currency claim counter and every MBUCKS transfer exactly. Current counters were checked at block **120,422,034**, **7 September 2026 03:25:18 UTC**. Current runtime matches Sourcify's exact-match deployed bytecode: **10,258 bytes**. This closes the known Sale contract's successful-claims subquestion, including absence of further successful claims for the five depositors at this snapshot.

| Depositor prefix | Deposit USDT | Refund USDT | Claim counter, USDT-equivalent | MBUCKS received | Outcome inside Sale |
|---|---:|---:|---:|---:|---|
| 3ce3a276 | 500 | 0 | 86.112862335267803167 | 615.091873823341451192 | Partial claims |
| a47a1d45 | 50 | 0 | 0 | 0 | No successful claim/refund |
| 67eeae0a | 5,000 | 5,000 | 0 | 0 | Fully refunded |
| 487363c0 | 350 | 0 | 350 | 2499.999999999999999999 | Full currency entitlement claimed; conversion floors retained |
| 5a168ccb | 125 | 0 | 125 | 892.857142857142857142 | Full currency entitlement claimed; conversion floors retained |

**Claim total: 4,007.949016680484308333 MBUCKS**, representing **561.112862335267803167 USDT-equivalent** of contract accounting. Full wallet addresses, the eight transaction hashes and per-claim calculations are in `sale_buyer_reconciliation.csv`, `sale_decoded_calls.json` and `sale_verified_transfers.csv`.

The owner `0x462a647318d8dc1f0b5217b14cdcc90957305a1d` called `withdrawAll(address)` on **8 January 2025 16:23:20 UTC**, block **45,590,721**, naming itself. The successful transaction transferred **77,420.050983319515691667 MBUCKS** to that owner address:

https://bscscan.com/tx/0xded7ccb71d50d0a27e64e385e77a0c23645a33b19b8c1a7ac378cb77c3cc41ec

The immutable configured claim deadline was **27 December 2024, 12:00 UTC**. This particular withdrawal follows the original deadline and uses an existing owner function. It is not a newly demonstrated permission-changing drain.

**81,428 MBUCKS funded = 4,007.949016680484308333 claimed + 77,420.050983319515691667 withdrawn.** The owner withdrawal includes excess sale inventory. Treating its entire amount as tokens owed to buyers would be wrong. The previously reconciled payment principal remains **6,025 USDT = 5,000 refunded + 1,025 owner proceeds**.

The remaining accounting difference is **463.887137664732196833 USDT-equivalent**, from the 500-USDT participant's partial claims plus the 50-USDT participant's zero counter. It is **not established as stolen cash or legally due compensation**. In particular, no signed winning allocation was recovered for the 50-USDT depositor. Buyer acceptance of expiry, available signed claim authorizations, notices, access failures and any off-contract settlement remain necessary. No complete owner-onward, staking, buyback or other-venue reconciliation was undertaken. EV-050 remains narrowed.

Primary RPC provenance, requests/results and hashes are preserved in `raw/`; `sale_reconciliation.json` records coverage and limitations. Explorer web opens failed; blockchain claims rely on the successful RPC records, not those failed opens. Sourcify source locator: https://sourcify.dev/server/v2/contract/56/0x8d43Bdd99DB5a36ccb64f868f80Aa51B53FbcF4C?fields=all .

## 2. Nativz: specific consent and survey records; keep separate from KidletCoin

The **7 April 2025** Schools readiness article identifies adult school mentors, parent engagement, on-campus supervision and different arrangements for remote play. The **5 May 2025** game-selection article describes **teacher-led student surveys**, with school rules, parental consent and publisher age restrictions relevant to selection. These add concrete school-level custodians and data-flow questions. They do not establish actual survey collection, deficient consent or harm. [SEC-N11–N12]

Nativz's public Terms, dated **27 July 2025**, require parental permission in section 2 and assert broad permanent commercial contribution-use rights in section 8.4. Compare any actual submitted content, accepted media permission and later use. A website clause alone does not show that a child submitted anything, that permission was missing or that material was sold. The current **4 April 2026** Privacy policy discloses automatic series-to-IEL newsletter enrolment; this was already known. Actual signup screens, age mix, notices and messages remain missing. [SEC-N13–N14]

**Correction:** the About page expressly describes a **2025/26 pilot followed by phased 2026/27 rollout**. Those years can describe different phases; their mere difference is not a direct contradiction. Stale upcoming-pilot wording still merits dated delivery records. [SEC-N15]

The Alumni page still states €300 per title and closed entries. Current search indexing locates the revised CS2 event ID, but direct tournament access failed again. No authenticated prize receipts were recovered. Do not replace the existing qualified outcomes with an allegation of unpaid prizes. [SEC-N16–N17]

## 3. Other bounded additions

- **Kaskade:** recovered an earlier issuer announcement displayed **4 March 2024**: three weeks of BTRFLY/ETH incentives up to $30,000, activity-based gas-rebate chances, dates to follow. It predates the existing March 11/13 chronology. It is neither final accepted scoring rules nor proof Laura wrote it or controlled payouts. Existing unresolved rules/control/campaign gaps remain. [SEC-K13]
- **Spores/MegaFans:** the platform's **12 June 2024** article announces June 17, while its round timeline contains unfilled May dates; later known sale dates are June 24–26. This adds offer-version/acceptance records to request. Search snippets about a 24-hour optional refund referred to related stories, so they were not adopted as proof the MegaFans offer contained that right. [SEC-M19]
- **Techstars/Cardano:** no decisive new later-cohort outcome ledger; a fresh milestone-6 retrieval failed. Prior approved delivery evidence remains controlling. No diverted-grant allegation is supported. [SEC-T6]

No new independent archive capture was recovered this pass. Existing Wayback/Arquivo captures and prior failed requests remain preserved; lack of another capture is not evidence of concealment. Exact URLs, displayed dates, search references and findings are in `web_findings.json`.

## 4. Precise records targets for authorized review

| Separate matter | Records that would resolve the remaining question |
|---|---|
| MBUCKS two unresolved buyer outcomes | Executed buyer terms and exact expiry clause accepted; signed allocation/claim authorizations and issue/delivery logs; notice versions and delivery; support/access errors; complete off-contract refunds or migration settlements |
| MBUCKS owner and inventory | Dated controller mandate for 462a…5a1d; approval/purpose of January 2025 withdrawal; onward inventory ledger and recipients; keep excess stock distinct from accepted buyer entitlements |
| MBUCKS other venues/staking/buybacks | Venue-specific accepted agreements/settlements, deposits and reward liabilities for exact Ferrum pools, profit basis, buyback fills and burns; reviewed NFT source must match deployed bytecode |
| Nativz Schools surveys/consent | School/organizer controller or processor roles; survey templates, fields, recipients and dates; anonymous counts; parental notice/permission versions; school adult-supervision approvals; game-age checks; retention/deletion and media publication authorizations |
| Nativz newsletters | Dated signup screens and checkbox state; series-to-IEL enrolment configuration; lawful-basis assessment; anonymized age mix; actual notices/messages and opt-out handling |
| Nativz Alumni prizes | Event-specific accepted prize terms, changed brackets/cancellations, registration/refund ledger and dated prize receipts; participant counts can be supplied without child identities |
| Kaskade | Accepted rule versions, full multipliers/cutoffs, score calculation and exclusions, all-wallet allocation/Merkle approvals, gas-rebate disbursements, custody/instructions and exact role dates |

The material listed above is a records roadmap, not proof that an offence occurred. No person was contacted, no account was entered, and no child personal data was acquired.

Cardano outcome questions remain: completed-session logs, survey denominators and verified later outcomes.
