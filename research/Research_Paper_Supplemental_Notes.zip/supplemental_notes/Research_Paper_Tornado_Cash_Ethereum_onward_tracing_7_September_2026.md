# Research Paper — Tornado Cash — Ethereum onward tracing — 7 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Two further exchange connections were established from the Ethereum Safe that received the previously traced, pooled USDC proceeds. These are **Safe-level counterparty routes**. The evidence does not establish a specific GamiFi amount at either exchange, and neither route is a Tornado withdrawal.

## KuCoin: first USDC outflow after the pooled receipt

- The existing transparent bridge route reaches Safe **0x525a234de4eee961de7a7fabbf43a0ddcc289494** through dd5217. On 28 July 2022 at 10:13:41 UTC, the Safe receives **125,704.075705 USDC** in [0x6e6f3bef…383cb11](https://etherscan.io/tx/0x6e6f3bef6718fde140bce434808d86be590f00efa536082920228737f383cb11).
- Its **first subsequent positive canonical-USDC outflow** is **300,000 USDC**, 2 August 2022 at 17:19:40 UTC, to **0x1041c9f9ad584f3785f68ce59dd6eab3afc49aff**, [transaction](https://etherscan.io/tx/0x0b92c36aee1df3f456a8283afb5885cf07aa100dba28c46fc8feb00fc7f83627).
- At **17:37:27 UTC**, **17 minutes 47 seconds later**, the entire 300,000 USDC is collected from 1041c9 into **0xf16e9b0d03470827a95cdfd0cb8a8a3b46969b91**, [transaction](https://etherscan.io/tx/0xe2a98054b35e3ba00c45d0161efd0866f3afb596437bfa6ed9fe4baa337233e2).
- This final transaction is submitted by **0xa152f8bb749c55e9943a3a0a3111d18ee2b3f94e** using `transferFrom(1041c9, f16e9b0d, 300000000000)`, not by 1041c9 as the transaction sender. The canonical USDC Transfer log establishes the actual asset path.
- **Primary exchange attribution:** [KuCoin's 11 November 2022 wallet disclosure](https://www.kucoin.com/blog/transparency-and-trust-a-detailed-list-of-kucoin-s-wallets) explicitly lists f16e9b0d as its USDC wallet, with a snapshot of 11 November 2022 at 07:00 UTC, height 15,944,930. Etherscan also calls it “KuCoin 9.” The primary disclosure postdates the August transfer; it is not a claim of a contemporaneously dated August disclosure.
- All **14 indexed canonical-USDC transfers** for 1041c9 were obtained to pagination exhaustion. They show a zero balance before and after this 300,000-USDC pair, with no intervening USDC input. Current tokenbalance independently returns zero. Thus the Safe-to-KuCoin 300,000-USDC transfer sequence is exact at the intermediary.

## OKX-associated collection in July 2024

- Safe → **0x4d69eee233a0b4428d051c6bb861a2a8eb7bd407**: **100 USDC** at 10:54:11 UTC on 3 July 2024, [transaction](https://etherscan.io/tx/0xea5d6c8e726dc054d9b431a0286db786e5473ab9ee3a690069738d6b74fe2a15).
- Same Safe → same recipient: **1,255,106 USDC**, 10:59:11 UTC, [transaction](https://etherscan.io/tx/0x9789b31cd6721b7278a270960f9d94e20575c57ff6407854a095ceacda4e5621).
- At **11:16:11 UTC**, **17 minutes after the second input**, 4d69 sends the exact combined **1,255,206 USDC** to **0x7eb6c83ab7d8d9b8618c0ed973cbef71d1921ef2**, [transaction](https://etherscan.io/tx/0x5f791d72c33f459640978322d623b468e1c8951e85a4c0280e694c8512856f4a).
- [Etherscan labels the destination “OKX 20”](https://etherscan.io/address/0x7eb6c83ab7d8d9b8618c0ed973cbef71d1921ef2). The exact-address official proof-of-reserves CSV check remains incomplete: the [official OKX download page](https://www.okx.com/proof-of-reserves/download) was retrieved through web search, but its 11 August 2026 ZIP timed out after 90 seconds; a 25-second retry also timed out. Therefore this report presently grades this endpoint as an **explorer-labeled OKX address**, not a successfully verified primary CSV row.
- All **three indexed canonical-USDC transfers** for 4d69 were obtained to pagination exhaustion, and the current tokenbalance is zero. No other canonical-USDC input is present in this returned history. The 1,255,206-USDC Safe-to-collector-to-OKX-associated path is exact at the intermediary.

## Why this does not quantify a GamiFi exchange deposit

The full Safe USDC ledger shows **6,493,868.210826 USDC already held** immediately before the 125,704.075705-USDC receipt on 28 July 2022. It held **6,619,572.286531 USDC** afterward. The original receipt already combined multiple upstream sources in the 77.6-ETH swap. The exchange routes establish further counterparties and possible records-request targets, but **do not justify assigning either 300,000 or 1,255,206 USDC to GamiFi**.

The dd5217 → Safe relationship itself predates the investigated July route: **14 canonical-USDC transfers totaling 2,582,144.820837 USDC** appear from 13 January through 28 July 2022, inclusive. That is gross repeated-counterparty volume, not GamiFi proceeds. The Safe's organizational operator remains unidentified by a primary public source.

## Additional transparent bridge lead

On 23 September 2022, Safe sends **310,000 USDC** to **0x50c999deb7f140082edb48c8b1c8802cacc2b14d**, 13:43:35 UTC, [transaction](https://etherscan.io/tx/0x05db2dcab8f535198968a528b907230ff9d44af2c5d8c295981399728923a2dd). At 13:46:59, that address sends **302,000 USDC** into [Synapse's officially listed Ethereum bridge zap](https://docs.synapseprotocol.com/docs/Contracts/Bridge-Zaps), **0x6571d6be3d8460cf5f7d6711cd9961860029d85f**, [transaction](https://etherscan.io/tx/0x357dc71b24846d69c2e38a1b94613f468ff003856fa88af622d4c99402d7213a).

The source `TokenDepositAndSwap` event specifies **destination chain 56** and recipient **50c999**, with **301,605.120907739002033060** units of the intermediate LP token (18 decimals). This is a **verified source-chain bridge instruction**, not a completed cross-chain join. Two initial NodeReal BSC index pages were also retrieved (15 normal rows; 59 token rows), but no independent BSC receipt/bridge-match validation was completed in this pass. Those raw pages are retained only as an open lead. No GamiFi amount or Tornado exit is assigned to it.

## Coverage and verification

- Safe canonical token pagination exhausted: **121 USDC rows / 3 pages**, **178 USDT rows / 4 pages**, **14 DAI rows / 1 page**. Counts include 6, 12, and 2 zero-value rows respectively; zero-value/address-poisoning patterns are excluded from money-flow amounts. Noncanonical tokens imitating USDC/USDT symbols are excluded entirely.
- The Safe USDC event ledger ends at **0.481761 USDC**, matching the independently requested current tokenbalance API. Historical pre/post balances are **event-derived**; an independent Ethereum archive RPC state check was not performed.
- **Eight selected Ethereum full transaction records** and their **independently fetched transaction-log pages** were obtained, all successful; the selected pages contain **nine canonical USDC Transfer logs**. No log page has an unconsumed continuation token. Safe outflows also have `ExecutionSuccess` events.
- This is Blockscout transaction/log verification, not separately fetched raw `eth_getTransactionReceipt` objects or independent RPC consensus verification.
- The legacy internal-transaction endpoint warns that some transactions in its queried block range have not been processed. Accordingly, no complete native-ETH balance census is claimed.
- Additional canonical USDC histories were obtained for four exploratory Safe counterparties (355, 158, 15 and 4 rows). They are retained as supporting lead material, not asserted to be exhaustive onward flow attribution or separately receipt-verified.
- Direct urllib Blockscout queries initially returned 403. Retrying with requests successfully recovered the canonical-token and transaction-log data. Failed attempts and the unresolved OKX download are recorded.

Primary machine-readable result: `ethereum_onward_findings.json`. Complete Safe USDC event accounting: `safe_usdc_ledger.json`. Selected full records and log payloads: `verified_selected_hops.json`; individual captures are in `raw/` with URL and retrieval timestamps. This analysis does not edit the prior report or prior evidence.
