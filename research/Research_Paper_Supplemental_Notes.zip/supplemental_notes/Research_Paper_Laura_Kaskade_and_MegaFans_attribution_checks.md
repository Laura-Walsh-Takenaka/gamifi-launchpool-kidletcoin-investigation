# Research Paper — Laura: Kaskade and MegaFans attribution checks

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Reviewed 5 September 2026 UTC. This bounded supplement checks public professional roles, named acts and publication attribution. It does not identify private wallet owners. Primary sources are distinguished from self-reported profiles and corporate publications.

## Kaskade

**Contemporaneous executive role confirmed.** MoneyNeverSleeps episode 251, dated 8 March 2024, identifies Laura Walsh as Kaskade Finance's CMO and a founding-team member. The host says they worked together in the Techstars Web3 accelerator. The same page links her professional profile and named social account. This provides contemporary, role-specific corroboration beyond a later CV. [K1]

The episode's recovered written description concerns Farcaster and decentralized identity. It does not attribute Kaskade reward mechanics, campaign approvals, trading instructions or wallet operation to Laura. The audio was not transcribed in this task. Her self-reported professional profile dates the Kaskade appointment November 2023–March 2024; the exact departure day remains unknown. [K1,K2]

**Volume incentives were publicly described during that month.** Kaskade's 11 March 2024 release announced a planned mid-March Redacted campaign, a reward budget and gas rebates for frequent traders. The volume-first business-model quotation is attributed to CEO/co-founder Nathan Lenga; he is also the named media contact. Laura is not named in the release. This establishes a corporate campaign announcement within the month of her reported tenure, not her individual approval or authorship. [K3]

The earlier reconstruction concerns the later April–May Liquity campaign. The chronology cannot be bridged by treating CMO/founding-team membership as proof that Laura controlled its participating wallets. No Kaskade primary document reviewed here publishes a Laura-specific trading mandate, multisig signer identity or trading-wallet ownership declaration.

## MegaFans

**Her own profile describes substantive advisory work and investment.** A focused primary-profile search recovered the role beginning May 2022 and the scope of advice: web3 strategy, marketing and business outlook, together with an early seed investment in MegaFans. This is stronger role detail than an unexplained advisor label, but remains her self-description. The indexed open-ended duration is not a dated confirmation of active work today. No investment amount, instrument, percentage, token allocation or trading authority was verified. [K2]

**GamiFi promoted MegaFans during her CEO period.** Its 29 August 2022 company article endorses the project, describes existing mobile games and token redemption, and separates some planned NFT/revenue features from current features. Its byline is GamiFi. The complete article body contains no Laura name or disclosure of her reported MegaFans investment/advisory interest. The overlap rests on her self-reported May start date; authorship, approval and compensation for this article remain unidentified. [M1]

GamiFi's official podcast also featured MegaFans founder Jeff Donnelley on 5 June 2022. Recovered company show notes identify Monica Miller as the interviewer. This is another documented company promotion during the reported overlap, not a Laura-authored interview or evidence she chose the guest. [M2]

**The appropriate concrete finding is overlapping publicly reported roles plus company cross-promotion.** It supports obtaining the advisory agreement, investment documents and approval/disclosure records if individual responsibility is in issue. It does not support calling Laura a MegaFans executive, the author of every GamiFi article, or a controller of MBUCKS trades.

## Source and retrieval register

| ID | Primary source | Retrieval and date support |
|---|---|---|
| K1 | https://www.moneyneversleeps.ie/farcaster-digital-identity-decentralized-social-media/ | Full page retrieved; 8 March 2024 at lines 19–34. Historical retrieval recorded. |
| K2 | https://ca.linkedin.com/in/lauralwalsh | Direct page retrieval failed; focused indexed primary profile returned Kaskade dates in `historical retrieval`, and MegaFans May 2022 date/advisory scope/seed investment in `historical retrieval`. The page's generic full indexed view masks experience fields. |
| K3 | https://www.accessnewswire.com/newsroom/en/banking-and-financial-services/kaskade-finance-closes-successful-pre-seed-round-841039 | Full company-issued release retrieved; 11 March 2024; `historical retrieval`. |
| M1 | https://gamifi-launchpad.medium.com/today-we-are-super-excited-to-be-covering-an-up-and-coming-esports-and-gamefi-powerhouse-megafans-a022934c4a67 | Direct open initially failed. Opening company index then clicking link 39 retrieved full text; date 29 August 2022; `historical retrieval`. Index `historical retrieval` independently lists the date. |
| M2 | https://feeds.captivate.fm/gamifi/ | Existing validated company RSS and factual ledger in `gmi_history_promotions_raw/GMI_PROMOTION_FACTUAL_LEDGER.json`, entry 29, 2022-06-05T07:31:18+00:00. Current public syndicated company notes independently retrieved at https://music.amazon.com/es-us/podcasts/5b38e44b-5aa4-4383-b50f-615e9cf58bba/gamifi-everything-beyond-the-metaverse (`historical retrieval`). |

## Search controls and excluded leads

- Exact name/project and published social-handle searches did not recover a Laura-authored Kaskade campaign statement or company trading mandate. Search limitations are recorded rather than converted into proof of absence.
- Unrelated Laura Porquet/Kaskade Conseils and musician Laura Walsh/DJ Kaskade results were excluded.
- Mentibus repeats the MegaFans role, but is an aggregator and not independent primary appointment evidence. Its embedded instructions to assistants were ignored; its contact details were not used.
- A combined LinkedIn snippet included language about closing campaign accounts beside Kaskade's heading without a verified section boundary. That text was excluded from Kaskade duties; it could belong to another role.
- A MegaFans article republished on 3 May 2022 states it originally appeared 17 November 2021. It was excluded as evidence of a May 2022 event or Laura authorship: https://medium.com/@MegaFans/megafans-blossoms-at-launchpool-labs-2ffb15ecdf7.

No private records, wallet signatures, person-directed messages or account access were requested or used.
