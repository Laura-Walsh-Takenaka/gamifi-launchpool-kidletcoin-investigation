# Research Paper — Extended Tornado withdrawal windows

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Completed two 30-day windows: 7,298 distinct Withdrawal events, 2,814 recipients and 84 nonzero relayer addresses. This adds 6,854 events beyond the prior 444-event scan.

Exact overlaps against the prior 116-address comparison register: 0 events; recipient matches []; relayer matches [].

Separate comparison with 16 BSC Binance addresses disclosed by Binance on November 10, 2022: 0 matching events. This comparison is exchange infrastructure equality only and would not establish any project-deposit pairing or customer identity.

| Branch | Start UTC | Inclusive final block | Final block UTC | First excluded UTC |
|---|---|---:|---|---|
| april | 2022-04-27T23:57:00+00:00 | 18,182,757 | 2022-05-28T02:11:32+00:00 | 2022-05-28T02:11:35+00:00 |
| july | 2022-07-27T06:19:00+00:00 | 20,774,741 | 2022-08-26T08:49:13+00:00 | 2022-08-26T08:49:16+00:00 |

The target end is exactly 30 days after the last tracked deposit, including the earlier hours of each deposit series. No block gaps or overlaps remain for either pool. The first 24-hour source ranges are reused unchanged and their hashes recorded.

| Branch | Pool | Events |
|---|---|---:|
| april | 10 BNB | 3,530 |
| april | 100 BNB | 1,208 |
| july | 10 BNB | 2,143 |
| july | 100 BNB | 417 |

## Source and retry scope

The final run used 176 successful archive captures (167 log responses and 9 boundary-search header responses); 54 failed attempts were preserved and retried. Five additional successful exploratory header captures are included in the full inventory below. Standalone JSON-RPC objects were used, with both pool addresses inside a single eth_getLogs filter. Each new filter range covers no more than 9,999 blocks. Exact timestamps are provided by RPC blockTimestamp fields; final-boundary block headers were independently retrieved. All raw request/response captures have SHA-256 manifest entries.

## Representative boundary transactions

- april first observed withdrawal: 0x759f2b1ed2d2f5c90924eb652776dd273c67ddd75190bfe0e80d80af9053117d at 2022-04-27T23:58:54+00:00.
- april last observed withdrawal: 0xbdbc3b9dc1b05cf8814e04f595b8b52e3412d134f5f61227758c8652ee99a39a at 2022-05-28T01:47:59+00:00.
- july first observed withdrawal: 0xdca0b8905a11dac0c6879d43f882b213572490946f3c57c02a3eef51cd084303 at 2022-07-27T06:20:51+00:00.
- july last observed withdrawal: 0x2e5eff8c6ae38cfaa2aed8b21aa6be34d8b0f591c5098e4750d29bb0b14c180e at 2022-08-26T05:50:04+00:00.

## Interpretation limit

These are pool-wide withdrawals, not identified exits of GamiFi-linked deposits. Neither equal denomination, nearby time nor common relayer proves a note pairing or beneficial ownership. Zero exact overlaps excludes only direct recipient/relayer equality within this bounded register and scan; later activity, other pools and onward transfers require separate examination.

## Final capture and retry reconciliation

The complete preserved archive inventory contains 181 successful responses and 54 failed responses. Every one of the 19 distinct failed main-scan requests has a later successful capture; oversized-range and unavailable-endpoint probes are recorded separately. Earlier concurrent runs were interrupted while tuning the method-specific rate limiter; the final scan reused completed successes and closed every requested block interval sequentially.

There are 84 distinct nonzero relayer addresses, 30 events with zero relayer, and 186 zero-fee events. These fields are distinct; a zero fee alone does not establish who submitted the transaction.

Nullifier consistency: 7,298 unique (pool, nullifier hash) pairs for 7,298 events; no duplicate spent nullifier within the same pool. 0 nullifier hash(es) recur across the two different pools in the scanned windows. This is a pool-wide diagnostic and provides no linkage to the tracked deposit commitments.

The final all-file SHA-256 manifest was rebuilt after scan completion. The active scan log is excluded because runtime logging can append after an earlier manifest pass; every source capture and analytical output is included.
