# Research Paper — Nativz Gaming Limited — validated company review

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Ireland Esports Leagues, Office Showdown, Schools Series and Nemesis**  
**Review date:** 5 September 2026  
**Scope:** Public company records, published commercial statements, competition information, product claims, terms, privacy disclosures and safeguarding explanations.

The strongest validated weaknesses are inconsistent advertised prizes and schedules, defects in public terms and guidance, and acknowledged difficulty establishing commercial success. Recent registry filings and documented competition results provide substantive evidence of continuing operations. Financial solvency, prize settlement and actual data-processing compliance remain unverified.

## Identity and accountability

Nativz Gaming Limited is the company under review. Ireland Esports Leagues is its competition network; Nemesis is its platform. Laura Walsh is currently listed among its advisers. The reviewed public team page assigns the founder/CEO role to Kurt Pittman and identifies separate technology and league-operations leads. It does not establish Laura's responsibility for tournament terms, marketing consents, schools safeguards, accounting or the statements examined here. [Official team page, reviewed 5 September 2026](https://www.nativzgaming.com/our-team)

The similarly named Dallas marketing agency using nativz.io is excluded. Its reviews and complaints cannot be transferred to this Irish company.

## Claim disposition

| Lead | Result | Validated conclusion |
|---|---|---|
| Office Showdown achieved commercial success | **Confirmed limitation** | Company reporting acknowledges an unsuccessful commercial outcome in 2025. |
| All Company Series activity stopped until Winter 2026 | **Resolved** | A later, separately described alumni summer competition was promoted; the April update cannot describe every subsequent activity. |
| Summer prize information is consistent | **Confirmed fault** | One announcement gives two different prize totals; other official pages align with the lower figure. |
| Summer dates are consistently maintained | **Confirmed fault** | Public pages retain different registration and finals dates without a consolidated revision history. |
| Nativz has no recent company filing | **Resolved** | The Irish registrar records a March 2026 annual-return receipt. |
| Schools pilot was completed | **Open** | Reviewed pages continue describing its preparation; a completed pilot and results were not verified. |
| Terms are fully adapted to Nativz | **Confirmed fault** | An unexplained EFL entity remains in its intellectual-property clause. |
| Nemesis secretly relies on another platform | **Resolved** | Registration instructions disclose the integration. |
| 1,070 means independently verified individual students | **Open** | Official publications switch between students and registrations. |
| Newsletter enrolment violates consent rules | **Open** | Policy and signup wording require examination against actual consent records and messages. |
| Schools safeguards are absent | **Downgraded** | Public supervision commitments exist; operational implementation remains untested. |

**Status definitions:** Confirmed means an observable inconsistency or explicitly reported limitation. Resolved means a broader adverse interpretation is contradicted or explained by additional evidence. Open means the decisive evidence was unavailable. These classifications concern the specified leads, not the company's overall legitimacy.

## 1. Corporate records: a recent filing is independently confirmed

The Companies Registration Office's **1 April 2026 Gazette, PDF page 70**, lists **700794 — Nativz Gaming Limited — B1C — received 26 March 2026**. Its **27 March 2024 Gazette, PDF page 86**, records a B1C receipt on **25 March 2024**. These official records corroborate corporate identity and filing activity. They do not disclose the underlying balance sheet, prove filing timeliness, or certify solvency. [2026 CRO Gazette](https://cro.ie/wp-content/uploads/2026/04/April-1-Annual-Returns-Received.pdf), [2024 CRO Gazette](https://cro.ie/wp-content/uploads/2024/04/27-March-2024-Annual-Returns-Received.pdf)

The CORE registry interface returned an access error in this review. The actual annual-return package and financial statements were not obtained. Accordingly, no conclusion is made about turnover, liabilities, cash runway, beneficial ownership or Laura's statutory directorship. [CRO CORE](https://core.cro.ie/)

## 2. Commercial chronology: delivery and profitability must be separated

| Publication | What the company reported | Assessment |
|---|---|---|
| 6–7 August 2025 | The initial Company pilot had concluded; a September season was planned. | This was a launch announcement, not an audited financial outcome. |
| 22 January 2026 | The annual review discussed commercial results and future funding. | See the specific admissions below. |
| 16 April 2026 | After two pilots, the next Company tournament moved to Winter 2026 while Schools pilot delivery took priority. | A documented sequencing decision. |
| 18 June 2026 | An open alumni summer event was offered across three games. | Subsequent activity means a blanket cessation claim is inaccurate. |

Sources: [August launch announcement](https://company.irelandesportsleagues.com/p/ireland-esports-leagues-officially-launches-7e65), [January annual review](https://www.nativzgaming.com/p/2025-in-review), [April update](https://www.nativzgaming.com/p/esports-olympics-to-enc-iel-stepping-forward-making-choices-and-more), [June Company announcement](https://company.irelandesportsleagues.com/p/it-s-been-a-while-here-s-what-we-re-up-to-this-summer).

The annual review acknowledges Office Showdown's commercial failure in 2025 and no capital raised that year. Collegiate operations are described as covering basic costs, while workplace competitions are intended to generate scalable revenue. Its positive demand and launch descriptions therefore do not establish profitability. These disclosed limitations do not establish insolvency. [Annual review, 22 January 2026](https://www.nativzgaming.com/p/2025-in-review)

The current Company archive records earlier pilot winners, including Logitech-linked competition entries, and retains unresolved winner fields for some 2025/26 games. Its broad completeness claim is weakened by those placeholders and the absence of summer outcomes in the reviewed archive. Missing entries do not prove missing competitions. [Company results archive, reviewed 5 September 2026](https://company.irelandesportsleagues.com/results-archive)

## 3. New confirmed fault: conflicting summer prize figures

The **18 June 2026 IEL announcement** advertises **€300 per game in its subtitle**, but its prize paragraph gives **€350**, allocated as **€200 to winners plus €150 to runners-up**. The arithmetic supports the paragraph's €350, creating a **€50-per-game conflict**. Across three titles the advertised alternatives total **€900 versus €1,050**. [IEL summer announcement](https://www.irelandesportsleagues.com/p/get-the-old-team-back-together)

The parallel Company announcement gives €300, and the dedicated alumni landing page also gives €300. This establishes inconsistent offer information. The accepted entry terms, entrant communications and payment receipts would determine what was owed and paid; none was obtained. [Company announcement, 18 June 2026](https://company.irelandesportsleagues.com/p/it-s-been-a-while-here-s-what-we-re-up-to-this-summer), [Alumni landing page](https://company.irelandesportsleagues.com/alumni)

## 4. New confirmed fault: public dates were not reconciled

| Published surface | Registration cutoff | Finals |
|---|---|---|
| Original 18 June IEL article | 3 July 2026 | Week starting 27 July |
| Dedicated alumni page | 12 July 2026 | Week starting 3 August |
| Company homepage | 20 July 2026, 5 p.m. | Not specified in that panel |

[Original announcement](https://www.irelandesportsleagues.com/p/get-the-old-team-back-together), [Alumni page](https://company.irelandesportsleagues.com/alumni), [Company homepage](https://company.irelandesportsleagues.com/)

These may reflect legitimate deadline extensions or rescheduling. The confirmed problem is that a reader encounters incompatible retained dates without an explicit update trail. The homepage also says entries have closed and links recordings; this is not evidence of a current open registration window.

## 5. Schools: public launch status and educational evidence remain incomplete

The Schools homepage continues to describe a forthcoming **2025/26 pilot**. Its About page anticipates a **2026/27 phased rollout**, but supplies no completed pilot date or results. That About page also carries a Company Series/Office Showdown browser title while its body concerns Schools—a separate editorial defect. [Schools homepage](https://schools.irelandesportsleagues.com/), [Schools About page](https://schools.irelandesportsleagues.com/about-us)

The educational case study invokes the founder's earlier Harlequins work and describes an Irish esports programme still in development. The reviewed page offers no measured outcomes from a completed Irish Schools cohort. Past experience and educational objectives should not be substituted for a programme evaluation. [Education Through Esports](https://schools.irelandesportsleagues.com/education-through-esports)

The Parents FAQ promises supervised activity and appropriate titles, while expecting schools to appoint suitable supervisors. The Teachers FAQ discusses structured practice and training, with pilot details to follow. These are public commitments, not proof of operational delivery. School agreements, staff vetting, incident procedures, age-appropriate participation rules and guardian forms were unavailable. An absence of those documents in this review does not establish an absence of safeguards. [Parents FAQ](https://schools.irelandesportsleagues.com/parent-faqs), [Teachers FAQ](https://schools.irelandesportsleagues.com/teachers-faqs)

## 6. Terms: EFL wording has a traceable comparator

Nativz's terms, updated **27 July 2025**, identify Nativz as operator but retain **EFL Digital** in section 8.2's permission requirement. The official English Football League terms contain the same named-entity phrase, a matching children-section structure and the same Computer Misuse Act reference. The latter page's publicly delivered content was inspected through a normal unauthenticated request. This confirms shared wording and supports a template-adaptation explanation. It does not identify the author, prove copying direction, or establish an EFL relationship. [Nativz terms](https://www.nativzgaming.com/terms-of-use), [EFL terms](https://www.efl.com/terms-of-use/)

The Nativz terms also preserve statutory rights and require parental permission for minors. Irish governing law alongside a UK cybercrime reference is a drafting/scope question; it does not automatically invalidate the contract or establish an offence.

## 7. Privacy: the published mechanism is clear; its implementation is not

The **4 April 2026 policy** identifies company 700794 as the default controller, covers associated microsites, and automatically enrols Schools, Collegiate and Company subscribers into IEL using legitimate interests. It permits independent unsubscribe and requires consent before third-party direct marketing. It describes demographic and interest profiling. These facts warrant checking the scope of each subscriber's permission; they do not establish that children were profiled or marketed to unlawfully. [Nativz privacy policy](https://www.nativzgaming.com/privacy-policy)

Public newsletter surfaces contain an email field and generic consent wording about receiving newsletters, with a link to Nativz's terms. The visible wording does not separately explain umbrella-newsletter enrolment. Checkbox default state, later screens, confirmation emails and backend consent records were not captured. The word “newsletters” is plural, so the record cannot support an assertion that users necessarily consented to only one publication. [Schools homepage](https://schools.irelandesportsleagues.com/), [Collegiate signup page](https://collegiate.irelandesportsleagues.com/subscribe), [IEL signup page](https://www.irelandesportsleagues.com/subscribe)

The Irish DPC explains that electronic direct marketing ordinarily requires affirmative consent, with a limited existing-customer exception subject to specific conditions. A GDPR legitimate-interests statement alone does not answer that separate requirement. Actual messages, recipient status, consent scope and any applicable exception must be evaluated before alleging a breach. [DPC direct-marketing guidance](https://www.dataprotection.ie/en/faqs/direct-marketing/consent-explicitly-required-all-cases-electronic-direct-marketing)

## 8. Nemesis: disclosed integration, uneven public documentation

The Company registration guide directs users to Challengermode. The alumni FAQ explicitly requires building the team there and completing a Nemesis profile. This reconciles their coexistence as an integration rather than a concealed substitution. The guide itself mixes one set of game titles in its team-size list with a different set of registration links—a practical documentation weakness. [Registration guide](https://company.irelandesportsleagues.com/help-centre/how-to-register), [Alumni FAQ](https://company.irelandesportsleagues.com/alumni)

Nemesis's marketing page promotes analytics, CRM enrichment and targeted marketing, alongside a GDPR-compliance claim. Several feature descriptions are duplicated under different headings, leaving specific advertised capabilities poorly explained. The page's search-index freshness is limited; current implementation was not inspected. No independently verified technical audit, ownership inventory, service-level agreement or vendor contract was obtained. [Nemesis product page](https://www.nativzgaming.com/nemesis)

## 9. Metrics and delivered competition

The May announcement labels the 1,070 figure as students; the official LinkedIn announcement also uses registrations. Without a deduplication definition, it should be reported as a company-stated participation measure, not an independently verified individual count. Different labels do not establish fabricated registrations. [11 May announcement](https://www.irelandesportsleagues.com/p/ireland-esports-collegiate-series-national-finals-head-to-gamerfest-2026), [Official IEL LinkedIn](https://ie.linkedin.com/company/ireland-esports-leagues)

The annual review's email rates declined from **47.5% to 43.5% opens** and **5% to 3.8% clicks**: reductions of **4 and 1.2 percentage points**, respectively, or approximately **8.4% and 24% relative declines**. The company attributes the change to platform migration. These are engagement metrics, not financial results. [Annual review](https://www.nativzgaming.com/p/2025-in-review)

The 30 May report supplies collegiate champions, match scores and event recordings. UCD won the overall championship; four universities won individual titles. An indexed official video channel also lists Alumni Summer Showdown 2026 playlists. These materially contradict any claim that the enterprise has delivered nothing. Independent validation of every result and prize payout was outside the available record. [Finals report](https://www.irelandesportsleagues.com/p/collegiate-lan-finals-delivered-relive-the-weekend), [Official video channel](https://www.youtube.com/@IELeagues)

## Access limits and decisive next evidence

This was a read-only review. No accounts were created, payment or subscription forms submitted, people contacted, private participant information collected, or systems tested intrusively. Some web-tool results use cached indexing; the date of this review does not guarantee every page was fetched live. Direct normal requests to several Nativz/IEL pages returned 403, as did the CORE interface and Nemesis client. These are access limitations, not proof of a broken site. The YouTube channel was indexed but live fetching was throttled. The tournament upgrade page exposed only its public shell, preventing checkout-term validation. [Public upgrade page](https://company.irelandesportsleagues.com/upgrade)

The most decisive outstanding records are: the filed financial statements; final accepted summer competition terms and payout receipts; the dated pilot-completion record; unique-participant definitions; consent capture and actual newsletter messages; school agreements and safeguarding procedures; and the Nemesis/Challengermode contractual responsibilities. Current searches did not independently validate the Techstars or Enterprise Ireland backing claimed on the company's profile through those organisations' own records. Their absence from the retrieved material is an open corroboration issue, not proof that the claims are false. [Nativz company profile](https://ie.linkedin.com/company/nativz-gaming)

Company-level inconsistencies identified here are not attributed personally to Laura. The record does not establish personal responsibility or financial misconduct.
