# Research Paper — Closure-stage historical valuation

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Prepared 6 September 2026. This extends the existing *Historical file: PRICE_METHOD.md* and its 73 previously recovered asset/block marks. Earlier files are unchanged.

## Dollar figures

GMI transfers are marked using the GMI/WBNB reserve ratio from PancakeSwap pair `0x58d4b61983ca0afe6e352e90719f403e24e016f4`, multiplied by the Chainlink BNB/USD answer. Both states are queried at the completed block immediately before the transfer block. The calculation is a marginal token price. It is not money raised, a bank receipt, a loss, an investment cost, or the price available for selling an entire large balance.

BNB and BUSD proceeds use their respective historical Chainlink USD answers at that same previous-block convention. Actual received token amounts come from independently decoded transaction records. Amounts received are different from a GMI reserve-ratio mark of the input sold; the input and output legs must not be added together.

Chainlink feeds, each with eight answer decimals:

| Asset | USD feed |
|---|---|
| BNB / WBNB | `0x0567f2323251f0aab15c8dfb1967e4e8a7d42aee` |
| BUSD | `0xcbb98864ef56e9042e7d2efef76141f15731b82f` |
| CAKE | `0xb6064ed41d4f67e353768aa239ca86f4f73665a1` |

Every new mark preserves the transaction block and hash, oracle round, last answer-update time, answer age and, for GMI, pool reserves and last reserve-update age. A historical oracle query can return a value last updated earlier; that age is disclosed rather than silently treated as a contemporaneous trade. A thin pool or stale reserve ratio can make a token multiplication particularly theoretical.

The CAKE feed identity is confirmed by the saved feed directory and historical calls at block 23,901,230: `description()` returned `CAKE / USD` and `decimals()` returned 8. The relevant CAKE receipt uses $3.7886211 per CAKE, updated 91 seconds before its transaction.

Material GMI/WBNB LP token mint and redemption legs use previous-block net asset value per LP unit: `2 × pool WBNB reserve × BNB/USD ÷ outstanding LP units`. The other half of the pool is GMI, marked using that same pool ratio. Historical `totalSupply()` and 18 LP decimals are verified directly. This is a marginal value of a liquidity claim on the pool assets. Minted LP tokens and their underlying deposits, or redeemed LP tokens and their outputs, represent corresponding sides of the same liquidity operation and must not be totaled as additional proceeds.

## Canadian dollars

CAD amounts use Bank of Canada's published daily average CAD per USD for the UTC transaction date. Where that date has no published observation, the latest available prior business day is used and its date is recorded. These are daily comparison conversions, not exact intraday FX fills. A missing period beyond seven days remains unpriced rather than borrowing a distant rate. Existing successfully retrieved 2022/2023 API responses are reused.

Sources:

- Chainlink API semantics: https://docs.chain.link/data-feeds/api-reference
- Chainlink feed directory: https://docs.chain.link/data-feeds/price-feeds/addresses?network=bnb-chain&page=1
- Bank of Canada daily rates: https://www.bankofcanada.ca/rates/exchange/daily-exchange-rates/
- Bank of Canada API: https://www.bankofcanada.ca/valet-api-how-to/
- 2022 FX response: https://www.bankofcanada.ca/valet/observations/FXUSDCAD/json?start_date=2022-01-01&end_date=2022-12-31
- 2023 FX response: https://www.bankofcanada.ca/valet/observations/FXUSDCAD/json?start_date=2023-01-01&end_date=2023-12-31

## Evidence and reproducibility

`value_history.py` accepts material transaction records. It reuses existing asset/block marks and sends read-only JSON-RPC batches to `https://docs-demo.bsc.quiknode.pro/` for missing marks. Each saved batch includes the endpoint, UTC retrieval timestamp, exact request and returned response. No transactions are signed or broadcast. No private exchange account records are accessed.

`prefetch_multicall.py` consolidates the three historical contract reads per material block through Multicall3 `0xca11bde05977b3631167028862be2a173976ca11`. The entire outer `eth_call` is pinned to the same previous block, preserving the valuation convention. Transaction timestamps and block hashes are carried from the supplied canonical Transfer logs; their source path is recorded. No transfer amounts or classification are inferred from this quote prefetch. Early blocks before Multicall3 deployment require direct historical calls instead. The provider's five-requests-per-second limit prevents large JSON-RPC batches; successful runs use batches of at most three outer calls.

`valuation_inputs.json` combines the prior 73 marks with new ones. Files ending `_valued.json` contain the input rows, exact USD and CAD Decimal results, and valuation metadata. Unavailable values remain null. Rounded display amounts must not replace exact asset quantities in the evidence ledger.

Balances, allocation-book rows and transfer legs are different accounting concepts. Do not assign a transaction-time dollar receipt to a getter-only allocation record, or total successive forwarding legs as though they were separate funds.
