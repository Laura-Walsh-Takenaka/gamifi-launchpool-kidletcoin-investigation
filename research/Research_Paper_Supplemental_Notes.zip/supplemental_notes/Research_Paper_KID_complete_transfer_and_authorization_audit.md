# Research Paper — KID complete transfer and authorization audit

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Audit generated 2026-09-05T13:59:55.270016+00:00. Token payments independently replayed from retained public-node blocks; three secondary control blocks newly fetched; reconciled against newly refreshed terminal account histories.

## Findings

- Replayed **28 unique transfers, 19 participant wallets and 25 directed edges**. Every exact amount, sender, recipient and block inclusion timestamp agrees with its retained public-node block. All intermediate positions remain nonnegative; the reconstructed total remains **21,000,000 KID** after every transfer.
- Gross transfer volume is **60,901,115.523681 KID**. The same 21-million supply moves through issuance/staging/distribution and subsequent returns. This gross is neither additional issuance nor cash funding.
- Final transfer is **16 July 2019, 04:56:54 UTC**. Reconstructed positions below are historical positions at that point. The namespace later expired: **2 May 2021, 07:44:17 UTC**, derived from lease rules and verified block timestamp. They are not present spendable balances.
- Development, education and distributor wallets retained **17,500,000 KID (83.333333% of supply)**. Eight allocation/signing wallets retained **3,498,980 KID**. Six secondary participants collectively retained **1,020 KID (0.004857143% of supply)**. Six wallet addresses do not establish six children or independent users.
- A new concrete small-wallet control link: **NBGTCB… actually cosigned all seven KID multisig transfers** sent by ND6D4I…, NCIT7A… and NBYH5N…. Each has two common assigned members (NBGTCB… and NCYKQW…) plus its own third key. The common NCYKQW… account first received and forwarded the same 20 KID on 11 June. This demonstrates a shared signing architecture; key ownership and user ages remain unidentified.
- The project shared NBDCOH… key actually cosigned **five KID transfers**: one 1,000-KID distributor payment to itself, and four later development-wallet allocations. It directly sent three other KID transactions. It was an assigned member of three project wallets, without being an issuer signer.
- The explorer richlist is unsuitable as an authoritative balance statement: its retained response totals **17,501,020 KID**, and shows zero for eight wallets whose complete transfer replay yields positive historical positions totaling **3,498,980 KID**. The mismatch is documented, without assigning a cause.
- Earlier *Historical file: normalized-transfers.json* covers 19 of the 28 KID records because its 16-account scope omitted secondary wallets. The full token index and exact blocks contain the missing nine. Reconciliation against all expanded terminal account histories yields exactly the same 28 KID hashes, amounts, senders and recipients, with zero missing or extra records.

## Reconstructed positions after the last KID transfer

| Address | Operational role | Incoming KID | Outgoing KID | Historical position KID |
|---|---|---:|---:|---:|
| `NA5JKIQRYPQ6XB3BT2NQWY4SYH4L6Q43OKVKG2PS` | Development fund | 8,750,000 | 1,750,000 | **7,000,000** |
| `NDSTP4YZPMGACPKS26PV4U4VX63WZRD76UNB7IRL` | Education fund | 6,300,000 | 0 | **6,300,000** |
| `NC6JT7YGYASHVZ2NNS4TK372PTDXBUS354XG7TL4` | Distributor | 21,000,000 | 16,800,000 | **4,200,000** |
| `NCM2QKZZ3AYMGYBMQSQ2ETCXDNDF33NDO2R2E2PX` | Signer / allocation | 1,050,000 | 350,000 | **700,000** |
| `NBDCOHCTOKI3RY46YK7EEPPQRG2UHPCNUQIDVLU5` | Shared project / Foundation signer | 700,010 | 1,070 | **698,940** |
| `NDMV5M4Y2GKQOJ3C4W6HYUK32PSEWLKRHPGS4V2V` | Signer / allocation | 350,050 | 10 | **350,040** |
| `NAHLQEVQ6GI2P67GFRTNGSAKP35XC6WPBBZLR2ZS` | Allocation wallet | 350,000 | 0 | **350,000** |
| `NBLIITQIUKQFK5NFB2L2TPE65B4N3HSHR7KPNU6I` | Definition cosigner | 350,000 | 0 | **350,000** |
| `NCDYOMFFNO5T567SBODMNGZAYBGWREFCIGZ7T26J` | Allocation wallet | 350,000 | 0 | **350,000** |
| `NCEUKZQJXJGQSTEWUIRURSQVX2MDTXU5ZW37YQ4I` | Definition initiator / levy / signer | 350,000 | 0 | **350,000** |
| `NCJHETVLYHK5C3GGO27HNRMBHCLPBSXYRL4WPHJ5` | Signer / allocation | 350,000 | 0 | **350,000** |
| `NBXPW6HJ4UFHPOWMFRKI2Q4KOL7PIA6YAOGHU6ZI` | Secondary KID participant; identity unverified | 1,000 | 0 | **1,000** |
| `NBQVQ64MHCOXTFSNQNZOX2JQE4W2LCI6YCITE4FP` | Secondary KID participant; identity unverified | 20.25 | 10 | **10.25** |
| `ND6D4I6T2UD2ZVFR5UWLW6PAIEXMFCNN5BIMHWOS` | Secondary KID participant; identity unverified | 11 | 3.073681 | **7.926319** |
| `NCIT7ATTMW67VKKSD5DKIWZVKITN5GSHNSC264CP` | Secondary KID participant; identity unverified | 3.273681 | 2.25 | **1.023681** |
| `NBYH5NYA4GOH4V6HEQQKVWCRZBTMRY7L356JUEQK` | Secondary KID participant; identity unverified | 1 | 0.2 | **0.8** |
| `NADLLJRTUU73OZ4MU5PY47PUMWQZUGG25GVVRB4X` | Staging | 21,000,000 | 21,000,000 | **0** |
| `NC7HKOMA4N4ZCYJ7PXJPUGGQLSBLQL6S6LEFQHNZ` | Issuer | 0 | 21,000,000 | **0** |
| `NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE` | Secondary KID participant; identity unverified | 20 | 20 | **0** |

Issuer starting position is 21,000,000 KID; all other wallets start at zero. Issuance is not counted as a payment to the issuer. Automatic levy is denominated in XEM and does not reduce KID supply.

## Allocation and return chronology

- 9 December 2018: issuer → staging → distributor, each leg 21,000,000 KID. These are two movements of the same complete supply.
- 8 January 2019: distributor → NBDCOH…, 1,000 KID, message `Give away KID`. On 9 January NBDCOH… sends 50 KID to NDMV5M…; on 12 January 10 KID returns. Both small legs say `KID for demo`. Net result of that two-way pair is 40 KID at NDMV5M…, not 60 KID of new distribution.
- 4 May 2019: after namespace renewal, distributor allocates four lots of 350,000 KID, 699,000 KID to NBDCOH…, 8,400,000 KID to the message-labelled future development fund and 6,300,000 KID to the message-labelled educational establishment fund. Distributor retains 4,200,000 KID. Together with the January 1,000, gross distributor-to-NBDCOH allocation reaches 700,000 KID before its demo and later sends.
- 26 June 2019: development sends NCM2QK… 700,000 KID; that recipient returns 350,000 KID 25 minutes 33 seconds later. This is an observed partial return, leaving a 350,000-KID net allocation on that pair, on top of its earlier 350,000 allocation. The development wallet also sends 350,000 KID each to NBLIIT… (`BJ Founders`) and NCDYOM…. The label `BJ Founders` is the sender's transaction text; it does not resolve a civil identity.
- 16 July 2019: development sends NAHLQE… 350,000 KID, leaving 7,000,000 KID in the fund. Education has no outgoing KID transfer in this full token history.

## Twenty-KID branch and dates

11 June 2019 was the recovered contest deadline. The initial two 20-KID rows are **one 20-KID amount forwarded**, not two demonstrated contest payouts. The whole branch retains 20 KID, distributed across four final wallets (10.25, 7.926319, 1.023681 and 0.8 KID). The first relay retains zero. A separate 1,000-KID payment on 23 June goes to NBXPW6… and has no further KID movement. No KID transaction in these branches contains a contest/prize or merchant/purchase description.

| Block inclusion UTC | From | To | KID | Initiator | Explicit cosigner | Transaction |
|---|---|---|---:|---|---|---|
| 2019-06-11 01:57:19 | `NBDCOH…` | `NCYKQW…` | 20 | `NBDCOH…` | — | [899d19b357…](https://explorer.nemtool.com/#/s_tx?hash=899d19b357b02601e7a834ec044df9555e0e25be97b4393c7876d66336be4a4b) |
| 2019-06-11 03:37:56 | `NCYKQW…` | `NBQVQ6…` | 20 | `NCYKQW…` | — | [0cb985eff8…](https://explorer.nemtool.com/#/s_tx?hash=0cb985eff8d43358f2c91f0e7e05c4deeee897a024418f4ab257e42315ce3880) |
| 2019-06-11 03:56:24 | `NBQVQ6…` | `ND6D4I…` | 10 | `NBQVQ6…` | — | [e673145da9…](https://explorer.nemtool.com/#/s_tx?hash=e673145da9f1b112e5ea77d18fc677c5fcd44311c7a2cc5b1310f46550e7c4f2) |
| 2019-06-11 04:35:53 | `ND6D4I…` | `NCIT7A…` | 1 | `NAXOAY…` | `NBGTCB…` | [7366d75af6…](https://explorer.nemtool.com/#/s_tx?hash=7366d75af66b6a876f63bb39fa801b62931c6bc37e74cfc37c1896fdf3df7cfd) |
| 2019-06-12 03:54:16 | `ND6D4I…` | `NCIT7A…` | 1 | `NAXOAY…` | `NBGTCB…` | [d350b011d0…](https://explorer.nemtool.com/#/s_tx?hash=d350b011d013c9fa39a5dbbbeffb72d3a19ae493c988d685439c0d317e577e09) |
| 2019-06-12 04:01:29 | `ND6D4I…` | `NCIT7A…` | 1.073681 | `NAXOAY…` | `NBGTCB…` | [3cff7d284c…](https://explorer.nemtool.com/#/s_tx?hash=3cff7d284c437fdb4aeb3bee1c14a6d06d1acef87ac39b0be46450f89172b8a8) |
| 2019-06-14 09:34:02 | `NCIT7A…` | `ND6D4I…` | 1 | `NA5D3O…` | `NBGTCB…` | [26e17e569e…](https://explorer.nemtool.com/#/s_tx?hash=26e17e569e01511aa3d111f6bb6c55a13f286b5b113c2bd727c1cbd7f42434f0) |
| 2019-06-23 05:53:53 | `NBDCOH…` | `NBXPW6…` | 1,000 | `NBDCOH…` | — | [9143808ab0…](https://explorer.nemtool.com/#/s_tx?hash=9143808ab06f768b87ec48e1238bc49aa0fe7383f3c1a414d4d5a4e7f6ad453e) |
| 2019-07-11 07:04:56 | `NCIT7A…` | `NBQVQ6…` | 0.25 | `NA5D3O…` | `NBGTCB…` | [6b6787e3dc…](https://explorer.nemtool.com/#/s_tx?hash=6b6787e3dc932030c87a8cf07358347596424b5371d6bf5927e238c4621dcb7d) |
| 2019-07-12 04:48:48 | `NCIT7A…` | `NBYH5N…` | 1 | `NA5D3O…` | `NBGTCB…` | [76f7a6b77e…](https://explorer.nemtool.com/#/s_tx?hash=76f7a6b77e3c4b2defcac3f75c25e3c8fa2eb66a2ac96de83ffc262da48ecc7d) |
| 2019-07-12 06:14:40 | `NBYH5N…` | `NCIT7A…` | 0.2 | `NAHGR4…` | `NBGTCB…` | [640513d8ce…](https://explorer.nemtool.com/#/s_tx?hash=640513d8ce8d400b2ffb6fc49ba21f4160bb2127cd6f994b2cfdc950d8274eb3) |

## Dynamic authorization

Project wallet controls were replayed in the preserved control audit: issuer 2-of-2 from 14 February 2018 throughout all KID transfers; distributor 3-of-6 from 9 December 2018; development 3-of-6 from 4 May 2019; education 1-of-6 from 4 May 2019. Staging remains ordinary. Identical six-key sets on the latter three consist of NBDCOH…, NBLIIT…, NCEUKZ…, NCJHET…, NCM2QK… and NDMV5M…. Issuer changed to a new 1-of-1 signer through three October 2021 events after KID expiry. Assigned membership is distinct from actual authorization. The distributor received 21 million KID at 07:29:35 UTC on 9 December 2018 and became 3-of-6 at 08:01:10, 31 minutes 35 seconds later. Development became 3-of-6 before its 8.4-million receipt. Education received 6.3 million at 08:35:22 UTC on 4 May 2019 and became 1-of-6 at 09:02:26, 27 minutes 4 seconds later. These observed ordinary-to-multisig sequences do not alone establish misuse.

### Five actual project shared-key cosignatures

| Confirmed UTC | Source | Recipient | KID | Transaction |
|---|---|---|---:|---|
| 2019-01-08T01:36:14+00:00 | `NC6JT7…` | `NBDCOH…` | 1,000 | [63d14a3d3c…](https://explorer.nemtool.com/#/s_tx?hash=63d14a3d3c156527559048ed8d80a6fad23f018c3f32b3ef6e87211e6d1eef22) |
| 2019-06-26T08:47:33+00:00 | `NA5JKI…` | `NCM2QK…` | 700,000 | [277e86f048…](https://explorer.nemtool.com/#/s_tx?hash=277e86f0486b61633bcaa2723672ac998f9df7262af3619fdbfe838c588cee31) |
| 2019-06-26T08:48:08+00:00 | `NA5JKI…` | `NBLIIT…` | 350,000 | [7ee2de0c36…](https://explorer.nemtool.com/#/s_tx?hash=7ee2de0c36c4da1d0e0ddfec77f85e3bae3e557606272b1d664bfafb90822cc6) |
| 2019-06-26T08:48:09+00:00 | `NA5JKI…` | `NCDYOM…` | 350,000 | [137082b8ae…](https://explorer.nemtool.com/#/s_tx?hash=137082b8ae733de7d78b7ae3ba9e7423723033a9d9d3ed6510688df9a170e1f8) |
| 2019-07-16T04:56:54+00:00 | `NA5JKI…` | `NAHLQE…` | 350,000 | [668848f801…](https://explorer.nemtool.com/#/s_tx?hash=668848f801960ed636f3bd31cdface6b2b28018b463f09a52cbf990420d179a0) |

### Secondary current control and historical replay

Full histories currently available for replay produced **3 control events** and **9 exact token-transfer authorization checks**; all checks pass. Current member sets agree with replay where history is available. Control creation timestamps are distinguished from block inclusion timestamps unless the exact control block is separately verified.

| Address | Current threshold | Current members |
|---|---|---|
| `NBQVQ64MHCOXTFSNQNZOX2JQE4W2LCI6YCITE4FP` | Ordinary | — |
| `NBXPW6HJ4UFHPOWMFRKI2Q4KOL7PIA6YAOGHU6ZI` | Ordinary | — |
| `NBYH5NYA4GOH4V6HEQQKVWCRZBTMRY7L356JUEQK` | 2 of 3 | `NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE`, `NAHGR4VEKEL6MUBAKDNO7WFVZLOICPM2ASI2RKOA`, `NBGTCBEUP2YW4Y47Q2ACZYCDME6VV6OVVBN7PSS3` |
| `NCIT7ATTMW67VKKSD5DKIWZVKITN5GSHNSC264CP` | 2 of 3 | `NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE`, `NA5D3OH234C7C32INKU6P4QSW5SOWVWYMZ4UZYXR`, `NBGTCBEUP2YW4Y47Q2ACZYCDME6VV6OVVBN7PSS3` |
| `NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE` | Ordinary | — |
| `ND6D4I6T2UD2ZVFR5UWLW6PAIEXMFCNN5BIMHWOS` | 2 of 3 | `NCYKQWAU23TD2XSZFNLUVSA7XG4UY5LWJLBP2IRE`, `NBGTCBEUP2YW4Y47Q2ACZYCDME6VV6OVVBN7PSS3`, `NAXOAYPEYBHPNOXSFZ3FSCZ2LXKNIWKGCYRYMM7E` |

| Control block inclusion UTC | Wallet | Resulting threshold | Transaction |
|---|---|---|---|
| 2019-07-12T04:17:57+00:00 | `NBYH5N…` | 2 of 3 | [3067b5e1a2…](https://explorer.nemtool.com/#/s_tx?hash=3067b5e1a2c36a09f4ea9e96b4336016ed4e5608d11bcd47da2541c21a719705) |
| 2019-06-03T03:17:38+00:00 | `NCIT7A…` | 2 of 3 | [510bb72a0f…](https://explorer.nemtool.com/#/s_tx?hash=510bb72a0f4130ded8197f2d1f569435ee4689d670a407c29e78c2ad1d52df2b) |
| 2019-06-11T03:53:51+00:00 | `ND6D4I…` | 2 of 3 | [c21a219769…](https://explorer.nemtool.com/#/s_tx?hash=c21a2197693750f484fdfdb98f5ea7f2b017a05796305985e1edb102054dabdc) |

## Every KID transfer

| Block inclusion UTC | Sender | Recipient | KID | Public message | Hash |
|---|---|---|---:|---|---|
| 2018-12-09T07:04:02+00:00 | `NC7HKO…` | `NADLLJ…` | 21,000,000 | — | [59050d1b06…](https://explorer.nemtool.com/#/s_tx?hash=59050d1b0674e290e04d7619faef8717284e3a08e38a9d08879accacec7df4a3) |
| 2018-12-09T07:29:35+00:00 | `NADLLJ…` | `NC6JT7…` | 21,000,000 | — | [a907fa0b09…](https://explorer.nemtool.com/#/s_tx?hash=a907fa0b09a25f1899e7c96fbaa56bf38b780fce36626e4d0f7fcd4301e45eea) |
| 2019-01-08T01:36:14+00:00 | `NC6JT7…` | `NBDCOH…` | 1,000 | Give away KID | [63d14a3d3c…](https://explorer.nemtool.com/#/s_tx?hash=63d14a3d3c156527559048ed8d80a6fad23f018c3f32b3ef6e87211e6d1eef22) |
| 2019-01-09T03:41:52+00:00 | `NBDCOH…` | `NDMV5M…` | 50 | KID for demo | [5cad79f8d1…](https://explorer.nemtool.com/#/s_tx?hash=5cad79f8d1452649ff06925e3a71dc007945b93ae8899e54975c63a584d963e7) |
| 2019-01-12T10:38:23+00:00 | `NDMV5M…` | `NBDCOH…` | 10 | KID for demo | [b4904e890f…](https://explorer.nemtool.com/#/s_tx?hash=b4904e890f2dc46e215e9e4e2dceb44e35c87752b7a618e0b8484438b66f9f07) |
| 2019-05-04T06:53:28+00:00 | `NC6JT7…` | `NDMV5M…` | 350,000 | — | [4cfc7be3b6…](https://explorer.nemtool.com/#/s_tx?hash=4cfc7be3b6f228cff84f975e597a537657b0d14a6bd649f99810d98e8d0223d4) |
| 2019-05-04T06:53:28+00:00 | `NC6JT7…` | `NCJHET…` | 350,000 | — | [a1737a7e42…](https://explorer.nemtool.com/#/s_tx?hash=a1737a7e42a3fda78421abc371b08563a681e5af1df778fd9f84cfa97b7bbf14) |
| 2019-05-04T06:53:28+00:00 | `NC6JT7…` | `NCM2QK…` | 350,000 | — | [896975edd2…](https://explorer.nemtool.com/#/s_tx?hash=896975edd24249459a45c1d323e11372f45b3b125c1ebc590c02a85ccf244353) |
| 2019-05-04T06:53:28+00:00 | `NC6JT7…` | `NCEUKZ…` | 350,000 | — | [e212e8e8be…](https://explorer.nemtool.com/#/s_tx?hash=e212e8e8be7f58a99b47479c5015ce8410a582cc309f17198de9ff585e216ca5) |
| 2019-05-04T06:53:28+00:00 | `NC6JT7…` | `NBDCOH…` | 699,000 | — | [ecfc880d3f…](https://explorer.nemtool.com/#/s_tx?hash=ecfc880d3fbfaafdd156156aa377589c6620ad2629573cd5724d5e04a1e72024) |
| 2019-05-04T07:53:30+00:00 | `NC6JT7…` | `NA5JKI…` | 8,400,000 | kid future development fund | [33c5a6822b…](https://explorer.nemtool.com/#/s_tx?hash=33c5a6822b730a3677bbec8337fce9ba72cdba83329ec49cb567883a34afdcb9) |
| 2019-05-04T08:35:22+00:00 | `NC6JT7…` | `NDSTP4…` | 6,300,000 | educational establishment fund | [f9eb7d56d4…](https://explorer.nemtool.com/#/s_tx?hash=f9eb7d56d483c16336cd445933ad32a3cd287b245207929dec8412430c340112) |
| 2019-06-11T01:57:19+00:00 | `NBDCOH…` | `NCYKQW…` | 20 | — | [899d19b357…](https://explorer.nemtool.com/#/s_tx?hash=899d19b357b02601e7a834ec044df9555e0e25be97b4393c7876d66336be4a4b) |
| 2019-06-11T03:37:56+00:00 | `NCYKQW…` | `NBQVQ6…` | 20 | — | [0cb985eff8…](https://explorer.nemtool.com/#/s_tx?hash=0cb985eff8d43358f2c91f0e7e05c4deeee897a024418f4ab257e42315ce3880) |
| 2019-06-11T03:56:24+00:00 | `NBQVQ6…` | `ND6D4I…` | 10 | — | [e673145da9…](https://explorer.nemtool.com/#/s_tx?hash=e673145da9f1b112e5ea77d18fc677c5fcd44311c7a2cc5b1310f46550e7c4f2) |
| 2019-06-11T04:35:53+00:00 | `ND6D4I…` | `NCIT7A…` | 1 | — | [7366d75af6…](https://explorer.nemtool.com/#/s_tx?hash=7366d75af66b6a876f63bb39fa801b62931c6bc37e74cfc37c1896fdf3df7cfd) |
| 2019-06-12T03:54:16+00:00 | `ND6D4I…` | `NCIT7A…` | 1 | — | [d350b011d0…](https://explorer.nemtool.com/#/s_tx?hash=d350b011d013c9fa39a5dbbbeffb72d3a19ae493c988d685439c0d317e577e09) |
| 2019-06-12T04:01:29+00:00 | `ND6D4I…` | `NCIT7A…` | 1.073681 | — | [3cff7d284c…](https://explorer.nemtool.com/#/s_tx?hash=3cff7d284c437fdb4aeb3bee1c14a6d06d1acef87ac39b0be46450f89172b8a8) |
| 2019-06-14T09:34:02+00:00 | `NCIT7A…` | `ND6D4I…` | 1 | — | [26e17e569e…](https://explorer.nemtool.com/#/s_tx?hash=26e17e569e01511aa3d111f6bb6c55a13f286b5b113c2bd727c1cbd7f42434f0) |
| 2019-06-23T05:53:53+00:00 | `NBDCOH…` | `NBXPW6…` | 1,000 | — | [9143808ab0…](https://explorer.nemtool.com/#/s_tx?hash=9143808ab06f768b87ec48e1238bc49aa0fe7383f3c1a414d4d5a4e7f6ad453e) |
| 2019-06-26T08:47:33+00:00 | `NA5JKI…` | `NCM2QK…` | 700,000 | — | [277e86f048…](https://explorer.nemtool.com/#/s_tx?hash=277e86f0486b61633bcaa2723672ac998f9df7262af3619fdbfe838c588cee31) |
| 2019-06-26T08:48:08+00:00 | `NA5JKI…` | `NBLIIT…` | 350,000 | BJ Founders | [7ee2de0c36…](https://explorer.nemtool.com/#/s_tx?hash=7ee2de0c36c4da1d0e0ddfec77f85e3bae3e557606272b1d664bfafb90822cc6) |
| 2019-06-26T08:48:09+00:00 | `NA5JKI…` | `NCDYOM…` | 350,000 | — | [137082b8ae…](https://explorer.nemtool.com/#/s_tx?hash=137082b8ae733de7d78b7ae3ba9e7423723033a9d9d3ed6510688df9a170e1f8) |
| 2019-06-26T09:13:06+00:00 | `NCM2QK…` | `NA5JKI…` | 350,000 | — | [47bd8bbf7b…](https://explorer.nemtool.com/#/s_tx?hash=47bd8bbf7bef2ef5abec5f4456b523e5177bed4c82477f5723ff6e87ef058db3) |
| 2019-07-11T07:04:56+00:00 | `NCIT7A…` | `NBQVQ6…` | 0.25 | — | [6b6787e3dc…](https://explorer.nemtool.com/#/s_tx?hash=6b6787e3dc932030c87a8cf07358347596424b5371d6bf5927e238c4621dcb7d) |
| 2019-07-12T04:48:48+00:00 | `NCIT7A…` | `NBYH5N…` | 1 | — | [76f7a6b77e…](https://explorer.nemtool.com/#/s_tx?hash=76f7a6b77e3c4b2defcac3f75c25e3c8fa2eb66a2ac96de83ffc262da48ecc7d) |
| 2019-07-12T06:14:40+00:00 | `NBYH5N…` | `NCIT7A…` | 0.2 | — | [640513d8ce…](https://explorer.nemtool.com/#/s_tx?hash=640513d8ce8d400b2ffb6fc49ba21f4160bb2127cd6f994b2cfdc950d8274eb3) |
| 2019-07-16T04:56:54+00:00 | `NA5JKI…` | `NAHLQE…` | 350,000 | — | [668848f801…](https://explorer.nemtool.com/#/s_tx?hash=668848f801960ed636f3bd31cdface6b2b28018b463f09a52cbf990420d179a0) |

## Source and verification scope

Primary underlying sources are the retained complete block responses from `https://nem02.symbol-node.com:7891/block/at/public`, with requested block heights listed in each JSON row. Transfer identity is matched by complete outer signature, and decoded raw transaction amounts (including mosaic multiplier), sender public keys converted to NEM addresses, recipients and block timestamps are independently recomputed here. This is not a local cryptographic signature or full-consensus verification. The complete index consists of 28 records and a terminal empty response; independent reconciliation against the expanded terminal account histories agrees exactly. The three newly examined secondary control transactions were fetched from the public node in this audit and matched as complete transaction objects exactly once in their stated blocks.

Lifecycle source: *Historical file: lifecycle-replay.json* and `CONTROL_LIFECYCLE_RECHECK_2026-09-05.md`, including original definition, two renewals, description-only redefinition, exact protocol expiry boundary blocks and pinned NIS1 source commit `8de7b16dd2ec88faf7215b6737ceb7ab231e21e1`. Reissuing a description did not mint another 21 million. Automatic levy is 10 atomic XEM = 0.00001 XEM per applicable KID transfer.

No child is identified in this audit. Public addresses and signing links establish ledger relationships, not names, age, inbox contents, fraud, merchant acceptance, dollar value or legal ownership.
