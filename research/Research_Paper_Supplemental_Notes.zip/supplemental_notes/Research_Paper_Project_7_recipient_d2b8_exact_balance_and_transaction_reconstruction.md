# Research Paper — Project 7 recipient d2b8: exact balance and transaction reconstruction

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

Research dates: 6–7 September 2026 (UTC). Scope: BNB Smart Chain, chain ID 56. Address: `0xd2b806f9c0352a267ce7ccf33e74d68c070d6171`. This is a wallet address, not an identified person or corporate owner.

## New result

At pinned BSC block **120,394,077**, timestamp **2026-09-06 23:55:32 UTC**, block hash `0x779aaa476a63ca5f06ca65989f33617ab4851f24970f9114a9182c6cbba8b809`, the canonical Binance-Peg BUSD token (`0xe9e7cea3dedca5984780bafc599bd69add087d56`) returns a `balanceOf` of **23,722.715761539594859905 BUSD** for this address. This is the exact amount of the project 7 payment received on 18 March 2022. This is **37.654018168156%** of the seven withdrawals' total 63,001.817377359365034843 BUSD.

The pinned state query was made through `https://bsc-dataseed1.defibit.io/`. Three independent endpoint requests for latest state (Binance, Defibit, and QuickNode demo) returned the same exact balance. Pinned code is `0x`, transaction count is 2, native BNB balance is 0.000000005. See `current_pinned.json` and original request/response envelopes in `chain_raw/`.

This currently proves the amount remains held at the original recipient address. Equal balances at two dates alone do not prove continuous retention or exclude intervening movements. Do not describe this portion as cashed out or missing from all wallets. Ownership, entitlement, and any accounting settlement with the Time Raiders project remain unresolved.

## Original receipt and starting balance

Successful transaction `0xa68d28501388dd1939659be1a24f6fbed8c0c22d6df5bbe43196ff408b3ffba4`, block 16,160,046, 18 March 2022 at 06:58:39 UTC, transferred **23,722.715761539594859905 BUSD** from project contract `0x56c0cb2d047b69278f49b4759c1718436a546c7f` to d2b8. Its project-withdrawal event identifies project ID 7. Sender was `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`.

Historical `balanceOf` returns 0 at block 16,160,045 immediately before, and the exact receipt amount at block 16,160,046 immediately after. Historical recipient code at the receipt block is `0x`. Historical nonce is 1 immediately before and at block 16,360,046. Current nonce is 2.

The existing investigation's archived app mapping identifies project ID 7 as Time Raiders. A separately retrieved first-party 14 March 2022 Time Raiders article names GamiFi among four launchpads for its 17 March IDO: https://medium.com/timeraiders/how-to-participate-in-the-time-raiders-ido-43df9ca44e0f . GamiFi's 22 March podcast description says the Time Raiders IDO launched 17 March and distribution was ongoing: https://player.captivate.fm/587ac29a-5fc4-4db8-95e3-87f16c20e2af . These statements support the commercial campaign context, not the identity or entitlement of d2b8's controller.

## Signed transaction reconstruction

Historical nonces were located with monotonic binary search, then the full block and successful receipt were fetched. `nonce_1.json` contains the first outgoing signed transaction: nonce 0, **24 January 2022 07:57:05 UTC**, block **14,639,494**, hash `0x41c5768b57301456e73d3cad50c11e413bed073bdbd045796cd98afb7fd8c9cc`. It called the canonical GMI token's `transfer` function and moved **286,013.071750000025796608 GMI** to `0x87ec0fb0b85665c659347c4ca8bc9bdcf282143e`. It did not approve or move BUSD.

`nonce_2.json` contains the second and last signed transaction through the current pin: nonce 1, **4 November 2022 11:20:32 UTC**, block **22,763,511**, hash `0x5bdddcaebe994fbfd4809f99f2e04c7cd7621b4f5e124e39aa5f59de8f8b2af0`. It transferred **0.03854508 BNB** to `0xf4f86e37815217ed73ae817a4e5164d56315b1d7`. Its input is empty (`0x`), it used 21,000 gas, succeeded and emitted no event logs. Neither of the address's two signed transactions approved or moved BUSD.

This new BNB counterparty is already independently present in the master investigation as the **private-route onward wallet**. The master records ten prior-route BUSD arrivals totaling 5,411.003865738104347591 BUSD and four BNB payments back to private beneficiary 0x3604…b4d4. One returned 1 BNB on the same day at 14:25:04, approximately 3 hours after this newly recovered payment, 36 seconds before a large private claim. The new transaction creates a direct address-level link between the project 7 payment recipient and that previously traced private route. **It does not show the project 7 BUSD being transferred, and it does not establish common human ownership, Laura's involvement, or the payment's business purpose.** Do not infer that the later 1 BNB payment used these specific 0.03854508 BNB without that wallet's intervening balance reconciliation.

The two-tx inventory is complete for ordinary signed outgoing transactions at the pinned current nonce. A full all-period incoming log scan and token-implementation/authorization review were not completed; the conservative conclusion remains exact currently retained BUSD amount plus no BUSD instruction in the complete ordinary signed inventory.

## Lookup limits and reproducibility

- Direct BscScan address and transaction-list/token-list page requests returned HTTP 403. Web search exact-address lookups across two engines found no indexed named owner. This is not proof that no public label exists.
- Etherscan and PolygonScan same-address HTML requests succeeded and their multichain portfolio both display 23,722.7158 BUSD on BSC. They show no Ethereum/Polygon signed transactions. Those sites' web-search open calls failed, so cite the preserved HTML with source URLs, not a failed-open reference.
- Large `eth_getLogs` range returned Binance `limit exceeded` and QuickNode HTTP 413; no complete all-period BUSD event scan is claimed.
- QuickNode initially rate-limited parallel historical calls (HTTP 429). The later single-worker nonce reconstruction succeeded through cached, bounded historical requests.
- Binance historical state calls return `missing trie node`; latest state works. Defibit accepted the pinned current block 50 blocks behind its head. Original error responses are retained to show coverage limits.

Public explorer navigation links: https://bscscan.com/address/0xd2b806f9c0352a267ce7ccf33e74d68c070d6171 ; https://etherscan.io/address/0xd2b806f9c0352a267ce7ccf33e74d68c070d6171 ; https://polygonscan.com/address/0xd2b806f9c0352a267ce7ccf33e74d68c070d6171 .
