# Research Paper — Trading patterns and Canadian law: evidence mapping

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Prepared 5 September 2026 UTC for the Kaskade, MegaFans and GamiFi trading review. This is an investigative issue map for legal review. The transaction findings come from the accompanying evidence package; the statutory tests below were checked against primary sources, including versions covering the 2024 campaigns.

**The strongest present issue is whether repeated, rewarded turnover was represented as independent demand or durable adoption. The public evidence establishes capital recycling at Kaskade. It does not yet establish a Canadian criminal offence, the identity of the trader, or Laura Walsh/Takenaka's direction of that activity.**

## 1. The factual starting point

The previous transaction reconstruction establishes nine successive USDC/LUSD swaps by `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455` on 20 April 2024. Four complete loops took 204 seconds. Approximately 30,281 USDC initially deployed generated approximately 272,237 nominal stablecoin units of gross input turnover across nine swaps, under an explicit equal-$1 valuation assumption. Each preceding output became the next input. The transactions executed and incurred costs. Gross turnover is neither fresh capital nor profit.

Eight verified ETH transfers connect nine leading addresses whose displayed volume totals 84.3% of the displayed top ten. That denominator cannot be expanded to all traders or the full campaign. Connectivity alone does not establish one beneficial owner. Three LUSD distributions to the reconstructed address total 2,470.816261629075259392 LUSD; the second closely matches its displayed weekly share. The distributor's human or corporate operator remains unverified.

Those details are preserved in [the transaction review](TRADING_VOLUME_REVIEW_2026-09-05.md), with exact transaction links and calculation inputs. Its successful swaps are evidence of real execution; the questionable interpretation is how much independent economic demand that turnover represents. No comparable repeating sequence has yet been established for MBUCKS or GMI.

## 2. Which pattern is supported?

| Pattern being tested | Present assessment | Evidence that would change the assessment |
|---|---|---|
| Repeated turnover to earn incentives | Strongly supported for the reconstructed Kaskade address: exact-output reuse, rapid reversals and campaign-related distributions | Full campaign swap and reward records to determine scale, cost and beneficiaries |
| Wash trading through accounts under common control | A serious hypothesis to test, not an established ownership finding | Exchange account records or other authenticated records establishing control of both sides; AMM liquidity ownership and economic exposure; trading instructions |
| Coordinated matched orders | Not established by the inspected AMM sequence | Order-entry records demonstrating coordinated buy and sell orders of matching size, price and time; identified traders and instructions |
| Misleading promotion of demand/adoption | A concrete disclosure issue to examine | Exact advertisements, their dates and audiences, represented metric definitions, internal exclusions, approval history and knowledge of the recycled component |
| Pump-and-dump | Not established | Identified accumulated position, materially misleading promotion, resulting price movement and sales into induced demand, linked to the same actors |
| Fraudulently obtaining campaign rewards | Not established merely because rewards followed repeated swaps | Contemporaneous rules prohibiting the conduct; dishonest concealment or false eligibility statements; resulting deprivation or risk; evidence of knowledge |

Calling a campaign poorly designed is different from proving that a trader or promoter committed an offence. Equally, the fact that the swaps executed does not resolve whether their use created a misleading market impression. The question must be tested using the particular legal provision.

## 3. Federal criminal provisions

| Provision and legal test | Connection to the observed conduct | Material proof still required |
|---|---|---|
| **Criminal Code s. 382 — fraudulent market manipulation.** Requires a security, a market, intent to create misleading trading or price appearance, and either unchanged beneficial ownership or the specified knowing matched-order conduct. [Official text](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-382.html) | Rapid reversals and volume incentives justify asking whether turnover was deliberately manufactured to simulate market interest. | Classification under this provision; the actual trading arrangement; ownership or matched orders; intent and Canadian jurisdiction. A completed AMM swap followed by a reversal does not automatically satisfy unchanged beneficial ownership. |
| **Criminal Code s. 380(1) — fraud.** Dishonest means must cause deprivation of property, money, securities or services. [Official text](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-380.html) | Potentially relevant if misleading trading/adoption claims induced economic exposure, or dishonest eligibility claims diverted rewards. | A proven dishonest act, the affected economic interest, causal deprivation or risk, and the required knowledge. Known public incentives and accurate gross-turnover disclosures must be considered. |
| **Criminal Code s. 380(2) — affecting the public market.** Addresses fraudulent means affecting public market prices of stocks, shares, merchandise or anything publicly offered, with intent to defraud. [Official text](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-380.html) | Potentially relevant to proven fraudulent price inflation. Its subject-matter wording is broader than s. 382's reference to a security. | A fraudulent price effect and intent to defraud. The reconstructed stablecoin turnover is not, by itself, proof of a price-pumping scheme. |
| **Competition Act s. 52(1), (4).** Criminally prohibits knowing or reckless materially misleading public promotion of a product or business interest; both literal wording and overall impression matter. Actual deception need not be proved. [2024 text](https://laws-lois.justice.gc.ca/eng/acts/c-34/section-52-20220623.html) | Particularly relevant to claims selling Kaskade's incentive service or promoting a token/business using turnover as evidence of adoption. | The exact material representation and context; why its overall impression was misleading; who made or permitted it; knowledge or recklessness; jurisdiction. Reporting gross volume, clearly labelled and contextualized, is not inherently false. |

For fraud, *R. v. Théroux*, [1993] 2 SCR 5, explains that deprivation includes economic prejudice or its risk. The mental element includes subjective knowledge of the prohibited act and of the possible deprivation. The Crown need not wait for a final realized loss, but a disappointing business outcome alone does not supply these elements. [Official decision](https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/992/index.do).

**A separate civil route:** Competition Act **s. 74.01(1)(a)** addresses materially misleading public promotion as reviewable conduct without s. 52's knowing/reckless requirement. It must not be described as a criminal conviction or criminal charge. Section **74.01(1)(b)** may also require adequate testing where a specific product-performance claim is made. Whether a particular promised incentive-service result qualifies needs its exact wording. [Text covering March–May 2024](https://laws-lois.justice.gc.ca/eng/acts/C-34/section-74.01-20220623.html).

## 4. Quebec securities provisions

The following are **provincial securities penal provisions**, distinct from federal Criminal Code offences. [Official Securities Act](https://www.legisquebec.gouv.qc.ca/en/document/cs/v-1.1).

| Provision | Statutory subject | Application question |
|---|---|---|
| **s. 199.1, first paragraph** | Knowing or reasonably knowable misleading securities-trading activity or artificial prices; alternatively fraud | Does the reconstructed series create a misleading trading appearance, and can the required fault and securities connection be proved? A transaction series requires review beyond a single swap. |
| **s. 195.2** | Unfair, improper or fraudulent influence or attempted influence on securities prices/value | Was price/value influence pursued through dishonest practices? Normal AMM price movement is not enough by itself. |
| **ss. 196–197** | Misrepresentations in specified offering/disclosure documents or other securities-transaction contexts, including material omissions | Was an investor-facing claim false or incomplete in a legally covered context? An ordinary promotional blog is not automatically a statutory prospectus. |
| **s. 205; s. 208** | Authorization/permission by officers or employees; assistance, inducement or orders | Which identified person authorized the prohibited act, enabled it or gave instructions? A title or investment alone does not answer this. |

Section **204.1** supplies substantial fine formulas; **208.1** permits up to five years less one day of imprisonment for listed offences. These penalties apply only after the relevant offence and responsibility are established.

**Classification is a required first step.** The CSA stated in October 2023 that value-referenced crypto assets may be securities or derivatives. That is not a determination that every stablecoin transaction satisfies every provincial or Criminal Code securities provision. The precise instrument, contractual rights, trading arrangement and applicable definition need review. [CSA primary guidance](https://www.securities-administrators.ca/news/canadian-securities-regulators-clarify-interim-approach-to-value-referenced-crypto-asset/).

## 5. Canadian jurisdiction and individual responsibility

*Libman v. The Queen*, [1985] 2 SCR 178, addresses the real and substantial link needed between an offence and Canada, including where a significant portion of the constituting activities occurred here. A Canadian-associated individual or globally accessible website does not substitute for examining the actual conduct, participants and effects. [Official judgment](https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/79/index.do).

In *Sharp v. Autorité des marchés financiers*, **2023 SCC 29**, the Supreme Court upheld Quebec regulatory jurisdiction over out-of-province defendants where the alleged securities scheme had sufficient Quebec connections. The Quebec-facing issuer, local involvement, promotion and affected investors mattered together. That jurisdiction decision is not a finding that Laura's projects meet the same test, and it is not itself a Criminal Code jurisdiction ruling. [Official court overview](https://www.scc-csc.ca/judgments-jugements/cb/2023/39920/); [judgment](https://decisions.scc-csc.ca/scc-csc/scc-csc/en/item/20161/index.do).

Criminal Code **s. 21** addresses committing, aiding or abetting an offence. **Section 22.2** concerns an organization's responsibility through specified senior-officer conduct and an intent, at least partly, to benefit the organization. The latter is not automatic personal guilt by job title. [Section 21](https://laws-lois.justice.gc.ca/eng/acts/C-46/section-21.html); [section 22.2](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-22.2.html).

For Laura specifically, the current record establishes professional affiliations, not control of the wallets. Kaskade's March launch may overlap her reported CMO tenure; the inspected April 20 activity follows its stated ending month. Later corporate publications cannot be attributed to her personal authorship or knowledge without evidence.

## 6. Comparators with checked outcomes

**Quebec — Luc Desjardins:** The AMF reported a guilty plea and a **$22,450 fine imposed on 2 February 2015** for securities manipulation. Its investigation identified fictitious mining-share transactions between his TFSA and a controlled company's brokerage account, establishing control of both buy and sell positions. This is a Quebec securities penal example, not a Criminal Code conviction. It illustrates the ownership evidence missing from the present wallet links. This individual and case have no established connection to Laura. [AMF disposition, published 24 February 2015](https://lautorite.qc.ca/en/general-public/media-centre/news/fiche-dactualites/22450-fine-for-securities-manipulation-1).

**United States — Gotbit:** DOJ reported criminal sentencing in June 2025 following guilty pleas involving wire fraud and conspiracy to commit market manipulation and wire fraud. Its account identifies intentional artificial-volume services, multiple accounts used to avoid detection, client payments and admissions. Those evidentiary features explain why Gotbit is a useful comparison; they cannot be imported into Kaskade's record. [DOJ sentencing release](https://www.justice.gov/usao-ma/pr/cryptocurrency-financial-services-firm-gotbit-and-founder-sentenced-market-manipulation).

The SEC's **3 August 2026** release says a proposed civil settlement was filed on 28 July, subject to court approval, and the claims against Fedor Kedrov were dismissed. It also confirms Gotbit's separate criminal guilty plea and sentence. A targeted recent official-source search found no later release establishing approval; this is the verified release status, not a full live docket certification. [SEC release 26598](https://www.sec.gov/enforcement-litigation/litigation-releases/lr-26598).

No verified public Gotbit connection to Laura or these three projects has been established. Gotbit is a comparator under United States law, not a Canadian precedent or an affiliation finding.

## 7. Promotions: what the new chronology means

Kaskade's **31 July 2024** company-channel article recognizes that farming can distort apparent participation while advocating its own incentive model. That is evidence the corporate publication discussed the risk. It is also an open acknowledgment, which must remain in any fair comparison of the promotional message. It does not identify the author, establish Laura's knowledge, or admit that specific metrics were deliberately falsified. [Company article](https://medium.com/@KaskadeFinance/rethinking-airdrops-regular-issuance-events-69c9353fe364).

The useful next comparison is chronological: preserve each claim before and after the partner's May report, identify what metric was promised, check what the company already knew at that date, and determine whether the public received a materially different impression from the measured result. A later statement about farming cannot retroactively prove a particular person's earlier intent.

**GamiFi — named promotion:** MEXC's 23 February 2022 AMA recap attributes to Laura a description of GMI as “pure utility,” discussion of staking and whitelist allocations, and directions to acquire GMI on PancakeSwap or MEXC. This is attributed promotional speech, without establishing deception or trade direction. [MEXC recap](https://blog.mexc.com/mexc-ama-gamefi-session-with-laura-and-casey/), retrieved through the search index; its live page returned 404.

The legal question is whether the complete offering and staking arrangement required securities compliance, and whether any material claim was misleading. CSA guidance predating the AMA says utility functions do not prevent an offering from involving securities. Calling GMI a utility token neither settles classification nor proves a fraudulent description. [CSA Staff Notice 46-308, 11 June 2018](https://www.osc.ca/en/securities-law/instruments-rules-policies/4/46-308/csa-staff-notice-46-308-securities-law-implications-offerings-tokens).

**MegaFans — return claims:** The companion promotion review records an APY headline, pool tables labelled APR and “guaranteed returns” wording on the [official staking page](https://www.megafans.io/staking/index.html). Publication date and realized returns remain unverified. This supplies a specific representation to test under the promotion provisions, not proof of wash trading.

The relevant comparison requires the actual accrual formula, compounding assumptions, lock period, fees, promised reward asset and guarantee terms. A promised number of tokens is not a guaranteed dollar gain. Different APR/APY labels do not by themselves prove overstated payout or dishonest intent. Attribution of that webpage to Laura remains a separate question.

## 8. Records that would resolve the key questions

These are proposed preservation and lawful document-request targets for counsel or investigators, not records already obtained or requests already sent.

1. **Campaign rules and scoring code as deployed:** eligible markets, epoch boundaries, one-wallet/one-person limits, prohibited round trips, exclusions, rebate calculations, changes and audit logs. This separates allowed incentive farming from dishonest reward extraction.
2. **Complete execution and incentive records:** pool Swap events, order fills where applicable, reward entitlements and claims, gas costs, distribution funding and final beneficiaries. This establishes scope and avoids counting token transfers as trades.
3. **Wallet and account attribution:** authenticated project wallet disclosures, exchange account/control records and signing-authority evidence obtained through lawful process. Transfers and similar timing provide leads rather than a substitute for attribution.
4. **Promotional provenance:** original posts, edited versions, decks, audience targeting, publication dates, metric definitions, supporting calculations and internal approval history. This ties a specific representation to a responsible person and time.
5. **Market-maker and contractor records:** agreements, invoices, trading mandates, target-volume requirements, communications and performance reports. These could establish whether a project commissioned the turnover or merely attracted independent farmers.
6. **Knowledge and response:** records of the partner report's circulation, analytics on repeat traders, anti-farming investigations, corrections and decisions to retain particular headlines. These bear on knowledge and recklessness without assuming either.
7. **Economic exposure and jurisdiction:** identifiable investments or purchases, contemporaneous solicitation, actual loss or risk, involved legal entities, operating locations and relevant Canadian/Quebec activity.
8. **Role dates and responsibilities:** exact appointment/departure dates and signing or approval authority. These are necessary before attaching any trading or promotional act to Laura.

## 9. Validation record and limits

The offence language was checked in official section pages. The Justice Canada archives explicitly identify versions covering the 2024 conduct: s. 380 from **1 November 2011**, s. 382 from **19 September 2019**, and Competition Act ss. 52 and 74.01 from **23 June 2022 to 19 June 2024**. The relevant core tests match the current text inspected; later unrelated amendments must not be applied retroactively. [Historical s. 380](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-380-20111101.html); [historical s. 382](https://laws-lois.justice.gc.ca/eng/acts/c-46/section-382-20190919.html).

The core Competition Act tests were also verified in the versions covering February 2022 promotions: [s. 52, effective 9 March 2015–22 June 2022](https://laws-lois.justice.gc.ca/eng/acts/c-34/section-52-20150309.html) and [s. 74.01, effective 12 March 2009–22 June 2022](https://laws-lois.justice.gc.ca/eng/acts/C-34/section-74.01-20090312.html).

Quebec's official amendment annotations for all cited sections precede 2024. A date-specific consolidation failed to load; historical verification rests on those annotations.

Official search-indexed passages supplied the stated *Théroux* and *Libman* principles; their full judgment pages returned access errors. The *Sharp* court overview loaded, but is expressly a staff summary rather than the reasons for use in legal proceedings. This mapping does not represent a complete case-law citator search, token-classification opinion, court finding or exhaustive trading audit. Counsel should retrieve the full judgments and apply the applicable definitions to identified conduct before a formal allegation is made.
