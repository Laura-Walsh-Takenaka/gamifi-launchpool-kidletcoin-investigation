# Research Paper — Kaskade Finance public-source audit notes

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Checked 2026-09-05. Passive public research only; no wallet connection, transactions, login, vulnerability testing or private-person enrichment. These are intermediate notes for the consolidated review, not a conclusion of wrongdoing.

## Prioritized findings

### K1 — Current project continuity is not established; former official domain publicly advertised for sale

The exact former official domain, kaskade.finance, has a fetched marketplace listing headed “Premium domain · For sale,” with a $100 USD asking price and Afternic / GoDaddy references. URL: https://expireddomains.com/domain/kaskade.finance (page fetched today; no publication date). This verifies the existence of the listing, not ownership, actual availability, corporate closure, loss of funds or the party responsible. The site's claimed domain age and SEO data are marketplace assertions, not independently verified. Search also indexes https://www.kaskade.finance/ as “Buy kaskade.finance”; direct fetches timed out or returned 403 and are NOT evidence of an outage.

Old project-issued Medium material continues linking the former domain. The visible author timeline's newest post is Sep 28, 2024: https://medium.com/@KaskadeFinance . This is a stale public communications channel, not proof all activity ended on that date.

Nathan Lenga's own public professional-profile search result states Co-Founder & CEO at Kaskade Nov 2023–Jan 2025 and Head of Growth at Plasma Jan 2025–present: https://uk.linkedin.com/in/nathan-lenga . Full profile fetch failed, but indexed primary profile explicitly provides dates. Corroboration (secondary): https://www.crunchbase.com/person/nathan-lenga . Do not imply his departure itself is misconduct or that he was sole controller.

Inference: A current operating entity, support path and replacement domain need verification before treating Kaskade as an active project. Laura's own profile ends March 2024, so current continuity issues cannot be personally attributed to her from these sources.

### K2 — Definite funding-announcement terminology inconsistency and financial disclosure gap

Company-issued release, March 11, 2024: https://www.accessnewswire.com/newsroom/en/banking-and-financial-services/kaskade-finance-closes-successful-pre-seed-round-841039 . Title and opening call the round pre-seed; the body calls it an oversubscribed seed round. It names over 40 investors but gives no actual raise amount, valuation or financing instrument. It targeted an August MVP and announced a mid-March Redacted campaign with up to $30,000 in rewards. Practical implication: investor count does not establish funded runway, and the reward budget is not the investment amount. Treat stage mismatch as a drafting/disclosure flaw, not proof of fabricated funding. This announcement is within Laura's self-reported tenure; no evidence here identifies its individual author or approver.

### K3 — Incentive quality and retention remain the central design question; real activity is counterevidence

Partner primary source, DeFi Collective, April 10, 2024: https://deficollective.org/blog/kaskade-campaign-launch/ . It announced a 30-day LUSD/USDC campaign with $30,000 of trader incentives alongside $20,000 of liquidity-provider support. It describes points for each dollar traded, distributed pro rata by trading volume. It also reports $3.2 million prior platform volume and claims LP fees exceeded incentives in the first campaign. This is substantial counterevidence to a claim Kaskade was only a paper project. Those metrics are partner-reported, not reproduced onchain in this audit.

Inference: Paying for volume requires demonstrating economically meaningful trading and retained liquidity after subsidies stop; aggregate turnover alone cannot establish either. A repeated-trading/wash-volume susceptibility is a design-review question, NOT observed wash trading. No located transaction dataset, campaign-level retention study or independently reproduced accounting resolved it here. General scarcity of search results is not proof those data never existed.

### K4 — Candidate marketing-versus-terms discrepancy, not ready for strongest conclusions

Project-issued Sep 28, 2024 guide: https://medium.com/@KaskadeFinance/how-to-earn-scroll-marks-on-kaskade-b72b228325c8 . Says marks will eventually convert into governance tokens and describes automatic accrual with trading/holding. Scroll's primary program terms, indexed with May 10, 2024 update: https://portal.scroll.io/sessions-terms-of-use . Search snippets state marks have no monetary value and no guaranteed outcome. The full terms body could not be extracted; no archived version was obtained. This supports a lead that marketing was more categorical than program terms, but do not assert definitive historical breach from snippets. Sep 2024 is after Laura's reported tenure.

Counterevidence: official later airdrop FAQ search results at https://scroll.io/airdrop-faq describe a 200-mark threshold and future eligibility (direct page returned 404). So do not claim token airdrops never happened.

## Confirmed delivery counterevidence

Scroll ecosystem's dated Aug 26, 2024 post explicitly announces Kaskade live on Scroll: https://scroll.ghost.io/kaskade-x-scroll/ . This supports delivery around the promised August window; it would be incorrect to call the August target missed. The fetched Ghost page includes title, author Zhengqi, date and summary, not full article.

## Laura attribution boundary

Her professional profile search result states CMO / Founding Team Nov 2023–Mar 2024: https://ca.linkedin.com/in/lauralwalsh . Contemporary independent podcast host identifies her as CMO and founding team March 8, 2024: https://www.moneyneversleeps.ie/farcaster-digital-identity-decentralized-social-media/ . The latter verifies historical role but gives no evidence of individual authorship of any audited company statement. Later operating conditions and 2024 September claims are outside stated tenure.

## Exclusions and search limits

- No authentic Kaskade contract, public repository or audit report was located through the examined primary links/searches. Do not rewrite this as “unaudited,” “insecure” or “no code.”
- No primary shutdown notice or corporate dissolution record was located. Do not call it dissolved, abandoned, fraudulent or a rug pull.
- kaskade.com is a separately described Panama crypto payment company; no connection established. Exclude.
- Musician Kaskade is unrelated. Exclude.
- Aggregator pages with 2026 copyright dates or generated “2026 company profile” titles are not 2026 project announcements.
- Droomdroom's $0 funding and malformed date are unreliable third-party fields, not evidence actual funding was zero.
- No source located in this review establishes Laura's personal misconduct.
