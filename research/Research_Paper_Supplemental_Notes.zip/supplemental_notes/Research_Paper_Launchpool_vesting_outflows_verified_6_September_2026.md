# Research Paper — Launchpool vesting outflows — verified 6 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

## Main finding

The missing large outgoing transfer has been identified. On **5 November 2022 at 06:45:09 UTC**, a successful transaction transferred **14,000,000 GMI** from GamiFi's official Launchpool vesting contract `0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb` to `0x35dc4a16db1e30036fee83e733ee065ad8535422`.

Transaction: `0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48`, block **22,786,456**, log index 17. Primary BNB RPC receipt and transaction, plus independent QuickNode indexed log, are saved. Successful transaction receipt status is `0x1`.

It was a **token `transferFrom` using an approved spender**, not a normal vesting `claim`. The nested transaction calldata calls GMI with selector `0x23b872dd` and the vesting address, recipient and 14m amount. Approval logs show the allowance to spender `0x9362ced428b4179650252ad87731240b32ef25f3` being reduced by precisely the transferred amount. No Claim event from the vesting contract appears in this receipt.

The same transaction transfers **23,000,000 GMI** from `0xee57b1241f243a1a794f60ffa643d202188d31d9` and **7,000,000 GMI** from `0xba306306b117a25145d58c67a03deb7f22ee2a3a` to the same recipient, totaling **44,000,000 GMI**. This lane has not established the product names/purposes of those two additional proxy contracts.

## Exact prior authorization mechanism

**30 minutes 31 seconds earlier**, on **5 November 2022 at 06:14:38 UTC**, successful transaction `0x4af5d1dccd4008191749c6f193b552edd4e2d10d96028661eed4d508b8901a63`, block **22,785,865**, emitted this ordered sequence:

1. ProxyAdmin `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475` transfers ownership from `0x6bf55810ab061a016a968016818a6e1246aa8b5a` to `0x5e0cf46e675b985f992c5fafd15e56e8c9a94387`.
2. Each of the three source proxies is temporarily upgraded to implementation `0x1ee38d535d541c55c9dae27b12edf090c608e6fb`.
3. Each grants the GMI spender `0x9362ced428b4179650252ad87731240b32ef25f3` the maximum uint256 allowance.
4. Each proxy is switched back to its previous implementation: Launchpool `0x7ed8022c43ab08e79c79addd8a7e5427aaa52250`; the other two `0x4e9fcbbbca286a5be04bdfc9a7f7babb43253e55`.
5. The ProxyAdmin's ownership is transferred from `0x5e0cf…` to **`0x538a8b615e98e87d025c4336be44e4b8588277c7`**, the same owner observed in the prior current-state checks.

Thus the dates and mechanism behind that previously undated ownership change and large token removal are recoverable. The vesting implementation's lack of a direct owner-withdraw function did not prevent removal through the upgrade-and-allowance pathway. Restoring the implementation left the token-level approval in place.

These are contract-level permissions and executed calls. They do not establish investor consent, legal authorization, a human key holder, a theft, or the ultimate recipient of proceeds. The separate Safe-control lane handles owner/signature verification; no human attribution is supplied by this lane.

`key_event_timeline.json` decodes the relevant receipt events for all three pools in log order. All raw receipts and original requests are retained.

## Exact balance and allocation checks

Archive state at **22,786,455** and **22,786,456** independently shows the Launchpool GMI balance changing from **14,923,065.568267084392219941** to **923,065.568267084392219941 GMI**: precisely 14m.

The previously identified beneficiary `0xe356fe28b7b6b015a3b2bb4419dbdf2777d7420b` (nonce 0) has **byte-identical `getVest` output** at four block ends:

- 22,785,864, immediately before the approval transaction's block;
- 22,785,865, after that block;
- 22,786,455, immediately before the removal transaction's block;
- 22,786,456, after that block.

Its stored amount is **587,755.519557566 GMI**, and its stored `claimed` amount remains zero. The grant and removal did not reduce or settle that sampled record on chain. This is a sampled record, not a full ledger audit. At the time of the 14m removal, the remaining 923k still exceeded this single full allocation; later outgoing transfers reduce the balance further. Do not say this single removal immediately prevented that specific claim.

## Opening funding total now verified through token logs

A bounded query of blocks **17,082,000–17,091,999**, the contract's initial day, returned **39 inbound GMI Transfer events**, all from `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`, totaling **15,456,885.882908530406846 GMI**.

The first deposit is **10 GMI**, transaction `0x020b2a285f0c7f1bc3560d814e2d6a13358d35ee2a96b8b70e36ce2f0b840ccc`, block 17,084,824. The remaining 38 deposits total **15,456,875.882908530406846 GMI**, equal to the previously calculated CSV total. Token-transfer funding of this total is established; this lane did not decode every batch's beneficiary calldata to claim all 7,493 list entries executed correctly.

The same opening window contains **16 outgoing GMI transfers totaling 25.428780603935948847 GMI**. Deposits minus these outflows exactly reconcile to the archive balance at block 17,091,999: **15,456,860.454127926470897153 GMI**.

## Additional sampled outflows and scope

Three transfer logs on 7 February 2023 total **5,960.867970016455045862 GMI** to three addresses. One transfer on 5 January 2024 at 18:18:14 UTC pays **808.354375746811 GMI** to `0x7f55f171f223a84a83058fa356797c954881d6cf`, transaction `0xdf2932057ec109dd1e2fc3b6d2121bc57fe9a3e7b3745aca8151954012fc1570`. These subsidiary samples were located by balance thresholds; their call mechanisms have not been decoded here. `decoded_transfers.json` supplies full identifiers.

This is **not** a full historical transfer census. Archive-balance bisection was used to locate one crossing of chosen thresholds, then bounded log requests located the corresponding transfers. No monotonic balance assumption or whole-chain completeness claim is made.

Public QuickNode documentation advertises `https://docs-demo.bsc.quiknode.pro/`. This endpoint successfully serves historical state and bounded logs. Queries were at most 10,000 blocks, later gated to its observed 1-log-request/second limit. Routescan returned `chain not supported`; 1RPC returned HTTP 429. These failures are preserved, not treated as empty histories. Original BNB Chain RPC independently serves the two key historical receipts and transactions.

## Evidence files

- `quicknode_10k_inflows.json`, `quicknode_10k_outflows.json`: opening token transfers.
- `seven_million_logs_retry.json`: indexed 14m outgoing transfer.
- `fourteen_million_receipt.json`, `fourteen_million_tx.json`, `fourteen_million_block.json`: official BNB primary record.
- `allowance_grant_logs.json`, `allowance_grant_receipt.json`, `allowance_grant_tx.json`: grant/upgrade/owner mechanism.
- `key_event_timeline.json`: decoded relevant event sequence from both key receipts.
- `allocation_*.json`, `exact_balance_*.json`, `implementation_*.json`: precise archive state around both events.
- `decoded_transfers.json`: all successful sampled transfer logs in machine-readable form.
- `balance_*.json`, `allowance_*.json`, `*_crossing.json`: search path and scope evidence.

Dollar valuation is assigned by the parent pricing lane, using historical prices and explicit uncertainty. GMI token figures here are not dollar amounts, realized proceeds or losses.
