# Research Paper — Archived campaign frontend: bounded retrieval result

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Checked 2026-09-05 17:38:43 UTC. Three filenames were verified against the already-recovered May 22, 2024 build manifest, then requested as ordinary public archived assets. No JavaScript was executed, backend queried, or credential used.

| Manifest-derived chunk | Result |
|---|---|
| `static/chunks/pages/campaigns-b540c1b715671910.js` | HTTP 404 |
| `static/chunks/pages/campaigns/[id]-a9c3acd72e5902fc.js` | HTTP 404 |
| `static/chunks/pages/claim-26c2c628a005e09e.js` | HTTP 404 |

Each request used the archive prefix `https://web.archive.org/web/20240522163738js_/https://app.kaskade.finance/_next/`. Exact request URLs, individual UTC retrieval times, and errors are recorded in `history_expansion/campaign_archive_asset_log.json`.

No successful chunk body, resolved capture timestamp, redirect target, or content hash was obtained for these three files. No code-based authentication of distributor `0xC1EBB8CE7121069A1208ABd4744C717CA7Ce015B` or campaign eligibility/scoring rule was therefore added by this follow-up. A build manifest proves those route filenames were referenced; it does not prove the archive retained their contents. The retrieval failure says nothing about whether the original platform had policies or filtering controls.

The manifest itself had already been recovered by the consolidated research from capture `20240522181859`, SHA-256 `65985660ac789a6233f7a38e9194b74c847be5b63665e9a626c353ff868aec83`. Its observed filenames were used without guessing other captures or URL variants.
