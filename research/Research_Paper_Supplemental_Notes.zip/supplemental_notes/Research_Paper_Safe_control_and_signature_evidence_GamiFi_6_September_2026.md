# Research Paper — Safe control and signature evidence — GamiFi, 6 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

The approval and withdrawal steps on 5 November 2022 were executed through two different Safe smart accounts. Historical owner calls and cryptographic recovery of the signatures identify the blockchain addresses authorizing each step. They do not identify the humans controlling those addresses or establish why they acted.

## Verified authority sequence

| Time (UTC) | Transaction / block | Verified event |
|---|---|---|
| 2021-08-06 18:47:20 | `0xa70318639ebe3967e334ef9a4aa2866d958bc1889ed6ef6823493132d8a44328`; block 9,804,169 | Withdrawal Safe `0x9362ced428b4179650252ad87731240b32ef25f3` created by `0x7e0135da76bb6cdb35ac5f1342808925e3ef7445`; SafeSetup records that address as initial sole owner, threshold 1. |
| 2022-09-19 14:24:11 | `0x958512439479d367fc0afd13e8928f810dfe40b4945b084bc51fffedc5b9627b`; block 21,470,205 | Safe9362 emits RemovedOwner(7e01...) and AddedOwner(`0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9`). Safe service decodes a swapOwner call at Safe nonce 2. |
| 2022-11-04 07:53:58 | `0x2ecfaeb4b20fedb2a1d0fd838c01cc9e26e898c48284d74062898861eab1bda5`; block 22,759,426 | Approval Safe `0x6bf55810ab061a016a968016818a6e1246aa8b5a` created by `0x538a8b615e98e87d025c4336be44e4b8588277c7`; SafeSetup records the same sole owner, threshold 1. |
| 2022-11-05 06:14:38 | `0x4af5d1dccd4008191749c6f193b552edd4e2d10d96028661eed4d508b8901a63`; block 22,785,865 | Safe6bf executes two signed calls. First transfers ProxyAdmin ownership to `0x5e0cf46e675b985f992c5fafd15e56e8c9a94387`. Second calls that contract to temporarily upgrade three project proxies, grant GMI allowances to Safe9362, restore implementations and transfer ProxyAdmin ownership to 538a. BOTH signatures recover 538a. |
| 2022-11-05 06:45:09 | `0xce306e566653d227a138975f721436d91d457d81ebc32d9cd4386e2fb7455f48`; block 22,786,456 | Safe9362 executes three GMI transferFrom calls for 23,000,000 + 14,000,000 + 7,000,000 GMI, all to `0x35dc4a16db1e30036fee83e733ee065ad8535422`. ALL THREE signatures recover afd9. |

All listed creation/change transactions were independently retrieved from the BNB public RPC and have successful status. Timestamps are in their receipt log blockTimestamp fields; matching Safe API timestamps are corroborative.

## Historical control calls

Immediately before approval, at block **22,785,864**:

- Safe6bf `getOwners()` = [538a], `getThreshold()` = 1, `nonce()` = 0.
- ProxyAdmin `0x6ef316a4e3d378e5b75599daeca94c86d5ce4475` `owner()` = Safe6bf.

At the end of approval block **22,785,865**:

- Safe6bf still has sole owner 538a and threshold 1; nonce = 2.
- ProxyAdmin `owner()` = 538a.

Immediately before withdrawal, at block **22,786,455**:

- Safe9362 `getOwners()` = [afd9], `getThreshold()` = 1, `nonce()` = 3.

At the end of withdrawal block **22,786,456**:

- Safe9362 same sole owner and threshold; nonce = 6.

Current observations on 6 September 2026 also return nonce 6 for Safe9362 and nonce 2 for Safe6bf; Safe API reports no enabled modules for either at its current indexed state. This does not describe historical module configuration outside the checked transactions.

## Cryptographic signature verification

For each SafeMultiSigTransaction event, the script extracts its 65-byte signature from the ABI dynamic bytes field. It pairs it with the subsequent ExecutionSuccess safe transaction hash from the same Safe and calls the EVM ecrecover precompile, address `0x0000000000000000000000000000000000000001`, with hash + v + r + s. These are read-only eth_call requests and do not submit transactions.

Approval signatures:

| Safe transaction hash | Recovered signer |
|---|---|
| `0x78e3b1d837b1b65d87654b207971f0547a99b787ade3c9be6195ac2c2dac1654` | `0x538a8b615e98e87d025c4336be44e4b8588277c7` |
| `0xc42e2675ca74fbbea1a7e8b478302351f8f281b511e9105f9c74ecda8cdddebb` | `0x538a8b615e98e87d025c4336be44e4b8588277c7` |

Withdrawal signatures:

| Safe transaction hash | Recovered signer |
|---|---|
| `0xbe877e68e939e44a3e4cd25ea36b0a664df3d95b6769b2af0ed48e530e6fe562` | `0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9` |
| `0x60dc923f02e13e5d2a3098d6d677e1c681c2c6e62676698076859970243f5255` | `0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9` |
| `0x05a5b02c25bb75b969e6df70cb083ced927370b99f5ea825ccecb565c725bba7` | `0xafd9cfc21ee553ef9c0f3e5525b077b12d0dc3f9` |

The three signatures in the 19 September 2022 owner-change transaction were also independently recovered; all recover the original owner `0x7e0135da76bb6cdb35ac5f1342808925e3ef7445`. The final call replaced that owner with afd9. Raw recoveries are *Historical file: 2.json* and `owner_change_signers_decoded.json`.

These recovered addresses equal the historical sole owners. Safe Transaction Service separately records the same confirmation owner addresses. Its submissionDate fields are off-chain API submission timestamps, not proof of the exact time a signature was produced.

## Contract identity

Both Safes' masterCopy() returned `0x3e5c63644e683549055b9be8653de26e0b4cd36e`, VERSION() = `1.3.0`. Historical singleton runtime was **23,800 bytes**. Its keccak hash exactly matches the official Safe GnosisSafeL2 v1.3.0 deployment artifact for BSC chain 56:

`0x21842597390c4c6e3c1239e434a682b054bd9548eee5e9b1d6a4482731023c0f`

This is a code identity match, not just an explorer label.

## Scope and interpretation

- The approval signer538a is the same address that remains owner of the previously identified project ProxyAdmin. The withdrawal signerafd9 is a separate address.
- Outer transaction gas payers are distinct: approval `0xc1bb5fb09c63f11fde8a5a1f60cd442e84a6422e`, withdrawal `0x343cebd1e7d1a6838cd8b82f6238b29ad78e235e`. A gas payer is not automatically the Safe owner or beneficiary.
- The bulk-recipient lane independently found that the withdrawal executor343c also funded recipient35dc's gas in its next account nonce (249) 30 seconds after the withdrawal. Refer to that lane's receipt for amount and transaction hash.
- Address searches for 9362, afd9 and 7e01 did not yield verified human/business attribution. No address here is attributed to Laura or another person.
- Safe9362's pre-GamiFi history includes transfers involving another token. That alone does not establish a business association with that token project and is excluded from the GMI money totals.
- This lane verifies authorization addresses and control chronology. Dollar valuation and downstream sales belong to other evidence lanes.

## Primary sources and raw files

- Safe official deployment artifact: https://raw.githubusercontent.com/safe-global/safe-deployments/main/src/assets/v1.3.0/gnosis_safe_l2.json
- Safe owner/threshold documentation: https://docs.safe.global/reference-smart-account/owners/getThreshold
- Safe9362 creation: https://safe-transaction-bsc.safe.global/api/v1/safes/0x9362CED428B4179650252ad87731240B32ef25f3/creation/
- Safe9362 executed history: https://safe-transaction-bsc.safe.global/api/v1/safes/0x9362CED428B4179650252ad87731240B32ef25f3/multisig-transactions/?executed=true&ordering=nonce&limit=100
- Safe6bf creation: https://safe-transaction-bsc.safe.global/api/v1/safes/0x6Bf55810ab061A016a968016818a6e1246AA8B5A/creation/
- Safe6bf executed history: https://safe-transaction-bsc.safe.global/api/v1/safes/0x6Bf55810ab061A016a968016818a6e1246AA8B5A/multisig-transactions/?executed=true&ordering=nonce&limit=100
- Public historical RPC: https://docs-demo.bsc.quiknode.pro/
- Independent receipt RPC: https://bsc-dataseed.bnbchain.org

Raw historical calls include `approval_safe_*`, `proxyadmin_owner_*`, `owners_22786455.json`, `threshold_22786455.json`; signature recoveries include `approval_signer_0.json`, `approval_signer_1.json`, `signer_0.json`, `signer_1.json`, `signer_2.json`; summaries include `approval_signers_decoded.json`, `signers_decoded.json`, `singleton_match.json`. Creation and owner-change receipts have corresponding `safe*_receipt.json` names. Retrieval time, endpoint, full request and response are retained in each RPC file. Early lowercase-address API 422 failures were resolved using checksummed addresses and are not evidence of absence.
