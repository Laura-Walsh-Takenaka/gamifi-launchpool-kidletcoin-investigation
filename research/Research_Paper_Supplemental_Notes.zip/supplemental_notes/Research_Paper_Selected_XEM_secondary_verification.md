# Research Paper — Selected XEM secondary verification

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Retrieved 5 September 2026. All 22 selected primary-node transaction records match their asserted historical blocks on nem02.symbol-node.com:7891. Every outer signature occurs once, the entire inner transaction matches the nem01 history, and every normalized XEM amount agrees. This compares ledger records; it does not independently audit cryptographic signatures, payment purpose or beneficial ownership.

| Confirmed UTC | Direction | XEM | Public transaction message | Transaction |
|---|---|---:|---|---|
| 2018-04-02 01:01:15 | SEA regional → shared | 18741.15 | SEA/2018/04/04 | [c5a1f4ad9…](https://explorer.nemtool.com/#/s_tx?hash=c5a1f4ad908bc5369a94d8eb0b8c114ef23b7488891d0f4d2b8bc39b6e9d98ff) |
| 2018-04-05 06:24:27 | Shared → mixed-use issuer | 17237 | calculated at .23 for 4000 USD | [3af266b71…](https://explorer.nemtool.com/#/s_tx?hash=3af266b71effdc825d436ad3212bd6d1c0675d7f6e16612566888846c4485833) |
| 2018-05-02 20:57:12 | SEA regional → shared | 18669.21 | SEA/2018/05/04 | [2ed3f7641…](https://explorer.nemtool.com/#/s_tx?hash=2ed3f7641c2b250411ace074f73a922fba5e0c977cecc83ad22f7d0b5914ff50) |
| 2018-05-03 10:47:42 | Shared → mixed-use issuer | 16000 | For April | [acb192c08…](https://explorer.nemtool.com/#/s_tx?hash=acb192c08b5ba0a4ac9c1cead2e2513d13307c2d2f476d7ed6e1b9a016748036) |
| 2018-05-04 16:40:21 | SEA regional → shared | 9440.73 | SEA/2018/05/07 | [eea5afcb3…](https://explorer.nemtool.com/#/s_tx?hash=eea5afcb38af846b23be953af89094bc045c88be795a2f2a823a4d4430ff38a7) |
| 2018-05-09 03:43:18 | Shared → mixed-use issuer | 8602 | — | [30e66565b…](https://explorer.nemtool.com/#/s_tx?hash=30e66565ba38f30eb652b0c9727d6435bd8eb66297a92151643426e3c3134afb) |
| 2018-06-05 15:12:19 | SEA regional → shared | 21910.45 | SEA/2018/06/04 | [61ad8fb01…](https://explorer.nemtool.com/#/s_tx?hash=61ad8fb01cf16baae8313bda9fbbe662298e705f2b6badee48dee83fc6ffef70) |
| 2018-06-06 00:39:26 | Shared → mixed-use issuer | 20 | May | [3fe28026c…](https://explorer.nemtool.com/#/s_tx?hash=3fe28026c74c7acd7b6dbd684a406847a58475feedd93a04dc9eae4dee82c750) |
| 2018-06-06 00:40:02 | Shared → mixed-use issuer | 20000 | try try again | [458626ca4…](https://explorer.nemtool.com/#/s_tx?hash=458626ca4b91c359bb48001bdc1cea5375e3a65049e9eb8f4d5601dbd4700ea1) |
| 2018-07-08 19:50:59 | SEA regional → shared | 35388.31 | SEA/2018/07/03 | [49025cd0e…](https://explorer.nemtool.com/#/s_tx?hash=49025cd0e4395158046b70ad795bbf4fa08a4fa4dbbf6b08243901925ec0bfde) |
| 2018-07-10 05:26:39 | Shared → mixed-use issuer | 35 | June | [67938e13b…](https://explorer.nemtool.com/#/s_tx?hash=67938e13bba37117f3026966309e1675e74f0956587ab4dd36b1d717bf8be513) |
| 2018-07-10 05:27:09 | Shared → mixed-use issuer | 35000 | — | [a570b1c7a…](https://explorer.nemtool.com/#/s_tx?hash=a570b1c7a5186d69c317fb9035426d56ee00f3fcf5dd587f1e15619d22025285) |
| 2018-08-07 15:48:23 | SEA regional → shared | 37208.64 | SEA/2018/08/04 | [a776693d6…](https://explorer.nemtool.com/#/s_tx?hash=a776693d646f0fd382841995155469eeea88d575ee9e472e66332acfb236c8b5) |
| 2018-08-13 04:18:34 | Shared → mixed-use issuer | 35000 | — | [da3106f87…](https://explorer.nemtool.com/#/s_tx?hash=da3106f872d94a731f332f3ef7e340c5ed139de8236e1f1051463f8f9df245be) |
| 2018-09-11 18:13:13 | SEA regional → shared | 55996.8 | SEA/2018/09/03 | [1704d90c6…](https://explorer.nemtool.com/#/s_tx?hash=1704d90c693a14e21f84a405355981a19a5df63ad7e5b52f861ddbab0fdd1930) |
| 2018-10-08 00:20:28 | SEA regional → shared | 8821.37 | SEA/2018/10/02 | [1e5710d2b…](https://explorer.nemtool.com/#/s_tx?hash=1e5710d2b56ff65481b322415311a283e99fa1f71c40642a993c39a91789efe8) |
| 2018-11-12 08:55:21 | SEA regional → shared | 8865.08 | SEA/2018/11/02 | [a2acc94f4…](https://explorer.nemtool.com/#/s_tx?hash=a2acc94f4a12a23f1eb1c63d12b21f2e9db8900e3dfcc54bcbc04b2c16f540ec) |
| 2018-12-14 08:13:35 | SEA regional → shared | 1871.3 | SEA/2018/12/05 | [f0fd899a5…](https://explorer.nemtool.com/#/s_tx?hash=f0fd899a5ad729c24068ff5521fa7c589d537b1333190962b6e629bd88722114) |
| 2019-01-09 03:41:52 | Shared → NDMV5M… | 100 | For KID | [e5c7ad591…](https://explorer.nemtool.com/#/s_tx?hash=e5c7ad5914018167b6125fc31d6133d65667aae2771807c116d750d9be9a1e07) |
| 2019-02-13 07:15:46 | SEA regional → shared | 601.3 | SEA/2019/02/01 | [b9b1e216d…](https://explorer.nemtool.com/#/s_tx?hash=b9b1e216d270e216652d02eba9fc12f0cbce67689c96c4efd41c7778eaebb890) |
| 2019-03-20 04:36:50 | Shared → mixed-use issuer | 20000 | — | [d0d92edcc…](https://explorer.nemtool.com/#/s_tx?hash=d0d92edcccce440102022115588e7aaf67a63e8fbb0b578a0b3d616b19719a1e) |
| 2019-09-06 17:42:22 | SEA regional → shared | 3773.23 | SEA/2019/09/01 | [0137e3422…](https://explorer.nemtool.com/#/s_tx?hash=0137e3422de11d75421bbc5fb04bac739d3aa81e3b9850a11b046e82942a36a5) |

The SEA→shared gross total is 221,287.57 XEM (12 transfers). Shared→issuer is 151,894 XEM (9 transfers). These sets overlap in time and form a real two-hop transaction path; they cannot be added as new money entering the project, and the path does not establish that the same funds were passed through or that the issuer payments were KID expenditure. The issuer is a mixed-use address. Eight shared→issuer sends occur within six days of an earlier SEA receipt in April–August 2018; timing and month-related messages merit accounting-document follow-up, rather than a purpose conclusion.

The separately selected 100-XEM transfer carries the public message “For KID”. This is stronger project-purpose evidence in the transaction itself, but remains a payer-supplied description.
