# Research Paper — Kaskade Finance — validated public-source review

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Review date: **5 September 2026**. Scope: company claims, historical delivery, incentive economics, published transaction examples and current public entry point. This supersedes the earlier Kaskade notes where new evidence is identified below. No wallet connection, transactions, intrusion, login or third-party contact was performed.

**Result:** Historical campaign evidence and the current public entry point warrant further scrutiny. The strongest findings are developed below, with independently inspected transaction examples. This review does not establish Laura's personal involvement in the criticized activity.

## 1. Dated chronology and attribution boundary

| Date | Verified event | Evidence |
|---|---|---|
| November 2023–March 2024 | Laura's self-reported CMO/founding-team tenure. | [Professional profile](https://ca.linkedin.com/in/lauralwalsh), indexed primary profile; full profile access limited. |
| 8 March 2024 | Contemporary podcast host independently identifies her as CMO/founding-team member. | [MoneyNeverSleeps](https://www.moneyneversleeps.ie/farcaster-digital-identity-decentralized-social-media/), full article retrieved. |
| 11 March 2024 | Funding announcement and August MVP target. | [Company-issued release](https://www.accessnewswire.com/newsroom/en/banking-and-financial-services/kaskade-finance-closes-successful-pre-seed-round-841039). |
| 10 April 2024 | LUSD incentive experiment announced. | [Partner launch](https://deficollective.org/blog/kaskade-campaign-launch/). |
| 20 April 2024 | Two partner-linked swaps inspected below. | Etherscan transaction records, section 3. |
| 2 May 2024 | Partner publishes critical outcome report. | [DeFi Collective report](https://deficollective.org/blog/kaskade-campaign-report/). |
| 27 May 2024 | Kaskade publishes its own outcome analysis. | [Company retrospective](https://medium.com/@KaskadeFinance/kaskade-x-liquity-campaign-analysis-a0f0d48ee97f). |
| 26 August 2024 | Scroll announces Kaskade live. | [Scroll announcement](https://scroll.ghost.io/kaskade-x-scroll/), title/date/summary retrieved. This supports the August delivery target. |
| 28 September 2024 | Kaskade publishes Scroll points guidance. | [Company guide](https://medium.com/@KaskadeFinance/how-to-earn-scroll-marks-on-kaskade-b72b228325c8). |
| January 2025 | Both Nathan Lenga and Ali Habbabeh date the end of Kaskade positions to this month. | Their own indexed [Lenga](https://uk.linkedin.com/in/nathan-lenga) and [Habbabeh](https://ch.linkedin.com/in/ali-habbabeh) profiles. These are self-reported career dates, not legal succession records. |
| 5 September 2026 | Former official website visibly redirects to a domain-sale page. | Live browser observation, section 5. |

The April–May campaign material and September Scroll guidance postdate Laura's stated March 2024 departure. A historical title does not identify the author, approver or controller of later decisions.

## 2. Campaign outcomes: stronger evidence replaces an earlier tentative risk

### Partner account — confirmed publication; ownership attribution remains the partner's inference

DeFi Collective's May report says nine of Week 2's ten leading wallets appeared linked, characterizes repeated swaps as wash trading, and concludes the experiment missed its goals. It favored other liquidity tools unless shortcomings were addressed, and states Kaskade reviewed the draft. Wallet transfers alone do not establish one human owner, concealment intent or a legal offense; those characterizations remain the partner's analysis. Its estimated 16% fee recovery assumed a 50/50 volume split between pools. [Partner report](https://deficollective.org/blog/kaskade-campaign-report/).

### Company's own accounting — reported inputs; independently reproduced arithmetic

Kaskade reported the following for 10 April–1 May 2024:

| Metric | Reported / calculated amount |
|---|---:|
| Incentive budget | $30,000 |
| Routed trading volume | $12.02 million |
| Direct LP trading fees | $5,601 |
| Unique Kaskade traders | 47 |
| Direct fee recovery: 5,601 ÷ 30,000 × 100 | **18.67%** |
| Incentive-minus-direct-fee gap: 30,000 − 5,601 | **$24,399** |

It acknowledged weak fee recovery and uncertainty over whether liquidity growth came from its campaign, simultaneous LP incentives or market conditions. These figures demonstrate a weak direct-fee result; they are **not company revenue, net loss or total social return**. Indirect arbitrage benefits were not quantified. The totals were not independently reconstructed transaction by transaction. [Company retrospective](https://medium.com/@KaskadeFinance/kaskade-x-liquity-campaign-analysis-a0f0d48ee97f).

### Budget and duration clarification

The launch allocated **$30,000 to trader rewards plus $20,000 to separate LP support**: **$50,000** combined support, not company fundraising. Its own body alternates between **30 days and three weeks**. It also states **10,500 LUSD weekly**, which would total **31,500**, while its example uses **10,000 weekly**, consistent with the 30,000 total. These are confirmed publishing inconsistencies; actual shortpayment or overspending is unproved. Positive claims about earlier Dinero activity concern a different experiment. [Launch announcement](https://deficollective.org/blog/kaskade-campaign-launch/).

## 3. Passive transaction verification

The partner's published links led to two successful Ethereum transactions from the same sender, `0xcfC2F1b6363F02C701ec62f892A7da5DA3D7B455`, through the explorer-labeled Aggregation Router V5. Both were inspected in the live public Etherscan UI.

| Record | UTC time on 20 April 2024 | Sender's token flow | Gas paid |
|---|---|---|---:|
| [Swap A](https://etherscan.io/tx/0x66e91ec0018193397cfd98a2e7ed941f61c90e2a76d11d8f1891e0ed635432dd), block 19698298 | 18:05:23 | 30,281.192454 USDC out; 30,280.462242451578365788 LUSD back | 0.002283486062268027 ETH |
| [Swap B](https://etherscan.io/tx/0xb41b25cef02424ec43c872307d746ba76b522f0c6d7bc7b46c97d53ca84e3d1a), block 19698300 | 18:05:47 | The exact received LUSD amount out; 30,263.026732 USDC back | 0.002453940054255420 ETH |

Reproduction:

- Elapsed time: 18:05:47 − 18:05:23 = **24 seconds**.
- USDC shortfall before gas: 30,281.192454 − 30,263.026732 = **18.165722 USDC**.
- Gas: 0.002283486062268027 + 0.002453940054255420 = **0.004737426116523447 ETH**.

This confirms a rapid token round trip. It does not independently identify the sender, prove the nine-wallet cluster, show reward receipt or prove use of a particular frontend. The Kaskade campaign attribution comes from the partner's leaderboard evidence. Displayed current-dollar estimates were excluded from historical accounting. The partner's separate rounded profitability illustration uses different amounts and is not the same pair reproduced here.

## 4. Scroll points: language mismatch confirmed, no-airdrop allegation rejected

Kaskade's September guide states points will become governance tokens and describes automatic accrual through trading/holding. It gives no age or U.S.-person eligibility warning in the retrieved body, though it links Scroll's FAQ. [Company guide](https://medium.com/@KaskadeFinance/how-to-earn-scroll-marks-on-kaskade-b72b228325c8).

Scroll's full rendered terms, labeled **last updated 10 May 2024**, say marks confer no right to future tokens, may never convert, are nonredeemable and subject to discretionary allocation. Participation requires age 18+ and excludes U.S. persons. **Confirmed mismatch:** Kaskade's categorical language exceeds these conditions. **Historical limitation:** no independently archived September version of the terms was obtained, so the displayed revision date alone is not a complete historical provenance record. [Scroll terms](https://portal.scroll.io/sessions-terms-of-use).

A categorical claim that rewards never materialized is unsupported: Scroll's indexed official FAQ describes an airdrop requiring at least **200 marks at the 19 October 2024 snapshot**. Direct retrieval of that former FAQ URL failed, so its full eligibility rules were not validated. The current official portal identifies SCR as Scroll's governance token. [Indexed airdrop FAQ](https://scroll.io/airdrop-faq); [live SCR portal](https://portal.scroll.io/scr).

## 5. Current continuity: public entrance redirected, corporate status unresolved

In the live browser on the review date, navigating to `https://www.kaskade.finance/` redirected to **[this exact observed destination](https://expireddomains.com/domain/kaskade.finance?utm_source=redi)**, which advertised the domain for **$100 USD**. This upgrades the earlier finding from an isolated third-party listing to a verified redirect from the former official entry point. It establishes present website behavior, not who controls the domain, when control changed, why it changed, corporate dissolution or investor losses.

The newest visible nonpinned entry on the [official Medium timeline](https://medium.com/@KaskadeFinance) remains September 2024. Combined with the leadership dates above, this warrants asking for the current legal operator, support route and any replacement product. No primary registry extract, verified entity identifier, succession announcement or shutdown notice was located. Dubai in a press-release dateline does not itself prove incorporation jurisdiction. Searches of company-name variants did not resolve the legal entity; unrelated similarly named firms were excluded.

## 6. Funding language: downgraded to low-severity drafting issue

The March announcement uses pre-seed in the title/opening and seed in the body while describing the same investor group. These are overlapping early-stage financing labels; the wording is a minor editorial inconsistency, not evidence of two conflicting completed raises. The amount, valuation and instrument are undisclosed publicly. Their absence limits outside runway analysis but does not establish a disclosure violation or financial impropriety. [Company-issued release](https://www.accessnewswire.com/newsroom/en/banking-and-financial-services/kaskade-finance-closes-successful-pre-seed-round-841039).

## 7. Lead disposition and next evidence needed

| Lead | Disposition | Evidentiary consequence |
|---|---|---|
| Reward farming / weak campaign economics | **Confirmed partner report; partially independently corroborated** | Preserve the report, historical leaderboard and complete wallet linkage evidence; distinguish author analysis from observed swaps. |
| 30-day versus three-week campaign | **Confirmed mismatch; explanation open** | Campaign amendments and epoch schedules would resolve whether duration changed transparently. |
| August MVP was never delivered | **Resolved against allegation** | Scroll's dated announcement supports launch. |
| Official website still provides the product | **Resolved against current availability at that entry point** | Live redirect establishes domain-sale destination; alternate deployment remains open. |
| Current legal status and disposition of project funds | **Open** | Requires legal-entity identification and financial records. |
| Points were guaranteed token rights | **Confirmed marketing/terms mismatch; historical version open** | Obtain archived terms and any campaign-specific agreement. |
| No token airdrop occurred | **Downgraded / unsupported** | Official indexed eligibility information contradicts a categorical no-airdrop claim. |
| Funding stage is evidence of dishonest fundraising | **Downgraded to editorial issue** | No financial misconduct shown by terminology. |
| No code / unaudited contracts | **Open** | No authenticated Kaskade-specific code or audit located; absence from search is not proof none existed. |
| Laura personally controlled criticized later acts | **Unsupported in reviewed sources** | Post-tenure events require individual decision or authorship evidence. |

## Access and reproducibility notes

All checks were performed on 5 September 2026. Company/partner articles were retrieved as public text. Browser inspection resolved prior text-fetch limits for the domain, Scroll terms and the two Etherscan records. No retrieval error was classified as a project outage. The archive index request did not produce usable records; no unsupported historical snapshot is claimed. Professional-profile dates rely on indexed self-published text. The Google receipts spreadsheet was identified but not opened or verified in this pass. Research distinguishes observed records, issuer/partner assertions, our arithmetic, inference and unresolved leads.
