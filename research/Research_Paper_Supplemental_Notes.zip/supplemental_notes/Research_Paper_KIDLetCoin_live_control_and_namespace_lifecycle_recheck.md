# Research Paper — KIDLetCoin: live control and namespace lifecycle recheck

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

Rechecked 5 September 2026, approximately 08:00–08:08 UTC, using NIS1 mainnet nodes `nem01.symbol-node.com:7891` and `nem02.symbol-node.com:7891`, both reporting version 0.6.102. This review concerns public keys and ledger records; it does not identify the human controlling a key.

## Material findings

The original `kidlet:kid` asset is presently inactive. Both nodes reject active namespace and mosaic-definition queries with HTTP 404. Both nevertheless return the same historical definition from the dedicated `/mosaic/definition/last` endpoint. That endpoint deliberately returns the last definition even if expired; its success must not be interpreted as active issuance. [Active namespace](https://nem01.symbol-node.com:7891/namespace?namespace=kidlet), [active mosaic query](https://nem01.symbol-node.com:7891/mosaic/definition?mosaicId=kidlet:kid), [historical definition](https://nem01.symbol-node.com:7891/mosaic/definition/last?mosaicId=kidlet:kid).

The prior audit's unresolved lifecycle question can now be narrowed with the complete 780-record issuer history and pinned NIS1 protocol source. Exactly three `kidlet` namespace transactions and two `kidlet:kid` definitions occur in that history; zero KID supply-change transactions occur. The second definition changes only a newline in its description. Initial supply, divisibility, transferability, immutability, creator and levy are unchanged. Its block, 2,137,280, is after the mainnet redefinition fork at 1,110,000. The applicable source code expressly preserves supply and balances for this description-only update. **It did not create an additional 21 million KID or reset the existing allocations.** [Update transaction](https://explorer.nemtool.com/#/s_tx?hash=250b0463c72bc6e1322d5e8bc3a5f726bc2094bebc5c9fb6d1a1635ad6b7610b), [pinned balance-preservation code](https://github.com/NemProject/nem/blob/8de7b16dd2ec88faf7215b6737ceb7ab231e21e1/nis/src/main/java/org/nem/nis/state/Mosaics.java), [pinned mainnet fork height](https://github.com/NemProject/nem/blob/8de7b16dd2ec88faf7215b6737ceb7ab231e21e1/nis/src/main/java/org/nem/nis/BlockMarkerConstants.java).

The original lease did temporarily lapse in April 2019. The same issuer renewed it within the 43,200-block grace window, restoring the mosaic. The last issuer renewal was in April 2020. Applying the 525,600-block mainnet lease duration places final inactivity at **block 3,178,560, 2 May 2021 at 07:44:17 UTC**. This date is derived from the renewal history and protocol rules, with the actual timestamp of the derived block independently returned by both nodes. It is not an expiration transaction. The corresponding grace boundary is block 3,221,760, 1 June 2021 at 14:00:59 UTC. [Namespace rules](https://docs.nemtest.net/en/textbook/namespaces/), [pinned expiry condition](https://github.com/NemProject/nem/blob/8de7b16dd2ec88faf7215b6737ceb7ab231e21e1/core/src/main/java/org/nem/core/model/namespace/Namespace.java), [last renewal](https://explorer.nemtool.com/#/s_tx?hash=f014ae53b02234221dbf94bc63ef1cf56a49ddb051d912bb7a46a3ee2bd5628b).

Historical KID allocations on the visual map are consequently **historical ledger positions, not presently spendable KID balances or cash values**. The October 2021 issuer-control changes occurred after the original token's inactivity and do not renew the namespace.

## Confirmed lifecycle chronology

Dates below use block inclusion, not transaction creation timestamps. All five registration/definition transaction objects occur exactly once in their stated blocks on each node; complete returned blocks are identical between the two nodes.

| Event | Block | Confirmed UTC | Transaction |
|---|---:|---|---|
| Original namespace registration | 1,580,133 | 2018-04-09 05:07:37 | [5b318ecd…](https://explorer.nemtool.com/#/s_tx?hash=5b318ecdc1d6b79489174a2abcc8c64f208fd07d90b3ffbc2052bc1c4946835e) |
| Original 21-million KID definition | 1,580,152 | 2018-04-09 05:35:06 | [7f8910e2…](https://explorer.nemtool.com/#/s_tx?hash=7f8910e2fa04ef06ea233fd6d56f97a621095a3f0c225e6c813787d2007baddd) |
| First lease expiry, derived | 2,105,733 | 2019-04-12 04:17:31 | No transaction; registration height + 525,600 |
| Same-issuer renewal within grace | 2,137,262 | 2019-05-04 05:38:06 | [8e956d31…](https://explorer.nemtool.com/#/s_tx?hash=8e956d31acd8b7d7d8a3ab2dcca098bf3e0471ad153eeca6c9d8345071428312) |
| Description-only update | 2,137,280 | 2019-05-04 05:59:47 | [250b0463…](https://explorer.nemtool.com/#/s_tx?hash=250b0463c72bc6e1322d5e8bc3a5f726bc2094bebc5c9fb6d1a1635ad6b7610b) |
| Last issuer renewal | 2,652,960 | 2020-04-29 06:33:31 | [f014ae53…](https://explorer.nemtool.com/#/s_tx?hash=f014ae53b02234221dbf94bc63ef1cf56a49ddb051d912bb7a46a3ee2bd5628b) |
| Final lease expiry, derived | 3,178,560 | 2021-05-02 07:44:17 | No transaction; last renewal height + 525,600 |
| Grace-period boundary, derived | 3,221,760 | 2021-06-01 14:00:59 | No transaction; final expiry height + 43,200 |

The 2019 renewal occurs 31,529 blocks after the initial expiry, within the 43,200-block grace period. Because the same issuer renewed and did not change mosaic properties or levy, it preserves the original asset's continuity; this is not evidence of a second 21-million supply.

## Historical and current control

Every returned control event was replayed in height order. All five reconstructed current key sets and signature thresholds match both nodes' current account responses. Seven control events were independently checked against exact public blocks on each node. The source history counts are issuer 780, staging 5, distributor 12, development 9 and education 3, each ending in an empty pagination response.

| Wallet | During 2–11 June 2019 | Current state | Common NBDCOH… key during contest |
|---|---|---|---|
| Issuer NC7HKO… | 2 of 2 | 1 of 1, NAWYC… | Absent |
| Staging NADLLJ… | Ordinary single-key account | Ordinary single-key account | Different key |
| Distributor NC6JT7… | 3 of 6 | 3 of 6 | Present |
| Development NA5JKI… | 3 of 6 | 3 of 6 | Present |
| Education NDSTP4… | 1 of 6 | 1 of 6 | Present |

No control change occurred within 2–11 June 2019. Assigning a key as a signer is distinct from that key signing a transaction: the common NBDCOH… key does not initiate or cosign any of these seven control modifications. Six keys do not establish six independent people. [Distributor state](https://nem01.symbol-node.com:7891/account/get?address=NC6JT7YGYASHVZ2NNS4TK372PTDXBUS354XG7TL4), [development state](https://nem01.symbol-node.com:7891/account/get?address=NA5JKIQRYPQ6XB3BT2NQWY4SYH4L6Q43OKVKG2PS), [education state](https://nem01.symbol-node.com:7891/account/get?address=NDSTP4YZPMGACPKS26PV4U4VX63WZRD76UNB7IRL).

The identical shared six-key set consists of NBDCOH…, NCEUKZ…, NBLIIT…, NCM2QK…, NDMV5M… and NCJHET…. Its membership is reproduced in full in `control-replay.json`. The education wallet's one-signature threshold establishes that any one of these keys could authorize a transaction; its three-record history contains no outgoing transfer, so authority must not be depicted as an executed payment.

Issuer control changed in three steps on 20 October 2021: at 08:19:02 UTC it added NAWYC… and reduced the threshold from two to one; at 08:33:47 it removed NBLIIT…; at 08:35:33 it removed NCEUKZ…. The latter two transactions were initiated by the newly added NAWYC… key. These are wallet-control movements, not payments or asset reactivation. [First change](https://explorer.nemtool.com/#/s_tx?hash=9df67ddcb69b04ca0c8ad298e4dae72d84d01250d0a17d24f216ece3e4e9c40c), [second change](https://explorer.nemtool.com/#/s_tx?hash=855080ea02e139352cca651edf88ec70cb4acef1a96eccfb2d2c782748236dea), [third change](https://explorer.nemtool.com/#/s_tx?hash=1a8e688fb672744ec7ad57152bbf7be698c5ded4ac1dec597d9c5c9a3aaef8fa).

## Scope corrections for financial maps

The issuer was not used exclusively for KID. Its history also contains registration/renewal of the `loyalcoin` namespace at heights 1,486,170, 1,974,311 and 2,527,336. This supports labeling its wider XEM flows as **activity of a wallet used by KID**, rather than declaring every XEM receipt or payment to be KID project revenue or expenditure. It does not itself establish any relationship with a similarly named business or person. [Original other-namespace registration](https://explorer.nemtool.com/#/s_tx?hash=7729be9a602a5797bbebc9b5d2ff0356ae166956ee1c033b7f909fe62824fb74).

Both KID definitions set an absolute levy of **10 atomic XEM units = 0.00001 XEM**, to NCEUKZ…, per KID transfer. This is not a ten-XEM charge, percentage, child-data revenue stream or fiat amount. Automatic levies are separate from a transfer's explicit recipient and may not appear as separate transfer rows. Any map of fees should handle self-paid levies as zero net movement for the same address. [Historical definition](https://nem01.symbol-node.com:7891/mosaic/definition/last?mosaicId=kidlet:kid), [levy calculation reference](https://docs.nemtest.net/en/textbook/mosaics/#how-levies-are-charged).

## Verification limits and retained evidence

This is a consistency check of histories, historical transaction objects, public blocks, current state and pinned protocol code. It is not an independently operated full-consensus node replay or local cryptographic verification of every signature. The two queried hosts share a domain; matching their responses strengthens reproducibility but does not demonstrate independently administered infrastructure.

The new local historical-supply and expired-mosaic endpoints exist in NIS1 0.6.102, but the node correctly rejected remote access with HTTP 401. No bypass was attempted. Consequently the precise inactivity height is derived from the published protocol and complete issuer rental history; it was not obtained from a node's private historical-supply endpoint.

Retained evidence: `lifecycle-replay.json`, `control-replay.json`, current query responses, five node2 account states, source files pinned to commit `8de7b16dd2ec88faf7215b6737ceb7ab231e21e1`, and paired node block JSON for the material transactions and derived lifecycle heights. Source histories and node1 current account states reside in the parent `histories/` and `accounts/` directories.
