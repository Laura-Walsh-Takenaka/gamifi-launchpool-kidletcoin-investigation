# Research Paper — Offshore company number search — 6 September 2026

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

## Result

A commercial BVI company directory, i-BVI, lists a **Launchpool Ltd**, registration number **2054898**, registration date displayed **12.02.2021** (12 February 2021 in the directory day.month.year convention).

- Verified detail URL: https://i-bvi.com/company/launchpool-ltd_1123236
- Search URL: https://i-bvi.com/search?q=Launchpool
- Alternate search URL: https://i-bvi.com/search?q=Launch%20Pool
- Both observed searches return one match, the same company.
- Citation reference available from the historical search: historical retrieval. The source was independently opened during the historical research.
- Evidence classification: **secondary-source company-number candidate**. This is not an official registry extract or an established platform-to-company match.

The directory does not establish any registered agent, director, shareholder or owner on the free page. It lists paid document products; no purchase, cart addition or contact was made.

## How discovered

Search-index snippets of two unrelated company pages contained rotating related-company links naming LAUNCHPOOL LTD:
- https://i-bvi.com/company/magnet-global-corporation_862619
- https://i-bvi.com/company/sorgall-company-inc_449251

These related-company recommendations are not business relationships. Opening the directory search and entering Launchpool yielded the candidate detail page. The unrelated companies have no evidential relationship to Launchpool from those links.

## Verification boundary

Exact-name and exact-number searches with Launchpool, Launch, BVI, and Gazette did not supply independent official corroboration. The previously encountered official BVI registry browser block was respected; the blocked site was not retried or bypassed.

The archived Launchpool terms use both Launchpool Limited and Launch Pool Limited. The candidate uses Launchpool Ltd. The candidate date should not itself be used as proof that it is the platform company. Earlier terms captured in May 2021 display a January 2021 revision date, preceding the directory incorporation date; because that capture is later than both dates, it does not prove a contemporaneous contradiction.

## Concrete manual verification task

Use official BVI company-search guidance already read in the associated research:
- https://www.bvifsc.vg/searches-bvi-registered-entities
- https://www.bvifsc.vg/public-search

The guidance describes fee-based company search, not necessarily a free interactive company directory. A historical candidate number is a search lead; the available record product and access requirements should be verified on the official registry website.

The required result is a company extract containing exact current and former names, incorporation date, status, and registered agent, plus available director filings covering 2021–2024. The primary target is registration identity. A company profile or director list alone should not be described as a beneficial ownership certificate.

For name searches use **LAUNCHPOOL LTD**, then **LAUNCHPOOL LIMITED**, then **LAUNCH POOL LIMITED** if the first spelling produces no result. Include historical/inactive entities if such a filter exists; exact field labels and screen flow were not verified because the official browser was blocked.

## Preserved evidence

- launchpool_bvi_2054898_directory_20260906.jpg — screenshot of company header and offered documents.
- launchpool_bvi_2054898_directory_20260906.txt — observed browser DOM snapshot.
- candidate_record_receipt.json — observation receipt and source classification.
