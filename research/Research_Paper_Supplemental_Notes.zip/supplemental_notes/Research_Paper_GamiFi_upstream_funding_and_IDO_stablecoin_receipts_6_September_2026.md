# Research Paper — GamiFi upstream funding and IDO stablecoin receipts — 6 September 2026

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

## Verified result

The archived GamiFi app identifies `0x56c0cb2d047b69278f49b4759c1718436a546c7f` as its project contract. Successful BNB Smart Chain transaction receipts independently establish **seven withdrawals totaling 63,001.817377359365034843 BUSD** from that contract. The total equals the sum of its nine current project records' `fundedTotalAmount` counters. This is a reconciliation of those seven withdrawals and current counters, not a complete lifetime audit of all token movements, all investor deposits, other contracts, or off-chain business revenue.

The four withdrawals for project IDs 6–9 total **60,639.317377359365034843 BUSD**. Project IDs 1, 3 and 4 account for another 2,362.5 BUSD; their early, small, test-like parameters mean they should remain separate until their commercial purpose is documented. This lane does not independently map project IDs to project names.

Every withdrawal in projects 4, 6, 7, 8 and 9 was initiated by `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`, the previously verified vesting/NFT deployer and Launchpool vesting deposit payer. This establishes an operational blockchain link. The address's individual or organizational key owner remains unidentified.

## Actual BUSD withdrawals

All rows below have receipt `status=0x1`, a canonical BUSD `Transfer` log from the project contract to the listed recipient, a corresponding project `WithdrawFunding` event, calldata `withdrawFunding(projectId)`, and a timestamp independently checked against an official BNB RPC block header. BUSD contract: `0xe9e7cea3dedca5984780bafc599bd69add087d56`; displayed units use 18 decimals.

| Project ID | UTC | BUSD transferred | Recipient | Transaction |
|---|---|---:|---|---|
| 1 | 2022-03-10 15:25:05 | 252.5 | `0x8fea0bb760218398d32d4a9ef18553c403e3c2a0` | `0x4b0b66e2f020479b6381a1b31be240bfb86347cf1813ddb520c094576e6158df` |
| 3 | 2022-03-11 09:35:55 | 110 | `0x8fea0bb760218398d32d4a9ef18553c403e3c2a0` | `0x4389510604c93f928c4e1a2f6fda07979d792228de1b6bb66a8242a7a7ee05b5` |
| 7 | 2022-03-18 06:58:39 | 23,722.715761539594859905 | `0xd2b806f9c0352a267ce7ccf33e74d68c070d6171` | `0xa68d28501388dd1939659be1a24f6fbed8c0c22d6df5bbe43196ff408b3ffba4` |
| 6 | 2022-03-18 12:23:52 | 28,421.141280969119319259 | `0x56aa83035aea8bfeb9e395a51607cc4621649aa2` | `0x4e2b2cebb9895bb8ed1ffa817e730273d9271e97e559a2fdd7ba2d4e86fd5299` |
| 4 | 2022-03-23 14:58:07 | 2,000 | `0x35b119730f79881dac623dc51c831c6a04cab5f3` | `0x33f6c2ae7893cf8763b5306d4220780592390cc22ab9399034f4b3ac6ee09683` |
| 8 | 2022-05-23 11:50:16 | 3,775.228767123287671432 | `0x56aa83035aea8bfeb9e395a51607cc4621649aa2` | `0xfb51cbbf265af6b604ba3499d1608f36ab04a57eb3a71a4d5cbe3c6fe807d780` |
| 9 | 2022-06-22 08:29:58 | 4,720.231567727363184247 | `0x56aa83035aea8bfeb9e395a51607cc4621649aa2` | `0x757fe0ce1d898fff34b0d4c4f58f2fc7610d3821eacc51c43d7e7e6ac0edcf63` |

The repeated recipient `0x56aa…` received **36,916.601615819770174938 BUSD** across projects 6, 8 and 9. It is presently an unidentified recipient, not a verified personal wallet or verified bank account. Project 7's different recipient received 23,722.715761539594859905 BUSD.

These are actual stablecoin amounts. If expressed as approximate US dollars using a one-dollar BUSD reference, label that conversion explicitly. This lane did not retrieve a historical BUSD/USD market quote or prove bank redemption, fiat proceeds, profit, or loss. The exact asset transferred was BUSD on BNB Smart Chain.

## Source of April 19 Launchpool funding

At **2022-04-19 13:32:12 UTC**, block **17,082,611**, successful transaction `0x00f1ad6f5d7560d5325d08d0afcf253a99b46d588a6509abb37349bacdea965f` transferred **15,456,876 GMI** from `0x78d09e1435e1906878621bcb0aaa9d47561214c3` to the deployer/deposit-payer address `0x3e0f4c7bdbf9bcc4aa9f22b3d03048b3ef2d7199`.

The sender directly called the canonical GMI token. Its GMI `Transfer` log is independently verified from an official BNB RPC receipt. The number is the public allocation CSV total 15,456,875.882908530406846 rounded up to a whole token; that numerical relationship is an observation, not an independent attribution of source ownership.

At **2022-04-19 16:19:46 UTC**, block **17,085,953**, successful transaction `0x19d1cd7e49be9a4226dec5323cc5bc8c36a6e465dceec4fb70fa3f598b019bfd` transferred another **5 GMI** from `0xe5d5245dce768ef43f1c5fa9c96b7e1520d96dc8` to the same deployer. The query covered GMI transfers into this deployer during blocks 17,077,000–17,086,999; it is not the deployer's complete history.

Previously verified later April 19 deposit transactions connect this deployer to the Launchpool vesting contract. The new source address is a concrete upstream lead. Its source of GMI, funding agreement and ownership remain unverified here.

## Current control and qualified candidate links

Official BNB RPC current-state calls at block **120,224,737**, corroborated on the QuickNode public demo endpoint at block **120,224,859**, returned:

- Project contract `owner()`: `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b`.
- `gmi()`: canonical GMI `0x93d8d25e3c9a847a5da79f79ecac89461feca846`.
- `busd()`: canonical BSC BUSD `0xe9e7cea3dedca5984780bafc599bd69add087d56`.
- `memberCard()`: `0x0be0e13c828b60b53d7577651cc54581855f7bad`.
- `latestProjectId()`: 9.

All nine records were separately retrieved at block **120,224,903** and decoded using the official archived app ABI. IDs 2 and 5 report zero funding; the other seven report the exact amounts above and a withdrawal flag.

At block **120,225,773**, addresses `0x78d09…`, `0x56aa…`, `0xd2b806…`, and `0x35b119…` had no deployed code. This does not identify who controls their keys.

The separately preserved candidate `MemberCard.sol` has `treasury = 0x35b119730F79881DAc623dc51c831C6A04cAB5f3` in its initializer. That equals project 4's withdrawal recipient. Candidate runtime/source identity and historical actual treasury state were not verified in this lane, so it is a lead rather than a verified additional operational role. Project 4's funding receiver was `0x8fea…` at block 16,222,560 and `0x35b119…` by the withdrawal; its change transaction remains to be located.

## Evidence and method

- Official archived frontend: https://web.archive.org/web/20220420121112id_/https://app.gamifi.gg/_nuxt/f76e883.js — existing preserved artifact `contract_trace/attribution/f76e883.js`, SHA-256 `625120707c8c8505a1794be03015d7dab4e03ec99df70502bf9aff6221d8008c`. ABI extracted to `project_abi.json`; provenance saved `source_manifest.json`.
- Public RPC discovery/history: `https://docs-demo.bsc.quiknode.pro/`, bounded `eth_getLogs` queries and read-only historical `eth_call`. Blocks of 100,000 returned HTTP 413; smaller blocks succeeded. Some concurrent calls returned HTTP 429; those failures are preserved. Later log requests used the shared rate gate.
- Independent canonical receipts, transactions and block headers: `https://bsc-dataseed.bnbchain.org` using `eth_getTransactionReceipt`, `eth_getTransactionByHash`, `eth_getBlockByNumber`.
- Raw requests/responses are timestamped per file. `receipt_<tx>.json`, `tx_<tx>.json`, `block_<number>.json` are primary response records. `receipts_decoded.json` and `transfers.csv` are derived; `decode_receipts.py` reproduces decoding.
- Current `https://raw.githubusercontent.com/sheandev/gamifiContracts/main/contracts/Project.sol` was retrieved as a candidate. Its API differs from the archived ABI and was **not** treated as a verified match to deployed runtime. Receipt conclusions do not depend on that candidate's implementation.
- Broad address search yielded no reliable ownership attribution. Failed explorer opens are not treated as evidence. No bank account, individual receipt, wrongdoing, or Cayman connection is established by this lane.
