# Research Paper — MegaFans / MBUCKS — expanded history and promotions

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Review date: September 5, 2026 UTC. This supplements `volume_megafans_notes.md`; it does not replace the earlier decoded transaction records.

**Disposition:** Incentive-heavy marketing and unresolved disclosure issues are documented. Artificial trading volume or a recurring wash-trade sequence in MBUCKS remains unproven. No new company claim of a particular trading-volume total was located to compare against the same historical window. Accordingly, the earlier Kaskade finding cannot be transferred to this company.

## 1. Broader, reproducible pool coverage

Exact BSC token: `0x3638fea0c645b1aa79db706fab6e8a761385c390`.

At block **120150826**, **2026-09-05 17:30:16 UTC**, hash `0xf4b1ed78d6321b6360a2586449b8b998354493c30b2c087d3a51b1778e8384bb`, direct public RPC calls tested twenty factory combinations:

| Factory | Quote tokens | Fee tiers | Result |
|---|---|---|---|
| PancakeSwap V2 | WBNB, USDT, USDC, BUSD | V2 | Only WBNB returned a pair |
| PancakeSwap V3 | Same four | 100, 500, 2500, 10000 | All sixteen returned the zero address |

The single returned pool is the previously decoded `0x5282c0ea15348dfa64a8a2690e0cb770e56a72dc`. A separate positive-control V3 lookup of WBNB/USDT at fee 500 returned `0x36696169c63e42cd08ce11f5deebbcebae652050`; this checks the selector and response decoding. All twenty MBUCKS queries succeeded at the same stated block.

**Meaning:** This narrows the common PancakeSwap V2/V3 pool universe to one verified pool. It does not exhaust other quote tokens, fee tiers, DEX factories, PancakeSwap Infinity, chains, centralized exchanges, or historical token migrations.

Primary references: [V2 factory addresses](https://developer.pancakeswap.finance/contracts/v2/addresses), [V3 factory addresses](https://developer.pancakeswap.finance/contracts/v3/addresses), [PancakeSwap quote-token list](https://raw.githubusercontent.com/pancakeswap/token-list/main/lists/pancakeswap-extended.json). The quote list identifies the BSC pegged versions; it should not be read as an issuer guarantee of peg or redemption.

Saved: `mbucks_history_raw/coverage_factory_results.json`, labels, block-number response, quote addresses, positive control. `check_pools.py` reproduces public reads; `validate_coverage.py` verifies saved results offline.

## 2. What the historical trade coverage actually contains

The previous investigation directly decoded successful pair swaps on July 29, 2024; November 15, 2024; and August 20, 2026. These are **three purposively located examples**, not an exhaustive tape or statistical sample. The November transaction also contains a separate liquidity burn. The August transaction is the last reserve update identified in the September 5 snapshot of this pair. None of these three examples supplies a repeated buy/sell loop.

Raw receipts in `volume_megafans_raw/` preserve exact times, addresses and event amounts. Token transfers, LP burns, claims, deposits and swaps are separate event classes. The August transfer-sum calculation of 5120 MBUCKS versus 2432 actually swapped illustrates possible accounting error; **no evidence shows MegaFans or an index used that erroneous counting method**.

A full historical candle request was attempted against TradingStrategy's documented API, for the exact pair ID 3702117, with daily intervals and a bounded three-megabyte response. Pair-details, candles and data-availability requests returned HTTP403. The [official specification](https://github.com/tradingstrategy-ai/spec/blob/main/open-defi-api.yaml) explains that missing candles can mean no trades and provides a separate freshness endpoint, so missing data must not be treated as zero volume. GeckoTerminal's public API-guide retrieval also returned403. Requests stopped; no route, fingerprint or authentication changes were used.

No complete transaction sequence, historical dollar-volume series, round-trip frequency, wash-volume percentage, complete holder ledger, or centralized-exchange account records were obtained. Known BscScan/DEX Screener security blocks and BNB RPC historical-state/log limits remain as recorded in the preceding review.

## 3. Dated promotion chronology

| Date / observation status | Promotion | Evidential assessment |
|---|---|---|
| November 20, 2021 publication | [Launchpool Labs AMA](https://launchpoollabs.medium.com/launchpool-ama-recap-megafans-d826664eda5c) discusses mobile games, crypto prizes and future token-linked participation. | Partner-published statements by named founders. No contemporaneous MBUCKS market-volume result. |
| February 16, 2023 indexed post | [Company post](https://x.com/MegafansGaming/status/1626303068693299204) anticipates MBUCKS trading following a future TGE. | Search excerpt only; establishes promotional anticipation, not an executed launch. |
| May 17, 2023 indexed post | [Company Candy Boo promotion](https://x.com/MegafansGaming/status/1658776644608294913) advertises PEPE prizes. | Promotional prize asset is distinct from MBUCKS trading volume. Payouts unverified. |
| May 29, 2024 | [Company-issued press release](https://www.prnewswire.com/news-releases/megafans-launches-and-lists-token-mbucks-on-binance-smart-chain-302158231.html) announces launch/listing on BSC, predicts June MEXC/PancakeSwap availability and also calls the launch upcoming. | Chain deployment and exchange admission are different. No matched official MEXC or Binance spot-listing notice was found. Wording requires chronological clarification. |
| June 24–26, 2024 | [Spores launchpad](https://launchpad.spores.app/ido/megafans-ido), read in the live browser, displays a $0.14 sale, $150,000 target filled, June 27 listing, 15% TGE release and five-month daily vesting. | A venue's historical offering display; actual settlement, refunds and vesting execution require receipts. |
| June 26, 2024 indexed post | [Company flash-sale post](https://x.com/MegafansGaming/status/1806186320143999032) thanks Spores for a second round and urges purchases. | Company account promotion; Laura's authorship is not established. Full post fetch returned403. |
| June 27, 2024 indexed posts | [Company](https://x.com/MegafansGaming/status/1806401684668907988) and [Launchpool](https://x.com/LaunchPoolXYZ/status/1806405186212040798) announce claiming at 19:30 UTC. | Claim availability is distinct from an exchange trade. |
| July 8, 2024 indexed post | [Company Play to Burn post](https://x.com/MegafansGaming/status/1810441460891705652) refers to the second week of a Candy Boo tournament. | Token-reduction theme warrants checking burn receipts; the excerpt does not establish executed burns or wash trades. |
| Undated page; copyright2024; observed September5,2026 | [Company staking page](https://www.megafans.io/staking/index.html). | See rate and contract table below; copyright year does not establish launch date or current availability. |

Search engines also returned unrelated mBucks reward apps, similarly named tokens and generic exchange articles. These were excluded. The Spores site's header addresses are **SPO**, not MBUCKS; they must not be copied as this project's token identifiers.

## 4. Specific promotional checks

### Staking claims

The [staking page](https://www.megafans.io/staking/index.html) advertises a maximum **150% APY**, describes returns as guaranteed, then labels the individual rates **APR**. APR/APY terminology is inconsistent; realized compounding and rewards were not decoded. Token returns are not guaranteed dollar gains. Closed labels coexist with two active-looking liquidity-staking links; live deposits were not tested.

| Published pool | Rate label | Maturity | Published Ferrum link |
|---|---:|---:|---|
| BigFan | 60% APR | 45 days | [0xdd1595de28b28d64b40803c9713f1ab33f47b173](https://stake.ferrumnetwork.io/megafansbsc/info/0xdd1595de28b28d64b40803c9713f1ab33f47b173/BSC) |
| SuperFan | 100% APR | 90 days | [0xbf7e1ab7ea1f919dcce748e7d187f5d3d052abce](https://stake.ferrumnetwork.io/megafansbsc/info/0xbf7e1ab7ea1f919dcce748e7d187f5d3d052abce/BSC) |
| MegaFan | 150% APR | 180 days | [0x2de19777f66f508173b392ed982b3d485f04ae38](https://stake.ferrumnetwork.io/megafansbsc/info/0x2de19777f66f508173b392ed982b3d485f04ae38/BSC) |
| Liquid Gold | 50% APR | 90 days | [0xbf4eddefd40793ac0a6dae8fa322411926c57e17](https://stake.ferrumnetwork.io/megafansbscliq/info/0xbf4eddefd40793ac0a6dae8fa322411926c57e17/BSC) |
| Liquid Diamond | 100% APR | 180 days | [0x6929ab39442de298f58afcda3cd36ee3481a7e7c](https://stake.ferrumnetwork.io/megafansbscliq/info/0x6929ab39442de298f58afcda3cd36ee3481a7e7c/BSC) |

Linked Ferrum pages returned502. Direct BSC reads found nonempty 3,767-byte code at each linked address (`staking_code_results.json`). Contract existence is verified; reward execution, solvency and behaviour remain untested.

### Buybacks and sales disclosures

[Republic's campaign](https://republic.com/megafans) assigns 45% of net profits to token buybacks for rewards and possible burns. This is an advertised economic policy, not evidence of completed buybacks. The same page warns that additional sales/airdrops can depress price and plans an unrestricted 75,000-token PancakeSwap allocation. Its campaign was withdrawn with investments refunded. Those disclosures are material counterevidence against portraying all dilution or downside as undisclosed. The company investor homepage repeats the 45% policy in indexed text; a current live origin read failed.

### Spores valuation basis

The [Spores page](https://launchpad.spores.app/ido/megafans-ido) displays initial circulation **4,001,500 MBUCKS** and initial market cap **$259,910**. At its displayed **$0.14** price, ordinary multiplication gives **$560,210**. The smaller cap implies **1,856,500 tokens**, a **2,145,000-token** difference. No readable explanation was located; overview tokenomics images returned404. Retain this as an unresolved calculation-basis issue, because a convention excluding a token category could explain it. Do not infer deliberate deception.

The offering UI remains stronger for its own displayed dates than aggregator pages giving an earlier May28 end date. Aggregator fundraising totals and January2025 sale dates were not adopted as receipts or verified additional sales.

## 5. Laura-specific boundary

[Laura's professional-profile excerpt](https://ca.linkedin.com/in/lauralwalsh) self-reports advising and early seed investment from May2022. No independently verified appointment contract, trading wallet, market-making instruction, paid-promotion agreement, buyback authorization, or authorship of the reviewed MegaFans posts was located. A third-party people database repeating her title is not independent corporate appointment evidence.

## 6. Questions the evidence supports investigating

1. What are the complete Swap logs, starting at pool creation, and what other pools or centralized venues existed? Needed for repeat-cycle and ownership-cluster statistics.
2. Which transactions implement claimed buybacks, burns, staking payouts and vesting, and what net-profit accounts authorize the 45% calculation?
3. Why does the staking copy alternate APR/APY and describe returns as guaranteed? What token-denominated formula and risk disclosures governed each pool?
4. What denominator produces the Spores initial market-cap figure? What historical sale, refund and vesting records reconcile the displays?
5. Did any person pay, direct or authorize misleading promotion or artificial trading? Title alone does not answer this.

No full-history audit, criminal-trading conclusion or personal attribution is asserted. New raw RPC responses and factual promotion extraction are saved in `mbucks_history_raw/`; full copyrighted promotional pages were not saved for distribution.
