# Research Paper — Beacon route recovered: BSC → Beacon → BSC → Gate-labeled endpoint

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.

The prior 895.83779264-BNB TokenHub request now matches official Beacon explorer Oracle claims by exact source-event sequences and transfer fields. The subsequent Beacon transfers, return to BSC and onward payments reach a BscScan-labeled Gate endpoint. This is a branch funded by two observed Tornado recipients with other assets and activity. It is not an identified GamiFi deposit-note exit or an exclusively Tornado-funded amount.

## Source bridge

Successful BSC request `0x6c10184394ef98643836332ff8f5de707bcf81eeeea208f8053a0fa4ee14fe1d` has global sequence 3,717,577, channel 3 and channel sequence 4,792,146. Eight successful Beacon Oracle claims at 05:13:49.599–05:13:51.281 UTC on July 29, 2022 contain the same amount, recipient, refund address and expiry. They are eight validator attestations for **one package**, not eight payments.

Recipient `bnb1vjs2l4m5rq9h09krqxtm35g9kpxe4us7m505y6` sends 1 BNB and 894.83764264 BNB to `bnb18frgpxceqgc5d7zkyksexv6ggdrw9qfegmpnnk`. These payments plus 0.00015 BNB in transaction fees reconcile to the original amount. The second address requests 895.83356764 BNB back to BSC address `0x818e3620d92f291bafbea8595c9d4b1ced50f9a9`. Its selected arithmetic leaves a 0.004-BNB difference after the reported 0.000075-BNB transaction fee.

The official explorer returns two and three normal-history rows for the two Beacon addresses, respectively. Current balance arrays are empty. No independent historical Beacon state or consensus replay was performed.

## Return bridge

The successful BSC return transaction `0x970cdd09ded344fda3e12c93f5ee9053e8f2dfc6df7855c5e930b7133e3d8e16` contains an RLP package matching all six Beacon request fields: BNB symbol, zero token contract, amount, EVM recipient, raw Beacon refund address and expiry. The actual TokenHub credit event independently confirms the recipient and 895.83356764 BNB amount. The source height in calldata is 256,702,331; BSC channel 2 sequence is 17,466,312.

The raw Beacon refund bytes are `3a46809b19023146f85625a19333484346e281398`. They are used only for protocol matching, not as an EVM same-key ownership inference. The match is by the six-field package, rather than a source-transaction-hash field.

## BSC onward payments

| UTC | Sender → receiver | BNB | Transaction |
|---|---|---:|---|
| 2022-07-29T05:18:24+00:00 | 0x818e3620d92f291bafbea8595c9d4b1ced50f9a9 → 0x850d187268e0b44d9f3256c3b94e3a2eefd7cdad | 10 | [Explorer](https://bscscan.com/tx/0x1be586cb0040e1732d7906f2067bc3b7f23b3b718c5a5f68759fef2d7de03c4a) |
| 2022-07-29T05:18:48+00:00 | 0x818e3620d92f291bafbea8595c9d4b1ced50f9a9 → 0x850d187268e0b44d9f3256c3b94e3a2eefd7cdad | 885.83335764 | [Explorer](https://bscscan.com/tx/0xe7d813b30f94956c17c4c5caaa40510b6aa70fcd62ecb07a9ca022e167585710) |
| 2022-07-31T10:09:49+00:00 | 0x850d187268e0b44d9f3256c3b94e3a2eefd7cdad → 0xcf1f346ed5b87f430de78724e3d023d7f45509e6 | 895.83325264 | [Explorer](https://bscscan.com/tx/0x593c8848db3c9777f2c47aaaf226ce36239cb43676279e553c5c711948a533b4) |
| 2022-07-31T10:10:37+00:00 | 0xcf1f346ed5b87f430de78724e3d023d7f45509e6 → 0x3321cc7565bd4f436ffa93c6ac44d99f1c59da76 | 395.8 | [Explorer](https://bscscan.com/tx/0xf348e0b9582ffcb9fae56e192b129a753322cd51d3a99bcc245709b7d53cde49) |
| 2022-07-31T12:32:10+00:00 | 0x3321cc7565bd4f436ffa93c6ac44d99f1c59da76 → 0x0d0707963952f2fba59dd06f2b425ace40b492fe | 395.7998319916 | [Explorer](https://bscscan.com/tx/0x7644e2fc0e50ed64034c4bc07b549f9c680261ff4a3a1cfbc433e0dfd7a5b103) |
| 2022-08-06T14:19:15+00:00 | 0xcf1f346ed5b87f430de78724e3d023d7f45509e6 → 0x3321cc7565bd4f436ffa93c6ac44d99f1c59da76 | 200 | [Explorer](https://bscscan.com/tx/0x1e95af2dca3ce3d860a97b39adac5bd6ce0abd18ad32ae4bec28ad6d3c98789c) |
| 2022-08-06T14:50:09+00:00 | 0xcf1f346ed5b87f430de78724e3d023d7f45509e6 → 0x3321cc7565bd4f436ffa93c6ac44d99f1c59da76 | 300.03293764 | [Explorer](https://bscscan.com/tx/0xa4ddff4343073d682e604cc7e5e77ac75132ca92e7593ac9778aba87d08c5e21) |
| 2022-08-06T16:18:35+00:00 | 0x3321cc7565bd4f436ffa93c6ac44d99f1c59da76 → 0x0d0707963952f2fba59dd06f2b425ace40b492fe | 500.0327696316 | [Explorer](https://bscscan.com/tx/0x345a7605f351123f77b62d2073831d64402b6b68b18db5522187c39b70d40366) |

All nine selected BSC full transactions, successful receipts and block inclusions are verified. Four historical balance equations close. Wallets 818e, 850d and cf1 start and end their selected intervals at zero. Collector 3321 starts and ends with 100002112299 wei.

Gate endpoint payments total **895.8326016232 BNB**. Preserving the collector's old reserve gives a strict route-source contribution range of **895.832601523197887701–895.8326016232 BNB**. Other lifetime collector inputs occur outside this selected interval.

## Attribution and reproducibility

The exact BSC endpoint `0x0d0707963952f2fba59dd06f2b425ace40b492fe` is labeled **Gate 1** by [BscScan](https://bscscan.com/address/0x0d0707963952f2fba59dd06f2b425ace40b492fe). No exchange-published address row or customer identity was recovered. These payments are not added to GamiFi proceeds or losses.

`findings.json` and `analyze.py` preserve exact decoding, arithmetic and source paths. The official Beacon API query returned 56 Oracle-claim rows in the requested 200-second interval; eight match the investigated package. Two cross-chain hash lookups returned 500 and one legacy transfer-in endpoint returned 404. Those failures remain recorded despite the successful protocol-field recovery.

Full frontend HTML/JavaScript bodies may be omitted from the distributable bundle; source URLs, retrieval metadata and hashes remain. Historical TokenHub source in the preceding bundle supplies the six-field decoding specification. Independent review is in *Historical file: beacon_qa.json*.
