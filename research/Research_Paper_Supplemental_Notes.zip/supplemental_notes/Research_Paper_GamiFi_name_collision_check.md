# Research Paper — GamiFi name collision check

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

**Later GamiFi correction.** The 7 September review records repayment of original ShibaFriend principal to all 23 non-dust funding addresses, with only 168 BUSD base units of unmatched dust. All 194 identified paid Mystery Box mints have matching buyer and project burn-address transfers. Original FOMO principal was fully repaid to all 27 funding addresses, and all 127 original GAMI buyers matched their recorded allocations, with remaining recorded allocations backed at the stated block. These results supersede earlier unresolved wording for those exact cohorts and checks; they do not identify a human wallet controller or settle distinct obligations.

Reviewed 5 September 2026 UTC as a check against similarly named businesses. This is a bounded entity-resolution check, not a review of children's data practices.

| Entry | What the retrieved primary material identifies | Link to Laura's GamiFi |
|---|---|---|
| **gamifi.gg / GMI** | The token launchpad in the existing investigation, with official company publications and a February 2022 MEXC interview naming Laura Walsh. | This is the documented project. |
| **gamifi.com / Gamifi Inc.** | Its own site offers learning media, websites and gamification. It identifies **Isinsu as owner**, refers to Gamifi Inc. and describes projects with the City of Ottawa, IRCC and Carleton's School of Industrial Design. | No connection to Laura or the GMI token found in the reviewed sources. Different service and ownership presentation; corporate independence was not exhaustively registry-verified. |
| **gamifi.me** | Its own site sells tournament, leaderboard and reward-workflow tools to operators. The footer names **Manolo-gaming-company**. A public professional post by **Charith Fernando** says he and his cofounder built the platform. | No connection to Laura or the GMI token found in the reviewed sources. Footer wording alone is not an incorporation record. |
| **Facebook /gamificationllc** | A search-result image was the historical lead for the similarly named coding brand. Direct Facebook retrieval was throttled; the exact-handle and exact-name searches did not recover a reliable full profile. The related source notes report a primary search excerpt mentioning an academy in Bangladesh and children aged 8–16; that remains excerpt-level evidence. | Founder, official domain and relationship remain unresolved. Do not merge this page into gamifi.com, gamifi.me or gamifi.gg from the shared name. |

## Primary sources

1. https://www.gamifi.com/ — full page retrieved, tool ref `historical retrieval`; owner statement at lines 89–94, company name in project descriptions. The linked professional page is https://www.linkedin.com/in/isinsus/; direct retrieval returned HTTP 999 and was not used to expand the identity.
2. https://gamifi.me/ — full indexed primary page, `historical retrieval`; footer names Manolo-gaming-company. The displayed leaderboard is explicitly labelled illustrative sample data, so its numbers were not counted as real users or payouts.
3. https://www.linkedin.com/posts/charith-fernando-4034694_gamifime-cloud-platform-activity-7447197454640402432-AgV4 — author's own public post, `historical retrieval`, describes cofounding/building gamifi.me. The display uses a relative date; no exact founding date is assigned here.
4. https://www.facebook.com/gamificationllc/ — direct request throttled (`historical retrieval`); no successful full-page verification in this pass.
5. https://blog.mexc.com/mexc-ama-gamefi-session-with-laura-and-casey/ — existing validated primary GMI/Laura source; should be cited for the actual project connection.
6. https://linktr.ee/GamiFi — an independent Linktree inspection resolved its Facebook link to https://www.facebook.com/GamiFigg-111293688015523, a different public identifier from `/gamificationllc`. Destination retrieval was throttled. This supports distinguishing the official project channel from the screenshot's handle; it does not prove that common ownership is globally impossible.

## Excluded matches

Searches also returned Gamify LLC at gamifygames.org (college learning games), a Russian company using the legal name Gamification LLC, Gamify Studio FZ-LLC, and unrelated gaming/education papers. No identity bridge to the Facebook handle was established; none was adopted as its owner. A shared word, industry term or geographic proximity does not establish common control.

**Usable finding:** the inspected results concern multiple namesakes. It does not establish that Laura's GMI launchpad offered the children's coding classes. The Facebook business requires its own verified domain or organization record before any such attribution.
