# Research Paper — Nativz Gaming / Ireland Esports Leagues / Nemesis — public evidence review

**Historical research note.** This text records the dated research stage described below; it is not a fresh verification on the repository packaging date. Later topic-specific reports and corrections take precedence. Historical working-file titles are research locators, not a promise that every working file is distributed in this edition. Public source URLs, source dates and exact technical identifiers support independent verification.

Reviewed 5 September 2026. Source dates below are publication/update dates, distinguished from the review date. Read-only public-source review; no accounts created, forms submitted, private participant records inspected, or security testing performed. Excludes unrelated Dallas agency Nativz (nativz.io).

## Attribution

[Official team page](https://www.nativzgaming.com/our-team) currently lists Laura Walsh among advisers. It does not assign her operations, privacy compliance, school-programme control, or authorship of the statements below. CEO Kurt Pittman authors the business updates. The review concerns the company's published claims, not proof of personal responsibility by Laura.

## 1. Commercial weakness explicitly acknowledged; promotional framing needs qualification

[2025 In Review, 22 January 2026](https://www.nativzgaming.com/p/2025-in-review)

The CEO describes workplace demand as established and lists a full Company Series launch as a milestone, but also acknowledges that Office Showdown did not achieve commercial success in 2025. Collegiate operations are described as covering basic costs, with the Company Series intended to generate scalable revenue. He reports no capital raised in 2025, characterising that as a deliberate decision. School-pilot delivery was slowed after advisory-committee feedback. Nemesis is disclosed as a lightweight product using Challengermode's engine, operating in production and prepared for early partners. These are specific evidence of an evolving business model and third-party technology dependency; demand and commercial viability are different metrics, so their differing presentation is not automatically dishonest. None establishes insolvency. Marketing-database growth is not revenue. Additional low-priority metric weakness: annual email open rates declined from 47.5% to 43.5%, and click-through from 5% to 3.8%; the company attributes this to migration. (Keep total derivation from this annual source below 200 words in a final report.)

## 2. Delivery postponement confirmed; schools readiness publicly unresolved

[CEO update, 16 April 2026](https://www.nativzgaming.com/p/esports-olympics-to-enc-iel-stepping-forward-making-choices-and-more)

The CEO says lessons from two Company Series pilots prompted postponement of the next tournament to Winter 2026 while prioritising the Schools pilot. This is an explicit delivery change, with management acknowledging limited capacity to advance every opportunity simultaneously. Present this as a revised schedule and commercial execution risk, not a cancelled business or evidence that no events have happened.

[Schools Series homepage, reviewed 5 September 2026](https://schools.irelandesportsleagues.com/)

The page still describes preparation for a 2025/26 pilot and labels that pilot as coming soon. The site markets a structured national school pathway, but the reviewed page supplies neither a completed pilot date nor results. The precise finding is stale/unresolved public launch information; it does not prove a pilot never occurred elsewhere.

[Company Series homepage, reviewed 5 September 2026](https://company.irelandesportsleagues.com/)

Counterevidence: the site carries an Alumni Summer Showdown, says 2026 entries have closed, and links recordings. Do not imply the April postponement stopped all company/alumni activity.

## 3. Clear drafting inconsistency in governing terms

[Terms of Use, updated 27 July 2025](https://www.nativzgaming.com/terms-of-use)

The operator is identified as Nativz Gaming, but section 8.2 requires permission from **EFL Digital** to reproduce certain material without explaining that entity's role. This is a concrete document-consistency problem. Section 5.1 references the UK Computer Misuse Act 1990, while section 12 selects Irish law and courts; cross-border use prevents treating that reference alone as legal invalidity. The terms also contemplate betting facilities and rely on minors confirming parental permission, but neither proves actual betting exposure or actual failure to obtain consent. They expressly preserve statutory rights and require parental permission. These qualifications matter. A conservative final finding should lead with the unexplained EFL Digital reference and describe the rest as drafting/scope questions, not established offences.

## 4. Newsletter auto-enrolment creates a concrete consent-scope question

[Privacy policy, updated 4 April 2026](https://www.nativzgaming.com/privacy-policy)

The controller is identified as Irish company Nativz Gaming Limited, number 700794. Subscribers to Schools, Collegiate or Company publications are automatically enrolled into the overarching IEL newsletter. The policy relies on legitimate interests for that enrolment and provides an independent unsubscribe option. It describes profiling using demographics, inferred interests and third-party inputs, and sharing with defined service-provider categories. It also expressly requires consent before sharing marketing details for another party's direct marketing. The reviewed policy does not separately explain a child-specific profiling workflow. References to stadium visits and season tickets suggest generic sports-policy drafting but do not prove fictitious operations. Questions to resolve: actual signup wording, scope of recorded consent, recipient class, marketing content, controller/processor mapping, and whether children are profiled or only adult organisers.

[Irish Data Protection Commission — direct-marketing consent FAQ](https://www.dataprotection.ie/en/faqs/direct-marketing/consent-explicitly-required-all-cases-electronic-direct-marketing)

The DPC says electronic direct marketing generally requires affirmative consent under Regulation 13, with a limited exception for existing customers subject to conditions including similar own products/services, objection opportunities and timing. Consequently, citing GDPR legitimate interests alone does not settle the separate electronic-marketing rules. Breach cannot be established from the privacy-policy sentence alone: inspect actual messages and consent records before any allegation. Do not presume a Schools newsletter recipient is a child rather than a teacher or parent.

## 5. Data marketing is an express product purpose, but claimed safeguards need operational evidence

[Nemesis product page](https://www.nativzgaming.com/nemesis) — search index lists a last-year crawl; do not overstate freshness.

Nemesis is marketed for competition management, social login, demographic insights, CRM enrichment, targeted marketing and passing gamer data to a newsletter platform. It also asserts GDPR-compliant user access. The page repeats identical descriptions under mismatched headings: Publisher Logins repeats Social Platforms, Platform Analytics repeats Community Management, and Low Latency Performance repeats Newsletter Platform. This is a visible content-quality defect that leaves advertised technical functions poorly explained. A compliance claim on a marketing page is not an independent audit. Equally, data analytics and platform integrations are not themselves evidence of unlawful processing. The production client returned a crawler 403; that is a retrieval limitation, not evidence that users cannot access it or that the software is defective.

## 6. Education/safeguarding claims: public operational detail is thin, not absent safeguards

[Parents FAQ](https://schools.irelandesportsleagues.com/parent-faqs)

The FAQ promises supervised practice and appropriate games, but says the school is expected to arrange the coach/manager/supervisor. It gives no detailed verification or incident-reporting workflow on this page. It correctly acknowledges that the proposed 2027 Esports Olympics will not go ahead, rather than continuing to promise that event. This is a division of responsibility that schools need to understand; it is not evidence of abuse or unsupervised children.

[Teachers FAQ](https://schools.irelandesportsleagues.com/teachers-faqs)

Schools are asked to complete an interest/resources survey, with training and pilot-timeline details to follow. The FAQ encourages controlled practice time, supervision and sportsmanship. It refers to guidelines and soft-skill training, including Skilly. This supports classifying the public offer as still being developed. No access to the actual school agreements, guardian forms or operational safeguards was obtained.

## 7. Substantial counterevidence: actual collegiate competitions and named outcomes

[National-finals announcement, 11 May 2026](https://www.irelandesportsleagues.com/p/ireland-esports-collegiate-series-national-finals-head-to-gamerfest-2026)

The organiser reports over 1,070 students across 15 universities and colleges during the 2025/26 season. It does not supply an audited distinct-person counting method here. That is a metric-definition limit, not evidence of fabricated participation.

[Finals report, 30 May 2026](https://www.irelandesportsleagues.com/p/collegiate-lan-finals-delivered-relive-the-weekend)

The report gives named game champions, match scores and embedded recordings from the GamerFest finals: DCU in Valorant, UCD in League of Legends, SETU in Rocket League and TCD in Counter-Strike 2; UCD won the overall season championship. This is strong counterevidence to a claim that the project consists only of promises. Prize-payout reconciliation, revenue and user-data handling cannot be inferred from these results.

## Ranked conclusions for synthesis

1. Best commercial finding: admitted 2025 Office Showdown commercial failure plus documented Winter 2026 postponement.
2. Best document defect: unexplained EFL Digital reference in Nativz's terms.
3. Best concrete governance inquiry: automatic cross-newsletter enrolment on legitimate interests versus actual direct-marketing consent requirements.
4. Best product-readiness limitation: school pilot still described as forthcoming; Nemesis openly depends on Challengermode.
5. Do not use browser/crawler 403 or stale copyrights as proof of operational failure. Do not attribute these company-level matters personally to Laura without role-specific evidence. Do not characterize the education programme, analytics, rewards or school association as criminal or abusive based on these records.
