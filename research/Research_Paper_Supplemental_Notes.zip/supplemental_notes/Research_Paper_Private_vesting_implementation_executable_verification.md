# Research Paper — Private vesting implementation: executable verification

> Historical research note. Dates, snapshots and access results below belong to the original research period; they are not a current status check. Public roles, wallet control and allegations retain their separate evidentiary status. Local working-file references have been reduced to source titles; consult the repository catalog for included files.
> Later correction: the 7 September ShibaFriend review reconciles all 23 non-dust original funding addresses, with 168 BUSD base units unmatched, and matching project contributions for all 194 paid Mystery Box mints. Earlier refund or mint-coverage gaps below must be read with that later review. The full 120-million-GMI claim amount was also subsequently reconciled; the beneficiary’s human identity remains unresolved.

At BNB Smart Chain block **120,226,470**, proxy `0x74e0ddf89807107378beb02e6bc504243e0cdf6c` selected implementation `0x21ba8b5e4c07f937f4fe887af964581d79f6bb30`.

The candidate `Vesting.sol` reproduces **all 7,847 executable runtime bytes** with Solidity **0.8.7+commit.e28d00a7**, OpenZeppelin **4.4.1**, optimizer **disabled** (runs parameter 200). Complete runtime length is 7,900 bytes. The final 53 compiler-metadata bytes differ; this is an executable match, not an assertion that the original complete build input has been recovered.

The complete deployed runtime SHA-256 is `ad16284a6d2539167c78c70a94b26222d0808ae5efd183f545e6be3172607fce`.

## Confirmed current semantics

- Each `initiateVest` call transfers the schedule's entire amount from the caller to the contract before storing the schedule. The overload without an explicit beneficiary uses the caller as beneficiary. This differs from the Launchpool contract's individual schedule-creation function.
- Any initial release is recorded in `claimed` and transferred to the beneficiary during creation.
- A `claim` call adds the computed claimable amount to `claimed` and transfers the tokens to the named schedule beneficiary. Transfer failure reverts the claimed-counter update. `claimed` therefore includes initial releases as well as later claims under this implementation.
- The numeric `stakeType` is stored and returned but has no category-name definition, enum, access-control meaning or pricing logic in this contract. **Type 5 alone does not identify a seed, private-sale, team, adviser or treasury allocation.**
- No token price, investment paid in dollars, or human owner is established by this code.

## Interpretation of the supplied sample

Independently decoding the saved RPC response in *Historical file: recipient_private_vest.json* yields beneficiary `0x36048413c4edf0cf3e633aab317fcd9824dfb4d4`, amount **120,000,000 GMI**, type **5**, start **18 January 2022 15:56:50 UTC**, initial **0**, cliff **0**, linear period **31,104,000 seconds (360 days)**, and `claimed` **120,000,000 GMI**. The associated nonce getter returns 1, and this record is nonce 0.

The saved state thus records that allocation as fully claimed. This is stronger than the single December payout amount but is still a current accounting field. Independently verified transfer receipts, plus intervening implementation/storage history, are required to reconstruct and corroborate every actual payout. The present executable match alone does not prove an uninterrupted implementation history or exclude alternative past storage changes.

## Evidence

`fixed_code.json` preserves the fixed-block proxy slot and implementation bytecode, exact RPC requests and responses, endpoint and retrieval times. `match_result.json` reports the comparison. `compiler_input.json` embeds every source file; `compiler_output.json` preserves ABI, storage layout and deployed bytecode. `compiler_provenance.json` records compiler version, URL and SHA-256. `verify_private.py` reproduces the bounded compilation checks. `source_provenance.json` records the pinned public-source retrieval and comparison with the supplied candidate.

The compiler executable can be omitted from a deliverable archive because its URL/hash and exact input are preserved. No signed transaction, mutable simulation or exploit test was conducted in this lane.
