"""Third public on-chain pass: original cash pools, ML continuity and control."""
def add_pass3(B):
    def p(t,k='p'):B.append({'kind':k,'text':t})
    def h(t):p(t,'h')
    def h2(t):p(t,'h2')
    def page():B.append({'kind':'break'})
    def table(rows,widths):B.append({'kind':'table','rows':rows,'widths':widths})

    page();h('9.11 Original BSC fundraising pools identified')
    p('<b>The original Mintlayer fundraising contract is now identified, and its six pools record 903,794.346419582485370326 BUSD raised.</b> Recovered public application configuration maps Raise 1 to pools 19-21 and Raise 2 to pools 125-127. Pinned contract reads confirm the funding token and matching schedule blocks. [F32-F33]')
    p('BSC contract: <font face="DVM" size="7.4">0xd975b13cdf91de3aa0e0e888fb827fec3650624a</font><br/>State: block 120,444,465 | 7 September 2026, 06:13:37 UTC','small')
    table([
        ['Raise / pool','Recorded BUSD raised','Funds claimed flag'],
        ['Raise 1 / 19','194,775.268548166718546','True'],
        ['Raise 1 / 20','195,415.21517867104204','True'],
        ['Raise 1 / 21','197,226.626562780028172','True'],
        ['Raise 1 subtotal','587,417.110289617788758','All three'],
        ['Raise 2 / 125','101,799.763199702252300446','True'],
        ['Raise 2 / 126','103,426.318782728639320062','True'],
        ['Raise 2 / 127','111,151.154147533804991818','True'],
        ['Raise 2 subtotal','316,377.236129964696612326','All three'],
    ],[111,264,124])
    p('The owner getter returns the same upstream ML wallet, <font face="DVM" size="7.3">0x77bfe8d704b1948374bf8dab8328a810b2836e66</font>. This establishes its current contract role. The counters are not an independent sum of every investor transfer, and a true claimed flag does not reveal a historical withdrawal recipient or date. Neither the total nor the flags establish missing or stolen funds. [F33]')
    h2('One original purchase independently confirmed')
    p('On 29 November 2021 at 19:02:49 UTC, a successful fundPledge(21) call transferred <b>59.820643332035352 BUSD</b> into this contract and emitted the matching purchase event. The same transaction returned LPOOL staking tokens; that was not a BUSD refund. This purchase belongs within the recorded total and must not be added again. [F34]')
    h2('The remaining cash gap is the withdrawal trail')
    p('Historical Mintlayer withdrawal recipients and onward BUSD transfers remain unrecovered. Section 9.16 now verifies selected withdrawal mechanics from D975 itself. Its full source remains unverified; the different Ethereum contract is not used as proof of its authority. [F32-F33]')
    p('Provenance limits: archived 2021/2022 app code led to public project records read in 2026, last updated in August 2024 and February 2025. These are not unchanged 2021 snapshots. The reward-token field is a TBUSD test placeholder, not Ethereum ML; project attribution rests on the explicit mapping and corroborating schedule/purchase evidence. The 153-pool contract\'s aggregate BUSD balance is not a segregated Mintlayer reserve. [F32-F34]','small')

    page();h('9.12 Earlier ML payments and vesting origins')
    p('<b>The old contract\'s previously unexplained 135,122.08850450400117 ML difference is fully accounted for by 236 successful payments.</b> Public project configuration identifies 0x4d7b...f0a9 as Raise 2, tranche 13, dated 8 November 2024 and displayed as 8.4%. [F32; F35]')
    p('Earlier contract: <font face="DVM" size="7.4">0x4d7b84910d042f5431b156397bff0db5ebb4f0a9</font>','small')
    table([
        ['Verified movement','Exact ML'],
        ['8 November 2024: funding from 0x77bf...6e66','706,395.73825655713798756'],
        ['236 claims, 8 November 2024-6 February 2025','-135,122.08850450400117'],
        ['29 May 2025: return to 0x77bf...6e66','-571,273.64975205313681756'],
        ['Reconciled remainder / pinned balance','0 / 0'],
    ],[277,222])
    p('Two explorer histories agree on all 238 ML events. Every successful claim matches its proof, payment and claimed bit. One additional claim attempt failed out of gas, paid nothing, and was later retried successfully. All 236 recipients also appear in the final 1,999-record ledger: 49 have claimed there, while 187 retain combined final allocations of <b>143,732.0324654474325 ML</b> in the retained final-state census. Different tranches must not be counted as duplicate liabilities. [F35]')
    h2('Withdrawal authority existed without a 2026 wait')
    p('Selected deployed-bytecode analysis establishes an owner check and a withdrawal timestamp threshold. At block 25,923,590, the stored delay is zero and the threshold equals creation: 8 November 2024, 12:20:23 UTC. Read-only simulations agree with the owner restriction. The full source remains unverified; these are bounded runtime findings. The May return is established by its actual transfer, not by the simulation. [F35]')
    h2('The upstream ML now reaches the original vesting tree')
    table([
        ['Direct vesting beneficiary','Total ML received from token contract'],
        ['0x3b883762...1610061','4,201,680.67226891'],
        ['0x752d11a9...5b62562','5,252,100.84033613'],
        ['0xdd923ff5...8bd3695','1,575,630.2521008'],
        ['Combined direct releases','11,029,411.76470584'],
    ],[245,254])
    p('On 21 March 2023, releases to the first two beneficiaries flowed through 0xdd923...3695, which sent 683,000 ML to 0x77bf...6e66 that afternoon. Seven sampled schedules validate against the original or later whitelisted vesting roots. The complete relevant ML ledgers reconcile to pinned balances; inter-wallet turnover is not additional issuance or investor cash. A shared gas/ML counterparty is a lead, not a named controller. [F36]','small')

    page();h('9.13 Dated control handover and settlement wallets')
    p('<b>Launchpool\'s Ethereum fundraising contract changed owner on 11 February 2022 at 08:19:43 UTC.</b> The earlier owner 0xdb7d...fea6c transferred authority to 0x77bf...6e66. The call and ownership event agree, and the pinned current-owner read still returns 0x77bf...6e66. This is a wallet-control chronology, not a management appointment. [F37]')
    p('Ethereum contract: <font face="DVM" size="7.4">0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf</font><br/>Earlier owner: <font face="DVM" size="7.4">0xdb7d1459ddce7887266f25de31f090ff0eafea6c</font>','small')
    table([
        ['Observed control / receipts','Verified result'],
        ['17 May 2021, 10:43:53 UTC','Contract created by 0xdb7d...fea6c.'],
        ['15 fundraising withdrawals in 2021','2,520,862.549169 USDC paid to 0xdb7d...fea6c.'],
        ['11 February 2022, 08:19:43 UTC','Ownership transferred to 0x77bf...6e66.'],
        ['2 July 2024: IAG pools 9 and 10','191,393.685754 USDC paid to 0x77bf...6e66.'],
        ['Complete 17-withdrawal total','2,712,256.234923 USDC; all events match actual USDC transfers and pool bookkeeping.'],
    ],[226,273])
    p('All 21 pools were created in May-July 2021 and use USDC; none specifies the exact ML reward token. These receipts are separate from the original Mintlayer BUSD raises. The deployed Ethereum runtime exactly matches the archived app artifact, corroborating platform attribution. This exact match does not extend to the different BSC D975 runtime. [F32; F37]')
    h2('A repeated settlement link predates Mintlayer')
    p('Four daily fundraising totals received by the earlier owner exactly match eight later transfers to <font face="DVM" size="7.2">0xa594af6496a61423582b19319732e3c7dc072f9f</font>, a wallet that later supplied ML to 0x77bf...6e66. Each pair was 10 USDC plus the remainder, sent after the corresponding fundraising withdrawals. [F36-F37]')
    table([
        ['Date UTC','Matched daily USDC total'],
        ['23 June 2021','459,688.011230'],
        ['5 August 2021','445,769.391270'],
        ['14 September 2021','372,973.160577'],
        ['1 October 2021','387,592.576407'],
        ['Combined eight onward transfers','1,666,023.139484'],
    ],[245,254])
    p('The records support a repeated operational settlement relationship between the earlier fundraising owner and a later ML supplier. They do not provide the earlier owner\'s complete balance history, exclude commingling, identify the purchase mandate, or name Laura as either wallet\'s controller. This matched sum is part of existing USDC flows and must not be added as new fundraising. [F36-F37]','small')

    page();h('9.14 Exchange routes and remaining attribution')
    p('<b>A connected USDC branch now reaches a specifically labeled KuCoin deposit address.</b> After receiving 150,010 USDC from 0x77bf...6e66 on 2 July 2024, 0x1991...86d0 sent three payments to 0x4d0d...a7ee. Each amount then reached Etherscan-labeled KuCoin 20. [F38]')
    p('Sender: <font face="DVM" size="7.3">0x1991e27e2908847c0274a662eb6675002e8386d0</font><br/>KuCoin Deposit label: <font face="DVM" size="7.3">0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee</font><br/>KuCoin 20 label: <font face="DVM" size="7.3">0x58edf78281334335effa23101bbe3371b6a36a51</font>','small')
    table([
        ['Date UTC','1991 to deposit address','Deposit address to KuCoin 20'],
        ['3 July 2024','15,000 USDC','15,000 USDC'],
        ['9 July 2024','50,250 USDC','50,250 USDC'],
        ['14 July 2024','15,500 USDC','15,500 USDC'],
        ['Total','80,750 USDC','80,750 USDC'],
    ],[110,185,204])
    p('All six explorer transaction records show successful matching inputs. Two onward sweeps were transferFrom calls by Etherscan-labeled KuCoin 22. The deposit label and sweeps supply a precise exchange-account mapping lead; customer identity remains unknown. The sender had earlier USDC activity, and its historical starting balance was unavailable. These later payments cannot be assigned exclusively to the July fundraising receipt. [F38]')
    h2('A separate MEXC route and an exact cash reconciliation')
    p('On 2 July 2024, 0x77bf...6e66 sent <b>10,000 USDC</b> to 0x9118...05f9, which forwarded the same amount to Etherscan-labeled MEXC 1 about seven minutes later. Both successful transfer logs were independently checked through RPC. The intermediary\'s complete retained token history contains only these two USDC events. [F38]')
    p('The originating IAG fundraising receipt was 191,393.685754 USDC. Outflows totaled 191,413.685754 USDC: the extra 20 came from two distinct lookalike addresses sending 10 each. Their full addresses differ from the genuine recipient, so they are excluded from operator attribution. The remaining 31,403.685754 USDC passed through 0x3b4d...2eef to 0x78d7...5582. These are separate USDC flows, not original Mintlayer BUSD proceeds. [F38]')
    h2('What this changes for Laura and the deadline')
    p('The evidence now connects original BSC fundraising configuration, current administrative ownership, earlier ML payments, vesting origins and exchange-facing settlement routes. It still does not establish Laura\'s signing key, personal receipt, exchange account or authority over these funds. The examined evidence establishes no automatic 1 November 2026 payment to Laura. The final distributor remains fully backed at the retained 05:45:47 UTC snapshot; section 9.15 now records a later common-block refresh. [F30; F32-F38]')
    p('Specific unresolved records: D975 withdrawal transactions and BUSD recipients; wallet signers and corporate mandates; KuCoin/MEXC customer mappings; complete purchase-to-tranche reconciliation; and actual native Mintlayer delivery. Current job titles, shared funding and explorer labels do not resolve those questions.','small')
    return [
        ('F32','Recovered public project configuration','https://web.archive.org/web/20211122145742id_/https://app.launchpool.xyz/_nuxt/41d2656.js','onchain_pass3/archived_bsc_contracts/: archived app metadata, public project records read 7 September 2026, exact contract/pool and tranche mappings. Records last updated in 2024/2025; stale Raise 2 pricing excluded. Runtime comparison confirms Ethereum artifact match and BSC mismatch.'),
        ('F33','Original BSC pool state','https://bsc-dataseed.bnbchain.org','onchain_pass3/bsc_cash/ and bsc_validation/: exact pinned requests/responses, six amounts/flags, owner and token metadata; independent ABI/arithmetic checks. Block 120,444,465 at 06:13:37 UTC. Historical withdrawal and source acquisition failed; failures retained.'),
        ('F34','Original BUSD purchase receipt','https://bscscan.com/tx/0x56ba03b73564c3c110319c4c056230441b58c89a8cdaff071cfe71afc3912da9','onchain_pass3/bsc_validation/: successful raw receipt at block 13,056,994, 29 November 2021; decoded fundPledge(21), BUSD transfer and PledgeFunded event. Exact contribution 59.820643332035352 BUSD.'),
        ('F35','Old ML claims and selected runtime checks','https://etherscan.io/address/0x4d7b84910d042f5431b156397bff0db5ebb4f0a9','onchain_pass3/old_ml_contract/: two complete explorer histories, 237 valid proofs, 236 payments/bitmap matches, recipient overlap, owner/time checks and independent review. Runtime/state pin 25,923,590 at 06:09:11 UTC. Full source remains unverified.'),
        ('F36','ML vesting origin and wallet crosslinks','https://etherscan.io/tx/0x06293db7ae63be6e47d9159c875d0ba0bd7a4b0c978f4770277c12699b0eb22e','onchain_pass3/ml_upstream/: four ML ledgers, original/later roots and seven verified proof samples, pinned balances, exact 2021 USDC crosslinks. reproduce_verified.py runs offline without full webpage bodies. Full later tree and root registrar remain unrecovered.'),
        ('F37','Dated ownership and complete fundraising census','https://etherscan.io/tx/0x520df656ffe5c57278aafd86977b8fb7e43c58d638c3f2f5dfc756cc77114ecf','onchain_pass3/fundraising_control/: deployment/handover, 21 pools, 17 matched owner receipts and eight later settlement transfers. State pin 25,923,587 at 06:08:35 UTC. All pools use USDC; these are not the Mintlayer BUSD raises.'),
        ('F38','USDC onward routes and exchange-label records','https://etherscan.io/address/0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee','onchain_pass3/usdc_onward/: exact event/calldata records, success checks, MEXC RPC receipts, KuCoin Deposit/20/22 labels and independent review. KuCoin route uses explorer transaction evidence; its raw RPC receipts were unavailable. Historical starting balance is unresolved; customer identity is not established.'),
    ]
