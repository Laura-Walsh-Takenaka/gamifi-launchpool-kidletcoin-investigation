"""Evidence-backed extension to the existing Launchpool follow-up."""
def add_thread(B):
    def p(t,k='p'): B.append({'kind':k,'text':t})
    def h(t):p(t,'h')
    def h2(t):p(t,'h2')
    def page():B.append({'kind':'break'})
    def table(rows,widths):B.append({'kind':'table','rows':rows,'widths':widths})
    page();h('9.6 Laura and the original Mintlayer offers')
    p('<b>The connection is historical platform involvement; no reviewed Mintlayer-specific approval, receipt or wallet-control record names Laura.</b> Nativz dates her Launchpool COO appointment to May 2021. An 8 October 2021 interview identifies her as COO and records her explanation of the Launchpool/Alphabit allocation model. [F17; S15]')
    table([
        ['Dated evidence','What the record establishes'],
        ['22 November-1 December 2021','First Mintlayer offer: 600,000 BUSD target on BSC; $0.0952 per token; 10% at token generation, then 6% monthly for 15 months. Archived opening and closing-day pages agree. [F18]'],
        ['16-23 March 2022','Raise 2 preoffer page targets 350,000 BUSD at about $0.162. It summarizes 20 months, but the launch-week AMA specifies two tranches extending to 34 months. The preoffer page also prints the wrong year. [F19-F20]'],
        ['13 December 2022','Mintlayer announces initial Ethereum ERC-20 distribution for 21 March 2023, followed by a future 1:1 distribution to Mojito wallets. Earlier app pages had advertised native Mintlayer delivery. [F18-F19; F25]'],
        ['By 30 March 2023','Archived Raise 2 page shows a 400,000 BUSD target, a 34-month vesting summary and Ethereum distribution. This dates the recovered page state, not the exact revision or investor agreement. [F19]'],
    ],[125,374])
    p('Advertised targets and stake values are not payment receipts. Those app snapshots did not expose a collection wallet; section 9.11 now identifies the contract and pools through recovered public configuration. The early 20-month summary must be read alongside the 34-month launch-week AMA; the evidence does not establish a post-sale extension from 20 to 34 months. [F18-F20]')
    h2('Named contacts narrow the records search')
    p('The March 2022 AMA names Enrico Rubboli and Andreas Kohl as guests, with a Launchpool host using the name Spiderman. Kohl identifies himself and Sarita Yasmin for investor relations and describes his relationship with Richard and the Alphabit team. The reviewed text does not name Laura. These statements identify contacts, not treasury signers. [F20]')
    p('A 2 March 2023 Mintlayer partnership page names Roxana Nasoi as Launchpool Labs managing director. Laura\'s July 2022 Nativz profile describes separate accelerator-liaison work; her exact COO end date remains unverified. GamiFi\'s September 2022 CEO change does not establish departure from Launchpool. [F17; F26; S18]')
    p('<b>Personal attribution still requires:</b> the Mintlayer deal file, approval/signature records, allocation and payment instructions, management handover and communications showing Laura\'s own role. The search found no such personal bridge.','small')

    page();h('9.7 Withdrawal authority and the funding trail')
    p('<b>The distributor owner can already withdraw the entire ML balance to the fixed treasury. Missing 1 November is not a condition for that power.</b> At the pinned block in section 9.2, owner and treasury are the same address. No retrieved record identifies its human controller or the entity for which it acts. [F06; F21]')
    p('Treasury: <font face="DVM" size="7.4">0x6c2b3a90acb72ef896325e19af9098d157f929c4</font><br/>Deployer: <font face="DVM" size="7.4">0xb72fc236ab043029776b9d25e99a5b6456a2e16d</font>','small')
    table([
        ['Related deployment','Verified difference in authority'],
        ['24 July 2025','0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b: claim/proof/bitmap functions; no owner, treasury or withdrawal function. [F22]'],
        ['25 August 2025','0xcc32853fb709666332cde0fc47f3f74119b970c4: same deployer, ML token and allocation root; adds ownership and withdrawal of the whole ML balance to immutable treasury. [F06; F22]'],
    ],[125,374])
    p('The claim/proof logic is unchanged. Neither source includes a calendar expiry or automatic sweep. Initial history access failed; section 9.10 now records zero balance, zero claim bits and explicit empty transfer history. This remains an earlier related deployment, not a proved operational replacement or a second set of liabilities. The reason for the added authority remains undocumented. [F22-F23]')
    h2('Three incoming ML transfers funded the treasury')
    table([
        ['UTC date / source','Exact ML received'],
        ['2-3 June 2025: unidentified account<br/>0x77bfe8d704b1948374bf8dab8328a810b2836e66','10 plus 1,246,628.736235076904436035'],
        ['26 August 2025, 15:12:11: explorer label MEXC 16<br/>0x9642b23ed1e01df1092b92641051881a322f5d4e','48,011.999999999996854272'],
        ['Combined incoming ML','1,294,650.736235076901290307'],
    ],[305,194])
    p('The combined inflows exactly equals the two bulk October transfers into the final distributor. The separate 1-ML deposit/return cancels. All seven ML events in the retrieved treasury history net to zero; this is event arithmetic, not a new pinned balance read. [F21]')
    p('MEXC-labeled withdrawal transaction:','small')
    p('0xb49e67fb0823b34d8e4864b0a4c442bb27be4959ee28f280e7a10da5e6a3bc8d','code')
    p('The label identifies an exchange hot wallet, not its customer. The transaction gives investigators an exact account/order-mapping target. Initial gas funding of 0.01 ETH came from 0x1aafe5974189e5a854e20617be8176578868da0f on 29 May 2025; shared funding alone does not identify common ownership. [F21]','small')

    page();h('9.8 What happens if a holder misses the deadline?')
    p('<b>No automatic payment to Laura or an identified organization is established.</b> Mintlayer\'s 1 November 2026 notice concerns access to its migration portal. The assets and contracts below have different custody rules. [F08; F21-F24]')
    table([
        ['Asset or stage','Established custody / remaining question'],
        ['Original purchase money','The original offers advertised BUSD funding on BSC. Section 9.11 now identifies the contract, recorded raised amounts and a verified purchase; historical withdrawal recipients remain unrecovered. They are not the ML balance now held in the final distributor. [F18-F19; F32-F34]'],
        ['Unclaimed ML in the distributor','The current owner can invoke withdraw() and send all ML to the immutable treasury. Without a transaction, the calendar date itself does not move those tokens. Who controls the treasury, and under which mandate, remains unknown. [F06; F21-F23]'],
        ['ML successfully submitted to the migration contract','The portal calls burnTokens(amount, mintlayerAddress). This transfers caller-approved ML into the separate TokenBurner contract and emits an event. Its verified source has no withdrawal or owner function. [F24]'],
        ['Native Mintlayer delivery','An Ethereum submission/event is not proof of native-coin receipt. Individual mainnet payments and the final disposition of any unused native migration reserve remain unreconciled. [F24]'],
    ],[145,354])
    p('Separate migration contract: <font face="DVM" size="7.4">0xe03aed8dfa6200292a2585918f656e2345ea283f</font>','small')
    h2('The word burned needs a technical distinction')
    p('Although the contract and event use burn terminology, the inspected function transfers ERC-20 tokens into the contract; it does not call a supply-reducing burn. Its source has no timestamp check and no native-chain payout logic. The portal application points to this exact contract and function. No wallet transaction was submitted in this research. [F23-F24]')
    p('Mintlayer\'s notice says unmigrated tokens will remain locked and the portal will close. That published wording does not, by itself, demonstrate a future global Ethereum-token freeze, automatic forfeiture, transfer to Laura, or legal extinction of investor claims. Successfully submitting tokens and receiving native ML remain separate events. [F08; F24]')
    h2('The records that would answer who benefits')
    p('Identify the distributor treasury signer and company mandate; obtain the specified MEXC withdrawal account mapping and upstream source records; reconcile original BUSD payments to signed purchase obligations; recover the authorization and notice for added withdrawal power; and match remaining holder entitlements to final native-chain payments or any alternative settlement.')
    p('The source comparison establishes a discretionary withdrawal power and the MEXC transfer establishes a funding route. Neither identifies Laura as beneficiary or proves that the unclaimed, fully backed allocation has been taken. [F21-F24]','small')
    return [
        ('F17','Laura role records','https://www.nativzgaming.com/p/newsletter-09-07-22','9 July 2022 profile dates COO appointment to May 2021; October 2021 interview at S15. laura_thread/laura_sources/ preserves source records and 28-query search scope; COO end remains unresolved.'),
        ('F18','Original Mintlayer Raise 1 offer','https://web.archive.org/web/20211122150545/https://app.launchpool.xyz/projects/mintlayer/','Opening and 1 December 2021 captures recovered. Funding/price/vesting fields and hashes: laura_thread/raise_chronology/. Targets are not payment receipts.'),
        ('F19','Original Mintlayer Raise 2 snapshots','https://web.archive.org/web/20220316182610/https://app.launchpool.xyz/projects/mintlayer-raise-2/','Compare capture 20230330212228 of the same URL. Bounded fields preserve target, delivery-network and preliminary-summary changes; no payment recipient recovered.'),
        ('F20','Named contacts and launch-week terms','https://launchpool.medium.com/launchpool-ama-recap-mintlayer-7dbef79f623d','Published 23 March 2022; event 21 March. Detailed short/long tranches extend to 34 months. Named contacts are not wallet signers.'),
        ('F21','Treasury and upstream transfers','https://etherscan.io/address/0x6c2b3a90acb72ef896325e19af9098d157f929c4','laura_thread/treasury/: exact event CSV, source histories and request receipts. MEXC 16 label preserved as a short source record; account customer remains unidentified.'),
        ('F22','Earlier related distributor','https://etherscan.io/address/0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b','Verified source and constructor inputs compared with F06. Same deployer/token/root; later adds withdrawal power. Initial history gap is updated by F30: zero balance/claim bits and explicit empty transfer history.'),
        ('F23','Independent control comparison',None,'laura_thread/control_peer_checks.json and control_peer_review.md. Source and constructor comparisons; no independent compiler rebuild. A later earlier-contract balance/bitmap census appears at F30.'),
        ('F24','Separate migration mechanism','https://token.mintlayer.org/migration','Portal application identifies TokenBurner at 0xe03aed8dfa6200292a2585918f656e2345ea283f. Verified source, application hash/metadata and interpretation: laura_thread/migration_mechanics/.'),
        ('F25','Initial Ethereum delivery announcement','https://medium.com/@mintlayer/mintlayer-token-launch-announcement-c5bdf062873c','13 December 2022 original; prospective 21 March 2023 TGE. Later website copy has an inconsistent publication date; original Medium date used.'),
        ('F26','Mintlayer and Launchpool Labs','https://www.mintlayer.com/blog/launchpool-partnership-1a7d0/','Displayed 2 March 2023; Roxana Nasoi identified as Labs managing director. Public role and partnership statement, not a corporate ownership or treasury record.'),
    ]
