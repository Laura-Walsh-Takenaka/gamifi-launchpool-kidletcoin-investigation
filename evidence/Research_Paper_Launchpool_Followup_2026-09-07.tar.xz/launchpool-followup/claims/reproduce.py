#!/usr/bin/env python3
"""Read-only re-fetch of evidence, or offline reproduction. Standard library only.
Usage: python reproduce.py --offline
       python reproduce.py --fetch-dir /absolute/path/to/new_capture
No wallet, signatures, private credentials, approvals, or transactions are used.
"""
import argparse, concurrent.futures, hashlib, json, pathlib, subprocess, sys, urllib.request
HERE=pathlib.Path(__file__).resolve().parent
BASE=HERE.parent
ADDR='0xcc32853fb709666332cde0fc47f3f74119b970c4'
TOKEN='0x059956483753947536204e89bfad909e1a434cc6'
BLOCK='0x18b8eb1'
URLS={
 'claim_index.txt':'https://mintlayerclaim.netlify.app/',
 'index-D-t69RK1.js':'https://mintlayerclaim.netlify.app/assets/index-D-t69RK1.js',
 'claims.json':'https://mintlayerclaim.netlify.app/claims.json',
 'mintlayer_final_distro_readable.json':'https://mintlayerclaim.netlify.app/mintlayer_final_distro_readable.json',
 'blockscout_api.txt':'https://eth.blockscout.com/api?module=contract&action=getsourcecode&address=0xCc32853fb709666332cDe0fc47F3f74119B970c4',
 'transfers_blockscout_min.txt':'https://eth.blockscout.com/api?module=account&action=tokentx&address='+ADDR,
 'txs_blockscout_min.txt':'https://eth.blockscout.com/api?module=account&action=txlist&address='+ADDR,
 'address_blockscout.txt':'https://eth.blockscout.com/api/v2/addresses/'+ADDR,
 'address_etherscan.txt':'https://etherscan.io/address/'+ADDR,
 'etherscan_tokenholder.txt':'https://etherscan.io/token/'+TOKEN+'?a=0xCc32853fb709666332cDe0fc47F3f74119B970c4',
 'withdraw_transaction.txt':'https://etherscan.io/tx/0xb41ca7e94895ab95886a38f49965365caeaebae8707f6c43bf37759837c23e6b'
}
def tasks():
 for name,url in URLS.items():yield name,url,None
 rpc='https://ethereum-rpc.publicnode.com'
 calls={'pinned_block':('eth_getBlockByNumber',[BLOCK,False])}
 for name,to,data in [('owner',ADDR,'0x8da5cb5b'),('token',ADDR,'0xfc0c546a'),('root',ADDR,'0x2eb4a7ab'),('treasury',ADDR,'0x61d027b3'),('balance',TOKEN,'0x70a08231'+ADDR[2:].zfill(64)),('decimals',TOKEN,'0x313ce567')]:
  calls['pinned_'+name]=('eth_call',[{'to':to,'data':data},BLOCK])
 slots=json.loads((BASE/'claims_peer/rpc_slots_and_selectors.json').read_text())['bitmap_slots']
 for idx,slot in slots.items():calls['bitmap_'+idx]=('eth_getStorageAt',[ADDR,slot,BLOCK])
 for name,(method,params) in calls.items():yield name+'.json',rpc,{'jsonrpc':'2.0','id':1,'method':method,'params':params}
def fetch(dest):
 dest.mkdir(parents=True,exist_ok=False)
 def one(task):
  name,url,body=task
  try:
   req=urllib.request.Request(url,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json','User-Agent':'Launchpool-public-record-research/1.0'})
   with urllib.request.urlopen(req,timeout=25) as r:raw=r.read();status=r.status
   (dest/name).write_bytes(raw)
   return {'file':name,'url':url,'request':body,'http_status':status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  except Exception as err:return {'file':name,'url':url,'request':body,'error':str(err)}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(one,tasks()))
 (dest/'fetch_manifest.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(results,indent=2))
 print('Capture saved separately. Live explorer histories can extend past pinned block; filter those before reconciliation.')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--offline',action='store_true');ap.add_argument('--fetch-dir',type=pathlib.Path);args=ap.parse_args()
 if args.fetch_dir:fetch(args.fetch_dir)
 if args.offline:
  for name in ['verify_claims.py','reconcile_claims.py']:
   subprocess.run([sys.executable,str(BASE/'claims_peer'/name)],check=True)
 if not args.offline and not args.fetch_dir:ap.print_help()
if __name__=='__main__':main()
