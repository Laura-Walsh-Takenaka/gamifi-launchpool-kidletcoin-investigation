import json
import hashlib
from pathlib import Path
from decimal import Decimal, getcontext
from collections import Counter

getcontext().prec = 100
BASE = Path(__file__).resolve().parent.parent
SOURCE = BASE / 'claims'
MASK = (1 << 64) - 1
ROT = [[0,36,3,41,18], [1,44,10,45,2], [62,6,43,15,61], [28,55,25,21,56], [27,20,39,8,14]]
RC = [0x0000000000000001,0x0000000000008082,0x800000000000808a,0x8000000080008000,0x000000000000808b,0x0000000080000001,0x8000000080008081,0x8000000000008009,0x000000000000008a,0x0000000000000088,0x0000000080008009,0x000000008000000a,0x000000008000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,0x8000000000008002,0x8000000000000080,0x000000000000800a,0x800000008000000a,0x8000000080008081,0x8000000000008080,0x0000000080000001,0x8000000080008008]

def rol(a, b):
    return ((a << b) | (a >> (64-b))) & MASK

def permute(s):
    for rc in RC:
        c = [s[x]^s[x+5]^s[x+10]^s[x+15]^s[x+20] for x in range(5)]
        d = [c[(x-1)%5]^rol(c[(x+1)%5],1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                s[x+5*y] ^= d[x]
        b = [0]*25
        for x in range(5):
            for y in range(5):
                b[y+5*((2*x+3*y)%5)] = rol(s[x+5*y], ROT[x][y])
        for x in range(5):
            for y in range(5):
                s[x+5*y] = b[x+5*y] ^ ((~b[(x+1)%5+5*y]) & b[(x+2)%5+5*y])
        s[0] ^= rc

def keccak256(data):
    rate=136
    padded=bytearray(data)
    padded.append(0x01)
    padded.extend(b'\0' * ((-len(padded)) % rate))
    padded[-1] |= 0x80
    state=[0]*25
    for offset in range(0,len(padded),rate):
        for i in range(rate//8):
            state[i] ^= int.from_bytes(padded[offset+i*8:offset+i*8+8], 'little')
        permute(state)
    return b''.join(x.to_bytes(8,'little') for x in state)[:32]

def load(name):
    pairs=[]
    def hook(p):
        keys=[k for k,v in p]
        if len(set(keys)) != len(keys):
            pairs.extend(k for k,c in Counter(keys).items() if c>1)
        return dict(p)
    d=json.loads((SOURCE/name).read_text(encoding='utf-8-sig'),object_pairs_hook=hook)
    assert not pairs, (name, 'duplicate literal JSON keys', pairs)
    return d

def main():
    assert keccak256(b'').hex() == 'c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
    assert keccak256(b'abc').hex() == '4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45'
    assert keccak256(b'transfer(address,uint256)').hex()[:8] == 'a9059cbb'
    print('Keccak vectors passed',flush=True)
    selectors={sig:'0x'+keccak256(sig.encode()).hex()[:8] for sig in ['isClaimed(uint256)','merkleRoot()','token()','treasury()','owner()','withdraw()','decimals()','balanceOf(address)','claim(uint256,address,uint256,bytes32[])']}
    print(json.dumps(selectors),flush=True)
    data=load('claims.json')
    readable=load('mintlayer_final_distro_readable.json')
    rows=data['claims']
    normalized={a.lower():v for a,v in rows.items()}
    assert len(rows)==len(normalized), 'case insensitive duplicate'
    indices=[r['index'] for r in rows.values()]
    assert sorted(indices)==list(range(len(rows))), 'index gap or duplicate'
    assert set(normalized)==set(a.lower() for a in readable), 'different addresses'
    total=sum(int(r['amount'],16) for r in rows.values())
    assert total==int(data['tokenTotal'],16), 'declared total differs'
    mismatch=[]
    leaves=[]
    failures=[]
    for a,r in rows.items():
        raw=int(r['amount'],16)
        assert raw>0
        if Decimal(readable[a.lower()])*10**18 != raw:
            mismatch.append(a)
        leaf=keccak256(r['index'].to_bytes(32,'big')+bytes.fromhex(a[2:])+raw.to_bytes(32,'big'))
        leaves.append(leaf)
        h=leaf
        for p in r['proof']:
            pair=sorted((h,bytes.fromhex(p[2:])))
            h=keccak256(pair[0]+pair[1])
        if '0x'+h.hex()!=data['merkleRoot']:
            failures.append(a)
    # Typical Uniswap Merkle tree builder: sorted unique leaves, sorted sibling hashing,
    # unpaired rightmost node promoted. Proof validation above does not require this choice.
    layer=sorted(set(leaves))
    while len(layer)>1:
        layer=[keccak256(b''.join(sorted(layer[i:i+2]))) if i+1<len(layer) else layer[i] for i in range(0,len(layer),2)]
    out={
        'source_sha256':{n:hashlib.sha256((SOURCE/n).read_bytes()).hexdigest() for n in ['claims.json','mintlayer_final_distro_readable.json','deployed_MerkleDistributor.sol']},
        'keccak_known_vectors_passed':True,
        'selectors':selectors,
        'event_topics':{s:'0x'+keccak256(s.encode()).hex() for s in ['Claimed(uint256,address,uint256)','Transfer(address,address,uint256)']},
        'claim_count':len(rows),
        'unique_addresses_case_insensitive':len(normalized),
        'unique_indices':len(set(indices)),
        'indices_contiguous_zero_based':True,
        'total_base_units':str(total),
        'declared_total_equal':True,
        'total_ML_using_18_decimals':str(Decimal(total)/10**18),
        'readable_file_matching_address_set':True,
        'readable_amount_mismatch_addresses':mismatch,
        'proofs_passed':len(rows)-len(failures),
        'proof_failure_addresses':failures,
        'published_merkle_root':data['merkleRoot'],
        'independently_rebuilt_merkle_root':'0x'+layer[0].hex(),
        'rebuilt_merkle_root_matches':'0x'+layer[0].hex()==data['merkleRoot'],
        'proof_length_counts':dict(Counter(len(r['proof']) for r in rows.values())),
        'smallest_base_unit_allocation':str(min(int(r['amount'],16) for r in rows.values())),
        'largest_base_unit_allocation':str(max(int(r['amount'],16) for r in rows.values())),
    }
    (BASE/'claims_peer'/'independent_validation.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2),flush=True)

if __name__=='__main__':
    main()
