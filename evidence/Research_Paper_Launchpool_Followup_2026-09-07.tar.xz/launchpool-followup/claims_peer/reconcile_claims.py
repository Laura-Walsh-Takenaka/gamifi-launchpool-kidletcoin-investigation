import json
from decimal import Decimal, getcontext
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter

getcontext().prec=100
BASE=Path(__file__).resolve().parent.parent
P=BASE/'claims'
DIST='0xcc32853fb709666332cde0fc47f3f74119b970c4'
TOKEN='0x059956483753947536204e89bfad909e1a434cc6'
def load(n): return json.loads((P/n).read_text(encoding='utf-8-sig'))
def ml(n): return str(Decimal(n)/10**18)
block=load('pinned_block.json')['result']
height=int(block['number'],16)
data=load('claims.json')['claims']
byindex={r['index']:(a.lower(),int(r['amount'],16)) for a,r in data.items()}
words={i:int(load(f'bitmap_{i}.json')['result'],16) for i in range(8)}
claimed={i for i in byindex if (words[i//256]>>(i%256))&1}
extra_claimed={i for i in range(len(data),2048) if (words[i//256]>>(i%256))&1}
assert not extra_claimed
claimed_raw=sum(byindex[i][1] for i in claimed)
total=sum(x[1] for x in byindex.values())
unclaimed_raw=total-claimed_raw
balance=int(load('pinned_balance.json')['result'],16)
txs=load('txs_blockscout_min.txt')['result']
assert max(int(t['blockNumber']) for t in txs)<=height
assert len(txs)==len(set(t['hash'] for t in txs))
decoded={}
for tx in txs:
    if tx['input'].startswith('0x2e7ba6ef') and tx['isError']=='0':
        assert tx['txreceipt_status']=='1'
        assert tx['to'].lower()==DIST
        input_hex=tx['input'][10:]
        idx=int(input_hex[:64],16)
        addr='0x'+input_hex[64:128][-40:]
        amount=int(input_hex[128:192],16)
        assert (addr,amount)==byindex[idx]
        assert idx not in decoded
        decoded[idx]={'hash':tx['hash'],'amount':amount,'address':addr,'time':datetime.fromtimestamp(int(tx['timeStamp']),timezone.utc).isoformat()}
assert set(decoded)==claimed
events=load('transfers_blockscout_min.txt')['result']
assert max(int(t['blockNumber']) for t in events)<=height
ml_events=[t for t in events if t['contractAddress'].lower()==TOKEN]
ins=[t for t in ml_events if t['to'].lower()==DIST]
outs=[t for t in ml_events if t['from'].lower()==DIST]
assert len(ins)+len(outs)==len(ml_events)
flow=sum(int(t['value']) for t in ins)-sum(int(t['value']) for t in outs)
assert flow==balance
claims_byhash={t['hash']:t for t in decoded.values()}
matched=[]
nonclaim_out=[]
for e in outs:
    if e['hash'] in claims_byhash:
        c=claims_byhash[e['hash']]
        assert e['to'].lower()==c['address']
        assert int(e['value'])==c['amount']
        matched.append(e['hash'])
    else:
        nonclaim_out.append(e)
assert len(matched)==len(set(matched))==len(decoded)
withdraws=[t for t in txs if t['input'].startswith('0x3ccfd60b')]
def brief(t):
    return {k:t[k] for k in ['hash','from','to','value','blockNumber','timeStamp','isError','txreceipt_status'] if k in t}
out={
    'pinned_block':height,
    'block_hash':block['hash'],
    'pinned_time_UTC':datetime.fromtimestamp(int(block['timestamp'],16),timezone.utc).isoformat(),
    'allocation_count':len(data),
    'claimed_count':len(claimed),
    'unclaimed_count':len(data)-len(claimed),
    'claimed_base_units':str(claimed_raw),
    'unclaimed_base_units':str(unclaimed_raw),
    'claimed_ML':ml(claimed_raw),
    'unclaimed_ML':ml(unclaimed_raw),
    'balance_ML':ml(balance),
    'balance_minus_unclaimed_ML':ml(balance-unclaimed_raw),
    'successful_inputs_match_bitmap_and_allocations':True,
    'successful_claim_transfer_matches':len(matched),
    'normal_txs_retrieved':len(txs),
    'all_token_events_retrieved':len(events),
    'ML_transfer_events':len(ml_events),
    'ML_inflows':[brief(t) for t in ins],
    'ML_nonclaim_outflows':[brief(t) for t in nonclaim_out],
    'withdraw_calls':[brief(t) for t in withdraws],
    'ML_transfer_net_matches_pinned_balance':True,
    'first_claim':min(decoded.values(),key=lambda t:t['time']),
    'last_claim':max(decoded.values(),key=lambda t:t['time']),
    'bitmap_set_bits_outside_allocations':len(extra_claimed),
}
(BASE/'claims_peer'/'independent_reconciliation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
