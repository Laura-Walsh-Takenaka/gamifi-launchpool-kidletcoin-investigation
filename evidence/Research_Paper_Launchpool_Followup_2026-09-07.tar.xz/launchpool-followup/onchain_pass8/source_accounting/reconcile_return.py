"""Offline source bounds for the July23 return; inherited indexed completeness is explicit."""
from pathlib import Path
from decimal import Decimal
import json,hashlib
R=Path(__file__).resolve().parents[2]; P=Path(__file__).resolve().parent
W='0x1991e27e2908847c0274a662eb6675002e8386d0'
T='0xdac17f958d2ee523a2206206994597c13d831ec7'
RETURN='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4'
K='0x188b1922d1961500cbd30066029590cb20dbd817'
Q='0x327ae1e62fdea32763d6e5de1b08ebe84edff303'
OTHER='0x2c94c30bdd9aa400df9d2347ee16094ab1858941'
p=R/'onchain_pass6/returned_funds/USDT_history.json';raw=json.loads(p.read_text())
assert raw['status']=='1'; rows=raw['result'];assert len(rows)==1577
assert all(x['contractAddress'].lower()==T and x['tokenDecimal']=='6' and W in [x['from'].lower(),x['to'].lower()] for x in rows)
rows=sorted(rows,key=lambda x:(int(x['blockNumber']),int(x['transactionIndex'])))
bal=0;pre=None;selected=[]
for x in rows:
 b=int(x['blockNumber']);n=int(x['value']);
 if b>=20369851 and pre is None:pre=bal
 bal+=n*((x['to'].lower()==W)-(x['from'].lower()==W));assert bal>=0
 if 20369851<=b<=20375526 and n: selected.append(x)
assert pre==8375183313 and bal==0 and len(selected)==6
assert selected[0]['from'].lower()==RETURN and int(selected[0]['value'])==58724105382
assert [x['to'].lower() for x in selected if x['from'].lower()==W]==[K,OTHER,Q]
returned=int(selected[0]['value']); amounts={x['to'].lower():int(x['value']) for x in selected if x['from'].lower()==W}
assert amounts=={K:21882270000,OTHER:4000000000,Q:105907029506}
def fmt(n):return format(Decimal(n)/10**6,'f')
# Replay two source colors chronologically, selectively assigning return units to an output.
# For each endpoint objective, a greedy extremal assignment works on this one-wallet ledger.
# Include the full late outside receipts, which cannot retroactively fund the first payment.
def replay(target,maximize):
 cash=[0,pre];alloc=[]
 for x in selected:
  n=int(x['value']);src=x['from'].lower();dst=x['to'].lower()
  if dst==W:cash[0 if src==RETURN else 1]+=n;continue
  want_return=(dst in target)==maximize
  n0=min(n,cash[0]) if want_return else max(0,n-cash[1]);n1=n-n0
  assert 0<=n0<=cash[0] and 0<=n1<=cash[1]
  cash[0]-=n0;cash[1]-=n1
  alloc.append({'tx':x['hash'],'to':dst,'gross_USDT':fmt(n),'return_USDT':fmt(n0),'outside_USDT':fmt(n1)})
 assert cash==[0,0]
 return {'return_to_target_USDT':fmt(sum(int(Decimal(a['return_USDT'])*10**6) for a in alloc if a['to'] in target)),'allocation':alloc}
objectives={'first_188b_branch':{K},'KuCoin_branch':{Q},'joint_188b_and_KuCoin':{K,Q}}
results={}
for name,target in objectives.items():
 lo=replay(target,False);hi=replay(target,True);results[name]={'minimum':lo,'maximum':hi}
assert results['first_188b_branch']['minimum']['return_to_target_USDT']=='13507.086687'
assert results['first_188b_branch']['maximum']['return_to_target_USDT']=='21882.27'
assert results['joint_188b_and_KuCoin']['minimum']['return_to_target_USDT']=='54724.105382'
assert results['joint_188b_and_KuCoin']['maximum']['return_to_target_USDT']=='58724.105382'
# Conservation independently proves the joint result: only4000 can leave by the other branch.
assert returned-amounts[OTHER]==54724105382
# Upgrade only the selected return interval using new complete raw coverage and historical state.
EP=R/'onchain_pass8/eth_tail'; evidence={}
def pairs(name):
 fp=EP/name;rp=EP/(name+'.request.json');mp=EP/(name+'.receipt.json')
 response=json.loads(fp.read_text());request=json.loads(rp.read_text());meta=json.loads(mp.read_text())
 for q in [fp,rp,mp]:evidence[str(q.relative_to(R))]=hashlib.sha256(q.read_bytes()).hexdigest()
 assert meta['status']==200 and meta['sha256']==hashlib.sha256(fp.read_bytes()).hexdigest()
 bodies=request['jsonrpc_body']; bodies=bodies if isinstance(bodies,list) else [bodies]
 response=response if isinstance(response,list) else [response];byid={x['id']:x for x in response}
 return [(q,byid[q['id']]) for q in bodies]
states={}
for q,r in pairs('1991_state.json'):
 assert q['method']=='eth_call' and 'result' in r and 'error' not in r
 c,b=q['params'];assert c['to'].lower()==T and c['data']=='0x70a08231'+'0'*24+W[2:]
 states[int(b,16)]=int(r['result'],16)
assert states=={20369850:pre,20375526:0}
coverage={'in':[],'out':[]};logs={};failed=0
for name in ['1991_raw_logs.json','1991_out_retry_0.json','1991_out_retry_2.json','1991_out_retry_4.json']:
 for q,r in pairs(name):
  assert q['method']=='eth_getLogs';c=q['params'][0]
  if 'error' in r:failed+=1;continue
  assert c['address'].lower()==T and c['topics'][0]=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
  side=1 if c['topics'][1] else 2;direction='out' if side==1 else 'in'
  assert c['topics'][side]=='0x'+'0'*24+W[2:]
  a,b=int(c['fromBlock'],16),int(c['toBlock'],16);coverage[direction].append((a,b))
  for x in r['result']:
   assert x['address'].lower()==T and not x.get('removed') and a<=int(x['blockNumber'],16)<=b
   assert x['topics'][side]==c['topics'][side]
   key=(x['transactionHash'],int(x['logIndex'],16));assert key not in logs;logs[key]=x
assert failed==1
for spans in coverage.values():
 cursor=20369851
 for a,b in sorted(spans):assert a==cursor;cursor=b+1
 assert cursor==20375527
assert len(logs)==6
for x in selected:
 match=[v for v in logs.values() if v['transactionHash']==x['hash']]
 assert len(match)==1;y=match[0]
 assert int(y['data'],16)==int(x['value']) and int(y['blockNumber'],16)==int(x['blockNumber'])
 assert '0x'+y['topics'][1][-40:]==x['from'].lower() and '0x'+y['topics'][2][-40:]==x['to'].lower()
out={'scope':'1991 canonical USDT source-accounting; six positive events Jul23 14:32:47 through Jul24 09:32:23UTC,2024',
'input':str(p.relative_to(R)),'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
'indexed_history_events':len(rows),'opening_USDT':fmt(pre),'selected_return_USDT':fmt(returned),
'joint_gross_out_USDT':fmt(amounts[K]+amounts[Q]),'objectives':results,
'raw_evidence':evidence,'condition':'Selected interval now has complete both-direction raw canonical USDT logs and successful historical opening/closing states, matching all six positive indexed events. Intermediary continuity and service labels are independently verified under pass8 eth_tail and prior pass6 returned_funds. This does not upgrade the separate initial IAG USDC history.',
'limits':['Source is the selected USDT return from183600, not original BUSD or an amount of IAG investment/profit.','No FIFO or pro-rata tracing rule; chronological feasible allocations delimit sources only.','Separate lower bounds cannot be added; their allocations use the same outside and return budgets.','No beneficial owner, exchange customer, authorized purpose, investor entitlement or Laura receipt is identified.']}
(P/'returned_source_bounds.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','opening':fmt(pre),'return':fmt(returned),'joint_gross':out['joint_gross_out_USDT'],'bounds':{k:[v['minimum']['return_to_target_USDT'],v['maximum']['return_to_target_USDT']] for k,v in results.items()}}))
