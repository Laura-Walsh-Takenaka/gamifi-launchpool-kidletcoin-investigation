"""Reconcile the prior pass7 flow frontier; distinct historical cutoffs are retained."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,hashlib
getcontext().prec=80
R=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent;inputs={}
def read(s):
 p=R/s;inputs[s]=hashlib.sha256(p.read_bytes()).hexdigest();return json.loads(p.read_text())
def fmt(x):return format(Decimal(x)/10**18,'f')
a=read('onchain_pass6/original_busd_onward/verified_owner_onward.json')
b=read('onchain_pass6/original_busd_onward/verified_intermediary_onward.json')
c=read('onchain_pass7/busd_branches/verified_branches.json')
d=read('onchain_pass7/busd_branches/verified_extension.json')
e=read('onchain_pass7/owner_and_retained/verified_retained_d7.json')
owner=a['owner'];pool='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';binance='0x8894e0a0c962cb723c1976a4421c95949be2d4e3'
opening={owner:int(a['window_balances'][0]['opening_raw'])}
for x in b['window_balances']:
 if x['raise']==1:opening[x['address']]=int(x['opening_raw'])
for x in c['window_balances']:opening[x['address']]=int(x['opening_raw'])
rows={}
for data in [a,b,c,d,e]:
 for x in data['rows']:
  if int(x['amount_raw'])==0:continue
  key=x['tx_hash'],x['log_index']
  if key in rows:assert all(rows[key][k]==x[k] for k in ['from','to','amount_raw','block_number'])
  rows[key]=x
cash=dict(opening);endpoints=0;raised=0
for x in sorted(rows.values(),key=lambda x:(x['block_number'],x['log_index'])):
 n=int(x['amount_raw']);src=x['from'];dst=x['to']
 if src==pool:raised+=n;assert dst==owner
 else:cash[src]-=n;assert cash[src]>=0
 if dst==binance:endpoints+=n
 else:cash[dst]=cash.get(dst,0)+n
assert raised==903794346419582485370326 and endpoints==501460520000000000000000
assert sum(opening.values())+raised==sum(cash.values())+endpoints
assert sum(cash.values())==403500914021983632450616
checks={}
for x in e['window_balances']:checks[x['address']]=(int(x['closing_raw']),'2022-11-12T13:59:08Z')
for x in d['window_balances']:checks[x['address']]=(int(x['closing_raw']),'2022-11-10T09:02:17Z')
for x in b['window_balances']:
 if x['raise']==2 and x['address'].startswith('0x2108'):checks[x['address']]=(int(x['closing_raw']),'2022-11-05T13:59:08Z')
retained=[]
for wallet,n in cash.items():
 if n:
  assert checks[wallet][0]==n
  retained.append({'address':wallet,'balance_BUSD':fmt(n),'cutoff_UTC':checks[wallet][1]})
out={'scope':'Accounting frontier of captured original Mintlayer BUSD flow through pass7, before the pass8 extensions. Wallet cutoffs differ; this is not one common-date balance snapshot.',
'inputs':inputs,'original_withdrawals_BUSD':fmt(raised),'other_opening_funds_BUSD':fmt(sum(opening.values())),
'opening_funds_by_wallet':[{'address':w,'prior_BUSD':fmt(n)} for w,n in sorted(opening.items()) if n],
'unique_endpoint_receipts':7,'Binance_gross_BUSD':fmt(endpoints),'remaining_at_dated_frontiers_BUSD':fmt(sum(cash.values())),
'frontiers':retained,'arithmetic_residual_BUSD':'0',
'limit':'Exact conservation of this captured graph is not full purchaser-to-settlement reconciliation, a current-balance statement, proof of payment purpose, proof all funds remain recoverable, or proof of a human beneficiary. Lateractivity beyond each frontier is outside this specific calculation.'}
(P/'busd_frontier.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['inputs','frontiers','opening_funds_by_wallet']}))
