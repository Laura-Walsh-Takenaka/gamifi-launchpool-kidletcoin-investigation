# Pass 8 source accounting and inspector navigation

The selected July 23, 2024 USDT return from183600 is58,724.105382. Across the Kraken and KuCoin branches, its contribution is54,724.105382–58,724.105382USDT within127,789.299506 grossUSDT. Complete raw logs and successful historical balance calls now corroborate the narrow1991 source window. This does not reclassify the return as entirely original IAG funding or profit, and does not upgrade the separate initialUSDC histories.

`reconcile_return.py` reconstructs the source timeline, proves complete new raw coverage including successful smaller replacement queries, verifies exact raw/indexed agreement and two states, and emits feasible chronological allocations for individual and joint bounds. The independently implemented peer verifier uses feasible-polytope vertices. Separate branch minima cannot be added.

`reconcile_busd_frontier.py` reconstructs the34unique positive events in the prior captured originalBUSD graph and checks exact conservation. Original withdrawals903,794.346419582485370326 plus1,167.08760240114708029 previously heldBUSD equal501,460.52 grossBinance receipts plus403,500.914021983632450616 at six dated leaves. The old frontier cutoffs differ. This equation is an accounting result for captured data; it is not currentrecoverability, authorizedsettlement, or proof of a person. The newpass8 tail lane carries later cutoffs separately.

`service_record_index.json/.csv` indexes nine exact endpoint receipts for focused record matching: seven originalBUSD Binance receipts and the two newEthereum endpoints. It contains chain, tokencontract, amount, full sender/recipient, transactionhash, logindex, UTC and evidencefile. It is a navigation subset; previous KuCoin, MEXC, Revolut and other routes remain in their existing lanes. No aggregate across tokens is meaningful.

Reproduce from the extracted project root:

```text
python onchain_pass8/source_accounting/reconcile_return.py
python onchain_pass8/source_accounting/reconcile_busd_frontier.py
```

These offline standard-library scripts rewrite their derivedJSON outputs. Use an extracted working copy to retain the original package hashes. No financial transaction or external records request was made.
