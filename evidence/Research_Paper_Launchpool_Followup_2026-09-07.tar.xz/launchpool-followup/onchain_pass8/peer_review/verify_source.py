"""Independent offline pass8 source bounds: rational polytope vertices + chronological replay.
Run from any working directory. Does not import or execute evidence collectors.
"""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal
from itertools import combinations
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
checks=[]
def ck(ok,label):
    if not ok: raise AssertionError(label)
    checks.append(label)
def read(rel):
    p=ROOT/rel
    inputs[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
    return json.loads(p.read_text())
def fmt(n):return format(Decimal(int(n))/1000000,'f')
def units(s):return int(Decimal(s)*1000000)
inputs={}
raw=read('onchain_pass6/returned_funds/USDT_history.json')
claimed=read('onchain_pass8/source_accounting/returned_source_bounds.json')
W='0x1991e27e2908847c0274a662eb6675002e8386d0'; TOKEN='0xdac17f958d2ee523a2206206994597c13d831ec7'
RETURN='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4'; FIRST='0x188b1922d1961500cbd30066029590cb20dbd817'
OTHER='0x2c94c30bdd9aa400df9d2347ee16094ab1858941'; LAST='0x327ae1e62fdea32763d6e5de1b08ebe84edff303'
ck(raw['status']=='1','indexed request successful')
rows=raw['result'];ck(len(rows)==1577,'indexed count1577')
ck(all(r['contractAddress'].lower()==TOKEN and int(r['tokenDecimal'])==6 for r in rows),'all indexed rows canonical USDT six decimals')
ck(all(W in (r['from'].lower(),r['to'].lower()) for r in rows),'all indexed rows touch selected wallet')
rows=sorted(rows,key=lambda r:(int(r['blockNumber']),int(r['transactionIndex'])))
first_block=20369851;last_block=20375526
opening=sum(int(r['value'])*((r['to'].lower()==W)-(r['from'].lower()==W)) for r in rows if int(r['blockNumber'])<first_block)
events=[r for r in rows if first_block<=int(r['blockNumber'])<=last_block and int(r['value'])>0]
ck(len(events)==6,'six positive events in selected window')
ck(len({(r['blockNumber'],r['transactionIndex']) for r in events})==6,'selected chronology unambiguous without logIndex')
ck([r['to'].lower() if r['from'].lower()==W else 'IN' for r in events]==['IN',FIRST,OTHER,'IN','IN',LAST],'chronology includes two late outside inflows after first two payments')
ck(events[0]['from'].lower()==RETURN,'selected source return sender')
ck(all(r['from'].lower()!=RETURN for r in events[1:] if r['to'].lower()==W),'later inflows are outside selected source')
R=int(events[0]['value']);A=int(events[1]['value']);B=int(events[2]['value']);C=int(events[5]['value'])
late=sum(int(r['value']) for r in events[3:5])
ck((opening,R,A,B,C,late)==(8375183313,58724105382,21882270000,4000000000,105907029506,64690010811),'independent raw amounts')
ck(opening+R+late==A+B+C,'complete-window conservation closes zero')
ck(claimed['input_sha256']==inputs['onchain_pass6/returned_funds/USDT_history.json'],'input raw bytes match claimed source hash')
ck(units(claimed['opening_USDT'])==opening and units(claimed['selected_return_USDT'])==R,'opening and selected return match')
ck(units(claimed['joint_gross_out_USDT'])==A+C==127789299506,'joint gross excludes separate4000 payment')
# Let x,y be selected-return units allocated to FIRST and OTHER. LAST receives R-x-y.
# All inequalities are a*x+b*y<=c. Include both source colors, all chronological
# inventories, and final-output capacity; no tracing convention is imposed.
ineq=[(-1,0,0),(1,0,A),(0,-1,0),(0,1,B),(-1,0,opening-A),
      (-1,-1,opening-A-B),(1,1,R),(-1,-1,C-R)]
vertices=set()
for (a,b,c),(d,e,f) in combinations(ineq,2):
    det=a*e-b*d
    if not det:continue
    x=Fraction(c*e-b*f,det);y=Fraction(a*f-c*d,det)
    if all(aa*x+bb*y<=cc for aa,bb,cc in ineq):vertices.add((x,y))
ck(len(vertices)==4,'independent feasible polytope has four vertices')
ck(all(x.denominator==y.denominator==1 for x,y in vertices),'all extrema attainable in integer micro-USDT')
objectives={'first_188b_branch':lambda x,y:x,'KuCoin_branch':lambda x,y:R-x-y,'joint_188b_and_KuCoin':lambda x,y:R-y}
results={}
for name,fn in objectives.items():
    values=[fn(*v) for v in vertices];lo=min(values);hi=max(values)
    results[name]={'minimum':fmt(lo),'maximum':fmt(hi)}
    for side,expected in [('minimum',lo),('maximum',hi)]:
        item=claimed['objectives'][name][side]
        ck(units(item['return_to_target_USDT'])==expected,name+' '+side+' independently bounded')
        bytx={a['tx']:a for a in item['allocation']}
        ck(len(bytx)==3,name+' '+side+' three unique allocations')
        cash_return=0;cash_outside=opening;allocated={}
        for e in events:
            n=int(e['value'])
            if e['to'].lower()==W:
                if e['from'].lower()==RETURN:cash_return+=n
                else:cash_outside+=n
                continue
            a=bytx[e['hash']];sr=units(a['return_USDT']);so=units(a['outside_USDT'])
            ck(a['to'].lower()==e['to'].lower() and units(a['gross_USDT'])==n,name+' '+side+' output mapping '+e['hash'][:12])
            ck(sr>=0 and so>=0 and sr+so==n and sr<=cash_return and so<=cash_outside,name+' '+side+' nonnegative chronological inventory '+e['hash'][:12])
            cash_return-=sr;cash_outside-=so;allocated[e['to'].lower()]=sr
        ck((cash_return,cash_outside)==(0,0),name+' '+side+' terminal conservation both sources')
        ck(fn(allocated[FIRST],allocated[OTHER])==expected,name+' '+side+' objective allocation attained')
ck(results['joint_188b_and_KuCoin']=={'minimum':'54724.105382','maximum':'58724.105382'},'joint result exact')
ck('raw' in claimed['condition'].lower() and 'historical' in claimed['condition'].lower() and 'separate initial IAG' in claimed['condition'],'selected-window evidence upgrade and initial-IAG limit explicit')
eth=read('onchain_pass8/peer_review/eth_review.json')
ck(eth['status']=='PASS','separate independent raw Ethereum review passed')
for rel,sha in claimed['raw_evidence'].items():
    actual=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
    ck(actual==sha==eth['input_sha256'][rel],'raw corroboration bytes independently reviewed '+rel)
ck(eth['ledgers'][W]['opening']==fmt(opening) and eth['ledgers'][W]['closing']=='0','independent raw review confirms opening and closing')
ck(any('not original BUSD' in s and 'IAG' in s for s in claimed['limits']),'source is selected return, no original-fund/profit attribution')
report={'status':'PASS','checks':len(checks),'method':'Independently derived rational feasible-polytope vertices, followed by chronological verification of each published endpoint allocation. No collector import or execution.',
'input_sha256':inputs,'opening_USDT':fmt(opening),'selected_return_USDT':fmt(R),'joint_gross_USDT':fmt(A+C),
'feasible_vertices_micro_USDT':[list(map(int,v)) for v in sorted(vertices)],'bounds_USDT':results,
'condition':'Source math independently derives from saved indexed history. The separate independent verify_eth.py review corroborates the selected window with complete bidirectional raw logs and historical opening/closing state; all15 cited raw input hashes match that review. This selected USDT-window upgrade does not extend to the initial IAG USDC ledger.',
'limits':['Only the selected July23 USDT return is source-colored; original IAG/BUSD, profit, ownership and investor entitlement are not inferred.','Onward destinations and service labels require the separately captured routing evidence.','Joint bounds must be optimized jointly; summing separate lower bounds is invalid.'],
'assertions':checks}
(OUT/'source_review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('assertions','input_sha256')},indent=2))
