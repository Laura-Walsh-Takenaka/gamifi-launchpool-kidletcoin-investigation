"""Independent incidence-accounting audit of the pass7 dated BUSD frontier.
Uses previously certified frozen ledgers; does not re-run original RPC collectors.
"""
from pathlib import Path
from collections import defaultdict
from decimal import Decimal,getcontext
import json,hashlib
getcontext().prec=80
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
inputs={};checks=[]
def ck(x,s):
    if not x:raise AssertionError(s)
    checks.append(s)
def read(rel):
    p=ROOT/rel;inputs[rel]=hashlib.sha256(p.read_bytes()).hexdigest();return json.loads(p.read_text())
def u(x):return int(Decimal(x)*10**18)
def fmt(x):return format(Decimal(x)/10**18,'f')
claimed=read('onchain_pass8/source_accounting/busd_frontier.json')
paths=list(claimed['inputs']);data=[read(p) for p in paths]
ck(len(data)==5,'five frozen certified source ledgers')
for p,sha in claimed['inputs'].items():ck(sha==inputs[p],'frozen input identity '+p)
owner='0x77bfe8d704b1948374bf8dab8328a810b2836e66';pool='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';endpoint='0x8894e0a0c962cb723c1976a4421c95949be2d4e3'
# Derive unique transfer incidence independently; internal transfers cancel in graph totals.
events={}
for d in data:
    for r in d['rows']:
        if not int(r['amount_raw']):continue
        k=(r['tx_hash'],r['log_index']);v=(r['from'],r['to'],int(r['amount_raw']),r['block_number'])
        ck(k not in events or events[k]==v,'duplicate factual event equality '+r['tx_hash'][:12]);events[k]=v
prior={owner:int(data[0]['window_balances'][0]['opening_raw'])}
for b in data[1]['window_balances']:
    if b['raise']==1:prior[b['address']]=int(b['opening_raw'])
for b in data[2]['window_balances']:
    ck(b['address'] not in prior,'new branch opening counted once '+b['address']);prior[b['address']]=int(b['opening_raw'])
ck({w:n for w,n in prior.items() if n}=={r['address']:u(r['prior_BUSD']) for r in claimed['opening_funds_by_wallet']},'all five positive preexisting funds independently recovered')
net=defaultdict(int);pool_out=0;endpoint_in=0;endpoint_events=0
for src,dst,n,block in events.values():
    net[src]-=n;net[dst]+=n
    if src==pool:pool_out+=n;ck(dst==owner,'original withdrawal enters owner')
    if dst==endpoint:endpoint_in+=n;endpoint_events+=1
ck(net[pool]==-pool_out and net[endpoint]==endpoint_in,'pool and endpoint have no counterflow within graph')
leaves={w:prior.get(w,0)+net[w] for w in sorted(set(prior)|set(net)) if w not in (pool,endpoint)}
ck(all(n>=0 for n in leaves.values()),'every account incidence balance nonnegative')
leaves={w:n for w,n in leaves.items() if n}
ck(leaves=={r['address']:u(r['balance_BUSD']) for r in claimed['frontiers']},'six nonzero dated leaf balances independently reproduced')
# Compare each resulting leaf against an independently selected historical state row.
state={}
for d in data[1:]:
    for row in d['window_balances']:
        if row.get('window')=='owner_gap':continue
        state[row['address']]=int(row['closing_raw'])
for w,n in leaves.items():ck(state[w]==n,'dated closing state equals graph leaf '+w)
original=903794346419582485370326;outside=1167087602401147080290;remaining=403500914021983632450616;gross=501460520000000000000000
ck((pool_out,sum(prior.values()),sum(leaves.values()),endpoint_in)==(original,outside,remaining,gross),'four headline amounts exact')
ck(endpoint_events==claimed['unique_endpoint_receipts']==7,'seven unique endpoint receipts')
ck(original+outside-gross-remaining==0,'zero exact arithmetic residual')
ck(u(claimed['original_withdrawals_BUSD'])==original and u(claimed['other_opening_funds_BUSD'])==outside and u(claimed['remaining_at_dated_frontiers_BUSD'])==remaining and u(claimed['Binance_gross_BUSD'])==gross,'claimed numbers consistent')
ck(len({r['cutoff_UTC'] for r in claimed['frontiers']})==3,'three distinct dated frontiers remain explicit')
ck('not one common-date' in claimed['scope'],'not presented as common-date balance')
ck(all(s in claimed['limit'] for s in ['current-balance','payment purpose','recoverable','human beneficiary']),'purpose recovery date and identity limits retained')
result={'status':'PASS','checks':len(checks),'method':'Deduplicated frozen-ledger transfer incidence, per-account terminal balances, independent opening-funds enumeration and exact integer conservation. Previously certified capture provenance is inherited.',
'input_sha256':inputs,'unique_positive_graph_events':len(events),'original_withdrawals_BUSD':fmt(original),'other_opening_funds_BUSD':fmt(outside),'Binance_gross_BUSD':fmt(gross),'dated_leaf_balances_BUSD':fmt(remaining),'arithmetic_residual_BUSD':'0',
'condition':'The graph frontiers are distinct historical cutoffs, not a common-date or current balance snapshot. Conservation of captured flows does not establish purpose, entitlement, controller identity, full purchaser-to-settlement completeness or present recoverability.',
'assertions':checks}
(OUT/'frontier_review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('input_sha256','assertions')},indent=2))
