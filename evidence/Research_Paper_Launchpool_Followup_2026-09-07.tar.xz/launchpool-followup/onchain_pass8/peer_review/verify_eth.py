"""Independent portable read-only audit of pass8 Ethereum captures.
Only writes this peer-review directory; no network and no collector imports.
"""
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]; P=ROOT/'onchain_pass8/eth_tail'; OUT=Path(__file__).resolve().parent
checks=[];inputs={};failures=[];rpc={};captures={}
USDC='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'; USDT='0xdac17f958d2ee523a2206206994597c13d831ec7'
TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
def ck(x,s):
    if not x:raise AssertionError(s)
    checks.append(s)
def load(p):
    inputs[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
    return json.loads(p.read_text())
def key(q):return q['method'],json.dumps(q['params'],sort_keys=True)
def fmt(n):return format(Decimal(n)/1000000,'f')
def event(l):return {'tx':l['transactionHash'],'log_index':int(l['logIndex'],16),'block':int(l['blockNumber'],16),'block_hash':l['blockHash'],'token':l['address'].lower(),'from':'0x'+l['topics'][1][-40:],'to':'0x'+l['topics'][2][-40:],'amount_raw':int(l['data'],16),'amount':fmt(int(l['data'],16)),'utc':datetime.fromtimestamp(int(l['blockTimestamp'],16),timezone.utc).isoformat() if l.get('blockTimestamp') else None}
for mp in sorted(P.glob('*.receipt.json')):
    m=load(mp); name=m['response_file']
    if name.endswith('.html'):
        # Full website bodies are excluded from the distributable evidence. Exact label
        # excerpts are separately retained; do not make portable verification depend on HTML.
        continue
    q=load(P/m['request_file']);rp=P/name
    if q.get('request_body_utf8') is not None:
        ck(hashlib.sha256(q['request_body_utf8'].encode()).hexdigest()==q['request_body_sha256'],name+' exact request hash')
        ck(json.loads(q['request_body_utf8'])==q['jsonrpc_body'],name+' serialized request equality')
    if m.get('status')!=200:
        ck('error' in m,name+' failed capture explicit');failures.append({'file':name,'status':m.get('status'),'error':m.get('error')});continue
    ck(rp.exists(),name+' successful file exists')
    blob=rp.read_bytes();ck(len(blob)==m['bytes'] and hashlib.sha256(blob).hexdigest()==m['sha256'],name+' successful response bytes and hash')
    r=load(rp);captures[name]=(q,r)
    if 'jsonrpc_body' not in q:continue
    qs=q['jsonrpc_body'];rs=r if isinstance(r,list) else [r];qs=qs if isinstance(qs,list) else [qs]
    byid={v['id']:v for v in rs};ck(len(byid)==len(rs)==len(qs),name+' unique complete RPC IDs')
    for call in qs:
        v=byid[call['id']]
        if 'error' in v or v.get('result') is None:
            failures.append({'file':name,'rpc_id':call['id'],'error':v.get('error'),'result':v.get('result')});continue
        ck(True,name+' nonnull successful RPC '+str(call['id']))
        k=key(call);ck(k not in rpc or rpc[k]==v['result'],name+' repeated result stable');rpc[k]=v['result']

def get(method,params):return rpc[(method,json.dumps(params,sort_keys=True))]
ledgers={};alllogs={}
for name,(q,r) in sorted(captures.items()):
    if not name.endswith('_raw_logs.json'):continue
    calls=q['jsonrpc_body'];ck(len(calls)==2,name+' incoming and outgoing query pair')
    fs=[x['params'][0] for x in calls]
    out=next(f for f in fs if len(f['topics'])==2);inc=next(f for f in fs if len(f['topics'])==3)
    w='0x'+out['topics'][1][-40:];token=out['address'].lower();lo=int(out['fromBlock'],16);hi=int(out['toBlock'],16)
    ck(token in (USDC,USDT) and inc['address'].lower()==token,name+' canonical matching tokens')
    ck(out['topics'][0]==inc['topics'][0]==TRANSFER and inc['topics'][1] is None and inc['topics'][2]==out['topics'][1],name+' exact directional topics')
    ck(inc['fromBlock']==out['fromBlock'] and inc['toBlock']==out['toBlock'],name+' same complete bounded window')
    found={}
    for direction,template in [('out',out),('in',inc)]:
        covering=[]
        for (method,paramtext),value in rpc.items():
            if method!='eth_getLogs':continue
            f=json.loads(paramtext)[0]
            if f['address'].lower()!=token or f['topics']!=template['topics']:continue
            fl=int(f['fromBlock'],16);fh=int(f['toBlock'],16)
            if fl<lo or fh>hi:continue
            covering.append((fl,fh,f,value))
        # Union coverage tolerates identical overlaps but rejects every missing block.
        cursor=lo
        for fl,fh,f,rows in sorted(covering,key=lambda x:(x[0],x[1])):
            ck(fl<=cursor,name+' '+direction+' coverage has no gap');cursor=max(cursor,fh+1)
            ck(isinstance(rows,list),name+' array result')
            for l in rows:
                ck(l['address'].lower()==token and l['topics'][0]==TRANSFER and len(l['topics'])==3 and not l.get('removed',False),name+' canonical retained Transfer')
                ck(fl<=int(l['blockNumber'],16)<=fh,name+' emitted block in requested range')
                ck(l['topics'][1 if direction=='out' else 2]==out['topics'][1],name+' directional event topic')
                identity=(l['transactionHash'],int(l['logIndex'],16));ck(identity not in found or found[identity]==l,name+' duplicate consistency');found[identity]=l
                ck(identity not in alllogs or alllogs[identity]==l,name+' cross-wallet log agreement');alllogs[identity]=l
        ck(cursor==hi+1,name+' '+direction+' complete successful-query coverage')
    rows=sorted(found.values(),key=lambda l:(int(l['blockNumber'],16),int(l['transactionIndex'],16),int(l['logIndex'],16)))
    opening=int(get('eth_call',[{'to':token,'data':'0x70a08231'+w[2:].zfill(64)},hex(lo-1)]),16)
    closing=int(get('eth_call',[{'to':token,'data':'0x70a08231'+w[2:].zfill(64)},hex(hi)]),16)
    balance=opening;incoming=0;outgoing=0
    for l in rows:
        n=int(l['data'],16)
        if l['topics'][2][-40:]==w[2:]:incoming+=n;balance+=n
        if l['topics'][1][-40:]==w[2:]:outgoing+=n;balance-=n
        ck(balance>=0,name+' chronological state nonnegative')
    ck(balance==closing,name+' full log ledger equals historical closing state')
    ledgers[w]={'token':token,'first_block':lo,'last_block':hi,'opening':fmt(opening),'incoming':fmt(incoming),'outgoing':fmt(outgoing),'closing':fmt(closing),'events':[event(l) for l in rows]}
receipt_count=0;receipt_hashes=[];decoded=[]
for name,(q,r) in sorted(captures.items()):
    if not name.endswith('_receipt_tx.json'):continue
    calls=q['jsonrpc_body'];th=calls[0]['params'][0]
    receipt=get('eth_getTransactionReceipt',[th]);tx=get('eth_getTransactionByHash',[th]);receipt_count+=1;receipt_hashes.append(th)
    ck(receipt['status']=='0x1',name+' transaction successful')
    ck(receipt['transactionHash']==tx['hash']==th and receipt['blockHash']==tx['blockHash'] and receipt['blockNumber']==tx['blockNumber'],name+' receipt transaction identity')
    ck(tx.get('chainId')=='0x1',name+' Ethereum chain1')
    ck(receipt['from'].lower()==tx['from'].lower() and receipt['to'].lower()==tx['to'].lower(),name+' receipt caller and target')
    token=tx['to'].lower()
    if token not in (USDT,USDC):
        matches=[l for l in receipt['logs'] if (th,int(l['logIndex'],16)) in alllogs]
        ck(bool(matches),name+' indirect call has traced canonical transfer')
        for l in matches:ck(l==alllogs[(th,int(l['logIndex'],16))],name+' indirect call exact raw-log receipt match')
        decoded.append({'tx':th,'caller':tx['from'].lower(),'method':'indirect call; ABI not interpreted','target':token,'input_sha256':hashlib.sha256(tx['input'].encode()).hexdigest(),'matched_transfer_events':[event(l) for l in matches]})
        continue
    ck(True,name+' canonical token call')
    data=tx['input'];selector=data[:10];words=[data[i:i+64] for i in range(10,len(data),64)]
    ck(selector in ('0xa9059cbb','0x23b872dd'),name+' supported exact token transfer calldata')
    if selector=='0xa9059cbb':
        ck(len(words)==2,name+' transfer two args');src=tx['from'].lower();dst='0x'+words[0][-40:];amount=int(words[1],16)
    else:
        ck(len(words)==3,name+' transferFrom three args');src='0x'+words[0][-40:];dst='0x'+words[1][-40:];amount=int(words[2],16)
    matched=[l for l in receipt['logs'] if l['address'].lower()==token and l['topics'][0]==TRANSFER and l['topics'][1][-40:]==src[2:] and l['topics'][2][-40:]==dst[2:] and int(l['data'],16)==amount]
    ck(len(matched)==1,name+' one exact calldata-matching emitted transfer')
    for l in matched:
        identity=(th,int(l['logIndex'],16))
        if identity in alllogs:ck(l==alllogs[identity],name+' raw query and successful receipt exact match')
    decoded.append({'tx':th,'caller':tx['from'].lower(),'method':'transfer' if selector=='0xa9059cbb' else 'transferFrom','token':token,'from':src,'to':dst,'amount':fmt(amount)})
# Specific selected-return gateway consistency is now raw-log + historical-state supported.
w='0x1991e27e2908847c0274a662eb6675002e8386d0';g=ledgers[w]
ck((g['first_block'],g['last_block'],g['opening'],g['closing'],len(g['events']))==(20369851,20375526,'8375.183313','0',6),'1991 complete return window and opening directly corroborated')
indexed=load(ROOT/'onchain_pass6/returned_funds/USDT_history.json')['result']
ix={(r['hash'],int(r['value']),r['from'].lower(),r['to'].lower()) for r in indexed if 20369851<=int(r['blockNumber'])<=20375526 and int(r['value'])}
rx={(r['tx'],r['amount_raw'],r['from'],r['to']) for r in g['events'] if r['amount_raw']}
ck(rx==ix,'raw selected-window events exactly equal source-accounting indexed events')
# Routing facts are checked explicitly below, independent of collector summaries.
first='0x188b1922d1961500cbd30066029590cb20dbd817';dep='0x0d560ac1b578ee5ac815a0e096cac37cb4c0eb5e';kraken='0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40'
for a in (first,dep):
    g=ledgers[a];ck(g['opening']=='0' and g['closing']=='0' and len([e for e in g['events'] if e['amount_raw']])==2 and g['incoming']==g['outgoing']=='21882.27',a[:8]+' unmixed21,882.27 route')
ck(any(t.get('from')==dep and t.get('to')==kraken and t['caller']==kraken and t['method']=='transferFrom' and t['amount']=='21882.27' for t in decoded),'Kraken-address caller pulled exact21,882.27USDT')
# Source bounds for the selected d541 payment through the USDC branch.
# Conservation supplies the proof: first hop can retain at most0585 opening;
#22c84 closes zero with only a60-USDC recirculation;2fb794 can retain at most
#its969.468168 closing balance after the sole external payment to67124.
a='0x0585b2d1df27523712561163f73210096202ad52';b='0x22c84da2d2f89873dd18e957609c0f0eb9c628f8';c='0x2fb794baf5c06c011b705123a0a07375633ff4a8';d='0x67124cb10bd4cd6de2946caa1a905c61f05c838e';src='0xd5417e96dd04363c675e41ee6f30bf788412c719'
U=lambda x:int(Decimal(x)*1000000)
selected=21664000000;first_old=U(ledgers[a]['opening']);final_remain=U(ledgers[c]['closing'])
ck(first_old==452461220 and final_remain==969468168,'USDC historical source-bound capacities')
ck(ledgers[b]['opening']==ledgers[b]['closing']=='0','22c84 cannot retain source')
unique={}
for w in (a,b,c):
    for e in ledgers[w]['events']:unique[(e['tx'],e['log_index'])]=e
allusdc=sorted(unique.values(),key=lambda e:(e['block'],e['log_index']))
ck([e['amount_raw'] for e in allusdc if e['from']==c and e['to'] not in (a,b,c)]==[66600000000],'2fb only one external output66600')
ck([e['amount_raw'] for e in allusdc if e['from']==b and e['to']!=c]==[],'22c all outgoing back into route')
minimum=max(0,selected-first_old-final_remain);maximum=selected
usdc_allocations={}
for side in ('minimum','maximum'):
    cash={w:[0,U(ledgers[w]['opening'])] for w in (a,b,c)};alloc=[];received=0
    for e in allusdc:
        sender=e['from'];dest=e['to'];n=e['amount_raw']
        if sender in cash:
            sr,so=cash[sender]
            prefer_return=sender==b or (side=='maximum' and ((sender==a and dest==b) or (sender==c and dest==d)))
            r=min(n,sr) if prefer_return else max(0,n-so);o=n-r
            ck(0<=r<=sr and 0<=o<=so,'USDC '+side+' feasible source inventories '+e['tx'][:12]);cash[sender][0]-=r;cash[sender][1]-=o
        else:r=n if sender==src and dest==a else 0;o=n-r
        if dest in cash:cash[dest][0]+=r;cash[dest][1]+=o
        if dest==d:received+=r
        alloc.append({'tx':e['tx'],'from':sender,'to':dest,'gross':fmt(n),'d541_payment':fmt(r),'other_funds':fmt(o)})
    ck(all(sum(cash[w])==U(ledgers[w]['closing']) for w in cash),'USDC '+side+' exact ending balances')
    ck(received==(minimum if side=='minimum' else maximum),'USDC '+side+' proven endpoint attained')
    usdc_allocations[side]={'selected_payment_to67124_USDC':fmt(received),'allocation':alloc}
ck((minimum,maximum)==(20242070612,21664000000),'USDC selected-payment bound20,242.070612–21,664')
# Compare independent derivation with frozen delivered facts and metadata.
claimed=load(P/'summary.json')
for name,g in claimed['ledgers'].items():
    actual=ledgers[g['wallet']]
    ck((g['token'],g['start_block'],g['end_block'])==(actual['token'],actual['first_block'],actual['last_block']),name+' claimed coverage matches raw query')
    ck([g[k] for k in ('opening_balance','incoming','outgoing','closing_balance')]==[actual[k] for k in ('opening','incoming','outgoing','closing')],name+' claimed state equation matches independent')
    ck(g['positive_event_count']==sum(e['amount_raw']>0 for e in actual['events']) and g['zero_event_count']==sum(e['amount_raw']==0 for e in actual['events']),name+' positive and zero events distinct')
    ae={(e['tx'],e['log_index']):e for e in actual['events']}
    ck(len(g['events'])==len(ae),name+' summary contains exact event count')
    for e in g['events']:
        aevent=ae[(e['transaction_hash'],e['log_index'])]
        ck((e['block'],e['block_hash'],e['token'],e['from'],e['to'],int(e['value_raw']),e['utc'])==(aevent['block'],aevent['block_hash'],aevent['token'],aevent['from'],aevent['to'],aevent['amount_raw'],aevent['utc']),name+' exact event fact comparison '+e['transaction_hash'][:12])
for number,bh in claimed['boundary_blocks'].items():
    h=get('eth_getBlockByNumber',[hex(int(number)),False])
    ck(int(h['number'],16)==int(number) and h['hash']==bh['hash'] and datetime.fromtimestamp(int(h['timestamp'],16),timezone.utc).isoformat()==bh['utc'],'boundary header facts '+number)
ck({r['transaction_hash'] for r in claimed['selected_successful_receipts']}==set(receipt_hashes),'claimed receipt set exact')
ck([U(x['binance_component']) for x in claimed['usdc_source_scenarios']]==[minimum,maximum],'claimed USDC endpoints independently reproduced')
labels=load(P/'label_records.json');label_snapshots=load(OUT/'independent_label_snapshots.json')
byurl={r['url']:r for r in labels}
for snapshot in label_snapshots:
    label=byurl[snapshot['url']];metadata=load(P/(snapshot['file']+'.receipt.json'));request=load(P/(snapshot['file']+'.request.json'))
    ck(label['exact_title']==snapshot['exact_title'] and label['html_sha256']==snapshot['html_sha256']==metadata['sha256'],'independently extracted primary title and original body hash '+snapshot['file'])
    ck(request['url']==snapshot['url']=='https://etherscan.io/address/'+label['address'],'label exact primary URL/address '+snapshot['file'])
manifest=P/'SHA256SUMS.txt';inputs[str(manifest.relative_to(ROOT))]=hashlib.sha256(manifest.read_bytes()).hexdigest();manifest_files=0
for line in manifest.read_text().splitlines():
    sha,rel=line.split(None,1);rel=rel.lstrip('*');blob=(P/rel).read_bytes()
    ck(hashlib.sha256(blob).hexdigest()==sha,'frozen lane manifest '+rel);manifest_files+=1
report={'status':'PASS','checks':len(checks),'method':'Independent request/response hash and RPC-ID validation, raw directional filters, exact receipt and calldata matches, historical state equations, and selected-window comparison to inherited indexed source input. No collector imports or execution.',
'input_sha256':inputs,'failed_captures':failures,'raw_unique_transfer_logs':len(alllogs),'successful_receipts_with_calldata':receipt_count,'ledgers':ledgers,'decoded_transactions':decoded,
'USDC_selected_payment_to67124_bounds':{'gross':'66600','minimum':fmt(minimum),'maximum':fmt(maximum),'source':'Only the selected d541→0585 payment; no unique attribution through upstream mixed d541','feasible_allocations':usdc_allocations},
'frozen_manifest_files':manifest_files,'service_label_records':labels,
'upgraded_source_condition':'For the selected Jul23–Jul24 return window, opening8,375.183313USDT and zero closing balance now have historical RPC state, and all six events have canonical bidirectional RPC logs. The source bounds still mean selected-return token origin only.',
'limits':['Labels do not identify an exchange customer or a human controller.','0585/22c84 route funding limits must retain prior balance and timing; upstream d541 receipt remains mixed.','This review covers declared historical windows, not current balances or lifetime activity.'],
'assertions':checks}
(OUT/'eth_review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks),'raw_unique_logs':len(alllogs),'receipts':receipt_count,'wallet_ledgers':len(ledgers),'failed_captures':failures},indent=2))
