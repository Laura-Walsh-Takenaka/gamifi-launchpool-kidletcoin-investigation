"""Independent portable pass8 BUSD tail audit: request coverage, logs and state.
No collector imports, network, or writes outside peer_review.
"""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal,getcontext
import hashlib,json
getcontext().prec=80
ROOT=Path(__file__).resolve().parents[2];P=ROOT/'onchain_pass8/busd_tail';OUT=Path(__file__).resolve().parent
TOKEN='0xe9e7cea3dedca5984780bafc599bd69add087d56';TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
checks=[];inputs={};calls={};failed=[]
def ck(x,s):
    if not x:raise AssertionError(s)
    checks.append(s)
def read(p):
    inputs[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest();return json.loads(p.read_text())
def fmt(x):return format(Decimal(x)/10**18,'f')
def key(m,p):return m,json.dumps(p,sort_keys=True)
def get(m,p):return calls[key(m,p)]
def utc(h):return datetime.fromtimestamp(int(h['timestamp'],16),timezone.utc).isoformat()
for mp in sorted(P.glob('*.receipt.json')):
    m=read(mp);rp=mp.with_name(mp.name.replace('.receipt.json','.response'))
    if not rp.exists():
        ck('error' in m,mp.name+' explicit failed capture');failed.append({'metadata':mp.name,'error':m.get('error')})
        ep=mp.with_name(mp.name.replace('.receipt.json','.error_body'))
        if ep.exists():ck(hashlib.sha256(ep.read_bytes()).hexdigest()==m['error_body_sha256'],mp.name+' original error-body hash')
        continue
    blob=rp.read_bytes();ck(hashlib.sha256(blob).hexdigest()==m['sha256'],rp.name+' exact captured response hash')
    data=read(rp);data=data if isinstance(data,list) else [data];byid={r['id']:r for r in data}
    ck(len(byid)==len(data)==len(m['request']),rp.name+' complete unique RPC IDs')
    for q in m['request']:
        r=byid[q['id']]
        if 'error' in r or r.get('result') is None:failed.append({'metadata':mp.name,'rpc_id':q['id'],'error':r.get('error')});continue
        k=key(q['method'],q['params']);ck(k not in calls or calls[k]==r['result'],rp.name+' repeated result agrees');calls[k]=r['result']
claims=read(P/'tail_verified.json');coverage=read(P/'scan_coverage.json');ck(claims['token']==TOKEN,'claimed canonical BSC BUSD')
queries=[];observed={}
for (method,ps),value in calls.items():
    params=json.loads(ps)
    if method!='eth_getLogs':continue
    f=params[0];lo=int(f['fromBlock'],16);hi=int(f['toBlock'],16);topics=f['topics']
    ck(f['address'].lower()==TOKEN and topics[0]==TRANSFER,'canonical token and transfer filter')
    ck(len(topics) in (2,3),'directional query shape')
    direction=1 if len(topics)==2 else 2
    ck(direction==1 or topics[1] is None,'incoming wildcard sender')
    wallets=topics[direction];wallets=wallets if isinstance(wallets,list) else [wallets]
    queries.append((lo,hi,direction,set(wallets),value))
    for l in value:
        ck(l['address'].lower()==TOKEN and l['topics'][0]==TRANSFER and not l.get('removed',False),'canonical nonremoved emitted Transfer')
        ck(lo<=int(l['blockNumber'],16)<=hi and l['topics'][direction] in wallets,'emitted log satisfies exact block and topic filters')
        k=(l['transactionHash'],int(l['logIndex'],16));ck(k not in observed or observed[k]==l,'duplicate canonical event agrees');observed[k]=l
windows=[]
for window in claims['windows']:
    lo=window['first_block'];hi=window['last_block'];name=window['name']
    for wallet in window['addresses']:
        topic='0x'+wallet[2:].zfill(64)
        for direction in (1,2):
            spans=sorted((max(a,lo),min(b,hi)) for a,b,d,w,_ in queries if d==direction and topic in w and a<=hi and b>=lo)
            cursor=lo
            for a,b in spans:
                ck(a<=cursor,name+' '+wallet+' direction'+str(direction)+' no coverage gap');cursor=max(cursor,b+1)
            ck(cursor==hi+1,name+' '+wallet+' direction'+str(direction)+' complete successful coverage')
    heads={h:get('eth_getBlockByNumber',[hex(h),False]) for h in (lo,hi,hi+1)}
    ck(all(int(header['number'],16)==h for h,header in heads.items()),name+' boundary block identities')
    ck([utc(heads[h]) for h in (lo,hi,hi+1)]==[window[x] for x in ('first_block_utc','last_block_utc','after_block_utc')],name+' exact boundary timestamps')
    ck(datetime.fromisoformat(window['last_block_utc'])<=datetime.fromisoformat(window['cutoff_utc'])<datetime.fromisoformat(window['after_block_utc']),name+' exact cutoff bracket')
    windows.append({'name':name,'first_block':lo,'last_block':hi,'cutoff_utc':window['cutoff_utc'],'wallets':window['addresses']})
ck(len(observed)==len(claims['rows']),'unique raw and claimed event counts')
for row in claims['rows']:
    l=observed[(row['tx_hash'],row['log_index'])];n=int(l['data'],16)
    ck((row['from'],row['to'],int(row['amount_raw']),row['block_number'])==('0x'+l['topics'][1][-40:],'0x'+l['topics'][2][-40:],n,int(l['blockNumber'],16)),'claimed event decoding')
    receipt=get('eth_getTransactionReceipt',[row['tx_hash']]);tx=get('eth_getTransactionByHash',[row['tx_hash']]);header=get('eth_getBlockByNumber',[hex(row['block_number']),False])
    ck(receipt['status']=='0x1' and l in receipt['logs'],'successful transaction contains exact emitted log')
    ck(receipt['blockHash']==tx['blockHash']==header['hash']==l['blockHash']==row['block_hash'],'receipt tx header and log block identity')
    ck(row['tx_from']==tx['from'] and row['tx_to']==tx['to'] and row['tx_input']==tx['input'],'caller target calldata retained')
    ck(row['utc']==utc(header),'claimed event time matches header')
balances=[]
for b in claims['window_balances']:
    w=next(w for w in claims['windows'] if w['name']==b['window']);wallet=b['address'];topic='0x'+wallet[2:].zfill(64)
    opening=int(get('eth_call',[{'to':TOKEN,'data':'0x70a08231'+wallet[2:].zfill(64)},hex(w['first_block']-1)]),16)
    closing=int(get('eth_call',[{'to':TOKEN,'data':'0x70a08231'+wallet[2:].zfill(64)},hex(w['last_block'])]),16)
    logs=[l for l in observed.values() if w['first_block']<=int(l['blockNumber'],16)<=w['last_block']]
    incoming=sum(int(l['data'],16) for l in logs if l['topics'][2]==topic);outgoing=sum(int(l['data'],16) for l in logs if l['topics'][1]==topic)
    ck((opening,closing,incoming,outgoing)==tuple(int(b[k+'_raw']) for k in ('opening','closing','in','out')),wallet+' independent balances and aggregates')
    ck(opening+incoming-outgoing==closing,wallet+' historical state conservation')
    balances.append({'wallet':wallet,'window':b['window'],'opening':fmt(opening),'incoming':fmt(incoming),'outgoing':fmt(outgoing),'closing':fmt(closing)})
common=read(P/'common_cut_verified.json');block=common['block_number'];header=get('eth_getBlockByNumber',[hex(block),False])
ck(common['token']==TOKEN and common['block_hash']==header['hash'] and common['utc']==utc(header),'common-cut canonical token and exact header')
ck(len(common['balances'])==6 and len({b['address'] for b in common['balances']})==6,'six unique common-cut wallets')
common_total=0
for cb in common['balances']:
    wallet=cb['address'];state=int(get('eth_call',[{'to':TOKEN,'data':'0x70a08231'+wallet[2:].zfill(64)},hex(block)]),16)
    ck(state==int(cb['balance_raw']) and Decimal(cb['balance_busd'])==Decimal(fmt(state)),wallet+' directly pinned common state')
    b=next(b for b in claims['window_balances'] if b['address']==wallet);window=next(w for w in claims['windows'] if w['name']==b['window'])
    ck(window['first_block']-1<=block<=window['last_block'],wallet+' common-cut within full query coverage')
    total=int(b['opening_raw'])
    for log in observed.values():
        if window['first_block']<=int(log['blockNumber'],16)<=block:
            total+=int(log['data'],16)*((log['topics'][2][-40:]==wallet[2:])-(log['topics'][1][-40:]==wallet[2:]))
    ck(total==state,wallet+' common-cut independently reconciled from raw log incidence');common_total+=state
ck(common_total==int(common['total_raw']) and Decimal(common['total_busd'])==Decimal(fmt(common_total)),'common-cut exact six-wallet total')
ck(common_total==403500914021983632450616,'prior frontier value corroborated at one common block')
# Independently decode the only positive BUSD event in transaction context.
# The receipt is a token swap initiated by8724; the BUSD sender is the pair.
swap=read(P/'swap_verified.json');th=swap['transaction'];tx=get('eth_getTransactionByHash',[th]);receipt=get('eth_getTransactionReceipt',[th]);data=tx['input']
ck(data[:10]=='0x38ed1739' and receipt['status']=='0x1','ULX swap successful exact selector')
words=[data[i:i+64] for i in range(10,len(data),64)]
ck(len(words)==8 and int(words[2],16)==160 and int(words[5],16)==2,'swap ABI dynamic two-token path layout')
in_raw=int(words[0],16);min_raw=int(words[1],16);recipient='0x'+words[3][-40:];path=['0x'+x[-40:] for x in words[6:8]]
ck(tx['from'].lower()==recipient==swap['initiator']==swap['recipient'],'swap initiator and recipient8724 identical')
ck(tx['to'].lower()==swap['router'] and path==swap['path'] and path[1]==TOKEN,'router target and exact token path')
ck(in_raw==int(swap['input_amount_raw']) and min_raw==int(swap['minimum_output_raw']),'calldata input amount and minimum output')
logs=[l for l in receipt['logs'] if l['topics'][0]==TRANSFER]
ck(len(logs)==2,'receipt exactly two token transfers')
first=next(l for l in logs if l['address'].lower()==path[0]);last=next(l for l in logs if l['address'].lower()==TOKEN)
pair='0x'+first['topics'][2][-40:];out_raw=int(last['data'],16)
ck(first['topics'][1][-40:]==recipient[2:] and int(first['data'],16)==in_raw and pair==swap['pair'],'input token8724 to pair exact amount')
ck(last['topics'][1][-40:]==pair[2:] and last['topics'][2][-40:]==recipient[2:] and out_raw>=min_raw and out_raw==int(swap['output_amount_raw']),'BUSD pair to8724 exact amount and slippage minimum')
metadata={}
for field,selector in [('decimals','0x313ce567'),('symbol','0x95d89b41'),('name','0x06fdde03')]:
    value=get('eth_call',[{'to':path[0],'data':selector},hex(swap['block_number'])])
    if field=='decimals':metadata[field]=int(value,16)
    else:
        blob=bytes.fromhex(value[2:]);offset=int.from_bytes(blob[:32],'big');size=int.from_bytes(blob[offset:offset+32],'big');metadata[field]=blob[offset+32:offset+32+size].decode()
ck(metadata=={'decimals':18,'symbol':'ULX','name':'Ultron'},'historical input-token contract metadata exact')
ck(metadata['decimals']==swap['input_token_decimals'] and metadata['symbol']==swap['input_token_historical_symbol'] and metadata['name']==swap['input_token_historical_name'],'claimed token metadata matches calls')
ck(Decimal(swap['input_amount'])==Decimal(fmt(in_raw)) and Decimal(swap['output_amount_busd'])==Decimal(fmt(out_raw)),'swap human-readable units exact')
ck('origin/acquisition' in swap['qualification'] and 'not established' in swap['qualification'],'ULX acquisition and original-fund linkage not inferred')
# Check that new opening state continues the previously frozen boundary without a gap.
for baseline in read(P/'prior_baselines.json'):
    source=ROOT/baseline['source_path'];ck(hashlib.sha256(source.read_bytes()).hexdigest()==baseline['source_sha256'],'prior baseline file identity '+baseline['address'])
    b=next(b for b in claims['window_balances'] if b['address']==baseline['address']);w=next(w for w in claims['windows'] if w['name']==baseline['window'])
    ck(int(b['opening_raw'])==int(baseline['closing_raw']) and w['first_block']==baseline['prior_cutoff_block']+1,'prior state continuity '+baseline['address'])
manifest=P/'SHA256SUMS.txt'
if manifest.exists():
    inputs[str(manifest.relative_to(ROOT))]=hashlib.sha256(manifest.read_bytes()).hexdigest()
    for line in manifest.read_text().splitlines():
        sha,rel=line.split(None,1);rel=rel.lstrip('*');ck(hashlib.sha256((P/rel).read_bytes()).hexdigest()==sha,'frozen BUSD manifest '+rel)
result={'status':'PASS','checks':len(checks),'method':'Independent RPC request/response identity and hash audit, interval-union proof of complete incoming and outgoing coverage for each wallet/window, canonical event decoding, and historical-state conservation.',
'input_sha256':inputs,'swap_context':swap,'common_cut':common,'failed_captures':failed,'unique_transfer_events':len(observed),'successful_log_queries':len(queries),'windows':windows,'balances':balances,
'limits':['Zero movements only applies within exact declared successful query windows. It does not prove later inactivity, current recoverability, transaction purpose or ownership.','These BSC BUSD balances are separate from Ethereum USDC/USDT and ML reserves.'],
'assertions':checks}
(OUT/'busd_tail_review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('status','checks','unique_transfer_events','successful_log_queries')},indent=2))
