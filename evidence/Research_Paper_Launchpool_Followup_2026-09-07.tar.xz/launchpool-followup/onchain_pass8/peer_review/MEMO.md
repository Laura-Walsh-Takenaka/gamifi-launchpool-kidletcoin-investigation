# Pass8 independent verification

All checks are offline and use saved evidence. These scripts do not import or execute collectors, make network calls, or change the source lanes. They write their own result JSON files under this peer-review directory. Previous frozen pass6/pass7 ledger certification is inherited where noted; this review does not repeat the prior 4,905 checks.

## Selected USDT return source bounds

`verify_source.py` independently builds the two-dimensional feasible allocation polytope for the selected July23 return at 1991, finds its four rational vertices, and checks every published endpoint allocation chronologically. This differs from the source collector's greedy extremal algorithm.

The selected return is 58,724.105382 USDT. Gross payments into the 188b and KuCoin branches total127,789.299506 USDT. The selected return's contribution to those branches jointly is54,724.105382–58,724.105382 USDT. The first188b branch alone contains13,507.086687–21,882.27 USDT of that return; KuCoin alone contains32,841.835382–41,217.018695. Separate minima cannot be added because they share the same source and outside-funds budgets.

The math initially uses the frozen indexed 1991 history. `verify_eth.py` independently confirms that the selected six-event window has complete bidirectional raw canonical USDT logs and historical opening 8,375.183313/closing 0 states. `verify_source.py` crosschecks all 15 corroborating file hashes against that independent review. This upgrades only the selected USDT window; the separate initial IAG USDC reconstruction retains its own conditions. Nothing here attributes original fundraising, investment profit, legal entitlement, an exchange account, or personal receipt to Laura.

## Ethereum route and USDC source bound

`verify_eth.py` checks successful response bytes and metadata hashes, request serialization, RPC IDs, exact incoming/outgoing query coverage, canonical tokens and topics, historical state equations, selected successful receipts, calldata and block identities. It excludes the failed broad 1991 outgoing request from coverage; six successful narrower requests cover that direction without gaps. The initial failed block-header batch is also retained as failure, never interpreted as an empty result.

The1991→188b→0d56 route carries 21,882.27 USDT. Both intermediaries have zero opening/closing balances and only two positive events; 188b's one zero-value lookalike event is separately retained. Kraken7's address itself calls `transferFrom` to collect the 21,882.27 USDT. The review verifies the raw caller, canonical USDT target, exact three arguments, successful receipt and matching emitted transfer. The Kraken7 service label is distinct from the still-unidentified service customer.

The separate USDC route sends 66,600 USDC from 2fb794 to the explorer-labeled Binance deposit 67124. Conservation and independently replayed feasible allocations prove that 20,242.070612–21,664 USDC comes from the selected d541→0585 payment. The proof retains 0585's452.461220 USDC opening balance, 2fb794's969.468168 USDC closing balance, and the internal 60 USDC refund loop. It does not establish that d541's selected payment came from its earlier mixed July24 receipt: zero attribution from that earlier receipt remains feasible.

The independent reviewer extracted the four exact explorer titles and original body hashes into `independent_label_snapshots.json`. Portable checks compare these factual extracts with the lane's label records, exact request URLs and original capture metadata. Full third-party HTML is intentionally not required. The non-token router transaction is verified through its successful receipt and exact canonical USDC log; its full calldata is retained without asserting an independently decoded router ABI.

## Original BUSD graph frontier

`verify_frontier.py` independently deduplicates 34 positive events from five already certified frozen ledgers and sums their account incidence. It enumerates five positive opening balances and recovers six nonzero dated leaf balances:

903,794.346419582485370326 original BUSD + 1,167.08760240114708029 prior BUSD = 501,460.52 BUSD in seven Binance receipts + 403,500.914021983632450616 BUSD at the dated graph frontiers.

The arithmetic residual is exactly zero. The frontier dates differ. This is not a common-date/current snapshot, a full purchaser-to-settlement reconciliation, proof of payment purpose, an entitlement determination, or proof that funds remain recoverable.

## BUSD tail and common-block state

`verify_busd_tail.py` independently checks 84 successful log queries, all exact incoming/outgoing coverage windows, historical opening/closing state, the one positive canonical BUSD event and its successful receipt. No queried BUSD outflow occurred. The original recorded balances continue into the next windows without gaps; all six prior baseline file hashes and boundary values match.

The only positive BUSD event is a swap initiated by 8724 on 18 November 2022 at 17:38:52 UTC. Its transaction sends 57,357.66598584903399695 ULX to the pair and returns 3,457.600228610921015515 BUSD. The verifier independently decodes the exact two-token calldata path, minimum output and recipient, matches both canonical Transfer logs, and checks the input token's historical contract-returned metadata: Ultron/ULX, 18 decimals. This is a wallet-initiated swap, not evidence of a new funding transfer from an unrelated cash sender. Acquisition of the input ULX and any original-fund contribution remain unestablished.

The review also confirms a genuinely common-block snapshot: all six residual wallets total 403,500.914021983632450616 BUSD at block 23,129,158, 17 November 2022 at 09:02:15 UTC. Six directly pinned historical state calls reconcile to raw log incidence. This establishes the same numerical residual at one block, distinct from the earlier frontier's mixed cutoff dates. Neither snapshot states current holdings or recoverability.

## Final verification totals

| Independent script | Checks | Result |
|---|---:|---|
| Ethereum routes, states, labels and selected USDC source bounds |887|PASS|
| Selected USDT return bounds and raw-evidence crosscheck |96|PASS|
| Prior BUSD graph frontier |88|PASS|
| BUSD tail, common-block states, swap and capture manifest |1156|PASS|
| Total |2227|PASS|

The Ethereum lane's 134 and BUSD lane's 195 distributable manifest entries pass byte-hash verification. These are additional current-pass checks. Passing checks establishes the stated bounded evidence and arithmetic; it does not identify the humans behind the wallets or their payment authority.

## Reproduction order

Run from the evidence bundle root:

```sh
python onchain_pass8/peer_review/verify_eth.py
python onchain_pass8/peer_review/verify_source.py
python onchain_pass8/peer_review/verify_frontier.py
python onchain_pass8/peer_review/verify_busd_tail.py
```

The source-bound verifier reads the independent Ethereum review, so run the Ethereum verifier first. All paths are resolved from the script location; no absolute workspace path or external dependency is needed.
