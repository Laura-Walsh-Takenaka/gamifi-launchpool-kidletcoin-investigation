#!/usr/bin/env python3
"""Offline verification of frozen Ethereum tail captures. No network or third-party modules.
Run: python onchain_pass8/eth_tail/verify_tail.py --check
"""
from pathlib import Path
from decimal import Decimal
import datetime, hashlib, json, re, sys
P=Path(__file__).resolve().parent
T='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
USDC='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';USDT='0xdac17f958d2ee523a2206206994597c13d831ec7'
W={'1991':'0x1991e27e2908847c0274a662eb6675002e8386d0','188b':'0x188b1922d1961500cbd30066029590cb20dbd817','0d56':'0x0d560ac1b578ee5ac815a0e096cac37cb4c0eb5e','0585':'0x0585b2d1df27523712561163f73210096202ad52','22c84':'0x22c84da2d2f89873dd18e957609c0f0eb9c628f8','2fb794':'0x2fb794baf5c06c011b705123a0a07375633ff4a8'}
SPECS={'1991':(USDT,20369851,20375526),'188b':(USDT,20369900,20377136),'0d56':(USDT,20369936,20377136),'0585':(USDC,20417688,20424888),'22c84':(USDC,20417688,20425508),'2fb794':(USDC,20418690,20425890)}
checks=[]
def ck(v,s):
 if not v:raise AssertionError(s)
 checks.append(s)
def read(n):return json.loads((P/n).read_text())
def amt(n):return format(Decimal(n)/1000000,'f')
def utc(n):return datetime.datetime.fromtimestamp(n,datetime.timezone.utc).isoformat()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# Every successful response is hash checked against its contemporaneous receipt.
for f in sorted(P.glob('*.receipt.json')):
 r=read(f.name);q=read(r['request_file']);ck(q['response_file']==r['response_file'],f'{f.name} response name')
 if q.get('request_body_utf8') is not None:
  ck(hashlib.sha256(q['request_body_utf8'].encode()).hexdigest()==q['request_body_sha256'],f'{f.name} request hash')
  ck(json.loads(q['request_body_utf8'])==q['jsonrpc_body'],f'{f.name} request JSON')
 if r.get('status')==200 and not r['response_file'].endswith('.html'):
  z=P/r['response_file'];ck(z.exists(),f'{f.name} response exists');ck(z.stat().st_size==r['bytes'],f'{f.name} size');ck(h(z)==r['sha256'],f'{f.name} response hash')
# Retain, rather than silently treating, failed RPC calls as absence of events.
ck(read('boundary_blocks.json.receipt.json')['status']==500,'dRPC initial six-call free plan rejection retained')
ck((P/'boundary_blocks.json.error_body').exists(),'dRPC failure body retained')
ck(read('1991_raw_logs.json')[0]['error']['code']==-32602,'1991 initial outgoing range rejection retained')
blocks={}
for f in sorted(P.glob('*bounds_*.json'))+sorted(P.glob('boundary_blocks_[03].json')):
 if '.request.' in f.name or '.receipt.' in f.name:continue
 for r in read(f.name):
  b=r['result'];bn=int(b['number'],16);ck(bn==r['id'],f'{f.name} pinned block');blocks[bn]={'hash':b['hash'],'utc':utc(int(b['timestamp'],16))}
def norm(z):
 return {'transaction_hash':z['transactionHash'],'block':int(z['blockNumber'],16),'block_hash':z['blockHash'],'transaction_index':int(z['transactionIndex'],16),'log_index':int(z['logIndex'],16),'utc':utc(int(z['blockTimestamp'],16)),'token':z['address'],'from':'0x'+z['topics'][1][-40:],'to':'0x'+z['topics'][2][-40:],'value_raw':str(int(z['data'],16)),'amount':amt(int(z['data'],16))}
ledgers={};raw_by_key={}
for name,(token,start,end) in SPECS.items():
 files=[name+'_raw_logs.json']+(['1991_out_retry_0.json','1991_out_retry_2.json','1991_out_retry_4.json'] if name=='1991' else [])
 evs={};coverage={0:[],1:[]}
 for fn in files:
  q={z['id']:z for z in read(fn+'.request.json')['jsonrpc_body']}
  for r in read(fn):
   if 'error' in r:continue
   query=q[r['id']]['params'][0];direction=0 if len(query['topics'])==2 else 1
   ck(query['address']==token and query['topics'][0]==T,fn+' canonical token/topic')
   ck(query['topics'][-1]=='0x'+W[name][2:].rjust(64,'0'),fn+' exact wallet topic')
   a,b=int(query['fromBlock'],16),int(query['toBlock'],16);coverage[direction].append((a,b))
   ck(isinstance(r['result'],list),fn+' logs result list')
   for z in r['result']:
    ck(z['address']==token and z['topics'][0]==T,fn+' canonical log')
    ck(not z.get('removed',False),fn+' log not removed')
    ck(a<=int(z['blockNumber'],16)<=b,fn+' log within range')
    e=norm(z);ck(e['from' if direction==0 else 'to']==W[name],fn+' direction match')
    key=(e['transaction_hash'],e['log_index']);ck(key not in evs,fn+' no duplicate scoped event');evs[key]=e
    if key in raw_by_key:ck(raw_by_key[key]==z,fn+' shared edge matches exact raw log')
    raw_by_key[key]=z
 for d in (0,1):
  cov=sorted(coverage[d]);ck(cov[0][0]==start and cov[-1][1]==end,name+' exact coverage endpoints')
  ck(all(cov[i][1]+1==cov[i+1][0] for i in range(len(cov)-1)),name+' contiguous nonoverlapping coverage')
 q=read(name+'_state.json.request.json')['jsonrpc_body'];r={z['id']:z['result'] for z in read(name+'_state.json')};states={}
 for z in q:
  ck(z['method']=='eth_call',name+' historical state method');ck(z['params'][0]=={'to':token,'data':'0x70a08231'+W[name][2:].rjust(64,'0')},name+' balanceOf input')
  bn=int(z['params'][1],16);ck(bn in (start-1,end),name+' pinned state boundary');states[bn]=int(r[z['id']],16)
 ordered=sorted(evs.values(),key=lambda e:(e['block'],e['transaction_index'],e['log_index']));balance=states[start-1];incoming=outgoing=0
 for e in ordered:
  v=int(e['value_raw'])
  if e['to']==W[name]:balance+=v;incoming+=v
  if e['from']==W[name]:balance-=v;outgoing+=v
  ck(balance>=0,name+' nonnegative chronological balance');e['balance_after_raw']=str(balance);e['balance_after']=amt(balance)
 ck(balance==states[end],name+' independent closing balance reconciliation')
 ledgers[name]={'wallet':W[name],'token':token,'start_block':start,'end_block':end,'opening_balance':amt(states[start-1]),'incoming':amt(incoming),'outgoing':amt(outgoing),'closing_balance':amt(balance),'positive_event_count':sum(int(e['value_raw'])>0 for e in ordered),'zero_event_count':sum(int(e['value_raw'])==0 for e in ordered),'events':ordered}
 if name in ['0d56','0585','22c84','2fb794']:
  indexed=read(name+'_initial_indexed.json')['result']
  ik={(z['hash'],int(z['blockNumber']),z['from'],z['to'],int(z['value'])) for z in indexed}
  rk={(z['transaction_hash'],z['block'],z['from'],z['to'],int(z['value_raw'])) for z in ordered}
  ck(ik==rk and len(indexed)==len(ordered),name+' complete indexed/raw log agreement')
# Selected successful transaction receipts, calldata and raw transfer logs.
selected=[]
for f in sorted(P.glob('0x*_receipt_tx.json')):
 q=read(f.name+'.request.json')['jsonrpc_body'];j={z['id']:z['result'] for z in read(f.name)};r,tx=j[0],j[1]
 ck(r['status']=='0x1',f.name+' successful receipt');ck(r['transactionHash']==tx['hash']==q[0]['params'][0]==q[1]['params'][0],f.name+' matching transaction hashes')
 ck(r['blockHash']==tx['blockHash'] and r['blockNumber']==tx['blockNumber'],f.name+' tx block agreement')
 scoped=[]
 for z in r['logs']:
  key=(z['transactionHash'],int(z['logIndex'],16))
  if key in raw_by_key:
   a=raw_by_key[key]
   ck(all(z[k]==a[k] for k in ['transactionHash','blockHash','blockNumber','address','topics','data','logIndex']),f.name+' canonical receipt/raw log agreement')
   scoped.append(norm(a))
 ck(bool(scoped),f.name+' selected receipt includes scoped transfer')
 selector=tx['input'][:10];calldata_checked=False
 if selector in ('0xa9059cbb','0x23b872dd'):
  words=[tx['input'][i:i+64] for i in range(10,len(tx['input']),64)]
  if selector=='0xa9059cbb':frm=tx['from'];to='0x'+words[0][-40:];value=int(words[1],16)
  else:frm='0x'+words[0][-40:];to='0x'+words[1][-40:];value=int(words[2],16)
  ck(any(e['token']==tx['to'] and e['from']==frm and e['to']==to and int(e['value_raw'])==value for e in scoped),f.name+' exact transfer calldata');calldata_checked=True
 selected.append({'receipt_file':f.name,'transaction_hash':tx['hash'],'transaction_caller':tx['from'],'transaction_to':tx['to'],'selector':selector,'calldata_transfer_checked':calldata_checked,'events':scoped})
ck(len(selected)==13,'13 selected successful receipts')
kraken=next(z for z in selected if z['transaction_hash'].startswith('0x2d7f8d'))
ck(kraken['transaction_caller']=='0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40' and kraken['selector']=='0x23b872dd','Kraken7 itself collected via transferFrom')
# Bind source scenarios and route conclusions to independently captured state.
for name,opening,closing in [('1991','8375.183313','0'),('188b','0','0'),('0d56','0','0'),('0585','452.46122','452.46122'),('22c84','0','0'),('2fb794','31008.122752','969.468168')]:
 ck(ledgers[name]['opening_balance']==opening and ledgers[name]['closing_balance']==closing,name+' stated opening/closing amounts')
for name,sender,recipient in [('188b',W['1991'],W['0d56']),('0d56',W['188b'],'0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40')]:
 events=[e for e in ledgers[name]['events'] if int(e['value_raw'])>0]
 ck(len(events)==2 and all(e['amount']=='21882.27' for e in events),name+' exact two-event amount')
 ck(events[0]['from']==sender and events[0]['to']==W[name] and events[1]['from']==W[name] and events[1]['to']==recipient,name+' exact route participants')
# Construct two feasible chronological source-color allocations for the entire USDC chain.
# Source here is the d541 July30 payment, not its July24 mixed-balance source.
def scenario(minimum):
 balances={'0585':[0,452461220],'22c84':[0,0],'2fb794':[0,31008122752]};sent=[]
 def move(a,b,v,source):
  ck(0<=source<=v,'color nonnegative transfer split')
  if a in balances:
   ck(balances[a][0]>=source and balances[a][1]>=v-source,'color chronological funds available');balances[a][0]-=source;balances[a][1]-=v-source
  if b in balances:balances[b][0]+=source;balances[b][1]+=v-source
  sent.append({'from':a,'to':b,'amount':amt(v),'selected_payment_component':amt(source)})
 move('d541','0585',21664000000,21664000000)
 transfer_source=21211538780 if minimum else 21664000000
 move('0585','22c84',21664000000,transfer_source)
 move('22c84','2fb794',100000000,100000000)
 move('2fb794','22c84',60000000,0)
 move('22c84','2fb794',21624000000,transfer_source-100000000)
 move('outside','2fb794',14897345416,0)
 binance_source=transfer_source-969468168 if minimum else transfer_source
 move('2fb794','BinanceDeposit67124',66600000000,binance_source)
 # Later July31 flows occur after the Binance payment and can use only new outside cash.
 move('outside128000','0585',128000000000,0)
 move('outside92500','0585',92500000000,0)
 move('0585','66e092',220500000000,0)
 ck(sum(balances['2fb794'])==969468168,'color final2fb balance')
 ck(sum(balances['0585'])==452461220 and sum(balances['22c84'])==0,'color final intermediate balances')
 return {'binance_component':amt(binance_source),'transfers':sent,'final_balances_raw':balances}
scenarios=[scenario(True),scenario(False)]
ck([x['binance_component'] for x in scenarios]==['20242.070612','21664'],'USDC payment-source feasible interval')
labels=read('label_records.json')
ck(any(x['address']=='0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40' and x['exact_title'].startswith('Kraken 7 |') for x in labels),'primary Kraken7 label recorded')
ck(any(x['address']=='0x67124cb10bd4cd6de2946caa1a905c61f05c838e' and x['exact_title'].startswith('Binance Deposit:') for x in labels),'primary Binance deposit label recorded')
result={'status':'PASS','check_count':len(checks),'network':'Ethereum mainnet','token_decimals':6,'scope':'Historical bounded captures, not current balances. No human or exchange-customer attribution.','boundary_blocks':blocks,'ledgers':ledgers,'selected_successful_receipts':selected,'usdc_source_scenarios':scenarios,'checks':checks}
if '--check' in sys.argv:
 prior=read('summary.json');ck(json.loads(json.dumps(result))==prior,'summary deterministic reproduction');print(json.dumps({'status':'PASS','checks':len(checks),'ledger_positive_events':sum(x['positive_event_count'] for x in ledgers.values()),'selected_successful_receipts':len(selected)},indent=2))
else:
 (P/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'PASS','checks':len(checks),'summary':'summary.json'},indent=2))
