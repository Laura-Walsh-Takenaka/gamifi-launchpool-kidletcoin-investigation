# Pass8: Ethereum return tails reach Kraken7 and another Binance deposit

Research and capture date: 2026-09-07 UTC. All values below are exact token units except explicitly stated bounds. These are historical bounded balances, not September2026 holdings. Canonical Ethereum USDT is `0xdac17f958d2ee523a2206206994597c13d831ec7`; canonical USDC is `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48`; both use six decimals. Full wallet addresses, transaction hashes, event indices, block hashes, exact query windows and state inputs are in `summary.json` and paired request/response captures.

## New USDT endpoint: the July23 return branch was collected by Kraken7

The previously unresolved `0x0d560ac1b578ee5ac815a0e096cac37cb4c0eb5e` (0d56) tail ends at the explorer-labeled **Kraken7**, `0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40`, on 23 July2024.

| UTC | From | To | USDT | Transaction |
|---|---|---|---:|---|
| July23 14:42:35 | 1991 | 188b | 21882.27 | `0x80c22d120cf43e2192e19920636dfa77ccf65508437ffec0e6c4b426a86a7df5` |
| July23 14:49:47 | 188b | 0d56 | 21882.27 | `0x3c16f58a165c1040ac5a529c0e5c630f461e20b6eb050f7ecb69791ef0223b9c` |
| July23 14:51:59 | 0d56 | Kraken7 | 21882.27 | `0x2d7f8d2319465342ca9766215c00fbded8896cdabe7a1e620cd261009650e987` |

The final movement occurred **2m12s** after receipt at0d56 and **9m24s** after departure from1991. It was a successful **transferFrom(0d56,Kraken7,21882.27)** call signed/submitted by the Kraken7 address itself to canonical USDT. The actual sender, calldata, receipt status1 and canonical Transfer log agree. This is operationally stronger than a transfer merely landing at a service-labeled address, but it does not disclose the Kraken customer or a human controller.

188b (`0x188b1922d1961500cbd30066029590cb20dbd817`) and0d56 each had historical **zero opening and closing USDT** balances in their stated windows. Each had only one positive incoming and one positive outgoing transfer. 188b also has one canonical zero-value transfer to the similar-looking `0x0d566afdeb4ef0ecaef6f05f30bbb16e3371eb5e`; it is retained in the ledger and excluded from positive cash tracing. The genuine cash recipient remains exact0d56 above.

The source1991 is `0x1991e27e2908847c0274a662eb6675002e8386d0`. Its **8375.183313USDT** opening balance at block20369850 and **zero** closing at20375526 are now successful historical balanceOf results. Raw logs in both directions fully cover20369851–20375526, July23 14:32:47 through July24 09:32:23UTC. The six positive events are:

| Flow | USDT |
|---|---:|
| Opening prior cash | 8375.183313 |
| Return from183600 | +58724.105382 |
| Paid188b, subsequently collected byKraken7 | -21882.27 |
| Paid2c94 | -4000 |
| Received fromMEXC1 address75e89 | +14690.010811 |
| Received from33b2 | +50000 |
| PaidKuCoin deposit327a | -105907.029506 |
| Closing | 0 |

This upgrades the opening balance and complete six-event attribution window from indexed reconstruction to historical state plus raw RPC logs. It does not mean that all gross exchange receipts were the selected trading return. Parent/source-accounting analysis treats the shared prior cash and later receipts jointly and avoids adding independently maximized bounds.

## New USDC endpoint: 0585's next payment joins a 66600 transfer to Binance

The previous tail was d541's July30 **21664USDC** payment to `0x0585b2d1df27523712561163f73210096202ad52` (0585). It continues the same day through22c84 and2fb794 to a different Ethereum exchange endpoint: Etherscan's **Binance Deposit**, `0x67124cb10bd4cd6de2946caa1a905c61f05c838e`.

| July30 UTC | From | To | USDC | Transaction |
|---|---|---|---:|---|
| 06:47:35 | d541 | 0585 | 21664 | `0x99e13b72626a5296c1b9c6ff709b9e806a10caa0883c35761c8d9333a81215ce` |
| 08:52:59 | 0585 | 22c84 | 21664 | `0x82ddb902ab39aa3f295a966409fa73abd0a81fa0143da55b4089bfdaabcfcd4f` |
| 10:11:23 | 22c84 | 2fb794 | 100 | `0x7d6c77a2ffb66f8c6d39c1e33d5630d55f22f5f7a17478ab52c32f59a0de7744` |
| 11:13:35 | 2fb794 | 22c84 | 60 | `0x7599c6f4760079e147ff9bd6bcc35954e7663ec1df0e6f12647293ccd9146890` |
| 12:53:23 | 22c84 | 2fb794 | 21624 | `0x2622f92784587109443797970373c93c2190b35be62e8b453cea7bccb48f9807` |
| 13:47:47 | outside74de | 2fb794 | 14897.345416 | `0xd96bef3d10948bfc4b9062fec5fb7fc56d5f046c19ea32baed235d894917043d` |
| 13:50:59 | 2fb794 | Binance deposit67124 | 66600 | `0x4e51df9d444cfde748c2428a976f9bcdd8c88dd3dee7a4595d1c51032a727651` |

Full intermediate addresses:
- 22c84: `0x22c84da2d2f89873dd18e957609c0f0eb9c628f8`
- 2fb794: `0x2fb794baf5c06c011b705123a0a07375633ff4a8`
- d541: `0xd5417e96dd04363c675e41ee6f30bf788412c719`
- outside74de: `0x74de5d4fcbf63e00296fd95d33236b9794016631`

The21664 movement to22c84 followed receipt at0585 by **2h05m24s**. Binance received the66600 payment **57m36s** after22c84's final21624 payment, and **3m12s** after the outside14897.345416 input. Direct Ethereum Etherscan captures label only the Binance deposit;22c84 and2fb794 have generic address titles.

Successful historical balances establish0585's **452.461220** priorUSDC,22c84's zero priorUSDC, and2fb794's **31008.122752** priorUSDC.22c84 ends at zero;2fb794 ends at **969.468168**. Their complete raw canonical logs reconcile all incoming and outgoing values.0585 also receives128000 and92500 onJuly31 and sends220500 to66e092; these later movements are fully included in0585's captured ledger. They occur after the Binance payment and do not change its source bound.

The Binance66600 payment necessarily contains **20242.070612–21664USDC of d541's July30 payment**, treating tokens as fungible and accounting for the0585 prior balance and2fb ending balance. The lower endpoint is21664−452.461220−969.468168. Both endpoints have explicit feasible chronological source-color allocations in the verifier; the60 refund is an internal loop, not new outside funds or a second source payment.

**That is a payment-source bound, not an IAG-return bound.** d541 already had228092.803239USDC before receiving318192.18 onJuly24. Those old funds could cover its entire21664 payment. Therefore a zero contribution from that specificJuly24 receipt to this Binance route remains feasible. Neither the66600 gross payment nor the21664 branch can be counted wholesale as IAG fundraising or trading-return money. No service-account customer or Laura receipt is identified.

## Exact coverage, limitations and reproduction

| Wallet/token | Inclusive block range | Last block UTC | Opening | Totalin | Totalout | Closing | Positive/zero events |
|---|---|---|---:|---:|---:|---:|---:|
| 1991USDT | 20369851–20375526 | July24 09:32:23 | 8375.183313 | 123414.116193 | 131789.299506 | 0 | 6/0 |
| 188bUSDT | 20369900–20377136 | July24 14:56:11 | 0 | 21882.27 | 21882.27 | 0 | 2/1 |
| 0d56USDT | 20369936–20377136 | July24 14:56:11 | 0 | 21882.27 | 21882.27 | 0 | 2/0 |
| 0585USDC | 20417688–20424888 | July31 06:57:35 | 452.461220 | 242164 | 242164 | 452.461220 | 5/0 |
| 22c84USDC | 20417688–20425508 | July31 09:01:59 | 0 | 21724 | 21724 | 0 | 4/0 |
| 2fb794USDC | 20418690–20425890 | July31 10:18:47 | 31008.122752 | 36621.345416 | 66660 | 969.468168 | 5/0 |

The exploration windows approximate the first24hours and deliberately state exact block/time endpoints; some are slightly longer. Exchange endpoints were found within the firstday, so no seven-day extension was needed. Ledgers contain24positive scoped rows plusonezero; shared edges occur in both endpoint ledgers and must not be summed as distinct funds. There are13selected successful transaction receipt/transaction-input pairs. Canonical raw logs and12successful historical balanceOf calls cover all six ledgers. The13receipts include the newKraken collection and the fullUSDC branch; not all1991 pre-existing six events have new receipt pairs in this lane, though all six have new complete raw log coverage and priorpass6 receipts remain preserved.

Two provider failures are explicit: dRPC rejected an initial six-call batch (free plan maximum3), so block reads were split into batches of at most3. Blockmachine rejected1991's initial outgoing range as exceeding1000; six contiguous smaller queries cover the exact same range and succeeded. No failure is interpreted as zero events. Successful raw capture bodies, request JSON, request timestamps, response SHA256 receipts and the initial dRPC error body are retained. Full third-party explorer HTML is local retrieval material, excluded from the distributable manifest; only exact factual label/title records and capture hashes are distributed.

Reproduce offline with:

```sh
python onchain_pass8/eth_tail/verify_tail.py --check
```

The standard-library verifier checks raw receipt hashes, exact queries, gap-free both-direction coverage, canonical topics/contracts, historical state, chronological balance conservation, indexed/raw agreement where indexed discovery was used, successful selected receipts, calldata, Kraken's collection call and both feasibleUSDC source allocations. It requires no files outside this lane and makes no network calls. `SHA256SUMS.txt` covers distributable files; the manifest excludes itself and fullHTML. `summary.json` contains exact machine-readable findings. The remaining nonpublic gap is exchange-account/customer identity and authority over funds, not another forced ownership inference from shared infrastructure.
