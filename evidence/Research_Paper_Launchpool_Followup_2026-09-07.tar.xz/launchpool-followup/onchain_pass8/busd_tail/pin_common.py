import json
from trace_tail import P,rpc,q,BUSD,A,B,T,dec
r=json.loads((P/'tail_verified.json').read_text());h=next(w['last_block'] for w in r['windows'] if w['name']=='branch_next7')
addresses=A+T
qs=[q(i,'eth_call',[{'to':BUSD,'data':'0x70a08231'+a[2:].zfill(64)},hex(h)]) for i,a in enumerate(addresses)]
values={}
for part in range(0,len(qs),2):values.update(rpc('common_cut_balances_%03d'%part,qs[part:part+2]))
balances={a:int(values[i],16) for i,a in enumerate(addresses)}
for b in r['window_balances']:
 if b['address'] in B:balances[b['address']]=int(b['closing_raw'])
rows=[]
for a in A+B+T:
 b=next(b for b in r['window_balances'] if b['address']==a);w=next(w for w in r['windows'] if w['name']==b['window'])
 assert w['first_block']-1<=h<=w['last_block']
 entries=[x for x in r['rows'] if w['first_block']<=x['block_number']<=h]
 expected=int(b['opening_raw'])+sum(int(x['amount_raw']) for x in entries if x['to']==a)-sum(int(x['amount_raw']) for x in entries if x['from']==a)
 assert expected==balances[a]
 rows.append({'address':a,'balance_raw':str(balances[a]),'balance_busd':dec(balances[a]),'reconciled_to_window':w['name']})
header=q(0,'eth_getBlockByNumber',[hex(h),False])
# Header already exists inside tail_headers responses; do not request it again.
from datetime import datetime,timezone
for meta in sorted(P.glob('tail_headers_*.receipt.json')):
 m=json.loads(meta.read_text());data=json.loads(meta.with_name(meta.name[:-len('.receipt.json')]+'.response').read_text())
 for row in data:
  if int(row['result']['number'],16)==h:head=row['result']
result={'token':BUSD,'block_number':h,'block_hash':head['hash'],'utc':datetime.fromtimestamp(int(head['timestamp'],16),timezone.utc).isoformat(),'balances':rows,'total_raw':str(sum(balances.values())),'total_busd':dec(sum(balances.values())),'meaning':'One-block historical BUSD balances for the six traced residual leaves. This is gross token custody, not a new amount raised, legal entitlement or present-day holdings.'}
(P/'common_cut_verified.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
