"""Offline, non-mutating independent verification of pass8 BUSD tail capture."""
import pathlib,json,hashlib,datetime,sys
P=pathlib.Path(__file__).resolve().parent
BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56';TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
checks=[]
def check(x,label):
 if not x:raise AssertionError(label)
 checks.append(label)
qmap={};logqueries=[]
for meta in sorted(P.glob('*.receipt.json')):
 m=json.loads(meta.read_text());rp=meta.with_name(meta.name[:-len('.receipt.json')]+'.response')
 if not rp.exists():
  ep=meta.with_name(meta.name[:-len('.receipt.json')]+'.error_body')
  if ep.exists():check(hashlib.sha256(ep.read_bytes()).hexdigest()==m['error_body_sha256'],meta.name+' error hash')
  check('error' in m,meta.name+' failed capture recorded');continue
 raw=rp.read_bytes();check(hashlib.sha256(raw).hexdigest()==m['sha256'],meta.name+' response hash')
 data=json.loads(raw)
 if isinstance(data,dict):data=[data]
 check(len(data)==len(m['request']),meta.name+' row count');dm={x['id']:x for x in data}
 for q in m['request']:
  check(q['id'] in dm,meta.name+' matching id');v=dm[q['id']]
  check('error' not in v,meta.name+' RPC success');qmap[(q['method'],json.dumps(q['params'],sort_keys=True))]=v['result']
  if q['method']=='eth_getLogs':logqueries.append((q['params'][0],v['result']))
def result(method,params):return qmap[(method,json.dumps(params,sort_keys=True))]
res=json.loads((P/'tail_verified.json').read_text());coverage=json.loads((P/'scan_coverage.json').read_text())
check(res['token']==BUSD,'canonical BUSD')
observed={}
for query,ls in logqueries:
 check(query['address']==BUSD and query['topics'][0]==TRANSFER,'canonical log filter')
 lo=int(query['fromBlock'],16);hi=int(query['toBlock'],16);check(0<=hi-lo<10000,'inclusive range cap')
 for l in ls:
  check(l['address'].lower()==BUSD and l['topics'][0]==TRANSFER,'canonical emitted log')
  check(lo<=int(l['blockNumber'],16)<=hi,'emitted log in range')
  check(not l.get('removed',False),'canonical not removed')
  if len(query['topics'])==2:check(l['topics'][1] in query['topics'][1],'outgoing topic matched')
  else:check(l['topics'][2] in query['topics'][2],'incoming topic matched')
  k=(l['transactionHash'],int(l['logIndex'],16));check(k not in observed or observed[k]==l,'duplicate logs equal');observed[k]=l
check(len(observed)==len(res['rows']),'deduplicated count')
for w in res['windows']:
 for a in w['addresses']:
  for direction in ('out','in'):
   ranges=[]
   for q,_ in logqueries:
    topics=q['topics'];ats=topics[1] if direction=='out' and len(topics)==2 else topics[2] if direction=='in' and len(topics)==3 else []
    if '0x'+a[2:].zfill(64) not in ats:continue
    lo=max(w['first_block'],int(q['fromBlock'],16));hi=min(w['last_block'],int(q['toBlock'],16))
    if lo<=hi:ranges.append((lo,hi))
   ranges.sort();cursor=w['first_block']
   for lo,hi in ranges:check(lo==cursor,'contiguous '+w['name']+' '+a+' '+direction);cursor=hi+1
   check(cursor==w['last_block']+1,'full coverage '+a+' '+direction)
 for pos,h in [('first_block_utc',w['first_block']),('last_block_utc',w['last_block']),('after_block_utc',w['last_block']+1)]:
  head=result('eth_getBlockByNumber',[hex(h),False]);u=datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat();check(u==w[pos],'boundary timestamp')
 check(w['last_block_utc']<=w['cutoff_utc']<w['after_block_utc'],'exact cutoff bracket')
for row in res['rows']:
 l=observed[(row['tx_hash'],row['log_index'])];r=result('eth_getTransactionReceipt',[row['tx_hash']]);t=result('eth_getTransactionByHash',[row['tx_hash']]);h=result('eth_getBlockByNumber',[hex(row['block_number']),False])
 check(l in r['logs'],'receipt contains exact log');check(r['status']=='0x1' and row['status']==1,'transaction success');check(l['blockHash']==r['blockHash']==t['blockHash']==h['hash']==row['block_hash'],'independent receipt/header hash match')
 check(row['from']=='0x'+l['topics'][1][-40:] and row['to']=='0x'+l['topics'][2][-40:] and int(row['amount_raw'])==int(l['data'],16),'decoded transfer fields')
 check(row['tx_from']==t['from'] and row['tx_to']==t['to'] and row['tx_input']==t['input'],'calldata retained')
 check(row['utc']==datetime.datetime.fromtimestamp(int(h['timestamp'],16),datetime.timezone.utc).isoformat(),'event UTC')
for b in res['window_balances']:
 w=next(w for w in res['windows'] if w['name']==b['window']);a=b['address'];rows=[r for r in res['rows'] if w['first_block']<=r['block_number']<=w['last_block']]
 for pos,h in [('opening',w['first_block']-1),('closing',w['last_block'])]:
  val=result('eth_call',[{'to':BUSD,'data':'0x70a08231'+a[2:].zfill(64)},hex(h)])
  check(int(val,16)==int(b[pos+'_raw']),'raw historical '+pos)
 inc=sum(int(r['amount_raw']) for r in rows if r['to']==a);out=sum(int(r['amount_raw']) for r in rows if r['from']==a)
 check(inc==int(b['in_raw']) and out==int(b['out_raw']),'aggregate flows from logs');check(int(b['opening_raw'])+inc-out==int(b['closing_raw']),'historical ledger balances')
for base in json.loads((P/'prior_baselines.json').read_text()):
 b=next(b for b in res['window_balances'] if b['window']==base['window'] and b['address']==base['address'])
 w=next(w for w in res['windows'] if w['name']==base['window'])
 check(int(base['closing_raw'])==int(b['opening_raw']) and base['prior_cutoff_block']==w['first_block']-1,'matches prior published cutoff')
common=json.loads((P/'common_cut_verified.json').read_text())
check(common['token']==BUSD,'common cut canonical BUSD')
head=result('eth_getBlockByNumber',[hex(common['block_number']),False])
check(head['hash']==common['block_hash'],'common cut block hash')
for b in common['balances']:
 val=result('eth_call',[{'to':BUSD,'data':'0x70a08231'+b['address'][2:].zfill(64)},hex(common['block_number'])])
 check(int(val,16)==int(b['balance_raw']),'common cut direct historical state')
check(sum(int(b['balance_raw']) for b in common['balances'])==int(common['total_raw']),'common cut total')
swap=json.loads((P/'swap_verified.json').read_text())
tx=result('eth_getTransactionByHash',[swap['transaction']]);rec=result('eth_getTransactionReceipt',[swap['transaction']])
words=[tx['input'][i:i+64] for i in range(10,len(tx['input']),64)]
check(tx['input'][:10]=='0x38ed1739' and int(words[0],16)==int(swap['input_amount_raw']),'swap amount calldata')
check(['0x'+x[-40:] for x in words[6:]]==swap['path']==[swap['input_token'],BUSD],'swap path calldata')
check('0x'+words[3][-40:]==tx['from']==swap['recipient'],'swap beneficiary is initiator')
check(int(result('eth_call',[{'to':swap['input_token'],'data':'0x313ce567'},hex(swap['block_number'])]),16)==swap['input_token_decimals'],'input token historical decimals')
ls=[l for l in rec['logs'] if l['address']==swap['input_token'] and l['topics'][0]==TRANSFER]
check(len(ls)==1 and int(ls[0]['data'],16)==int(swap['input_amount_raw']),'swap input token transfer')
check('0x'+ls[0]['topics'][1][-40:]==swap['initiator'] and '0x'+ls[0]['topics'][2][-40:]==swap['pair'],'swap input direction')
check(int(swap['output_amount_raw'])==int(res['rows'][0]['amount_raw']),'swap BUSD output is the traced inflow')
def decode_string(value):
 raw=bytes.fromhex(value[2:]);offset=int.from_bytes(raw[:32],'big');n=int.from_bytes(raw[offset:offset+32],'big');return raw[offset+32:offset+32+n].decode()
for selector,key in [('0x95d89b41','input_token_historical_symbol'),('0x06fdde03','input_token_historical_name')]:
 check(decode_string(result('eth_call',[{'to':swap['input_token'],'data':selector},hex(swap['block_number'])]))==swap[key],'input token historical string metadata')
sl=[l for l in rec['logs'] if l['address']==swap['pair'] and l['topics'][0]=='0xd78ad95fa46c994b6551d0da85fc275fe613ce37657fb8d5e3d130840159d822']
check(len(sl)==1,'pair swap event exists')
fields=[int(sl[0]['data'][i:i+64],16) for i in range(2,len(sl[0]['data']),64)]
check(fields==[int(swap['input_amount_raw']),0,0,int(swap['output_amount_raw'])],'pair swap input/output amounts')
print(json.dumps({'status':'PASS','checks':len(checks),'unique_events':len(observed),'windows':len(res['windows']),'balances':len(res['window_balances'])},indent=2))
