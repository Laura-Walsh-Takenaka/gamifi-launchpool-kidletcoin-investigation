import pathlib,urllib.request,json,datetime,hashlib,sys,time,csv
from decimal import Decimal,getcontext
getcontext().prec=80
P=pathlib.Path(__file__).parent
U='https://rpc-bsc.blockmachine.io';BNB='https://bsc-dataseed.bnbchain.org'
OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66';BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56';TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
A=[OWNER,'0xbf7f26976b451cee4d055f43dbdb10c0426ce630','0x87245c288fcc858bf7225dc3ab97d0ad94730757']
B=['0xcedfa732228e532ef6e62296cf0f6de188c5d5a0','0xdc127dd1218e555684d7e5605e80afdc75868d42']
T=['0x2108dfd8c35d6426c71173bb85ac01cf86adcc6c']
OFFLINE='--offline' in sys.argv

def rpc(name,qs,url=U):
 meta=P/(name+'.receipt.json');resp=P/(name+'.response')
 if resp.exists():
  m=json.loads(meta.read_text());b=resp.read_bytes();assert m['request']==qs and m['url']==url and m['sha256']==hashlib.sha256(b).hexdigest()
 elif OFFLINE:raise FileNotFoundError(name)
 else:
  m={'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs}
  try:
   with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=45) as r:
    b=r.read();m.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());resp.write_bytes(b)
  except Exception as e:
   m['error']=str(e)
   if hasattr(e,'read'):
    eb=e.read();(P/(name+'.error_body')).write_bytes(eb);m['error_body_sha256']=hashlib.sha256(eb).hexdigest()
   raise
  finally:meta.write_text(json.dumps(m,indent=2))
  time.sleep(8 if url==U else .3)
 data=json.loads(b)
 if isinstance(data,dict):data=[data]
 for row in data:
  if 'error' in row:raise RuntimeError((name,row))
 assert len(data)==len(qs) and set(x['id'] for x in data)==set(x['id'] for x in qs)
 return {x['id']:x['result'] for x in data}
def q(i,m,p):return {'jsonrpc':'2.0','id':i,'method':m,'params':p}
def topic(a):return '0x'+a[2:].zfill(64)
def dec(n):return format(Decimal(n)/Decimal(10**18),'f')
def utc(t):return datetime.datetime.fromtimestamp(t,datetime.timezone.utc).isoformat()
def boundary(name,iso,base):
 target=int(datetime.datetime.fromisoformat(iso).timestamp());low=base+7*25000;high=base+7*30000
 dd=rpc(name+'_initial',[q(n,'eth_getBlockByNumber',[hex(n),False]) for n in [low,high]],BNB)
 assert int(dd[low]['timestamp'],16)<=target<int(dd[high]['timestamp'],16)
 for i in range(20):
  if high-low==1:break
  mid=(low+high)//2;d=rpc(name+'_%02d'%i,[q(mid,'eth_getBlockByNumber',[hex(mid),False])],BNB)[mid]
  if int(d['timestamp'],16)<=target:low=mid
  else:high=mid
 assert high-low==1
 return low,target

def capture_window(pref,first,last,addresses):
 qs=[]
 for start in range(first,last+1,10000):
  for direction in ('out','in'):
   tops=[TRANSFER,[topic(a) for a in addresses]] if direction=='out' else [TRANSFER,None,[topic(a) for a in addresses]]
   qs.append(q(len(qs)+1,'eth_getLogs',[{'address':BUSD,'topics':tops,'fromBlock':hex(start),'toBlock':hex(min(start+9999,last))}]))
 logs=[]
 for part in range(0,len(qs),2):
  dat=rpc(pref+'_logs_%03d'%part,qs[part:part+2])
  for ls in dat.values():logs+=ls
  print(pref,part+2,'/',len(qs),'raw matches',len(logs),flush=True)
 return logs

def enrich(pref,logs,windows):
 logs=list({(l['transactionHash'],l['logIndex']):l for l in logs}.values());logs.sort(key=lambda l:(int(l['blockNumber'],16),int(l['logIndex'],16)))
 assert len(logs)<=250,'Bounded stop: more than250events'
 txs=sorted(set(l['transactionHash'] for l in logs));hs=sorted(set(int(l['blockNumber'],16) for l in logs)|set(h for w in windows for h in [w['first_block']-1,w['first_block'],w['last_block'],w['last_block']+1]));hd={};rd={};td={}
 for part in range(0,len(hs),8):hd.update(rpc(pref+'_headers_%03d'%part,[q(h,'eth_getBlockByNumber',[hex(h),False]) for h in hs[part:part+8]],BNB))
 for method,target_dict,stem in [('eth_getTransactionReceipt',rd,'receipts'),('eth_getTransactionByHash',td,'transactions')]:
  for part in range(0,len(txs),8):
   sub=txs[part:part+8];d=rpc(pref+'_'+stem+'_%03d'%part,[q(i,method,[tx]) for i,tx in enumerate(sub)],BNB);target_dict.update({tx:d[i] for i,tx in enumerate(sub)})
 qs=[];maps={}
 for w in windows:
  for a in w['addresses']:
   for pos in ['opening','closing']:
    h=w['first_block']-1 if pos=='opening' else w['last_block'];i=len(qs)+1;maps[i]=(w['name'],a,pos);qs.append(q(i,'eth_call',[{'to':BUSD,'data':'0x70a08231'+a[2:].zfill(64)},hex(h)]))
 bals={}
 for part in range(0,len(qs),2):bals.update(rpc(pref+'_balances_%03d'%part,qs[part:part+2]))
 bal={maps[k]:int(v,16) for k,v in bals.items()};rows=[];recs=[]
 for l in logs:
  h=int(l['blockNumber'],16);r=rd[l['transactionHash']];head=hd[h];tx=td[l['transactionHash']]
  assert r['status']=='0x1' and r['blockHash']==head['hash']==l['blockHash']==tx['blockHash'] and any(x==l for x in r['logs'])
  f='0x'+l['topics'][1][-40:];t='0x'+l['topics'][2][-40:];v=int(l['data'],16)
  rows.append({'tx_hash':l['transactionHash'],'block_number':h,'block_hash':head['hash'],'utc':utc(int(head['timestamp'],16)),'from':f,'to':t,'amount_raw':str(v),'amount_busd':dec(v),'log_index':int(l['logIndex'],16),'tx_from':tx['from'],'tx_to':tx['to'],'tx_input':tx['input'],'status':1})
 for w in windows:
  for a in w['addresses']:
   applicable=[r for r in rows if w['first_block']<=r['block_number']<=w['last_block']]
   inc=sum(int(r['amount_raw']) for r in applicable if r['to']==a);out=sum(int(r['amount_raw']) for r in applicable if r['from']==a);op=bal[w['name'],a,'opening'];cl=bal[w['name'],a,'closing'];assert op+inc-out==cl,(a,op,inc,out,cl)
   recs.append({'window':w['name'],'address':a,'opening_raw':str(op),'closing_raw':str(cl),'in_raw':str(inc),'out_raw':str(out),'opening_busd':dec(op),'closing_busd':dec(cl),'in_busd':dec(inc),'out_busd':dec(out),'reconciled':True})
  w['first_block_utc']=utc(int(hd[w['first_block']]['timestamp'],16));w['last_block_utc']=utc(int(hd[w['last_block']]['timestamp'],16));w['after_block_utc']=utc(int(hd[w['last_block']+1]['timestamp'],16))
 result={'token':BUSD,'windows':windows,'rows':rows,'window_balances':recs}
 (P/(pref+'_verified.json')).write_text(json.dumps(result,indent=2))
 if rows:
  with (P/(pref+'_verified.csv')).open('w') as f:
   wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
 print(json.dumps(result,indent=2))
 return result

def main():
 end_b,target_b=boundary('branch_boundary','2022-11-17T09:02:17+00:00',22930997)
 end_a,target_a=boundary('retained_boundary','2022-11-19T13:59:08+00:00',22993378)
 windows=[{'name':'retained_next7','first_block':22993379,'last_block':end_a,'addresses':A,'cutoff_utc':utc(target_a)}, {'name':'branch_next7','first_block':22930998,'last_block':end_b,'addresses':B,'cutoff_utc':utc(target_b)}, {'name':'tiny_next14','first_block':22794959,'last_block':end_a,'addresses':T,'cutoff_utc':utc(target_a)}]
 scan_parts=[{'name':'tiny_leadin','first_block':22794959,'last_block':22930997,'addresses':T},{'name':'early_branches','first_block':22930998,'last_block':22993378,'addresses':B+T},{'name':'shared','first_block':22993379,'last_block':end_b,'addresses':A+B+T},{'name':'late_retained','first_block':end_b+1,'last_block':end_a,'addresses':A+T}]
 logs=[]
 for w in scan_parts:logs+=capture_window(w['name'],w['first_block'],w['last_block'],w['addresses'])
 (P/'scan_coverage.json').write_text(json.dumps(scan_parts,indent=2))
 enrich('tail',logs,windows)
if __name__=='__main__':main()
