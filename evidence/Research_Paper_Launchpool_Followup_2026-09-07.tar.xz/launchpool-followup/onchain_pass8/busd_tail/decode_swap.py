import json
from decimal import Decimal,getcontext
from trace_tail import P,rpc,q,BUSD,TRANSFER
getcontext().prec=80
r=json.loads((P/'tail_verified.json').read_text());assert len(r['rows'])==1
row=r['rows'][0];h=row['block_number'];token='0xd983ab71a284d6371908420d8ac6407ca943f810'
qs=[q(i,'eth_call',[{'to':token,'data':selector},hex(h)]) for i,selector in enumerate(['0x313ce567','0x95d89b41','0x06fdde03'])]
values={}
for part in range(0,len(qs),2):values.update(rpc('swap_token_metadata_%03d'%part,qs[part:part+2]))
def abi_string(value):
 b=bytes.fromhex(value[2:]);offset=int.from_bytes(b[:32],'big');n=int.from_bytes(b[offset:offset+32],'big');return b[offset+32:offset+32+n].decode()
decimals=int(values[0],16);symbol=abi_string(values[1]);name=abi_string(values[2])
tx=json.loads((P/'tail_transactions_000.response').read_text())[0]['result'];receipt=json.loads((P/'tail_receipts_000.response').read_text())[0]['result']
data=tx['input'];assert data[:10]=='0x38ed1739';words=[data[i:i+64] for i in range(10,len(data),64)]
amount_in=int(words[0],16);minimum_out=int(words[1],16);recipient='0x'+words[3][-40:];path=['0x'+x[-40:] for x in words[6:]]
assert int(words[2],16)==160 and int(words[5],16)==2 and path==[token,BUSD] and recipient==tx['from']==row['to']
input_logs=[l for l in receipt['logs'] if l['address']==token and l['topics'][0]==TRANSFER]
assert len(input_logs)==1
l=input_logs[0];assert int(l['data'],16)==amount_in and '0x'+l['topics'][1][-40:]==recipient and '0x'+l['topics'][2][-40:]==row['from']
assert int(row['amount_raw'])>=minimum_out
result={'transaction':tx['hash'],'block_number':h,'utc':row['utc'],'initiator':tx['from'],'router':tx['to'],'selector':data[:10],'calldata_layout':'swapExactTokensForTokens(uint256,uint256,address[],address,uint256)','input_token':token,'input_token_historical_name':name,'input_token_historical_symbol':symbol,'input_token_decimals':decimals,'input_amount_raw':str(amount_in),'input_amount':format(Decimal(amount_in)/Decimal(10**decimals),'f'),'minimum_output_raw':str(minimum_out),'output_token':BUSD,'output_amount_raw':row['amount_raw'],'output_amount_busd':row['amount_busd'],'pair':row['from'],'recipient':recipient,'path':path,'receipt_status':1,'qualification':'The token labels are contract-returned metadata at the transaction block. Ultimate origin/acquisition of the input tokens and any relation to the original Mintlayer fundraising are not established by this transaction.'}
(P/'swap_verified.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
