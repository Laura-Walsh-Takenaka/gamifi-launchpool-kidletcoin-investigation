# BUSD tail capture, pass8

This directory is a bounded extension of the original Mintlayer BSC BUSD trace. It does not scan every subsequent year or identify a human controller.

Offline, non-mutating verification:

```bash
python onchain_pass8/busd_tail/verify_tail.py
```

A full deterministic reconstruction is also available. It rewrites the derived JSON/CSV and should therefore be run on a copy of the evidence directory:

```bash
python onchain_pass8/busd_tail/trace_tail.py --offline
python onchain_pass8/busd_tail/pin_common.py --offline
python onchain_pass8/busd_tail/decode_swap.py --offline
```

The first command verifies stored request/response hashes, exact canonical token and event topics, complete contiguous incoming/outgoing coverage for every stated wallet window, successful official BNB transaction receipts, transaction calldata, matching block hashes/timestamps, independent historical balance responses and exact ledger reconciliation. It makes no network requests and writes no files.

`trace_tail.py` defaults to network collection when `--offline` is absent. Live collection uses the public Blockmachine BSC RPC for historical logs/balances, and the official BNB endpoint for block headers, receipts and transaction details. Blockmachine batches contain two requests and are spaced by eight seconds. Existing successful captures are hash-checked and reused.

`common_cut_verified.json` adds a direct same-block historical state snapshot of all six wallets at the earlier branch cutoff. It reuses two existing balance calls and adds four calls for the remaining wallets.

`scan_coverage.json` describes economical query partitions. `tail_verified.json` describes the separate wallet-specific research windows. Both are inclusive; a single incoming/outgoing OR query can cover several wallets. Duplicate matches are counted once by transaction hash plus log index.

The `*.receipt.json` files are HTTP capture metadata, not Ethereum transaction receipts; the successful chain receipts are inside the corresponding `tail_receipts_*.response` files. Amounts use the canonical BSC BUSD contract's 18 decimals. Zero-valued transfer logs, if present, are retained as events but add no cash flow.

See `MEMO.md` for factual findings and the limits of attribution, and `SHA256SUMS.txt` for the frozen distributable file hashes.
