# Bounded original Mintlayer BUSD tail check

Research date: 7 September 2026. Canonical BSC BUSD: `0xe9e7cea3dedca5984780bafc599bd69add087d56`.

This extension captures **1 unique canonical BUSD transfer event(s) (1 positive)** in the wallet-specific windows below. Every stated opening and closing amount comes from a successful historical `balanceOf` RPC response, independently reconciled to both directions of the full bounded event ledger.

| Research window | Inclusive blocks | First / last captured block UTC | Research cutoff UTC |
|---|---|---|---|
| retained_next7 | 22993379–23191705 | 2022-11-12T13:59:10+00:00 / 2022-11-19T13:59:08+00:00 | 2022-11-19T13:59:08+00:00 |
| branch_next7 | 22930998–23129158 | 2022-11-10T09:02:18+00:00 / 2022-11-17T09:02:15+00:00 | 2022-11-17T09:02:17+00:00 |
| tiny_next14 | 22794959–23191705 | 2022-11-05T13:59:10+00:00 / 2022-11-19T13:59:08+00:00 | 2022-11-19T13:59:08+00:00 |

`retained_next7` covers owner 77bf, bf7f and 8724 for the next seven days after 12 November. `branch_next7` covers cedfa and dc127 for the next seven days after 10 November. `tiny_next14` extends the 10-BUSD recipient 2108 continuously from 5 November through 19 November. The different cutoffs are explicit; this is not a same-block snapshot of all six wallets.

| Address | Opening BUSD | Incoming BUSD | Outgoing BUSD | Closing BUSD | Cutoff |
|---|---:|---:|---:|---:|---|
| `0x77bfe8d704b1948374bf8dab8328a810b2836e66` | 7424.678430731639424238 | 0 | 0 | 7424.678430731639424238 | 2022-11-19T13:59:08+00:00 |
| `0xbf7f26976b451cee4d055f43dbdb10c0426ce630` | 150000 | 0 | 0 | 150000 | 2022-11-19T13:59:08+00:00 |
| `0x87245c288fcc858bf7225dc3ab97d0ad94730757` | 25197.437915171993026378 | 3457.600228610921015515 | 0 | 28655.038143782914041893 | 2022-11-19T13:59:08+00:00 |
| `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | 180205.79767608 | 0 | 0 | 180205.79767608 | 2022-11-17T09:02:17+00:00 |
| `0xdc127dd1218e555684d7e5605e80afdc75868d42` | 40663 | 0 | 0 | 40663 | 2022-11-17T09:02:17+00:00 |
| `0x2108dfd8c35d6426c71173bb85ac01cf86adcc6c` | 10 | 0 | 0 | 10 | 2022-11-19T13:59:08+00:00 |

The six historical opening balances total **403500.914021983632450616 BUSD**; the six stated closing balances total **406958.514250594553466131 BUSD**. Because the wallet cutoffs differ, these sums describe this specifically bounded leaf set, not a simultaneous global account balance or an additional amount raised.

## Positive events

| UTC | From | To | BUSD | Transaction |
|---|---|---|---:|---|
| 2022-11-18T17:38:52+00:00 | `0x65f2ee8b6c52a263b39f1ffc8f97d4b38f14e96d` | `0x87245c288fcc858bf7225dc3ab97d0ad94730757` | 3457.600228610921015515 | `0x7d12b0239c1aeb47c98599ba4814975d9714cb1aec20f5a743761292a16d03ce` |

## One-block residual snapshot

All six residual wallets are also directly pinned at **block 23129158**, **2022-11-17T09:02:15+00:00**, hash `0xbcc3ba89ef9ef57290cc12f0739b30246450a8a92344c6475ae50244bb927007`. Six historical BUSD state responses give a joint gross balance of **403500.914021983632450616 BUSD**. The cedfa/dc127 calls are reused from their exact closing boundary; four additional calls pin the remaining wallets at the same block. Each value reconciles from its stated opening through the common block. `common_cut_verified.json` contains the exact address-by-address state.

## Explanation of the November 18 inflow

The lone BUSD inflow is the output of a swap initiated by wallet 8724 itself. Its successful transaction to the PancakeSwap v2 router `0x10ed43c718714eb63d5aa57b78b54704e256024e` sells **57357.66598584903399695 ULX** from token `0xd983ab71a284d6371908420d8ac6407ca943f810` and receives **3457.600228610921015515 BUSD** from pair `0x65f2ee8b6c52a263b39f1ffc8f97d4b38f14e96d`. Calldata encodes selector 0x38ed1739 and the two-token path [ULX, BUSD]; the full successful receipt contains matching input/output Transfer events and the pair Swap event. Historical token metadata at that block return the name `Ultron`, symbol `ULX` and decimals 18.

The original 25,000-BUSD transfer into 8724 did not leave within this scan. Its closing balance rises only by the observed swap output, to 28,655.038143782914041893 BUSD on 19 November. None of the six wallets has an outgoing BUSD event in its stated window. This new inflow is not counted as an additional original Mintlayer withdrawal. The acquisition/source of the ULX is outside this bounded pass. Public router/token naming is separately corroborated in the parent report from official PancakeSwap and UltronSwap documentation; the raw state and transaction proof here are independently portable.

## Attribution and investigator use

These amounts retain the earlier funding qualifications. Wallet 8724 includes 197.437915171993026378 BUSD that predated its 25,000-BUSD owner-chain receipt; dc127 includes 663 BUSD that predated its 40,000-BUSD receipt; cedfa entered the original trace with 215.79767608 BUSD of prior cash; the owner originally held 0.332011149154053912 BUSD before the Mintlayer withdrawals. Prior money must not be counted repeatedly across paths or assumed to have left a particular mixed wallet without an allocation analysis.

These are custody observations at identified blocks. They do not identify beneficial ownership, a legal payment mandate, an exchange customer, the human holding the private key, or Laura’s personal receipt. The inspector-useful next records are the custody/access records and underlying payment instructions for the exact wallets and previously verified recipients. No person or institution was contacted by this research.

## Capture integrity and reproduction

The offline independent verifier passes **1025 checks**. It validates each stored successful response hash and request, contiguous incoming/outgoing coverage per wallet, canonical BUSD topics, exact block cutoffs, successful transaction receipts for any events, decoded fields, historical state and ledger reconciliation. All six new openings exactly match the previously published cutoffs; `prior_baselines.json` records those earlier file paths and hashes.

The public Blockmachine BSC RPC supplied logs and historical balances. Official BNB RPC supplied cutoff and event block headers and, if any events are present, transaction receipts and calldata. Query partitions use two requests per batch, eight-second spacing and inclusive ranges no larger than 10,000 blocks. Stored HTTP metadata distinguish a successfully completed response from a failed or interrupted request. `capture_notes.json` documents the collector restart that added 2108; this did not modify an earlier pass.

Run `python onchain_pass8/busd_tail/verify_tail.py` for offline non-mutating verification. Run `python onchain_pass8/busd_tail/trace_tail.py --offline` on a copied directory to reconstruct derived output from the saved captures. See `README.md` and the frozen `SHA256SUMS.txt` for distribution details.
