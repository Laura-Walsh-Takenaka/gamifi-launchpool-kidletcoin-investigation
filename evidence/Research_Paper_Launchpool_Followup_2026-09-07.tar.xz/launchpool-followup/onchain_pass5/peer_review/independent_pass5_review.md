# Independent pass 5 review

**PASS. No remaining actionable corrections.** This review used preserved files only and made no network requests. No pass 4 file was changed. The checked report module is `onchain_pass5_content.py`, SHA-256 `3032d84d7ad0acbf4796cedef8b36a27257841b2a4d1d1fb806481be368c45a0`.

## Second Base return and payments

The independent checker `verify_final_base_return.py` decoded all five new successful receipts: Base burn, Ethereum mint, Ethereum swap and both subsequent USDT payments. Each receipt was matched to its contemporaneously recorded request; response and POST-body hashes were checked. The independent results are in `base_final_return_review.json`.

The second bridge transfers exactly 59,737.4 USDC from Base to Ethereum for wallet `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4`. Its Circle message has source domain 6, destination domain 0 and nonce 240419. The source event, Circle message and destination input contain identical message bytes. Token, amount, recipient, message sender and messenger fields agree, and the destination receipt contains the exact successful native USDC mint. The submitted attestation bytes match; this review does not separately verify Circle signatures outside the successful execution.

The Ethereum swap receipt records 59,737.4 USDC paid and 59,724.105382 USDT received. The two independently checked payment receipts distribute exactly that USDT output:

| Recipient | USDT |
| --- | ---: |
| `0xf695f1d1688698abc97b2e5937ba24934561aae9` | 1,000 |
| `0x1991e27e2908847c0274a662eb6675002e8386d0` | 58,724.105382 |

The 13.294618 difference compares counts of two distinct tokens. It does not independently establish a fee, a fiat loss or missing funds. The generic explorer address title does not identify the first recipient's human controller or payment purpose.

I independently summed the complete retained July Base native USDC ledger, all 34 rows:

`27,100 − 20,100 + 73,854.395784 − 21,116.99 − 59,737.4 = 0.005784 USDC`.

The new historical Base calls at block 17,475,891 confirm that balance and one raw BAMBOO unit. The relevant token ledger independently agrees with both calls. The 18 July return was therefore a partial return while inventory remained; the later sales and second burn close the July trading route except for dust.

## Ethereum inventory evidence

The exact-token USDT API query requested block 0 through 20,369,851 and returned 699 entries. I independently checked its endpoint filters, token contract, decimals, wallet and returned block range. Raw integer event arithmetic gives zero before the mint and immediately before the swap, 59,724.105382 USDT after the swap, 58,724.105382 after the first payment, and zero after the payment to 1991. The three selected USDT receipt transfers match the ledger exactly.

The earlier exact-token Ethereum USDC ledger separately gives zero before the second mint, 59,737.4 after the mint and zero after the swap. These results support the local payment sequence but do not undo the upstream source-wallet commingling limitation.

Historical Ethereum USDT balanceOf calls failed: the first provider returned timeouts and the alternative returned HTTP 502. No failed response was interpreted as zero. The USDT balances above are indexed event-ledger results, not successful historical state calls. The report now explicitly preserves this distinction. The successful Base historical state reads remain a separate evidence class.

The amounts returned to 1991 remain stated by asset: 21,116.99 USDC and 58,724.105382 USDT. Neither a dollar-parity conversion nor personal profit entitlement is assumed. The prior positive BAMBOO trading cash difference excludes native ETH gas and fiat valuation. The exclusive fundraising source, human trader, authorization and ultimate beneficiary remain unestablished.

## Raise 1 proof-delivery gap

`verify_raise1_gap.py` independently checks the retained app and configuration hashes, array alignment, exact checksummed proof URL construction, repository path listings and archive response. Results are in `raise1_gap_review.json`.

The contract and proof directory share zero-based index 10. The client checksums the account address, appends `.json` to the corresponding proof directory, and reads the returned claim index. This examined flow identifies individual files, not a full allocation ledger URL.

The two returned repository trees are untruncated, with 243 and 51 entries and no Mintlayer-named path. The exact CDX prefix query returned an empty JSON array, whose response hash checks. These are limited absence findings for the examined sources, not proof that no ledger exists elsewhere or in historical revisions.

The one documented individual proof URL correctly follows the recovered loader and names an observed paid beneficiary. Its request returned HTTP 502. No new full allocation file, Merkle root reconstruction or outstanding-entitlement total was obtained. The prior 2,418,075.7303282383408825 ML custody balance must remain distinct from a verified remaining-liability total. The scope of report section 9.15 and reference F45 is supported.

## Final content assessment

The updated section 9.18 and references F44-F45 match the raw-derived amounts, state/event coverage and attribution limits. The review found no unsupported Laura attribution, automatic deadline payment, exclusive IAG source, original Mintlayer BUSD source or withdrawal of the still-held ML reserves. The report module hash above identifies the final reviewed text. All peer artifacts are frozen for packaging.
