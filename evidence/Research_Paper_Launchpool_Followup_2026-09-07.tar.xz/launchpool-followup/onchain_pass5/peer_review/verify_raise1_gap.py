#!/usr/bin/env python3
"""Check preserved evidence for the bounded Raise 1 proof retrieval gap; no network."""
from pathlib import Path
import json,hashlib,sys
P=Path(__file__).resolve().parent;F=P.parent/'raise1_entitlements';ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'claims_peer'))
from verify_claims import keccak256
J=lambda p:json.loads(p.read_text())
d=J(F/'documented_loader.json');bundle=(F/d['source_bundle']).resolve();assert hashlib.sha256(bundle.read_bytes()).hexdigest()==d['source_bundle_sha256']
s=bundle.read_text();part=s[d['source_bundle_offset']-300:d['source_bundle_offset']+1000]
for text in ['l=c.claimContractAddress[i],m=c.claimProofsPath[i]','w=h.ethers.utils.getAddress(f.account)','v.a.get("".concat(m).concat(w,".json"))','x.isClaimed(data.index)']:assert text in part
config=ROOT/'onchain_pass3/archived_bsc_contracts/mintlayer_project_configuration.json';assert hashlib.sha256(config.read_bytes()).hexdigest()==d['source_configuration_sha256']
c=J(config)[0]['fields'];ix=[x.lower() for x in c['claimContractAddress']].index(d['contract'].lower());assert ix==10 and c['claimProofsPath'][ix]==d['configured_proof_directory']
repos=[]
for name,n in [('github_merkle_tree.json',243),('github_new_merkle_tree_refreshed.json',51)]:
 x=J(F/name);assert x['truncated'] is False and len(x['tree'])==n
 assert not any('mintlayer' in r['path'].lower() for r in x['tree']);repos.append({'file':name,'tree_entries':n,'truncated':False,'Mintlayer_named_paths':[],'response_sha256':hashlib.sha256((F/name).read_bytes()).hexdigest()})
a=F/'archive_lookup';raw=(a/'cdx_prefix_response.txt').read_bytes();receipt=J(a/'cdx_prefix_receipt.json');assert receipt['status']==200 and hashlib.sha256(raw).hexdigest()==receipt['sha256'] and json.loads(raw)==[]
assert receipt['query']['url']=='claims.launchpool.xyz/mintlayer1-11/' and receipt['query']['matchType']=='prefix'
leaf=J(F/'single_documented_proof_url.json');addr=leaf['checksum_address'][2:].lower();h=keccak256(addr.encode()).hex();checksum='0x'+''.join(c.upper() if c.isalpha() and int(h[i],16)>=8 else c for i,c in enumerate(addr));assert checksum==leaf['checksum_address']
assert leaf['exact_url']==d['configured_proof_directory']+checksum+'.json'
events=J(ROOT/'onchain_pass4/tranche_census/reserve_ml_events.json');assert any(x['tx_hash']==leaf['public_claim_event'] and x['to']==checksum.lower() and x['from']==d['contract'].lower() for x in events)
leaf_receipt=J(F/'documented_paid_beneficiary_proof.json.receipt.json');assert leaf_receipt['url']==leaf['exact_url'] and leaf_receipt['status']==502
result={'pass':True,'bundle_sha256_verified':True,'configuration_sha256_verified':True,'aligned_zero_based_configuration_index':ix,'loader_uses_checksumming_and_individual_JSON':True,'loader_reads_returned_index':True,'full_ledger_not_identified_by_examined_loader':True,'repository_tree_checks':repos,'CDX_exact_prefix_response':[],'CDX_response_sha256_verified':True,'single_leaf_follows_actual_loader_and_observed_beneficiary':True,'leaf_status':502,'no_full_entitlement_file_or_total_recovered':True,'absence_claim_limited_to_examined_loader_trees_and_archive_query':True}
(P/'raise1_gap_review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
