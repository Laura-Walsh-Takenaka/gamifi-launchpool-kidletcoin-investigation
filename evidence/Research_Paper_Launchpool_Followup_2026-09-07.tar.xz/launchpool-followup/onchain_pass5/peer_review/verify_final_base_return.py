#!/usr/bin/env python3
"""Independent offline review of the second Base return and selected Ethereum legs."""
from pathlib import Path
import json, sys, hashlib, re
from decimal import Decimal as D
P=Path(__file__).resolve().parent
F=P.parent/'base_final_returns'
B=P.parents[1]/'onchain_pass4/shared_counterparty/base_continuation'
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
A='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4'
EU='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';BU='0x833589fcd6edb6e08f4c7c32d4f71b54bda02913';BAM='0x689644b86075ed61c647596862c7403e1c474dbf';UT='0xdac17f958d2ee523a2206206994597c13d831ec7'
Z='0x'+'0'*40;DEST='0x1991e27e2908847c0274a662eb6675002e8386d0';OTHER='0xf695f1d1688698abc97b2e5937ba24934561aae9'
TRANSFER='0x'+keccak256(b'Transfer(address,address,uint256)').hex();MESSAGE='0x'+keccak256(b'MessageSent(bytes)').hex()
J=lambda p:json.loads(p.read_text())
def provenance(name):
 request=J(F/(name+'.request.json'));receipt=J(F/(name+'.receipt.json'));raw=(F/name).read_bytes()
 assert receipt['status']==200 and receipt['sha256']==hashlib.sha256(raw).hexdigest()
 body=request['request_body_utf8']
 if body is not None:
  assert request['request_body_sha256']==hashlib.sha256(body.encode()).hexdigest()
  assert json.loads(body)==request['jsonrpc_body']
 return request
responses={};request_map={}
for name in ['base_second_return_rpc.json','ethereum_second_return_rpc1.json','ethereum_second_return_rpc2.json','base_post_burn_inventory.json']:
 req=provenance(name);requests={x['id']:x for x in req['jsonrpc_body']}
 for r in J(F/name):
  assert 'result' in r
  responses[r['id']]=r['result'];request_map[r['id']]=requests[r['id']]
  method=requests[r['id']]['method'];x=r['result']
  if method=='eth_getTransactionReceipt':assert x['transactionHash']==requests[r['id']]['params'][0] and x['status']=='0x1'
  elif method=='eth_getTransactionByHash':assert x['hash']==requests[r['id']]['params'][0]

def transfers(r):
 return [(l['address'].lower(),'0x'+l['topics'][1][-40:],'0x'+l['topics'][2][-40:],int(l['data'],16)) for l in r['logs'] if l.get('topics',[None])[0]==TRANSFER]

def dynamic(encoded,word=0):
 b=bytes.fromhex(encoded.removeprefix('0x'));offset=int.from_bytes(b[word*32:word*32+32]);n=int.from_bytes(b[offset:offset+32]);assert offset+32+n<=len(b);return b[offset+32:offset+32+n]

burn=responses['burn_receipt'];mint=responses['mint_receipt'];swap=responses['swap_receipt'];third=responses['third_party_receipt'];ret=responses['return_1991_receipt']
for r in [burn,mint,swap,third,ret]:assert r['from'].lower()==A and r['status']=='0x1'
assert (BU,A,'0xe45b133ddc64be80252b0e9c75a8e74ef280eed6',59737400000) in transfers(burn)
assert (BU,'0xe45b133ddc64be80252b0e9c75a8e74ef280eed6',Z,59737400000) in transfers(burn)
assert transfers(mint)==[(EU,Z,A,59737400000)]
provenance('circle_second_return.json');circle=J(F/'circle_second_return.json')['messages'][0];message=bytes.fromhex(circle['message'][2:])
assert len(message)==248 and int.from_bytes(message[4:8])==6 and int.from_bytes(message[8:12])==0
assert int.from_bytes(message[12:20])==int(circle['eventNonce'])==240419
assert '0x'+message[164:184].hex()==A and int.from_bytes(message[184:216])==59737400000
assert '0x'+message[132:152].hex()==BU and '0x'+message[228:248].hex()==A
assert '0x'+message[32:52].hex()=='0x1682ae6375c4e4a97e4b583bc394c861a46d8962' and '0x'+message[64:84].hex()=='0xbd3fa81b58ba92a82136038b25adec7066af3155'
assert burn['to'].lower()=='0x1682ae6375c4e4a97e4b583bc394c861a46d8962' and mint['to'].lower()=='0x0a992d191deec32afe36203ad87d7d289a738f81'
mlogs=[x for x in burn['logs'] if x.get('topics',[None])[0]==MESSAGE];assert len(mlogs)==1 and dynamic(mlogs[0]['data'])==message
mint_input=responses['mint_transaction']['input'];assert mint_input[:10]=='0x57ecfd28'
assert dynamic(mint_input[10:])==message and dynamic(mint_input[10:],1)==bytes.fromhex(circle['attestation'][2:])
assert responses['burn_transaction']['hash']==burn['transactionHash'] and responses['mint_transaction']['hash']==mint['transactionHash']
pool='0x3416cf6c708da44db2624d63ea0aaef7113527c6'
assert sorted(transfers(swap))==sorted([(EU,A,pool,59737400000),(UT,pool,A,59724105382)])
assert transfers(third)==[(UT,A,OTHER,1000000000)]
assert transfers(ret)==[(UT,A,DEST,58724105382)]
assert int(mint['blockNumber'],16)<int(swap['blockNumber'],16)<int(third['blockNumber'],16)<int(ret['blockNumber'],16)
assert 59724105382==1000000000+58724105382
rows=J(B/'all_base_token_events.json');july=sorted([r for r in rows if r['token']==BU and r['utc'].startswith('2024-07')],key=lambda r:r['block']);assert len(july)==34
burnblock=int(burn['blockNumber'],16);assert burnblock==17475891 and max(r['block'] for r in july)==burnblock
net=sum((D(r['amount'])*(int(r['to']==A)-int(r['from']==A)) for r in july),D(0));assert net==D('0.005784')
assert D('27100')-D('20100')+D('73854.395784')-D('21116.99')-D('59737.4')==net
balance_call='0x70a08231'+'0'*24+A[2:]
for id,token,raw in [('USDC_after_burn',BU,5784),('BAMBOO_after_burn',BAM,1)]:
 req=request_map[id];assert req['method']=='eth_call' and req['params']==[{'to':token,'data':balance_call},hex(burnblock)]
 assert int(responses[id],16)==raw
bamboo=sum((D(r['amount'])*(int(r['to']==A)-int(r['from']==A)) for r in rows if r['token']==BAM and r['block']<=burnblock),D(0));assert bamboo==D('0.000000000000000001')
# Historical USDT requests remain separate from successful transfer receipts.
utstate={};errors=[]
for f in sorted(F.glob('ethereum_USDT_inventory*.json')):
 if f.name.endswith(('.request.json','.receipt.json')):continue
 req=provenance(f.name);mapping={r['id']:r for r in req['jsonrpc_body']}
 for r in J(f):
  if 'error'in r:errors.append({'file':f.name,'id':r['id'],'error':r['error']});continue
  q=mapping[r['id']];assert q['method']=='eth_call' and q['params'][0]=={'to':UT,'data':balance_call}
  value={'file':f.name,'block':int(q['params'][1],16),'raw':int(r['result'],16)}
  if r['id'] in utstate:assert utstate[r['id']]['block']==value['block'] and utstate[r['id']]['raw']==value['raw']
  utstate[r['id']]=value
# Independent full returned USDT event-ledger arithmetic; this is not a historical RPC state read.
from urllib.parse import urlparse,parse_qs
ureq=provenance('USDT_wallet_history.json');query=parse_qs(urlparse(ureq['url']).query)
assert query['address']==[A] and query['contractaddress']==[UT] and query['startblock']==['0'] and query['endblock']==[str(int(ret['blockNumber'],16))]
uobj=J(F/'USDT_wallet_history.json');urows=uobj['result'];assert uobj['status']=='1' and len(urows)==699
assert all(r['contractAddress'].lower()==UT and A in [r['from'].lower(),r['to'].lower()] and r['tokenDecimal']=='6' for r in urows)
assert min(int(r['blockNumber']) for r in urows)==14268527 and max(int(r['blockNumber']) for r in urows)==int(ret['blockNumber'],16)
usdt_ledger=[]
for label,block,expected in [('before_mint',int(mint['blockNumber'],16)-1,0),('before_swap',int(swap['blockNumber'],16)-1,0),('after_swap',int(swap['blockNumber'],16),59724105382),('after_1000_payment',int(third['blockNumber'],16),58724105382),('after_1991_payment',int(ret['blockNumber'],16),0)]:
 n=sum(int(r['value'])*(int(r['to'].lower()==A)-int(r['from'].lower()==A)) for r in urows if int(r['blockNumber'])<=block);assert n==expected
 usdt_ledger.append({'point':label,'block':block,'raw':n,'USDT':str(D(n)/10**6)})
for receipt in [swap,third,ret]:
 expected={(receipt['transactionHash'],f,t,n) for token,f,t,n in transfers(receipt) if token==UT}
 got={(r['hash'],r['from'].lower(),r['to'].lower(),int(r['value'])) for r in urows if r['hash']==receipt['transactionHash']}
 assert got==expected
usdc_rows=J(B.parent/'USDC_events.json');usdc_points=[]
for label,block,expected in [('before_mint',int(mint['blockNumber'],16)-1,0),('after_mint',int(mint['blockNumber'],16),59737400000),('after_swap',int(swap['blockNumber'],16),0)]:
 n=sum(int(r['value'])*(int(r['to'].lower()==A)-int(r['from'].lower()==A)) for r in usdc_rows if r['contractAddress'].lower()==EU and int(r['blockNumber'])<=block);assert n==expected
 usdc_points.append({'point':label,'block':block,'raw':n,'USDC':str(D(n)/10**6)})
result={'pass':True,'successful_new_raw_receipts':5,'all_contemporaneous_request_response_hashes_checked':True,'bridge':{'USDC':'59737.4','nonce':240419,'source_domain':6,'destination_domain':0,'recipient':A,'burn_tx':burn['transactionHash'],'mint_tx':mint['transactionHash'],'message_hash':'0x'+keccak256(message).hex(),'source_message_Circle_destination_input_equal':True,'attestation_bytes_match_successfully_executed_input':True},'swap':{'tx':swap['transactionHash'],'USDC_spent':'59737.4','USDT_received':'59724.105382','nominal_token_quantity_difference':'13.294618','difference_not_independently_identified_as_fee_or_fiat_loss':True},'payments':[{'token':'USDT','recipient':OTHER,'amount':'1000','tx':third['transactionHash'],'recipient_identity_unestablished':True},{'token':'USDT','recipient':DEST,'amount':'58724.105382','tx':ret['transactionHash']}],'USDT_output_equals_two_onward_payments':True,'Base_July_USDC_event_count':34,'Base_post_burn_block':burnblock,'Base_post_burn_USDC':'0.005784','Base_post_burn_BAMBOO_raw':1,'Base_post_burn_state_matches_complete_relevant_token_ledger':True,'historical_USDT_successful_reads':utstate,'historical_USDT_read_errors':errors,'historical_USDT_successful_read_count':len(utstate),'USDT_indexed_event_ledger_count':len(urows),'USDT_event_balance_checkpoints':usdt_ledger,'USDT_inventory_is_event_arithmetic_not_historical_RPC_state':True,'Ethereum_USDC_event_balance_checkpoints':usdc_points,'original_Ethereum_source_commingled':True,'no_human_or_investor_entitlement_attribution':True}
(P/'base_final_return_review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
