#!/usr/bin/env python3
"""Reconcile the bounded July 2024 Base second-return loop, offline."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,sys,hashlib,datetime,csv,re,html
P=Path(__file__).resolve().parent;ROOT=P.parents[1];OLD=ROOT/'onchain_pass4/shared_counterparty';BASE=OLD/'base_continuation'
sys.path.insert(0,str(ROOT/'claims_peer'))
from verify_claims import keccak256
getcontext().prec=90
A='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4';R='0x1991e27e2908847c0274a662eb6675002e8386d0';F='0xf695f1d1688698abc97b2e5937ba24934561aae9';U='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';T='0xdac17f958d2ee523a2206206994597c13d831ec7';BU='0x833589fcd6edb6e08f4c7c32d4f71b54bda02913';B='0x689644b86075ed61c647596862c7403e1c474dbf'
TRANSFER='0x'+keccak256(b'Transfer(address,address,uint256)').hex();SENT='0x'+keccak256(b'MessageSent(bytes)').hex();ZERO='0x'+'0'*40
def read(n):return json.load(open(P/n))
def dyn(data,index=0):
 b=bytes.fromhex(data.removeprefix('0x'));offset=int.from_bytes(b[index*32:(index+1)*32]);size=int.from_bytes(b[offset:offset+32]);assert offset+32+size<=len(b);return b[offset+32:offset+32+size]
def amount(n):return str(Decimal(n)/10**6)
def txs(name):return {x['id']:x.get('result') for x in read(name)}
def find_transfer(receipt,token,frm,to,raw):
 matches=[l for l in receipt['logs'] if l['address']==token and l['topics'][0]==TRANSFER and '0x'+l['topics'][1][-40:]==frm and '0x'+l['topics'][2][-40:]==to and int(l['data'],16)==raw];assert len(matches)==1;return matches[0]
def stamp(receipt):
 if receipt.get('blockTimestamp'):return datetime.datetime.fromtimestamp(int(receipt['blockTimestamp'],16),datetime.timezone.utc).isoformat()
 return None
base=txs('base_second_return_rpc.json');eth=txs('ethereum_second_return_rpc1.json')|txs('ethereum_second_return_rpc2.json')
for x in [base['burn_receipt'],eth['mint_receipt'],eth['swap_receipt'],eth['third_party_receipt'],eth['return_1991_receipt']]:assert x['status']=='0x1' and x['from']==A
assert base['burn_receipt']['to']=='0x1682ae6375c4e4a97e4b583bc394c861a46d8962';assert eth['mint_receipt']['to']=='0x0a992d191deec32afe36203ad87d7d289a738f81'
circle=read('circle_second_return.json')['messages'][0];message=bytes.fromhex(circle['message'][2:]);attestation=bytes.fromhex(circle['attestation'][2:]);assert len(message)==248
sl=[l for l in base['burn_receipt']['logs'] if l['topics'][0]==SENT];assert len(sl)==1 and dyn(sl[0]['data'])==message
raw=eth['mint_transaction']['input'];assert raw[:10]=='0x57ecfd28' and dyn(raw[10:])==message and dyn(raw[10:],1)==attestation
nonce=int.from_bytes(message[12:20]);assert nonce==int(circle['eventNonce']);assert int.from_bytes(message[4:8])==6 and int.from_bytes(message[8:12])==0;assert '0x'+message[152:184][-20:].hex()==A;assert int.from_bytes(message[184:216])==59737400000
find_transfer(base['burn_receipt'],BU,A,'0xe45b133ddc64be80252b0e9c75a8e74ef280eed6',59737400000)
find_transfer(eth['mint_receipt'],U,ZERO,A,59737400000)
POOL='0x3416cf6c708da44db2624d63ea0aaef7113527c6';find_transfer(eth['swap_receipt'],U,A,POOL,59737400000);find_transfer(eth['swap_receipt'],T,POOL,A,59724105382)
find_transfer(eth['third_party_receipt'],T,A,F,1000000000);find_transfer(eth['return_1991_receipt'],T,A,R,58724105382);assert 59724105382==1000000000+58724105382
# End-to-end Base USDC accounting reuses frozen, already independently checked rows.
base_rows=json.load(open(BASE/'all_base_token_events.json'));cash=[r for r in base_rows if r['token']==BU and int(r['block'])<=17475891];cash.sort(key=lambda r:r['block']);assert len(cash)==34
running=0;cashledger=[]
for r in cash:
 n=Decimal(r['amount'])*10**6;assert n==n.to_integral_value();raw=int(n);running+=raw*(1 if r['to']==A else -1);cashledger.append({**r,'raw_amount':str(raw),'running_USDC':amount(running)})
assert running==5784
late_sales=[r for r in cash if r['to']==A and r['utc']>='2024-07-22'];assert len(late_sales)==12;late_total=sum(Decimal(r['amount']) for r in late_sales);assert late_total==Decimal('59737.397261')
assert Decimal('27100')-Decimal('20100')+Decimal('73854.395784')-Decimal('21116.99')-Decimal('59737.4')==Decimal('0.005784')
# Prove exactly which block/token/wallet was queried, with contemporaneous request body.
req=read('base_post_burn_inventory.json.request.json');assert hashlib.sha256(req['request_body_utf8'].encode()).hexdigest()==req['request_body_sha256'];calls={x['id']:x for x in req['jsonrpc_body']};snap=txs('base_post_burn_inventory.json')
for label,token in [('USDC_after_burn',BU),('BAMBOO_after_burn',B)]:assert calls[label]['params']==[{'to':token,'data':'0x70a08231'+A[2:].rjust(64,'0')},hex(17475891)]
assert int(snap['USDC_after_burn'],16)==5784 and int(snap['BAMBOO_after_burn'],16)==1
# Recovered USDT event history; this is not a successful historical balanceOf call.
hist=read('USDT_wallet_history.json');assert hist['status']=='1' and hist['message']=='OK';rows=hist['result'];assert len(rows)==699
assert all(r['contractAddress']==T and r['tokenDecimal']=='6' and A in [r['from'],r['to']] for r in rows);assert max(int(r['blockNumber']) for r in rows)==20369851
ordered=sorted(enumerate(rows),key=lambda v:(int(v[1]['blockNumber']),int(v[1]['transactionIndex']),v[0]));balance=0;history=[]
for original_i,r in ordered:
 delta=int(r['value'])*(1 if r['to']==A else -1);balance+=delta;history.append({'api_row':original_i,'block':int(r['blockNumber']),'transaction_index':int(r['transactionIndex']),'tx_hash':r['hash'],'from':r['from'],'to':r['to'],'raw_USDT':r['value'],'USDT':amount(int(r['value'])),'running_USDT':amount(balance),'utc':datetime.datetime.fromtimestamp(int(r['timeStamp']),datetime.timezone.utc).isoformat()})
def event_balance_through(block):return sum(int(r['value'])*(1 if r['to']==A else -1) for r in rows if int(r['blockNumber'])<=block)
checkpoints={str(b):amount(event_balance_through(b)) for b in [20369798,20369809,20369839,20369851]};assert checkpoints=={'20369798':'0','20369809':'59724.105382','20369839':'58724.105382','20369851':'0'}
# Old USDC event ledger also closes before the second mint and after the swap.
eusd=json.load(open(OLD/'USDC_events.json'));usdcbal={str(b):amount(sum(int(r['value'])*(1 if r['to']==A else -1) for r in eusd if int(r['blockNumber'])<=b)) for b in [20369798,20369799,20369809]};assert usdcbal=={'20369798':'0','20369799':'59737.4','20369809':'0'}
first=json.load(open(BASE/'verified_bridges.json'))[2];assert first['onward_to_1991_USDC']=='21116.99' and first['onward_to_1991_status']=='0x1'
bridge={'source_tx':base['burn_receipt']['transactionHash'],'destination_tx':eth['mint_receipt']['transactionHash'],'source_block':int(base['burn_receipt']['blockNumber'],16),'destination_block':int(eth['mint_receipt']['blockNumber'],16),'source_domain':6,'destination_domain':0,'nonce':nonce,'USDC':'59737.4','recipient':A,'message_keccak256':'0x'+keccak256(message).hex(),'source_message_matches_Circle':True,'destination_message_matches_Circle':True,'destination_attestation_matches_Circle':True,'source_status':'0x1','destination_status':'0x1'}
table=[]
for label,chain,rec in [('Base burn','Base',base['burn_receipt']),('Ethereum mint','Ethereum',eth['mint_receipt']),('USDC to USDT swap','Ethereum',eth['swap_receipt']),('USDT payment to f695','Ethereum',eth['third_party_receipt']),('USDT return to 1991','Ethereum',eth['return_1991_receipt'])]:
 h=rec['transactionHash'];matching=[r for r in cashledger if r['tx_hash']==h]+[r for r in history if r['tx_hash']==h]+[r for r in eusd if r['hash']==h];utc=matching[0]['utc'] if matching else stamp(rec);table.append({'stage':label,'chain':chain,'tx_hash':h,'block':int(rec['blockNumber'],16),'utc':utc,'status':rec['status'],'transaction_caller':rec['from'],'transaction_to':rec['to']})
s=Path(P/'f695_address.html').read_text();title=' '.join(html.unescape(re.search(r'<title>(.*?)</title>',s,re.S).group(1)).split());label={'address':F,'url':'https://etherscan.io/address/'+F,'source_file':'f695_address.html','source_sha256':hashlib.sha256((P/'f695_address.html').read_bytes()).hexdigest(),'page_title_excerpt':title,'direct_public_name_tag_observed':None,'limitation':'No direct public name tag observed on this retrieved Ethereum address page; this is not a claim that no attribution exists elsewhere. No onward tracing.'}
summary={'wallet':A,'later_BAMBOO_sale_USDC':'59737.397261','earlier_Base_USDC_residual':'0.008523','second_bridge_USDC':'59737.4','all_Base_bridge_returns_USDC':'80854.39','Base_USDC_after_second_burn':'0.005784','Base_BAMBOO_raw_after_second_burn':'1','second_bridge':bridge,'swap':{'USDC_input':'59737.4','USDT_output':'59724.105382','token_count_difference':'13.294618','difference_description':'Difference between input USDC count and output USDT count, not a missing balance or established fee amount.','pool':POOL},'USDT_payouts':[{ 'recipient':F,'amount':'1000','tx':eth['third_party_receipt']['transactionHash']},{'recipient':R,'amount':'58724.105382','tx':eth['return_1991_receipt']['transactionHash']}],'total_returned_to_1991_by_asset':{'USDC':'21116.99','USDT':'58724.105382'},'USDT_historical_state_calls':'Unavailable: dRPC timeout; alternative RPC502. No zero-state claim based on these failed calls.','USDT_event_history_rows':699,'USDT_event_history_block_range':[min(int(r['blockNumber']) for r in rows),max(int(r['blockNumber']) for r in rows)],'USDT_event_balance_checkpoints':checkpoints,'USDC_prior_event_balance_checkpoints':usdcbal,'successful_new_receipts':5,'Base_July_USDC_event_rows':34,'third_party_label':label,'scope':'Bounded July final return loop. No exclusive original fundraising source, human controller, payment purpose, net-of-gas profit or later exchange-hop attribution.'}
(P/'final_return_summary.json').write_text(json.dumps(summary,indent=2));(P/'verified_stage_table.json').write_text(json.dumps(table,indent=2));(P/'Base_July_USDC_ledger.json').write_text(json.dumps(cashledger,indent=2));(P/'USDT_event_ledger.json').write_text(json.dumps(history,indent=2));(P/'f695_label_record.json').write_text(json.dumps(label,indent=2))
with (P/'verified_stage_table.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
print(json.dumps(summary,indent=2))
