# Final July BAMBOO proceeds: second bridge, conversion and returns

Research date: 7 September 2026. This bounded continuation closes the July 22–23 proceeds route for `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4` (1836). Prior pass 4 files remain unchanged.

**The later BAMBOO proceeds returned from Base to Ethereum, were exchanged for USDT, and were then paid to two addresses.** The full verified amounts returned to 1991 across both July legs are **21,116.99 USDC plus 58,724.105382 USDT**. A separate **1,000 USDT** went to `0xf695f1d1688698abc97b2e5937ba24934561aae9`. These assets are reported separately; no dollar parity or fiat conversion is assumed.

## Verified July 23 sequence

| UTC time | Action | Actual transfer amount |
|---|---|---:|
| 13:23:31 | Final BAMBOO sale on Base | 5,649.477799 USDC received |
| 13:25:29 | Circle source burn on Base | 59,737.4 USDC |
| 14:22:23 | Circle destination mint on Ethereum | 59,737.4 USDC to 1836 |
| 14:24:23 | Ethereum swap | 59,737.4 USDC out; 59,724.105382 USDT in |
| 14:30:23 | Payment to `f695…aae9` | 1,000 USDT |
| 14:32:47 | Return to `1991…386d0` | 58,724.105382 USDT |

The complete recipient for the final return is `0x1991e27e2908847c0274a662eb6675002e8386d0`.

The second bridge is proved through identical message bytes in the successful Base `MessageSent` log, Circle's official API response, and the Ethereum `receiveMessage` input. The submitted attestation also matches Circle's response. Its source/destination domains are **6 → 0**, nonce **240419**, recipient **1836**, and amount **59,737.4 USDC**. Both bridge receipts show success and the real USDC Transfer logs match. This establishes the previously inferred bridge as an actual matched transfer.

The swap receipt independently records the exact output **59,724.105382 USDT**. It is not inferred from subsequent payments. Both transfer receipts independently verify **1,000 + 58,724.105382 = 59,724.105382 USDT**. The **13.294618** difference between the input USDC token count and output USDT token count belongs to this documented conversion; it is not an unexplained balance shortfall or an established fee amount.

## Cash and inventory closure

The twelve July 22–23 BAMBOO sales generated **59,737.397261 USDC**. Added to the earlier **0.008523 USDC** residual, this supported the **59,737.4 USDC** bridge and left **0.005784 USDC** on Base.

Across the whole July Base loop:

`27,100 − 20,100 + 73,854.395784 − 21,116.99 − 59,737.4 = 0.005784 USDC`

These terms are, respectively, incoming bridge funds, BAMBOO purchase payments, all BAMBOO sale receipts, the first bridge return, and the second bridge return. Historical Base calls at block **17,475,891**, immediately after the second burn, independently confirm **0.005784 USDC** and **one raw BAMBOO unit** remained. Both Base-to-Ethereum bridge returns total **80,854.39 USDC**, before the second leg's USDT conversion.

For the Ethereum leg, a bounded query from block 0 through **20,369,851** returned **699 real-USDT transfer entries**. All entries match the USDT contract and the requested end-block limit. Their raw-integer event ledger reconciles as follows:

| Ethereum block | USDT event balance |
|---:|---:|
| 20,369,798, before second mint/swap | 0 |
| 20,369,809, after swap | 59,724.105382 |
| 20,369,839, after 1,000 payment | 58,724.105382 |
| 20,369,851, after return to 1991 | 0 |

This is independently reconciled **event history**, not a successful historical `balanceOf` result. Historical state requests timed out at dRPC; one alternative provider returned HTTP 502. The existing USDC event history separately reconciles to zero before the mint, 59,737.4 after it and zero after conversion. The payment accounting therefore has evidence beyond coincidentally matching amounts.

## Third-party recipient and limits

The captured Ethereum Etherscan page for `0xf695f1d1688698abc97b2e5937ba24934561aae9` has a generic address title and no direct public name tag was observed. It is retained as an **unattributed 1,000-USDT recipient**. Its payment purpose and human controller remain unresolved. No onward transactions were traced in this pass.

The upstream 1991 commingling limitation remains. These findings do not exclusively assign its earlier incoming funds to any particular fundraising withdrawal, identify Laura or another human controller, establish trading/payment authorization, or calculate profit after native gas. The positive BAMBOO trading cash difference from pass 4 is unchanged; no new fee or loss claim is introduced.

## Evidence

Five new successful receipts verify the Base burn, Ethereum mint, swap and two Ethereum payments. `final_return_summary.json` holds exact findings; `verified_stage_table.json` and `.csv` contain transaction hashes, blocks and UTC times. `Base_July_USDC_ledger.json` contains the 34 July Base USDC entries. `USDT_wallet_history.json` preserves the raw 699-entry response and `USDT_event_ledger.json` supplies its reproducible accounting.

`verify_final_returns.py` reruns the bridge/message comparison, exact receipt checks, complete July Base equation, returned amounts, event-history checkpoints and pinned Base inventory checks. Each new request has a contemporaneous `.request.json` containing endpoint, exact JSON-RPC payload/body hash where applicable, and UTC start time; its `.receipt.json` records response status, hash and completion time. An initial dRPC batch exceeded its stated three-call free-plan limit; subsequent batches used the supported size. No paid account, token, signature or access bypass was used. Raw source hashes and frozen dependency hashes are listed in `source_records.json` and `SHA256SUMS`.
