#!/usr/bin/env python3
"""Bounded public reads; contemporaneous request bodies and response receipts."""
from pathlib import Path
import sys,json,hashlib,datetime,urllib.request,urllib.error,concurrent.futures
P=Path(__file__).resolve().parent
jobs=json.load(sys.stdin)
def fetch(job):
 name,url,*payload=job;now=datetime.datetime.now(datetime.timezone.utc).isoformat();body=json.dumps(payload[0]).encode() if payload else None
 request={'response_file':name,'url':url,'method':'POST' if payload else 'GET','started_utc':now,'headers':{'User-Agent':'Public-record-research/1.0',**({'Content-Type':'application/json'} if payload else {})},'request_body_utf8':body.decode() if body else None,'request_body_sha256':hashlib.sha256(body).hexdigest() if body else None}
 if payload: request['jsonrpc_body']=payload[0]
 requestfile=name+'.request.json';(P/requestfile).write_text(json.dumps(request,indent=2));out={'request_file':requestfile,'response_file':name,'started_utc':now}
 try:
  req=urllib.request.Request(url,headers=request['headers'],data=body)
  with urllib.request.urlopen(req,timeout=40) as r:raw=r.read();out.update(status=r.status,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());(P/name).write_bytes(raw)
 except urllib.error.HTTPError as e:
  raw=e.read();out.update(status=e.code,error=str(e),retry_after=e.headers.get('Retry-After'),error_body=raw[:2000].decode(errors='replace'))
 except Exception as e:out['error']=str(e)
 out['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(P/(name+'.receipt.json')).write_text(json.dumps(out,indent=2));return out
out=list(concurrent.futures.ThreadPoolExecutor(max_workers=2).map(fetch,jobs));print(json.dumps(out,indent=2))
