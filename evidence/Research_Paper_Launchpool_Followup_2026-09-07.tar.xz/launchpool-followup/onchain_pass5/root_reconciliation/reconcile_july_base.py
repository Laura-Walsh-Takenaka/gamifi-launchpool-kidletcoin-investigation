"""Offline exact arithmetic over the retained, receipt-crosschecked Base event ledger."""
from pathlib import Path
import hashlib,json,csv
from decimal import Decimal, getcontext
getcontext().prec=80
P=Path(__file__).resolve().parent;R=P.parents[1]
f=R/'onchain_pass4/shared_counterparty/base_continuation/all_base_token_events.json'
a='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4';u='0x833589fcd6edb6e08f4c7c32d4f71b54bda02913'
rows=sorted((x for x in json.loads(f.read_text()) if x['token']==u and x['utc']<'2024-07-24'),key=lambda x:(x['block'],x['tx_hash']))
assert len(rows)==34
mint=spend=sales=bridged=net=Decimal(0);out=[]
for x in rows:
 v=Decimal(x['amount']);incoming=x['to']==a
 assert (x['from']==a)!=incoming
 if incoming:
  category='bridge mint' if x['from']=='0x'+'0'*40 else 'BAMBOO sale receipt'
  if category=='bridge mint':mint+=v
  else:sales+=v
 else:
  category='bridge burn transfer' if x['to']=='0xe45b133ddc64be80252b0e9c75a8e74ef280eed6' else 'BAMBOO purchase payment'
  if category=='bridge burn transfer':bridged+=v
  else:spend+=v
 net+=v if incoming else -v
 assert net>=0
 out.append({**x,'category':category,'signed_USDC':str(v if incoming else -v),'running_USDC':str(net)})
assert mint==27100 and spend==20100 and sales==Decimal('73854.395784') and bridged==Decimal('80854.39')
assert net==Decimal('0.005784')
with (P/'july_base_USDC_ledger.csv').open('w') as g:
 w=csv.DictWriter(g,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
summary={'source':str(f.relative_to(R)),'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'scope':'Base native USDC events through2024-07-23; other token dust excluded. Independent arithmetic on retained parsed ledger, not a new independent RPC collection. Pass4 independently verifies all22BAMBOOtrade receipts. Pass5 separately verifies laterbridge.','row_count':len(rows),'USDC_bridge_mints':str(mint),'USDC_BAMBOO_purchase_payments':str(spend),'USDC_BAMBOO_sale_receipts':str(sales),'USDC_two_bridge_burns':str(bridged),'USDC_post_second_burn':str(net),'final_sale_utc':out[-2]['utc'],'second_burn_utc':out[-1]['utc'],'last_sale_to_bridge_seconds':118,'no_native_ETH_gas_deduction':True,'no_fiat_value_or_human_ownership_inference':True}
(P/'july_base_reconciliation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
