from pathlib import Path
import urllib.request,urllib.error,json,hashlib,datetime,fcntl
P=Path(__file__).resolve().parent

def get(url,filename,source_basis):
 path=P/'requests.json'
 rec={'url':url,'filename':filename,'source_basis':source_basis,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Public-record-research/1.0'})
  with urllib.request.urlopen(req,timeout=40) as r:
   b=r.read();rec.update(status=r.status,headers={k:v for k,v in r.headers.items() if k.lower()!='set-cookie'},sha256=hashlib.sha256(b).hexdigest(),bytes=len(b));(P/filename).write_bytes(b)
 except urllib.error.HTTPError as e:
  rec.update(status=e.code,error=str(e),headers={k:v for k,v in e.headers.items() if k.lower()!='set-cookie'})
 except Exception as e:rec['error']=str(e)
 (P/(filename+'.receipt.json')).write_text(json.dumps(rec,indent=2))
 with (P/'request_log.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);records=json.loads(path.read_text()) if path.exists() else [];records.append(rec);path.write_text(json.dumps(records,indent=2));fcntl.flock(lock,fcntl.LOCK_UN)
 print(json.dumps({k:rec[k] for k in ['url','status','bytes','error'] if k in rec}),flush=True);return rec
if __name__=='__main__':
 import sys
 get(sys.argv[1],sys.argv[2],sys.argv[3])
