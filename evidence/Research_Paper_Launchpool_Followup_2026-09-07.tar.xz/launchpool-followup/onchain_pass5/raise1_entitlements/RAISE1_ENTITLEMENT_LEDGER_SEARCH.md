# Raise 1 tranche 11: exact proof-loading mechanism and unrecovered full ledger

**The full Raise 1 tranche-11 allocation ledger was not recovered.** This bounded continuation established the exact published application's individual proof-file convention and checked the documented archive prefix, two public Launchpool Merkle repository trees and their README links. No candidate full dataset was obtained, so no new full-tree or remaining-entitlement amount was validated.

Target contract: `0x9298136Ec995AEFb1E99FD4087080D3DF328162F`.

Expected deployed root, as previously pinned:

`0x203f224dded0a827c8e18d16a08a9bb5111b55bfc9223a36ad79f3f371ed47ad`

The **2,418,075.7303282383408825 ML** recorded in pass 4 remains a verified token-custody balance at block 25,923,764. Pass 5 made no new balance query and does not convert that balance into a verified outstanding-liability total.

## What the public app actually requests

The recovered public project configuration maps this contract to `claimProofsPath[10]`, `https://claims.launchpool.xyz/mintlayer1-11/`. The preserved Raise 1 application bundle takes the proof directory at the matching contract-array index, converts the user's Ethereum account to its checksum address using `ethers.utils.getAddress`, and appends that address followed by `.json`. It then reads the returned index to query `isClaimed`.

This is a **per-wallet file loader**, not an identified full-ledger download. The exact source-file hash, byte offset and a short code excerpt are preserved in `documented_loader.json`. The recorded source bundle is the already-retrieved public `raise1_last.js`; no previously saved pass was edited.

One exact individual URL was derived from this documented loader and the last publicly observed paid beneficiary in pass 4:

`https://claims.launchpool.xyz/mintlayer1-11/0x424cd658a2EE5679f3e3f315916A9f70c42FEA70.json`

That single request returned **HTTP 502 on 7 September 2026 at 07:20:55 UTC**. The checksummed address, source claim transaction and construction provenance are in `single_documented_proof_url.json`; the full request receipt is `documented_paid_beneficiary_proof.json.receipt.json`. This was a documented individual filename, not a guessed filename or a repeat of the previously failed directory request. No further live proof requests were made.

## Bounded source checks

| Source | Result | Exact limitation |
|---|---|---|
| Internet Archive CDX, exact documented directory prefix | HTTP 200; literal `[]`; no returned captures or resume key | Limited to this public index query and prefix; does not prove the files never existed or no copy survives |
| Archive availability index, exact directory | HTTP 429; stopped | No usable availability result; no immediate retry |
| Exact directory, contract and root searches | No indexed result returned by either search engine | Search outcomes, not proof of universal absence |
| `Launchpool/merkle-distributor`, current master tree | 243 entries; `truncated=false`; no Mintlayer-named path | A complete current path listing, not an exhaustive search of historical branches or every blob's contents |
| `Launchpool/merkle-distributor-new`, current main tree | 51 entries; `truncated=false`; no Mintlayer-named path | Same path-listing limitation; its README describes mock generation inputs but supplies no production Mintlayer ledger link |
| Both repository README files | Successfully retrieved from exact blob URLs returned by the tree API; blob hashes verified | No linked production Mintlayer proof archive or full ledger found |
| One documented per-wallet proof file | HTTP 502 | No individual proof row recovered from this request; no full ledger identified |

The public old repository contains allocation files for other named projects. Those filenames were not relabelled as Mintlayer data. The newer repository's mock files were not treated as production claims. No speculative aggregate filename or alternative storage path was fetched.

Archive raw queries, result bytes, hashes and the subtask's precise search scope are preserved under `archive_lookup/`. Repository tree responses, README blob responses and per-request receipts are preserved here. `search_summary.json` provides the consolidated machine-readable result.

## The remaining record to obtain

The needed artifact is the **complete allocation dataset associated with the exact root above**, including eligible addresses, indices and integer ML amounts, with proofs or sufficient original input to independently rebuild the tree. A full export of the documented per-wallet proof directory could also supply that dataset, subject to completeness checks.

Any recovered dataset must first reproduce the deployed root. Only then can its eligible rows be reconciled against the recorded claims and custody balance to distinguish unpaid entitlements, already satisfied amounts and any surplus. The 1,000 paid-recipient transfers alone do not identify every remaining eligible address or its amount. The app's displayed 6% figure is not a substitute for the original ledger or proof of how carry-forward balances were calculated.

No individual or complete candidate dataset was recovered in this pass. **Candidate full roots tested: zero.** No recipient enumeration, recovery of all 1,000 individual claim proofs, private collection read, wallet connection, signature or state-changing transaction was undertaken. No new Laura attribution or automatic deadline-transfer conclusion follows from these results.

## Retrieval audit notes

One unsupported GitHub blob hash was accidentally supplied during retrieval and returned HTTP 422. It is preserved as `input_error_receipt.json`, explicitly classified as an input error and excluded from completed-source checks and all conclusions. No ledger body was obtained from it.

A concurrent local journal update lost the initial receipt for the newer repository's otherwise successful tree response. The same previously successful linked tree was retrieved again to repair provenance. Both response bodies are byte-identical; the second has its own complete receipt. Subsequent request logging uses a lock and separately persists each receipt. These recording issues do not change the two tree contents or the target-proof outcome.

Earlier-pass files and the master report remain unchanged by this lane. The report's proposed section 9.15 / F45 wording accurately states the per-wallet loader, empty exact-prefix result, absence of a Mintlayer-named path in the two returned trees, and unrecovered full ledger.
