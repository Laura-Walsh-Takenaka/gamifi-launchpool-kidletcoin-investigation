from pathlib import Path
import urllib.request,urllib.parse,datetime,json,hashlib
P=Path(__file__).parent
q={'url':'claims.launchpool.xyz/mintlayer1-11/','matchType':'prefix','output':'json','fl':'timestamp,original,statuscode,mimetype,digest,length','collapse':'urlkey','limit':'100','showResumeKey':'true'}
u='https://web.archive.org/cdx/search/cdx?'+urllib.parse.urlencode(q)
r={'url':u,'query':q,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Public archive index lookup of the exact documented proof-directory prefix; no live proof-host request and no invented filenames.'}
try:
 with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0'}),timeout=35) as z:b=z.read();r.update(status=z.status,final_url=z.url,content_type=z.headers.get('Content-Type'))
 (P/'cdx_prefix_response.txt').write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());print(b.decode()[:16000])
except urllib.error.HTTPError as e:
 b=e.read();(P/'cdx_prefix_error.txt').write_bytes(b);r.update(status=e.code,error=str(e),error_body_sha256=hashlib.sha256(b).hexdigest());print(str(e),b.decode()[:1000])
except Exception as e:r['error']=str(e);print(str(e))
(P/'cdx_prefix_receipt.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
