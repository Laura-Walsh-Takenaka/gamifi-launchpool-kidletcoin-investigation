# Raise 1 tranche 11 proof archive lookup

**No usable capture or published full allocation-file URL was recovered.** This was a bounded public lookup on 7 September 2026 for the exact documented directory `https://claims.launchpool.xyz/mintlayer1-11/`, associated in the preserved app configuration with contract `0x9298136ec995aefb1e99fd4087080d3df328162f` and Merkle root `0x203f224dded0a827c8e18d16a08a9bb5111b55bfc9223a36ad79f3f371ed47ad`.

The Internet Archive CDX prefix query completed successfully with HTTP 200 and returned the literal JSON result `[]`. It requested the documented directory prefix, all status codes, timestamp/original URL/status/MIME/digest/length fields, one record per URL key, and at most 100 results with a resume key if needed. No rows or resume key were returned. The exact query URL, retrieval time, raw three-byte response and SHA-256 are preserved in `cdx_prefix_receipt.json` and `cdx_prefix_response.txt`.

A separate availability-index query for the exact directory returned HTTP 429. It was not retried and supplies no corroborating result. Both search engines returned no indexed result for the documented directory string, exact contract address or exact Merkle root. Exact searches and outcomes are recorded in `web_search_scope.json`.

The known-live 502 proof endpoint was not requested. No recipient filenames, alternate directories or other candidate paths were invented or fetched. No credential, user collection, private data or third-party mutation was used. No earlier pass or master report was edited.

The empty CDX result is limited to this public index query and prefix; it does not prove that the files never existed or that no copy survives elsewhere. No new full tree or entitlement total can be inferred. The parent lane's inspection of the app's exact proof loading convention remains a separate line of evidence.
