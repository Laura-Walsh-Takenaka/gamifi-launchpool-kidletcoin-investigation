"""Sixth integrated pass: original cash receipts, onward routes and bounded funding attribution."""
def add_pass6(B):
    changes=[
      ('Historical Mintlayer withdrawal recipients and onward BUSD transfers remain unrecovered. Section 9.16 now verifies selected withdrawal mechanics from D975 itself. Its full source remains unverified; the different Ethereum contract is not used as proof of its authority. [F32-F33]',
       'Sections 9.19-9.20 now recover all six original Mintlayer withdrawal receipts and their immediate BUSD outflows. Section 9.16 verifies D975 withdrawal mechanics. Its full source remains unverified; the different Ethereum contract is not used as proof of its authority. [F32-F33; F46-F47]'),
      ('All six explorer transaction records show successful matching inputs. Two onward sweeps were transferFrom calls by Etherscan-labeled KuCoin 22. The deposit label and sweeps supply a precise exchange-account mapping lead; customer identity remains unknown. The sender had earlier USDC activity, and its historical starting balance was unavailable. These later payments cannot be assigned exclusively to the July fundraising receipt. [F38]',
       'All six explorer transaction records show successful matching inputs. Two onward sweeps were transferFrom calls by Etherscan-labeled KuCoin 22. The deposit label and sweeps supply a precise exchange-account mapping lead; customer identity remains unknown. Section 9.21 now reconstructs the sender\'s zero starting USDC event balance and narrows the earlier source-attribution gap, accounting separately for the 20-USDC outside contribution. [F38; F48; F50]'),
      ('Each successful call, pool event and actual BUSD Transfer receipt agrees on the pool, amount and recipient. Public project records match both D975 and BSC. These are six other projects; the original Mintlayer pools 19-21 and 125-127 remain outside the recovered withdrawal history. Indexer rounding was replaced with exact RPC event integers. [F41]',
       'Each successful call, pool event and actual BUSD Transfer receipt agrees on the pool, amount and recipient. Public project records match both D975 and BSC. These are six other projects; section 9.19 separately recovers the original Mintlayer pools 19-21 and 125-127. Indexer rounding was replaced with exact RPC event integers. [F41; F46]'),
      ('Verified returns to 1991 are 21,116.99 USDC and 58,724.105382 USDT, with the additional 1,000-USDT recipient identified above. The earlier Ethereum source mixed USDC, so this trading cannot be assigned exclusively to an IAG fundraising receipt. Original Mintlayer BUSD and the still-held ML reserves remain separate. Native ETH gas and fiat valuation are excluded; the human trader, company authorization and allocation of returns remain unresolved. [F39; F41-F44]',
       'Verified returns to 1991 are 21,116.99 USDC and 58,724.105382 USDT. Section 9.21 follows the returned funds and narrows the initial Base funding to a conditional 27,080-27,100 USDC IAG-pool origin interval. Section 9.22 follows the separate 1,000-USDT payment. Original Mintlayer BUSD and ML reserves remain separate. Native gas and fiat valuation are excluded; the human trader, authorization and allocation of returns remain unresolved. [F39; F44; F48-F50]')
    ]
    for old,new in changes:
      found=[b for b in B if b.get('text')==old];assert len(found)==1,old[:60];found[0]['text']=new
    def p(t,k='p'):B.append({'kind':k,'text':t})
    def h(t):p(t,'h')
    def h2(t):p(t,'h2')
    def page():B.append({'kind':'break'})
    def table(rows,widths):B.append({'kind':'table','rows':rows,'widths':widths})

    page();h('9.19 Original Mintlayer BUSD withdrawals recovered')
    p('<b>All six original Mintlayer fundraising withdrawals paid 903,794.346419582485370326 BUSD to 77bf on 3-4 November 2022.</b> Successful official BNB RPC receipts now establish actual payment, recipient and time. This closes the historical receipt gap behind the earlier raised-counter finding. It is the same amount, not additional fundraising or a loss estimate. [F33; F46]')
    p('BSC fundraising contract: <font face="DVM" size="7.2">0xd975b13cdf91de3aa0e0e888fb827fec3650624a</font><br/>Caller and actual recipient: <font face="DVM" size="7.2">0x77bfe8d704b1948374bf8dab8328a810b2836e66</font>','small')
    table([
      ['Pool','UTC payment time','Exact BUSD transferred'],
      ['19','3 Nov 2022 09:02:17','194,775.268548166718546'],
      ['20','3 Nov 2022 09:02:44','195,415.21517867104204'],
      ['21','3 Nov 2022 09:03:14','197,226.626562780028172'],
      ['Raise 1 total','Three calls in 57 seconds','587,417.110289617788758'],
      ['125','4 Nov 2022 13:59:08','101,799.763199702252300446'],
      ['126','4 Nov 2022 13:59:35','103,426.318782728639320062'],
      ['127','4 Nov 2022 14:00:02','111,151.154147533804991818'],
      ['Raise 2 total','Three calls in 54 seconds','316,377.236129964696612326'],
      ['Combined','','903,794.346419582485370326'],
    ],[88,167,244])
    h2('Three matching records for every payment')
    p('Each transaction input selects the configured Mintlayer pool using claimFundRaising(uint256). D975 emits the matching FundRaisingClaimed pool/recipient/amount, and the exact BUSD contract emits the same transfer to 77bf. All receipts are successful. Pool mapping matches the public application\'s BSC deployment and network; similarly numbered pools elsewhere are excluded. [F32-F33; F46]')
    p('BUSD token: <font face="DVM" size="7.2">0xe9e7cea3dedca5984780bafc599bd69add087d56</font><br/>Transition blocks: 22,732,478 / 22,732,487 / 22,732,497 and 22,766,632 / 22,766,641 / 22,766,650.','small')
    h2('How the old access gap was resolved')
    p('A documented keyless archive endpoint returned historical claimed-state reads. A bounded binary search located adjacent false/true blocks for each pool; official BNB RPC then independently supplied the full block bodies and actual transaction receipts. An independent decoder checked all six payments and 151 preserved historical query points. Failed earlier searches remain preserved with their original limits. [F46]')
    h2('What is now established')
    p('77bf received original Mintlayer fundraising cash in November 2022 and later operated ML allocation contracts. The following section records the immediate BUSD outflows. Original purchase obligations, payment purposes, company mandates and human signing-key holders remain separate records questions. Laura\'s public role alone does not identify the person who called these six transactions. [F19; F39; F46-F47]')

    page();h('9.20 Original BUSD outflows connect to wallet 1991')
    p('<b>Eleven payments moved 896,370 BUSD from 77bf to six addresses within the two reviewed 24-hour windows.</b> The only positive BUSD inflows in those windows were the six original Mintlayer withdrawals. Historical opening/closing balance calls and official BNB receipts reconcile the flows exactly. One zero-value incoming row is retained but contributes no cash. [F47]')
    table([
      ['Recipient from 77bf','Payments','Total BUSD'],
      ['0x1991...386d0','4 on 3 November','267,000'],
      ['0xf98f...de420','3 across both dates','424,990'],
      ['0xbf7f...ce630','1 on 4 November','150,000'],
      ['0x14c8...a7b25','1 on 3 November','29,370'],
      ['0x8724...30757','1 on 4 November','25,000'],
      ['0x2108...dcc6c','1 on 3 November','10'],
      ['Total','11','896,370'],
    ],[230,143,126])
    h2('The same address appears in the later cash/trading network')
    p('Recipient <font face="DVM" size="7.1">0x1991e27e2908847c0274a662eb6675002e8386d0</font> received 10, 199,990, 25,000 and 42,000 BUSD on 3 November 2022. Its first payment arrived 2 minutes 15 seconds after the final Raise 1 withdrawal. This exact address later received 150,010 USDC from 77bf in July 2024 and participated in the Base trading/return routes. The link is a repeated address relationship across BSC and Ethereum, not an identified human. [F38; F44; F47-F48]')
    h2('54,370 BUSD reaches Binance 51')
    p('14c840 received 29,370 BUSD directly from 77bf and 25,000 from 1991, then sent both amounts to Binance 51 at 09:38:08 and 10:00:27 UTC on 3 November. The exact endpoint is <font face="DVM" size="7.0">0x8894e0a0c962cb723c1976a4421c95949be2d4e3</font>. Both 1991 and 14c840 opened and closed the window at zero. Raw receipts and historical state calls verify these paths; the Binance customer remains unidentified. This 54,370 is part of the onward total, not additional proceeds. [F47]')
    h2('Historical custody balances')
    table([
      ['24-hour window','Opening BUSD','Incoming BUSD','Outgoing BUSD'],
      ['Raise 1','0.332011149154053912','587,417.110289617788758','521,370'],
      ['Raise 2','66,047.442300766942811912','316,377.236129964696612326','375,000'],
    ],[78,148,175,98])
    p('Raise 1 closes at <b>66,047.442300766942811912 BUSD</b>; the next window opens at that same amount. Raise 2 closes at <b>7,424.678430731639424238 BUSD</b>. The windows run from 3 November 09:02:17 to 4 November 09:02:17, and from 4 November 13:59:08 to 5 November 13:59:08 UTC. Equal balances across the intervening gap do not prove no intervening activity. These are historical balances, not September 2026 reserves. [F47]')
    p('The opening 0.332011149154053912 BUSD predates the Mintlayer receipts and limits exclusive source allocation. Payment purposes, contractual settlement and human control remain unidentified. Full recipient addresses and hashes are in the evidence. [F47]')

    page();h('9.21 Returned funds and a second KuCoin deposit')
    p('<b>1991 deposited 105,907.029506 USDT through a second KuCoin-labeled deposit address on 24 July 2024.</b> The whole amount reached the KuCoin 18-labeled wallet nine minutes later. Both transfers have successful raw RPC receipts. This deposit combines the earlier trading return, an existing balance and new receipts. [F48]')
    table([
      ['USDT event at 1991','Change','Balance afterward'],
      ['Before 23 July return','','8,375.183313'],
      ['Return from 183600','+58,724.105382','67,099.288695'],
      ['Payment to 188b','-21,882.27','45,217.018695'],
      ['Payment to 2c94','-4,000','41,217.018695'],
      ['Receipt from MEXC 1','+14,690.010811','55,907.029506'],
      ['Receipt from 33b2','+50,000','105,907.029506'],
      ['Payment to KuCoin Deposit 327a','-105,907.029506','0'],
    ],[227,133,139])
    p('KuCoin Deposit: <font face="DVM" size="7.1">0x327ae1e62fdea32763d6e5de1b08ebe84edff303</font><br/>KuCoin 18: <font face="DVM" size="7.1">0x83c41363cbee0081dab75cb841fa24f3db46627e</font><br/>24 July: deposit 09:32:23 UTC; onward sweep 09:41:23. This deposit address differs from the earlier 4d0d USDC route. Labels identify services, not customers. [F48]','small')
    h2('The first USDC return also moved onward')
    p('Before the 21,116.99-USDC return on 18 July, 1991 held an event-derived 11,460 USDC. It then sent 32,500 USDC to 2c94, leaving 76.99; 2c94 forwarded 32,500 to unlabeled 47da one minute later. A separate 8,720.1948-USDT payment followed the same route. After additional July 24 funding, a 318,192.184647-USDC payment went through 0008; its later 318,192.18-USDC transfer to d541 involved other balances. Exact receipts and token separation are preserved. [F48]')
    h2('Initial Base funding is now bounded more tightly')
    p('The newly complete USDC history reaches zero at 1991 before its July 2 receipts; its only positive inflows before the first return are the 150,010 USDC from 77bf. Upstream, 77bf\'s event balance was zero before 191,393.685754 USDC of IAG-pool receipts, with only 20 USDC added by the two lookalike-address payments. 183600 also had an event-derived zero USDC balance before receiving and bridging 27,100 USDC. [F38; F48; F50]')
    p('<b>Conservation interval: 27,080-27,100 USDC of the Base funding came through the IAG-pool receipts, conditional on complete captured histories.</b> Even allocating all 20 USDC of outside funding to that branch leaves 27,080 from the pool receipts. This uses neither FIFO nor proportional allocation, and does not assign investor entitlements or trading profits. It narrows the earlier unbounded source gap. [F50]')
    p('370 USDC and 1,577 USDT events each reconcile through the bounded 24 July endpoint. These historical balances are event reconstructions; state calls failed. All 15 selected onward transfers have successful raw receipts, with 14 token-call inputs decoded. Eight misleading other-token/zero rows were excluded. [F48]','small')

    page();h('9.22 The 1,000-USDT branch reaches Revolut')
    p('<b>The separate 1,000-USDT payment reached an Etherscan-labeled Revolut hot wallet on 23 July 2024.</b> 183600 paid f695 at 14:30:23 UTC; f695 forwarded the full amount at 15:57:47, <b>87 minutes 24 seconds later</b>. Both legs have successful raw RPC receipts. The reconstructed USDT cycle is zero before receipt and after the sweep, with no intervening USDT events. [F44; F49]')
    p('Intermediary: <font face="DVM" size="7.1">0xf695f1d1688698abc97b2e5937ba24934561aae9</font><br/>Revolut: Hot Wallet: <font face="DVM" size="7.1">0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921</font>','small')
    table([
      ['183600 payment date','USDT received','Later sweep to Revolut','Other cycle inputs'],
      ['23 Jul 2024','1,000','1,000','0'],
      ['4 Feb 2025','252.3037','745.8037','493.5'],
      ['30 Jun 2025','305','789.581448','484.581448'],
      ['22 Jul 2025','965','965','0'],
      ['4 Aug 2025','283.514525','513.514525','230'],
      ['19 Jan 2026','170','170','0'],
      ['Source total','2,975.818225','',''],
    ],[138,103,145,113])
    p('All six source payments fall within balance cycles ending at the same Revolut-labeled endpoint. Three cycles include other inputs, so the larger sweep amounts cannot be assigned entirely to 183600. The five later payments establish repeated use; their upstream funding was outside this bounded inquiry. [F49]')
    h2('A service-associated pattern, with customers still unidentified')
    p('The complete retrieved USDT history has 65 events: 38 incoming and 27 outgoing, totaling 23,722.265580 USDT each way. Twenty-five payments sent 23,378.068982 USDT to Revolut; two separate September 2024 payments sent 344.196598 USDT to KuCoin Deposit 8e211. These whole-address totals include unrelated funds. [F49]')
    p('Etherscan-labeled Revolut 1, <font face="DVM" size="7.0">0xb23360ccdd9ed1b15d45e5d3824bb409c8d7c460</font>, provided initial and repeated gas funding: 34 ETH payments totaling 0.02092218 ETH. Together with the repeated sweeps, this is consistent with a service deposit/sweep address. That is a behavioral inference; f695 itself has no retrieved public name tag. [F49]')
    p('At Ethereum block 25,925,814, 7 September 2026 13:36:35 UTC, f695 holds zero USDT and 0.034566131300512124 ETH, with empty runtime and nonce 30. All 33 selected USDT edges were checked: 27 successful RPC receipts and six indexed successful-transaction/raw-log confirmations. The latter are not represented as RPC receipts. [F49]','small')
    p('Ancillary indexed activity includes 6.320509399529568055 ETH and 850.921922 USDC sent to the Revolut endpoint; those were not part of the 33-edge USDT receipt audit or assigned to the July trade. The exact incoming and sweep hashes supply account-credit records leads. Explorer labels are not direct confirmation by Revolut, and no customer, human signer, payment purpose or personal receipt by Laura is identified. [F49]','small')

    return [
      ('F46','All six original Mintlayer BUSD withdrawal receipts','https://bscscan.com/tx/0x3d0006d4dc6efd3afa6e0ef00c6fc922e923c9554948b3603cdb68b67693e530','onchain_pass6/original_busd/ and peer_review/: six official BNB receipts/block bodies, exact input/event/Transfer agreement and all counter matches. Archive-state discovery and its bounded incomplete SQD alternative are preserved; independent original-receipt review passed 935 checks.'),
      ('F47','Original BUSD: immediate outflows and historical balances','https://bscscan.com/address/0x77bfe8d704b1948374bf8dab8328a810b2836e66','onchain_pass6/original_busd_onward/: exact 24-hour windows, both-direction logs, official BNB receipts and historical opening/closing state. Eleven owner payments total 896,370 BUSD; 267,000 BUSD reaches the same 1991 address seen in later Ethereum flows. A 54,370-BUSD branch reaches Binance 51 via 14c840. All 14 historical balance equations reconcile; independent onward review passed 1,002 checks. Service label: https://blockscan.com/Address/0x8894e0a0c962cb723c1976a4421c95949be2d4e3 . Pre-existing funds, the window gap and human-attribution limits remain explicit.'),
      ('F48','Returned funds and the second KuCoin deposit route','https://etherscan.io/address/0x327ae1e62fdea32763d6e5de1b08ebe84edff303','onchain_pass6/returned_funds/ and peer_review/: 370 USDC and 1,577 USDT events; 15 selected successful RPC receipts; second KuCoin deposit/sweep and other bounded onward routes. Historical state calls failed; event balances, mixed funding and rejected lookalikes are explicitly documented.'),
      ('F49','Revolut endpoint and recurring f695 payments','https://etherscan.io/address/0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921','onchain_pass6/f695_recipient/ and peer_review/: 65 USDT events, six recurring source cycles, direct Ethereum explorer labels and current state. 33 selected edges use 27 RPC receipts plus six indexed status/raw-log confirmations. Ancillary ETH/USDC activity has separate evidence scope; customer identity remains unknown.'),
      ('F50','Conditional conservation bound for the Base funding','https://eth.blockscout.com/address/0x1991e27e2908847c0274a662eb6675002e8386d0','onchain_pass6/source_bounds/ and peer_review/: exact-token histories, zero starting event balances, 20-USDC outside input and 27,080-27,100 source interval. Independent review proves both endpoints feasible. Event-history completeness is a stated condition; no legal tracing rule, investor entitlement or human identity is inferred.'),
    ]
