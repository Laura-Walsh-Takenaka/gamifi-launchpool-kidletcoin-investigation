from pathlib import Path
import urllib.request,json,datetime,hashlib
P=Path(__file__).resolve().parent
URL='https://ethereum-rpc.publicnode.com';A='0x4d7b84910d042f5431b156397bff0db5ebb4f0a9';ML='0x059956483753947536204e89bfad909e1a434cc6'
def post(name,data):
 rec={'url':URL,'request':data,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(URL,data=json.dumps(data).encode(),headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=40) as r:
   b=r.read();rec.update(status=r.status,headers={k:v for k,v in r.headers.items() if k.lower()!='set-cookie'},sha256=hashlib.sha256(b).hexdigest());(P/(name+'.json')).write_bytes(b);result=json.loads(b)
 except Exception as e:rec['error']=str(e);result=None
 (P/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2));return result
head=post('rpc_head',{'jsonrpc':'2.0','method':'eth_getBlockByNumber','params':['latest',False],'id':1})
if head and head.get('result'):
 block=head['result']['number'];calls=[]
 for id,to,data in [('owner',A,'0x8da5cb5b'),('token',A,'0xfc0c546a'),('merkleRoot',A,'0x2eb4a7ab'),('ml_balance',ML,'0x70a08231'+A[2:].zfill(64))]:calls.append({'jsonrpc':'2.0','method':'eth_call','params':[{'to':to,'data':data},block],'id':id})
 print('block',int(block,16));print(post('rpc_pinned_state',calls))
else:print(head)
