# Independent peer review: older ML distributor

Reviewed 7 September 2026 UTC using preserved evidence only. No network queries, compilation, transactions or report edits. **Result: PASS for the bounded findings in the lane memo and JSON summaries.**

## Independent checks performed

The separate `independent_peer_checks.py` script re-decodes the raw Blockscout transaction inputs rather than trusting `decoded_claims.json`, then recomputes each Merkle proof against the pinned getter root. It uses the retained Keccak implementation after checking standard empty-string and `abc` test vectors. All **237 supplied proofs** validate. There are **236 successful unique-index claims** by 236 unique beneficiaries, and every successful input beneficiary/amount matches exactly one ML transfer. The failed attempt has no transfer and the identical entitlement appears in a later successful claim. The paid sum independently reproduces **135,122.08850450400117 ML**.

The 238 raw ML event tuples independently match the Etherscan-derived tuples. Funding of **706,395.73825655713798756 ML**, successful claims, and the **571,273.64975205313681756 ML** owner return reconcile to zero. The pinned ML balance is zero. The bitmap storage locations were recomputed from mapping slot 5 and word indices 0–7; their set bits equal the 236 successful indices exactly. This validates the observed claim population without inferring the full older entitlement count.

## Withdrawal mechanics

I inspected the actual runtime bytes and checked these branch links:

- Selector `0x2eef326a` dispatches to wrapper `0x201`, which jumps to withdrawal entry `0x83c`.
- The entry obtains CALLER through helper `0xc7d`, masks the stored slot-0 owner and caller to 160 bits, and permits the equality branch. The non-equal path ends in REVERT at `0x893`.
- The subsequent `TIMESTAMP; PUSH1 2; SLOAD; GT; ISZERO` comparison permits execution only when **slot 2 is no greater than block time**. The false branch reverts at `0x8e3`.
- The owner getter reads slot 0. The duration getter reads slot 1, and the timelock and creation getters read slots 2 and 3 respectively. The independently checked getter values and storage words agree: owner 77bf, duration **0**, and both timestamps **1731068423**, or **8 November 2024 12:20:23 UTC**.
- The runtime root getter embeds the same root used in proof verification. The runtime bytes match the previously captured explorer runtime.

Both saved simulations are read-only `eth_call` requests at the same pinned block, with identical destination and withdrawal selector. The owner call completes; the nonowner call reverts with the owner-check error. Because the simulated contract balance is already zero, this simulation alone is not evidence of an actual payout. The separately observed historical ML return supplies the transfer evidence.

The correct conclusion is a **bounded bytecode, storage, getter and simulation result**. The complete source remains unverified; no compile-to-runtime equivalence was established. The candidate public source should not be presented as verified deployed source. The stored withdrawal threshold is the creation timestamp, not November 2026.

## Raise 2 tranche attribution

Independently checked the recovered application configuration document `mintlayer-raise-2`: old contract `0x4d7b84910d042f5431b156397bff0db5ebb4f0a9` occurs once, at zero-based index 12. Corresponding entries specify **tranche 13**, **8 November 2024**, **8.4%**, and proof path `https://claims.launchpool.xyz/mintlayer-2-13/`.

The app's `claimLocked: true` and the pinned on-chain `isClaimingPaused: false` are distinct observations. The document-wide update time does not date the change to that individual flag. The memo correctly avoids inferring a deliberate cutoff date, double payment, duplicated entitlement, or a human controller.

## Output and reproducibility

- Machine-readable result: `independent_peer_checks.json`.
- Standalone offline recheck: `python independent_peer_checks.py` from this directory.
- No corrections to numerical or runtime conclusions required.
