# Older Mintlayer contract: 236 actual claims, complete token reconciliation

**The previously unexplained 135,122.08850450400117 ML difference is now fully reconciled to 236 successful claims by 236 distinct addresses. Every recipient also appears in the current 1,999-address final-allocation file.** The earlier contract is independently identified by the recovered public Launchpool application configuration as Mintlayer Raise 2's thirteenth tranche, dated 8 November 2024 and displayed as 8.4%. This closes a distribution-history gap. It is not a finding of a missing reserve or a second obligation to add to the final ledger.

Scope: Ethereum contract `0x4d7b84910d042f5431b156397bff0db5ebb4f0a9`; exact ML token `0x059956483753947536204e89bfad909e1a434cc6`, 18 decimals. Public read-only collection on 7 September 2026. Source requests, timestamps and hashes are preserved in `requests.json` and individual RPC receipts. No signature, wallet connection or state-changing transaction was used; the two withdrawal calls were `eth_call` simulations only.

## Complete flow reconciliation

| Observed movement | Events | Exact ML |
|---|---:|---:|
| Funding from 77bf on 8 November 2024 | 1 | 706,395.73825655713798756 |
| Successful claims, 8 November 2024–6 February 2025 | 236 | 135,122.08850450400117 |
| Return to 77bf on 29 May 2025 | 1 | 571,273.64975205313681756 |
| Funding minus both outbound categories | — | 0 |

Owner/funder address: `0x77bfe8d704b1948374bf8dab8328a810b2836e66`.

- Funding, 8 November 2024 12:20:47 UTC: https://etherscan.io/tx/0xcf0db84fd2f9d4f680b59ea044decd22a1dd4e0073ad6e04e6505b05dc9fbe1a
- First successful claim, 8 November 2024 16:11:59 UTC, 36.5821934558641 ML: https://etherscan.io/tx/0x3b7d3afb5eb8d8ebd72a2ddc9eaec6813a366ebe228c6a5ab19c955fea83107b
- Last successful claim, 6 February 2025 11:09:47 UTC, 35.9806313889352 ML: https://etherscan.io/tx/0xf4669fa4e8ab0de82d8137376604af14dbb96d9f598044a4afbaed35f43abc93
- Return, 29 May 2025 11:10:47 UTC: https://etherscan.io/tx/0xf86225aedc2adce03c53e006d295c8241623154d664ecd92b45f1c3dec3e8769

Three complete Etherscan token pages contain 238 ML events and no other token events. Three normal-transaction pages contain 239 transactions: creation, 237 claim attempts and the return. Blockscout independently returns the same 238 exact ML event tuples and 239 normal-transaction hashes; sender, block and success status also match. The incoming ERC-20 funding is a call to the ML token and consequently is not an ordinary transaction addressed to the receiving distributor.

All 237 claim inputs decode under the independently computed selector for `claim(uint256,address,uint256,bytes32[])`. Each supplied proof validates against the earlier contract's on-chain root:

`0x976c38db0b559280062fa4ae155dd9d9e310637f147a3dd8198449f131bfee8c`

For all 236 successful calls, sender equals beneficiary, the input amount and beneficiary exactly match the ML transfer, and the claim index is unique. The first eight bitmap words at the pinned block contain exactly those 236 successful indices; their maximum index is 1992. This is not an assertion that the old complete entitlement set contains exactly 1,999 records.

One claim attempt ran out of gas on 16 December 2024, transaction `0xb75d9aa2b9f4bdd85b720abaa8859881e1d7a23bbbd2ed98f833ef78f400799e`, and paid no ML. The same beneficiary successfully claimed the same 40.6677563247315 ML on 11 January 2025, transaction `0x6a377264ba1ee761784da2d59590e0edcebe87dbc80b3905d945a1be0b29401a`. The failed attempt is excluded from paid totals.

## Recipient continuity with the final ledger

All 236 old recipients occur in the retained current final-claim file. Their combined final allocations equal **232,891.189119370945 ML**. The following comparison uses the independently verified final-distributor status census at block 25,923,249; the later pass-2 state refresh reported those final claim flags unchanged.

| Status in the final distributor | Addresses that received this older tranche | Earlier ML received | Final-ledger ML allocation |
|---|---:|---:|---:|
| Claimed in final distributor | 49 | 39,555.9328137275558 | 89,159.1566539235125 |
| Unclaimed in final distributor | 187 | 95,566.15569077644537 | 143,732.0324654474325 |

This proves a common recipient population across the old tranche and the final allocation. It does not establish double payment, duplicate liabilities, or that a current allocation should be reduced by a past tranche. Original purchase terms and all intervening tranche calculations are needed for that conclusion. The recovered app configuration supplies a project/tranche attribution that was missing in the previous pass; its full source provenance is in `../archived_bsc_contracts/`.

## Wallet control and the older withdrawal restriction

At **Ethereum block 25,923,590, 7 September 2026 06:09:11 UTC**, block hash `0x0cd658148b97788ccdb8b5148ee49643e77c20134c1f9860870c0006f87fdd61`:

- ML `balanceOf(4d7b)` returns zero, independently corroborating the complete event arithmetic.
- The owner getter and storage slot 0 both return 77bf.
- The token getter returns the exact ML address above.
- The `timelockDurationDays()` getter returns 0; `timelock()` and `creationTime()` both return timestamp 1731068423, **8 November 2024 12:20:23 UTC**, the creation transaction's timestamp.
- `isClaimingPaused()` returns false.
- A read-only withdrawal simulation from 77bf completes; the otherwise identical simulation from a different address reverts with the owner-check reason.

The 3,739-byte runtime read from RPC matches the retained Etherscan runtime exactly. A bounded disassembly independently identifies the withdrawal selector path, its comparison of caller with the owner in slot 0, and its requirement that the timestamp in slot 2 be no later than the current block time. The stored withdrawal threshold therefore is the creation time, not a 2026 deadline. The selected bytecode path and exact state values are recorded in `runtime_review.json` and `withdrawal_disassembly.json`.

**Source boundary:** Etherscan still identifies the contract source as unverified. A public Launchpool repository contains a candidate contract with matching function names and conceptual layout, but this pass did not independently compile and match the full source. The assertions above are bounded runtime, getter, simulation and event findings, not a verified-source claim. The candidate source is retained only in scratch `retrieval_work/`; omit its full UNLICENSED body from the evidence ZIP while retaining URL/hash metadata.

The recovered application configuration's `claimLocked: true` is separate from the on-chain pause getter. The configuration document was last updated 7 February 2025, the day after the last successful claim, but the document-wide update timestamp does not establish when that particular flag changed. No claim-closing intent or exact cutoff is inferred. The historical proof path `https://claims.launchpool.xyz/mintlayer-2-13/` returned HTTP 502 on this pass, so the full old allocation file was not recovered.

## Reproduction and remaining questions

From this directory, run `python analyze.py`, then `python verify.py`, then `python runtime_review.py`. These commands read preserved evidence and do not query the network. `verify.py` uses the already retained standard-library Keccak implementation in `../../claims_peer/verify_claims.py`. Fresh network scripts are separately named `fetch.py`, `rpc_read.py`, `rpc_mechanics.py` and `read_claim_state.py`.

The June 2025 onward bridge of the returned balance to the current treasury was already reconciled in `../../onchain_pass2/ml_origin/ml_origin_memo.md`. This pass does not equate returned ML with original BUSD proceeds, establish a human signer, or identify Laura as a beneficiary. The original full tranche allocation, all-round purchase-to-payment reconciliation, wallet mandate and exchange/customer identity records remain separate questions.
