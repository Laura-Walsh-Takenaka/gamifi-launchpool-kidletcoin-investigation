from pathlib import Path
import urllib.request,json,datetime,hashlib,sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
URL='https://ethereum-rpc.publicnode.com';A='0x4d7b84910d042f5431b156397bff0db5ebb4f0a9';block=json.loads((P/'rpc_head.json').read_text())['result']['number']
queries=[]
for sig in ['timelockDurationDays()','timelock()','creationTime()','isClaimingPaused()']:
 queries.append({'jsonrpc':'2.0','method':'eth_call','params':[{'to':A,'data':'0x'+keccak256(sig.encode()).hex()[:8]},block],'id':sig})
for word in range(8):
 slot='0x'+keccak256(word.to_bytes(32,'big')+(5).to_bytes(32,'big')).hex()
 queries.append({'jsonrpc':'2.0','method':'eth_getStorageAt','params':[A,slot,block],'id':f'claimed_word_{word}'})
rec={'url':URL,'request':queries,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 req=urllib.request.Request(URL,data=json.dumps(queries).encode(),headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=40) as r:
  b=r.read();rec.update(status=r.status,headers={k:v for k,v in r.headers.items() if k.lower()!='set-cookie'},sha256=hashlib.sha256(b).hexdigest());(P/'rpc_claim_state.json').write_bytes(b);a=json.loads(b);print(a)
except Exception as e:rec['error']=str(e);print(rec['error'])
(P/'rpc_claim_state.receipt.json').write_text(json.dumps(rec,indent=2))
