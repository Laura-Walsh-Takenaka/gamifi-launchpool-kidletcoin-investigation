#!/usr/bin/env python3
"""Read-only offline arithmetic from the complete retained Etherscan tables."""
from pathlib import Path
from decimal import Decimal,getcontext
from collections import Counter,defaultdict
import re,json,csv,html,datetime
getcontext().prec=90
P=Path(__file__).resolve().parent
A='0x4d7b84910d042f5431b156397bff0db5ebb4f0a9';FUNDER='0x77bfe8d704b1948374bf8dab8328a810b2836e66';ML='0x059956483753947536204e89bfad909e1a434cc6'
def txt(s):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>',' ',s))).strip()
def fmt(n):return str(Decimal(n)/10**18)
rows=[];normal=[]
for page in (1,2,3):
 s=(P/f'token_page{page}.html').read_text();assert 'A total of 238 txns found' in s
 for ord,row in enumerate(re.findall(r'<tr\b[^>]*>(.*?)</tr>',s,re.S)):
  tx=re.search(r'/tx/(0x[0-9a-fA-F]{64})',row)
  if not tx:continue
  ad=re.findall(r'data-clipboard-text=[\'\"](0x[0-9a-fA-F]{40})[\'\"]',row);token=re.search(r'/token/(0x[0-9a-fA-F]{40})',row);amount=re.search(r'class="td_showAmount"[^>]*data-bs-title="([^"]+)"',row);stamp=re.search(r'class=[\'\"]showLocalDate[^>]*>(.*?)</td>',row,re.S);block=re.search(r'/block/(\d+)',row);method=re.search(r'data-title="([^"]+)"',row)
  assert len(ad)==2 and token and amount and stamp and block,(page,ord)
  ts=int(txt(stamp.group(1)));dec=amount.group(1).split('|')[0].strip().replace(',','');raw=Decimal(dec)*10**18;assert raw==raw.to_integral_value()
  rows.append({'page':page,'row':ord,'tx_hash':tx.group(1).lower(),'block':int(block.group(1)),'timestamp':ts,'utc':datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat(),'from':ad[0].lower(),'to':ad[1].lower(),'token':token.group(1).lower(),'amount':dec,'raw_amount':str(int(raw)),'method_label':html.unescape(method.group(1)) if method else '', 'source_file':f'token_page{page}.html'})
 s=(P/f'normal_page{page}.html').read_text();assert 'A total of 239 transactions found' in s
 m=re.search(r"const quickExportTransactionListData = '(.*?)';",s,re.S);assert m
 for r in json.loads(m.group(1)):r['source_file']=f'normal_page{page}.html';normal.append(r)
assert len(rows)==238 and len(normal)==239
assert len({r['tx_hash'] for r in rows})==238
assert len({r['Txhash'].lower() for r in normal})==239
ml=[r for r in rows if r['token']==ML];ins=[r for r in ml if r['to']==A];outs=[r for r in ml if r['from']==A];payouts=[r for r in outs if r['to']!=FUNDER];returns=[r for r in outs if r['to']==FUNDER]
normal_by={r['Txhash'].lower():r for r in normal}
for r in payouts:
 n=normal_by[r['tx_hash']];r['normal_status']=n['Status'];r['normal_method_label']=n['Method'];r['normal_sender']=n['Sender'].lower();r['sender_equals_recipient']=r['normal_sender']==r['to']
assert all(r['normal_status']=='Success' for r in payouts)
current=json.loads((P.parents[1]/'claims/claims.json').read_text(encoding='utf-8-sig'))['claims'];current={a.lower():d for a,d in current.items()}
agg={}
for r in payouts:
 d=agg.setdefault(r['to'],{'address':r['to'],'old_payments':0,'old_raw':0,'hashes':[]});d['old_payments']+=1;d['old_raw']+=int(r['raw_amount']);d['hashes'].append(r['tx_hash'])
for a,d in agg.items():
 d['old_ml']=fmt(d['old_raw']);d['old_raw']=str(d['old_raw']);d['in_current_1999']=a in current
 if a in current:d['current_index']=current[a]['index'];d['current_raw']=str(int(current[a]['amount'],16));d['current_ml']=fmt(int(current[a]['amount'],16))
matched=[d for d in agg.values() if d['in_current_1999']];unmatched=[d for d in agg.values() if not d['in_current_1999']]
sumraw=lambda rs:sum(int(r['raw_amount']) for r in rs)
summary={'all_token_events':len(rows),'ML_events':len(ml),'normal_transactions':len(normal),'normal_status_counts':dict(Counter(r['Status'] for r in normal)),'normal_method_counts':dict(Counter(r['Method'] for r in normal)),'incoming_ML_events':len(ins),'incoming_ML':fmt(sumraw(ins)),'outgoing_ML_events':len(outs),'outgoing_ML':fmt(sumraw(outs)),'net_ML':fmt(sumraw(ins)-sumraw(outs)),'return_to_funder_events':len(returns),'returned_ML':fmt(sumraw(returns)),'other_outbound_events':len(payouts),'other_outbound_ML':fmt(sumraw(payouts)),'unique_other_recipients':len(agg),'all_other_outbound_successful_claim_label':all(r['normal_method_label']=='Claim' and r['normal_status']=='Success' for r in payouts),'all_other_outbound_sender_equals_recipient':all(r['sender_equals_recipient'] for r in payouts),'first_other_payment_utc':min(r['utc'] for r in payouts),'last_other_payment_utc':max(r['utc'] for r in payouts),'recipient_overlap_current_1999':len(matched),'nonoverlap_current_1999':len(unmatched),'old_ML_paid_to_overlap':fmt(sum(int(d['old_raw']) for d in matched)),'current_allocation_ML_for_overlap':fmt(sum(int(d['current_raw']) for d in matched)),'old_ML_paid_to_nonoverlap':fmt(sum(int(d['old_raw']) for d in unmatched)),'normal_without_ML_event':[r for r in normal if r['Txhash'].lower() not in {e['tx_hash'] for e in ml}],'unmatched_recipients':unmatched,'note':'Full table arithmetic and successful transaction-label matching; a method label is not verified deployed source. Recipient overlap does not prove duplicate liabilities or double payment.'}
for fn,data in [('token_events.json',rows),('normal_transactions.json',normal),('ml_events.json',ml),('claim_label_payouts.json',payouts),('recipient_overlap.json',list(agg.values())),('summary.json',summary)]:
 (P/fn).write_text(json.dumps(data,indent=2))
for fn,data in [('ml_events.csv',ml),('recipient_overlap.csv',list(agg.values()))]:
 with (P/fn).open('w') as f:
  fields=list(dict.fromkeys(k for r in data for k in r));w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(data)
print(json.dumps(summary,indent=2))
