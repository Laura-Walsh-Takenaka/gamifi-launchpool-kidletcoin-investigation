#!/usr/bin/env python3
"""Bounded disassembly and pinned-storage checks, not a source-verification claim."""
from pathlib import Path
import json,hashlib,datetime,sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
state={r['id']:r for r in json.loads((P/'rpc_mechanics.json').read_text())};runtime=state['runtime']['result'];b=bytes.fromhex(runtime[2:]);old=(P.parents[1]/'onchain_pass2/ml_origin/old4d7_runtime_from_etherscan.txt').read_text().strip();assert runtime==old
(P/'pinned_runtime.txt').write_text(runtime+'\n')
names={0x00:'STOP',0x01:'ADD',0x02:'MUL',0x03:'SUB',0x04:'DIV',0x10:'LT',0x11:'GT',0x14:'EQ',0x15:'ISZERO',0x16:'AND',0x17:'OR',0x19:'NOT',0x1b:'SHL',0x1c:'SHR',0x20:'KECCAK256',0x30:'ADDRESS',0x33:'CALLER',0x35:'CALLDATALOAD',0x39:'CODECOPY',0x3b:'EXTCODESIZE',0x3d:'RETURNDATASIZE',0x3e:'RETURNDATACOPY',0x42:'TIMESTAMP',0x50:'POP',0x51:'MLOAD',0x52:'MSTORE',0x54:'SLOAD',0x55:'SSTORE',0x56:'JUMP',0x57:'JUMPI',0x5a:'GAS',0x5b:'JUMPDEST',0xf1:'CALL',0xf3:'RETURN',0xfa:'STATICCALL',0xfd:'REVERT',0xfe:'INVALID',0xff:'SELFDESTRUCT'}
segments={}
for start,end in [(0x083c,0x0a57),(0x0b02,0x0b11),(0x0b11,0x0b37),(0x0c7d,0x0c81)]:
 out=[];pc=start
 while pc<end:
  oldpc=pc;op=b[pc];pc+=1
  if 0x60<=op<=0x7f:n=op-0x5f;arg=b[pc:pc+n];pc+=n;desc=f'PUSH{n} 0x{arg.hex()}'
  elif 0x80<=op<=0x8f:desc='DUP'+str(op-0x7f)
  elif 0x90<=op<=0x9f:desc='SWAP'+str(op-0x8f)
  else:desc=names.get(op,f'OP{op:02x}')
  out.append({'pc':oldpc,'pc_hex':hex(oldpc),'instruction':desc,'bytes':b[oldpc:pc].hex()})
 segments[hex(start)]=out
assert b[0x895:0x89f].hex()=='4260025411156108e457'
assert b[0xc7d:0xc81].hex()=='5b339056'
assert b[0xb02:0xb11].hex()=='5b6000546001600160a01b03169056'
sel='0x'+keccak256(b'transferRemainingToOwner()').hex()[:8];assert sel=='0x2eef326a'
threshold=int(state['slot2']['result'],16);owner='0x'+state['slot0']['result'][-40:]
summary={'runtime_bytes':len(b),'runtime_sha256_bytes':hashlib.sha256(b).hexdigest(),'rpc_runtime_matches_previously_retrieved_etherscan_runtime':True,'withdrawal_selector':sel,'withdrawal_entry_pc':'0x83c','caller_helper_pc':'0xc7d','owner_check':'At 0x83c caller is obtained, then masked against storage slot 0 and inequality leads to REVERT.','owner_getter_pc':'0xb02','storage_slot0_owner':owner,'timelock_check':'At 0x895 TIMESTAMP; PUSH1 0x02; SLOAD; GT; ISZERO; conditional jump to success. Requires storage slot 2 <= block timestamp.','storage_slot2_threshold':threshold,'storage_slot2_utc':datetime.datetime.fromtimestamp(threshold,datetime.timezone.utc).isoformat(),'storage_slot3_equal_threshold':state['slot3']['result']==state['slot2']['result'],'owner_withdrawal_simulation_result':state['withdraw_owner_simulation'],'nonowner_withdrawal_simulation_result':state['withdraw_nonowner_simulation'],'scope':'Selected bytecode path and state observations; the full contract source has not been independently compiled and matched. Candidate public source is only contextual and not treated as verified deployed source.'}
(P/'withdrawal_disassembly.json').write_text(json.dumps(segments,indent=2));(P/'runtime_review.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
