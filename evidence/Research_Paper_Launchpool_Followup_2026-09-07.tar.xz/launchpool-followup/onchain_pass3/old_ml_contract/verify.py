#!/usr/bin/env python3
"""Cross-provider ledger matching and cryptographic claim-input verification. Offline."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,collections,csv,hashlib,sys,datetime
getcontext().prec=100
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
A='0x4d7b84910d042f5431b156397bff0db5ebb4f0a9';ML='0x059956483753947536204e89bfad909e1a434cc6'
def fmt(n):return str(Decimal(n)/10**18)
a=json.loads((P/'ml_events.json').read_text());api=json.loads((P/'blockscout_ml_events.json').read_text())['result'];normal=json.loads((P/'blockscout_normal.json').read_text())['result'];htmlnormal=json.loads((P/'normal_transactions.json').read_text())
key=lambda r:(r['hash'].lower(),int(r['blockNumber']),int(r['timeStamp']),r['from'].lower(),r['to'].lower(),r['contractAddress'].lower(),int(r['value']))
htmlkey=lambda r:(r['tx_hash'],r['block'],r['timestamp'],r['from'],r['to'],r['token'],int(r['raw_amount']))
assert collections.Counter(map(key,api))==collections.Counter(map(htmlkey,a));assert len(api)==238
assert {r['hash'].lower() for r in normal}=={r['Txhash'].lower() for r in htmlnormal};assert len(normal)==239
normalby={r['hash'].lower():r for r in normal}
for r in htmlnormal:
 b=normalby[r['Txhash'].lower()]
 assert r['Sender'].lower()==b['from'].lower() and int(r['Blockno'])==int(b['blockNumber'])
 assert (r['Status']=='Success')==(b['isError']=='0' and b['txreceipt_status']=='1')
state={r['id']:r['result'] for r in json.loads((P/'rpc_pinned_state.json').read_text())};root=state['merkleRoot'];decoded=[]
for tx in normal:
 if not tx['input'].startswith('0x2e7ba6ef'):continue
 b=bytes.fromhex(tx['input'][10:]);index=int.from_bytes(b[0:32],'big');address='0x'+b[44:64].hex();amount=int.from_bytes(b[64:96],'big');offset=int.from_bytes(b[96:128],'big');assert offset==128
 n=int.from_bytes(b[offset:offset+32],'big');proof=[b[offset+32+i*32:offset+64+i*32] for i in range(n)];assert len(b)==offset+32+n*32
 leaf=keccak256(index.to_bytes(32,'big')+bytes.fromhex(address[2:])+amount.to_bytes(32,'big'));h=leaf
 for sibling in proof:h=keccak256(b''.join(sorted((h,sibling))))
 assert '0x'+h.hex()==root
 transfers=[r for r in api if r['hash']==tx['hash']]
 success=tx['isError']=='0' and tx['txreceipt_status']=='1'
 if success:
  assert len(transfers)==1;r=transfers[0];assert r['from']==A and r['to']==address and int(r['value'])==amount and r['contractAddress']==ML
 else:assert len(transfers)==0
 assert tx['from']==address
 decoded.append({'hash':tx['hash'],'utc':datetime.datetime.fromtimestamp(int(tx['timeStamp']),datetime.timezone.utc).isoformat(),'old_index':index,'address':address,'raw_amount':str(amount),'amount_ml':fmt(amount),'proof':['0x'+x.hex() for x in proof],'proof_valid':True,'success':success,'matching_ML_transfer':success,'sender_matches_beneficiary':True})
claimed=[r for r in decoded if r['success']];assert len(claimed)==236 and len({r['old_index'] for r in claimed})==236
statuses={r['address'].lower():r for r in csv.DictReader((P.parents[1]/'claims/entitlements_status.csv').open())};overlap=json.loads((P/'recipient_overlap.json').read_text());status_summary={}
for status in ['True','False']:
 rows=[r for r in overlap if statuses[r['address']]['claimed_at_block_25923249']==status]
 status_summary['claimed_in_final' if status=='True' else 'unclaimed_in_final']={'records':len(rows),'old_received_ML':fmt(sum(int(r['old_raw']) for r in rows)),'final_allocation_ML':fmt(sum(int(r['current_raw']) for r in rows))}
failed=[r for r in decoded if not r['success']]
for r in failed:r['later_success_same_address']=[x['hash'] for x in claimed if x['address']==r['address'] and x['utc']>r['utc']]
head=json.loads((P/'rpc_head.json').read_text())['result'];summary={'blockscout_ML_events':len(api),'etherscan_ML_events':len(a),'exact_cross_provider_events_match':True,'normal_tx_count_both_providers':len(normal),'normal_tx_hash_sender_block_status_match':True,'claim_selector_independently_computed':'0x'+keccak256(b'claim(uint256,address,uint256,bytes32[])').hex()[:8],'claim_calls':len(decoded),'successful_claims':len(claimed),'failed_claims':failed,'successful_raw_sum':str(sum(int(r['raw_amount']) for r in claimed)),'successful_ML_sum':fmt(sum(int(r['raw_amount']) for r in claimed)),'all_237_proofs_validate_against_getter_root':True,'all_236_successful_input_amounts_addresses_match_ML_transfers':True,'old_merkle_root':root,'old_claimed_min_index':min(r['old_index'] for r in claimed),'old_claimed_max_index':max(r['old_index'] for r in claimed),'old_unique_successful_indices':236,'old_total_entitlement_count_unestablished':True,'pinned_block':int(head['number'],16),'pinned_block_hash':head['hash'],'pinned_block_utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'pinned_owner':'0x'+state['owner'][-40:],'pinned_ML_balance':str(int(state['ml_balance'],16)),'current_ledger_status_overlap_at_block_25923249':status_summary,'source_sha256':{f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in ['blockscout_normal.json','blockscout_ml_events.json','ml_events.json','rpc_head.json','rpc_pinned_state.json']}}
(P/'decoded_claims.json').write_text(json.dumps(decoded,indent=2));(P/'verification.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
