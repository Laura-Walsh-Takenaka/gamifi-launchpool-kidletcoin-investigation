from pathlib import Path
import urllib.request,json,datetime,hashlib
P=Path(__file__).resolve().parent
URL='https://ethereum-rpc.publicnode.com';A='0x4d7b84910d042f5431b156397bff0db5ebb4f0a9';OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
block=json.loads((P/'rpc_head.json').read_text())['result']['number']
requests=[{'jsonrpc':'2.0','method':'eth_getCode','params':[A,block],'id':'runtime'}]
requests +=[{'jsonrpc':'2.0','method':'eth_getStorageAt','params':[A,hex(slot),block],'id':f'slot{slot}'} for slot in range(6)]
requests +=[{'jsonrpc':'2.0','method':'eth_call','params':[{'to':A,'from':sender,'data':'0x2eef326a'},block],'id':name} for name,sender in [('withdraw_owner_simulation',OWNER),('withdraw_nonowner_simulation','0x0000000000000000000000000000000000000001')]]
rec={'url':URL,'request':requests,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'note':'eth_call is a local simulation only. No signed transaction or network state mutation.'}
try:
 req=urllib.request.Request(URL,data=json.dumps(requests).encode(),headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=40) as r:
  b=r.read();rec.update(status=r.status,headers={k:v for k,v in r.headers.items() if k.lower()!='set-cookie'},sha256=hashlib.sha256(b).hexdigest());(P/'rpc_mechanics.json').write_bytes(b);a=json.loads(b);print([{**v,'result':v.get('result','')[:100]} for v in a])
except Exception as e:rec['error']=str(e);print(rec['error'])
(P/'rpc_mechanics.receipt.json').write_text(json.dumps(rec,indent=2))
