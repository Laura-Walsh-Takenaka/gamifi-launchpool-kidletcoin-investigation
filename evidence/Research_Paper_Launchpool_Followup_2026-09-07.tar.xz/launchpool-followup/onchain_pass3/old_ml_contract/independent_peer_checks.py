#!/usr/bin/env python3
"""Offline independent peer checks of preserved old Mintlayer evidence."""
import collections,datetime,hashlib,json,pathlib,sys
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
assert keccak256(b'').hex()=='c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
assert keccak256(b'abc').hex()=='4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45'
A='0x4d7b84910d042f5431b156397bff0db5ebb4f0a9';ML='0x059956483753947536204e89bfad909e1a434cc6';O='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
def J(f):return json.loads((P/f).read_text())
normal=J('blockscout_normal.json')['result'];events=J('blockscout_ml_events.json')['result'];html=J('ml_events.json');state={r['id']:r for r in J('rpc_pinned_state.json')};mechanics={r['id']:r for r in J('rpc_mechanics.json')};claimstate={r['id']:r for r in J('rpc_claim_state.json')}
assert len(normal)==239 and len({r['hash'] for r in normal})==239
assert len(events)==238
assert collections.Counter((r['hash'].lower(),int(r['blockNumber']),int(r['timeStamp']),r['from'].lower(),r['to'].lower(),r['contractAddress'].lower(),int(r['value'])) for r in events)==collections.Counter((r['tx_hash'].lower(),int(r['block']),int(r['timestamp']),r['from'].lower(),r['to'].lower(),r['token'].lower(),int(r['raw_amount'])) for r in html)
root=bytes.fromhex(state['merkleRoot']['result'][2:]);selector='0x'+keccak256(b'claim(uint256,address,uint256,bytes32[])').hex()[:8]
claims=[]
for tx in normal:
 if tx['input'][:10]!=selector:continue
 assert tx['to'].lower()==A
 data=bytes.fromhex(tx['input'][10:]);words=[data[i:i+32] for i in range(0,128,32)];idx=int.from_bytes(words[0]);assert words[1][:12]==b'\0'*12;beneficiary='0x'+words[1][12:].hex();amount=int.from_bytes(words[2]);offset=int.from_bytes(words[3]);assert offset==128
 length=int.from_bytes(data[offset:offset+32]);assert len(data)==offset+32+length*32
 leaf=keccak256(words[0]+words[1][12:]+words[2]);h=leaf
 for i in range(length):
  sibling=data[offset+32*(i+1):offset+32*(i+2)];h=keccak256(min(h,sibling)+max(h,sibling))
 assert h==root
 assert tx['from'].lower()==beneficiary
 outgoing=[e for e in events if e['hash'].lower()==tx['hash'].lower()]
 success=tx['isError']=='0' and tx['txreceipt_status']=='1'
 assert len(outgoing)==int(success)
 if success:
  e=outgoing[0];assert (e['from'].lower(),e['to'].lower(),e['contractAddress'].lower(),int(e['value']))==(A,beneficiary,ML,amount)
 claims.append({'tx':tx['hash'],'success':success,'index':idx,'beneficiary':beneficiary,'amount_raw':amount})
successes=[c for c in claims if c['success']];failures=[c for c in claims if not c['success']]
assert len(claims)==237 and len(successes)==236 and len(failures)==1
assert len({c['index'] for c in successes})==236 and len({c['beneficiary'] for c in successes})==236
assert sum(c['amount_raw'] for c in successes)==135122088504504001170000
assert any(c['index']==failures[0]['index'] and c['amount_raw']==failures[0]['amount_raw'] and c['beneficiary']==failures[0]['beneficiary'] for c in successes)
net=sum((1 if e['to'].lower()==A else -1)*int(e['value']) for e in events);assert net==0
assert sum(int(e['value']) for e in events if e['to'].lower()==O)==571273649752053136817560
assert sum(int(e['value']) for e in events if e['from'].lower()==O)==706395738256557137987560
assert int(state['ml_balance']['result'],16)==0
requests={r['id']:r for r in J('rpc_claim_state.receipt.json')['request']}
bits=set()
for w in range(8):
 key='claimed_word_'+str(w);slot='0x'+keccak256(w.to_bytes(32)+int(5).to_bytes(32)).hex();assert requests[key]['params']==[A,slot,'0x18b9006']
 value=int(claimstate[key]['result'],16)
 bits.update(w*256+i for i in range(256) if value & (1<<i))
assert bits=={c['index'] for c in successes}
runtime=bytes.fromhex(mechanics['runtime']['result'][2:]);assert len(runtime)==3739
assert hashlib.sha256(runtime).hexdigest()=='b946980f6b7aa72b94e09ec2ca1d63060b4e2c154db32e28e4e96378ddc774bd'
assert mechanics['runtime']['result']==(P.parents[1]/'onchain_pass2/ml_origin/old4d7_runtime_from_etherscan.txt').read_text().strip()
withdraw_selector=keccak256(b'transferRemainingToOwner()')[:4]
assert withdraw_selector.hex()=='2eef326a'
# Dispatcher compares requested selector, branches to 0x201; wrapper jumps to 0x83c.
assert bytes.fromhex('632eef326a1461020157') in runtime[:256]
assert runtime[0x201:0x209].hex()=='5b61012a61083c56'
assert runtime[0x83c:0x85a].hex()=='5b610844610c7d565b6000546001600160a01b0390811691161461089457'
assert runtime[0xc7d:0xc81].hex()=='5b339056'
assert runtime[0x893]==0xfd and runtime[0x894]==0x5b
assert runtime[0x895:0x89f].hex()=='4260025411156108e457'
assert runtime[0x8e3]==0xfd and runtime[0x8e4]==0x5b
assert runtime[0x4b5:0x4bb].hex()=='5b6001548156'
assert runtime[0xb37:0xb43].hex()=='5b60025481565b6003548156'
assert runtime[0x818:0x83c].hex()=='5b7f'+root.hex()+'8156'
assert '0x'+mechanics['slot0']['result'][-40:]==O
assert int(mechanics['slot1']['result'],16)==0
assert int(mechanics['slot2']['result'],16)==int(mechanics['slot3']['result'],16)==1731068423
assert int(claimstate['timelockDurationDays()']['result'],16)==0
assert int(claimstate['timelock()']['result'],16)==int(claimstate['creationTime()']['result'],16)==1731068423
assert int(claimstate['isClaimingPaused()']['result'],16)==0
rq={r['id']:r for r in J('rpc_mechanics.receipt.json')['request']}
for k,fromaddr in [('withdraw_owner_simulation',O),('withdraw_nonowner_simulation','0x0000000000000000000000000000000000000001')]:
 assert rq[k]['method']=='eth_call' and rq[k]['params']==[{'to':A,'from':fromaddr,'data':'0x2eef326a'},'0x18b9006']
assert mechanics['withdraw_owner_simulation']['result']=='0x'
assert mechanics['withdraw_nonowner_simulation']['error']['message']=='execution reverted: Ownable: caller is not the owner'
config_path=P.parent/'archived_bsc_contracts/mintlayer_project_configuration.json';conf=json.loads(config_path.read_text());doc=next(d for d in conf if d['name'].endswith('/mintlayer-raise-2'));f=doc['fields'];indices=[i for i,a in enumerate(f['claimContractAddress']) if a.lower()==A];assert indices==[12]
assert f['claimDates'][12]=='8th November 2024' and f['claimPercentage'][12]=='8.4%' and f['claimProofsPath'][12]=='https://claims.launchpool.xyz/mintlayer-2-13/' and f['claimLocked'][12] is True
assert all(r['params'][-1]=='0x18b9006' for r in J('rpc_pinned_state.receipt.json')['request'])
out={'review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pass':True,'raw_data_redecoded':True,'keccak_known_vectors_pass':True,'cross_provider_exact_ml_events':238,'normal_transactions':239,'all_237_proofs_independently_validated':True,'successful_claims_exactly_matched_to_transfers':236,'claim_raw_sum':str(sum(c['amount_raw'] for c in successes)),'failed_attempt_excluded_and_same_entitlement_later_paid':True,'funding_minus_claims_minus_owner_return_raw':'0','all_eight_bitmap_words_recomputed_and_match':True,'runtime_hash_and_dispatcher_owner_timelock_branches_checked':True,'owner_simulation_readonly_and_successful':True,'nonowner_simulation_readonly_and_owner_revert':True,'duration_days_getter':0,'threshold_and_creation_timestamp':1731068423,'source_status':'unverified; bounded bytecode/getter/simulation findings only','tranche_config':{'project':'mintlayer-raise-2','tranche':13,'index':12,'date':f['claimDates'][12],'percentage':f['claimPercentage'][12],'proof_path':f['claimProofsPath'][12],'app_locked':True,'onchain_paused':False,'config_sha256':hashlib.sha256(config_path.read_bytes()).hexdigest(),'document_updateTime':doc['updateTime'],'readTime':doc['readTime']},'limitations':['No verified full-source equivalence','No old complete entitlement count inferred','Current app flag has no independently established change timestamp','Simulation at zero balance does not by itself prove historical transfer economics; actual observed owner return supplies transfer evidence','No human controller attribution']}
(P/'independent_peer_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
