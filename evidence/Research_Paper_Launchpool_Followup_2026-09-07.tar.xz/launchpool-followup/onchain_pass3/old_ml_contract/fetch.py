from pathlib import Path
import urllib.request,urllib.error,json,hashlib,datetime
P=Path(__file__).resolve().parent
REQ=P/'requests.json'
records=json.loads(REQ.read_text()) if REQ.exists() else []
def get(url,filename):
 rec={'url':url,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'filename':filename}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Public-record-research/1.0'})
  with urllib.request.urlopen(req,timeout=45) as r:
   body=r.read();rec.update(status=r.status,headers=dict(r.headers));(P/filename).write_bytes(body);rec['bytes']=len(body);rec['sha256']=hashlib.sha256(body).hexdigest()
 except Exception as e:rec['error']=str(e)
 records.append(rec);REQ.write_text(json.dumps(records,indent=2));print(json.dumps(rec))
if __name__=='__main__':
 import sys
 get(sys.argv[1],sys.argv[2])
