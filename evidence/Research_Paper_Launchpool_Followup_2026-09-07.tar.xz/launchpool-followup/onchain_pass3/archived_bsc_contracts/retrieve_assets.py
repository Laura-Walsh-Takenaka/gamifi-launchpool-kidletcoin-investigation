from pathlib import Path
import urllib.request,json,hashlib,datetime,concurrent.futures,gzip
P=Path(__file__).parent
items=[('raise1_runtime.js','https://web.archive.org/web/20211122150545id_/https://app.launchpool.xyz/_nuxt/c4a25da.js'),('raise1_last.js','https://web.archive.org/web/20211122150545id_/https://app.launchpool.xyz/_nuxt/41d2656.js'),('raise2_runtime.js','https://web.archive.org/web/20220316182610id_/https://app.launchpool.xyz/_nuxt/9dae71e.js'),('raise2_last.js','https://web.archive.org/web/20220316182610id_/https://app.launchpool.xyz/_nuxt/5ef6fbd.js')]
def one(x):
 name,url=x; row={'file':name,'url':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Public-record-research/1.0'}),timeout=35) as r:
   b=r.read();row.update(status=r.status,final_url=r.url,content_type=r.headers.get('content-type'))
  if b.startswith(b'\x1f\x8b'):b=gzip.decompress(b)
  (P/'retrieval_work'/name).write_bytes(b);row.update(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
 except Exception as e:row['error']=str(e)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e: rows=list(e.map(one,items))
(P/'asset_receipts.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
