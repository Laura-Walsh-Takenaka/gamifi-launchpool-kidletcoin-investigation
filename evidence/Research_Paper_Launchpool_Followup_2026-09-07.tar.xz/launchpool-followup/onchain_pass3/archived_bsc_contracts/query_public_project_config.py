from pathlib import Path
import json,urllib.request,datetime,hashlib
P=Path(__file__).parent
url='https://firestore.googleapis.com/v1/projects/lpstakeapp/databases/(default)/documents:runQuery'
q={'structuredQuery':{'from':[{'collectionId':'projects'}],'where':{'fieldFilter':{'field':{'fieldPath':'slug'},'op':'IN','value':{'arrayValue':{'values':[{'stringValue':'mintlayer'},{'stringValue':'mintlayer-raise-2'}]}}}},'limit':2}}
(P/'project_config_read_query.json').write_text(json.dumps(q,indent=2))
rec={'url':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Read-only query of the public project configuration collection used by the archived app; only Mintlayer slugs; no credential or user collection requested.'}
try:
 req=urllib.request.Request(url,data=json.dumps(q).encode(),headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'},method='POST')
 with urllib.request.urlopen(req,timeout=30) as r:b=r.read();rec.update(status=r.status,final_url=r.url)
 (P/'project_config_query_response.json').write_bytes(b);rec.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());print(b.decode()[:2000])
except urllib.error.HTTPError as e:
 b=e.read();(P/'project_config_query_error.json').write_bytes(b);rec.update(status=e.code,error=str(e),error_body=b.decode()[:1000]);print(str(e),b.decode()[:1000])
except Exception as e:rec['error']=str(e);print(str(e))
(P/'project_config_query_receipt.json').write_text(json.dumps(rec,indent=2))
