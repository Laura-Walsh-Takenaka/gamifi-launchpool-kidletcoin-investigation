"""Offline byte-for-byte comparison of archived artifacts and pinned runtime responses."""
from pathlib import Path
import re, ast, json, hashlib
P=Path(__file__).parent

def split(code):
    raw=bytes.fromhex(code.removeprefix('0x'))
    length=int.from_bytes(raw[-2:],'big')
    if length+2>len(raw):raise ValueError('Invalid metadata trailer length')
    meta=raw[-length-2:-2]
    if not meta.startswith(b'\xa2'):raise ValueError('Expected the recovered two-entry CBOR metadata map')
    return raw,raw[:-length-2],meta,length

def describe(code):
    raw,body,meta,length=split(code)
    marker=b'\x64solc\x43'
    solc=list(meta.split(marker,1)[1][:3]) if marker in meta else None
    return {'bytes':len(raw),'sha256_bytes':hashlib.sha256(raw).hexdigest(),'metadata_offset_bytes':len(body),'metadata_length_bytes':length,'length_trailer_bytes':2,'metadata_hex':meta.hex(),'solc_version_from_metadata':solc}

bsc_dir=P.parent/'bsc_cash'
br=json.loads((bsc_dir/'mintlayer_pools.receipt.json').read_text())
bq=next(x for x in br['request'] if x['id']==2)
bsc=next(x['result'] for x in json.loads((bsc_dir/'mintlayer_pools.response').read_text()) if x['id']==2)
eth=json.loads((P/'ethereum689c_code.json').read_text())[0]['result']
er=json.loads((P/'bytecode_metadata_receipts.json').read_text())
eq=next(x for x in er['requests'] if x['name']=='ethereum689c_code')['request'][0]
artifacts=[]
for f in sorted((P/'retrieval_work').glob('*last.js')):
    for m in re.finditer(r"JSON\.parse\('((?:\\.|[^'\\])*)'\)",f.read_text()):
        try:x=json.loads(ast.literal_eval("'"+m[1]+"'"))
        except (ValueError,SyntaxError,json.JSONDecodeError):continue
        if isinstance(x,dict) and x.get('contractName')=='LaunchPoolERC20FundRaisingWithVesting':
            code=x['deployedBytecode']
            (P/(f.stem+'_fundraising_deployed_bytecode.txt')).write_text(code+'\n')
            (P/(f.stem+'_fundraising_creation_bytecode.txt')).write_text(x['bytecode']+'\n')
            artifacts.append((f.name,code))
results=[]
for chain,code,q in [('BSC',bsc,bq),('Ethereum',eth,eq)]:
    (P/(('d975' if chain=='BSC' else 'ethereum689c')+'_deployed_bytecode.txt')).write_text(code+'\n')
    desc=describe(code)
    rec={'chain':chain,'address':q['params'][0],'pinned_block_hex':q['params'][1],'pinned_block_decimal':int(q['params'][1],16),'onchain_runtime':desc,'comparisons':[]}
    for filename,artifact in artifacts:
        rec['comparisons'].append({'asset':filename,'artifact_runtime':describe(artifact),'exact_match':bytes.fromhex(code[2:])==bytes.fromhex(artifact[2:]),'match_after_removing_cbor_metadata_and_two_byte_length':split(code)[1]==split(artifact)[1]})
    results.append(rec)
(P/'runtime_equivalence_results.json').write_text(json.dumps(results,indent=2))
for rec in results:print(rec['chain'],rec['pinned_block_decimal'],[(x['asset'],x['exact_match'],x['match_after_removing_cbor_metadata_and_two_byte_length']) for x in rec['comparisons']])
