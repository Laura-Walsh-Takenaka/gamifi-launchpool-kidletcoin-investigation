# Original Mintlayer sale contracts recovered from Launchpool application configuration

Research date: 7 September 2026. Public, read-only retrieval. Scope: the two Mintlayer project records and the app assets referenced by their archived offer pages. No user records, authentication credentials, signatures or transactions were requested.

## New finding

The original BSC fundraising contract identification gap is now substantially narrowed: Launchpool's still-readable public project configuration names **0xD975B13CDF91de3AA0e0E888fb827Fec3650624A** for both Mintlayer raises. It assigns pools **21, 20, 19** to Raise 1 and **125, 126, 127** to Raise 2. These are configuration mappings, to be corroborated with the contract's pool data and events before assigning any receipt total.

| Configuration record | Contract network | Pool IDs | Published target in current record | Creation / last update |
|---|---|---|---|---|
| `mintlayer` | BSC | 21, 20, 19 | 600k BUSD | 2021-11-09 16:18:59.214700 UTC / 2024-08-27 15:00:11.108606 UTC |
| `mintlayer-raise-2` | BSC | 125, 126, 127 | 400k BUSD | 2022-03-11 14:55:06.091994 UTC / 2025-02-07 12:29:37.004647 UTC |

Both documents were returned at Firestore read time **2026-09-07 06:11:01.558801 UTC**. The first record's deposit, staking-end and payment-end blocks are 12,858,074; 13,041,550; and 13,125,200, matching the previously preserved 2021 offer. The second lists deposit block 16,250,000, allocation start 16,280,000, staking end 16,455,000 and payment end 16,525,000. These identify the intended sale configuration; field labels and date estimates should not substitute for actual block timestamps.

## Why this is platform-attributed evidence

The 22 November 2021 and 16 March 2022 archived offer HTML reference their contemporaneous Nuxt main bundles. Both bundles were retrieved successfully from Internet Archive, with the actual redirect capture timestamps retained in `asset_receipts.json`. Inspection establishes that the app loads its project configuration from the Firestore **projects** collection in Firebase project **lpstakeapp**, maps records by their **slug**, and uses the project fields **contractAddress**, **fundraisingType**, **network** and **pools** to construct the corresponding fundraising contract and query its pool information. Thus the empty server-rendered contract maps were not the end of the available evidence: they awaited client-side configuration loading.

A narrowly filtered, unauthenticated `runQuery` read requested only `slug IN [mintlayer, mintlayer-raise-2]`, limit two. It succeeded. The query, raw response, flattened factual records, URL, retrieval time and SHA-256 are preserved. No `usermeta`, investor subcollection, KYC, wallet-login or other private record was requested.

This is a **live retrieval of configuration last updated in 2024/2025**, connected to the project configuration source demonstrably used by the archived app. It is not an archived 2021/2022 capture of those exact database values. The two project documents' creation timestamps and retained schedules strengthen the mapping but do not prove that every present field was unchanged since creation.

## Separate earlier generic deployment mapping

Both archived main bundles also contain an ABI artifact named **LaunchPoolERC20FundRaisingWithVesting** with an embedded deployment map:

| Chain ID | Address |
|---|---|
| 1 / Ethereum | `0x689cF22e945466340F2e0BFD80Ac8Ee398AB9ECf` |
| 56 / BSC | `0x7134A20B0Ac1FB5dB7791363c3a6a87e48ADd8D9` |
| 97 / BSC testnet | `0x13cfAB00512B917aCaD10e652069de084ed75037` |

This independently connects the Ethereum 689c fundraising contract investigated in another lane to Launchpool's published application. It does **not** make those generic addresses the Mintlayer collector; the explicit Mintlayer project records name D975. The extracted ABI's `poolInfo(uint256)` returns reward token, fundraising token, allocation-start block, staking-end block, pledge-end block, target and staking cap. That ABI is an investigation aid until the D975 deployment's actual bytecode/source or return layout is verified.

## Historical ML claim map recovered

The same project records contain a previously unrecovered sequence of Ethereum distribution contracts, dates and proof-directory paths:

- Raise 1: 11 claim entries, from 21 March 2023 to 16 July 2024.
- Raise 2: 13 claim entries, from 21 March 2023 to 8 November 2024.

The final listed Raise 2 entry is **0x4d7b84910D042F5431B156397BFf0DB5EBb4f0a9**, date label **8 November 2024**, proof directory `https://claims.launchpool.xyz/mintlayer-2-13/`. This gives a primary platform mapping for the older ML contract independently traced in the parallel on-chain lane. Exact arrays, including all 24 addresses, are retained in `mintlayer_project_configuration.json`. The indexed dates are display labels, not independently verified deployment or first-claim dates.

The `claimLocked` field is an app configuration flag; it must not be presented as proof of an on-chain pause, contract restriction or forfeiture. Similarly `claimPercentage` and `claimTotal` are published configuration fields rather than a reconciled payout ledger. The separate 2025 final distributor does not appear in these older database records, whose last update predates it.

## Data quality and limits

The current Raise 2 record still contains reward-token price `0.0952` and total-token field `6302521`, matching the older Raise 1 values while its own target is 400k BUSD. Those apparent stale/copy fields must not override the contemporaneous Raise 2 offer and AMA pricing previously preserved. Retain the discrepancy rather than silently correcting the source.

A target is not the amount paid or withdrawn. These records alone establish neither original BUSD receipts, current ML liabilities, legal entitlement to unclaimed assets nor a human key holder. Laura is not named in either recovered project configuration. Further BSC pool reads and events can now be directed at exact contract/pool identifiers, and the historical ML contract map can be reconciled with actual claims.

## Sources and reproducibility

- Prior offer HTML: `../../laura_thread/raise_chronology/retrieval_work/raise1_20211122150545.html` and `raise2_20220316182610.html`; original URLs/hashes remain in that lane's source records.
- November main bundle: `https://web.archive.org/web/20211122145742id_/https://app.launchpool.xyz/_nuxt/41d2656.js`; SHA-256 `57b821209165538bac405c8ad11f6e01286f6b7af78c591e8c46ef11fd467c5c`.
- March main bundle: `https://web.archive.org/web/20220316182710id_/https://app.launchpool.xyz/_nuxt/5ef6fbd.js`; SHA-256 `a68289be20aec3da2ee3432267fe8942d6c25024add1da6d42cd5a996450f0d0`.
- Public read endpoint: `https://firestore.googleapis.com/v1/projects/lpstakeapp/databases/(default)/documents:runQuery`. Exact bounded query and raw response are preserved; the GET equivalents use `/documents/projects/mintlayer` and `/documents/projects/mintlayer-raise-2`.
- GitHub `https://github.com/Launchpool` and `https://github.com/Launchpool/Smart-Contracts`: the current public repository list and Smart-Contracts tree were recovered. The latter contains six Solidity files and no deployment directory. No Mintlayer configuration was recovered from this repository; the archived application/database supplied the useful mapping.

`retrieve_assets.py`, `query_public_project_config.py` and `extract_bundle_config.py` reproduce the bounded retrieval/extraction. Internet Archive may redirect to the closest asset capture; compare recorded actual URLs/hashes. Live database values may change; the preserved response is the evidence for this retrieval. The web search tool rejected direct Firestore document URLs as unsafe-to-open, but the raw unauthenticated API read succeeded. No browser or login was used.

Raw full JavaScript assets remain in `retrieval_work/` for local inspection; use their hashes and factual configuration/ABI extracts in the distributable evidence package. The broader app bundles include unrelated third-party code and public runtime keys, unnecessary to this finding.

## Follow-up: deployed runtime comparison

The bundle artifact's full `deployedBytecode` was recovered and compared offline with the independently retrieved, pinned Ethereum and BSC runtimes. `compare_runtime.py` reproduces the comparison; `runtime_equivalence_results.json` records byte lengths, SHA-256 of decoded bytes, exact metadata boundaries, metadata bytes and pinned block numbers.

- **Ethereum 689c:** runtime at block 25,923,587 is an exact byte-for-byte match with the generic fundraising artifact in both archived app bundles: **12,387 bytes**, including CBOR metadata. SHA-256 of the decoded runtime bytes: `53dba378be8db97787ec7eff51320869a5521f6eb4617b6a2c71a14dba2ba6c9`. Metadata encodes Solidity 0.6.12. This materially strengthens the archived application's attribution of that Ethereum contract.
- **BSC D975:** runtime at the block recorded in the BSC lane's `mintlayer_pools.receipt.json` is **12,612 bytes**, with Solidity 0.8.0 encoded in its metadata. It differs from both archived artifacts even after removing the 51-byte CBOR metadata and final two-byte metadata-length trailer. SHA-256 of its decoded runtime bytes: `34aaf9e747ed09ee4655869f287158525de2a1f3f50961e477fcd12171a4ef0d`. Therefore the Ethereum source/authority semantics must **not** be silently carried over to D975 merely because the interface matches.

D975's on-chain metadata contains IPFS multihash `QmSuyu2YBwsqzocJi7i3GQ638TVAnu5JAnx7G4gs24tNmM`. A bounded request for this exact metadata asset through ipfs.io and dweb.link returned HTTP 403 in both cases. No metadata/source content was recovered, and no further retrieval was attempted. This leaves source equivalence unresolved; it does not invalidate the independent live project-to-contract/pool mapping or the BSC lane's state reads and confirmed transaction sample.
