from pathlib import Path
import json,urllib.request,datetime,hashlib,concurrent.futures
P=Path(__file__).parent
alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
def b58(b):
 n=int.from_bytes(b,'big');s=''
 while n:n,r=divmod(n,58);s=alphabet[r]+s
 return '1'*(len(b)-len(b.lstrip(b'\0')))+s
h='122043f89c54ef454baa77041f1da9c7e5b06412aebf427a9524934fed392268cbc8'
cid=b58(bytes.fromhex(h));print(cid,flush=True)
block=json.loads(Path('launchpool_followup/onchain_pass3/fundraising_control/rpc_block.json').read_text())['result']
items=[('d975_ipfs_metadata','https://ipfs.io/ipfs/'+cid,None),('d975_dweb_metadata','https://dweb.link/ipfs/'+cid,None),('ethereum689c_code','https://ethereum-rpc.publicnode.com',[{'jsonrpc':'2.0','id':1,'method':'eth_getCode','params':['0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf',block]}])]
def f(item):
 n,u,q=item;r={'name':n,'url':u,'request':q,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(q).encode() if q else None,headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'}),timeout=25) as a:b=a.read();r.update(status=a.status,final_url=a.url)
  (P/(n+'.json')).write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r['error']=str(e)
 print(json.dumps(r),flush=True);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:rs=list(e.map(f,items))
(P/'bytecode_metadata_receipts.json').write_text(json.dumps({'d975_metadata_ipfs_cid':cid,'requests':rs},indent=2))
