from pathlib import Path
import re,json,ast,hashlib
P=Path(__file__).parent
out=[]
for f in sorted((P/'retrieval_work').glob('*last.js')):
 s=f.read_text(); arts=[]
 for m in re.finditer(r"JSON\.parse\('((?:\\.|[^'\\])*)'\)",s):
  try:x=json.loads(ast.literal_eval("'"+m[1]+"'"))
  except:continue
  if isinstance(x,dict) and x.get('contractName')=='LaunchPoolERC20FundRaisingWithVesting':
   a={'contractName':x['contractName'],'sourceName':x.get('sourceName'),'abi':x['abi'],'networks':x.get('networks'),'bundled_creation_bytecode_sha256':hashlib.sha256(x.get('bytecode','').encode()).hexdigest(),'bundled_deployed_bytecode_sha256':hashlib.sha256(x.get('deployedBytecode','').encode()).hexdigest()}
   arts.append(a)
   (P/(f.stem+'_fundraising_abi.json')).write_text(json.dumps(a,indent=2))
 rec={'asset':f.name,'asset_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'fundraising_artifacts':arts,'project_configuration_source':{'firebase_project_id':'lpstakeapp','firestore_collection':'projects','lookup_field':'slug','app_uses_fields':['contractAddress','fundraisingType','network','pools']},'archived_bundle_contains_mintlayer_literal':bool(re.search('mintlayer',s,re.I))}
 out.append(rec)
 print(f.name,[(a['contractName'],a['networks']) for a in arts])
(P/'bundle_configuration_extract.json').write_text(json.dumps(out,indent=2))
