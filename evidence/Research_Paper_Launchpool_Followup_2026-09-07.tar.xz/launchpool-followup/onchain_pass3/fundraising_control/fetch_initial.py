import json,urllib.request,urllib.error,hashlib,datetime,concurrent.futures,pathlib
P=pathlib.Path(__file__).parent
A='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf'
items=[('address','https://eth.blockscout.com/api/v2/addresses/'+A,None),('ownership_logs','https://eth.blockscout.com/api?module=logs&action=getLogs&fromBlock=0&toBlock=latest&address='+A+'&topic0=0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0',None),('github_repo','https://api.github.com/repos/Launchpool/Smart-Contracts',None)]
def fetch(t):
 n,u,p=t;r={'name':n,'url':u,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  q=urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0'})
  with urllib.request.urlopen(q,timeout=40) as x:b=x.read();r.update(status=x.status,headers=dict(x.headers))
  (P/(n+'.json')).write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:r=list(e.map(fetch,items))
(P/'initial_receipts.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
