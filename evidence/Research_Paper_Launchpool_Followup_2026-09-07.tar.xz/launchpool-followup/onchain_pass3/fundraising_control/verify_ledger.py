import json,urllib.request,hashlib,datetime,pathlib,concurrent.futures,sys
P=pathlib.Path(__file__).parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
A='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf';USDC='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
block=json.load(open(P/'rpc_block.json'))['result']
def sig(s,n=8):return '0x'+keccak256(s.encode()).hex()[:n]
def fetch(t):
 n,u,p=t;r={'name':n,'url':u,'request':p,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  q=urllib.request.Request(u,data=json.dumps(p).encode() if p is not None else None,headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'})
  with urllib.request.urlopen(q,timeout=45) as x:b=x.read();r.update(status=x.status)
  (P/(n+'.json')).write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r['error']=str(e)
 return r
batch=[]
for i in range(21):
 for k,s in enumerate(['poolIdToTotalRaised(uint256)','poolIdToFundsClaimed(uint256)']):
  batch.append({'jsonrpc':'2.0','id':i*2+k+1,'method':'eth_call','params':[{'to':A,'data':sig(s)+format(i,'064x')},block]})
batch.append({'jsonrpc':'2.0','id':43,'method':'eth_call','params':[{'to':USDC,'data':sig('balanceOf(address)')+'0'*24+A[2:]},block]})
items=[('pool_fund_state','https://ethereum-rpc.publicnode.com',batch),('usdc_out_logs','https://eth.blockscout.com/api?module=logs&action=getLogs&fromBlock=0&toBlock='+str(int(block,16))+'&address='+USDC+'&topic0='+sig('Transfer(address,address,uint256)',64)+'&topic1=0x'+'0'*24+A[2:]+'&topic0_1_opr=and',None)]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:r=list(e.map(fetch,items))
(P/'verification_receipts.json').write_text(json.dumps(r,indent=2));print([{k:v for k,v in z.items() if k!='request'} for z in r])
