import json,urllib.request,hashlib,datetime,pathlib,concurrent.futures,sys
P=pathlib.Path(__file__).parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
A='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf'
block=json.load(open(P/'rpc_block.json'))['result']
def fetch(t):
 n,u,p=t;r={'name':n,'url':u,'request':p,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  q=urllib.request.Request(u,data=json.dumps(p).encode() if p is not None else None,headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'})
  with urllib.request.urlopen(q,timeout=40) as x:b=x.read();r.update(status=x.status)
  (P/(n+'.json')).write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r['error']=str(e)
 return r
batch=[{'jsonrpc':'2.0','id':i+1,'method':'eth_call','params':[{'to':A,'data':'0x1526fe27'+format(i,'064x')},block]} for i in range(21)]
def topic(s):return '0x'+keccak256(s.encode()).hex()
items=[('pools_rpc','https://ethereum-rpc.publicnode.com',batch),('fundsclaimed_logs','https://eth.blockscout.com/api?module=logs&action=getLogs&fromBlock=0&toBlock='+str(int(block,16))+'&address='+A+'&topic0='+topic('FundRaisingClaimed(uint256,address,uint256)'),None),('pooladded_logs','https://eth.blockscout.com/api?module=logs&action=getLogs&fromBlock=0&toBlock='+str(int(block,16))+'&address='+A+'&topic0='+topic('PoolAdded(uint256)'),None),('pinned_block','https://ethereum-rpc.publicnode.com',{'jsonrpc':'2.0','id':1,'method':'eth_getBlockByNumber','params':[block,False]}),('github_readme','https://raw.githubusercontent.com/Launchpool/Smart-Contracts/eed17d7ea2fe2c3c08e73df6a7e141d516a5a117/README.md',None)]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:r=list(e.map(fetch,items))
(P/'pools_receipts.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
