import json,datetime,pathlib,collections
P=pathlib.Path(__file__).parent
pools=[]
for x in sorted(json.load(open(P/'pools_rpc.json')),key=lambda r:r['id']):
 words=[x['result'][2:][i:i+64] for i in range(0,len(x['result'])-2,64)]
 assert len(words)==7
 fields=['rewardToken','fundRaisingToken','tokenAllocationStartBlock','stakingEndBlock','pledgeFundingEndBlock','targetRaise','maxStakingAmountPerUser']
 pools.append(dict(pid=x['id']-1,**{k:('0x'+v[-40:] if i<2 else str(int(v,16))) for i,(k,v) in enumerate(zip(fields,words))}))
claims=[]
for e in json.load(open(P/'fundsclaimed_logs.json'))['result']:
 claims.append({'pid':int(e['topics'][1],16),'recipient':'0x'+e['topics'][2][-40:],'amount_raw':str(int(e['data'],16)),'block':int(e['blockNumber'],16),'utc':datetime.datetime.fromtimestamp(int(e['timeStamp'],16),datetime.timezone.utc).isoformat(),'tx':e['transactionHash']})
added=[]
for e in json.load(open(P/'pooladded_logs.json'))['result']:
 added.append({'pid':int(e['topics'][1],16),'block':int(e['blockNumber'],16),'utc':datetime.datetime.fromtimestamp(int(e['timeStamp'],16),datetime.timezone.utc).isoformat(),'tx':e['transactionHash']})
for x in pools:
 x['creation']=next(a for a in added if a['pid']==x['pid'])
 x['fund_claims']=[a for a in claims if a['pid']==x['pid']]
(P/'pools_decoded.json').write_text(json.dumps(pools,indent=2))
(P/'fundclaims_decoded.json').write_text(json.dumps(claims,indent=2))
(P/'pooladded_decoded.json').write_text(json.dumps(added,indent=2))
print('pools',len(pools),'claims',len(claims))
for x in pools:print(x['pid'],x['rewardToken'],x['fundRaisingToken'],x['creation']['utc'],[(a['utc'],a['recipient'],a['amount_raw']) for a in x['fund_claims']])
print('recipient totals raw',collections.Counter(c['recipient'] for c in claims))
