# Ethereum fundraising ownership and complete pool census

Prepared 7 September 2026 UTC. Public, read-only examination of Ethereum contract `0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf`, verified as `LaunchPoolERC20FundRaisingWithVesting`. This lane covers this one contract and its 21 pools, not all Launchpool fundraising contracts.

## Findings

1. **The wallet control handover is now dated exactly.** The creator and original owner was `0xdb7d1459ddce7887266f25de31f090ff0eafea6c`. It deployed the contract on **17 May 2021 at 10:43:53 UTC**, block **12,451,406**, transaction `0xefc53f64ecbdad413ef171858b5615e149be6b8f1f3e7645c3373fe61671bf05`. On **11 February 2022 at 08:19:43 UTC**, block **14,183,639**, it successfully called `transferOwnership` to transfer contract authority to `0x77bfe8d704b1948374bf8dab8328a810b2836e66`, transaction `0x520df656ffe5c57278aafd86977b8fb7e43c58d638c3f2f5dfc756cc77114ecf`. The decoded call and OwnershipTransferred event agree. The log query returned the creation event and this one subsequent transfer event.

2. **The current owner remains 77bf.** Pinned RPC reads at Ethereum block **25,923,587**, hash `0x3777651e389298b343f7c6519f72791f9a2b5f0d603c04ebbb79ddaeb3d5b57a`, timestamp **7 September 2026 at 06:08:35 UTC**, return owner 77bf and 21 pools. The staking token is `0x6149c26cd2f7b5ccdb32029af817123f6e37df5b` and the reward guild is `0x137a28a85e00c8c2680ba1e0d4f344f435742ae7`. The staking token is distinct from each pool's reward token.

3. **All 21 pools have now been mapped; none specifies the exact ML ERC-20 address `0x059956483753947536204e89bfad909e1a434cc6` as its reward token.** All use USDC `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` as the fundraising token. PoolAdded logs cover every index 0–20, created from 17 May through 26 July 2021. The source initializes reward/fundraising-token addresses in `add` and has no setter replacing these fields. This closes this contract as a candidate for the November 2021 / March 2022 Mintlayer BUSD raises; it does not close the separate BSC contract lane.

4. **A complete fundraising-receipt census reconciles to token transfers and contract state.** There are 17 FundRaisingClaimed events, each matching exactly one outgoing USDC Transfer in the same transaction. Fifteen 2021 events paid the original owner db7d a total **2,520,862.549169 USDC**. The two already documented IAG pool 9/10 events paid 77bf **191,393.685754 USDC** on 2 July 2024. Total owner receipts for this contract are **2,712,256.234923 USDC**. All 21 `poolIdToTotalRaised` values and claimed flags match this ledger: pools 4, 7, 8 and 15 each report zero raised and funds not claimed; the other 17 are claimed. The pinned USDC balance is zero. Zero balance here follows the verified owner payouts; it is not a missing-funds calculation or evidence of theft.

5. **Four exact later-payment matches connect db7d to a594.** Independently joining this lane's claim records with the upstream lane's parsed transfer records yields the following. Each day's payments to a594 occur after that day's pool withdrawals. The eight transfers total **1,666,023.139484 USDC**. This is evidence of a repeated wallet settlement relationship. It is not a complete db7d balance history and does not exclude commingling of fungible USDC.

| Date UTC | Pool IDs | USDC received by db7d | Later USDC db7d → a594 |
|---|---|---:|---:|
| 23 June 2021 | 0, 1 | 459,688.011230 | 10 + 459,678.011230 |
| 5 August 2021 | 11, 12 | 445,769.391270 | 10 + 445,759.391270 |
| 14 September 2021 | 19, 20 | 372,973.160577 | 10 + 372,963.160577 |
| 1 October 2021 | 5, 6, 16 | 387,592.576407 | 10 + 387,582.576407 |

Here a594 is `0xa594af6496a61423582b19319732e3c7dc072f9f`. Exact transactions, amounts and ordering are retained in `matched_settlements.json`. The upstream source file is `../ml_upstream/db7d_a594_crosslinks.json`; the original explorer pages and parsed full wallet history are retained by that lane.

## Platform attribution and GitHub check

A separate lane recovered official app bundles containing the `LaunchPoolERC20FundRaisingWithVesting` artifact and network map naming this Ethereum address. Archived source URLs:

- https://web.archive.org/web/20211122145742id_/https://app.launchpool.xyz/_nuxt/41d2656.js — SHA256 `57b821209165538bac405c8ad11f6e01286f6b7af78c591e8c46ef11fd467c5c`.
- https://web.archive.org/web/20220316182710id_/https://app.launchpool.xyz/_nuxt/5ef6fbd.js — SHA256 `a68289be20aec3da2ee3432267fe8942d6c25024add1da6d42cd5a996450f0d0`.

See `../archived_bsc_contracts/bundle_configuration_extract.json` and extracted fundraising ABI/network artifacts for the reproduced primary platform mapping. Full JavaScript remains internal retrieval material.

The public Launchpool GitHub organization links launchpool.xyz. The Smart-Contracts repository tree at commit `eed17d7ea2fe2c3c08e73df6a7e141d516a5a117` contains contract source and README, with no deployment/configuration files exposing a signer address. The LPOOL_Arbitrum repository address file at commit `4059f4939fdbb21c1564fe9bcf9b5ce772810db9` contains an empty Arbitrum value. These bounded checks found no published deployer-to-person mapping; they are not a claim that all GitHub history was searched.

## Attribution limits

The dated on-chain actions identify addresses exercising contract authority and receiving tokens. They do not identify Laura Walsh/Takenaka as a signer, beneficiary, or current controller. Public job titles do not resolve private-key ownership. This lane does not establish the legal owner of the funds or wrongdoing.

The explorer currently marks db7d as having an EIP-7702 Forwarder delegation. That is current address metadata, not the address's execution status at the 2021/2022 transactions; it must not be retroactively described as a Safe or ordinary deployed contract at those dates.

## Reproducibility and verification

- Exact requests, responses and UTC captures: `initial_receipts.json`, `state_receipts.json`, `rpc_state_receipt.json`, `pools_receipts.json`, `verification_receipts.json`.
- Contract chronology: `address.json`, `creation_tx.json`, `handover_tx.json`, `ownership_logs.json`.
- Pinned state: `rpc_block.json`, `pinned_block.json`, `rpc_state.json`, `pools_rpc.json`, `pool_fund_state.json`.
- Complete decoded pool and receipt records: `pools_decoded.json`, `pooladded_decoded.json`, `fundclaims_decoded.json`.
- Independent USDC-event crosscheck: `usdc_out_logs.json`, `verification_results.json`.
- Cross-lane arithmetic: `crosscheck_settlements.py`, `matched_settlements.json`.
- Verified Solidity reused from `../../onchain_pass2/cash_custody/verified_source/contracts/LaunchPoolERC20FundRaisingWithVesting.sol`; exact-match source source URL https://etherscan.io/address/0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf#code.
- Human-readable primary transaction: https://etherscan.io/tx/0x520df656ffe5c57278aafd86977b8fb7e43c58d638c3f2f5dfc756cc77114ecf.
- Public APIs: https://eth.blockscout.com/api and https://ethereum-rpc.publicnode.com. No private credentials used.

All requests in this lane succeeded. The pool census and 17-event count were crosschecked against pinned state rather than relying on explorer list counts alone. The ownership log query used latest, retrieved shortly before the pinned state; the pinned current-owner read confirms its final owner. No new transaction or external request to a person was sent.
