import json,urllib.request,hashlib,datetime,pathlib,concurrent.futures
import sys
sys.path.insert(0,str(pathlib.Path(__file__).parents[2]/"claims_peer"))
from verify_claims import keccak256
P=pathlib.Path(__file__).parent
A='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf'
def sel(x):return '0x'+keccak256(x.encode()).hex()[:8]
def fetch(t):
 n,u,p=t;r={'name':n,'url':u,'request':p,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  q=urllib.request.Request(u,data=json.dumps(p).encode() if p is not None else None,headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'})
  with urllib.request.urlopen(q,timeout=35) as x:b=x.read();r.update(status=x.status)
  (P/(n+'.json')).write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r['error']=str(e)
 return r
items=[('handover_tx','https://eth.blockscout.com/api/v2/transactions/0x520df656ffe5c57278aafd86977b8fb7e43c58d638c3f2f5dfc756cc77114ecf',None),('creation_tx','https://eth.blockscout.com/api/v2/transactions/0xefc53f64ecbdad413ef171858b5615e149be6b8f1f3e7645c3373fe61671bf05',None),('github_tree','https://api.github.com/repos/Launchpool/Smart-Contracts/git/trees/master?recursive=1',None),('rpc_block','https://ethereum-rpc.publicnode.com',{'jsonrpc':'2.0','id':1,'method':'eth_blockNumber','params':[]})]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:r=list(e.map(fetch,items))
(P/'state_receipts.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
for e in json.load(open(P/'ownership_logs.json'))['result']:print('Ownership',int(e['blockNumber'],16),datetime.datetime.fromtimestamp(int(e['timeStamp'],16),datetime.timezone.utc).isoformat(),e['transactionHash'])
if (P/'rpc_block.json').exists():
 j=json.load(open(P/'rpc_block.json'));block=j.get('result')
 if block:
  batch=[{'jsonrpc':'2.0','id':i+1,'method':'eth_call','params':[{'to':A,'data':sel(f)},block]} for i,f in enumerate(['owner()','numberOfPools()','stakingToken()','rewardGuildBank()'])]
  r2=fetch(('rpc_state','https://ethereum-rpc.publicnode.com',batch));(P/'rpc_state_receipt.json').write_text(json.dumps(r2,indent=2));print(json.dumps(r2,indent=2))
