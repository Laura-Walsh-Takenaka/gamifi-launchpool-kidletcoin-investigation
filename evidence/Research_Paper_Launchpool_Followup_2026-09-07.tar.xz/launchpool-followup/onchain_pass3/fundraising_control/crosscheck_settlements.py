import json,pathlib,decimal,collections
P=pathlib.Path(__file__).parent
C=json.load(open(P/'fundclaims_decoded.json'));E=json.load(open(P.parent/'ml_upstream/db7d_a594_crosslinks.json'))['events']
D=decimal.Decimal
rows=[]
for day in ['2021-06-23','2021-08-05','2021-09-14','2021-10-01']:
 a=[c for c in C if c['utc'][:10]==day]
 b=[e for e in E if e['utc'][:10]==day and e['from']=='0xdb7d1459ddce7887266f25de31f090ff0eafea6c' and e['token']=='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48']
 x=sum((D(c['amount_raw'])/D(10**6) for c in a),D(0));y=sum((D(e['amount']) for e in b),D(0));assert x==y,(day,x,y)
 rows.append({'day':day,'fund_claim_total_usdc':str(x),'later_db7d_to_a594_total_usdc':str(y),'fund_claims':a,'transfers_to_a594':b,'exact_match':x==y,'ordering':min(z['utc'] for z in b)>max(z['utc'] for z in a)})
r={'matched_days':rows,'sum_usdc':str(sum(D(x['fund_claim_total_usdc']) for x in rows)),'scope':'Exact daily receipt-to-later-payout amount matching; not a complete db7d balance ledger and not a claim that fungible units cannot have been commingled. No named controller attribution.'}
(P/'matched_settlements.json').write_text(json.dumps(r,indent=2));print(r['sum_usdc'],[(r['day'],r['exact_match'],r['ordering']) for r in rows])
