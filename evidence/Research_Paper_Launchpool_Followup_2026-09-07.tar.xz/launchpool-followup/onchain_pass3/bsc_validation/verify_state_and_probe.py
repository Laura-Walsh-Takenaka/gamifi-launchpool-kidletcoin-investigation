import json,hashlib,datetime,pathlib,urllib.request,concurrent.futures
from decimal import Decimal, getcontext
import importlib.util
P=pathlib.Path(__file__).parent;R=P.parents[1];getcontext().prec=70
A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';B='0x72dd631'
spec=importlib.util.spec_from_file_location('verifier',R/'claims_peer/verify_claims.py');verifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(verifier)
def kh(s):return verifier.keccak256(s.encode()).hex()
abi=json.loads((P.parent/'archived_bsc_contracts/raise1_last_fundraising_abi.json').read_text())['abi']
mp=json.loads((P.parent/'bsc_cash/mintlayer_pool_request_map.json').read_text());raw=json.loads((P.parent/'bsc_cash/mintlayer_pools.response').read_text());req=json.loads((P.parent/'bsc_cash/mintlayer_pools.receipt.json').read_text())['request']
by={mp[str(r['id'])]:r for r in raw};results={'contract':A,'block':int(B,16),'independent_hash_library':'existing pure-Python verifier; ABI words and arithmetic independently decoded','selectors':{},'pools':[],'event_abi':next(x for x in abi if x.get('name')=='FundRaisingClaimed')}
for sig in ['poolInfo(uint256)','poolIdToTotalRaised(uint256)','poolIdToFundsClaimed(uint256)','owner()']:
 sel='0x'+kh(sig)[:8]; results['selectors'][sig]=sel
 for q in req:
  if q['method']=='eth_call' and mp[str(q['id'])].startswith(sig.split('(')[0]):assert q['params'][0]['data'].startswith(sel)
outputs=next(x for x in abi if x.get('name')=='poolInfo')['outputs']
for pid in [19,20,21,125,126,127]:
 s=by[f'poolInfo(uint256):{pid}']['result'][2:];w=[s[x:x+64] for x in range(0,len(s),64)];assert len(w)==len(outputs)
 info={o['name']:('0x'+v[-40:] if o['type']=='address' else int(v,16)) for o,v in zip(outputs,w)}
 n=int(by[f'poolIdToTotalRaised(uint256):{pid}']['result'],16);claimed=int(by[f'poolIdToFundsClaimed(uint256):{pid}']['result'],16)
 results['pools'].append({'pid':pid,**info,'raised_raw':str(n),'raised_busd':format(Decimal(n)/Decimal(10**18),'f'),'funds_claimed':bool(claimed)})
results['owner']='0x'+by['owner']['result'][-40:]
for k,pids in [('raise1',[19,20,21]),('raise2',[125,126,127]),('combined',[19,20,21,125,126,127])]:
 n=sum(int(p['raised_raw']) for p in results['pools'] if p['pid'] in pids);results[k]={'raised_raw':str(n),'raised_busd':format(Decimal(n)/Decimal(10**18),'f')}
results['event_topic']='0x'+kh('FundRaisingClaimed(uint256,address,uint256)')
(P/'state_peer_verification.json').write_text(json.dumps(results,indent=2))
topic=results['event_topic'];pidtopics=['0x'+format(n,'064x') for n in [19,20,21]]
probes=[('bnb_logs_raise1','https://bsc-dataseed.bnbchain.org',{'jsonrpc':'2.0','id':1,'method':'eth_getLogs','params':[{'address':A,'topics':[topic,pidtopics],'fromBlock':hex(13125200),'toBlock':hex(13225200)}]}),('publicnode_logs_raise1','https://bsc-rpc.publicnode.com',{'jsonrpc':'2.0','id':1,'method':'eth_getLogs','params':[{'address':A,'topics':[topic,pidtopics],'fromBlock':hex(13125200),'toBlock':hex(13225200)}]})]
def fetch(item):
 name,u,q=item;r={'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':q}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(q).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=30) as z:
   b=z.read();r.update(status=z.status,sha256=hashlib.sha256(b).hexdigest());(P/(name+'.response')).write_bytes(b);r['response_preview']=b.decode()[:500]
 except Exception as e:r['error']=str(e)
 (P/(name+'.receipt.json')).write_text(json.dumps(r,indent=2));return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex: print(json.dumps(list(ex.map(fetch,probes)),indent=2))
print(json.dumps({k:results[k] for k in ['raise1','raise2','combined','owner']},indent=2))
