# BSC original-cash lane: independent state and purchase verification

Checked 7 September 2026. Read-only work; no account access, signatures, transactions, or outside messages.

## Finding

The preserved RPC response at BNB Smart Chain block **120,444,465** independently decodes to the following pool counters for contract `0xd975b13cdf91de3aa0e0e888fb827fec3650624a`. The project-to-pool mapping is supplied by the separately preserved public application configuration in `archived_bsc_contracts`; this peer check verifies the corresponding ABI, request selectors, returned words, and arithmetic.

| Mapping | Pool | Recorded total raised, BUSD | Funds-claimed flag |
|---|---:|---:|---|
| Mintlayer Raise 1 | 19 | 194775.268548166718546 | true |
| Mintlayer Raise 1 | 20 | 195415.21517867104204 | true |
| Mintlayer Raise 1 | 21 | 197226.626562780028172 | true |
| Mintlayer Raise 2 | 125 | 101799.763199702252300446 | true |
| Mintlayer Raise 2 | 126 | 103426.318782728639320062 | true |
| Mintlayer Raise 2 | 127 | 111151.154147533804991818 | true |

Exact sums:

- Raise 1: **587417.110289617788758 BUSD**.
- Raise 2: **316377.236129964696612326 BUSD**.
- Combined: **903794.346419582485370326 BUSD**.

All six `fundRaisingToken` words identify `0xe9e7cea3dedca5984780bafc599bd69add087d56`. Conversion above uses 18 decimals, independently confirmed by the fresh metadata response at block 120,445,486. The current `owner()` word identifies `0x77bfe8d704b1948374bf8dab8328a810b2836e66`. Current ownership is not a historical claim-recipient record or an attribution to a named person.

Pool words contain 200000 BUSD target for each Raise 1 pool, and 133333.333333 BUSD target for each Raise 2 pool. These are present contract fields, not proof of what every investor was shown at purchase time. The actual raised counters are separate from the targets.

`state_peer_verification.json` preserves every decoded word, raw integer amount, exact decimal amount, and sum. Calculations use integer arithmetic and high-precision Decimal. Selectors were checked against signatures derived from the recovered ABI using the existing pure-Python Keccak implementation; this is an independent decoding/arithmetic review, not an independently implemented Keccak audit.

## Concrete purchase corroboration

Transaction `0x56ba03b73564c3c110319c4c056230441b58c89a8cdaff071cfe71afc3912da9` was independently obtained from BNB's public RPC through `eth_getTransactionReceipt` and `eth_getTransactionByHash`.

- Success status `0x1`, chain ID 56, block **13,056,994**.
- Block hash `0x4387ca5a31be56a3bc41dfe1c1b6fa7fb41d1bbeacbe9222ea5398b50c8e6e4e`.
- Receipt-log timestamp: **29 November 2021 at 19:02:49 UTC**.
- Caller `0xe5b7c3396ca0b154a80019ccf3fe08f162495e66` called `fundPledge(21)` on the contract above.
- BUSD Transfer records **59.820643332035352 BUSD** from that caller into the contract.
- The same successful receipt has a `PledgeFunded(address,uint256,uint256)` event with the same caller, pool 21, and exact amount.
- A separate LPOOL return appears in the receipt; it is not included in the BUSD amount.

This is one contribution example and is already encompassed by the raised-counter history. Do not add the example amount to the counter totals.

## Historical claim-recipient gap

The recovered ABI declares `FundRaisingClaimed(uint256,address,uint256)` with **both pid and recipient indexed**, and amount in data. The event topic is `0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089`.

Bounded attempts:

1. BNB public RPC rejected a filtered 100001-block Raise 1 event request with `limit exceeded`.
2. Publicnode's same bounded request returned HTTP 403. No bypass attempted.
3. A read batch that included a 5000-block log query returned `method eth_getLogs in batch triggered rate limit`; that batch does not establish any result for its individual subrequests.
4. A later standalone **100-block** event query also returned `limit exceeded`.
5. The transaction/receipt reads succeeded when issued without the log query. Four historical `poolIdToFundsClaimed` calls at Raise 1 and Raise 2 boundary blocks returned `missing trie node`.
6. Exact-address public searches did not recover useful historical settlement receipts. Search-engine empty or irrelevant results are not evidence of absence.

The six current true flags are not substitutes for the missing historical successful `claimFundRaising` receipts, their callers, recipient topics, outgoing BUSD Transfers, or onward use of those funds. No original-proceeds receipt by Laura is established in this lane. The figures are recorded raising totals, not a calculated loss or theft amount.

## Preserved evidence

- `state_peer_verification.json`: independently decoded supplied current snapshot.
- `purchase_and_historical_reads.response` and matching receipt: successful transaction/receipt plus historical state errors.
- `purchase_peer_verification.json`: independently checked purchase details and event agreement.
- Other `.response` / `.receipt.json` pairs: exact failed historical requests and responses.
- `verify_state_and_probe.py`, `historical_probe.py`, `decode_purchase.py`: review and retrieval logic.

## Metadata follow-up peer check

`metadata_peer_verification.json` and `verify_metadata.py` independently decode the fresh response at block **120,445,486**, verify each selector and dynamic string offset, validate the preserved response hash, and cross-check the updated root summary against this peer's six-pool arithmetic.

- Fundraising asset: **BUSD Token / BUSD / 18 decimals**.
- Reward field `0x39d3409ef92f6aa942b4b7be006e020b0c758131`: **Test Binance USD / TBUSD / 18 decimals**. This address must not be presented as ML. Mintlayer attribution comes from the explicit project mapping and corresponding schedules.
- `numberOfPools()` returns **153**.
- Aggregate contract BUSD balance: **10.9147285779989975 BUSD**. It is not a segregated Mintlayer reserve and provides no per-project deficit calculation.

The updated `bsc_cash/BSC_CASH_MEMO.md` amounts and metadata agree with the underlying data. Its explanation that D975 executable runtime differs from the generic archived source is appropriate: an interface match cannot import another contract's withdrawal authorization rules. Historical claim recipients and deployed source remain unresolved. The memo's phrase "actual owner withdrawal" would be more precise as "actual fundraising withdrawal" because source authority has not been recovered.
