import json,hashlib,datetime,pathlib,urllib.request
P=pathlib.Path(__file__).parent;A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';U='https://bsc-dataseed.bnbchain.org';TX='0x56ba03b73564c3c110319c4c056230441b58c89a8cdaff071cfe71afc3912da9'
def rpc(name,qs):
 r={'url':U,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs}
 try:
  with urllib.request.urlopen(urllib.request.Request(U,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=35) as z:
   b=z.read();r.update(status=z.status,sha256=hashlib.sha256(b).hexdigest());(P/(name+'.response')).write_bytes(b);x=json.loads(b)
 except Exception as e:r['error']=str(e);x=None
 (P/(name+'.receipt.json')).write_text(json.dumps(r,indent=2));return x
if __name__=='__main__':
 qs=[{'jsonrpc':'2.0','id':1,'method':'eth_getTransactionReceipt','params':[TX]},{'jsonrpc':'2.0','id':2,'method':'eth_getTransactionByHash','params':[TX]}]
 for i,(p,b) in enumerate([(19,13125200),(19,13500000),(125,16525000),(125,17000000)],3):qs.append({'jsonrpc':'2.0','id':i,'method':'eth_call','params':[{'to':A,'data':'0xb9641a21'+format(p,'064x')},hex(b)]})
 qs.append({'jsonrpc':'2.0','id':7,'method':'eth_getLogs','params':[{'address':A,'topics':['0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089'],'fromBlock':hex(13125200),'toBlock':hex(13130199)}]})
 x=rpc('purchase_and_historical_probe',qs);print(json.dumps(x,indent=2)[:13000])
