import pathlib,json,hashlib,importlib.util
from decimal import Decimal,getcontext
P=pathlib.Path(__file__).parent;R=P.parents[1];getcontext().prec=70
spec=importlib.util.spec_from_file_location('v',R/'claims_peer/verify_claims.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
D=P.parent/'bsc_cash';raw=(D/'token_metadata_fresh.response').read_bytes();receipt=json.loads((D/'token_metadata_fresh.receipt.json').read_text());assert hashlib.sha256(raw).hexdigest()==receipt['sha256'];rows={x['id']:x for x in json.loads(raw)}
sigs=['decimals()','symbol()','name()','balanceOf(address)','numberOfPools()','symbol()','name()','decimals()']; decoded={};selectors={}
def string(s):
 b=bytes.fromhex(s[2:]);offset=int.from_bytes(b[:32],'big');assert offset==32
 n=int.from_bytes(b[offset:offset+32],'big');assert 64+n<=len(b);return b[offset+32:offset+32+n].decode('utf-8')
for q,name,sig in zip(receipt['request'],receipt['names'],sigs):
 assert q['params'][1]=='0x72dda2e';sel='0x'+v.keccak256(sig.encode()).hex()[:8];assert q['params'][0]['data'].startswith(sel);selectors[sig]=sel
 s=rows[q['id']]['result'];decoded[name]=string(s) if sig in ['name()','symbol()'] else int(s,16)
assert decoded['busd_decimals']==decoded['reward_decimals']==18
assert decoded['reward_name']=='Test Binance USD' and decoded['reward_symbol']=='TBUSD'
assert decoded['busd_name']=='BUSD Token' and decoded['busd_symbol']=='BUSD'
assert decoded['numberOfPools']==153
balance=format(Decimal(decoded['contract_busd_balance'])/Decimal(10**decoded['busd_decimals']),'f')
summary=json.loads((D/'pool_state_summary.json').read_text());assert summary['contract_BUSD_balance_at_metadata_block']==balance
assert summary['token_metadata_block']==int('72dda2e',16)
assert summary['fundraising_asset']['name']==decoded['busd_name'];assert summary['reward_field_asset']['name']==decoded['reward_name']
peer=json.loads((P/'state_peer_verification.json').read_text())
for i,p in zip(summary['pools'],peer['pools']):
 assert i['pool_id']==p['pid'];assert i['reward_token']==p['rewardToken'];assert i['fundraising_token']==p['fundRaisingToken'];assert i['totalRaised_BUSD']==p['raised_busd'];assert i['fundsClaimed']==p['funds_claimed']
for key,old in [('raise1_recorded_BUSD','raise1'),('raise2_recorded_BUSD','raise2'),('combined_recorded_BUSD','combined')]:assert summary[key]==peer[old]['raised_busd']
result={'status':'PASS','metadata_block':int('72dda2e',16),'response_sha256':hashlib.sha256(raw).hexdigest(),'checked_selectors':selectors,'decoded':decoded,'contract_busd_balance_decimal':balance,'summary_matches_independent_pool_decode':True,'memo_interpretation':'Amounts, metadata, schedule blocks and source limitations agree. Current aggregate balance is not a per-project reserve. TBUSD reward field must not be called ML. Current owner and flags do not establish historical settlement recipient or deployed withdrawal authorization rules.'}
(P/'metadata_peer_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
