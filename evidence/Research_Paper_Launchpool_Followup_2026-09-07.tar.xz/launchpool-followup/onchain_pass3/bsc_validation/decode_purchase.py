import json,pathlib,datetime,importlib.util,hashlib
from decimal import Decimal,getcontext
P=pathlib.Path(__file__).parent;R=P.parents[1];getcontext().prec=70
s=importlib.util.spec_from_file_location('v',R/'claims_peer/verify_claims.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
a=json.loads((P.parent/'archived_bsc_contracts/raise1_last_fundraising_abi.json').read_text())['abi']
r={i['id']:i for i in json.loads((P/'purchase_and_historical_reads.response').read_text())};rec=r[1]['result'];tx=r[2]['result'];A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'
assert rec['status']=='0x1' and tx['to']==A and rec['transactionHash']==tx['hash']
f=next(x for x in a if x.get('name')=='fundPledge');sig=f['name']+'('+','.join(x['type'] for x in f['inputs'])+')';assert tx['input'][:10]=='0x'+v.keccak256(sig.encode()).hex()[:8]
pid=int(tx['input'][10:],16);assert pid==21
fund_event=next(x for x in a if x.get('name')=='PledgeFunded');event_sig=fund_event['name']+'('+','.join(x['type'] for x in fund_event['inputs'])+')';topic='0x'+v.keccak256(event_sig.encode()).hex()
fund=next(l for l in rec['logs'] if l['address']==A and l['topics'][0]==topic)
assert len(fund['topics'])==3
assert '0x'+fund['topics'][1][-40:]==tx['from'] and int(fund['topics'][2],16)==pid
busd=next(l for l in rec['logs'] if l['address']=='0xe9e7cea3dedca5984780bafc599bd69add087d56' and l['topics'][0]=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef')
assert '0x'+busd['topics'][1][-40:]==tx['from'] and '0x'+busd['topics'][2][-40:]==A
amount=int(busd['data'],16);assert amount==int(fund['data'],16)
out={'tx_hash':tx['hash'],'chain_id':int(tx['chainId'],16),'block':int(rec['blockNumber'],16),'block_hash':rec['blockHash'],'block_timestamp_from_receipt_log':int(busd['blockTimestamp'],16),'utc':datetime.datetime.fromtimestamp(int(busd['blockTimestamp'],16),datetime.timezone.utc).isoformat(),'status':int(rec['status'],16),'caller':tx['from'],'destination':tx['to'],'function':sig,'pid':pid,'busd_token':busd['address'],'busd_amount_raw':str(amount),'busd_amount':format(Decimal(amount)/Decimal(10**18),'f'),'pledge_event_matches_token_transfer':True,'event_abi':fund_event,'event_signature':event_sig,'event_topic':topic,'receipt_log_index':int(busd['logIndex'],16),'funded_event_log_index':int(fund['logIndex'],16),'limitation':'One concrete purchase example corroborates the recovered pool mapping; this is not a complete contribution-event census.'}
(P/'purchase_peer_verification.json').write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
files=[p for p in P.iterdir() if p.is_file() and p.name not in ['SHA256SUMS.txt']]
(P/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name for p in sorted(files))+'\n')
