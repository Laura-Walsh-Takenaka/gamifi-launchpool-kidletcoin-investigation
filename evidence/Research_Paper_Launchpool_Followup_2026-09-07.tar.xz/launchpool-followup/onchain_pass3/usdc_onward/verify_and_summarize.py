#!/usr/bin/env python3
"""Offline arithmetic and calldata verification for the bounded USDC branch."""
from pathlib import Path
from decimal import Decimal,getcontext
import re,html,json,collections,hashlib
getcontext().prec=80
P=Path(__file__).resolve().parent
A='0x77bfe8d704b1948374bf8dab8328a810b2836e66';R='0x1991e27e2908847c0274a662eb6675002e8386d0';U='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';K='0x58edf78281334335effa23101bbe3371b6a36a51';D='0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee'
def flat(s):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>',' ',re.sub(r'<(script|style)\b.*?</\1>','',s,flags=re.S))))
all77=json.load(open(P.parent.parent/'onchain_pass2/ml_origin/all_token_events.json'))
selected77=[r for r in all77 if r['token']==U and r['utc'].startswith('2024-07-02')]
ins=sum(Decimal(r['amount']) for r in selected77 if r['to']==A);outs=sum(Decimal(r['amount']) for r in selected77 if r['from']==A);assert ins==outs==Decimal('191413.685754')
# All retained source-wallet USDC events reconcile arithmetically to zero.
usdc77=[r for r in all77 if r['token']==U];net77=sum(Decimal(r['amount'])*(1 if r['to']==A else -1) for r in usdc77);assert net77==0
parsed=[]
for f in sorted(list(P.glob('kucoin_tx_*.html'))+list(P.glob('poison[12]_tx.html'))):
 s=f.read_text();t=flat(s);raw=re.search(r"id='rawinput'[^>]*>(0x[0-9a-fA-F]+)",s).group(1);sender=re.search(r"id='data-fadd'>(0x[0-9a-fA-F]{40})",s).group(1).lower();to=re.search(r"id='data-tadd'>(0x[0-9a-fA-F]{40})",s).group(1).lower();h=re.search(r'Transaction Hash: (0x[0-9a-fA-F]{64})',t).group(1).lower();status=re.search(r'Status: (\w+)',t).group(1);block=int(re.search(r'Status: \w+ Block: (\d+)',t).group(1));words=[raw[i:i+64] for i in range(10,len(raw),64)];assert to==U and status=='Success'
 if raw[:10]=='0xa9059cbb':assert len(words)==2;origin=sender;recipient='0x'+words[0][-40:];n=int(words[1],16);method='transfer'
 elif raw[:10]=='0x23b872dd':assert len(words)==3;origin='0x'+words[0][-40:];recipient='0x'+words[1][-40:];n=int(words[2],16);method='transferFrom'
 else:raise ValueError(raw[:10])
 d={'source_file':f.name,'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'tx_hash':h,'block':block,'status':status,'transaction_caller':sender,'contract':to,'method':method,'token_sender':origin.lower(),'recipient':recipient.lower(),'raw_USDC':str(n),'USDC':str(Decimal(n)/10**6),'input':raw,'explorer_labels':sorted(set(re.findall(r'Fake_Phishing\d+|KuCoin \d+',t)))};parsed.append(d)
(P/'decoded_successful_transfers.json').write_text(json.dumps(parsed,indent=2))
kucoin=[r for r in parsed if r['source_file'].startswith('kucoin')];assert sum(Decimal(r['USDC']) for r in kucoin if r['recipient']==K)==Decimal('80750');assert sum(Decimal(r['USDC']) for r in kucoin if r['recipient']==D)==Decimal('80750')
# Independently compare available RPC receipt Transfer logs to explorer event data.
all_events=selected77[:]
for f in ['9118_tokens.json','3b4d_tokens.json','1991_tokens6.json','4d0d_tokens.json']:
 all_events+=json.load(open(P/f))
verified=[]
for f in ['rpc_chain_receipts.json','branch_receipts.json','poison_receipts_drpc.json']:
 for r in json.load(open(P/f)):
  rec=r.get('result')
  if not isinstance(rec,dict):continue
  assert rec['status']=='0x1'
  for lg in rec.get('logs',[]):
   if lg['address']!=U or lg['topics'][0]!='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef':continue
   frm='0x'+lg['topics'][1][-40:];to='0x'+lg['topics'][2][-40:];raw=int(lg['data'],16);h=lg['transactionHash'];match=[x for x in all_events if x['tx_hash']==h and x['from']==frm and x['to']==to and Decimal(x['amount'])*10**6==raw];assert match,(f,h);verified.append({'tx_hash':h,'block':int(lg['blockNumber'],16),'from':frm,'to':to,'raw_USDC':str(raw),'USDC':str(Decimal(raw)/10**6),'receipt_source_file':f})
(P/'rpc_event_crosschecks.json').write_text(json.dumps(verified,indent=2))
flows=[r for r in json.load(open(P/'1991_tokens6.json')) if r['token']==U and r['from']==R and '2024-07-02'<=r['utc']<'2024-07-18'];totals=collections.defaultdict(Decimal)
for r in flows:totals[r['to']]+=Decimal(r['amount'])
assert len(flows)==14 and sum(totals.values())==Decimal('138550')
summary={'source_wallet':A,'fundraising_USDC':'191393.685754','lookalike_incoming_USDC':'20','july2_outgoing_USDC':str(outs),'july2_source_net_USDC':str(ins-outs),'all_retrieved_source_USDC_events':len(usdc77),'all_retrieved_source_USDC_event_net':str(net77),'july2_events':selected77,'MEXC_route':list({r['tx_hash']:r for r in all_events if r['tx_hash'] in ['0x5c51e3116c5092a676717c3d3ab88a913105b9e7a067bc869f5a8d979a505988','0x8ee2c0d99ff4c71c29fa422a19cdeb560c248d32cbb156c0542e8ff3c7ae7fab']}.values()),'KuCoin_route':kucoin,'KuCoin_destination':K,'KuCoin_USDC':'80750','recipient_1991_July3to16_USDC_out':'138550','recipient_1991_July3to16_by_destination':{k:str(v) for k,v in totals.items()},'recipient_1991_July3to16_events':flows,'RPC_USDC_event_crosschecks':len(verified),'historical_balance_status':'Not retrieved: Publicnode archive calls require a personal token. No starting-balance / exclusive-source conclusion for 1991.','scope_limit':'Exploratory address histories are bounded pages. No human key holder or exchange customer attribution, and no Mintlayer BUSD cash attribution.'}
(P/'usdc_onward_summary.json').write_text(json.dumps(summary,indent=2))
manifest=[]
for f in sorted(P.iterdir()):
 if f.is_file() and f.name!='SHA256SUMS':manifest.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name)
(P/'SHA256SUMS').write_text('\n'.join(manifest)+'\n');print(json.dumps({k:v for k,v in summary.items() if not isinstance(v,(list,dict))},indent=2))
