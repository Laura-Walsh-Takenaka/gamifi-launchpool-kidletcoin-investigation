# Independent peer review — USDC onward lane

**Disposition: PASS for the findings and limitations stated in the memo.** Review performed from retained public evidence without new network calls. No report edits made.

**Coverage clarification: zero KuCoin-route transactions have retained successful raw RPC receipts.** The six KuCoin transactions were checked against explorer HTML status/calldata. The separate six raw RPC checks cover the 150,000 USDC payment to 1991, the two MEXC-route transfers, the two 31,403.685754 USDC intermediary transfers, and the second 10 USDC lookalike receipt. No hash belongs to both groups.

## Independently checked

1. **KuCoin branch:** decoded the raw input elements from all six transaction HTML pages independently of the lane's decoder. Each page records Success and the exact Circle USDC contract. Three payments from 1991 to 4d0d—15,000, 50,250 and 15,500 USDC—match three later payments from 4d0d to the KuCoin 20-labelled address. Each side sums to **80,750 USDC**. The 15,000 and 15,500 sweeps are `transferFrom` calls by the KuCoin 22-labelled address; the 50,250 sweep is a `transfer` from 4d0d. Caller, token sender and token recipient are correctly distinguished. Their page hashes match the retained decoder records.
2. **Raw RPC checks:** independently decoded the actual Transfer topics/data from successful raw receipts and matched all **six** events cited in `rpc_event_crosschecks.json`. This includes both 10,000 USDC MEXC-route transfers, both 31,403.685754 USDC intermediary transfers, the 150,000 USDC payment to 1991 and the second 10 USDC lookalike receipt. The KuCoin branch does not have successful raw RPC receipt coverage in this lane; the memo correctly says so.
3. **Funding reconciliation:** recalculated the 11 source-wallet USDC events using the earlier preserved token records. The July 2024 fundraising receipts total **191,393.685754 USDC**. Two separate incoming 10 USDC transfers explain outgoing **191,413.685754 USDC** exactly. Overall retrieved USDC event net is zero. Both lookalike transaction pages independently show successful USDC `transfer` calldata of 10,000,000 base units to 77bf. This does not convert the two unrelated lookalike accounts into operator-controlled wallets.
4. **MEXC branch:** the 9118 explorer page advertises 14 token rows, matching the retained 14 rows; exactly two are USDC. Their 10,000 USDC receipt and onward payment match successful raw RPC receipts. This supports the direct two-transfer route more strongly than the source-attribution available for the active 1991 wallet.
5. **1991 boundary:** the retained archive responses explicitly require a personal token and supply no historical balance. The July 3–16 interval contains fourteen outgoing USDC transfers totaling **138,550**, with the next incoming USDC event on July 18. The memo correctly treats the KuCoin payments as an onward branch after the 150,010 receipt, without assigning every fungible unit exclusively to that receipt. Earlier funds and commingling remain material.
6. **Labels:** all six retained address-page title excerpts and source hashes match. The labels identify explorer-attributed KuCoin/MEXC addresses; none supplies a human customer identity, a Laura signing-key attribution, or a legal ownership conclusion.

## Review limits and wording

- Explorer page status and calldata for the KuCoin branch are not described as independently RPC-confirmed; preserve that distinction in the report.
- The memo's zero source-wallet figure is event arithmetic, not a newly pinned live balance; preserve that qualification.
- Do not add the 80,750 onward payments to the original fundraising total as new receipts or call them missing funds.
- The poisoning interpretation remains an inference from the two lookalike addresses, timing and explorer labels. The underlying 20 USDC receipts themselves are evidenced.
- Pool/project attribution was established by the separate fundraising-control work and was not re-audited here. The onward lane appropriately keeps these receipts separate from unidentified original Mintlayer BUSD purchase proceeds.

An additional cross-lane connection is supported by the retained data: 1991 sent **27,100 USDC** to `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4` on July 10–11, 2024. The ML-upstream lane separately identifies that exact address as a shared gas/ML counterpart of the vesting wallets. This strengthens the connected-wallet map without establishing common human control.

The independent check script and compact results are `independent_peer_check.py` and `independent_peer_checks.json`. All checks passed; no network requests were made.
