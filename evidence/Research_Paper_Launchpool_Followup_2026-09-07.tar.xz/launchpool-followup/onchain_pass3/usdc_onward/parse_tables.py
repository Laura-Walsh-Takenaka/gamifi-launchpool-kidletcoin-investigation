from pathlib import Path
import re,html,json,datetime
P=Path(__file__).resolve().parent
def text(s):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>',' ',s))).strip()
def parse(f):
 s=f.read_text();rows=[]
 for row in re.findall(r'<tr\b[^>]*>(.*?)</tr>',s,re.S):
  tx=re.search(r'/tx/(0x[0-9a-fA-F]{64})',row)
  if not tx:continue
  a=re.findall(r'data-clipboard-text=[\'\"](0x[0-9a-fA-F]{40})[\'\"]',row);tok=re.search(r'/token/(0x[0-9a-fA-F]{40})',row);amt=re.search(r'class="td_showAmount"[^>]*data-bs-title="([^"]+)"',row);stamp=re.search(r'class=[\'\"]showLocalDate[^>]*>(.*?)</td>',row,re.S);block=re.search(r'/block/(\d+)',row)
  if len(a)!=2 or not tok or not amt or not stamp or not block:continue
  ts=int(text(stamp.group(1)));d={'tx_hash':tx.group(1).lower(),'from':a[0].lower(),'to':a[1].lower(),'token':tok.group(1).lower(),'amount':amt.group(1).split('|')[0].strip().replace(',',''),'utc':datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat(),'block':int(block.group(1)),'source_file':f.name};rows.append(d)
 f.with_suffix('.json').write_text(json.dumps(rows,indent=2));return rows
if __name__=='__main__':
 for f in P.glob('*.html'):
  if 'tokens' not in f.name and 'usdc' not in f.name and 'july24' not in f.name:continue
  rows=parse(f);print(f.name,len(rows),min([r['utc'] for r in rows],default=''),max([r['utc'] for r in rows],default=''))
