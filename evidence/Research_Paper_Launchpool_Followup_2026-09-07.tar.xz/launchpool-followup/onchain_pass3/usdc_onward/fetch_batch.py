import urllib.request,json,pathlib,datetime,concurrent.futures,sys
P=pathlib.Path(__file__).resolve().parent
requests=json.loads(sys.stdin.read())
def get(t):
 name,url,*post=t;r={'file':name,'url':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Public-record-research/1.0',**({'Content-Type':'application/json'} if post else {})},data=json.dumps(post[0]).encode() if post else None)
  with urllib.request.urlopen(req,timeout=40) as x:raw=x.read();r.update(status=x.status,bytes=len(raw));(P/name).write_bytes(raw)
 except Exception as e:r['error']=str(e)
 return r
out=list(concurrent.futures.ThreadPoolExecutor(max_workers=2).map(get,requests));n=len(list(P.glob('request_batch*.json')))+1;(P/f'request_batch{n}.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
