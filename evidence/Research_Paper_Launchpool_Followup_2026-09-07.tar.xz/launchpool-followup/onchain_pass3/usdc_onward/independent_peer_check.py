from pathlib import Path
from decimal import Decimal,getcontext
import json,re,hashlib,datetime,collections
P=Path(__file__).resolve().parent;getcontext().prec=80;checks={};USDC='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';SRC='0x77bfe8d704b1948374bf8dab8328a810b2836e66';A='0x1991e27e2908847c0274a662eb6675002e8386d0';DEP='0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee';HOT='0x58edf78281334335effa23101bbe3371b6a36a51';CALLER='0xa152f8bb749c55e9943a3a0a3111d18ee2b3f94e'
s=json.loads((P/'usdc_onward_summary.json').read_text())
# Use targeted element parsing: full page has HTML void tags with parser depth issues.
def inner(s,id):
 m=re.search(r'<span\b[^>]*\bid=[\'\"]'+re.escape(id)+r'[\'\"][^>]*>(.*?)</span>',s,re.S);assert m,id
 return re.sub('<[^>]*>','',m.group(1)).strip()
seen=[]
for r in s['KuCoin_route']:
 raw=(P/r['source_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['source_sha256'];h=raw.decode();call=inner(h,'rawinput').lower();status=inner(h,'data-status');frm=inner(h,'data-fadd').lower();to=inner(h,'data-tadd').lower();assert status=='Success' and to==USDC and call==r['input']
 b=bytes.fromhex(call[10:]);method=call[:10]
 if method=='0xa9059cbb':sender=frm;recipient='0x'+b[12:32].hex();amount=int.from_bytes(b[32:64],'big')
 elif method=='0x23b872dd':sender='0x'+b[12:32].hex();recipient='0x'+b[44:64].hex();amount=int.from_bytes(b[64:96],'big');assert frm==CALLER
 else:raise ValueError(method)
 assert sender==r['token_sender'] and recipient==r['recipient'] and amount==int(r['raw_USDC']) and Decimal(amount)/10**6==Decimal(r['USDC']) and frm==r['transaction_caller']
 seen.append({'hash':r['tx_hash'],'block':r['block'],'sender':sender,'recipient':recipient,'caller':frm,'amount_USDC':str(Decimal(amount)/10**6),'method':method})
ins=[r for r in seen if r['sender']==A and r['recipient']==DEP];outs=[r for r in seen if r['sender']==DEP and r['recipient']==HOT]
assert len(ins)==len(outs)==3
assert sum(Decimal(r['amount_USDC']) for r in ins)==sum(Decimal(r['amount_USDC']) for r in outs)==Decimal(80750)
for x in ins:
 y=[r for r in outs if r['amount_USDC']==x['amount_USDC']];assert len(y)==1 and y[0]['block']>x['block']
assert sum(r['method']=='0x23b872dd' for r in outs)==2
checks['kucoin']={'six_inputs_independently_decoded':True,'all_status_success':True,'incoming_and_swept_USDC':'80750','amounts_USDC':['15000','50250','15500'],'kucoin22_transferFrom_count':2,'raw_rpc_receipts_not_available':True}
# Independently decode raw successful RPC Transfer logs and match the claimed facts.
receipts=[]
for name in ['rpc_chain_receipts.json','branch_receipts.json','poison_receipts_drpc.json']:
 for x in json.loads((P/name).read_text()):
  r=x.get('result')
  if isinstance(r,dict) and 'logs' in r:receipts.append((name,r))
logs=[]
for name,r in receipts:
 assert r['status']=='0x1'
 for e in r['logs']:
  if e['address'].lower()==USDC and e['topics'][0]=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef':
   logs.append({'hash':r['transactionHash'].lower(),'from':'0x'+e['topics'][1][-40:],'to':'0x'+e['topics'][2][-40:],'raw':int(e['data'],16),'block':int(r['blockNumber'],16),'source':name})
for e in json.loads((P/'rpc_event_crosschecks.json').read_text()):
 found=[r for r in logs if r['hash']==e['tx_hash'] and r['from']==e['from'] and r['to']==e['to'] and r['raw']==int(e['raw_USDC']) and r['block']==e['block']];assert len(found)==1,e
rpc_facts=json.loads((P/'rpc_event_crosschecks.json').read_text())
kucoin_hashes={r['tx_hash'] for r in s['KuCoin_route']}
assert not kucoin_hashes.intersection(r['tx_hash'] for r in rpc_facts)
checks['raw_rpc']={'independently_matched_USDC_events':6,'all_success':True,'KuCoin_route_events_with_raw_RPC_receipts':0,'scope':'These six checks cover source/intermediary/second-lookalike transfers; none covers the KuCoin route.','events':rpc_facts}
# Entire source-wallet token-history records were collected in the earlier lane.
prior=json.loads((P.parents[1]/'onchain_pass2/ml_origin/all_token_events.json').read_text());usdc=[r for r in prior if r['token']==USDC];assert len(usdc)==11
net=sum(Decimal(r['amount'])*(1 if r['to']==SRC else -1) for r in usdc);assert net==0
july=[r for r in usdc if r['utc'].startswith('2024-07-02')];fund=sum(Decimal(r['amount']) for r in july if r['from']=='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf');out=sum(Decimal(r['amount']) for r in july if r['from']==SRC);poison=sum(Decimal(r['amount']) for r in july if r['to']==SRC and r['from']!='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf');assert fund==Decimal('191393.685754') and poison==20 and out==fund+poison
for r in json.loads((P/'decoded_successful_transfers.json').read_text()):
 if r['source_file'].startswith('poison'):
  h=(P/r['source_file']).read_text();assert inner(h,'data-status')=='Success';assert inner(h,'data-tadd').lower()==USDC;x=inner(h,'rawinput');b=bytes.fromhex(x[10:]);assert x[:10]=='0xa9059cbb' and '0x'+b[12:32].hex()==SRC and int.from_bytes(b[32:64],'big')==10_000_000
checks['source_wallet']={'all_11_event_net_USDC':'0','July2_fundraising_USDC':str(fund),'lookalike_incoming_USDC':str(poison),'outgoing_USDC':str(out),'lookalikes_not_genuine_1991':True}
# MEXC route has exactly2USDC rows within the complete14-token-event history.
r911=json.loads((P/'9118_tokens.json').read_text());m=[r for r in r911 if r['token']==USDC];assert len(r911)==14 and len(m)==2 and {r['tx_hash'] for r in m}=={r['tx_hash'] for r in s['MEXC_route']};assert re.search('A total of 14 txns found',(P/'9118_tokens.html').read_text())
for r in m:assert any(e['hash']==r['tx_hash'] and e['raw']==10_000_000_000 for e in logs)
checks['mexc']={'complete_wallet_rows':14,'USDC_rows':2,'matching_in_and_out_USDC':'10000','both_raw_receipts_matched':True}
# The archive response explicitly forbids an established starting balance.
archive=json.loads((P/'1991_historical_balances.json').read_text());assert any('Archive requests require a personal token' in str(r) for r in archive);assert all(r.get('result') is None for r in archive)
page=json.loads((P/'1991_tokens6.json').read_text());j=[r for r in page if r['token']==USDC and r['from']==A and '2024-07-03'<=r['utc']<'2024-07-17'];assert len(j)==14 and sum(Decimal(r['amount']) for r in j)==Decimal(138550);nin=[r for r in page if r['token']==USDC and r['to']==A and r['utc']>'2024-07-02T13:10:23+00:00'];assert min(r['utc'] for r in nin).startswith('2024-07-18')
checks['1991_commingling']={'starting_balance_unavailable':True,'July3to16_outgoing_USDC':'138550','events':14,'next_incoming_USDC_date':'2024-07-18','exclusive_source_tracing_not_supported':True}
labels=[]
for r in json.loads((P/'explorer_label_records.json').read_text()):
 raw=(P/r['source_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];h=raw.decode();title=re.search(r'<title>(.*?)</title>',h,re.S).group(1);title=re.sub(r'\s+',' ',title).strip();assert title==r['title_excerpt'];labels.append({'address':r['address'],'title':title})
checks['labels']={'all6_title_excerpts_and_hashes_match':True,'labels':labels,'human_identity_not_established':True}
result={'reviewer':'ml_upstream independent peer lane','review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_passed':True,'checks':checks,'network_calls':0}
(P/'independent_peer_checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
