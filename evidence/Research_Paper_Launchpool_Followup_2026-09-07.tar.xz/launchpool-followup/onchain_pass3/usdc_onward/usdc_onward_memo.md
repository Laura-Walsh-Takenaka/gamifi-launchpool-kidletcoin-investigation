# Launchpool connected-wallet USDC continuation — 7 September 2026

Scope: passive Ethereum evidence for the actual USDC receipts at `0x77bfe8d704b1948374bf8dab8328a810b2836e66` (77bf). These are the IAG-reward fundraising contracts identified in the previous pass. This lane does not identify the original Mintlayer BUSD purchase wallets, Laura's signing keys, any personal beneficiary, or a legal entitlement to funds.

## Findings

### 1. A specifically labeled KuCoin deposit address

After 77bf sent 150,010 USDC to `0x1991e27e2908847c0274a662eb6675002e8386d0` (1991) on 2 July 2024, 1991 sent three payments totaling **80,750 USDC** to `0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee` (4d0d). Etherscan labels 4d0d **KuCoin Deposit**. The same exact amounts were forwarded to `0x58edf78281334335effa23101bbe3371b6a36a51`, labeled **KuCoin 20**.

| UTC date | 1991 → 4d0d | 4d0d → KuCoin 20 | Amount USDC |
|---|---|---|---:|
| 2024-07-03 | 15:55:59 | 16:35:47 | 15,000 |
| 2024-07-09 | 09:40:11 | 10:07:11 | 50,250 |
| 2024-07-14 | 13:59:11 | 14:05:59 | 15,500 |

All six transaction detail pages say Success; the decoded USDC calldata matches each table amount and address. The July 3 and July 14 sweeps are `transferFrom(4d0d, KuCoin20, amount)` called by `0xa152f8bb749c55e9943a3a0a3111d18ee2b3f94e`, which Etherscan labels **KuCoin 22**. The July 9 sweep is `transfer` called by 4d0d. This is meaningful deposit-account identification evidence. It does not identify the exchange customer, or mean that 1991 controls the exchange's keys.

1991 was an active wallet with earlier USDC activity. Its historical starting balance was not recovered: Publicnode requires a personal token for archive calls. Therefore the 80,750 USDC is a documented onward branch **after** the 150,010 receipt, not an exclusive-source tracing conclusion assigning every unit to that receipt. Do not describe this as a new fundraising receipt or as Mintlayer investor cash.

### 2. A separate 10,000 USDC route to MEXC

77bf → `0x91187ed207f0adeaa7abd239b64baaa3347105f9` (9118), **10,000 USDC**, 2024-07-02 13:12:59 UTC:
`0x5c51e3116c5092a676717c3d3ab88a913105b9e7a067bc869f5a8d979a505988`

9118 → `0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88`, **10,000 USDC**, 13:19:35 UTC:
`0x8ee2c0d99ff4c71c29fa422a19cdeb560c248d32cbb156c0542e8ff3c7ae7fab`

The endpoint is labeled **MEXC 1** by Ethereum Etherscan and Blockscan. Both USDC transfer logs were independently matched to successful raw RPC receipts. In the retained complete 14-row token history for 9118, these are its only USDC events. Other tokens were not attributed. Exchange deposit/customer mapping remains an appropriate records request; no request was sent.

### 3. The larger branches were already connected

The remaining 31,403.685754 USDC went 77bf → `0x3b4dfd886b2b6802573fcee2a2c0e4c745602eef` at 13:14:59 → `0x78d740c15ec5cf44812ddf2e219331c33a105582` (78d7) at 13:22:11, both 2 July 2024. Both successful raw RPC receipts independently match the explorer logs. The 3b4d history contains five token rows, including exactly these two USDC events.

On **1 July 2024 at 15:39:35 UTC**, one day before the fundraising receipts, 1991 had sent **40,000 USDT** directly to 78d7:
`0x1491f64cb71196109d3389eb0ce5882053da6731bd88275ce6b738f04cbfc757`.
This transfer appears in both independently retrieved address histories. Thus the two larger recipient branches were not previously disconnected addresses. It does not establish common human control. 78d7's subsequent payments mix other balances and tokens; no particular later payment is assigned exclusively to the 31,403.685754 USDC.

### 4. Two lookalike addresses explain the extra 20 USDC

77bf received **191,393.685754 USDC** from the IAG-reward fundraising contract, then sent out **191,413.685754 USDC** across four payments (10 + 150,000 + 10,000 + 31,403.685754). The additional 20 USDC is fully accounted for by two incoming 10 USDC transactions between the initial 10 USDC test and the 150,000 USDC payment:

- `0x19913c5816b014877b2a07071dd7a59619d386d0`, 13:08:23, Etherscan label **Fake_Phishing343404**.
- `0x1991584c19188b5ed676be73e8a4bf846d6686d0`, 13:09:47, Etherscan label **Fake_Phishing345783**.

Their full addresses differ from the genuine 1991 recipient. Both successful transaction pages show real Circle USDC, raw amount **10,000,000** (six decimals), and calldata directed to 77bf. The second also has an independent successful dRPC receipt. The first hash appears in Publicnode's block transaction list at the stated index, while receipt calls returned null/timeouts. The behavior and labels are consistent with address poisoning; these transfers must not be used to infer operator affiliation or fraud by the investigation subjects. The later 150,000 payment went to the genuine original 1991 address.

All 11 retained 77bf USDC event rows, spanning July 2022 and July 2024, reconcile arithmetically to zero. This is event arithmetic, not a newly pinned current balance.

## Other bounded findings / stopping points

- 1991 sent **138,550 USDC in 14 transfers** during July 3–16, before the next incoming USDC row on July 18. Recipients: 4d0d 80,750; `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4` 27,100; `0x2c94c30bdd9aa400df9d2347ee16094ab1858941` 19,200; `0x0008458f168399ee46412c1cff180edf1ec661a7` 11,500. These are subsequent payments, subject to the historical balance limitation above.
- Optional earlier branch: the 236,310.391146 USDC July 2022 payment to `0xeabceada673109ed2f80c1d09f80d4e9a43f1fa7` is its first token-history event in 173 retained rows. Subsequent rows show swaps, including 50,000 USDC exchanged against 2.07294091 WBTC July 30. Protocol identities, purposes and ultimate recipients were not developed in this lane. Do not identify this as personal spending or Mintlayer cash.
- 1991 has 2,533 token rows advertised; only pages 1, 2, 3, 6 and 7 were retained (100 rows each). Page 6 covers the complete June 24–August 6 event interval needed for this inquiry. Parameters attempting a block/token filter were ignored by Etherscan; those responses were recorded and not treated as filtered results. 78d7 has 228 rows advertised; only pages 1 and 2 (200 rows) retained. 4d0d has 128 rows advertised; only its latest 100 retained, sufficient for all July 2024 rows. Those histories are not full lifetime censuses.

## Evidence and method

`usdc_onward_summary.json` contains the relevant events, pairings and exact sums. `decoded_successful_transfers.json` independently decodes six KuCoin route transaction inputs plus the two lookalike transfers from retained transaction pages. `rpc_event_crosschecks.json` matches six real USDC transfer logs to raw RPC receipts. `verify_and_summarize.py` reruns the arithmetic and calldata checks offline; `parse_tables.py` reproduces the explorer-table facts. Request logs preserve exact URLs, UTC retrieval times, response lengths and failures. `SHA256SUMS` covers the lane's files.

No RPC failure was interpreted as zero activity. Archived-state requests required a personal token; later log calls returned 403. No token was acquired and no access restriction was bypassed. dRPC produced a successful second-lookalike receipt, a free-plan timeout for the first, and HTTP 408 on a bounded retry. KuCoin route status and inputs are independently verified from Ethereum Etherscan pages; raw RPC receipt/log verification for that route remains unavailable in this lane.

All exchange names are explorer attributions, not cryptographic human identities. The precise investigative records leads are KuCoin's account mapping for 4d0d and the three July deposits, and MEXC's mapping for 9118 and the July 2 10,000 USDC deposit. Nothing here names Laura as the customer.
