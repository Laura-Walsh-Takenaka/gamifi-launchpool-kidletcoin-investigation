# Original Mintlayer fundraising pools identified and state read

The recovered public Launchpool project configuration identifies BSC contract `0xd975b13cdf91de3aa0e0e888fb827fec3650624a` for Mintlayer Raise 1 (pools19,20,21) and Raise2 (125,126,127). At BSC block120,444,465, 7September2026 06:13:37UTC, its exact recorded raised counters total **903,794.346419582485370326 BUSD**. All six `poolIdToFundsClaimed` flags are true and `owner()` returns `0x77bfe8d704b1948374bf8dab8328a810b2836e66`.

## Recorded pool amounts

| Pool | Raise | Recorded BUSD raised |
|---|---|---:|
|19|1|194,775.268548166718546|
|20|1|195,415.21517867104204|
|21|1|197,226.626562780028172|
|125|2|101,799.763199702252300446|
|126|2|103,426.318782728639320062|
|127|2|111,151.154147533804991818|
|Raise1 total||587,417.110289617788758|
|Raise2 total||316,377.236129964696612326|

All six fundraising-token fields are the exact BSC BUSD contract `0xe9e7cea3dedca5984780bafc599bd69add087d56`. A separately pinned fresh metadata read confirms name BUSD Token, symbol BUSD, decimals18. The first pool field is rewardToken and returns `0x39d3409ef92f6aa942b4b7be006e020b0c758131`, whose getters say Test Binance USD / TBUSD. Do not describe that address as ML. Project attribution comes from the explicit application configuration and matching allocation/staking/funding schedule blocks, corroborated by a historical purchase sample.

All three Raise1 pools have stakingEndBlock13,041,550 and pledgeFundingEndBlock13,125,200; Raise2 uses16,455,000 and16,525,000. These match the recovered project fields. Pool targets total600,000 and399,999.999999BUSD respectively; targets are not added to recorded receipts.

## Independently verified original purchase

The separate peer lane verified successful transaction `0x56ba03b73564c3c110319c4c056230441b58c89a8cdaff071cfe71afc3912da9`: 29November2021 19:02:49UTC, block13,056,994, `fundPledge(21)`. It transferred **59.820643332035352 BUSD** from `0xe5b7c3396ca0b154a80019ccf3fe08f162495e66` into D975 and emitted the matching PledgeFunded event. It also returned LPOOL staking tokens to the caller; that token movement is not a refund of the BUSD contribution. This sample is included within the pool accounting, not an additional amount to add to the903,794.3464 total.

## What remains open

The totals above are the contract's bookkeeping state, not a new independent sum of every investor's transfer. A true claimed flag does not supply the date or recipient of an actual fundraising withdrawal. No D975 historical withdrawal recipient or onward BUSD settlement route was recovered. BscScan public pages returned403, independent Routescan reported chain unsupported, other indexer attempts failed. Historical RPC state returned missing trie node and event retrieval was rejected even for a bounded100-block window; no access controls were bypassed.

The public configuration was read on7September2026 from project records last updated August2024 and February2025. The archived app code identifies its configuration service, but these are not representations that the exact live records are unchanged since2021. Stale Raise2 pricing fields are not used as financial evidence.

D975 runtime is not identical to the archived generic contract: Solidity0.8.0 versus0.6.12, with executable-byte differences even after stripping CBOR metadata. Its retrieved getter interface agrees with the archived ABI, but the generic Ethereum contract's source cannot be imported as proof of D975's withdrawal rules. Source retrieval from Sourcify returned404; its on-chain metadata IPFS gateway attempts also failed. Current owner getter is established; historical custody remains open.

The fresh metadata query reports153pools and an aggregate BUSD balance (exact block and amount in pool_state_summary.json). This is not a segregated Mintlayer reserve, and this analysis assigns no deficit or beneficial ownership from that aggregate balance.

## Evidence

`mintlayer_pools.response`, exact request receipt and map preserve the main pin; block hash `0x534fd73966c873d046e406bf490d6a4a16a6d5aca0dce64a0d0572cac1b82fac`. `token_metadata_fresh.response` and its receipt/head preserve the later metadata pin; the failed older-block metadata query remains as an explicit failed record. `pool_state_summary.json` and sibling `../bsc_validation/` contain independent arithmetic and the successful purchase receipt. `../archived_bsc_contracts/` preserves project configuration provenance and runtime comparison.

The evidence links the later ML operational wallet77bf to current control of the original BSC fundraising contract. It does not identify Laura, a company beneficial owner, a historical cash recipient, or stolen funds.
