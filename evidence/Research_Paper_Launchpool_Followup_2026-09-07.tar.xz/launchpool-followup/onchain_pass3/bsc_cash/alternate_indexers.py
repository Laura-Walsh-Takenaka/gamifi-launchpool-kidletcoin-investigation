from pathlib import Path
import urllib.request,urllib.error,json,datetime,hashlib,concurrent.futures
P=Path(__file__).parent;A='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
J={'routescan_normal':'https://api.routescan.io/v2/network/mainnet/evm/56/etherscan/api?module=account&action=txlist&address='+A+'&startblock=0&endblock=999999999&page=1&offset=100&sort=asc','trustee_address':'https://bsc.trusteeglobal.com/api/v2/address/'+A+'?details=txs&page=1&pageSize=50','github_org':'https://api.github.com/orgs/LaunchpoolXYZ/repos?per_page=100'}
def get(it):
 n,u=it;r={'name':n,'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0','Accept':'application/json'}),timeout=30) as z:
   b=z.read();r.update(status=z.status,sha256=hashlib.sha256(b).hexdigest());(P/(n+'.response')).write_bytes(b);r['preview']=b.decode(errors='replace')[:200]
 except urllib.error.HTTPError as e:r.update(status=e.code,error=str(e))
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:rs=list(ex.map(get,J.items()))
(P/'alternate_requests.json').write_text(json.dumps(rs,indent=2));print(json.dumps(rs,indent=2))
