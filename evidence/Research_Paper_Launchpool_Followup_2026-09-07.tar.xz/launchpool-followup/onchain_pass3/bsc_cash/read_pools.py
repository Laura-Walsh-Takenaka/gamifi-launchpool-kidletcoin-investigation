import pathlib,json,urllib.request,datetime,hashlib,importlib.util
P=pathlib.Path(__file__).parent;R=P.parents[1];spec=importlib.util.spec_from_file_location('v',R/'claims_peer/verify_claims.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
u='https://bsc-dataseed.bnbchain.org';a='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'
def rpc(name,req):
 r={'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':req}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(req).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=40) as z:
   b=z.read();r.update(status=z.status,sha256=hashlib.sha256(b).hexdigest());(P/(name+'.response')).write_bytes(b);x=json.loads(b)
 except Exception as e:r['error']=str(e);x=None
 (P/(name+'.receipt.json')).write_text(json.dumps(r,indent=2));return x
head=rpc('bsc_head',{'jsonrpc':'2.0','id':1,'method':'eth_blockNumber','params':[]})
if not head or not head.get('result'):print(head);raise SystemExit
b=head['result'];qs=[];mp={}
def add(k,m,params):
 i=len(qs)+1;qs.append({'jsonrpc':'2.0','id':i,'method':m,'params':params});mp[str(i)]=k
def call(k,sig,pid=None):
 data='0x'+v.keccak256(sig.encode()).hex()[:8]+('' if pid is None else f'{pid:064x}');add(k,'eth_call',[{'to':a,'data':data},b])
add('block','eth_getBlockByNumber',[b,False]);add('code','eth_getCode',[a,b]);call('owner','owner()');call('poolLength','poolLength()')
for p in [19,20,21,125,126,127]:
 for sig in ['poolInfo(uint256)','poolIdToTotalRaised(uint256)','poolIdToFundsClaimed(uint256)']:call(f'{sig}:{p}',sig,p)
x=rpc('mintlayer_pools',qs);(P/'mintlayer_pool_request_map.json').write_text(json.dumps(mp,indent=2));print('block',int(b,16));print(json.dumps([{mp[str(i['id'])]:i.get('error') or (i.get('result','')[:500] if isinstance(i.get('result'),str) else str(i.get('result'))[:200])} for i in (x or [])],indent=2))
