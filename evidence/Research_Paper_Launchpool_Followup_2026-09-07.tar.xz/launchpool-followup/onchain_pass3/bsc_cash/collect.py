from pathlib import Path
import urllib.request,urllib.error,json,datetime,hashlib,concurrent.futures
P=Path(__file__).parent
A='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
jobs={'address':'https://bscscan.com/address/'+A,'normal_p1':'https://bscscan.com/txs?a='+A+'&ps=100&p=1','tokens_p1':'https://bscscan.com/tokentxns?a='+A+'&p=1'}
def get(x):
 n,u=x;r={'name':n,'url':u,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0'}),timeout=40) as z:
   b=z.read();r.update(status=z.status,headers=dict(z.headers),sha256=hashlib.sha256(b).hexdigest());(P/(n+'.html')).write_bytes(b)
 except urllib.error.HTTPError as e:r.update(status=e.code,error=str(e),headers=dict(e.headers))
 except Exception as e:r['error']=str(e)
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:rs=list(ex.map(get,jobs.items()))
(P/'initial_requests.json').write_text(json.dumps(rs,indent=2));print(json.dumps([{k:r[k] for k in ['name','status','error'] if k in r} for r in rs]))
