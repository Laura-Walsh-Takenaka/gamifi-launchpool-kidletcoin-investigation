import pathlib,json,urllib.request,datetime,hashlib
P=pathlib.Path(__file__).parent;contract='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';busd='0xe9e7cea3dedca5984780bafc599bd69add087d56';reward='0x39d3409ef92f6aa942b4b7be006e020b0c758131';b=None;u='https://bsc-dataseed.bnbchain.org'
specs=[('busd_decimals',busd,'0x313ce567'),('busd_symbol',busd,'0x95d89b41'),('busd_name',busd,'0x06fdde03'),('contract_busd_balance',busd,'0x70a08231'+contract[2:].zfill(64)),('numberOfPools',contract,'0x6f682a53'),('reward_symbol',reward,'0x95d89b41'),('reward_name',reward,'0x06fdde03'),('reward_decimals',reward,'0x313ce567')]
head_request={'jsonrpc':'2.0','id':99,'method':'eth_blockNumber','params':[]}
with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(head_request).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=25) as z:
 head_bytes=z.read();head=json.loads(head_bytes);b=head['result']
(P/'token_metadata_head.json').write_text(json.dumps({'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':head_request,'response':head},indent=2))
q=[{'jsonrpc':'2.0','id':i+1,'method':'eth_call','params':[{'to':a,'data':d},b]} for i,(_,a,d) in enumerate(specs)];r={'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':q,'names':[x[0] for x in specs]}
try:
 with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(q).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=35) as z:
  raw=z.read();r.update(status=z.status,sha256=hashlib.sha256(raw).hexdigest());(P/'token_metadata_fresh.response').write_bytes(raw);x=json.loads(raw);print(json.dumps(x))
except Exception as e:r['error']=str(e);print(r['error'])
(P/'token_metadata_fresh.receipt.json').write_text(json.dumps(r,indent=2))
