from pathlib import Path
import urllib.request,urllib.error,json,datetime,hashlib,concurrent.futures,decimal
P=Path(__file__).parent;D=decimal.Decimal;decimal.getcontext().prec=90;a='0xD975B13CDF91de3AA0e0E888fb827Fec3650624A'
J={'sourcify_full':'https://repo.sourcify.dev/contracts/full_match/56/'+a+'/metadata.json','sourcify_partial':'https://repo.sourcify.dev/contracts/partial_match/56/'+a+'/metadata.json'}
def get(it):
 n,u=it;r={'name':n,'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0'}),timeout=35) as z:
   b=z.read();r.update(status=z.status,sha256=hashlib.sha256(b).hexdigest());(P/(n+'.response')).write_bytes(b)
 except urllib.error.HTTPError as e:r.update(status=e.code,error=str(e))
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:rs=list(ex.map(get,J.items()))
(P/'source_requests.json').write_text(json.dumps(rs,indent=2));print(rs)
mp=json.loads((P/'mintlayer_pool_request_map.json').read_text());r={mp[str(x['id'])]:x for x in json.loads((P/'mintlayer_pools.response').read_text())};pools=[]
for pid in [19,20,21,125,126,127]:
 x=r[f'poolInfo(uint256):{pid}']['result'][2:];ws=[x[i:i+64] for i in range(0,len(x),64)];assert len(ws)==7
 q={'pool_id':pid,'reward_token':'0x'+ws[0][-40:],'fundraising_token':'0x'+ws[1][-40:],'tokenAllocationStartBlock':int(ws[2],16),'stakingEndBlock':int(ws[3],16),'pledgeFundingEndBlock':int(ws[4],16),'targetRaise_base_units':str(int(ws[5],16)),'targetRaise_assuming18':str(D(int(ws[5],16))/D(10**18)),'totalRaised_base_units':str(int(r[f'poolIdToTotalRaised(uint256):{pid}']['result'],16)),'fundsClaimed':bool(int(r[f'poolIdToFundsClaimed(uint256):{pid}']['result'],16))};q['totalRaised_assuming18']=str(D(q['totalRaised_base_units'])/D(10**18));pools.append(q)
block=r['block']['result'];out={'block':int(block['number'],16),'block_hash':block['hash'],'block_utc':datetime.datetime.fromtimestamp(int(block['timestamp'],16),datetime.timezone.utc).isoformat(),'owner':'0x'+r['owner']['result'][-40:],'pools':pools,'raise1_recorded_total_assuming18':str(sum(D(x['totalRaised_assuming18']) for x in pools[:3])),'raise2_recorded_total_assuming18':str(sum(D(x['totalRaised_assuming18']) for x in pools[3:])),'limits':['Bookkeeping getters, not independently traced cash withdrawals.','Decimals/tokenidentity pending directquery.','ABI matched archived app fields; no verifiedD975source retrievedyet.','poolLength() reverted; no fullpoolcensus.']}
(P/'pool_state_summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
