from pathlib import Path
import urllib.request,urllib.error,json,datetime,hashlib,sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'));from verify_claims import keccak256
URL='https://ethereum-rpc.publicnode.com';ML='0x059956483753947536204e89bfad909e1a434cc6'
root='77a75906dcc9ee5d36448bd70c5afa911633a120f42cc21936560be1b4812995'
block=json.loads((P.parent/'old_ml_contract/rpc_head.json').read_text())['result']['number']
def sel(s):return keccak256(s.encode()).hex()[:8]
calls=[]
for n,call in [('rootURI',sel('mapRootURIs(bytes32)')+root),('root_valid',sel('rootWhitelist(bytes32)')+root),('vestingStart',sel('VESTING_START_TIMESTAMP()'))]:calls.append({'jsonrpc':'2.0','id':n,'method':'eth_call','params':[{'to':ML,'data':'0x'+call},block]})
for n,addr in [('a594','0xa594af6496a61423582b19319732e3c7dc072f9f'),('dd923','0xdd923ff5961796b3005ee0d964d154ad08bd3695'),('3b883','0x3b883762d4a5af23e76ef463f86aad0db1610061'),('752d11','0x752d11a9be19cc9f1f06b33c9dcb99e375b62562')]:
 calls.append({'jsonrpc':'2.0','id':n+'_balance','method':'eth_call','params':[{'to':ML,'data':'0x'+sel('balanceOf(address)')+addr[2:].zfill(64)},block]})
 calls.append({'jsonrpc':'2.0','id':n+'_treasurer','method':'eth_call','params':[{'to':ML,'data':'0x'+sel('isTreasurer(address)')+addr[2:].zfill(64)},block]})
calls.append({'jsonrpc':'2.0','id':'ML_creation','method':'eth_getTransactionByHash','params':['0x750ec78b94893da83f68314bbe0b5d310792e3208823ff1dd9c7386bcd3cb60c']})
rec={'url':URL,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':calls,'block':block}
try:
 r=urllib.request.urlopen(urllib.request.Request(URL,data=json.dumps(calls).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=40);b=r.read();rec.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());(P/'rpc_state_raw.json').write_bytes(b);print(b.decode()[:800])
except Exception as e:rec['error']=str(e);print(e)
(P/'rpc_receipt.json').write_text(json.dumps(rec,indent=2))
