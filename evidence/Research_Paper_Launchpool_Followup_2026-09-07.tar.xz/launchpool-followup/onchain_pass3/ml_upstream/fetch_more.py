from pathlib import Path
import urllib.request,urllib.error,json,datetime,hashlib,sys
P=Path(__file__).resolve().parent
TASKS=json.loads(Path(sys.argv[1]).read_text()); receipts=[]
for n,u in TASKS:
 rec={'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  r=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0'}),timeout=35); data=r.read();rec.update(status=r.status,headers=dict(r.headers),file=n,sha256=hashlib.sha256(data).hexdigest());(P/n).write_bytes(data)
 except urllib.error.HTTPError as e:rec.update(status=e.code,headers=dict(e.headers),error=str(e))
 except Exception as e:rec['error']=str(e)
 receipts.append(rec);print(n,rec.get('status'),rec.get('error'),flush=True)
(P/sys.argv[2]).write_text(json.dumps(receipts,indent=2))
