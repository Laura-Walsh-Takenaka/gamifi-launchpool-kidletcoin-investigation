from pathlib import Path
import urllib.request,json,datetime,hashlib,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P.parents[1]/'claims_peer'));from verify_claims import keccak256
url='https://ethereum-rpc.publicnode.com';root='0x77a75906dcc9ee5d36448bd70c5afa911633a120f42cc21936560be1b4812995';topic='0x'+keccak256(b'AddedRoot(bytes32)').hex()
calls=[{'jsonrpc':'2.0','id':i,'method':'eth_getLogs','params':[{'address':'0x059956483753947536204e89bfad909e1a434cc6','fromBlock':hex(a),'toBlock':hex(b),'topics':[topic,root]}]} for i,(a,b) in enumerate([(16874225,16899999),(16900000,16925578)])]
rec={'url':url,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':calls}
try:
 r=urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(calls).encode(),headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'}),timeout=40);b=r.read();rec.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());(P/'root_added_logs.json').write_bytes(b);print(b.decode()[:2000])
except Exception as e:rec['error']=str(e);print(e)
(P/'root_added_receipt.json').write_text(json.dumps(rec,indent=2))
