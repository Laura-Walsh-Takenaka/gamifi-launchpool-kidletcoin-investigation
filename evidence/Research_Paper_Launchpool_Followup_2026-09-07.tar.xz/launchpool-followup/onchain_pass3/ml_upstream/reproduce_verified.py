"""Offline arithmetic and Merkle-proof reproduction from preserved factual records."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,sys,datetime,collections
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
getcontext().prec=100;s=json.loads((P/'verified_upstream.json').read_text());checks=[]
for n,d in s['wallets'].items():
 balance=0;ins=outs=0
 for r in d['events']:
  units=Decimal(r['amount'])*10**18;assert units==units.to_integral_value();units=int(units);assert units==int(r['raw_amount'])
  if r['to']==d['address']:balance+=units;ins+=units
  if r['from']==d['address']:balance-=units;outs+=units
  assert balance>=0
 assert balance==0 and Decimal(ins)/10**18==Decimal(d['gross_in_ML']) and Decimal(outs)/10**18==Decimal(d['gross_out_ML'])
 checks.append(n+':exact flow arithmetic passed')
for p in s['sample_proofs']:
 # Decode single schedule or the matching beneficiary/amount/cliff in batch.
 x=p['input'];b=bytes.fromhex(x[10:]);word=lambda pos:int.from_bytes(b[pos:pos+32],'big')
 if x[:10]=='0x3d1851c4':starts=[0];root=b[96:128]
 else:
  assert x[:10]=='0x2790100c';root=b[32:64];array=word(0);starts=[array+32+word(array+32+i*32) for i in range(word(array))]
 found=False
 for at in starts:
  addr=b[at+12:at+32];amount=word(at+32);cliff=word(at+64)
  if '0x'+addr.hex()!=p['beneficiary'] or cliff!=p['cliff_seconds'] or Decimal(amount)/10**18!=Decimal(p['amount_ML']):continue
  off=word(at+(128 if x[:10]=='0x3d1851c4' else 96))+at;num=word(off);leaf=keccak256(addr+amount.to_bytes(32,'big')+cliff.to_bytes(32,'big'));node=leaf
  for i in range(num):other=b[off+32+i*32:off+64+i*32];node=keccak256(min(node,other)+max(node,other))
  assert node==root and '0x'+root.hex()==p['root'] and '0x'+leaf.hex()==p['leaf'];found=True
 assert found,p['source_file'];checks.append(p['source_file']+':decoded proof passed')
rpc={r['id']:r['result'] for r in json.loads((P/'rpc_state_raw.json').read_text())}
for n in s['wallets']:assert int(rpc[n+'_balance'],16)==0
result={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_passed':True,'checks':checks,'note':'This verifies retained factual records and calldata, not independent fresh network completeness or human attribution.'}
(P/'offline_reproduction.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
