# ML upstream origin — third bounded pass

**New finding:** the first 683,000 ML funding of the older operational wallet `0x77bf...6e66` on 21 March 2023 can now be traced through two beneficiaries of the ML token's original vesting tree. Three wallets in this immediate upstream network received a combined **11,029,411.76470584 ML directly from the ML token contract through vesting releases**. This is upstream token distribution, not a newly discovered cash raise or evidence of personal receipt by Laura.

The same source wallet `0xa594...2f9f` also received **1,666,023.139484 USDC** from Launchpool's earlier fundraising-contract owner during June–October 2021. A sibling lane independently matched those four dated totals to fundraising withdrawals. This is a historical operational connection between the fundraising wallets and the later ML supply route. It does not assign their signing keys to a named person.

## 1. TGE-day origin of the first 683,000 ML

All times UTC on 21 March 2023; exact token `0x059956483753947536204e89bfad909e1a434cc6` (18 decimals).

| Time | Movement | ML | Transaction |
|---|---|---:|---|
| 13:25:59 | ML token contract → 3b883 | 420,168.067226891 | `0xc0f26f891208071f0ec45718d39af0b46efa86dddb08862c81aa9d3bf6d0e0bf` |
| 13:27:11 | 3b883 → dd923 | 1 | `0x51dbd8309a95e5aa3a6c8bb6530416960d2a12e6ad41e3aad25de47679e5e971` |
| 13:27:59 | ML token contract → 752d11 | 525,210.084033613 | `0x17a02d62251b6b73f93babc1dfcea2b4ec6db20d2a662ffd9e9b75545cb337b4` |
| 13:29:59 | 752d11 → dd923 | 525,210.084033613 | `0xf0108e7421986ee60674330640cb1663a690aca73a9e459ddcbb6f582c27804e` |
| 13:32:11 | 3b883 → dd923 | 227,940.177 | `0xecaa8091b8c582298190714764fd913be9da93b18078abd8a76c659c1223b09b` |
| 13:33:47 | dd923 → 77bf | 683,000 | `0x06293db7ae63be6e47d9159c875d0ba0bd7a4b0c978f4770277c12699b0eb22e` |

The first releases to 3b883 and 752d11 are successful `releaseVested` calls. Both decoded Merkle proofs independently calculate the original constructor root:

`0x8d83bb97927b5a92ed5a305064b6b27ac91b75e65c827d268ae31c78e3530014`.

The source of the 683,000 ML is therefore explained at the level of account balance origins. Fungible units are not individually earmarked, and the transfer does not identify a beneficial owner or payment purpose beyond the observed route.

## 2. Complete ML ledgers for four upstream wallets

| Address | Direct ML vesting receipts | Observed release pattern | ML balance at block 25,923,590 |
|---|---:|---|---:|
| `0x3b883762d4a5af23e76ef463f86aad0db1610061` | 4,201,680.67226891 | 420,168.067226891 once; 252,100.8403361346 fifteen times | 0 |
| `0x752d11a9be19cc9f1f06b33c9dcb99e375b62562` | 5,252,100.84033613 | 525,210.084033613 once; 315,126.0504201678 fifteen times | 0 |
| `0xdd923ff5961796b3005ee0d964d154ad08bd3695` | 1,575,630.2521008 | 157,563.02521008 once; 94,537.815126048 fifteen times | 0 |
| `0xa594af6496a61423582b19319732e3c7dc072f9f` | 0 direct from the token contract | Receives and forwards ML from other wallets | 0 |

Each of the three direct-release patterns totals an initial 10% plus fifteen 6% amounts. These are observed amounts, not an assertion about off-chain purchase prices, contracts or investor identities. Do not sum the inter-wallet throughput with direct issuance as though it were an additional token allocation.

The retained ML token's verified source mints the initial supply to itself, validates the vesting root/proof and cliff, records the claimed leaf and transfers tokens from itself to the beneficiary. It excludes authorized treasurer addresses from ordinary vesting release. The source contains no setter for its constructor-established treasurer mapping. All four addresses returned `false` for `isTreasurer` at the pinned block; none is thereby established as a Mintlayer corporate treasurer. Calling a release for a beneficiary is permissionless under the source and does not itself establish that the caller owns the beneficiary.

The separately decoded dd923 schedules use root:

`0x77a75906dcc9ee5d36448bd70c5afa911633a120f42cc21936560be1b4812995`.

That root returned whitelisted status `true`. Initial, batch, mid-period and final release calldata samples supply **seven proof-valid schedules** across both roots. The two equal 94,537.815126048 ML rows in transaction `0x7a8e97e21ed75b312b9e2e89195a79f74b30a85c986aad9ee2c58a25fcf8cbdc` are two separate schedules in one `batchReleaseVested` transaction. They are not a duplicate transaction mistakenly counted twice.

Current-state snapshot: Ethereum block **25,923,590**, **7 September 2026 06:09:11 UTC**, hash `0x0cd658148b97788ccdb8b5148ee49643e77c20134c1f9860870c0006f87fdd61`. Exact running balances for every retrieved ML event reconcile to the independently obtained RPC zero balances for all four accounts.

## 3. Immediate funding routes into 77bf

Source A (a594) received **5,843,226.8735352352 ML**, and forwarded exactly that amount: **5,472,201.6735352352 ML to 77bf in ten events**, plus **371,025.2 ML to dd923** on 23 May 2023. Source B (dd923) sent **2,499,173.893134413 ML to 77bf in ten events**. The 371,025.2 ML route is inter-wallet throughput and must not be counted as new issuance.

Both source A and source B receive ML from the original-vesting beneficiaries 3b883 and 752d11. Other a594 incoming counterparties are b3e71, d58ed and 3fedc; their full histories were not expanded in this bounded pass. The complete factual ledgers and aggregated source/destination amounts are in `verified_upstream.json`, `a594_summary.json`, `dd923_summary.json`, `source_3b883_summary.json` and `source_752d11_summary.json`.

Both 3b883 and 752d11 explorer address pages identify `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4` as the first gas funder. Their displayed normal transaction history also contains later ETH returns to that address. The ML ledgers independently show 3b883, 752d11 and dd923 sending ML to it. This is a shared-counterparty lead; no human control is inferred. Its history was not expanded by this lane.

## 4. A 2021 connection to the fundraising operator

Earlier fundraising owner `0xdb7d1459ddce7887266f25de31f090ff0eafea6c` sent the following exact USDC pairs to a594:

| Date UTC | Pair of receipts | Daily USDC total |
|---|---|---:|
| 23 June 2021 | 10 + 459,678.01123 | 459,688.01123 |
| 5 August 2021 | 10 + 445,759.39127 | 445,769.39127 |
| 14 September 2021 | 10 + 372,963.160577 | 372,973.160577 |
| 1 October 2021 | 10 + 387,582.576407 | 387,592.576407 |
| **Total** | **Eight transfers** | **1,666,023.139484** |

The full a594 ledger also shows multiple project tokens sent back to db7d, including **7,655,747.432 IAG** on 28 July 2021. This token identity is the same exact IAGON address used in the earlier pool analysis; its trace should be read with the sibling pool-specific findings. See `db7d_a594_crosslinks.json` for all twenty token events between these wallets and `../fundraising_control/` for the independent fundraising-pool reconciliation. These are separate historical project receipts, not a finding that Mintlayer investors paid that USDC sum or that it is missing.

The full a594 token history shows no additional USDC receipts from db7d on the three other dates suggested by the sibling lane (26 July, 2 August and 29 November 2021). This is an exact wallet/token/date observation, not a conclusion about the other fundraising withdrawals.

## 5. Coverage, preservation and limits

- a594: all **164** indexed token events across four pages; **30** exact ML events.
- dd923: latest **50** of 2,198 lifetime token events, containing **37** ML events. The page reaches back to block **16,684,985**, before ML was deployed at block **16,874,225**. Thus all expected ML-era rows are covered without downloading the other 43 pages of unrelated older token history.
- 3b883: all **88** indexed token events across two pages; all ML.
- 752d11: all **52** indexed token events across two pages; all ML.
- No outgoing self-transfer or negative running ML balance was found. The DD batch's two same-transaction transfer events are preserved and decoded correctly.
- Etherscan rows provide exact amounts from full-precision tooltips. Explorer HTML is the census source; pinned Ethereum RPC independently verifies current balances, token creation block, root whitelist and URI. This is not a second independent full-history census.
- `mapRootURIs` returned `ipfs://bafybeihilvxn57ai4pfndwlca7pamcy7gapityx3q5wdfgsagicdky4464/vestingTree_data.json` for the later root. A public gateway fetch returned HTTP 403; the tree content was not recovered. A bounded RPC query for the root's `AddedRoot` event also returned HTTP 403. Neither route was retried. The account that registered the later tree and any names in its published data remain open.
- The ordinary generic token-transfer endpoint returned a page-level error despite HTTP 200; it was not treated as successful evidence. All actual census rows came from the ordinary `/tokentxns` pages. An attempted holder page was read, but its balance is not substituted for pinned RPC state.
- Exact-address web searches found token rich-list entries and unrelated token/NFT references, but no primary source identifying a human operator. Secondary rich lists were not used to assign ownership.

**Reproduction:** `python reproduce_verified.py` verifies the preserved factual ledgers, full-precision base-unit arithmetic, pinned RPC zero balances and all seven decoded Merkle proofs without requiring retained third-party HTML. It passed. `verify_upstream.py` can rebuild the factual records from the retained HTML in the working evidence directory. Requests, URLs, capture times and SHA-256 values are retained in `requests1.json`–`requests7.json`, `rpc_receipt.json`, and `root_added_receipt.json`.

**Custody conclusion:** this pass closes an upstream ML origin gap and connects the later token supply network to an older fundraising operator. It establishes wallet roles and transactions. It identifies no Laura-controlled signing key, personal exchange account, personal ML receipt, or automatic November 2026 payment to Laura. The currently funded distributor and its owner-withdrawal behavior remain a separate, already documented custody question.
