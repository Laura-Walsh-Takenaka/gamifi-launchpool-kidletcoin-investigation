from pathlib import Path
import urllib.request,urllib.error,json,datetime,hashlib
P=Path(__file__).resolve().parent
TASKS=[('a594_tokens1','https://etherscan.io/tokentxns?a=0xa594af6496a61423582b19319732e3c7dc072f9f&p=1'),('dd923_tokens1','https://etherscan.io/tokentxns?a=0xdd923ff5961796b3005ee0d964d154ad08bd3695&p=1')]
receipts=[]
for n,u in TASKS:
 rec={'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  r=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0'}),timeout=35); data=r.read();rec.update(status=r.status,headers=dict(r.headers),file=n+'.html',sha256=hashlib.sha256(data).hexdigest());(P/(n+'.html')).write_bytes(data)
 except urllib.error.HTTPError as e:rec.update(status=e.code,headers=dict(e.headers),error=str(e))
 except Exception as e:rec['error']=str(e)
 receipts.append(rec);print(n,rec.get('status'),rec.get('error'),flush=True)
(P/'requests1.json').write_text(json.dumps(receipts,indent=2))
