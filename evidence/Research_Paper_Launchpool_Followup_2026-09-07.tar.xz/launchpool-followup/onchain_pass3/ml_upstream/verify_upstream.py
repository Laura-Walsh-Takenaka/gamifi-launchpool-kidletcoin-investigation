from pathlib import Path
from decimal import Decimal,getcontext
import re,json,sys,hashlib,contextlib,io,collections,datetime
P=Path(__file__).resolve().parent;getcontext().prec=100
sys.path.insert(0,str(P));sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
with contextlib.redirect_stdout(io.StringIO()):import analyze
ML=analyze.ML; wallets={'a594':analyze.A,'dd923':analyze.B,'3b883':'0x3b883762d4a5af23e76ef463f86aad0db1610061','752d11':'0x752d11a9be19cc9f1f06b33c9dcb99e375b62562'}
out={'scope':'Ethereum exact ML token '+ML,'wallets':{},'sample_proofs':[]}
for name,addr in wallets.items():
 paths=sorted(P.glob((name if name in ['a594','dd923'] else 'source_'+name)+'_tokens*.html'));rows=sum([analyze.parse(p) for p in paths],[]);events=[r for r in rows if r['token']==ML]
 balance=0;grossin=grossout=0
 for r in sorted(events,key=lambda r:(r['block'],r['source_file'],-r['ordinal'])):
  raw=Decimal(r['amount'])*10**18;assert raw==raw.to_integral_value();raw=int(raw);r['raw_amount']=str(raw)
  if r['to']==addr:balance+=raw;grossin+=raw
  if r['from']==addr:balance-=raw;grossout+=raw
  r['running_ML']=str(Decimal(balance)/10**18)
  assert balance>=0,(name,r)
 assert balance==0,(name,balance)
 d={'address':addr,'all_rows':len(rows),'ML_rows':len(events),'gross_in_ML':str(Decimal(grossin)/10**18),'gross_out_ML':str(Decimal(grossout)/10**18),'net_ML':'0','source_files':[p.name for p in paths]}
 releases=[r for r in events if r['from']==ML]
 if releases:
  amounts=collections.Counter(r['amount'] for r in releases);amounts={k:v for k,v in amounts.items()};d['release_events']=len(releases);d['release_amounts']=amounts;d['released_total_ML']=str(sum(Decimal(r['amount']) for r in releases));assert len(releases)==16 and sorted(amounts.values())==[1,15]
  initial=next(Decimal(k) for k,v in amounts.items() if v==1);monthly=next(Decimal(k) for k,v in amounts.items() if v==15);assert monthly==initial*Decimal('0.6');assert initial*10==sum(Decimal(r['amount']) for r in releases)
 d['events']=sorted(events,key=lambda r:(r['block'],-r['ordinal']));out['wallets'][name]=d

def verify(name):
 s=(P/(name+'.html')).read_text();matches=re.findall(r'0x[0-9a-fA-F]{400,}',s);x=matches[0];payload=bytes.fromhex(x[10:]);word=lambda i:int.from_bytes(payload[i:i+32],'big')
 schedules=[]
 if x[:10]=='0x3d1851c4':
  root=payload[96:128];off=word(128);n=word(off);schedules=[(payload[12:32],word(32),word(64),[payload[off+32+i*32:off+64+i*32] for i in range(n)])]
 elif x[:10]=='0x2790100c':
  root=payload[32:64];base=word(0);n=word(base)
  for i in range(n):
   tup=base+32+word(base+32+i*32);proofpos=tup+word(tup+96);m=word(proofpos)
   schedules.append((payload[tup+12:tup+32],word(tup+32),word(tup+64),[payload[proofpos+32+j*32:proofpos+64+j*32] for j in range(m)]))
 else:raise ValueError(x[:10])
 for addr,amount,cliff,proof in schedules:
  node=keccak256(addr+amount.to_bytes(32,'big')+cliff.to_bytes(32,'big'));leaf=node
  for sibling in proof:node=keccak256(min(node,sibling)+max(node,sibling))
  assert node==root,(name,addr.hex());out['sample_proofs'].append({'source_file':name+'.html','selector':x[:10],'beneficiary':'0x'+addr.hex(),'amount_ML':str(Decimal(amount)/10**18),'cliff_seconds':cliff,'cliff_days':str(Decimal(cliff)/86400),'root':'0x'+root.hex(),'leaf':'0x'+leaf.hex(),'proof_length':len(proof),'proof_valid':True,'input':x})
for n in ['initial_vesting_release','batch_vesting_release','release_first','last_vesting_release','source_3b883_first_release','source_752d11_first_release']:verify(n)
raw=json.loads((P/'rpc_state_raw.json').read_text());byid={r['id']:r['result'] for r in raw};block=json.loads((P/'rpc_receipt.json').read_text())['block'];head=json.loads((P.parent/'old_ml_contract/rpc_head.json').read_text())['result'];assert head['number']==block
out['state_block']={'number':int(block,16),'hash':head['hash'],'utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat()}
for name in wallets:assert int(byid[name+'_balance'],16)==0;assert int(byid[name+'_treasurer'],16)==0
out['ML_creation_block']=int(byid['ML_creation']['blockNumber'],16)
oldest=min(r['block'] for r in analyze.parse(P/'dd923_tokens1.html'));assert oldest<out['ML_creation_block'];out['dd923_first_page_covers_token_lifetime']={'oldest_token_row_block':oldest,'ML_creation_block':out['ML_creation_block'],'passes':True}
constructor=json.loads((P.parents[1]/'laura_thread/migration_mechanics/ml_token_source.json').read_text())['result'][0]['ConstructorArguments'];cb=bytes.fromhex(constructor[2:]);out['initial_root']='0x'+cb[128:160].hex();assert out['initial_root']==out['sample_proofs'][-1]['root']==out['sample_proofs'][-2]['root']
(P/'verified_upstream.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['wallets','sample_proofs']},indent=2));print('Verified:',len(out['sample_proofs']),'Merkle schedules; all4wallet MLledgers zero and match RPC.')
