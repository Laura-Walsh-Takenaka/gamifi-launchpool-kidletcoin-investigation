from pathlib import Path
from decimal import Decimal,getcontext
import re,json,html,datetime,collections
getcontext().prec=100
P=Path(__file__).resolve().parent;ML='0x059956483753947536204e89bfad909e1a434cc6';A='0xa594af6496a61423582b19319732e3c7dc072f9f';B='0xdd923ff5961796b3005ee0d964d154ad08bd3695'
def text(s):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>',' ',s))).strip()
def parse(p):
 rows=[];s=p.read_text()
 for ordinal,row in enumerate(re.findall(r'<tr\b[^>]*>(.*?)</tr>',s,re.S)):
  tx=re.search(r'/tx/(0x[0-9a-fA-F]{64})',row)
  if not tx:continue
  addresses=re.findall(r'data-clipboard-text=[\'\"](0x[0-9a-fA-F]{40})[\'\"]',row);token=re.search(r'/token/(0x[0-9a-fA-F]{40})',row);amount=re.search(r'class="td_showAmount"[^>]*data-bs-title="([^"]+)"',row);stamp=re.search(r'class=[\'\"]showLocalDate[^>]*>(.*?)</td>',row,re.S);block=re.search(r'/block/(\d+)',row);method=re.search(r'data-title="([^"]+)"',row)
  assert len(addresses)==2 and token and amount and stamp and block,(p,ordinal)
  ts=int(text(stamp.group(1)));dec=amount.group(1).split('|')[0].strip().replace(',','')
  rows.append({'source_file':p.name,'ordinal':ordinal,'tx_hash':tx.group(1).lower(),'block':int(block.group(1)),'timestamp':ts,'utc':datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat(),'from':addresses[0].lower(),'to':addresses[1].lower(),'token':token.group(1).lower(),'amount':dec,'method_label':html.unescape(method.group(1)) if method else ''})
 return rows
allrows=[]
for n,addr in [('a594',A),('dd923',B)]:
 rows=[]
 for p in sorted(P.glob(n+'_tokens*.html')):rows+=parse(p)
 ml=[r for r in rows if r['token']==ML]
 raw=lambda r:int(Decimal(r['amount'])*10**18)
 summary={'all_rows':len(rows),'ml_rows':len(ml),'incoming':{},'outgoing':{}}
 for r in ml:
  direction='incoming' if r['to']==addr else 'outgoing';counter=r['from'] if direction=='incoming' else r['to'];d=summary[direction].setdefault(counter,{'events':0,'raw':0});d['events']+=1;d['raw']+=raw(r)
 for d in list(summary['incoming'].values())+list(summary['outgoing'].values()):d['ML']=str(Decimal(d.pop('raw'))/10**18)
 summary['events']=sorted(ml,key=lambda r:(r['block'],-r['ordinal']))
 (P/(n+'_summary.json')).write_text(json.dumps(summary,indent=2));allrows+=rows
 print(n,json.dumps(summary,indent=2))
(P/'parsed_all_tokens.json').write_text(json.dumps(allrows,indent=2))
