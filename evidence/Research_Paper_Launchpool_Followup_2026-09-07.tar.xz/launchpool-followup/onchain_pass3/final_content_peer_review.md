# Final content peer review — sections 9.11–9.14 and sources F32–F38

Reviewed 7 September 2026 UTC from `onchain_pass3_content.py`, the lane memos, decoded state and transaction records, and the retained independent reviews. No new network requests or edits to the master report.

**Final disposition: PASS. The one narrow attribution wording correction identified below was applied by the root agent before finalization. No numerical or source-reference errors found.**

## Actionable correction

In section 9.14, replace:

> No examined contract creates an automatic 1 November 2026 payment to her.

With:

> The examined evidence establishes no automatic 1 November 2026 payment to Laura.

Reason: the former sentence applies categorically to every examined contract, including D975, whose complete source and historical withdrawal mechanics remain unrecovered. The replacement states the supported evidentiary conclusion and preserves the existing final-distributor findings.

## Checked and passed

- **Section 9.11:** All six BUSD pool values, both subtotals, the combined **903,794.346419582485370326 BUSD**, the true claimed flags, the owner address and pinned block/time agree with independently decoded state. Current control is not retroactively assigned to historical withdrawals. The text correctly separates recorded counters from an independently aggregated purchase ledger and does not characterize the amount as missing or stolen. The current project-record provenance and TBUSD placeholder are explicit. The single **59.820643332035352 BUSD** purchase matches the raw successful receipt and pool-21 event. The same receipt contains an outgoing transfer of the distinct LPOOL token, supporting the stated staking-token return rather than a BUSD refund.
- **Section 9.12:** The old funding, 236 successful payments, owner return and zero remainder reproduce exactly. The failed claim is excluded; the recipient-status split and **143,732.0324654474325 ML** final allocation figure agree with retained records. The tranche-13 mapping is correct. Runtime claims are appropriately limited to the selected bytecode path, stored values and read-only simulations; the complete source remains unverified. All three direct vesting receipt totals and combined **11,029,411.76470584 ML** agree with the upstream memo and arithmetic. The seven sampled schedule proofs are not misrepresented as a full published-tree recovery.
- **Section 9.13:** Deployment and ownership-transfer timestamps, all receipt totals, the 21-pool census, the exact archived Ethereum runtime match and BSC mismatch agree with preserved data. Four dated owner receipts match eight later a594 payments totaling **1,666,023.139484 USDC**. The text correctly calls this an operational relationship while preserving commingling and human-attribution limitations. The matched onward sum is not counted as additional fundraising.
- **Section 9.14:** All three KuCoin-route pairs sum to **80,750 USDC** on each side. The six explorer transaction records and the two KuCoin-22 transferFrom callers are accurately described. The section does not imply successful raw RPC verification of these six records. The two MEXC transfers are separately supported by successful RPC receipts. The **191,393.685754 / 191,413.685754 USDC** difference and the two separate 10-USDC receipts are correct. The text excludes the lookalike addresses from operator attribution. Historical starting-balance and exchange-customer identity gaps remain explicit.
- **Source references:** F32–F38 correspond to the appropriate retained lanes. F30 correctly supports the retained **05:45:47 UTC** final-distributor snapshot, and the text correctly states that this pass did not refresh it again. F38 explicitly says KuCoin raw RPC receipts were unavailable, preventing confusion with the separate successful MEXC checks. The Ethereum ownership-handover transaction in F37 and original purchase transaction in F34 match the evidence.

## Boundaries retained correctly

The new material does not identify Laura as a private-key holder, exchange customer or personal recipient. It keeps original BUSD purchase proceeds, earlier USDC project receipts, ML vesting releases and final token allocations distinct. It does not import the verified Ethereum fundraising source as proof of the different D975 BSC runtime. No unsupported allegation of missing funds, duplicate investor liability or personal spending was introduced.

## Finalization

The root agent confirmed that the exact recommended section 9.14 replacement was applied and the 31-page master rebuilt. This review is complete; lane writes are frozen.
