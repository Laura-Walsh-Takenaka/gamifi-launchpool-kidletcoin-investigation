import pathlib,json,urllib.request,datetime,hashlib,importlib.util
P=pathlib.Path(__file__).parent;R=P.parents[1]
spec=importlib.util.spec_from_file_location('verify',R/'claims_peer/verify_claims.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def nh(name):
 b=b'\0'*32
 for l in name.split('.')[::-1]:b=v.keccak256(b+v.keccak256(l.encode()))
 return b.hex()
A={'upstream':'0x77bfe8d704b1948374bf8dab8328a810b2836e66','prior_admin':'0xdb7d1459ddce7887266f25de31f090ff0eafea6c','sourceA':'0xa594af6496a61423582b19319732e3c7dc072f9f','sourceB':'0xdd923ff5961796b3005ee0d964d154ad08bd3695','treasury':'0x6c2b3a90acb72ef896325e19af9098d157f929c4','deployer':'0xb72fc236ab043029776b9d25e99a5b6456a2e16d'}
registry='0x00000000000c2e074ec69a0dfb2997ba6c7d2e1e';block=hex(25923587)
def fetch(name,req):
 rec={'url':'https://ethereum-rpc.publicnode.com','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':req}
 try:
  with urllib.request.urlopen(urllib.request.Request(rec['url'],data=json.dumps(req).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=35) as r:
   b=r.read();rec.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());(P/(name+'.response')).write_bytes(b);res=json.loads(b)
 except Exception as e:rec['error']=str(e);res=[]
 (P/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2));return res
nodes={k:nh(a[2:]+'.addr.reverse') for k,a in A.items()}
q=[{'jsonrpc':'2.0','id':i,'method':'eth_call','params':[{'to':registry,'data':'0x0178b8bf'+nodes[k]},block]} for i,k in enumerate(A)]
x=fetch('reverse_resolvers',q);resolvers={};keys=list(A)
for z in x:
 if z.get('result') and len(z['result'])==66:resolvers[keys[z['id']]]='0x'+z['result'][-40:]
q=[]
for k,a in resolvers.items():
 if int(a,16):q.append({'jsonrpc':'2.0','id':keys.index(k),'method':'eth_call','params':[{'to':a,'data':'0x691f3431'+nodes[k]},block]})
y=fetch('reverse_names',q) if q else []
names={}
for z in y:
 if z.get('result') and len(z['result'])>=130:
  b=bytes.fromhex(z['result'][2:]);off=int.from_bytes(b[:32],'big');length=int.from_bytes(b[off:off+32],'big');names[keys[z['id']]]=b[off+32:off+32+length].decode(errors='replace')
s={'block':int(block,16),'addresses':A,'nodes':nodes,'resolvers':resolvers,'reverse_names':names,'limit':'A reverse name requires forward confirmation before attribution. No reverse name is not proof that no public identity exists.'};(P/'summary.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
