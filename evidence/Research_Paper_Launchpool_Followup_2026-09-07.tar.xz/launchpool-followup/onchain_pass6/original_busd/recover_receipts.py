import pathlib,urllib.request,json,datetime,hashlib,sys,csv
from decimal import Decimal,getcontext
getcontext().prec=80
P=pathlib.Path(__file__).parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
U='https://bsc-dataseed.bnbchain.org';A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56'
SEL='0x'+keccak256(b'claimFundRaising(uint256)').hex()[:8]
EVENT='0x'+keccak256(b'FundRaisingClaimed(uint256,address,uint256)').hex()
TRANSFER='0x'+keccak256(b'Transfer(address,address,uint256)').hex()
assert EVENT=='0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089'
def rpc(name,qs):
 if '--offline' in sys.argv:
  meta=json.loads((P/(name+'.receipt.json')).read_text());b=(P/(name+'.response')).read_bytes()
  assert meta['request']==qs and meta['sha256']==hashlib.sha256(b).hexdigest()
  return {x['id']:x['result'] for x in json.loads(b)}
 meta={'url':U,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs}
 try:
  with urllib.request.urlopen(urllib.request.Request(U,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=35) as r:
   b=r.read();meta.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());(P/(name+'.response')).write_bytes(b)
  return {x['id']:x['result'] for x in json.loads(b)}
 except Exception as e:meta['error']=str(e);raise
 finally:(P/(name+'.receipt.json')).write_text(json.dumps(meta,indent=2))
x=json.loads((P/'transition_blocks.json').read_text());blocks=sorted({v['true_block'] for v in x})
b=rpc('bnb_transition_blocks',[{'jsonrpc':'2.0','id':i+1,'method':'eth_getBlockByNumber','params':[hex(h),True]} for i,h in enumerate(blocks)])
pidblock={v['pid']:v['true_block'] for v in x};txs={};headers={}
for v in b.values():
 assert v is not None
 h=int(v['number'],16);headers[h]=v
 for tx in v['transactions']:
  if tx.get('to')==A and tx['input'].startswith(SEL):
   pid=int(tx['input'][10:74],16)
   if pid in pidblock and h==pidblock[pid]:txs[pid]=tx
assert set(txs)==set(pidblock),(list(txs),pidblock)
(P/'discovered_claim_transactions.json').write_text(json.dumps(txs,indent=2))
r=rpc('bnb_claim_receipts',[{'jsonrpc':'2.0','id':pid,'method':'eth_getTransactionReceipt','params':[tx['hash']]} for pid,tx in txs.items()])
old={v['pool_id']:int(v['totalRaised_base_units']) for v in json.loads((P.parents[1]/'onchain_pass3/bsc_cash/pool_state_summary.json').read_text())['pools']};rows=[]
for pid,tx in sorted(txs.items()):
 rec=r[pid];h=pidblock[pid];head=headers[h]
 assert rec['status']=='0x1' and rec['transactionHash']==tx['hash'] and rec['blockHash']==head['hash']
 assert rec['from']==tx['from'] and rec['to']==A
 logs=[l for l in rec['logs'] if l['address']==A and l['topics'][0]==EVENT];assert len(logs)==1
 ev=logs[0];assert int(ev['topics'][1],16)==pid
 amount=int(ev['data'],16);recipient='0x'+ev['topics'][2][-40:]
 cash=[l for l in rec['logs'] if l['address']==BUSD and l['topics'][0]==TRANSFER and '0x'+l['topics'][1][-40:]==A and '0x'+l['topics'][2][-40:]==recipient and int(l['data'],16)==amount];assert len(cash)==1
 assert amount==old[pid]
 rows.append({'pool_id':pid,'raise':1 if pid<100 else 2,'tx_hash':tx['hash'],'block_number':h,'block_hash':head['hash'],'utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'caller':tx['from'],'contract':A,'recipient':recipient,'busd_token':BUSD,'amount_raw':str(amount),'amount_busd':format(Decimal(amount)/10**18,'f'),'claimed_event_log_index':int(ev['logIndex'],16),'busd_transfer_log_index':int(cash[0]['logIndex'],16),'status':1,'input_pid_event_pid_match':True,'claim_event_busd_transfer_match':True,'prior_counter_amount_match':True})
summary={'scope':'Exact six original Mintlayer BSC fundraising pool withdrawal receipts','discovery':'Historical false-to-true state brackets from documented Blockmachine archive endpoint; independently acquired block bodies and receipts from official BNB RPC','rows':rows,'total_raw':str(sum(int(r['amount_raw']) for r in rows)),'total_busd':format(sum(Decimal(r['amount_busd']) for r in rows),'f'),'recipients':sorted(set(r['recipient'] for r in rows)),'raises':{str(i):{'total_raw':str(sum(int(r['amount_raw']) for r in rows if r['raise']==i)),'total_busd':format(sum(Decimal(r['amount_busd']) for r in rows if r['raise']==i),'f')} for i in [1,2]}}
(P/'verified_original_mintlayer_claims.json').write_text(json.dumps(summary,indent=2))
with (P/'verified_original_mintlayer_claims.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(summary,indent=2))
