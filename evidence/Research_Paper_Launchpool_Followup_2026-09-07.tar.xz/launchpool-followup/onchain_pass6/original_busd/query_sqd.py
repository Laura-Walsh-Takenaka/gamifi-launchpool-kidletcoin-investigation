import pathlib,json,urllib.request,hashlib,datetime
P=pathlib.Path(__file__).parent
U='https://portal.sqd.dev/datasets/binance-mainnet/stream'
q={'type':'evm','fromBlock':13041550,'toBlock':24600000,'fields':{'block':{'number':True,'hash':True,'timestamp':True},'log':{'address':True,'topics':True,'data':True,'transactionHash':True,'logIndex':True}},'logs':[{'address':['0xd975b13cdf91de3aa0e0e888fb827fec3650624a'],'topic0':['0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089'],'topic1':['0x'+format(i,'064x') for i in [19,20,21,125,126,127]]}]}
# Documented cursor rule: advance past the last returned header; stop at toBlock.
# A bounded maximum of twenty responses avoids an unbounded archival scan.
for i in range(20):
 name=f'sqd_claims_{i+1:02}'
 meta={'url':U,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':q.copy()}
 try:
  with urllib.request.urlopen(urllib.request.Request(U,data=json.dumps(q).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=50) as r:
   b=r.read();meta.update(status=r.status,headers=dict(r.headers),sha256=hashlib.sha256(b).hexdigest());(P/(name+'.ndjson')).write_bytes(b)
  rows=[json.loads(x) for x in b.splitlines() if x.strip()]
  meta['returned_blocks']=len(rows);meta['returned_logs']=sum(len(x.get('logs',[])) for x in rows)
  if rows:meta['last_block']=rows[-1]['header']['number']
  (P/(name+'.receipt.json')).write_text(json.dumps(meta,indent=2))
  print(name,meta.get('status'),meta.get('returned_logs'),meta.get('last_block'),flush=True)
  for row in rows:
   if row.get('logs'):print(json.dumps(row),flush=True)
  if not rows or rows[-1]['header']['number']>=q['toBlock']:break
  q['fromBlock']=rows[-1]['header']['number']+1
 except Exception as e:
  meta['error']=str(e)
  if hasattr(e,'read'):
   b=e.read();(P/(name+'.error')).write_bytes(b);meta['error_body_sha256']=hashlib.sha256(b).hexdigest()
  (P/(name+'.receipt.json')).write_text(json.dumps(meta,indent=2));print(meta,flush=True);break
