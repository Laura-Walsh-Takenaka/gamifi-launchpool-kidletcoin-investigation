# Original Mintlayer BUSD withdrawals: all six actual receipts recovered

**Retrieved 7 September 2026.** This pass closes the earlier historical withdrawal-recipient gap for Mintlayer's original BSC fundraising pools. Six successful transactions transferred exactly **903,794.346419582485370326 BUSD** from Launchpool contract `0xd975b13cdf91de3aa0e0e888fb827fec3650624a` to **`0x77bfe8d704b1948374bf8dab8328a810b2836e66`**. The same address directly called all six withdrawals.

For every transaction, three independent fields agree: the `claimFundRaising(uint256)` input selects the configured Mintlayer pool, D975 emits the matching `FundRaisingClaimed` event, and BUSD contract `0xe9e7cea3dedca5984780bafc599bd69add087d56` emits a matching `Transfer` to 77bf. Every receipt status is successful. The exact amounts also equal the six previously recovered raised counters.

## Verified receipts

| Pool | UTC date and time | BUSD actually transferred | Transaction |
|---|---|---:|---|
| 19 | 2022-11-03 09:02:17 | 194775.268548166718546 | `0x3d0006d4dc6efd3afa6e0ef00c6fc922e923c9554948b3603cdb68b67693e530` |
| 20 | 2022-11-03 09:02:44 | 195415.21517867104204 | `0x43e7ac050c6554ad6687a1ee3b1a93b023c0612569fe457bc387f1c5caa9f1e2` |
| 21 | 2022-11-03 09:03:14 | 197226.626562780028172 | `0x55c7bac730a3710789f3e03e663e60d7d0de922915614321acb2c0bfe940cc4e` |
| 125 | 2022-11-04 13:59:08 | 101799.763199702252300446 | `0x66a3dc452a3bf55c036d337a59e42d0c901f5be74b40f03c8de1ad45779dd1cc` |
| 126 | 2022-11-04 13:59:35 | 103426.318782728639320062 | `0x9a7604579b4c73b22fd82d0d50a511c70432830c5dc55636a336f25f39fe34ab` |
| 127 | 2022-11-04 14:00:02 | 111151.154147533804991818 | `0x3419abf8099ee0fa49c5b1eea340da633bd312f411ee3e147827fc0b4f64169e` |

Raise 1 pools 19–21 paid **587,417.110289617788758 BUSD** in 57 seconds on 3 November 2022. Raise 2 pools 125–127 paid **316,377.236129964696612326 BUSD** in 54 seconds on 4 November 2022. Their allocation to Mintlayer comes from the earlier recovered public project configuration matching the exact BSC deployment, network and pool IDs; it does not depend on a token ticker or similarly numbered pools elsewhere.

## What this changes

The prior description that the Mintlayer amounts were only raised counters, with the actual withdrawal date and recipient unrecovered, is superseded for these six payouts. The evidence now establishes an actual historical BUSD receipt by 77bf in November 2022, as well as its later observed operational role and current contract control.

This is the **same 903,794.3464 BUSD** previously represented by those counters. Do not add it a second time. It is separate from the 18 other-project withdrawals totaling 1,918,188.01957 BUSD recovered in pass 4, the Ethereum ML allocation reserves, and the mixed USDC/Base trading lane.

The human signing-key holder, corporate mandate, project settlement records and ultimate onward disposition of these original Mintlayer receipts remain to be established. The receipts identify the receiving address; they do not themselves identify Laura as its controller or beneficiary. No personal receipt, theft, or loss amount is assigned from this finding.

## Acquisition and validation

Previous failure logs were reviewed before new retrieval. The official BNB public endpoint documents that `eth_getLogs` is disabled; those failed log queries, denied BscScan pages, unsupported Routescan chain, and public Binplorer latest-100 window were not repeated.

1. **Documented SQD public historical event index.** A filter selected D975, the fundraising-claim event topic and the six exact indexed pool IDs. Twenty documented cursor-continuation responses covered only blocks 13,041,550–13,048,659 and returned no matching events. This is an incomplete, narrow observation, not a negative result for the wider requested history. The attempt stopped at its request bound.
2. **Documented keyless Blockmachine archive RPC.** Historical `poolIdToFundsClaimed` calls succeeded. Each pool was false at its fundraising end block and true at block 24,600,000. Twenty-four batched binary-search rounds located an adjacent false/true pair for each pool. Their true blocks were 22,732,478; 22,732,487; 22,732,497; 22,766,632; 22,766,641; and 22,766,650. This located candidate blocks; the subsequent receipt check supplies the actual payment evidence.
3. **Independent official BNB RPC acquisition.** Full block bodies and transaction receipts were fetched from `https://bsc-dataseed.bnbchain.org`. Exact transaction input, successful receipt, block hash, block timestamp, event pool/recipient/amount and BUSD transfer were checked. Integer base units were summed before decimal formatting; no explorer floating-point amount was used.

Primary endpoint documentation and exact scope are preserved in `source_provenance.json`. All POST bodies, retrieval timestamps, response hashes and raw response bodies are preserved. No account, API credential, payment, signature, transaction or outside message was used.

## Files and reproduction

- `verified_original_mintlayer_claims.json` and `.csv`: full identifiers, exact amounts, block hashes, UTC times and matching checks.
- `bnb_transition_blocks.response` / `.receipt.json`: official BNB full block data and exact requests.
- `bnb_claim_receipts.response` / `.receipt.json`: six raw successful receipts and exact requests.
- `brackets.*`, `binary_01`–`binary_24.*`, `transition_blocks.json`: historical state discovery with exact request-to-pool/block mapping.
- `sqd_claims_*.ndjson`, matching request receipts and `sqd_attempt_summary.json`: bounded incomplete alternate attempt.
- `recover_receipts.py --offline`: reproduces all receipt/input/amount checks from preserved responses and validates their recorded hashes. It also compares amounts against the earlier pass-3 counter evidence in the consolidated package.
- `offline_reproduction.json`: successful offline reproduction output.

Run from the project root: `python onchain_pass6/original_busd/recover_receipts.py --offline`. Reproduction requires the preserved sibling `claims_peer/verify_claims.py` Keccak implementation and `onchain_pass3/bsc_cash/pool_state_summary.json`; it performs no network request in offline mode.
