import pathlib,urllib.request,json,datetime,hashlib,sys,time
P=pathlib.Path(__file__).parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
U='https://rpc-bsc.blockmachine.io';A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';SEL='0x'+keccak256(b'poolIdToFundsClaimed(uint256)').hex()[:8]
ranges={pid:[13125200 if pid<100 else 16525000,24600000] for pid in [19,20,21,125,126,127]}
def fetch(name,points):
 qs=[{'jsonrpc':'2.0','id':i+1,'method':'eth_call','params':[{'to':A,'data':SEL+format(pid,'064x')},hex(block)]} for i,(pid,block) in enumerate(points)]
 meta={'url':U,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs,'id_to_pool_block':{str(i+1):{'pid':pid,'block':block} for i,(pid,block) in enumerate(points)}}
 try:
  with urllib.request.urlopen(urllib.request.Request(U,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=35) as r:
   b=r.read();meta.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());(P/(name+'.response')).write_bytes(b)
  out={x['id']:x for x in json.loads(b)};ans=[]
  for i in range(len(points)):
   x=out[i+1];assert 'result' in x,x;n=int(x['result'],16);assert n in [0,1];ans.append(n)
  return ans
 except Exception as e:
  meta['error']=str(e);raise
 finally:(P/(name+'.receipt.json')).write_text(json.dumps(meta,indent=2))
points=[(pid,block) for pid,bracket in ranges.items() for block in bracket]
vals=fetch('brackets',points);assert vals==[0,1]*6,vals
for j in range(25):
 points=[(pid,(r[0]+r[1])//2) for pid,r in ranges.items() if r[1]-r[0]>1]
 if not points:break
 vals=fetch(f'binary_{j+1:02}',points)
 for (pid,block),val in zip(points,vals):ranges[pid][1 if val else 0]=block
 (P/'transition_progress.json').write_text(json.dumps(ranges,indent=2));print(j+1,ranges,flush=True)
 time.sleep(0.3)
assert all(b-a==1 for a,b in ranges.values())
(P/'transition_blocks.json').write_text(json.dumps([{'pid':pid,'false_block':a,'true_block':b} for pid,(a,b) in ranges.items()],indent=2))
print('SUCCESS',ranges,flush=True)
