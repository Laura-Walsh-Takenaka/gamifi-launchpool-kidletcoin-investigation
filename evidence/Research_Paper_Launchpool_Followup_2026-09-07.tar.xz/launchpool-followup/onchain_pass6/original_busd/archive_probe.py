import pathlib,urllib.request,json,datetime,hashlib,sys
P=pathlib.Path(__file__).parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
U='https://rpc-bsc.blockmachine.io';A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'
qs=[{'jsonrpc':'2.0','id':1,'method':'eth_chainId','params':[]}]
for pid,block in [(19,13125200),(19,24600000),(125,16525000),(125,24600000)]:
 qs.append({'jsonrpc':'2.0','id':len(qs)+1,'method':'eth_call','params':[{'to':A,'data':'0x'+keccak256(b'poolIdToFundsClaimed(uint256)').hex()[:8]+format(pid,'064x')},hex(block)]})
meta={'url':U,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs}
try:
 with urllib.request.urlopen(urllib.request.Request(U,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=35) as r:
  b=r.read();meta.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());(P/'blockmachine_archive_probe.response').write_bytes(b)
 print(b.decode())
except Exception as e:
 meta['error']=str(e)
 if hasattr(e,'read'):
  b=e.read();(P/'blockmachine_archive_probe.error').write_bytes(b);meta['error_body_sha256']=hashlib.sha256(b).hexdigest()
 print(meta)
(P/'blockmachine_archive_probe.receipt.json').write_text(json.dumps(meta,indent=2))
