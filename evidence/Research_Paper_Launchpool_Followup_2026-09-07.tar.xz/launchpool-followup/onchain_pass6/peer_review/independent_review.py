#!/usr/bin/env python3
"""Offline independent pass-six ledger and receipt review; raw inputs only."""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal
import hashlib, json, re

BASE=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
F='0xf695f1d1688698abc97b2e5937ba24934561aae9'
W='0x1991e27e2908847c0274a662eb6675002e8386d0'
SH='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4'
USDT='0xdac17f958d2ee523a2206206994597c13d831ec7'
USDC='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
consumed={};checks=[]
def read(p):
    b=p.read_bytes();consumed[str(p.relative_to(BASE))]=hashlib.sha256(b).hexdigest()
    return json.loads(b)
def check(label, condition):
    checks.append({'check':label,'pass':bool(condition)})
    if not condition: raise AssertionError(label)
def amount(v): return format(Decimal(v)/10**6,'f')
def utc(t): return datetime.fromtimestamp(int(t),timezone.utc).isoformat()
def ledger(lane,name,w,token,count):
    d=read(BASE/lane/name)
    check(name+' status',d['status']=='1')
    rows=d['result'];check(name+' count',len(rows)==count)
    check(name+' block/transaction ordering',rows==sorted(rows,key=lambda x:(int(x['blockNumber']),int(x['transactionIndex']))))
    incoming=defaultdict(lambda:[0,0]);outgoing=defaultdict(lambda:[0,0]);bal=0;minbal=0;beforeafter={};seen=Counter()
    for r in rows:
        fr=r['from'].lower();to=r['to'].lower();v=int(r['value'])
        check(name+' token/decimals/participant '+r['hash'],r['contractAddress'].lower()==token and r['tokenDecimal']=='6' and w in [fr,to] and v>=0)
        key=(r['hash'].lower(),fr,to,v);seen[key]+=1
        bef=bal
        if to==w: incoming[fr][0]+=1;incoming[fr][1]+=v;bal+=v
        if fr==w: outgoing[to][0]+=1;outgoing[to][1]+=v;bal-=v
        minbal=min(minbal,bal)
        beforeafter[r['hash'].lower()]={'before_raw':str(bef),'after_raw':str(bal),'block':int(r['blockNumber']),'timestamp_utc':utc(r['timeStamp']),'value_raw':str(v),'from':fr,'to':to}
    check(name+' no identical duplicate rows',max(seen.values())==1)
    check(name+' no negative derived balance',minbal==0)
    check(name+' final event-derived balance zero',bal==0)
    return rows,beforeafter,{'rows':len(rows),'incoming_raw':str(sum(v[1] for v in incoming.values())),'outgoing_raw':str(sum(v[1] for v in outgoing.values())),'final_event_derived_balance_raw':str(bal),'incoming_by_address':dict(incoming),'outgoing_by_address':dict(outgoing),'first_timestamp':utc(rows[0]['timeStamp']),'last_timestamp':utc(rows[-1]['timeStamp']),'last_block':int(rows[-1]['blockNumber']),'qualification':'Balances derived from returned indexed token events. This check alone does not prove completeness of the index or current/historical eth_call state.'}
def receipts(lane):
    """Use preserved exact requests to bind result IDs to queried hashes."""
    found={};calls=[];failed=[]
    for rp in sorted((BASE/lane).glob('*.request.json')):
        meta=read(rp)
        jobs=meta.get('jsonrpc_body')
        if jobs is None: continue
        if isinstance(jobs,dict):jobs=[jobs]
        selected={j['id']:j for j in jobs if j.get('method')=='eth_getTransactionReceipt'}
        if not selected:continue
        response=BASE/lane/meta['response_file']
        if not response.exists():continue
        if 'request_body_utf8' in meta and 'request_body_sha256' in meta:
            check(rp.name+' exact request hash',hashlib.sha256(meta['request_body_utf8'].encode()).hexdigest()==meta['request_body_sha256'])
            check(rp.name+' request body binding',json.loads(meta['request_body_utf8'])==meta['jsonrpc_body'])
        captured=read(response)
        provenance=response.with_name(response.name+'.receipt.json')
        if provenance.exists():
            provenance_data=read(provenance)
            if 'sha256' in provenance_data:check(response.name+' capture hash',consumed[str(response.relative_to(BASE))]==provenance_data['sha256'])
        if isinstance(captured,dict):captured=[captured]
        for item in captured:
            job=selected.get(item.get('id'))
            if not job:continue
            h=job['params'][0].lower();rec=item.get('result')
            if not isinstance(rec,dict):failed.append({'file':response.name,'hash':h,'error':item.get('error'),'null_result':item.get('result') is None});continue
            check(response.name+' returned queried transaction '+h,rec['transactionHash'].lower()==h)
            check(response.name+' receipt success '+h,int(rec['status'],16)==1)
            found.setdefault(h,[]).append({'file':response.name,'receipt':rec})
            calls.append({'hash':h,'file':response.name,'block':int(rec['blockNumber'],16)})
    return found,{'successful_unique_hashes':len(found),'successful_captures':len(calls),'captures':calls,'failed_or_null_attempts':failed}
def match_rows(rows,rs,label):
    matched=[]
    for row in rows:
        h=row['hash'].lower()
        if h not in rs:continue
        expected=(row['contractAddress'].lower(),row['from'].lower(),row['to'].lower(),int(row['value']))
        for item in rs[h]:
            rec=item['receipt'];logs=[]
            check(label+' block/hash '+h,int(rec['blockNumber'],16)==int(row['blockNumber']) and rec['blockHash'].lower()==row['blockHash'].lower())
            for log in rec['logs']:
                topics=log.get('topics',[])
                if len(topics)==3 and topics[0].lower()==TRANSFER:
                    logs.append((log['address'].lower(),'0x'+topics[1][-40:].lower(),'0x'+topics[2][-40:].lower(),int(log['data'],16)))
            check(label+' exact token Transfer log '+h,expected in logs)
        matched.append(h)
    return sorted(set(matched))

frows,fb,fstats=ledger('f695_recipient','f695_USDT_history.json',F,USDT,65)
crows,cb,cstats=ledger('returned_funds','USDC_history.json',W,USDC,370)
trows,tb,tstats=ledger('returned_funds','USDT_history.json',W,USDT,1577)
check('f695 total exact',fstats['incoming_raw']==fstats['outgoing_raw']=='23722265580')
check('f695 Revolut-label destination exact',fstats['outgoing_by_address']['0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921']==[25,23378068982])
check('f695 KuCoin-label destination exact',fstats['outgoing_by_address']['0x8e21157932ecd417c557b4c975bd3e89d8ea896e']==[2,344196598])
check('f695 shared-wallet six payments exact',fstats['incoming_by_address'][SH]==[6,2975818225])
payment='0x8882f17f55d39946da7ae8aadeef3ff4480b553b3441809480fcbc2d3d6d8ca9'
sweep='0xd9d2d2e0be5ae4814a64f653cb8c20ab3dfefc494a41eb16f11325cff0113cdb'
check('f695 July payment zero to 1000',fb[payment]['before_raw']=='0' and fb[payment]['after_raw']=='1000000000')
check('f695 July sweep 1000 to zero',fb[sweep]['before_raw']=='1000000000' and fb[sweep]['after_raw']=='0')
check('f695 July delay 87m24s',(datetime.fromisoformat(fb[sweep]['timestamp_utc'])-datetime.fromisoformat(fb[payment]['timestamp_utc'])).total_seconds()==5244)
expected_c={'0xd24120f60683e7e27ed0376e219f4de61b840aee28e72343e40bef1ba6377668':(11460000000,32576990000),'0xdae838abc3a146ed855c6221435d947a459deea79f3f25390a981974c347470b':(32576990000,76990000),'0x6eceebc587e9f72c31e0b13c86c24199f963fd3a259b9237e947441c08ae1c02':(318192184647,0)}
expected_t={'0x7ae7223ebfbeb9c0a06f34342c1e15f1a068c7feae454548d170d2f8ac16fd43':(8375183313,67099288695),'0x80c22d120cf43e2192e19920636dfa77ccf65508437ffec0e6c4b426a86a7df5':(67099288695,45217018695),'0x79e52446c43d9b1f7c0b3fb41f41ee006d2f2b6bd6d81426c9021f815ee43666':(45217018695,41217018695),'0x5e84f9d81c5b78e0f8e16b3bf8826862fee7ede8ceb50195969fd8d66d76fa2a':(105907029506,0)}
for asset,expected,states in [('USDC',expected_c,cb),('USDT',expected_t,tb)]:
    for h,(before,after) in expected.items():check(asset+' exact pre/post event balance '+h,(int(states[h]['before_raw']),int(states[h]['after_raw']))==(before,after))
fr,frstats=receipts('f695_recipient');rr,rrstats=receipts('returned_funds')
fm=match_rows(frows,fr,'f695')
side=[]
for name in ['0008_july.json','188b_july.json','2c94_july.json','327a_july.json']:
    for row in read(BASE/'returned_funds'/name)['result']:
        if row['contractAddress'].lower() in [USDC,USDT] and int(row['value'])>0:
            side.append(row)
rm=match_rows(crows+trows+side,rr,'returned')
selected_f={r['hash'].lower() for r in frows if r['from'].lower() in [F,SH]}
selected_r=set(read(BASE/'returned_funds/selected_hashes.json'))
check('f695 selected distinct 33 hashes',len(selected_f)==33)
check('returned all 15 selected receipts have matched indexed canonical transfer',selected_r<=set(rm))
fallback=[]
for h in sorted(selected_f-fr.keys()):
    row=next(r for r in frows if r['hash'].lower()==h)
    prefix='null_'+h[2:10]
    tx=read(BASE/'f695_recipient'/(prefix+'_transaction.json'))
    logdata=read(BASE/'f695_recipient'/(prefix+'_logs.json'))
    for suffix in ['_transaction.json','_logs.json']:
        name=prefix+suffix
        meta=read(BASE/'f695_recipient'/(name+'.request.json'))
        prov=read(BASE/'f695_recipient'/(name+'.receipt.json'))
        check(name+' exact endpoint hash',h in meta['url'])
        check(name+' captured response integrity',prov['sha256']==consumed['f695_recipient/'+name])
    check(h+' indexed successful transaction',tx['hash'].lower()==h and tx['status']=='ok' and tx['result']=='success' and tx['block_number']==int(row['blockNumber']))
    check(h+' all indexed log pages',logdata['next_page_params'] is None)
    expected=(USDT,row['from'].lower(),row['to'].lower(),int(row['value']))
    logs=[]
    for lg in logdata['items']:
        tops=[v.lower() for v in lg['topics'] if v is not None]
        if len(tops)==3 and tops[0]==TRANSFER:
            logs.append((lg['address']['hash'].lower(),'0x'+tops[1][-40:],'0x'+tops[2][-40:],int(lg['data'],16)))
    check(h+' independently decoded indexed raw log',expected in logs)
    inp=tx['raw_input']
    check(h+' indexed calldata transfer',inp[:10]=='0xa9059cbb' and '0x'+inp[10:74][-40:].lower()==row['to'].lower() and int(inp[74:138],16)==int(row['value']))
    fallback.append({'hash':h,'method':'Indexed Blockscout successful transaction and raw logs; not successful JSON-RPC receipt'})
pin=read(BASE/'f695_recipient/pin_drpc.json')['result']
check('current pin block number',int(pin['number'],16)==25925814)
current=[]
for name in ['current_state_limited_1.json','alternate_rpc_5.json']:
    meta=read(BASE/'f695_recipient'/(name+'.request.json'))
    qs={j['id']:j for j in meta['jsonrpc_body']}
    for ans in read(BASE/'f695_recipient'/name):
        if not isinstance(ans.get('result'),str):continue
        q=qs[ans['id']]
        check(name+' pinned state height '+str(ans['id']),q['params'][-1]==pin['number'])
        if q['method']=='eth_call':
            check(name+' pinned token/address',q['params'][0]['to'].lower()==USDT and q['params'][0]['data']=='0x70a08231'+F[2:].rjust(64,'0'))
        else:check(name+' pinned address',q['params'][0].lower()==F)
        current.append({'id':ans['id'],'method':q['method'],'result':ans['result'],'block':int(pin['number'],16)})
current_map={x['id']:x['result'] for x in current}
check('current separately queried USDT zero',int(current_map['USDT'],16)==0)
check('current separately queried ETH exact',int(current_map['ETH'],16)==34566131300512124)
check('current separately queried nonce and code',int(current_map['nonce'],16)==30 and current_map['code']=='0x')
normal=read(BASE/'f695_recipient/f695_normal_history.json')['result']
check('normal history count',len(normal)==89)
check('outgoing nonces complete 0 through29',sorted(int(r['nonce']) for r in normal if r['from'].lower()==F)==list(range(30)))
gas=[r for r in normal if r['from'].lower()=='0xb23360ccdd9ed1b15d45e5d3824bb409c8d7c460' and r['to'].lower()==F and r['isError']=='0']
check('34 gas fundings exact ETH',len(gas)==34 and sum(int(r['value']) for r in gas)==20922180000000000)
ethout=[r for r in normal if r['from'].lower()==F and r['to'].lower()=='0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921' and r['isError']=='0']
check('ancillary indexed ETH two outputs exact',len(ethout)==2 and sum(int(r['value']) for r in ethout)==6320509399529568055)
usdccycle=read(BASE/'f695_recipient/f695_USDC_history.json')['result']
check('ancillary USDC exact two event cycle',len(usdccycle)==2 and all(r['contractAddress'].lower()==USDC and r['tokenDecimal']=='6' and int(r['value'])==850921922 for r in usdccycle) and usdccycle[0]['to'].lower()==F and usdccycle[1]['from'].lower()==F and usdccycle[1]['to'].lower()=='0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921')
cycle_count=0
for i,r in enumerate(frows):
    if r['from'].lower()!=SH:continue
    check('cycle input starts at derived zero '+r['hash'],fb[r['hash']]['before_raw']=='0')
    subset=[]
    for later in frows[i+1:]:
        subset.append(later)
        if fb[later['hash']]['after_raw']=='0':break
    outs=[x for x in subset if x['from'].lower()==F]
    ins=[x for x in subset if x['to'].lower()==F]
    check('cycle one Revolut-label sweep '+r['hash'],len(outs)==1 and outs[0]['to'].lower()=='0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921')
    check('cycle mixed-input arithmetic '+r['hash'],int(r['value'])+sum(int(x['value']) for x in ins)==int(outs[0]['value']))
    cycle_count+=1
check('six independently checked source cycles',cycle_count==6)
labels=[]
prior_labels={}
if (OUT/'independent_review.json').exists():
    prior_labels={x['file']:x for x in json.loads((OUT/'independent_review.json').read_text()).get('explorer_labels',[])}
for lane,name in [('f695_recipient','revolut_address.html'),('f695_recipient','secondary_8e211_address.html'),('returned_funds','327a_address.html'),('returned_funds','83c4_address.html')]:
    p=BASE/lane/name
    if p.exists():
        data=p.read_bytes();s=data.decode();m=re.search(r'<title[^>]*>(.*?)</title>',s,re.S)
        labels.append({'file':str(p.relative_to(BASE)),'sha256':hashlib.sha256(data).hexdigest(),'title':re.sub(r'\s+',' ',m[1]).strip() if m else None})
    elif str(p.relative_to(BASE)) in prior_labels:
        labels.append(prior_labels[str(p.relative_to(BASE))])

result={'review_scope':'Independent raw indexed-event arithmetic, request-bound successful receipt verification and explorer-label capture; no human ownership attribution. All amounts use exact integer raw units. Only requested bounded histories reviewed.','f695':{'ledger':fstats,'selected_receipts_expected':33,'selected_receipts_obtained':len(selected_f&fr.keys()),'selected_RPC_receipts_missing':sorted(selected_f-fr.keys()),'indexed_fallback_verified':fallback,'matched_history_rows':len(fm),'july_payment':fb[payment],'july_sweep':fb[sweep],'receipt_coverage':frstats,'separately_queried_current_state':current,'pin_hash':pin['hash']},'returned_funds':{'USDC_ledger':cstats,'USDT_ledger':tstats,'selected_receipts_expected':len(selected_r),'selected_receipts_obtained':len(selected_r&rr.keys()),'selected_receipts_missing':sorted(selected_r-rr.keys()),'matched_history_rows':len(rm),'selected_USDC_states':{h:cb[h] for h in expected_c},'selected_USDT_states':{h:tb[h] for h in expected_t},'receipt_coverage':rrstats},'explorer_labels':labels,'qualifications':['Explorer service labels identify a claimed service endpoint; they do not identify the customer, signer, beneficial owner or purpose.','No current balance conclusion is drawn from an old bounded event ledger.','Source allocation across mixed balances is constrained by arithmetic but is not a unique token trail.'],'checks_passed':len(checks),'checks':checks,'consumed_sha256':consumed}
(OUT/'independent_review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'f695_receipts':result['f695']['selected_receipts_obtained'],'returned_receipts':result['returned_funds']['selected_receipts_obtained'],'label_titles':[x['title'] for x in labels]},indent=2))
