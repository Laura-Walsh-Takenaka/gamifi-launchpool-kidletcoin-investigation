# Independent review of Launchpool pass six

Review date: 7 September 2026. Verdict: **PASS for the bounded scopes below, with evidence classes preserved.** No corrections to the originating lanes' final findings were required. The review used retained public responses offline and did not expand the investigation, contact account holders, or submit blockchain transactions.

## Original Mintlayer BSC withdrawals

`independent_original_busd.py` independently decodes all six original pool withdrawals (19, 20, 21, 125, 126, 127). The review checks 151 preserved historical pool-flag query points, including adjacent false-to-true block boundaries for each pool. It separately binds the official BNB RPC requests to full block bodies and successful transaction receipts, then matches transaction calldata, pool IDs, fundraising-claim events and canonical BUSD Transfer logs.

All six transactions paid `0x77bfe8d704b1948374bf8dab8328a810b2836e66` on 3–4 November 2022. Exact total: **903,794.346419582485370326 BUSD**. Block-header timestamps and the report's transaction identifiers and amounts match the independent decode. **935 checks passed.** This closes the actual withdrawal recipient/timing gap. Onward settlement, human signers, authorization and legal entitlement remain outside these receipts' proof.

## f695, service endpoints and the returned-funds disposition

`independent_review.py` independently replays all **65 f695 USDT events**, **370 bounded 1991 USDC events**, and **1,577 bounded 1991 USDT events** using raw integers. Canonical token addresses, six decimals, participant addresses, ordering, exact duplicate tuples and nonnegative derived balances are checked. All three retrieved ledgers reconcile to zero at their respective ends.

For f695, all **33 selected USDT edges** are independently checked: **27 successful JSON-RPC receipts** and **six Blockscout indexed successful transaction/raw-log captures** after RPC null responses. The latter are explicitly not described as successful RPC receipts. The July 1,000-USDT receipt and onward sweep both have successful RPC receipts. Their indexed timestamps differ by **87 minutes 24 seconds**, and the retrieved event ledger shows a zero-to-1,000-to-zero cycle with no intervening USDT event.

The six inputs from 183600 total **2,975.818225 USDT**. Each complete observed balance cycle ends in one sweep to the same Revolut-labeled endpoint; three cycles contain other incoming funds. The entire retrieved f695 USDT ledger totals **23,722.265580 USDT** each way, including **23,378.068982 USDT** to the Revolut-labeled endpoint and **344.196598 USDT** to the KuCoin-labeled deposit address. Whole-address totals are not assigned entirely to 183600 or BAMBOO.

Current f695 state is separately request-bound to Ethereum block **25,925,814**, hash `0xb386179ef66493bd3446a907e6161ed90727b8f792059578ceb9b77caa07db35`: zero USDT, **0.034566131300512124 ETH**, empty runtime, nonce 30. The 89-row normal history contains outgoing nonces 0 through 29 and 34 gas-funding payments totaling **0.02092218 ETH**. Ancillary indexed totals of **6.320509399529568055 ETH** and **850.921922 USDC** sent to the Revolut endpoint also match; those ancillary assets were not part of the 33-edge USDT receipt audit.

For 1991 and its selected subsequent recipients, **all 15 selected transfers** have request-bound successful Ethereum RPC receipts matching exact canonical-token Transfer logs. The independently replayed ledger reproduces the reported pre-return and post-return balances and both final sweeps. In particular, **105,907.029506 USDT** goes through the precisely labeled KuCoin Deposit address 327a to the endpoint labeled **KuCoin 18**, not KuCoin 20. This includes a mixed balance assembled from the return, prior funds and later receipts.

Direct explorer title captures support the reported service labels. They identify service-associated endpoints according to the explorer, not a customer, signer, account credit, beneficial owner or Laura. The historical f695 and 1991 balance checkpoints are derived from retrieved indexed events; unavailable historical state calls were not converted into zero balances. **2,402 checks passed** in this combined ledger/receipt review.

## IAG-pool source conservation bound

`independent_source_bounds.py` independently checks the preserved **13-event 77bf USDC history**, the 370-event 1991 history, and the prior 322-event 183600 history. It reproduces zero starting event balances for the selected stages, **191,393.685754 USDC** from the fundraising contract, only **20 USDC** of other positive incoming funds, and the selected **27,100 USDC** sent through 1991 and 183600 into the previously verified Base bridge transactions.

The **27,080–27,100 USDC** IAG-pool-origin conservation interval is valid, conditional on completeness of these captured canonical-token histories. The review constructs nonnegative source allocations consistent with every selected transfer at both interval endpoints. This demonstrates that the lower and upper limits are attainable without imposing FIFO, last-in-first-out, or proportional attribution. **908 checks passed.** The prior IAG project mapping and bridge-message/receipt audit are dependencies rather than re-audited work in this scope.

The interval concerns bridge funding. It does not determine legal ownership or permitted use, identify specific fungible units or a human signer, allocate later profits, or convert this USDC route into original Mintlayer BUSD or ML-reserve activity. The failed fresh 183600 API request was not used as evidence of absent history; the preserved prior complete retrieved event capture supplies that leg.

## Reproduction and freeze

Run from any directory using the scripts' actual paths:

```text
python onchain_pass6/peer_review/independent_review.py
python onchain_pass6/peer_review/independent_original_busd.py
python onchain_pass6/peer_review/independent_source_bounds.py
```

Scripts use retained raw response and request files and produce the adjacent JSON review results. The first script can preserve its previously captured short explorer label records if full HTML has been omitted from redistribution. No complete third-party page is needed to rerun the numeric and receipt checks. The source-bound script also uses the prior pass-four USDC event capture explicitly identified and hashed in its output.

All peer-review files are frozen after the final run. Hashes of consumed evidence are recorded in the JSON results; `SHA256SUMS` covers this review directory's deliverables. No other lane or master report was edited.
