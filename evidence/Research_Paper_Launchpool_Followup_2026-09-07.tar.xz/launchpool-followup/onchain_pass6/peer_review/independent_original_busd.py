#!/usr/bin/env python3
"""Offline independent decode of six BSC receipts and their historical brackets."""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal
import json,hashlib
P=Path(__file__).resolve().parents[1]/'original_busd'
O=Path(__file__).resolve().parent
POOL='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'
OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56'
TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
CLAIM='0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089'
checks=[];hashes={}
def load(f):
 b=(P/f).read_bytes();hashes[f]=hashlib.sha256(b).hexdigest();return json.loads(b)
def ck(name,v):
 checks.append({'check':name,'pass':bool(v)})
 if not v:raise AssertionError(name)
def capture(stem):
 m=load(stem+'.receipt.json');r=load(stem+'.response')
 ck(stem+' content hash',m['sha256']==hashes[stem+'.response'])
 q={x['id']:x for x in m['request']};results=[]
 ck(stem+' unique response ids',len({x['id'] for x in r})==len(r))
 for x in r:
  ck(stem+' result exists '+str(x['id']),'result' in x and x['result'] is not None)
  results.append((q[x['id']],x['result']))
 ck(stem+' all responses',len(results)==len(q))
 return results

states={}
for f in sorted(P.glob('binary_*.receipt.json'))+[P/'brackets.receipt.json']:
 for q,r in capture(f.name.removesuffix('.receipt.json')):
  ck(f.name+' historical method',q['method']=='eth_call' and q['params'][0]['to'].lower()==POOL)
  data=q['params'][0]['data'];ck(f.name+' selector and size',data[:10]=='0xb9641a21' and len(data)==74)
  pid=int(data[10:],16);block=int(q['params'][1],16);v=int(r,16)
  ck(f.name+' Boolean value',v in (0,1))
  ck(f.name+' consistent repeated state',(pid,block) not in states or states[(pid,block)]==v)
  states[(pid,block)]=v
transitions=load('transition_blocks.json')
for t in transitions:
 pid=t['pid'];a=t['false_block'];b=t['true_block']
 ck('pool '+str(pid)+' adjacent false true',a+1==b and states[(pid,a)]==0 and states[(pid,b)]==1)

blocks={}
for q,b in capture('bnb_transition_blocks'):
 ck('block method/input',q['method']=='eth_getBlockByNumber' and q['params'][1] is True)
 ck('block number matches request',int(q['params'][0],16)==int(b['number'],16))
 blocks[int(b['number'],16)]=b
transactions={tx['hash'].lower():tx for b in blocks.values() for tx in b['transactions']}
decoded=[]
for q,r in capture('bnb_claim_receipts'):
 h=q['params'][0].lower();pid=q['id'];tx=transactions[h];bn=int(r['blockNumber'],16);b=blocks[bn]
 ck(str(pid)+' requested receipt hash',q['method']=='eth_getTransactionReceipt' and r['transactionHash'].lower()==h)
 ck(str(pid)+' success',int(r['status'],16)==1)
 ck(str(pid)+' block hashes',r['blockHash'].lower()==b['hash'].lower()==tx['blockHash'].lower())
 ck(str(pid)+' caller/contract',r['from'].lower()==tx['from'].lower()==OWNER and r['to'].lower()==tx['to'].lower()==POOL)
 ck(str(pid)+' calldata uint256 pool id',tx['input'][:10]=='0x67a49923' and len(tx['input'])==74 and int(tx['input'][10:],16)==pid)
 ck(str(pid)+' BSC transaction chain id',int(tx['chainId'],16)==56)
 ck(str(pid)+' transition matches receipt block',next(t for t in transitions if t['pid']==pid)['true_block']==bn)
 transfer=[];claim=[]
 for lg in r['logs']:
  top=lg['topics'];a=lg['address'].lower()
  if a==BUSD and top[0].lower()==TRANSFER:
   ck(str(pid)+' BUSD Transfer from/to',len(top)==3 and '0x'+top[1][-40:].lower()==POOL and '0x'+top[2][-40:].lower()==OWNER)
   transfer.append(int(lg['data'],16))
  if a==POOL and top[0].lower()==CLAIM:
   ck(str(pid)+' claim event pool/recipient',len(top)==3 and int(top[1],16)==pid and '0x'+top[2][-40:].lower()==OWNER)
   claim.append(int(lg['data'],16))
 ck(str(pid)+' one matching claim and BUSD transfer',len(claim)==len(transfer)==1 and claim[0]==transfer[0])
 decoded.append({'pool_id':pid,'tx_hash':h,'block_number':bn,'block_hash':b['hash'],'utc':datetime.fromtimestamp(int(b['timestamp'],16),timezone.utc).isoformat(),'amount_raw':str(transfer[0]),'amount_busd':format(Decimal(transfer[0])/10**18,'f'),'caller':OWNER,'recipient':OWNER})
ck('all six original pools',sorted(x['pool_id'] for x in decoded)==[19,20,21,125,126,127])
total=sum(int(x['amount_raw']) for x in decoded)
ck('exact original BUSD total',total==903794346419582485370326)
reported=load('verified_original_mintlayer_claims.json')
ck('reported total matches independent',reported['total_raw']==str(total))
for d in decoded:
 r=next(x for x in reported['rows'] if x['pool_id']==d['pool_id'])
 ck(str(d['pool_id'])+' report fields match independent',all(r[k]==v for k,v in d.items()))
result={'verdict':'PASS','scope':'All six original Mintlayer BSC withdrawal transactions: exact request/response integrity; adjacent historical false/true flags; independent calldata, successful receipt, canonical BUSD Transfer and fundraising claim event decode; independent timestamps from full BSC block headers.','rows':decoded,'total_raw':str(total),'total_busd':format(Decimal(total)/10**18,'f'),'historical_state_points_checked':len(states),'checks_passed':len(checks),'checks':checks,'source_hashes':hashes,'limits':['This proves actual pool withdrawals and receipt by address 77bf on 3–4 November 2022. It does not identify the human signer, establish onward disposition, contractual entitlement or misappropriation.','Historical pool flags were used to locate blocks; the money movement is separately supported by successful receipts from the official BNB RPC endpoint.']}
(O/'independent_original_busd.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','total_busd','historical_state_points_checked','checks_passed']},indent=2))
