#!/usr/bin/env python3
"""Independent offline review of the original-BUSD owner's two onward windows."""
from pathlib import Path
from collections import defaultdict
from decimal import Decimal, getcontext
from datetime import datetime,timezone
import json,hashlib
getcontext().prec=80
P=Path(__file__).resolve().parents[1]/'original_busd_onward'
OUT=Path(__file__).resolve().parent
OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
POOL='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'
W1991='0x1991e27e2908847c0274a662eb6675002e8386d0'
W14='0x14c840ec5b8cf28712e7e53391c8c860ba7a7b25'
BINANCE='0x8894e0a0c962cb723c1976a4421c95949be2d4e3'
BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56'
TOPIC='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
checks=[];hashes={}
def ck(n,c):
 checks.append({'check':n,'pass':bool(c)})
 if not c:raise AssertionError(n)
def read(n):
 b=(P/n).read_bytes();hashes[n]=hashlib.sha256(b).hexdigest();return json.loads(b)
def dec(v):return format(Decimal(v)/10**18,'f')
def capture(stem):
 meta=read(stem+'.receipt.json');data=read(stem+'.response');qs={q['id']:q for q in meta['request']}
 ck(stem+' successful HTTP and capture hash',meta['status']==200 and meta['sha256']==hashes[stem+'.response'])
 ck(stem+' exact response IDs',len(data)==len(qs) and {x['id'] for x in data}==set(qs))
 out=[]
 for r in data:
  ck(stem+' result returned '+str(r['id']),'result' in r and r['result'] is not None)
  out.append((qs[r['id']],r['result']))
 return out
windows=read('windows.json')
owner=read('verified_owner_onward.json')
inter=read('verified_intermediary_onward.json')
targets=sorted(set(r['to'] for r in owner['rows'] if r['direction']=='out'))
ck('six distinct direct recipient targets',len(targets)==6 and inter['target_addresses']==targets)
ck('same two windows',owner['windows']==inter['windows']==windows and len(windows)==2)
headers={};receipts={};txs={}
for pattern,method,store in [('headers_*.response','eth_getBlockByNumber',headers),('intermediary_headers_*.response','eth_getBlockByNumber',headers),('receipts_*.response','eth_getTransactionReceipt',receipts),('intermediary_receipts_*.response','eth_getTransactionReceipt',receipts),('transactions_*.response','eth_getTransactionByHash',txs),('intermediary_transactions_*.response','eth_getTransactionByHash',txs)]:
 for f in sorted(P.glob(pattern)):
  for q,r in capture(f.stem):
   ck(f.name+' request method',q['method']==method)
   key=int(q['params'][0],16) if method=='eth_getBlockByNumber' else q['params'][0].lower()
   actual=int(r['number'],16) if method=='eth_getBlockByNumber' else (r.get('transactionHash') or r['hash']).lower()
   ck(f.name+' returned requested identity',key==actual)
   if key in store:ck(f.name+' repeated returned identity agrees',store[key]==r)
   store[key]=r
for w in windows:
 first=headers[w['first_block']];last=headers[w['last_block']];after=headers[w['after_block']]
 start=int(first['timestamp'],16);cut=int(datetime.fromisoformat(w['cutoff_utc']).timestamp())
 ck('raise '+str(w['raise'])+' exact 24-hour boundary',cut-start==86400 and w['after_block']==w['last_block']+1 and int(last['timestamp'],16)<=cut<int(after['timestamp'],16))

def logs(prefix,addresses):
 unique={}
 for w in windows:
  coverage=defaultdict(list)
  for q,result in capture(prefix+'_logs_raise'+str(w['raise'])):
   ck(prefix+' log query method',q['method']=='eth_getLogs')
   arg=q['params'][0];topics=arg['topics'];start=int(arg['fromBlock'],16);end=int(arg['toBlock'],16)
   ck(prefix+' token/topic',arg['address'].lower()==BUSD and topics[0].lower()==TOPIC)
   direction='in' if len(topics)==3 and topics[1] is None else 'out'
   filt=topics[2] if direction=='in' else topics[1]
   if isinstance(filt,str):filt=[filt]
   ck(prefix+' exact address filter',sorted('0x'+t[-40:].lower() for t in filt)==sorted(addresses))
   coverage[direction].append((start,end))
   for l in result:
    ck(prefix+' returned log belongs to interval',start<=int(l['blockNumber'],16)<=end)
    key=(l['transactionHash'].lower(),int(l['logIndex'],16))
    if key in unique:ck(prefix+' repeated log exact match',unique[key]==l)
    unique[key]=l
  for direction in ['in','out']:
   intervals=sorted(coverage[direction])
   ck(prefix+' '+direction+' contiguous coverage',intervals[0][0]==w['first_block'] and intervals[-1][1]==w['last_block'] and all(a[1]+1==b[0] for a,b in zip(intervals,intervals[1:])))
 return sorted(unique.values(),key=lambda l:(int(l['blockNumber'],16),int(l['logIndex'],16)))
ownerlogs=logs('owner',[OWNER]);interlogs=logs('intermediary',targets)
ck('owner 18 raw log events',len(ownerlogs)==18)
ck('intermediary 19 raw log events',len(interlogs)==19)
def decode(ls):
 rows=[]
 for l in ls:
  h=l['transactionHash'].lower();bn=int(l['blockNumber'],16);r=receipts[h];tx=txs[h];hd=headers[bn];t=l['topics']
  ck(h+' successful BSC receipt',int(r['status'],16)==1 and int(tx['chainId'],16)==56)
  ck(h+' receipt transaction header and log same block',hd['hash'].lower()==r['blockHash'].lower()==tx['blockHash'].lower()==l['blockHash'].lower() and int(r['blockNumber'],16)==bn)
  ck(h+' exact log in receipt',l in r['logs'])
  ck(h+' canonical BUSD transfer',l['address'].lower()==BUSD and len(t)==3 and t[0].lower()==TOPIC)
  fr='0x'+t[1][-40:].lower();to='0x'+t[2][-40:].lower();v=int(l['data'],16)
  if fr!=POOL:
   inp=tx['input']
   ck(h+' direct transfer calldata',tx['from'].lower()==fr and tx['to'].lower()==BUSD and inp[:10]=='0xa9059cbb' and len(inp)==138 and '0x'+inp[10:74][-40:].lower()==to and int(inp[74:138],16)==v)
  rows.append({'tx_hash':h,'block_number':bn,'block_hash':hd['hash'],'utc':datetime.fromtimestamp(int(hd['timestamp'],16),timezone.utc).isoformat(),'from':fr,'to':to,'amount_raw':str(v),'amount_busd':dec(v),'log_index':int(l['logIndex'],16)})
 return rows
orows=decode(ownerlogs);irows=decode(interlogs)
for name,actual,reported in [('owner',orows,owner['rows']),('intermediary',irows,inter['rows'])]:
 ck(name+' exact reported row count',len(actual)==len(reported))
 for a in actual:
  rep=next(r for r in reported if r['tx_hash']==a['tx_hash'] and r['log_index']==a['log_index'])
  ck(name+' all independently decoded report fields '+a['tx_hash'],all(rep[k]==v for k,v in a.items()))
balances={}
for f in [P/'owner_balance_bounds.response']+sorted(P.glob('intermediary_balances_retry4_*.response')):
 for q,r in capture(f.stem):
  arg=q['params'][0];inp=arg['data'];block=int(q['params'][1],16)
  ck(f.name+' balanceOf request',q['method']=='eth_call' and arg['to'].lower()==BUSD and inp[:10]=='0x70a08231' and len(inp)==74 and len(r)==66)
  addr='0x'+inp[10:][-40:].lower();balances[(addr,block)]=int(r,16)
reconciled=[]
for addr,rows in [(OWNER,orows)]+[(a,irows) for a in targets]:
 for w in windows:
  opened=balances[addr,w['first_block']-1];closed=balances[addr,w['last_block']]
  selected=[r for r in rows if w['first_block']<=r['block_number']<=w['last_block']]
  ins=sum(int(r['amount_raw']) for r in selected if r['to']==addr);outs=sum(int(r['amount_raw']) for r in selected if r['from']==addr)
  ck(addr+' raise '+str(w['raise'])+' historical balance equation',opened+ins-outs==closed)
  running=opened
  for r in selected:
   running+=int(r['amount_raw'])*((r['to']==addr)-(r['from']==addr))
   ck(addr+' running balance nonnegative '+r['tx_hash'],running>=0)
  reconciled.append({'address':addr,'raise':w['raise'],'opening_raw':str(opened),'closing_raw':str(closed),'incoming_raw':str(ins),'outgoing_raw':str(outs)})
ownerouts=[r for r in orows if r['from']==OWNER]
to1991=[r for r in ownerouts if r['to']==W1991]
exchange=[r for r in irows if r['from']==W14 and r['to']==BINANCE]
ck('11 owner outputs total 896370 BUSD',len(ownerouts)==11 and sum(int(r['amount_raw']) for r in ownerouts)==896370*10**18)
ck('four owner transfers to same1991 total267000 BUSD',len(to1991)==4 and sum(int(r['amount_raw']) for r in to1991)==267000*10**18)
ck('two Binance-route sweeps total54370 BUSD',len(exchange)==2 and sorted(int(r['amount_raw']) for r in exchange)==[25000*10**18,29370*10**18])
ck('owner preexisting 0.332 BUSD included',balances[OWNER,windows[0]['first_block']-1]==332011149154053912)
labels=read('endpoint_label_provenance.json')
ck('service-label records name exact Binance endpoint',len(labels['labels'])>=2 and all(x['address'].lower()==BINANCE for x in labels['labels']))
result={'verdict':'PASS','scope':'Two precise 24-hour windows, owner and all six direct recipients, exact canonical BUSD logs, separate official BNB receipts/transactions/headers and archive-state opening/closing balances. No current balance or intervening-period claim.','windows':windows,'owner_events':len(orows),'intermediary_events':len(irows),'owner_outgoing_count':len(ownerouts),'owner_outgoing_BUSD':'896370','owner_to1991_BUSD':'267000','Binance_labeled_endpoint_BUSD':'54370','owner_prior_BUSD':'0.332011149154053912','owner_to1991':to1991,'Binance_route':exchange,'historical_balance_equations':reconciled,'checks_passed':len(checks),'checks':checks,'consumed_sha256':hashes,'label_review':'Exact endpoint and source provenance checked. Explorer label supplied by captured BscScan/Blockscan references; peer performed no new live label retrieval. Root source review remains the independent label-attribution check.','limitations':['All closing balances are historical window-end states, not balances today.','Two 24-hour windows do not cover the gap between them or all later activity. Equal balances at gap boundaries do not prove there was no offsetting activity.','The owner began with 0.332011149154053912 BUSD. Exact exclusive source attribution of every fractional unit of subsequent payments must allow that pre-existing balance.','The 54,370 BUSD is part of the subsequent onward flow, not additional money to add to the original 903,794.346419582485370326 BUSD raised.','The same 1991 address on BSC and Ethereum is a concrete address link across separate ledgers; no bridge or transfer between those chains is inferred here.','Service labels identify an attributed endpoint, not a customer, human signer, legal entitlement, loss, account credit or personal receipt by Laura.']}
(OUT/'onward_peer.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','checks_passed','owner_outgoing_BUSD','owner_to1991_BUSD','Binance_labeled_endpoint_BUSD']},indent=2))
