#!/usr/bin/env python3
"""Independent conservation bound and feasible extremal source allocations."""
from pathlib import Path
from collections import Counter
from decimal import Decimal
import hashlib,json
R=Path(__file__).resolve().parents[2]
O=Path(__file__).resolve().parent
A='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
B='0x1991e27e2908847c0274a662eb6675002e8386d0'
C='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4'
POOL='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf'
M='0xc4922d64a24675e16e1586e3e3aa56c06fabe907'
U='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
hashes={};checks=[]
def ck(n,v):
 checks.append({'check':n,'pass':bool(v)})
 if not v:raise AssertionError(n)
def load(f,w):
 p=R/f;b=p.read_bytes();hashes[f]=hashlib.sha256(b).hexdigest();d=json.loads(b)
 rows=d['result'] if isinstance(d,dict) else d
 if isinstance(d,dict):ck(f+' success',d['status']=='1')
 for r in rows:ck(f+' canonical positive-or-zero row '+r['hash'],r['contractAddress'].lower()==U and r['tokenDecimal']=='6' and w in [r['from'].lower(),r['to'].lower()] and int(r['value'])>=0)
 ck(f+' no duplicate event tuple',max(Counter((r['hash'],r['from'],r['to'],r['value']) for r in rows).values())==1)
 return sorted(rows,key=lambda r:(int(r['blockNumber']),int(r['transactionIndex'])))
def balance(rows,w,end):
 return sum(int(r['value'])*((r['to'].lower()==w)-(r['from'].lower()==w)) for r in rows if int(r['blockNumber'])<end)
arows=load('onchain_pass6/source_bounds/77bf_USDC_history.json',A)
brows=load('onchain_pass6/returned_funds/USDC_history.json',B)
crows=load('onchain_pass4/shared_counterparty/USDC_events.json',C)
ck('source history row counts',(len(arows),len(brows),len(crows))==(13,370,322))
ck('A zero event balance before IAG claims',balance(arows,A,20219016)==0)
ck('B zero event balance before A funding',balance(brows,B,20219026)==0)
ck('C zero event balance before B funding',balance(crows,C,20277548)==0)
periods=[(arows,20219016,20219064),(brows,20219026,20333140),(crows,20277548,20333000)]
unique={}
for rows,lo,hi in periods:
 for r in rows:
  if lo<=int(r['blockNumber'])<=hi and int(r['value'])>0:
   key=(r['hash'],r['from'].lower(),r['to'].lower(),int(r['value']))
   if key in unique:ck('cross-wallet transfer agrees '+r['hash'],unique[key]['blockHash'].lower()==r['blockHash'].lower())
   unique[key]=r
events=sorted(unique.values(),key=lambda r:(int(r['blockNumber']),int(r['transactionIndex'])))
outside=[r for r in events if r['to'].lower() in [A,B,C] and r['from'].lower() not in [A,B,C,POOL]]
funds=[r for r in events if r['to'].lower()==A and r['from'].lower()==POOL]
ck('only two outside positive inputs',len(outside)==2 and all(r['to'].lower()==A for r in outside))
ck('outside total 20 USDC',sum(int(r['value']) for r in outside)==20000000)
ck('IAG pool total exact',len(funds)==2 and sum(int(r['value']) for r in funds)==191393685754)
bridge=[r for r in events if r['from'].lower()==C]
ck('C only two bridge outflows',len(bridge)==2 and all(r['to'].lower()==M for r in bridge) and sum(int(r['value']) for r in bridge)==27100000000)

# Construct feasible source assignments at both limits. This is not a claim of
# actual coin identity, FIFO order, ownership, or a legal tracing convention.
route={(A,B),(B,C),(C,M)}
def allocation(max_outside_to_bridge):
 bal={w:0 for w in [A,B,C]};outside_bal={w:0 for w in [A,B,C]};bridge_outside=0;trace=[]
 for r in events:
  fr=r['from'].lower();to=r['to'].lower();v=int(r['value'])
  if fr in bal:
   ck('scenario has enough tokens '+r['hash'],bal[fr]>=v)
   low=max(0,v-(bal[fr]-outside_bal[fr]));high=min(v,outside_bal[fr])
   prefer_high=((fr,to) in route)==max_outside_to_bridge
   moved=high if prefer_high else low
   bal[fr]-=v;outside_bal[fr]-=moved
  else:moved=0 if fr==POOL else v
  if to in bal:bal[to]+=v;outside_bal[to]+=moved
  if fr==C and to==M:bridge_outside+=moved
  for w in bal:ck('scenario source conservation '+w+' '+r['hash'],0<=outside_bal[w]<=bal[w])
  trace.append({'hash':r['hash'],'from':fr,'to':to,'total_raw':str(v),'outside_source_raw':str(moved)})
 return {'outside_USDC_at_bridge_raw':str(bridge_outside),'IAG_USDC_at_bridge_raw':str(27100000000-bridge_outside),'trace':trace}
lower=allocation(True);upper=allocation(False)
ck('lower bound attainable',lower['outside_USDC_at_bridge_raw']=='20000000' and lower['IAG_USDC_at_bridge_raw']=='27080000000')
ck('upper bound attainable',upper['outside_USDC_at_bridge_raw']=='0' and upper['IAG_USDC_at_bridge_raw']=='27100000000')
result={'verdict':'PASS','interval_USDC':['27080','27100'],'method':'Conservation: only 20 USDC of positive outside funding can be assigned to the 27,100 USDC bridge branch; both endpoints admit nonnegative source allocations consistent with every selected transfer.','scope':'Independently replayed exact canonical-USDC histories, zero starting checkpoints, sole positive incoming sources, shared-wallet matching and all selected path events. Prior bridge-message/receipt verification and IAG project mapping are dependencies, not re-audited here.','conditional_on':'Completeness of the preserved indexed histories. Zero historic balances here are event-derived, not historical balanceOf RPC proofs.','source_hashes':hashes,'checks_passed':len(checks),'checks':checks,'lower_bound_feasible_allocation':lower,'upper_bound_feasible_allocation':upper,'limits':['The interval describes source accounting of bridge funding, not a unique token identity, beneficial ownership, authorization, purpose or loss.','It cannot independently apportion later trading returns or profit, identify Laura, or be combined with original Mintlayer BUSD receipts as one asset flow.']}
(O/'independent_source_bounds.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','interval_USDC','checks_passed']},indent=2))
