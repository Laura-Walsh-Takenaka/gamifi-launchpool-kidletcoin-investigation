# Independent review: original Mintlayer BUSD onward windows

Review date: 7 September 2026. **PASS — 1,002 independent checks.** Earlier peer-review files remain unchanged. This additional review covers the newly added `original_busd_onward` lane only and makes no new network requests.

## Verified amounts and paths

- The owner address `0x77bfe8d704b1948374bf8dab8328a810b2836e66` made **11 BUSD payments totaling 896,370 BUSD** within the two selected 24-hour windows following the first withdrawal in each Mintlayer raise.
- Four payments totaling **267,000 BUSD** went to `0x1991e27e2908847c0274a662eb6675002e8386d0`. This is the exact same hexadecimal address identified in the separate Ethereum USDC/USDT investigation. No bridge or transfer between those chains is inferred.
- Intermediary `0x14c840ec5b8cf28712e7e53391c8c860ba7a7b25` received **29,370 BUSD** directly from 77bf and **25,000 BUSD** from 1991. It sent those exact amounts to `0x8894e0a0c962cb723c1976a4421c95949be2d4e3`, totaling **54,370 BUSD**.
- The two endpoint transfers occurred on **3 November 2022 at 09:38:08 and 10:00:27 UTC**. Their transaction hashes are `0x7e78389fcc5f9a13d23b516dcf2fbdfa836a87a18b6ee10b6afdfac5f3e5464e` and `0x141937386f5dc40948d057b1172a73d55e2caff1b880c5eae7ad6e66a11e5292`.

The lane's primary-explorer provenance identifies 8894 as **Binance 51**. This peer review checked the exact address and the supplied BscScan/Blockscan source records; it did not independently retrieve a live label page. The root investigation's primary-source review supplies that attribution check. The label identifies an attributed service endpoint, not its customer, account credit, human signer or beneficial owner.

## Independent verification scope

`onward_peer.py` starts from preserved raw requests/responses. It binds response IDs to exact requested blocks and transaction hashes, verifies captured content hashes, and independently decodes:

- **18 owner log events:** six fundraising receipts, 11 subsequent payments and one zero-value incoming event.
- **19 intermediary log events:** all canonical BUSD incoming/outgoing events returned for the six direct recipients in the same windows, including transfers between selected recipients.
- Successful official BNB RPC receipts, transaction objects and block headers for every selected event. All direct BUSD transfer arguments agree with sender, recipient and raw transfer-log value.
- Continuous incoming and outgoing log-query coverage across each specified window, including correct canonical token, topic and address filters.
- The two exact 24-hour cutoffs: last included block timestamps are no later than each cutoff, and immediately following block timestamps are later.
- **14 historical state equations:** opening state plus all incoming events minus all outgoing events equals closing state for the owner and each of six recipients in both windows. Every replayed intermediate balance is nonnegative.

In the first window, 1991, 14c840 and f98f each have independently queried zero BUSD opening and closing balances, consistent with their complete returned window event ledgers. These are historical state calls at specified 2022 blocks, not statements of current balances.

## Accounting qualifications

The owner held **0.332011149154053912 BUSD** before the first Mintlayer withdrawal. The owner reconciliation includes that amount. Describing the exact later transfers as exclusively composed of every fractional unit of Mintlayer-origin funds would require allowing this pre-existing amount in source-allocation bounds.

The 54,370 BUSD endpoint flow is part of the already counted onward disposition. It must not be added again to either the 896,370 BUSD owner payments or the original 903,794.346419582485370326 BUSD fundraising receipts.

The two windows do not cover every intervening or later block. Matching owner balances at the gap boundaries prove equal balances, not absence of offsetting transactions in the gap. The owner’s **7,424.678430731639424238 BUSD** and recipients’ reported balances at the second window close are historical states, not funds confirmed to remain today.

No finding here establishes a human signer, payment purpose, contractual entitlement, authorization, loss, or personal receipt by Laura.

## Reproduction

```text
python onchain_pass6/peer_review/onward_peer.py
```

The script writes `onward_peer.json` with all checks, exact critical transfers, fourteen balance equations and consumed evidence hashes. It requires no network and does not modify the originating lane or earlier peer-review deliverables. `onward_peer_SHA256SUMS` covers these three additional review files.
