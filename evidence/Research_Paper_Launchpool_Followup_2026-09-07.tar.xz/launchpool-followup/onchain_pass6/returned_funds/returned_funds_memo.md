# Launchpool connected wallet 1991: disposition after the July returns

Research date: 7 September 2026. Scope: Ethereum address `0x1991e27e2908847c0274a662eb6675002e8386d0` (1991), after the previously verified 21,116.99-USDC return on 18 July 2024 and 58,724.105382-USDT return on 23 July 2024. All dates/times below are UTC. Prior files remain unchanged.

**A new KuCoin deposit route is verified: 1991 paid 105,907.029506 USDT to a second specifically labeled deposit address, which forwarded the whole amount to KuCoin 18 nine minutes later.** This payment followed the USDT return plus two substantial new receipts and a pre-existing balance. It is therefore a documented disposition of the combined wallet balance, not a claim that all 105,907.029506 came from BAMBOO or fundraising.

## 1. The first USDC phase now has a complete bounded event ledger

The public Blockscout account/token endpoint returned 370 canonical Circle-USDC Transfer entries from block 0 through block **20,376,000**. All rows name the exact USDC contract, six decimals, the queried wallet and blocks within the limit. Exact duplicate rows are absent; separate events in the same transaction are retained. Their ordered raw-integer ledger stays nonnegative and ends at zero.

The ledger reaches zero on **1 July 2024, 14:33:23**, after 1,360.027048 USDC went to 2c94 (transaction `0x9882640ddd066814508e773e297bb2bb2069b1c3180ff5af963a0d7f32e7f558`, block 20,212,289). From that point until the first return on 18 July, the only positive USDC inflows are **10 and 150,000 USDC from 77bf on 2 July**. The previously documented 138,550 USDC of subsequent payments therefore leaves an event balance of 11,460 USDC.

| 1991 event | USDC event balance afterward |
|---|---:|
| Before July 2 receipts | 0 |
| July 2: total 150,010 from 77bf | 150,010 |
| After previously documented July 3–16 payments | 11,460 |
| July 18 11:35:11: 21,116.99 returned from 183600 | 32,576.99 |
| July 18 11:37:47: 32,500 sent to 2c94 | 76.99 |
| July 24 09:58:47: 318,115.194647 from d91e | 318,192.184647 |
| July 24 10:00:23: 318,192.184647 sent to 0008 | 0 |

This closes the previous **missing starting event balance at 1991** for the narrow July 2–18 interval. It does not on its own settle all upstream attribution: 77bf's two separate 10-USDC lookalike-address receipts remain part of the original upstream accounting, and subsequent returns and new receipts must be explicitly included. A complete event ledger is not the same as an independently successful historical `balanceOf` call. The historical calls here returned dRPC free-plan timeouts and HTTP 502 at a second provider; no unavailable state response was treated as zero.

## 2. The 32,500-USDC payment was forwarded after one minute

At **11:37:47 on 18 July**, 1991 sent **32,500 USDC** to reused recipient `0x2c94c30bdd9aa400df9d2347ee16094ab1858941` (2c94), 2 minutes 36 seconds after receiving the first return. At **11:38:47**, 2c94 sent **32,500 USDC** to `0x47da741e9fada9aff75c0f2df69e9cd2b216b225` (47da).

Separately, at **11:40:35** 1991 sent its then remaining **8,720.1948 USDT** to 2c94. At **11:41:35**, 2c94 forwarded **8,720.1948 USDT** to 47da. That USDT preceded the July 23 BAMBOO return; it must not be described as part of that later receipt. Both assets moved through 2c94 separately. All four transfers have successful independent Ethereum RPC receipts matching the exact token contract, full recipient address and raw amount.

The captured Etherscan pages for 2c94 and 47da have generic address titles; no direct service name tag was observed. Payment purpose and ultimate beneficiary remain unresolved. This lane stops at 47da.

## 3. The later USDT balance was distributed and then deposited at KuCoin

The corresponding bounded Blockscout history contains **1,577 canonical USDT Transfer entries**. It is ordered, contains no exact duplicate event rows and reconciles to zero at the same end block. Immediately before the July 23 return, 1991's USDT event balance was **8,375.183313**.

| UTC event | USDT change | Event balance |
|---|---:|---:|
| July 23 14:32:47: return from 183600 | +58,724.105382 | 67,099.288695 |
| July 23 14:42:35: payment to 188b | −21,882.27 | 45,217.018695 |
| July 24 09:13:11: payment to 2c94 | −4,000 | 41,217.018695 |
| July 24 09:16:23: receipt from MEXC 1 | +14,690.010811 | 55,907.029506 |
| July 24 09:29:35: receipt from 33b2 | +50,000 | 105,907.029506 |
| July 24 09:32:23: payment to KuCoin Deposit 327a | −105,907.029506 | 0 |

Exact full addresses:

- 188b: `0x188b1922d1961500cbd30066029590cb20dbd817`.
- MEXC 1: `0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88`; service attribution was independently preserved in prior passes.
- 33b2: `0x33b2a0c06629f3faa7d0356e7c4c05e804ddbf32`.
- **KuCoin Deposit 327a**: `0x327ae1e62fdea32763d6e5de1b08ebe84edff303`.
- **KuCoin 18**: `0x83c41363cbee0081dab75cb841fa24f3db46627e`.

The 327a deposit is transaction `0x5e84f9d81c5b78e0f8e16b3bf8826862fee7ede8ceb50195969fd8d66d76fa2a`. At **09:41:23**, 327a forwarded **105,907.029506 USDT** to KuCoin 18, transaction `0x2a25157306ed6979467c99ab15bec782594eb95dc979372160b3292e158c38ba`. Both successful raw receipts match the exact amounts and addresses. The captured Etherscan pages explicitly label the deposit address and the destination hot wallet. This is a different deposit address from the earlier documented USDC route through 4d0d; it supplies another exact deposit-account records lead. Common use of KuCoin or its hot wallet does not identify a common customer.

The other selected payments also have verified onward hops. 188b forwarded **21,882.27 USDT** at **14:49:47 on 23 July** to `0x0d560ac1b578ee5ac815a0e096cac37cb4c0eb5e` (0d56), 7 minutes 12 seconds after receipt. The 4,000-USDT payment through 2c94 reached 47da at **09:14:11 on 24 July**, one minute after receipt. Both endpoints have generic Etherscan address titles. These are exact transfers, with no service attribution or human ownership inference.

## 4. The later USDC sweep also has a bounded next hop

After the new **318,115.194647-USDC** receipt from `0xd91efec7e42f80156d1d9f660a69847188950747`, 1991 combined it with its **76.99-USDC** residual and paid **318,192.184647 USDC** to `0x0008458f168399ee46412c1cff180edf1ec661a7` (0008) at **10:00:23 on 24 July**. At **15:36:59**, 0008 sent **318,192.18 USDC** to `0xd5417e96dd04363c675e41ee6f30bf788412c719` (d541).

The two transferred amounts differ by **0.004647 USDC**, but 0008 also had other receipts and payments; this figure is an amount comparison, not its proved remaining balance. All three transfers—the new receipt, payment to 0008 and payment to d541—are independently matched to successful canonical-USDC RPC logs. The receipt from d91e arose from a contract method (selector `0xe6930a22`); its payment is verified from the Transfer log, while the method's arguments were not decoded. The onward 0008 and d541 pages have generic titles. No further hop is asserted.

## 5. Lookalike rows were rejected

The unfiltered bounded 188b and 0008 responses include token rows with visually similar tickers and recipient addresses. Seven entries name other token contracts, and one canonical-USDT entry transfers zero. All eight are explicitly excluded from cash tracing in `rejected_lookalike_events.json`. In particular, the real 188b payout went to **0d560ac1…c0eb5e**; search-indexed lookalikes containing **0d561775…3eb5e** or **0d566afd…1eb5e** are not the cash recipient. These rows are not evidence of subject-controlled wallets or additional cash transfers.

## Evidence, reproducibility and limits

`returned_funds_summary.json` and `verified_transfers.json` contain all selected identifiers and balances. `USDC_event_ledger.json` and `USDT_event_ledger.json` preserve every indexed canonical-token event with before/after raw balances. `USDC_first_phase_inflows.json` isolates the only two positive incoming rows for the narrow first phase. `analyze_returned_funds.py` reruns the canonical-address/amount checks, ledger ordering, exact duplicate checks, six critical balance checkpoints, receipt/log comparisons and selected token-call input decoding offline. All **15 selected transfers** have successful raw receipt checks; **14** also have straightforward `transfer`/`transferFrom` arguments decoded from independently captured indexer transaction input.

Each public request has an exact `.request.json` and contemporaneous `.receipt.json` recording the endpoint/body, UTC times, status and SHA-256. Initial Publicnode calls returned null for some receipts; dRPC succeeded, including the final KuCoin sweep on one single-call retry. Neither null nor failed historical calls were interpreted as absent activity. The explorer title records preserve the observed labels independently of complete HTML retention. The file hash manifest covers preserved raw and derived evidence.

No human controller, exchange customer, legal entitlement, payment authorization or personal receipt by Laura is established by these transfers. The new evidence precisely identifies cash movement, a second KuCoin deposit address and the narrow pre-return accounting gap that can now be closed. No private account was accessed, signature submitted, funds moved or third party contacted.
