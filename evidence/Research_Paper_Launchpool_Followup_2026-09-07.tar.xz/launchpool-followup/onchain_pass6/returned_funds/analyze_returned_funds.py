#!/usr/bin/env python3
"""Reproduce bounded USDC/USDT event accounting and selected receipt matches offline."""
from pathlib import Path
import json,csv,re,hashlib,datetime
from decimal import Decimal
P=Path(__file__).resolve().parent
A='0x1991e27e2908847c0274a662eb6675002e8386d0'
TOK={'USDC':'0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48','USDT':'0xdac17f958d2ee523a2206206994597c13d831ec7'}
TRANS='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
def fmt(v):return format(Decimal(v)/10**6,'f')
def read(n):return json.loads((P/n).read_text())
def simple(x):
 return {'tx_hash':x['hash'],'block':int(x['blockNumber']),'block_hash':x['blockHash'],'transaction_index':int(x['transactionIndex']),'utc':datetime.datetime.fromtimestamp(int(x['timeStamp']),datetime.timezone.utc).isoformat(),'from':x['from'].lower(),'to':x['to'].lower(),'token':x['contractAddress'].lower(),'value_raw':x['value'],'amount':fmt(int(x['value'])),'input':x['input']}
ledger={};byhash={};checks=[]
for name,t in TOK.items():
 obj=read(name+'_history.json');assert obj['status']=='1';r=obj['result'];assert len(r)=={'USDC':370,'USDT':1577}[name]
 assert all(x['contractAddress'].lower()==t and x['tokenDecimal']=='6' and int(x['blockNumber'])<=20376000 and A in (x['from'].lower(),x['to'].lower())for x in r)
 assert [(int(x['blockNumber']),int(x['transactionIndex'])) for x in r]==sorted((int(x['blockNumber']),int(x['transactionIndex'])) for x in r)
 assert len({(x['hash'],x['from'],x['to'],x['value'])for x in r})==len(r),'Exact duplicate event row found'
 rows=[];bal=0
 for x in r:
  y=simple(x);y['balance_before_raw']=str(bal);y['balance_before']=fmt(bal)
  bal+=int(x['value'])*((x['to'].lower()==A)-(x['from'].lower()==A))
  y['balance_after_raw']=str(bal);y['balance_after']=fmt(bal);rows.append(y);byhash.setdefault(x['hash'],[]).append(y)
 assert min(int(x['balance_after_raw'])for x in rows)>=0
 assert bal==0
 ledger[name]=rows
 (P/(name+'_event_ledger.json')).write_text(json.dumps(rows,indent=2))
 checks.append({'check':name+' canonical bounded ordered unique events and nonnegative balance','passed':True,'rows':len(rows),'end_balance':fmt(bal)})
allrows=[]
for name in ['2c94','188b','327a','0008']:
 for x in read(name+'_july.json')['result']:
  if x['contractAddress'].lower()in TOK.values():allrows.append(simple(x))
for rows in ledger.values():allrows+=rows
selected=read('selected_hashes.json');receipt_map={};rpc_sources={}
for f in list(P.glob('receipts_[0-9].json'))+list(P.glob('receipts_drpc_[0-9].json'))+list(P.glob('receipt_kucoin_sweep_retry.json')):
 o=json.loads(f.read_text());o=o if isinstance(o,list)else[o]
 for q in o:
  if q.get('result'):
   r=q['result'];receipt_map[r['transactionHash'].lower()]=r;rpc_sources[r['transactionHash'].lower()]=f.name
verified=[];unverified=[]
for h in selected:
 candidates=[x for x in allrows if x['tx_hash']==h and int(x['value_raw'])>0]
 assert candidates
 x=candidates[0];r=receipt_map.get(h)
 if not r:unverified.append(h);continue
 assert r['status']=='0x1' and int(r['blockNumber'],16)==x['block'] and r['blockHash'].lower()==x['block_hash'].lower()
 matches=[l for l in r['logs']if l['address'].lower()==x['token'] and l['topics'][0].lower()==TRANS and '0x'+l['topics'][1][-40:].lower()==x['from']and'0x'+l['topics'][2][-40:].lower()==x['to']and int(l['data'],16)==int(x['value_raw'])]
 assert len(matches)==1
 # Match token-transfer calldata captured independently by Blockscout.
 d=x['input'].lower();sel=d[:10];words=[d[i:i+64]for i in range(10,len(d),64)]
 if sel=='0xa9059cbb':assert '0x'+words[0][-40:]==x['to']and int(words[1],16)==int(x['value_raw'])and r['from'].lower()==x['from']
 elif sel=='0x23b872dd':assert '0x'+words[0][-40:]==x['from']and'0x'+words[1][-40:]==x['to']and int(words[2],16)==int(x['value_raw'])
 else:assert h=='0x89b21ce8cfea54d22729ec067c2ab7afe2740186eeb4e1c4f8060fee703a74e7' # Contract-method payment: Transfer receipt independently verifies cash; arguments not decoded.
 if sel in ('0xa9059cbb','0x23b872dd'):assert r['to'].lower()==x['token']
 verified.append({**x,'receipt_file':rpc_sources[h],'log_index':int(matches[0]['logIndex'],16),'receipt_success':True,'calldata_match':sel in ('0xa9059cbb','0x23b872dd'),'calldata_selector':sel})
(P/'verified_transfers.json').write_text(json.dumps(verified,indent=2))
with (P/'verified_transfers.csv').open('w')as f:
 keys=['utc','token','amount','from','to','tx_hash','block','receipt_file','log_index'];w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(verified)
expected={
 '0x9882640ddd066814508e773e297bb2bb2069b1c3180ff5af963a0d7f32e7f558':('1360.027048','0'),
 '0xd24120f60683e7e27ed0376e219f4de61b840aee28e72343e40bef1ba6377668':('11460','32576.99'),
 '0xdae838abc3a146ed855c6221435d947a459deea79f3f25390a981974c347470b':('32576.99','76.99'),
 '0x6eceebc587e9f72c31e0b13c86c24199f963fd3a259b9237e947441c08ae1c02':('318192.184647','0'),
 '0x7ae7223ebfbeb9c0a06f34342c1e15f1a068c7feae454548d170d2f8ac16fd43':('8375.183313','67099.288695'),
 '0x5e84f9d81c5b78e0f8e16b3bf8826862fee7ede8ceb50195969fd8d66d76fa2a':('105907.029506','0')}
points=[]
for h,(before,after)in expected.items():
 x=byhash[h][0];assert Decimal(x['balance_before'])==Decimal(before)and Decimal(x['balance_after'])==Decimal(after);points.append(x)
positive=[x for x in ledger['USDC'] if 20212289<x['block']<20333141 and x['to']==A and int(x['value_raw'])>0]
assert len(positive)==2 and sum(int(x['value_raw'])for x in positive)==150010000000
assert all(x['from']=='0x77bfe8d704b1948374bf8dab8328a810b2836e66'for x in positive)
(P/'USDC_first_phase_inflows.json').write_text(json.dumps(positive,indent=2))
rejected=[]
for name in ['188b','0008']:
 for x in read(name+'_july.json')['result']:
  if x['contractAddress'].lower()not in TOK.values()or int(x['value'])==0:
   rejected.append({'source_file':name+'_july.json','tx_hash':x['hash'],'token_contract':x['contractAddress'],'display_symbol':x['tokenSymbol'],'raw_amount':x['value'],'from':x['from'],'to':x['to'],'reason':'Different token contract; excluded from real USDC/USDT trail'if x['contractAddress'].lower()not in TOK.values()else'Zero-value canonical transfer; no cash moved'})
(P/'rejected_lookalike_events.json').write_text(json.dumps(rejected,indent=2))
# The distributable evidence omits complete third-party HTML. Preserve captured factual title records when HTML is unavailable.
labels=read('explorer_label_records.json') if (P/'explorer_label_records.json').exists() else []
for f in sorted(P.glob('*_address.html')):
 s=f.read_text();title=re.search(r'<title>(.*?)</title>',s,re.S).group(1).strip();req=read(f.name+'.request.json');rec=read(f.name+'.receipt.json')
 labels=[x for x in labels if x['file']!=f.name]
 labels.append({'file':f.name,'url':req['url'],'retrieved_utc':rec['finished_utc'],'source_sha256':rec['sha256'],'exact_title':title,'qualification':'Explorer attribution; no customer or human controller identified'})
(P/'explorer_label_records.json').write_text(json.dumps(labels,indent=2))
summary={'scope':'Ethereum 1991 token event census block0 through20376000; selected July18-24 onward payments plus one consequential hop','checks':checks,'checkpoints':points,'only_positive_USDC_inflows_before_return':positive,'selected_receipts_verified':len(verified),'selected_receipts_missing':unverified,'label_records':labels,'rejected_lookalike_events':len(rejected),'historical_state_status':'Three dRPC calls returned free-plan timeouts; the Llama batch returned HTTP 502. These are event balances, not successful historical balanceOf results.','limits':['Blockscout indexed Transfer-event census, not an independent full-chain log scan','Canonical token/address matching prevents lookalike token/address promotion','Receipt plus captured indexer calldata verify selected transactions; unverified hashes explicitly listed','Existing balances and later third-party receipts combine with returns; no legal entitlement, human control, sale execution or exclusive fundraising attribution inferred','One extra hop only; generic unlabeled destination endpoints remain unidentified']}
(P/'returned_funds_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'ledger_checks':checks,'checkpoints':len(points),'verified_receipts':len(verified),'missing':unverified,'rejected_lookalikes':len(rejected)},indent=2))
