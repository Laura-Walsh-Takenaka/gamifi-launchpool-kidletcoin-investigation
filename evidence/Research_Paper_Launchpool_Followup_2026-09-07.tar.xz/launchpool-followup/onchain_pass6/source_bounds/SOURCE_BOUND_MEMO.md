# Base funding: a conditional conservation bound

The newly completed USDC history materially narrows the earlier source-attribution gap. **Given the retained event histories, between 27,080 and 27,100 USDC of the 27,100 USDC bridged to Base came through the identified IAG-reward fundraising withdrawals.** This is a balance-conservation interval, not a FIFO or proportional allocation and not identification of distinct token units.

The recorded sequence is:

1. The administrative wallet `77bf` has an event-derived USDC balance of zero immediately before the two July 2, 2024 IAG-pool withdrawals totaling **191,393.685754 USDC**.
2. Its only additional positive USDC receipts in the distribution interval are the two already documented **10-USDC** lookalike-address payments. Those **20 USDC** are conservatively treated as an outside source, with no affiliation assumed.
3. `77bf` pays **10 + 150,000 USDC** to `1991`. The newly complete bounded `1991` ledger reaches zero on July 1 and has no other positive incoming USDC before the July 18 return.
4. `1991` pays `183600` **2,100 + 25,000 USDC**. The latter wallet's retained complete USDC ledger is zero before those receipts; it receives no other positive USDC in that interval and transfers both amounts in full to Circle's Ethereum token-minter contract. The corresponding Base mints were verified in pass 4.

Even if all **20 USDC** of outside funding are allocated to this selected branch, the remaining **27,080 USDC** must come from the identified fundraising receipts under the captured histories. Assigning the 20 USDC to other contemporaneous outflows gives the upper bound of **27,100 USDC**. This updates the previous unbounded commingling uncertainty for the initial Base funding. Later returns and additional receipts remain separately reconciled; the bound does not assign trading profits or investor entitlements.

## Evidence and limits

The new canonical-USDC query for `77bf` returned **13 events, 11 positive**, through block 20,333,000; its positive records match the earlier complete explorer census. The independently acquired `1991` history contains 370 events through block 20,376,000. For `183600`, the calculation uses the already preserved complete 322-event history. A fresh bounded request for that wallet returned HTTP 429 and was not retried; no new result is claimed from that response.

All arithmetic uses raw six-decimal USDC integers. `reconcile_source_bounds.py` independently filters the exact token, verifies zero starting event balances, asserts the absence of other positive inputs in the relevant intervals, matches shared transaction hashes, and writes `source_bounds.json` with source hashes and exact source rows.

These historical balances are reconstructed from indexed events, not newly successful historical state reads. The interval is conditional on completeness of those records. It is not a legal tracing rule, does not identify a human signer or company mandate, and does not establish that trading was authorized or that the returns belong to particular investors. The IAG-reward pool receipts remain separate from original Mintlayer BUSD and the ML reserves.
