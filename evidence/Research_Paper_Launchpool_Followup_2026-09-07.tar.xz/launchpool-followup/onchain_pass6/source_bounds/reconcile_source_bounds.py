"""Offline conservation bound using exact canonical-USDC event records; no FIFO assumption."""
from pathlib import Path
import json,hashlib
from decimal import Decimal
P=Path(__file__).resolve().parent;R=P.parents[1]
A='0x77bfe8d704b1948374bf8dab8328a810b2836e66';B='0x1991e27e2908847c0274a662eb6675002e8386d0';C='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4';U='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';F='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf';M='0xc4922d64a24675e16e1586e3e3aa56c06fabe907'
def load(s):
 p=R/s;d=json.loads(p.read_text());rows=d['result'] if isinstance(d,dict) else d
 if isinstance(d,dict):assert d['status']=='1'
 for x in rows:assert x['contractAddress']==U and x['tokenDecimal']=='6'
 rows=sorted(rows,key=lambda x:(int(x['blockNumber']),int(x['transactionIndex'])))
 return rows,{'file':s,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'events':len(rows)}
a,sa=load('onchain_pass6/source_bounds/77bf_USDC_history.json');b,sb=load('onchain_pass6/returned_funds/USDC_history.json');c,sc=load('onchain_pass4/shared_counterparty/USDC_events.json')
def delta(x,w):return int(x['value'])*((x['to']==w)-(x['from']==w))
def before(rows,w,block):return sum(delta(x,w) for x in rows if int(x['blockNumber'])<block)
def fmt(v):return str(Decimal(v)/10**6)
start=20219016;last77=20219064;return_block=20333141
assert before(a,A,start)==0
j=[x for x in a if start<=int(x['blockNumber'])<=last77 and int(x['value'])>0]
fund=[x for x in j if x['to']==A and x['from']==F];other=[x for x in j if x['to']==A and x['from']!=F];to1991=[x for x in j if x['from']==A and x['to']==B]
funded=sum(int(x['value']) for x in fund);unknown=sum(int(x['value']) for x in other);received=sum(int(x['value']) for x in to1991)
assert len(fund)==2 and funded==191393685754 and len(other)==2 and unknown==20000000 and received==150010000000
first1991=min(int(x['blockNumber']) for x in to1991);assert before(b,B,first1991)==0
period=[x for x in b if first1991<=int(x['blockNumber'])<return_block and int(x['value'])>0]
inflows=[x for x in period if x['to']==B];assert len(inflows)==2 and {x['hash'] for x in inflows}=={x['hash'] for x in to1991}
tobridge=[x for x in period if x['from']==B and x['to']==C];assert len(tobridge)==2
bridged=sum(int(x['value']) for x in tobridge);assert bridged==27100000000
firstC=min(int(x['blockNumber']) for x in tobridge);lastC=20333000
assert before(c,C,firstC)==0
cp=[x for x in c if firstC<=int(x['blockNumber'])<=lastC and int(x['value'])>0]
assert len(cp)==4
cin=[x for x in cp if x['to']==C];cout=[x for x in cp if x['from']==C]
assert {x['hash'] for x in cin}=={x['hash'] for x in tobridge}
assert all(x['to']==M for x in cout) and sum(int(x['value']) for x in cout)==bridged
assert sum(delta(x,C) for x in cp)==0
# At most the entire20-USDC outside contribution can be assigned to this selected27,100 outflow.
low=bridged-unknown;high=bridged
assert low==27080000000
out={'method':'Conservation interval; allocate up to all20USDC of observed non-fundraising inflows to the selected bridge branch. No FIFO, last-in-first-out or proportional attribution imposed.','conditional_on':'Completeness of retained canonical-USDC event histories. Historical account states are reconstructed from events, not fresh successful balanceOf calls.','sources':[sa,sb,sc],'77bf_pre_fundraising_event_balance_USDC':'0','IAG_pool_USDC_receipts':fmt(funded),'other_USDC_inflows':fmt(unknown),'77bf_to1991_USDC':fmt(received),'1991_event_balance_before_receipts_USDC':'0','1991_other_positive_USDC_inflows_before_first_return':0,'183600_event_balance_before_bridge_funding_USDC':'0','183600_other_positive_USDC_inflows_before_first_return':0,'Base_bridge_funding_USDC':fmt(bridged),'IAG_pool_origin_conservation_interval_USDC':[fmt(low),fmt(high)],'source_rows':{'fundraising':fund,'other_inflows':other,'to1991':to1991,'to183600':tobridge,'bridge_burn_transfers':cout},'fresh_183600_query':'HTTP429; no retry. Bound uses preserved complete322event prior capture, including its exact July events.','limits':['Does not identify distinct physical token units or a legal tracing rule.','Does not establish investor entitlement, authorization, human signer or personal profit.','IAG-reward fundraising pool receipts are separate from original Mintlayer BUSD and ML reserves.','Later return/profit allocation cannot be assigned by this funding bound alone.']}
(P/'source_bounds.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['source_rows','sources']},indent=2))
