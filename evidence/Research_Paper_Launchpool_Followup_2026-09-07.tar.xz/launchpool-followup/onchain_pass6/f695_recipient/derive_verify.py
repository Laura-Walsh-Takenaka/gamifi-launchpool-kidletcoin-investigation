#!/usr/bin/env python3
"""Offline reproduction from retained public responses; --check makes no writes."""
from pathlib import Path
from decimal import Decimal
from collections import defaultdict
import json,hashlib,re,csv,sys,datetime
P=Path(__file__).resolve().parent
A='0xf695f1d1688698abc97b2e5937ba24934561aae9'
S='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4'
R='0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921'
K='0x8e21157932ecd417c557b4c975bd3e89d8ea896e'
G='0xb23360ccdd9ed1b15d45e5d3824bb409c8d7c460'
TOKEN='0xdac17f958d2ee523a2206206994597c13d831ec7'
TOPIC='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
def j(name): return json.loads((P/name).read_text())
def units(v,d=6): return format(Decimal(v)/Decimal(10)**d,'f')
def date(t):return datetime.datetime.fromtimestamp(int(t),datetime.timezone.utc).isoformat()
events=j('f695_USDT_history.json')['result']; normal=j('f695_normal_history.json')['result']; usdc=j('f695_USDC_history.json')['result']
assert len(events)==65 and len(normal)==89 and len(usdc)==2
assert len({x['hash']for x in events})==65
assert all(x['contractAddress']==TOKEN and x['tokenDecimal']=='6' for x in events)
assert events==sorted(events,key=lambda x:(int(x['blockNumber']),int(x['transactionIndex'])))
ledger=[];bal=0;dest=defaultdict(lambda:[0,0])
for x in events:
 before=bal;v=int(x['value']);bal+=v if x['to']==A else -v
 assert bal>=0
 if x['from']==A:dest[x['to']][0]+=1;dest[x['to']][1]+=v
 ledger.append({'tx':x['hash'],'block':int(x['blockNumber']),'timestamp_utc':date(x['timeStamp']),'from':x['from'],'to':x['to'],'USDT':units(v),'balance_before_USDT':units(before),'balance_after_USDT':units(bal)})
assert bal==0
assert sum(int(x['value']) for x in events if x['to']==A)==23722265580
assert dict(dest)=={R:[25,23378068982],K:[2,344196598]}
inputs=[x for x in ledger if x['from']==S];assert len(inputs)==6 and sum(Decimal(x['USDT'])for x in inputs)==Decimal('2975.818225')
cycles=[]
for x in inputs:
 i=ledger.index(x);following=[]
 for y in ledger[i+1:]:
  following.append(y)
  if y['balance_after_USDT']=='0':break
 outs=[y for y in following if y['from']==A];assert len(outs)==1 and outs[0]['to']==R
 otherin=[y for y in following if y['to']==A]
 cycles.append({'input':x,'other_inputs_before_sweep':otherin,'sweep':outs[0],'commingled_with_other_USDT_inputs':bool(otherin),'elapsed_seconds':int(events[ledger.index(outs[0])]['timeStamp'])-int(events[i]['timeStamp'])})
assert cycles[0]['elapsed_seconds']==5244 and not cycles[0]['commingled_with_other_USDT_inputs']
# Collect successful transaction receipts, without assuming the JSON-RPC id is a transaction hash.
receipts={}; receipt_source={}; states={}
for pattern in ['critical_receipts.json','selected_receipts_limited_*.json','alternate_rpc_*.json','current_state_limited_*.json']:
 for p in P.glob(pattern):
  if '.receipt.'in p.name or '.request.'in p.name:continue
  data=json.loads(p.read_text())
  if not isinstance(data,list):continue
  for x in data:
   z=x.get('result')
   if isinstance(z,dict) and 'logs'in z and 'transactionHash'in z:
    receipts[z['transactionHash']]=z;receipt_source[z['transactionHash']]=p.name
   elif isinstance(z,str):states[x['id']]=z
selected=[x for x in events if x['from']==A or x['from']==S];verified=[]
for x in selected:
 tx=x['hash']; rr=receipts.get(tx)
 if rr:
  assert rr['status']=='0x1' and int(rr['blockNumber'],16)==int(x['blockNumber'])
  logs=rr['logs'];source=receipt_source[tx];method='JSON-RPC successful transaction receipt'
 else:
  source=f'null_{tx[2:10]}_transaction.json';txinfo=j(source);assert txinfo['hash']==tx and txinfo['status']=='ok' and txinfo['result']=='success'
  assert txinfo['block_number']==int(x['blockNumber'])
  logjson=j(f'null_{tx[2:10]}_logs.json');assert logjson['next_page_params'] is None
  logs=[]
  for z in logjson['items']:
   logs.append({'address':z['address']['hash'],'topics':z['topics'],'data':z['data']})
  method='Blockscout indexed successful transaction and raw log topics/data; RPC returned null'
 matches=[z for z in logs if z['address'].lower()==TOKEN and z['topics'][0]==TOPIC and '0x'+z['topics'][1][-40:]==x['from'] and '0x'+z['topics'][2][-40:]==x['to'] and int(z['data'],16)==int(x['value'])]
 assert len(matches)==1,(tx,matches)
 # Check independent direct-transfer calldata in normal history, where this address signed the outgoing transaction.
 if x['from']==A:
  nr=[z for z in normal if z['hash']==tx];assert len(nr)==1;data=nr[0]['input'];assert nr[0]['isError']=='0' and nr[0]['to']==TOKEN
  assert data[:10]=='0xa9059cbb' and '0x'+data[10:74][-40:]==x['to'] and int(data[74:138],16)==int(x['value'])
 verified.append({'tx':tx,'method':method,'source_file':source,'from':x['from'],'to':x['to'],'USDT':units(x['value'])})
assert len(verified)==33
assert sum(x['method'].startswith('JSON-RPC')for x in verified)==27
assert sorted(int(x['nonce'])for x in normal if x['from']==A)==list(range(30))
assert states['code']=='0x' and int(states['nonce'],16)==30 and int(states['USDT'],16)==0
pin=j('pin_drpc.json')['result'];assert int(pin['number'],16)==25925814
assert sum(int(x['value'])for x in normal if x['from']==G and x['to']==A)==20922180000000000
summary={'subject':A,'source_wallet':S,'USDT_contract':TOKEN,'pin':{'block':int(pin['number'],16),'hash':pin['hash'],'timestamp_utc':date(int(pin['timestamp'],16))},'current_state':{'USDT':units(int(states['USDT'],16)),'ETH':units(int(states['ETH'],16),18),'runtime':states['code'],'transaction_count':int(states['nonce'],16)},'USDT_indexed_history':{'events':len(events),'first_block':int(events[0]['blockNumber']),'last_block':int(events[-1]['blockNumber']),'first_utc':date(events[0]['timeStamp']),'last_utc':date(events[-1]['timeStamp']),'incoming_count':38,'outgoing_count':27,'total_in_USDT':units(23722265580),'total_out_USDT':units(23722265580),'event_ledger_net_USDT':units(bal),'destinations':[{'address':a,'count':v[0],'USDT':units(v[1])}for a,v in dest.items()]},'repeated_source_payments':{'count':6,'total_USDT':'2975.818225','cycles':cycles},'normal_indexed_history':{'rows':89,'outgoing_nonces':'0 through 29 inclusive, matching pinned nonce30','Revolut_1_gas_funder':G,'gas_funder_payments':sum(x['from']==G for x in normal),'gas_funder_total_ETH':'0.02092218','ETH_out_to_Revolut_hot_wallet':units(sum(int(x['value'])for x in normal if x['from']==A and x['to']==R),18),'ETH_out_count':sum(x['from']==A and x['to']==R for x in normal)},'USDC_indexed_history':{'rows':2,'in_USDC':'850.921922','out_USDC':'850.921922','destination':R},'verification':{'selected_edges':33,'successful_RPC_receipts':27,'indexed_success_and_raw_logs_after_null_RPC':6,'all_selected_transfer_topics_amounts_match':True,'historical_state':'No successful historical eth_call: PublicNode requires an archive token. Historical zero checkpoints are reconstructed from token events, not state calls.'},'attribution_limit':'Direct public labels identify service endpoints, not the f695 customer, human signer, account credit, payment purpose, ownership by Laura, or a relation to original Mintlayer BUSD fundraising.'}
# Verify contemporaneous hashes of retained successful response bodies and POST requests.
hashes=0
for p in P.glob('*.receipt.json'):
 r=json.loads(p.read_text());response=P/r['response_file']
 if 'sha256'in r and response.exists():assert hashlib.sha256(response.read_bytes()).hexdigest()==r['sha256'];hashes+=1
 request=j(r['request_file'])
 if request.get('request_body_utf8') is not None:assert hashlib.sha256(request['request_body_utf8'].encode()).hexdigest()==request['request_body_sha256']
report={'status':'PASS','USDT_events':65,'normal_rows':89,'selected_edges':33,'RPC_receipts':27,'indexed_log_fallback_edges':6,'retained_response_hashes_checked':hashes,'scope':'Offline factual integer arithmetic, token topics, calldata and request/response checks; no identity or payment-purpose inference.'}
if '--check' not in sys.argv:
 (P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(P/'verification.json').write_text(json.dumps(report,indent=2)+'\n');(P/'verified_selected_edges.json').write_text(json.dumps(verified,indent=2)+'\n');(P/'USDT_ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
 with (P/'USDT_ledger.csv').open('w')as f:w=csv.DictWriter(f,fieldnames=list(ledger[0]));w.writeheader();w.writerows(ledger)
else:
 assert summary==j('summary.json')
print(json.dumps(report,indent=2))
