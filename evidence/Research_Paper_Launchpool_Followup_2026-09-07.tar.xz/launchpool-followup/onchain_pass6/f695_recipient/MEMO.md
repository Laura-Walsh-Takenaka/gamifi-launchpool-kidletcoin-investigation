# Launchpool follow-up: the f695 USDT recipient and Revolut endpoint

Research date: 7 September 2026. Ethereum only. Bounded scope: the specific 1,000 USDT payment from wallet `183600` on 23 July 2024, the recipient's exact USDT and normal transaction history, and direct service endpoints. No account contact or transactions were initiated. Earlier passes are unchanged.

## Principal finding

The previously unidentified 1,000 USDT payment reaches an Ethereum address publicly labeled **Revolut: Hot Wallet** by Etherscan:

| Event | UTC time | From | To | USDT | Transaction |
|---|---|---|---|---:|---|
| Initial payment | 23 July 2024 14:30:23 | `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4` | `0xf695f1d1688698abc97b2e5937ba24934561aae9` | 1,000 | `0x8882f17f55d39946da7ae8aadeef3ff4480b553b3441809480fcbc2d3d6d8ca9` |
| Onward transfer | 23 July 2024 15:57:47 | `0xf695f1d1688698abc97b2e5937ba24934561aae9` | `0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921` | 1,000 | `0xd9d2d2e0be5ae4814a64f653cb8c20ab3dfefc494a41eb16f11325cff0113cdb` |

The interval is **87 minutes 24 seconds**. Both transactions have successful RPC receipts and exact USDT Transfer logs. The indexed USDT ledger reconstructs zero balance before the initial payment, 1,000 after receipt, and zero after the onward payment, with no intervening USDT events. These historical balances are event reconstructions; a separate historical state call was unavailable.

Exact token contract: `0xdac17f958d2ee523a2206206994597c13d831ec7` (6 decimals). Neither token symbols nor lookalike token addresses were used for inclusion.

## Repeated payments from the same source

This is a repeated destination relationship. Six payments from `183600` to `f695`, from July 2024 through January 2026, total **2,975.818225 USDT**. Each lies within an observed balance cycle that ends in a single USDT sweep to the same Revolut-labeled endpoint.

| Source payment date (UTC) | Source amount USDT | Sweep date (UTC) | Sweep USDT | Other USDT received before sweep |
|---|---:|---|---:|---:|
| 23 July 2024 | 1,000 | 23 July 2024 | 1,000 | 0 |
| 4 February 2025 | 252.3037 | 11 March 2025 | 745.8037 | 493.5 |
| 30 June 2025 | 305 | 14 July 2025 | 789.581448 | 484.581448 |
| 22 July 2025 | 965 | 22 July 2025 | 965 | 0 |
| 4 August 2025 | 283.514525 | 15 August 2025 | 513.514525 | 230 |
| 19 January 2026 | 170 | 4 March 2026 | 170 | 0 |

Three cycles contain other USDT inputs before the sweep. The larger sweep amounts must not be attributed entirely to `183600`. Exact hashes, times and additional inputs are retained in `summary.json` and `USDT_ledger.csv`.

## Complete retrieved USDT history and service pattern

The supported Blockscout account API returned 65 USDT events, beginning 14 June 2024 and ending 4 March 2026. There are 38 incoming and 27 outgoing events. The incoming and outgoing totals each equal **23,722.265580 USDT**.

| Recipient | Direct Etherscan public label | Payments | USDT |
|---|---|---:|---:|
| `0xf7c8da79da4cb294c4f55dfebb1b404e3e38d921` | Revolut: Hot Wallet | 25 | 23,378.068982 |
| `0x8e21157932ecd417c557b4c975bd3e89d8ea896e` | KuCoin Deposit | 2 | 344.196598 |

The KuCoin payments occurred on 25 September 2024 and were 293.196598 and 51 USDT. They belong to separate balance cycles from the six `183600` payments. No onward trace of this KuCoin deposit was needed for the July 1,000 USDT route.

The 89 normal transactions include 30 outgoing transactions with consecutive nonces 0 through 29, matching current nonce 30. Address `0xb23360ccdd9ed1b15d45e5d3824bb409c8d7c460`, directly labeled **Revolut 1**, supplied 34 ETH payments totaling **0.02092218 ETH**, including the recipient's initial ETH funding. The combination of repeated gas funding and sweeps is consistent with a service deposit/sweep address. This is a behavioral inference; `f695` itself had no direct public name tag on the retrieved Etherscan page.

Ancillary indexed history shows two ETH payments totaling **6.320509399529568055 ETH** and one **850.921922 USDC** payment from `f695` to the same Revolut endpoint. These are whole-address activity, not additional proceeds assigned to the July BAMBOO trade. The USDC account API returned its two-event incoming/outgoing cycle. ETH and USDC ancillary transfers were read from indexed histories; the 33-edge receipt/log audit concerns USDT only.

## Pinned state and verification

At Ethereum block **25,925,814**, hash `0xb386179ef66493bd3446a907e6161ed90727b8f792059578ceb9b77caa07db35`, timestamp **7 September 2026 13:36:35 UTC**:

- `f695` has **0 USDT** and **0.034566131300512124 ETH**.
- Runtime is empty (`0x`); transaction count is **30**.
- The USDT current balance independently matches the complete retrieved event ledger's zero net amount.

All six `183600` inputs and all 27 USDT outputs were checked against exact Transfer topics and amounts. **27 successful RPC receipts** were recovered. For **six transactions**, two public RPCs returned null rather than a receipt; Blockscout's public transaction and raw-log APIs returned successful status, matching calldata and exact log data. They are explicitly recorded as indexed-log confirmations, not RPC receipts. A selected null case (4 February 2025) was also independently visible as successful on Etherscan. Null RPC responses were not treated as failed or absent transactions.

Initial dRPC batches exceeding its free batch-size cap were rejected. The requests were reduced to the supported three-item batch size; failures and exact sent request bodies are preserved. Timeout responses and PublicNode's archive-token requirement are likewise preserved. No access barrier was bypassed. A Blockscan label page returned 403 and was not retried.

Offline reproduction: `python derive_verify.py --check`. It checks integer arithmetic, all 33 selected edges, outgoing calldata, consecutive normal nonces, pinned state, and retained request/response hashes. Full third-party HTML pages may be omitted from redistribution; `label_records.json` preserves the short public-label excerpts, URLs, retrieval receipts and original content hashes.

## Investigative significance and limits

This supplies an exact service-associated endpoint for the previously open 1,000 USDT branch, plus five later payments to the same intermediary. It also identifies a concrete record holder to consider: Revolut could confirm its control of the receiving/gas-funding addresses and, if held, the internal customer/account credit associated with the incoming transaction to `f695` and its sweep. No request has been sent.

Public labels are explorer attributions, not direct confirmation by Revolut or KuCoin. The customer's identity, account credit, human signer and payment purpose remain unestablished. A service hot wallet can aggregate unrelated customers. Neither the endpoint nor the gas funder identifies Laura. The July 2024 1,000 USDT payment belongs to the already documented BAMBOO return branch. The five later payments establish reuse of the same intermediary, with their upstream funding outside this bounded pass. No exclusive attribution to original Mintlayer BUSD fundraising or the still-held ML reserves is made. The larger whole-address totals include unrelated inputs and must not be reported as missing funds or personal receipts.
