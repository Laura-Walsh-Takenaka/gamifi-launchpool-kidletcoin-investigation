import pathlib,urllib.request,json,datetime,hashlib,sys,csv
from decimal import Decimal,getcontext
getcontext().prec=80
P=pathlib.Path(__file__).parent
U='https://rpc-bsc.blockmachine.io';BNB='https://bsc-dataseed.bnbchain.org'
OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66'; BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56'; TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
OFFLINE='--offline' in sys.argv

def rpc(name,qs,url=U):
 meta_path=P/(name+'.receipt.json'); resp_path=P/(name+'.response')
 if resp_path.exists():
  m=json.loads(meta_path.read_text());b=resp_path.read_bytes();assert m['request']==qs and m['url']==url and m['sha256']==hashlib.sha256(b).hexdigest()
 elif OFFLINE:raise FileNotFoundError(name)
 else:
  m={'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs}
  try:
   with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=45) as r:
    b=r.read();m.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());resp_path.write_bytes(b)
  except Exception as e:m['error']=str(e);raise
  finally:meta_path.write_text(json.dumps(m,indent=2))
 data=json.loads(b)
 if isinstance(data,dict):data=[data]
 for row in data:
  if 'error' in row:raise RuntimeError((name,row))
 assert len(data)==len(qs) and set(x['id'] for x in data)==set(x['id'] for x in qs)
 return {x['id']:x['result'] for x in data}
def q(i,method,params):return {'jsonrpc':'2.0','id':i,'method':method,'params':params}
def topic(a):return '0x'+a[2:].zfill(64)
def dec(n):return format(Decimal(n)/Decimal(10**18),'f')

def main():
 claims=json.loads((P.parent/'original_busd/verified_original_mintlayer_claims.json').read_text())['rows']
 first={i:min(r['block_number'] for r in claims if r['raise']==i) for i in (1,2)}
 startutc={i:min(datetime.datetime.fromisoformat(r['utc']).timestamp() for r in claims if r['raise']==i) for i in (1,2)}
 # Exact upper cutoff: first block later than first withdrawal + 24h, excluded.
 headers={}; bounds={i:[first[i]+20000,first[i]+30000] for i in (1,2)}
 qs=[q(i*10+j,'eth_getBlockByNumber',[hex(bounds[i][j]),False]) for i in (1,2) for j in (0,1)]
 data=rpc('boundary_initial',qs,BNB)
 for i in (1,2):
  l,h=bounds[i];assert int(data[i*10]['timestamp'],16)<=startutc[i]+86400<int(data[i*10+1]['timestamp'],16)
 for step in range(15):
  active=[i for i in (1,2) if bounds[i][1]-bounds[i][0]>1]
  if not active:break
  mids={i:sum(bounds[i])//2 for i in active}
  data=rpc('boundary_%02d'%step,[q(i,'eth_getBlockByNumber',[hex(mids[i]),False]) for i in active],BNB)
  for i in active:
   h=data[i];t=int(h['timestamp'],16)
   if t<=startutc[i]+86400:bounds[i][0]=mids[i]
   else:bounds[i][1]=mids[i]
 for i in (1,2):assert bounds[i][1]-bounds[i][0]==1
 windows=[{'raise':i,'first_block':first[i],'last_block':bounds[i][0],'after_block':bounds[i][1],'start_utc':datetime.datetime.fromtimestamp(startutc[i],datetime.timezone.utc).isoformat(),'cutoff_utc':datetime.datetime.fromtimestamp(startutc[i]+86400,datetime.timezone.utc).isoformat()} for i in (1,2)]
 (P/'windows.json').write_text(json.dumps(windows,indent=2))
 logs=[]
 for w in windows:
  qs=[]
  for start in range(w['first_block'],w['last_block']+1,10000):
   end=min(start+9999,w['last_block'])
   for direction in ('in','out'):
    topics=[TRANSFER,topic(OWNER)] if direction=='out' else [TRANSFER,None,topic(OWNER)]
    qs.append(q(len(qs)+1,'eth_getLogs',[{'address':BUSD,'topics':topics,'fromBlock':hex(start),'toBlock':hex(end)}]))
  data=rpc('owner_logs_raise%d'%w['raise'],qs)
  for rows in data.values():logs+=rows
 logs=list({(l['transactionHash'],l['logIndex']):l for l in logs}.values());logs.sort(key=lambda l:(int(l['blockNumber'],16),int(l['logIndex'],16)))
 (P/'owner_logs.json').write_text(json.dumps(logs,indent=2))
 print('Owner logs',len(logs),flush=True)
 txs=sorted(set(l['transactionHash'] for l in logs));hs=sorted(set(int(l['blockNumber'],16) for l in logs)|{w['first_block']-1 for w in windows}|{w['last_block'] for w in windows}|{w['after_block'] for w in windows})
 blockdata={}
 for part in range(0,len(hs),20):
  blocks=rpc('headers_%02d'%part,[q(h,'eth_getBlockByNumber',[hex(h),False]) for h in hs[part:part+20]],BNB);blockdata.update(blocks)
 receiptd={};txd={}
 for part in range(0,len(txs),10):
  sub=txs[part:part+10]
  data=rpc('receipts_%02d'%part,[q(i,'eth_getTransactionReceipt',[tx]) for i,tx in enumerate(sub)],BNB)
  receiptd.update({tx:data[i] for i,tx in enumerate(sub)})
  data=rpc('transactions_%02d'%part,[q(i,'eth_getTransactionByHash',[tx]) for i,tx in enumerate(sub)],BNB)
  txd.update({tx:data[i] for i,tx in enumerate(sub)})
 bals=rpc('owner_balance_bounds',[q(i*10+j,'eth_call',[{'to':BUSD,'data':'0x70a08231'+OWNER[2:].zfill(64)},hex(w['first_block']-1 if j==0 else w['last_block'])]) for i,w in enumerate(windows) for j in (0,1)])
 rows=[]
 for l in logs:
  h=int(l['blockNumber'],16);rec=receiptd[l['transactionHash']];head=blockdata[h];tx=txd[l['transactionHash']]
  assert rec['status']=='0x1' and rec['blockHash']==head['hash']==l['blockHash'] and tx['blockHash']==head['hash']
  assert any(x==l for x in rec['logs'])
  f='0x'+l['topics'][1][-40:];t='0x'+l['topics'][2][-40:];amount=int(l['data'],16)
  rows.append({'tx_hash':l['transactionHash'],'block_number':h,'block_hash':head['hash'],'utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'from':f,'to':t,'amount_raw':str(amount),'amount_busd':dec(amount),'direction':'out' if f==OWNER else 'in','log_index':int(l['logIndex'],16),'tx_from':tx['from'],'tx_to':tx['to'],'tx_input':tx['input'],'status':1})
 out={'owner':OWNER,'token':BUSD,'windows':windows,'rows':rows,'window_balances':[]}
 for i,w in enumerate(windows):
  wr=[r for r in rows if w['first_block']<=r['block_number']<=w['last_block']];bal0=int(bals[i*10],16);bal1=int(bals[i*10+1],16);inc=sum(int(r['amount_raw']) for r in wr if r['direction']=='in');sent=sum(int(r['amount_raw']) for r in wr if r['direction']=='out');assert bal0+inc-sent==bal1
  out['window_balances'].append({'raise':w['raise'],'opening_raw':str(bal0),'closing_raw':str(bal1),'in_raw':str(inc),'out_raw':str(sent),'opening_busd':dec(bal0),'closing_busd':dec(bal1),'in_busd':dec(inc),'out_busd':dec(sent),'reconciled':True})
 (P/'verified_owner_onward.json').write_text(json.dumps(out,indent=2))
 with (P/'verified_owner_onward.csv').open('w') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
