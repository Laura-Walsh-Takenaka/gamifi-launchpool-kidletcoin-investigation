# Original Mintlayer BUSD: immediate onward payments and Binance endpoint

Retrieved and verified 7 September 2026. This lane follows the six original Mintlayer BSC fundraising withdrawals recovered in `../original_busd/`. It does not concern ML token allocations, the 2024 USDC trading lane, or the later Circularr BUSD payments.

## Result

The owner address `0x77bfe8d704b1948374bf8dab8328a810b2836e66` sent **896,370 BUSD in 11 payments** during the two defined 24-hour windows after the November 2022 original Mintlayer withdrawals. All payments are verified against raw logs, successful official BNB RPC receipts, transaction calldata, block hashes and timestamps.

A directly funded recipient is the previously traced address `0x1991e27e2908847c0274a662eb6675002e8386d0`. On 3 November 2022 it received **267,000 BUSD** in four payments from 77bf, then sent the entire amount onward that day. Its BUSD balance opened and closed at zero, and its only incoming BUSD in this window came from 77bf.

**54,370 BUSD reached the explorer-labelled Binance 51 address `0x8894e0a0c962cb723c1976a4421c95949be2d4e3` on 3 November 2022.** The intermediary `0x14c840ec5b8cf28712e7e53391c8c860ba7a7b25` received 29,370 BUSD from 77bf and 25,000 BUSD from 1991, then forwarded those exact amounts to 8894. That intermediary also opened and closed at zero; these two receipts and two outgoing payments are its complete BUSD ledger in the first window.

## Exact windows and custody reconciliation

| Window | Inclusive blocks | Start and cutoff UTC | Opening BUSD | Incoming BUSD | Outgoing BUSD | Closing BUSD |
|---|---|---|---:|---:|---:|---:|
| Raise 1 | 22,732,478–22,760,778 | 2022-11-03 09:02:17 to 2022-11-04 09:02:17 | 0.332011149154053912 | 587,417.110289617788758 | 521,370 | 66,047.442300766942811912 |
| Raise 2 | 22,766,632–22,794,958 | 2022-11-04 13:59:08 to 2022-11-05 13:59:08 | 66,047.442300766942811912 | 316,377.236129964696612326 | 375,000 | 7,424.678430731639424238 |

Each cutoff is bracketed to adjacent blocks using their timestamps. The first subsequent block is excluded. Both owner equations reconcile exactly in 18-decimal base units. The only positive BUSD inflows to 77bf in either window are the six Mintlayer fundraising withdrawals. One zero-value incoming transfer in the second window remains in the evidence and contributes no funds.

The approximately 4h57 gap between these two windows was not scanned. The owner balance is equal at the first window's end and the second window's beginning; this alone cannot exclude offsetting transfers during that gap. The scope is two bounded windows, not a continuous 53-hour history. The first window begins with 0.332011149154053912 BUSD already held. The second window includes the 66,047.442300766942811912 BUSD opening balance. BUSD is fungible; neither identical amounts nor timing supplies a project settlement agreement or a human beneficiary.

## Owner's 11 outgoing payments

| UTC | Recipient | BUSD | Transaction |
|---|---|---:|---|
| 2022-11-03 09:05:29 | `0x1991e27e2908847c0274a662eb6675002e8386d0` | 10 | `0xa6c8d98c5b82377b49a05bf70beb659a41e80311f8ed73834d4ba5a939a5107d` |
| 2022-11-03 09:09:05 | `0x14c840ec5b8cf28712e7e53391c8c860ba7a7b25` | 29,370 | `0xd9eabdb7df843f653e77cb7e762eefd27c02fe22a03a79878522157727aef50e` |
| 2022-11-03 09:27:56 | `0x1991e27e2908847c0274a662eb6675002e8386d0` | 199,990 | `0xf9d90ff5c8a77e73dd1fd25bdf8e88097b88465aab513d6cca3ce4adf65f0b3e` |
| 2022-11-03 09:31:05 | `0x1991e27e2908847c0274a662eb6675002e8386d0` | 25,000 | `0x99717f1714d79da635ded16e55444279fadc83346b67276533179e216f9a32c9` |
| 2022-11-03 10:37:37 | `0x2108dfd8c35d6426c71173bb85ac01cf86adcc6c` | 10 | `0x74bbfbd95ed74afee54518f857e1c6d06ec8fcd946dc5a2afa5b6b3f6f244122` |
| 2022-11-03 10:38:55 | `0x1991e27e2908847c0274a662eb6675002e8386d0` | 42,000 | `0x605d3f9678660d81d690a236c38e23dd848f2faa8515f88dc2e66e55c96e1cdc` |
| 2022-11-03 11:54:28 | `0xf98f525068971a572fa1ec2dee870ddec91de420` | 10 | `0xf1f84908db7d39db0d7989833505878225c72f3c4bad0cb186bfb11100a923df` |
| 2022-11-03 11:56:49 | `0xf98f525068971a572fa1ec2dee870ddec91de420` | 224,980 | `0x61a8c14c4ee9e1e9bbda0dbf30bb9789d6319da7654550215e64c743a04ed579` |
| 2022-11-04 14:05:44 | `0xf98f525068971a572fa1ec2dee870ddec91de420` | 200,000 | `0x9121099059948653e1728918fa14cf0db16e03f8b9a2a0d0bee9caa2016754a9` |
| 2022-11-04 14:06:56 | `0xbf7f26976b451cee4d055f43dbdb10c0426ce630` | 150,000 | `0xd61af9d796275fa226801be5c6dfb8e67dfad04de373ec83c40f70479e5e52a6` |
| 2022-11-04 14:08:22 | `0x87245c288fcc858bf7225dc3ab97d0ad94730757` | 25,000 | `0x159cb233790a40f5d03d01a4fa24c5989bee0077bee83fcc0b5a689e924c390e` |

The first outgoing payment occurred 2m15 after the final Raise 1 claim. The three Raise 2 outgoing payments occurred 5m42 to 8m20 after its final claim. Purpose is not encoded by these elapsed times.

## Additional recipient ledger

All six direct recipients were queried for incoming and outgoing BUSD logs in the same two windows. This produced 19 unique events, including the 11 owner payments already listed; these are not additional fundraising proceeds. No scan expanded beyond the six direct recipient addresses. Because both 1991 and 14c840 were already direct recipients, the captured data also includes their internal 25,000 BUSD transfer and its subsequent Binance payment.

| UTC on 3 November 2022 | From | To | BUSD | Transaction |
|---|---|---|---:|---|
| 09:38:08 | `14c840…7b25` | Binance 51 `8894e0…d4e3` | 29,370 | `0x7e78389fcc5f9a13d23b516dcf2fbdfa836a87a18b6ee10b6afdfac5f3e5464e` |
| 09:43:20 | `1991e2…86d0` | `14c840…7b25` | 25,000 | `0x3d41717da08ca013518d57e56c8ef81f02727ab741b01767d4cff5f9ec27eddf` |
| 10:00:27 | `14c840…7b25` | Binance 51 `8894e0…d4e3` | 25,000 | `0x141937386f5dc40948d057b1172a73d55e2caff1b880c5eae7ad6e66a11e5292` |
| 10:40:44 | `1991e2…86d0` | `0x0d43408dfc53fef53a41d978e072a69d4a00c5dd` | 200,000 | `0x67cd3f321dd775f94a85b1f0fbc563e046398124636a7b265f6141f1a0313161` |
| 11:31:13 | `1991e2…86d0` | `0xab3c27e291d073c4e3d2c1e0adfbb3fcc56b7151` | 2,000 | `0xb28e0dcc2a42f33cc39c5ef50305152e12c526240019fff4ca7347d00c57123f` |
| 12:11:19 | `1991e2…86d0` | `0xdc127dd1218e555684d7e5605e80afdc75868d42` | 40,000 | `0xd7680cde5908c4b875c5a9212bab3914a5b35e9a9e34168d460b1e70c1d50c88` |
| 12:41:49 | `f98f52…e420` | `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 20,000 | `0xb817ef54b76ab9c9e4a660f960372e252642fef2bb62bf6a888f118c858d0a3f` |
| 14:29:43 | `f98f52…e420` | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | 204,990 | `0xc5eb7659eb9787996bbc7e0907f79caf470ca764cb892a704b09eb9cda31a461` |

The first-window balances of 1991, 14c840 and f98f52 each open and close at zero, and their exact incoming and outgoing totals reconcile. The 10 BUSD at 2108df remained there at both window cutoffs. During the second window, f98f52 received 200,000 BUSD and retained it at cutoff; bf7f26 received and retained 150,000; 87245c received 25,000 and closed at 25,197.437915171993026378 BUSD, including its pre-existing 197.437915171993026378 BUSD. These are historical cutoff balances, not current balances.

## Attribution and remaining records

The BscScan search result for the exact BSC endpoint labels 8894 as Binance 51. The successfully opened Blockscan page labels that exact address Binance 51 and Binance Exchange and displays BNB Chain activity. See `endpoint_label_provenance.json`. The exchange label identifies the service-associated endpoint; the customer account, beneficial recipient, trade or withdrawal and mandate remain unidentified. None of the other terminal addresses is assigned a service or person in this lane.

The direct 2022 BSC transfer to address 1991 is an additional connection to an address already seen in the later Ethereum USDC investigation. It does not establish that the 2022 BUSD financed particular 2024 trades. Human key custody, project settlement instructions and Laura's personal receipt remain unverified. Payments to an exchange or another wallet are not by themselves evidence of misappropriation.

## Reproduction and preservation

- `verified_owner_onward.json/.csv`: 18 owner events, including six Mintlayer claims, 11 outgoing payments and one zero-value incoming transfer; two balance reconciliations.
- `verified_intermediary_onward.json/.csv`: 19 recipient events and 12 exact wallet/window balance reconciliations.
- Paired `.receipt.json` and `.response` files preserve the exact JSON-RPC request, endpoint, retrieval UTC, HTTP status and response SHA-256.
- Historical logs and balance calls use the documented keyless Blockmachine BSC endpoint. Each inclusive log window is at most 10,000 blocks. Every non-empty log event is matched to an independently acquired successful receipt from the official BNB RPC, with transaction and block checks.
- An initial 12-call intermediary balance batch received HTTP 429. Its failure record is retained. After a pause, six batches of four calls succeeded. No paid tier, authorization key or access-control workaround was used.
- Offline replay: `python onchain_pass6/original_busd_onward/trace_onward.py --offline` and `python onchain_pass6/original_busd_onward/trace_intermediaries.py --offline`, run from the project root. Both succeeded against the captured requests and responses.
- Provider documentation: https://blockmachine.io/docs/bnb-chain-rpc and https://blockmachine.io/docs/gateway-methods/bnb-chain . Service label: https://blockscan.com/Address/0x8894e0a0c962cb723c1976a4421c95949be2d4e3 .
