from trace_onward import *

def main():
 src=json.loads((P/'verified_owner_onward.json').read_text());windows=src['windows'];targets=sorted(set(r['to'] for r in src['rows'] if r['direction']=='out'));logs=[]
 for w in windows:
  qs=[]
  for start in range(w['first_block'],w['last_block']+1,10000):
   for direction in ('in','out'):
    tops=[TRANSFER,[topic(a) for a in targets]] if direction=='out' else [TRANSFER,None,[topic(a) for a in targets]]
    qs.append(q(len(qs)+1,'eth_getLogs',[{'address':BUSD,'topics':tops,'fromBlock':hex(start),'toBlock':hex(min(start+9999,w['last_block']))}]))
  data=rpc('intermediary_logs_raise%d'%w['raise'],qs)
  for rows in data.values():logs+=rows
 logs=list({(l['transactionHash'],l['logIndex']):l for l in logs}.values());logs.sort(key=lambda l:(int(l['blockNumber'],16),int(l['logIndex'],16)))
 (P/'intermediary_logs.json').write_text(json.dumps(logs,indent=2));print('intermediarylogs',len(logs),flush=True)
 if len(logs)>150:raise RuntimeError('Bounded lane exceeds150logs; preserveindexandstop')
 txs=sorted(set(l['transactionHash'] for l in logs));hs=sorted(set(int(l['blockNumber'],16) for l in logs));hd={};rd={};td={}
 for part in range(0,len(hs),20):hd.update(rpc('intermediary_headers_%02d'%part,[q(h,'eth_getBlockByNumber',[hex(h),False]) for h in hs[part:part+20]],BNB))
 for part in range(0,len(txs),10):
  sub=txs[part:part+10]
  data=rpc('intermediary_receipts_%02d'%part,[q(i,'eth_getTransactionReceipt',[tx]) for i,tx in enumerate(sub)],BNB);rd.update({tx:data[i] for i,tx in enumerate(sub)})
  data=rpc('intermediary_transactions_%02d'%part,[q(i,'eth_getTransactionByHash',[tx]) for i,tx in enumerate(sub)],BNB);td.update({tx:data[i] for i,tx in enumerate(sub)})
 qs=[];maps={}
 for w in windows:
  for a in targets:
   for pos in ['first','last']:
    block=w['first_block']-1 if pos=='first' else w['last_block'];i=len(qs)+1;maps[i]=(w['raise'],a,pos)
    qs.append(q(i,'eth_call',[{'to':BUSD,'data':'0x70a08231'+a[2:].zfill(64)},hex(block)]))
 balances={}
 for part in range(0,len(qs),4):balances.update(rpc('intermediary_balances_retry4_%02d'%part,qs[part:part+4]))
 bal={(maps[k]):int(v,16) for k,v in balances.items()};rows=[]
 for l in logs:
  h=int(l['blockNumber'],16);rec=rd[l['transactionHash']];head=hd[h];tx=td[l['transactionHash']]
  assert rec['status']=='0x1' and rec['blockHash']==head['hash']==l['blockHash']==tx['blockHash'] and any(x==l for x in rec['logs'])
  f='0x'+l['topics'][1][-40:];t='0x'+l['topics'][2][-40:];amount=int(l['data'],16)
  rows.append({'tx_hash':l['transactionHash'],'block_number':h,'block_hash':head['hash'],'utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'from':f,'to':t,'amount_raw':str(amount),'amount_busd':dec(amount),'log_index':int(l['logIndex'],16),'tx_from':tx['from'],'tx_to':tx['to'],'tx_input':tx['input'],'status':1})
 reconciliation=[]
 for w in windows:
  for a in targets:
   wr=[r for r in rows if w['first_block']<=r['block_number']<=w['last_block']];inc=sum(int(r['amount_raw']) for r in wr if r['to']==a);out=sum(int(r['amount_raw']) for r in wr if r['from']==a);opening=bal[w['raise'],a,'first'];closing=bal[w['raise'],a,'last'];assert opening+inc-out==closing,(a,w['raise'],opening,inc,out,closing)
   reconciliation.append({'raise':w['raise'],'address':a,'opening_raw':str(opening),'closing_raw':str(closing),'in_raw':str(inc),'out_raw':str(out),'opening_busd':dec(opening),'closing_busd':dec(closing),'in_busd':dec(inc),'out_busd':dec(out),'reconciled':True})
 obj={'scope':'All six direct recipients of the 11 owner payments, both incoming and outgoing BUSD logs, within the same two 24-hour windows. No new scan expanded beyond those six recipients. Transfers between these recipients are retained, including the 1991 to 14c840 route.','target_addresses':targets,'windows':windows,'rows':rows,'window_balances':reconciliation}
 (P/'verified_intermediary_onward.json').write_text(json.dumps(obj,indent=2))
 with (P/'verified_intermediary_onward.csv').open('w') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
 print(json.dumps(obj,indent=2))
if __name__=='__main__':main()
