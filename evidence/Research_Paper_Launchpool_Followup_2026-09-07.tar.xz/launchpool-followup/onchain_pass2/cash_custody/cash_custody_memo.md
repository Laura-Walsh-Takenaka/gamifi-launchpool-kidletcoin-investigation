# Dated USDC custody evidence: pools 9 and 10 are IAG reward pools

Prepared 7 September 2026 UTC. Bounded scope: two specified Ethereum transactions, the immediately sending contract, its verified source and the two pool records. Public read-only requests only; no wallet interaction.

## Finding

On 2 July 2024, address `0x77bfe8d704b1948374bf8dab8328a810b2836e66` successfully invoked `claimFundRaising(uint256)` twice against contract `0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf`, receiving a combined **191,393.685754 USDC**. Exact-match verified code restricts this function to the contract owner and transfers funds to `owner()`. The calls therefore establish this address's **contract-owner authority at those calls**, as well as receipt of the USDC. They do not identify the human or organization controlling its key.

**Do not characterize this amount as Mintlayer fundraising proceeds.** Pool IDs 9 and 10 each specify reward token `0x40eb746dee876ac1e78697b7ca85142d178a1fc8`, which Etherscan identifies as **IAGON (IAG)**. The source's first `poolInfo` field is `rewardToken`; the staking token is a separate global variable. The USDC amounts concern these IAG reward pools. This is useful evidence of the wallet's role across Launchpool-style contracts, with no demonstrated Mintlayer cash attribution in this bounded check.

## Transactions

| UTC event time | Block | Pool ID | USDC received | Transaction |
|---|---:|---:|---:|---|
| 2024-07-02 13:05:23 | 20219016 | 9 | 123,488.370079 | `0xdb32b44e9cb8048521ee3d350c5fdcc3175db307bf8779887f9fa0a0b6c9ecc4` |
| 2024-07-02 13:05:35 | 20219017 | 10 | 67,905.315675 | `0x1109a93d150080ca8f1ab295581848ada5ebb3afad9d6d748d7b282012d29cd4` |

Both transactions are successful, sent from the recipient address to the same source contract, with selector `0x67a49923` and ABI-decoded `claimFundRaising` arguments 9 and 10. The decoded `FundRaisingClaimed(uint256,address,uint256)` logs report the same pool IDs, recipient and raw amounts 123488370079 / 67905315675. The USDC contract is `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48`; its corresponding Transfer logs corroborate the source, recipient and amounts.

## Authorization and project mapping

Etherscan marks the sending contract's source **Exact Match**, named `LaunchPoolERC20FundRaisingWithVesting`, compiled with Solidity v0.6.12+commit.27d51765, optimizer enabled for 200 runs. Its `claimFundRaising` function is `external nonReentrant onlyOwner`; it checks a valid pool, previously configured rewards and that funds have not already been claimed, marks funds claimed, transfers `poolIdToTotalRaised[_pid]` in `pool.fundRaisingToken` to `owner()`, and emits `FundRaisingClaimed`.

The public RPC `poolInfo(uint256)` calls for IDs 9 and 10 succeeded at **2026-09-07T05:54:55.408047Z** against ethereum-rpc.publicnode.com. Both returned:

- Reward token: `0x40eb746dee876ac1e78697b7ca85142d178a1fc8` (Etherscan token page title: IAGON / IAG).
- Fundraising token: `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` (USDC).

These calls used the `latest` block tag, not a historical block. Historical applicability is supported by source inspection: `add` initializes the pool's reward and fundraising-token fields, and no function that modifies either field after creation was found in the verified contract. This inspection supports mapping the cited pool IDs to IAG; it does not substitute a historical RPC snapshot. The secondary Cloudflare RPC returned internal errors and is not corroboration.

No person, company beneficial owner, or Laura Walsh/Takenaka connection is established by these two transactions. The owner address's receipt does not by itself establish how it subsequently used the money, when the underlying raise occurred, or whether any duty was breached. No further hops were followed here.

## Reproducible sources and timestamps

1. https://etherscan.io/address/0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf#code — fetched 2026-09-07T05:52:45.412326Z; retained `source_contract.html` and extracted verified `.sol` files.
2. https://etherscan.io/tx/0xdb32b44e9cb8048521ee3d350c5fdcc3175db307bf8779887f9fa0a0b6c9ecc4 — fetched 2026-09-07T05:52:45.219881Z; `tx_123488.html`.
3. https://etherscan.io/tx/0x1109a93d150080ca8f1ab295581848ada5ebb3afad9d6d748d7b282012d29cd4 — fetched 2026-09-07T05:52:46.192611Z; `tx_67905.html`.
4. https://ethereum-rpc.publicnode.com — JSON-RPC `eth_call`, selector `0x1526fe27` + 32-byte padded pool ID, destination the source contract, block tag `latest`; exact requests, responses and capture times in `poolinfo_rpc_receipts.json`; decoded fields in `poolinfo_decoded.json`.
5. https://etherscan.io/token/0x40eb746dee876ac1e78697b7ca85142d178a1fc8 — fetched 2026-09-07T05:57:09.725698Z; `pool9_10_rewardtoken.html` and receipt.

The retrieval date differs from the 2024 transaction dates. Complete raw HTML is retained for internal reproducibility; the memo, decoded JSON, request records and relevant verified source are sufficient for report integration. Initial plain-UA Etherscan failures and the secondary RPC error are retained as diagnostics, not findings. No additional research was needed after the pool mapping resolved.
