import json,pathlib,urllib.request,urllib.error,datetime,hashlib
P=pathlib.Path(__file__).parent
hs={'usdc_onward':'0x9f2022618d5326b97338f704ebf394485a48f083ff92942fe7c55951bffb4420','eth_onward':'0x6d2560f865b3db4f4a953e8063a5b4b50e70582a7827b730cfab14d55f81bd7d','deployer_swap':'0x23f39909501c0ba8a872027ea74aa88e83b388a74922b32734285e139a5d8e81','deployer_usdc':'0x9008bd7dee2bb7323e6fc710d7d09906c8e5dbcfec61af2a1bc55066ef3c1d2a'}
req=[]; mapping={}
for name,h in hs.items():
 for m in ['eth_getTransactionByHash','eth_getTransactionReceipt']:
  i=len(req)+1;req.append({'jsonrpc':'2.0','id':i,'method':m,'params':[h]});mapping[str(i)]={'name':name,'method':m}
u='https://ethereum-rpc.publicnode.com';rec={'url':u,'request':req,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(req).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=40) as r:
  b=r.read();rec.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());(P/'rpc_response.json').write_bytes(b)
except urllib.error.HTTPError as e:rec.update(status=e.code,error=str(e))
except Exception as e:rec['error']=str(e)
(P/'rpc_request.json').write_text(json.dumps(rec,indent=2));(P/'rpc_map.json').write_text(json.dumps(mapping,indent=2));print(rec.get('status',rec.get('error')))
