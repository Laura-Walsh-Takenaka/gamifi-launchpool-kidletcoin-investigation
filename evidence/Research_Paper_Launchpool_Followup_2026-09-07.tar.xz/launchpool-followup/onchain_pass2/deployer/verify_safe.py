import json,pathlib,urllib.request,datetime,hashlib
P=pathlib.Path(__file__).parents[1]/'gas_control';a='0x03fafab75267cdf75c64a1c86188e612205b455e';ml='0x059956483753947536204e89bfad909e1a434cc6';b=hex(25923475)
qs=[('owners','eth_call',[{'to':a,'data':'0xa0e67e2b'},b]),('threshold','eth_call',[{'to':a,'data':'0xe75235b8'},b]),('nonce','eth_call',[{'to':a,'data':'0xaffed0e0'},b]),('ml_balance','eth_call',[{'to':ml,'data':'0x70a08231'+a[2:].zfill(64)},b]),('code_at_token_receipt','eth_getCode',[a,hex(22588033)]),('current_code','eth_getCode',[a,b])]
rq=[{'jsonrpc':'2.0','id':i+1,'method':m,'params':p} for i,(_,m,p) in enumerate(qs)];u='https://ethereum-rpc.publicnode.com';rec={'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'names':[x[0] for x in qs],'block':25923475,'request':rq}
try:
 with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(rq).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=40) as r:
  by=r.read();rec.update(status=r.status,sha256=hashlib.sha256(by).hexdigest());(P/'root_safe_rpc_response.json').write_bytes(by)
except Exception as e:rec['error']=str(e)
(P/'root_safe_rpc_request.json').write_text(json.dumps(rec,indent=2));print(rec.get('status',rec.get('error')))
