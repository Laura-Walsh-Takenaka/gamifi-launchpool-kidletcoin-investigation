import json,pathlib,urllib.request,datetime,hashlib,concurrent.futures
P=pathlib.Path(__file__).parent
addrs={'gas_june':'0x21b4299644286840ef37de64a18a7dbb8e914969','gas_roundtrip':'0x37595dfcf69f7cfdeff8c611e00c380e33db536b','usdc_exit':'0xaa3f5e11d8be37c1617862add32603bee12bb2d1','eth_exit':'0xc9899cc6c8864b7751a802a1d4f2dc24650e26ed','tlos_source':'0x3ccefaaa0ca14f902a797d23c7684ed45e2330b1'}
def get(it):
 n,a=it; u='https://etherscan.io/address/'+a; r={'name':n,'address':a,'url':u,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0'}),timeout=35) as z: b=z.read();r.update(status=z.status,sha256=hashlib.sha256(b).hexdigest()); (P/(n+'.html')).write_bytes(b)
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex: rs=list(ex.map(get,addrs.items()))
(P/'requests.json').write_text(json.dumps(rs,indent=2));print(json.dumps(rs,indent=2))
