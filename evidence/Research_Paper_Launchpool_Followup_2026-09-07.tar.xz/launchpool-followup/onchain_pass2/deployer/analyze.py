import json,pathlib,decimal,datetime,hashlib,csv
P=pathlib.Path(__file__).parent; R=P.parents[1]; D=decimal.Decimal;decimal.getcontext().prec=90
mp=json.loads((P/'rpc_map.json').read_text());rs=json.loads((P/'rpc_response.json').read_text());e={}
for r in rs:
 assert 'error' not in r and r.get('result') is not None
 m=mp[str(r['id'])];e.setdefault(m['name'],{})[m['method']]=r['result']
transfer='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'; usdc='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';dep='0xb72fc236ab043029776b9d25e99a5b6456a2e16d'
rows=[]
for n,v in e.items():
 tx=v['eth_getTransactionByHash'];rec=v['eth_getTransactionReceipt'];assert rec['status']=='0x1'
 for l in rec['logs']:
  if l['topics'][0]!=transfer:continue
  rows.append({'lane':n,'tx':tx['hash'],'block':int(tx['blockNumber'],16),'token':l['address'],'from':'0x'+l['topics'][1][-40:],'to':'0x'+l['topics'][2][-40:],'base_units':str(int(l['data'],16))})
assert [r for r in rows if r['lane']=='deployer_usdc'][0]['base_units']=='4761971580'
assert [r for r in rows if r['lane']=='usdc_onward'][0]['base_units']=='4761971580'
with (P/'verified_transfer_events.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
normal=json.loads((R/'laura_thread/treasury/deployer_txlist.json').read_text())['result'];tokens=json.loads((R/'laura_thread/treasury/deployer_tokentx.json').read_text())['result']
y2025=[]
for t in normal:
 if int(t['timeStamp'])<1735689600:continue
 y2025.append({k:t[k] for k in ['hash','from','to','value','blockNumber','contractAddress','isError']}|{'utc':datetime.datetime.fromtimestamp(int(t['timeStamp']),datetime.timezone.utc).isoformat(),'selector':t['input'][:10]})
(P/'deployer_2025_normal_facts.json').write_text(json.dumps(y2025,indent=2))
labels={'0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43':'Coinbase 10','0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511':'Coinbase 44'}
summary={'scope':{'prior_normal_rows':len(normal),'prior_token_rows':len(tokens),'fresh_primary_rpc_calls':len(rs),'no_ml_events_in_cached_token_rows':not any(t['contractAddress'].lower()=='0x059956483753947536204e89bfad909e1a434cc6' for t in tokens)},'usdc_route':{'date_utc':'2025-06-05','source_token':'TLOS','source_amount':'90843','net_swap_usdc':'4761.97158','deployer':dep,'intermediate':'0xaa3f5e11d8be37c1617862add32603bee12bb2d1','exchange_label_target':'0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43','swap_utc':'13:36:23','deployer_transfer_utc':'13:37:59','intermediate_transfer_utc':'13:41:59','full_forwarding_delay_seconds':336},'eth_route':{'deployer_transfer_utc':'2025-10-02T05:45:23Z','intermediate':'0xc9899cc6c8864b7751a802a1d4f2dc24650e26ed','deployer_eth_sent':'0.006568313627127521','intermediate_forward_utc':'2026-08-22T12:14:35Z','intermediate_forward_eth':str(D(int(e['eth_onward']['eth_getTransactionByHash']['value'],16))/D(10**18)),'exchange_label_target':'0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511'},'labels':labels,'label_sources':['https://etherscan.io/address/0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43','https://etherscan.io/address/0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511','https://docs.etherscan.io/api-reference/endpoint/getaddresstag'],'limits':['Explorer label is provider attribution, not exchange attestation or customer identity.','No same-human-control assertion from common gas funding or shared exchange destination.','TLOS swap proceeds are not identified Mintlayer purchase money; no ML event in retained105deployer token rows.','ETH forward occursmonths later; equal-source tracing excludes unknown intervening internal flows only if independently replayed, which was not done. This is an address/transfer route, not unique-wei tracing.','No originalBUSD/payment-account attribution established.']}
(P/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
