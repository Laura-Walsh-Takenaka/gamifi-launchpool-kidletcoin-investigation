# Independent deployer-route review

**PASS for the four transaction/receipt pairs, exact amounts, token distinction and bounded framing in REPORT.md.** Checks used preserved files only; exact results are in `peer_validation.json`.

All eight RPC result records are present and non-null. Each receipt has successful status and matches its transaction's hash, block hash, block number, sender and recipient. Relevant event logs are marked not removed and belong to the expected transaction.

The 5 June 2025 swap spends **90,843 TLOS**, contract `0x193f4a4a6ea24102f49b931deeeb931f6e32405d`, using the cached token's 18-decimal metadata. USDC uses the separate contract `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` and six decimals. Logs show **4,773.906345 USDC** into the router, **11.934765 USDC** separately paid out, and **4,761.97158 USDC net** to the deployer. The net amount is exactly repeated in the two subsequent transfer inputs and matching logs: deployer → `aa3f…b2d1` → `a9d1…3e43`. The swap-to-final-transfer interval is 336 seconds. These amounts must not be described as ML liquidation or original BUSD purchase receipts.

The cached 2 October 2025 ETH transfer to `c989…26ed` is **0.006568313627127521 ETH**. The freshly verified 22 August 2026 onward transaction is **0.006559021031199521 ETH**, with a separate fee of **0.000021 ETH**. The onward value plus fee exceeds the earlier single inflow; these two transactions therefore are not a closed account-funds reconciliation. REPORT.md appropriately describes an address/transfer route and explicitly leaves intervening flow unreconciled.

The preserved Etherscan HTML pairs **Coinbase 10** with `0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43` and **Coinbase 44** with `0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511`. These are explorer-provider labels. They do not identify a Coinbase customer, prove a particular customer's exchange deposit credit, or supply account/KYC records.

The retained deployer datasets contain 154 normal transactions and 105 token events; none of those 105 events uses the ML token contract. That is a scoped dataset result, not an all-chain or all-time exclusion. The review supplies no human ownership, Laura attribution, purpose-of-payment conclusion, or proof that separate addresses have the same controller.

The review confirms the core flow and numerical statements. It does not independently extend the secondary gas-funding history or suspicious-token assessment beyond the retained scope. No source files were changed and no network or wallet operation was performed.
