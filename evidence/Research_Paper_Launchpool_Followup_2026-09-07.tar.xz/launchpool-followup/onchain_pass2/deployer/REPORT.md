# Deployer follow-up — exchange-facing transfer routes

This lane analyzes the same address that created the July and August 2025 ML distributors: `0xb72fc236ab043029776b9d25e99a5b6456a2e16d`. It does not identify a person or prove disposition of Mintlayer purchase proceeds.

## Verified USDC route

On 5 June 2025 at 13:36:23 UTC the deployer spent **90,843 TLOS** in a router transaction. Receipt logs show 4,773.906345 USDC into the router, a separate 11.934765 USDC transfer to `0x27213e28d7fda5c57fe9e5dd923818dbccf71c47`, and **4,761.97158 USDC net to the deployer**.

- Swap: `0x23f39909501c0ba8a872027ea74aa88e83b388a74922b32734285e139a5d8e81`.
- At 13:37:59 the deployer transferred exactly 4,761.97158 USDC to `0xaa3f5e11d8be37c1617862add32603bee12bb2d1`; transaction `0x9008bd7dee2bb7323e6fc710d7d09906c8e5dbcfec61af2a1bc55066ef3c1d2a`.
- At 13:41:59 that address transferred exactly 4,761.97158 USDC to `0xa9d1e08c7793af67e9d92fe308d5697fb81d3e43`; transaction `0x9f2022618d5326b97338f704ebf394485a48f083ff92942fe7c55951bffb4420`.

The latter is labeled **Coinbase 10** by Etherscan. The address/label pairing also appears in Etherscan's own address-metadata API documentation. Three successful primary RPC transaction/receipt pairs verify callers, token contracts, recipients and exact amounts. Times come from retained explorer records and are not an additional block-timestamp RPC crosscheck.

This gives a precise potential exchange account-mapping lead. It is TLOS swap proceeds, not an identified ML liquidation or original BUSD receipt. A public exchange label does not identify the customer, beneficiary or owner of the deployer.

## Separate ETH route

The retained normal history shows the deployer sent **0.006568313627127521 ETH** to `0xc9899cc6c8864b7751a802a1d4f2dc24650e26ed` on 2 October 2025 at 05:45:23 UTC, transaction `0x85f68c7ad8e8e3910174a841c5a95dced0115d5fb981868aa8fde7b667a09729`.

That intermediate address later sent **0.006559021031199521 ETH** to `0xb5d85cbf7cb3ee0d56b3bb207d5fc4b82f43f511`, labeled **Coinbase 44**, on 22 August 2026 at 12:14:35 UTC, transaction `0x6d2560f865b3db4f4a953e8063a5b4b50e70582a7827b730cfab14d55f81bd7d`. The later transaction and successful receipt were freshly fetched through primary RPC. This is a transfer/address route; the months between transactions and absence of a complete intervening internal-flow replay prevent asserting unique-wei tracing.

## Other bounded findings and limits

The 2025 gas-funding address `0x21b4299644286840ef37de64a18a7dbb8e914969` also previously sent ETH to the same `c989…` intermediate in 2023 and 2024, as displayed in both address histories. This is a relationship to preserve, not proof that the same person controls all wallets.

The cached deployer dataset comprises 154 normal transactions and 105 token events. The latter contains no ML-token event. Two suspicious unrelated-token events mimic earlier sender/recipient or amount patterns; neither is used as an ownership link. This is a bounded exclusion, not a claim that every chain or later event was searched.

Fresh research used five public address pages and eight successful RPC calls. Exact RPC requests, responses, derived event CSV, cached-history extract, source hashes and label URLs are retained. Full webpage bodies will be excluded from the distributable bundle with their hashes listed. No account identity, Laura attribution, exchange customer records or original BUSD recipient was established.
