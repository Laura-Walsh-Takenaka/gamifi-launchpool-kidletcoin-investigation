#!/usr/bin/env python3
"""Reproduce Ethereum ML flow arithmetic from retained explorer HTML. No network."""
from pathlib import Path
from decimal import Decimal, getcontext
import re,json,csv,html,datetime,collections
getcontext().prec=90
P=Path(__file__).resolve().parent
A='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
ML='0x059956483753947536204e89bfad909e1a434cc6'
def text(s):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>',' ',s))).strip()
rows=[]
for page in range(1,4):
 s=(P/f'ml_transfer_list{page}.html').read_text()
 assert 'A total of 131 txns found' in s
 for ordinal,row in enumerate(re.findall(r'<tr\b[^>]*>(.*?)</tr>',s,re.S)):
  tx=re.search(r'/tx/(0x[0-9a-fA-F]{64})',row)
  if not tx:continue
  addresses=re.findall(r'data-clipboard-text=[\'\"](0x[0-9a-fA-F]{40})[\'\"]',row)
  token=re.search(r'/token/(0x[0-9a-fA-F]{40})',row)
  amount=re.search(r'class="td_showAmount"[^>]*data-bs-title="([^"]+)"',row)
  stamp=re.search(r'class=[\'\"]showLocalDate[^>]*>(.*?)</td>',row,re.S)
  block=re.search(r'/block/(\d+)',row)
  method=re.search(r'data-title="([^"]+)"',row)
  assert len(addresses)==2,(page,ordinal,addresses)
  assert token and amount and stamp and block,(page,ordinal)
  ts=int(text(stamp.group(1)))
  dec=amount.group(1).split('|')[0].strip().replace(',','')
  rows.append({'page':page,'row':ordinal,'tx_hash':tx.group(1).lower(),'block':int(block.group(1)),'timestamp':ts,'utc':datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat(),'from':addresses[0].lower(),'to':addresses[1].lower(),'token':token.group(1).lower(),'amount':dec,'method_label':html.unescape(method.group(1)) if method else '', 'source_file':f'ml_transfer_list{page}.html'})
assert len(rows)==131,len(rows)
(P/'all_token_events.json').write_text(json.dumps(rows,indent=2))
ml=[r for r in rows if r['token']==ML]
balance=0
for r in sorted(ml,key=lambda r:(r['block'], -r['page'], -r['row'])):
 raw=Decimal(r['amount'])*10**18
 assert raw==raw.to_integral_value()
 r['raw_amount']=str(int(raw))
 signed=int(raw)*(1 if r['to']==A else -1)
 assert r['from']==A or r['to']==A
 balance+=signed
 r['running_ML']=str(Decimal(balance)/10**18)
(P/'ml_events.json').write_text(json.dumps(ml,indent=2))
with (P/'ml_events.csv').open('w') as f:
 fields=['utc','block','tx_hash','from','to','amount','raw_amount','method_label','running_ML','source_file']
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(sorted(ml,key=lambda r:(r['block'],-r['page'],-r['row'])))
ins=[r for r in ml if r['to']==A];outs=[r for r in ml if r['from']==A]
by_source={}
for r in ins:
 d=by_source.setdefault(r['from'],{'events':0,'raw_amount':0,'methods':set()});d['events']+=1;d['raw_amount']+=int(r['raw_amount']);d['methods'].add(r['method_label'])
for d in by_source.values():d['amount_ML']=str(Decimal(d['raw_amount'])/10**18);d['raw_amount']=str(d['raw_amount']);d['methods']=sorted(d['methods'])
summary={'covered_total_token_events':len(rows),'ML_event_count':len(ml),'ML_in_count':len(ins),'ML_out_count':len(outs),'first_ML_utc':min(r['utc'] for r in ml),'last_ML_utc':max(r['utc'] for r in ml),'total_ML_in':str(sum(Decimal(r['amount']) for r in ins)),'total_ML_out':str(sum(Decimal(r['amount']) for r in outs)),'ML_event_net':str(Decimal(balance)/10**18),'incoming_sources':by_source,'last_10_ML_events':sorted(ml,key=lambda r:r['block'])[-10:],'note':'Explorer HTML supplies amounts and event rows. Running balance assumes no omitted earlier token events; corroborate with independent balance query if available. No transaction or token-unit ownership attribution is inferred.'}
(P/'origin_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
# The explorer embeds its own full normal-transaction export, preserving status
# and exact hash. Read it separately from the token table; labels are not ABI proof.
normal=[]
for page in (1,2):
 s=(P/f'normal_list{page}.html').read_text()
 assert 'A total of 146 transactions found' in s
 m=re.search(r"const quickExportTransactionListData = '(.*?)';",s,re.S)
 assert m
 decoded=json.loads(m.group(1))
 for r in decoded:r['source_file']=f'normal_list{page}.html'
 normal.extend(decoded)
assert len(normal)==146 and len({r['Txhash'].lower() for r in normal})==146
(P/'normal_transactions.json').write_text(json.dumps(normal,indent=2))
normal_by_hash={r['Txhash'].lower():r for r in normal}
important=[r for r in ml if r['block']>=21142885]
(P/'final_funding_steps.json').write_text(json.dumps(important,indent=2))
summary['normal_transaction_count']=len(normal)
summary['ML_outgoing_events_with_successful_normal_transaction']=sum(r['tx_hash'] in normal_by_hash and normal_by_hash[r['tx_hash']]['Status']=='Success' for r in outs)
summary['return_label_ML_event_count']=sum(r['method_label']=='Transfer Remaining To Owner' for r in ins)
summary['return_label_ML_amount']=str(sum(Decimal(r['amount']) for r in ins if r['method_label']=='Transfer Remaining To Owner'))
summary['balance_page_displays_zero_ML']=bool(re.search(r'>\s*0 ML\s*<',(P/'ml_balance_page.html').read_text()))
(P/'origin_summary.json').write_text(json.dumps(summary,indent=2))
print({k:summary[k] for k in ['normal_transaction_count','ML_outgoing_events_with_successful_normal_transaction','return_label_ML_event_count','return_label_ML_amount','balance_page_displays_zero_ML']})
