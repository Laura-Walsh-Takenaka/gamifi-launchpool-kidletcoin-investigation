"""Independent HTMLParser/column-based check; no network or source-file edits."""
from pathlib import Path
from html.parser import HTMLParser
from decimal import Decimal,getcontext
from collections import Counter
from datetime import datetime,timezone
import json,re,hashlib
getcontext().prec=100
P=Path(__file__).resolve().parent
A='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
ML='0x059956483753947536204e89bfad909e1a434cc6'

class Table(HTMLParser):
    def __init__(self):
        super().__init__();self.rows=[];self.row=None;self.cell=None
    def handle_starttag(self,t,a):
        d=dict(a)
        if t=='tr':self.row={'cells':[]}
        elif self.row is not None:
            if t=='td':
                self.cell={'attrs':d,'text':'','nodes':[]};self.row['cells'].append(self.cell)
            if self.cell is not None:self.cell['nodes'].append((t,d))
    def handle_data(self,s):
        if self.cell is not None:self.cell['text']+=s
    def handle_endtag(self,t):
        if t=='td':self.cell=None
        if t=='tr' and self.row is not None:self.rows.append(self.row);self.row=None;self.cell=None

def addr(cell):
    found=[a['data-clipboard-text'].lower() for t,a in cell['nodes'] if re.fullmatch('0x[0-9a-fA-F]{40}',a.get('data-clipboard-text',''))]
    assert len(found)==1
    return found[0]

rows=[];pagecounts={}
for page in range(1,4):
    parser=Table();parser.feed((P/f'ml_transfer_list{page}.html').read_text())
    n=0
    for r in parser.rows:
        c=r['cells']
        if len(c)!=13:continue
        txs=[a['href'][4:].lower() for t,a in c[1]['nodes'] if a.get('href','').startswith('/tx/')]
        if not txs:continue
        assert len(txs)==1
        amountattrs=[a['data-bs-title'].split('|')[0].strip().replace(',','') for t,a in c[11]['nodes'] if 'td_showAmount' in a.get('class','')]
        assert len(amountattrs)==1
        tok=[re.match('/token/(0x[0-9a-fA-F]{40})',a['href']).group(1).lower() for t,a in c[12]['nodes'] if re.match('/token/0x[0-9a-fA-F]{40}',a.get('href',''))]
        assert len(tok)==1
        timestamp=int(c[7]['text'].strip())
        assert datetime.fromtimestamp(timestamp,timezone.utc)==datetime.strptime(c[5]['text'].strip(),'%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)
        row={'tx_hash':txs[0],'block':int(c[4]['text'].strip()),'timestamp':timestamp,'from':addr(c[8]),'to':addr(c[10]),'token':tok[0],'amount':amountattrs[0]}
        assert A in (row['from'],row['to'])
        assert c[9]['text'].strip()==('IN' if row['to']==A else 'OUT')
        rows.append(row);n+=1
    pagecounts[page]=n

def key(r):return (r['tx_hash'],r['block'],r['timestamp'],r['from'],r['to'],r['token'],Decimal(r['amount']))
keys=[key(r) for r in rows]
assert len(keys)==len(set(keys))==131
assert pagecounts=={1:50,2:50,3:31}
supplied=json.loads((P/'all_token_events.json').read_text())
assert Counter(keys)==Counter(key(r) for r in supplied)
ml=[r for r in rows if r['token']==ML]
assert len(ml)==90
assert all(r['from']!=r['to'] for r in ml)
counts=Counter(r['block'] for r in ml)
sameblock={k:v for k,v in counts.items() if v>1}
events=json.loads((P/'ml_events.json').read_text())
assert Counter(key(r) for r in ml)==Counter(key(r) for r in events)
parsed={key(r):r for r in events}
rawin=rawout=running=0
for r in sorted(ml,key=lambda r:r['block']):
    raw=Decimal(r['amount'])*10**18
    assert raw==raw.to_integral_value()
    raw=int(raw)
    e=parsed[key(r)]
    assert raw==int(e['raw_amount'])
    if r['to']==A:rawin+=raw;running+=raw
    else:rawout+=raw;running-=raw
    assert Decimal(e['running_ML'])*10**18==running
    assert running>=0
summary=json.loads((P/'origin_summary.json').read_text())
fmt=lambda n:str(Decimal(n)/10**18)
assert Decimal(summary['total_ML_in'])==Decimal(fmt(rawin))
assert Decimal(summary['total_ML_out'])==Decimal(fmt(rawout))
assert rawin==rawout and running==0

steps={}
for r in events:
    if r['timestamp']>=1731068447:
        steps[r['tx_hash']]={'utc':r['utc'],'from':r['from'],'to':r['to'],'ML':r['amount'],'running_ML':r['running_ML']}
out={'status':'PASS','independent_parser':'Python HTMLParser, fixed table columns, amount from full-precision tooltip','pages_and_counts':pagecounts,'total_token_event_rows':len(rows),'unique_full_row_keys':len(set(keys)),'ML_rows':len(ml),'ML_in_count':sum(r['to']==A for r in ml),'ML_out_count':sum(r['from']==A for r in ml),'ML_same_block_groups':sameblock,'self_transfers_ML':0,'all_rows_match_agent_outputs':True,'all_90_raw_values_match_exact_integer_conversion':True,'all_90_running_ML_values_match':True,'total_ML_in':fmt(rawin),'total_ML_out':fmt(rawout),'net_ML':'0','final_steps':steps,'limitations':['Indexed HTML event census, not independent raw-log retrieval.','Zero running start assumes no omitted earlier ML history.','Labels do not establish purpose, project liabilities or human ownership.','Balances mix fungible ML; running arithmetic is not tracing uniquely identifiable token units.'],'source_sha256':{f'ml_transfer_list{i}.html':hashlib.sha256((P/f'ml_transfer_list{i}.html').read_bytes()).hexdigest() for i in range(1,4)}}
(P/'peer_validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['final_steps','source_sha256']},indent=2))
