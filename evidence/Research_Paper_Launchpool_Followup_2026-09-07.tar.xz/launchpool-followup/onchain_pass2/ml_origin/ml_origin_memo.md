# Immediate ML origin and treasury funding — bounded second pass

**Finding:** the two June 2025 transfers from `0x77bfe8d704b1948374bf8dab8328a810b2836e66` to the current distributor's treasury total **1,246,638.736235076904436035 ML**. Their balance origin can be reconciled exactly: an existing ML balance, a 990 ML exchange-labelled inflow, and **571,273.64975205313681756 ML returned from an earlier ML-holding contract on 29 May 2025**, less a separate 10 ML transfer to a Safe address. This establishes token movement and wallet roles. It does not establish Laura's personal control, legal ownership, original investor cash custody, or the earlier contract's remaining liabilities.

Scope: Ethereum; exact ML contract `0x059956483753947536204e89bfad909e1a434cc6`, 18 decimals. Public, read-only collection on 7 September 2026; detailed capture UTC/URLs/hashes in `etherscan_requests1.json` through `etherscan_requests4.json`. No wallet interaction or transaction submission. The full current-distributor audit and migration policy are separate and unchanged.

## Exact immediate funding bridge

All amounts below are ML. Running balances use all retrieved ML transfer rows for 77bf, beginning with zero before its earliest indexed ML event. The final zero is also displayed on the captured Etherscan holder page, although that is not a separately pinned RPC measurement.

| UTC | Movement | ML amount | 77bf cumulative ML after movement |
|---|---|---:|---:|
| 8 Nov 2024 12:20:47 | 77bf funds earlier contract 4d7b | −706,395.73825655713798756 | 674,385.086483023767618475 |
| 3 Mar 2025 10:54:11 | MEXC 16-labelled address → 77bf | +990 | 675,375.086483023767618475 |
| 29 May 2025 11:10:47 | Earlier contract 4d7b → 77bf | +571,273.64975205313681756 | 1,246,648.736235076904436035 |
| 29 May 2025 11:12:35 | 77bf → Safe address 03fa | −10 | 1,246,638.736235076904436035 |
| 2 Jun 2025 11:17:35 | 77bf → treasury 6c2b | −10 | 1,246,628.736235076904436035 |
| 3 Jun 2025 10:42:11 | 77bf → treasury 6c2b | −1,246,628.736235076904436035 | 0 |

Exact transaction sources in table order:

1. [November funding](https://etherscan.io/tx/0xcf0db84fd2f9d4f680b59ea044decd22a1dd4e0073ad6e04e6505b05dc9fbe1a)
2. [March 990 ML receipt](https://etherscan.io/tx/0xe636ba97c0275adb1c4513fa034765b9ba7a576ee64bb861be5e1f7e9721e264)
3. [May 29 return](https://etherscan.io/tx/0xf86225aedc2adce03c53e006d295c8241623154d664ecd92b45f1c3dec3e8769)
4. [May 29 separate 10 ML transfer](https://etherscan.io/tx/0xcdc28d5aefc2e4ef15f320acd434b1aed8f5ddcb7a1bfac7956d583c3a24e2d0)
5. [June 2 treasury transfer](https://etherscan.io/tx/0x52af33bad07a0aa5b078c47d40c5333dcf5c7e3d2716215d7d2be7bc559ee061)
6. [June 3 treasury transfer](https://etherscan.io/tx/0x8f2043cd852918d722fa4d46207b6fe8cc659013f4fc2528dd757a4342ec7d59)

These are fungible balance reconciliations, not identification of particular physical token units. The current treasury is `0x6c2b3a90acb72ef896325e19af9098d157f929c4`. Its subsequent final-distributor funding, separate MEXC receipt and 1 ML round trip were already reconciled in `../../laura_thread/treasury/treasury_control_memo.md` and the claims memo.

## What the earlier contract does—and does not—establish

Earlier ML-holding contract: [`0x4d7b84910d042f5431b156397bff0db5ebb4f0a9`](https://etherscan.io/address/0x4d7b84910d042f5431b156397bff0db5ebb4f0a9). The retained address page identifies its source as **unverified**. The normal-transaction census records its creation by 77bf on 8 November 2024 at 12:20:23 UTC, [transaction](https://etherscan.io/tx/0x3f63f5ed8eaa8ec1ae007fbe08ed582b32126a9f8c8a1de78657069ba85f4359). Funding followed 24 seconds later.

The 29 May transaction is successful, was sent by 77bf to 4d7b and has exact calldata `0x2eef326a`. Etherscan labels that selector `transferRemainingToOwner()`. The same transaction transferred the **exact ML token** from 4d7b to 77bf in the amount shown above. Thus this is demonstrably a return of previously held ML before the current treasury arrangement. The method name alone does **not** prove the deployed owner check, withdrawal timetable, root, entitlement set, or that every returned token represented an unclaimed investor entitlement. This pass did not verify those properties. In particular, the generic Launchpool GitHub contract is not treated as the deployed 4d7b source.

The difference between its November funding and May return is **135,122.08850450400117 ML**, but that difference is not labelled claimed or distributed: this pass did not obtain a complete 4d7b token ledger. Its relationship to either current claim ledger remains unresolved. It is distinct from final distributor `0xcc32853fb709666332cde0fc47f3f74119b970c4` and from deployment `0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b`.

The single follow-up exact-similar-source URL returned HTTP 403. Raw runtime bytecode was retained from the already successful address page as `old4d7_runtime_from_etherscan.txt`, but was not decompiled or treated as verified source. Investigation stopped at that boundary.

## Earlier sources and coverage

Three token-history pages returned **131 unique token rows** (50 + 50 + 31). Filtering the exact token address yields **90 ML rows: 53 in, 37 out**, from 21 March 2023 13:33:47 UTC through 3 June 2025 10:42:11 UTC. Gross ML inflow and gross outflow both equal **31,915,885.437859292120865343 ML**, with net zero. The normal-transaction census contains **146 unique transactions** across two pages; all 37 ML outgoing events match successful normal transactions.

The gross totals are repeated token throughput, not money raised or a unique investor allocation. For example, 25 incoming ML rows carry the explorer method label `Transfer Remaining To Owner`, totalling **23,222,507.683904883589227008 ML**. These labels and amounts document observed receipts; they do not establish uniform contract powers or project obligations across the 25 source contracts.

The largest simple-transfer incoming counterparties were:

| Immediate incoming source | ML received by 77bf | Events | Attribution established in this pass |
|---|---:|---:|---|
| `0xa594af6496a61423582b19319732e3c7dc072f9f` | 5,472,201.6735352352 | 10 | Explorer identifies an EOA; no named person or project established |
| `0xdd923ff5961796b3005ee0d964d154ad08bd3695` | 2,499,173.893134413 | 10 | Explorer identifies an EOA; no named person or project established |
| `0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88` | 110,233.41 | 1 | Explorer MEXC 1 label; exchange customer unknown |
| `0x9642b23ed1e01df1092b92641051881a322f5d4e` | 990 | 1 | Explorer MEXC 16 label; exchange customer unknown |

The first observed ML receipt was **683,000 ML from dd923 on 21 March 2023**. Source-wallet token histories were not expanded beyond this bounded inspection of their public address pages. This pass therefore does not connect those EOA receipts to token issuance, a vesting release, or a named beneficial owner. All incoming counterparties and exact totals remain in `origin_summary.json`.

## Safe chronology and separate cash question

The 29 May 10 ML recipient is `0x03fafab75267cdf75c64a1c86188e612205b455e`. A sibling investigation's retained official Safe creation record (`../gas_control/treasury_safe_creation.json`) dates its deployment to **29 May 2025 12:12:11 UTC**, one hour after the token receipt, with treasury 6c2b as initial sole owner and threshold 1. This could be consistent with sending to an address before deployment, but this pass does not establish intent or the address derivation. The May 29 10 ML transfer is separate from the June 2 10 ML treasury transfer. Safe history/balance conclusions belong to the sibling memo.

The two July 2024 USDC receipts totalling **191,393.685754 USDC** are separate assets and a separate custody question. The completed sibling investigation, `../cash_custody/cash_custody_memo.md`, confirms owner-only fundraising withdrawals by 77bf from pool IDs 9 and 10. Their recorded reward token is **IAGON (IAG), not ML**, supported by a current pool lookup and verified source showing the token fields are set at pool creation with no later setter found. This supplies dated contract-owner authority for 77bf, not a named human owner or Mintlayer cash-proceeds attribution. Consult that memo for the current-state versus historical-state qualification.

## Reproduction and limits

Run `python analyze_origin.py`, then `python peer_validate.py` in this directory. Amounts come from full-precision HTML tooltips, not rounded visual table amounts. Decimal arithmetic is converted to exact integer base units. The separate peer parser agrees on all 90 raw values, addresses, hashes, timestamps and running balances; it found no duplicates, self-transfers or same-block ML ordering ambiguity. See `peer_review.md` and `peer_validation.json`.

Source endpoints: `https://etherscan.io/tokentxns?a=0x77bfe8d704b1948374bf8dab8328a810b2836e66&p=1` through `p=3`; `https://etherscan.io/txs?a=0x77bfe8d704b1948374bf8dab8328a810b2836e66&ps=100&p=1` through `p=2`; exact transaction/address/holder URLs are retained in request records. The attempted page-1 token filter was ignored by the site, so all returned tokens were explicitly filtered locally by token address.

An earlier Blockscout 429 was retried only once after natural elapsed time; it again returned 429 and the route was stopped. Its response headers and outcome are retained in `first_request.json`; no Retry-After was supplied. The HTML census is explorer-indexed evidence, not a second independent RPC archive. The peer review independently parses this evidence, not a second network provider. A separate Etherscan holder page displays 0 ML. `SHA256SUMS` authenticates retained evidence and outputs.

**Custody conclusion:** the token trace strengthens the documented connection between 77bf, earlier ML-holding contracts and the current treasury. It does not answer whether a particular human or legal organization owns these wallets. It supplies no basis to call the current fully funded claim reserve missing, to equate ML with original cash payments, or to conclude that Laura personally receives tokens after the migration deadline.
