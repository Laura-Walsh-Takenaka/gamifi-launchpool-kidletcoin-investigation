# Independent ML-origin arithmetic review

**PASS.** A separate HTMLParser implementation using explicit table columns reproduces the original analysis without network calls or modification of its files. Three pages contain **50 + 50 + 31 = 131 unique event rows**. Of these, **90 concern the exact ML token**, comprising **53 incoming and 37 outgoing transfers** for `0x77bfe8d704b1948374bf8dab8328a810b2836e66`.

All event addresses, token identifiers, transaction hashes, blocks, timestamps and full-precision amount tooltips agree with the supplied JSON. Every ML amount converts exactly to its reported integer base units at 18 decimals. All 90 running sums agree. There are no duplicate full event rows, ML self-transfers or same-block ML events introducing ordering ambiguity. The cumulative sum never becomes negative.

Gross ML inflow and outflow both equal **31,915,885.437859292120865343 ML**, leaving an event-net balance of zero. This is gross token throughput, including movement into and out of other contracts; it is not cash raised or the size of a new investor allocation.

The funding decomposition agrees exactly:

| Step | ML movement | Resulting cumulative ML |
|---|---:|---:|
| After 8 November 2024 outgoing transfer | — | 674,385.086483023767618475 |
| 3 March 2025 incoming transfer | +990 | 675,375.086483023767618475 |
| 29 May 2025 return from `0x4d7b…f0a9` | +571,273.64975205313681756 | 1,246,648.736235076904436035 |
| 29 May transfer to `0x03fa…455e` | −10 | 1,246,638.736235076904436035 |
| 2 June transfer to final treasury | −10 | 1,246,628.736235076904436035 |
| 3 June transfer to final treasury | −1,246,628.736235076904436035 | 0 |

The two June transfers therefore total **1,246,638.736235076904436035 ML**. The running balance assumes the retrieved explorer history contains all earlier ML events; this review independently parses the same evidence and does not supply a second chain-history source. Explorer method labels alone do not establish the purpose of withdrawals, the underlying project obligations, or human ownership. Fungible balances are being reconciled; uniquely identifiable token units are not being traced.

Reproduction and exact checks: `peer_validate.py` and `peer_validation.json`.
