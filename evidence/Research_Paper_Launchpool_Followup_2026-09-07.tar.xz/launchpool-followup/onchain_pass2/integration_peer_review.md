# Final integration review: sections 9.9–9.10 and F27–F31

**PASS: no material numerical, contract or attribution error identified in `onchain_pass2_content.py`.** Exact checks and the reviewed content hash are in `integration_peer_check.json`.

The Safe initialization bytes independently decode to the treasury as the single owner with threshold one. The pinned getter values agree and return nonce zero and 10 ML. The prefunding/creation interval is 3,576 seconds (59 minutes 36 seconds). The historical code error is correctly described as an access failure; no zero-code result is invented. Modules and guards remain expressly unaudited, preserving the limit on claims about every possible control path.

The 571,273.64975205313681756 ML source is correctly described through the observed caller/transfer and explorer method label. The unverified source prevents elevating that label into proof of an enforced ownership restriction, deadline or beneficiary allocation.

PoolInfo results for pools 9 and 10 both put `0x40eb746dee876ac1e78697b7ca85142d178a1fc8` in the reward-token field and the exact USDC contract in the fundraising-token field. The root's issuer check supplies the IAG name/address attribution. The reviewed fundraising source has an owner-only `claimFundRaising` function which pays `owner()`, and no reward-token setter after pool addition. Preserved successful claim records identify pools 9/10 and amounts **123,488.370079 + 67,905.315675 = 191,393.685754 USDC**. Describing administrative control at those calls is supported. Separating these IAG-pool receipts from the Mintlayer BUSD collection gap is necessary and correctly done.

The ML event totals, later distributor refresh and transfer-route amounts match the prior independent numerical checks. Gross token turnover remains distinguished from money raised; old-contract history is scoped to retrieved records; exchange labels remain separate from customer identities; and no Laura beneficiary or deadline-triggered transfer is asserted.

This review used retained evidence only and changed no integration content or PDF.
