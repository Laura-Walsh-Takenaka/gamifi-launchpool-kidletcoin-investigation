# Independent check of root’s pinned Safe RPC responses

The successful responses independently decode to **one listed owner, threshold 1, nonce 0, and 10 ML**, with deployed bytecode present, at Ethereum block **25,923,475** (`0x18b8f93`). This closes the earlier gap concerning the Safe’s current owner list, threshold, nonce and token balance at a defined block.

- Safe: `0x03fafab75267cdf75c64a1c86188e612205b455e`.
- Listed owner: `0x6c2b3a90acb72ef896325e19af9098d157f929c4` (the Mintlayer treasury).
- ML token: `0x059956483753947536204e89bfad909e1a434cc6`.
- ML balance: `10000000000000000000` base units = **10 ML** using the earlier independently retained token `decimals()` result of 18 (`../../claims/pinned_decimals.json`).
- Bytecode: 171 bytes; SHA-256 `5b8bff324e02136edb0775bd77aa0fe773c1e23092305fe63f50a9e92f5b8faf`.
- RPC request recorded at `2026-09-07T05:53:49.049558+00:00`. This is the request timestamp, not a newly retrieved block-header timestamp.

The review checked the exact response-file SHA-256 against the request receipt; unique JSON-RPC IDs; the expected successful/error mapping; each target address and block; exact `balanceOf` encoded account; selector hashes computed independently with Keccak-256 for `getOwners()`, `getThreshold()`, `nonce()`, and `balanceOf(address)`; and the ABI dynamic-array offset, length and owner address. The independently decoded current owner and threshold match the initial Safe creation setup retained separately.

**Limits retained:** owner-list membership does not enumerate every possible execution path. Enabled modules, guards, fallback configuration and any other delegated authority were not examined by these calls. No exclusive-human-control or exclusive-execution-control finding is made. Nonce 0 and an empty indexed multisig history do not prove an absence of every possible module action or inbound/outbound event.

The historical observation, code at the 10 ML transfer block **22,588,033**, failed because the RPC requires a personal token for archive requests. The access requirement was not bypassed. The error is preserved, supplies no historical-code evidence, and does not undermine the five successful current-state responses. The separate official Safe creation record still dates creation to 29 May 2025 at 12:12:11 UTC; the companion token-transfer record precedes it by 59m36s.

Raw initial records were retained unchanged. `root_safe_rpc_peer_check.json` records normalized results; `control_summary.json` now includes the completed current-state check. Gas-funder lifetime history and human/account attribution remain unresolved.
