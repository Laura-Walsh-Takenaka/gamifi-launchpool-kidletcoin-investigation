# Gas funding and the treasury’s separately deployed Safe

Research date: 7 September 2026. Read-only public records and exact analysis of the retained transaction evidence. No wallet connection, signature or transaction.

## New finding

**Mintlayer treasury `0x6c2b3A90aCb72eF896325e19Af9098D157f929c4` created a separate Safe at `0x03FAFab75267CdF75c64a1c86188E612205B455E`, with itself as the sole initial owner and threshold 1.** A Safe address therefore exists in this operational history, but it is a different address from the final-distributor treasury and from the gas funder. Its initial configuration required only one owner authorization.

The official Safe Transaction Service identifies the creator, creation time, transaction hash, factory, singleton and fully decoded setup. The setup’s initial owner array and threshold were independently decoded from its raw bytes and matched the retained explorer transaction exactly.

| UTC, 29 May 2025 | Event | Evidence |
|---|---|---|
| 11:12:35 | `0x77BFe8d704B1948374bf8dab8328a810b2836e66` sends 10 ML to future Safe address `0x03FA…B455E` | Companion ML-origin agent’s explorer capture; tx `0xcdc28d5aefc2e4ef15f320acd434b1aed8f5ddcb7a1bfac7956d583c3a24e2d0`, block 22588033. Raw files in `../ml_origin/`. |
| 12:11:23 | Gas funder `0x1aAfe5974189E5a854E20617be8176578868da0F` sends 0.01 ETH to treasury `0x6c2b…29c4` | tx `0x71cfd39e902af8ec5a743064bcfef762dd48b7a1de1de84aabf8edf076e7799f`, block 22588326. |
| 12:12:11 | Treasury creates Safe `0x03FA…B455E` | tx `0xc79d5e844782a9fdc0d3aee4c53f4c6f414042cfaca6a7693e3d1b70492f58af`, block 22588330; official Safe creation record. |

The 10 ML transfer precedes creation by **59 minutes 36 seconds**. The gas funding precedes creation by **48 seconds**. Transferring tokens to an address before contract deployment is compatible with prefunding a predicted address; that operational explanation is an inference, not a retrieved instruction or identity proof. The ML-origin lane should perform the final citation/receipt verification for its transaction.

## Gas-funder classification and comparison

The gas transfer is a successful normal/top-level transaction from `0x1aAfe…8da0F`, with nonce 128, empty calldata and gas used 21,000. It identifies an external transaction-origin signer for that transfer. It was not obtained as an internal transfer emitted by a Safe execution. Its current bytecode was **not** successfully read in this lane, so a fresh no-code assertion is not made.

The gas funder’s checksummed Safe detail route returned 404; an official owner-to-Safes query returned an empty list. Those are service/index observations, not proof that the address has never had any smart-account association.

Neither gas funder `0x1aAfe…8da0F` nor BSC GMI owner `0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b` appears in the retained deployer datasets checked here: **154 normal transactions and 105 token-transfer events** for `0xb72fc236Ab043029776b9d25e99A5B6456A2e16D`. This is a bounded exact-address comparison. It does not rule out indirect transfers, other chains or relationships outside those files. The original dataset hashes and zero-match results are in `control_summary.json`.

The Safe’s **initial** owner set contains the treasury only, not the deployer or GMI owner. A subsequent root RPC batch, independently decoded in `root_safe_rpc_peer_check.md`, pins the current owner array to that same sole treasury address and the threshold to 1 at Ethereum block 25,923,475. The nonce is 0, deployed code is present, and the ML balance is exactly 10. Modules and guards were not inspected; the owner list is not a complete census of execution authority.

## Safe activity and remaining gap

The official multisig-transactions endpoint returned `count:0`, `results:[]`, `next:null`, and `countUniqueNonce:0`. This records an empty Safe-service multisig history. It does not prove no inbound token transfers, no balance, or exhaustive coverage of every possible module/internal transaction. A token transfer into a Safe does not itself require the Safe to execute a multisig transaction.

The Safe API detail call returned HTTP 429 and that route was stopped. A subsequent successful root RPC batch closed the current owners/threshold, nonce, code and ML-balance gaps at block 25,923,475; independent review is in `root_safe_rpc_peer_check.md`. The Safe held exactly 10 ML at that block. Comprehensive transfer/event history, enabled modules and guards remain unexamined. A historical code query at the earlier 10 ML transfer block failed with an archive-authentication requirement; it supplies no historical-code evidence.

The gas funder’s lifetime history was not retrieved: Blockscout address/transaction and Etherscan requests returned 403, Publicnode RPC returned 403, Llama RPC timed out, and Trezor’s address API returned 403. These access failures were preserved and were not treated as empty histories. No named human/controller attribution is established by the gas transfer, timing, sole-owner Safe or Laura’s job title.

## Primary records

- Treasury-owned Safes: https://safe-transaction-mainnet.safe.global/api/v1/owners/0x6c2b3A90aCb72eF896325e19Af9098D157f929c4/safes/
- Exact Safe creation: https://safe-transaction-mainnet.safe.global/api/v1/safes/0x03FAFab75267CdF75c64a1c86188E612205B455E/creation/
- Indexed multisig history: https://safe-transaction-mainnet.safe.global/api/v1/safes/0x03FAFab75267CdF75c64a1c86188E612205B455E/multisig-transactions/?limit=20
- Gas-funder owned Safes: https://safe-transaction-mainnet.safe.global/api/v1/owners/0x1aAfe5974189E5a854E20617be8176578868da0F/safes/
- Historical treasury transactions: https://eth.blockscout.com/api?module=account&action=txlist&address=0x6c2b3a90acb72ef896325e19af9098d157f929c4

Raw successful responses, original prior records, request receipts, errors and SHA-256 checksums are retained in this folder. `treasury_safe_creation.json` closes the identity and initial owner configuration of the separately created Safe. `root_safe_rpc_response.json` and its independent peer check verify the listed current owners, threshold, nonce, code presence and ML balance at block 25,923,475. It does not identify a legal entity or a human key holder.
