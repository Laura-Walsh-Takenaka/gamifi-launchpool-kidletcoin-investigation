# Distributor follow-up: earlier history recovered; final state unchanged

Ethereum block **25,923,475**, **7 September 2026 05:45:47 UTC**. Block hash: `0x649e3846d637a57dfa2efdc0ab4173b42c3d339b017aab2ab979361ef60c5622`.

## Earlier related deployment

At `0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b`, successful pinned RPC reads now show **zero ML balance** and the same token/root as the final distributor. All **eight** bitmap words at mapping slot 0 are zero: **none of the 1,999 published indices is marked claimed**. Slot 0 follows the previously reviewed source, which has no inherited owner state and uses immutable token/root values.

Successful Blockscout v2 history responses now close the earlier access failure:

- `/api/v2/addresses/0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b/transactions` returns **one record**, the previously verified 24 July 2025 creation transaction, and `next_page_params: null`.
- `/api/v2/addresses/0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b/token-transfers` returns **zero records** and `next_page_params: null`.

These are successful, explicitly empty transfer-history results, corroborated by the zero pinned balance and unchanged claim bits. The earlier contract appears unused for funding/distribution in these records. This is indexed history plus pinned state, not an independent replay of every Ethereum transfer log. No operational replacement, transfer between the two contracts, or second set of investor liabilities is inferred from the shared root.

## Final distributor refresh

At `0xcc32853fb709666332cde0fc47f3f74119b970c4`, the owner, treasury, token, root, ML balance and **all eight bitmap words are unchanged** from block 25,923,249.

| Refreshed measure | Exact result |
|---|---:|
| Claimed indices | 119 |
| Unclaimed indices | 1,880 |
| Claimed ML | 178,609.45446753072393 |
| Unclaimed ML | 1,116,040.8456174469614254 |
| Distributor balance ML | 1,116,041.281767546177360307 |
| Balance above unclaimed ML | 0.436150099215934907 |
| Added or removed claimed indices | 0 |

No new claim reconciliation was needed. Equal endpoint balances do not rule out intervening transfers; a fresh full final-contract transfer history was not fetched. The earlier 119-transaction/input/payment reconciliation remains dated to the earlier block, while these state values have now been refreshed.

## Acquisition and limitations

PublicNode and dRPC independently returned the same head, `0x18b8f93`. PublicNode then returned successful results for all 14 old-contract/block/token queries and all 13 final-contract queries, pinned to that block. A further five-query state batch through dRPC returned **HTTP 500** and supplied no crosscheck result. Its failure is preserved and is not treated as zero evidence. No retry loop or state-changing transaction was used.

The exact requests/responses, receipt times, HTTP outcomes and hashes are in this directory. `summary.json` contains the decoded numerical results; `manifest.json` indexes acquisition records. Earlier 403/429 failures remain preserved in the prior investigation and are superseded only for the specific questions answered by these successful reads.
