from pathlib import Path
import urllib.request,urllib.error,json,hashlib,datetime
BASE=Path(__file__).resolve().parent

def fetch(name,url,request=None):
    rec={'name':name,'url':url,'request':request,'started_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    data=None if request is None else json.dumps(request,separators=(',',':')).encode()
    req=urllib.request.Request(url,data=data,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json','Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=25) as r:
            raw=r.read();rec.update(status=r.status,headers=dict(r.headers),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
            (BASE/(name+'.response')).write_bytes(raw)
            try:result=json.loads(raw)
            except Exception:result=None
    except urllib.error.HTTPError as e:
        raw=e.read();rec.update(error=str(e),status=e.code,headers=dict(e.headers),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        (BASE/(name+'.response')).write_bytes(raw)
        result=None
    except Exception as e:
        rec.update(error=str(e));result=None
    rec['finished_UTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (BASE/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2)+'\n')
    print(name,rec.get('status'),str(result)[:450] if result is not None else rec.get('error'),flush=True)
    return result

def rpc(method,params=[],id=1):return {'jsonrpc':'2.0','method':method,'params':params,'id':id}
