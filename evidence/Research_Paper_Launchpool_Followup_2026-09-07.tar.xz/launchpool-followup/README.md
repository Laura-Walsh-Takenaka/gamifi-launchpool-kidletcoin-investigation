# Launchpool follow-up evidence — 7 September 2026

Start with `reports/Research_Paper_Launchpool_Followup_2026-09-07.pdf` or `LAUNCHPOOL_FOLLOWUP_2026-09-07.md`. The updated PDF preserves the prior corporate report and adds claims, website and operating-transition findings.

## Evidence scope

- `claims/`: public allocation datasets, pinned Ethereum RPC responses, claimed bitmap words, explorer transaction/event data, exact CSVs and read-only reproduction code.
- `claims_peer/`: a separately implemented proof/tree verifier and transaction/bitmap/transfer reconciliation. It uses the same preserved public evidence, not a separate historical witness.
- `gmi_sources/`: fresh BSC balance/owner reads and failed historical-log queries. The prior unpaid schedule total was not recalculated on 7 September.
- `prior_gmi_basis.json`: dated section 7 extract from the existing GamiFi master, version 3. The original underlying GamiFi audit collection is outside this follow-up bundle.
- `website_sources/`: RDAP, DNS, archive indexes and retrieval receipts; archived-shell excerpt and body hash.
- `migration_support_sources/`: current official migration-policy excerpts and retrieval records. Current deadline: 1 November 2026. No individual migration submission or mainnet receipt was tested.
- `transition_source_records.json`: source records and retrieval limits for the 2024 operating transition.
- `laura_thread/`: original offer fields and chronology, Laura role records and bounded search scope, treasury inflows and the MEXC-labeled withdrawal, related distributor source comparison, and separate migration-contract mechanics. Full webpage/application bodies are excluded explicitly. Detailed research notes support sections 9.6-9.8; the consolidated PDF controls the final conclusions.
- `onchain_pass2/`: upstream ML reconstruction, treasury-owned Safe, owner-authorized IAG fundraising receipts, deployer exchange-facing routes and refreshed distributor state. Exact read-only requests, raw data, derived ledgers, independent reviews and failed acquisition records are retained. Sections 9.9-9.10 distinguish wallet control from human identity.
- `onchain_pass3/`: recovered original BSC project/pool mapping and raised counters, historical BUSD purchase, old ML claims and selected runtime checks, vesting origins, dated Ethereum control handover and USDC exchange routes. Sections 9.11-9.14 preserve source, commingling and human-attribution limits. Full HTML/JavaScript and candidate unverified source in retrieval_work are omitted.
- `onchain_pass4/`: additional Raise 1 ML reserve and 24-tranche census, same-block final Raise 2 refresh, actual D975 withdrawal mechanics, six other projects' BUSD receipts and Circularr ChangeNOW route, shared-wallet ML/USDC exchange routes, and Circle/Base trading continuation. Independent reviews preserve authority, proof-coverage, source-commingling and attribution boundaries.
- `onchain_pass5/`: targeted continuation of the later Base trading returns and the published Raise 1 entitlement-ledger search. These findings update the existing reserve and trading sections; earlier findings and dated observations remain preserved.
- `onchain_pass6/`: all six original Mintlayer BUSD withdrawal receipts, bounded onward BUSD payments and Binance route, returned-funds KuCoin route, repeated Revolut-associated payments, and a conditional IAG source-conservation interval. Independent checks cover exact receipt and event evidence, historical-state scope, and service-versus-person attribution.
- `onchain_pass7/`: additional original BUSD routes to Binance, closure of the owner-window gap, bounded later custody and outflows, Kraken collection mechanics with measured commingling limits, and an exact initial IAG USDC partition with shared-source bounds.
- `onchain_pass8/`: bounded BUSD tail checks, Kraken USDT collection and source bounds, a separate mixed USDC Binance-deposit route, corrected handoff gaps and inspector records targets. Earlier evidence is preserved; historical cutoffs and separate tokens remain explicit.
- `original/`: the prior Launchpool corporate report, for preservation and rebuilding. Its historical source collections remain separate; this bundle does not claim to contain every underlying corporate deed or filing.

## Reproduction

Extract the whole ZIP, preserving directory structure. Run `python3 claims/reproduce.py --offline` to verify all allocation proofs and reconcile claims against the included snapshots. This uses Python's standard library and makes no network request. It rewrites derived peer reports with the reproduced results. The separate `--fetch-dir /absolute/path/to/new_capture` mode makes public read-only requests and saves a new capture; current explorer responses may extend beyond the original pinned block.

For the third pass, `python3 onchain_pass3/ml_upstream/reproduce_verified.py` and `python3 onchain_pass3/old_ml_contract/independent_peer_checks.py` recheck retained factual records offline. Some collection and parser scripts require the full source webpages intentionally excluded from this bundle; their completed checks and source hashes remain included. In particular, the KuCoin checks are explorer-derived status/calldata evidence, not successful raw RPC receipts.

For the fourth pass, `python3 onchain_pass4/bsc_settlements/peer_review_verify.py` independently decodes the retained raw BSC receipts and verifies all 18 project withdrawals plus the Circularr split and convergence. This offline check requires no omitted webpage. The shared-wallet and Base peer reports document exact receipt coverage, complete token-ledger reconciliation and explicitly disclosed inventory-request reconstructions.

For the fifth pass, `python3 onchain_pass5/root_reconciliation/reconcile_july_base.py` rebuilds the July Base USDC ledger from retained factual records without network access. `python3 onchain_pass5/peer_review/verify_final_base_return.py` checks the second bridge, Ethereum swap and payments, and distinguishes event-derived USDT balances from unsuccessful historical state calls. These scripts rewrite their derived results; run them in an extracted working copy if retaining original checksums. Full GitHub README bodies are omitted; repository tree metadata, source hashes and factual observations remain included.

For the sixth pass, `python3 onchain_pass6/original_busd/recover_receipts.py --offline` reconstructs the original six BUSD withdrawals. `python3 onchain_pass6/peer_review/onward_peer.py` independently checks the onward BUSD receipts and historical balance equations. `python3 onchain_pass6/source_bounds/reconcile_source_bounds.py` rebuilds the conditional USDC source interval. Run these offline scripts in an extracted working copy: they rewrite derived results. RPC receipts, indexed confirmations and failed requests retain their separate evidence status.

For the seventh pass, run `python3 onchain_pass7/peer_review/independent_busd.py`, `python3 onchain_pass7/peer_review/independent_iag.py`, and `python3 onchain_pass7/peer_review/independent_returned.py` to independently replay the BUSD routes/source bounds, USDC disposition/source intervals, and Kraken-route receipts/state equations. These commands use preserved factual files and no network. Run in an extracted working copy; generated results are rewritten.

For the eighth pass, run `python3 onchain_pass8/source_accounting/reconcile_return.py`, `python3 onchain_pass8/source_accounting/reconcile_busd_frontier.py`, and the independent commands listed in `onchain_pass8/peer_review/MEMO.md`. Use an extracted working copy because derived JSON is rewritten. The selected USDT return interval has new raw log coverage and successful historical states; this does not upgrade unrelated source histories.

To rebuild the PDF, install PyMuPDF and ReportLab, make DejaVu Sans fonts available under `/usr/share/fonts/truetype/dejavu/`, and run `python3 build_report.py`. The content inputs, extension module and original PDF are included.

## Preservation limits

Full third-party webpages and the minified claim application are omitted. Their hashes, receipt metadata, short extracts or factual observations are retained. `capture_preservation_index.json` explicitly lists excluded bodies. Capture-local checksum lists retain their original wider scope; use root `SHA256SUMS.txt` to check actual bundle files. Exploratory research memos are superseded by the consolidated findings.

Wallets are not identified as people. Token backing is measured in token units, not dollars. No wallet connection, signature, transaction, purchase or external records request was made.
