# Official announcement inspected 7 September 2026

Source: https://t.me/s/launchpoolannouncements/1500
Web source reference: turn536405view1 (root must open before final citation).
Associated original X status: https://twitter.com/LaunchPoolXYZ/status/1762833659093041216

Lines 197–217 of web-retrieved public Launchpool Community Announcements page contain the 2024 project status update. Under the category “Completed Vesting,” Gamifi is included among the projects. This verifies Launchpool’s published category; it does not itself state that every beneficiary claimed or was paid. Linear vesting maturity and actual distribution are different on-chain facts.

A separate historical official notice was surfaced by web search at https://t.me/s/launchpoolannouncements?q=%23Gaming (turn812236search0). It routes GMI beneficiaries to https://app.gamifi.gg/launchpool-claim/, gives BSC token0x93D8d25E3C9A847a5Da79F79ecaC89461FEcA846, and describes remaining tokens vesting linearly over nine months. The dated individual Telegram message should be captured before using a precise announcement date.

Direct Python HTML retrieval for the 2024 announcement timed out. Web retrieval succeeded; no direct HTML artifact is represented as captured.
