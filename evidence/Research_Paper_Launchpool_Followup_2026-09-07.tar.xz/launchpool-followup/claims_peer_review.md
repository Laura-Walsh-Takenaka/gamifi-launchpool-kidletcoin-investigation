# Independent validation of the Launchpool Mintlayer claim data

Review date: 7 September 2026. Scope: independent local checks of the recovered claim files and the pinned Ethereum state collected by the claims-forensics agent. This review did not conduct a second network census.

## Claim-file integrity and arithmetic

The independent script `claims_peer/verify_claims.py` checks raw integer amounts and uses decimal arithmetic without binary floating point. Its full machine-readable results are in `claims_peer/independent_validation.json`.

| Check | Independent result |
|---|---|
| Duplicate literal JSON keys | None in the checked claim and readable files |
| Claim entries | 1,999 |
| Distinct addresses, ignoring case | 1,999 |
| Distinct indices | 1,999; exactly 0 through 1,998 |
| Allocation total, base units | 1294650300084977685355400 |
| Total using 18 decimal places | 1,294,650.3000849776853554 ML |
| Declared `tokenTotal` comparison | Exact match |
| Readable-file address set | Exact match |
| Readable-file amount comparison | All 1,999 equal their hex amounts exactly at 18 decimals |
| Individual Merkle proofs | 1,999 passed; zero failed |
| Independently rebuilt complete tree | Matches the published root |

The matching root is `0x031862a21347c8b43c3fd3e7d67615141f32476371b3a31e3447de2530d06aa7`.

No Keccak library was installed, so a small pure-Python Keccak-256 implementation was used. Before the proof checks, it passed the known empty-string and `abc` digests and the known ERC-20 `transfer(address,uint256)` selector. Leaves use the deployed contract's `keccak256(abi.encodePacked(index, account, amount))` encoding. Each proof hashes sorted sibling pairs; the independently built full tree sorts leaves and promotes unpaired nodes.

These checks establish internal consistency of this allocation dataset and its commitment to the published Merkle root. The allocation dataset itself does not state whether a given entitlement was claimed, remains unpaid, was otherwise settled, or belongs to a distinct human investor.

## Contract and state consistency

The stored Blockscout verified-source response identifies the distributor as `0xcc32853fb709666332cde0fc47f3f74119b970c4`, compiler 0.8.17, and a non-proxy contract. Its constructor arguments match the claim root, the token `0x059956483753947536204e89bfad909e1a434cc6`, and treasury `0x6c2b3a90acb72ef896325e19af9098d157f929c4`.

The locally stored RPC results are pinned to Ethereum block **25,923,249**, hash `0xcbe553133f79829c8da8a4519d3944aa36c482c42cecc74a1986c05b5a22f912`, timestamp **2026-09-07 05:00:23 UTC**. They return:

- The same Merkle root and token.
- Token `decimals()` equal to **18**.
- Owner and treasury both equal to `0x6c2b3a90acb72ef896325e19af9098d157f929c4`.
- Distributor token balance **1,116,041.281767546177360307 ML**.

These balances use the specific historical ERC-20 token's 18-decimal scale, not the decimals of another asset or a later native Mintlayer coin. The ML token contract and the distribution contract are different addresses with different functions.

The verified deployed `claim()` function contains **no deadline**, no pause check, and no requirement that the caller equal the beneficiary. A valid claim transfers to the beneficiary committed in the proof. Therefore an announced April 2026 deadline is not an expiry condition in this deployed contract. This is a code-level result, not a promise that an arbitrary claim will succeed; claimed status and the token transfer conditions also matter.

The owner can call `withdraw()` to transfer the distributor's whole token balance to its immutable treasury, with no timelock in this deployed source. Code capability must be distinguished from its actual use, reconciled below. The newer GitHub contract is materially different and must not be used to describe this deployed distributor's controls.

The verified imports independently confirm the bitmap storage layout: OpenZeppelin Ownable has only `_owner` at slot 0, Context has no state, and the distributor's token, root and treasury are immutable. `claimedBitMap` therefore occupies mapping slot 1. Eight derived storage keys for indices 0 through 1,998 are recorded in `claims_peer/rpc_slots_and_selectors.json` for the independent RPC census.

## Interpretation limits

Keep the following distinctions in the main report:

- **Allocation is not the unpaid balance.** Use the census of current claim bits to label entries unclaimed in this distributor.
- **Unclaimed in this contract is not proven investor loss.** Refunds, alternative settlement or other compensation require separate records.
- **A wallet is not a person.** There is no human ownership or Laura attribution in these claim files or getter outputs.
- **Token units are not US dollars.** Neither entitlement nor remaining tokens should be presented as dollar losses without a separate valuation method and date.
- **Contract capability is not conduct.** Withdrawal authority and absence of an on-chain deadline need to be distinguished from actual withdrawal events and off-chain notices.

## Independent bitmap and transfer reconciliation

The second independent script, `claims_peer/reconcile_claims.py`, decodes the eight stored bitmap words directly, reads the original Blockscout transaction and token-transfer responses, and checks the following values against the same pinned block. Results are in `claims_peer/independent_reconciliation.json`.

| Category at block 25,923,249 | Count | ML at 18 decimals |
|---|---:|---:|
| Entire Merkle allocation | 1,999 entries | 1,294,650.3000849776853554 |
| Claimed in this distributor | 119 indices | 178,609.45446753072393 |
| Unclaimed in this distributor | 1,880 indices | 1,116,040.8456174469614254 |
| Distributor balance | One contract | 1,116,041.281767546177360307 |
| Balance minus unclaimed allocations | — | 0.436150099215934907 |

All 119 successful claim-transaction inputs independently decode to an address, amount and index that exactly match the published claim data. Their indices exactly match the 119 set bitmap bits. Every one also matches a token-transfer event in the same transaction for the correct ML contract, beneficiary and amount. No bit outside the 1,999 published indices is set in these eight words.

The retrieved account history contains 156 normal transactions and 124 token-transfer events. One transfer belongs to a different token and is excluded. For the remaining 123 ML events, the sum of inflows less outflows exactly equals the pinned ML balance. The returned transaction hashes are unique, and all returned blocks precede the pinned block. This arithmetic plus the complete bitmap agreement is a strong internal reconciliation; this review did not independently re-query an additional explorer or verify an RPC storage proof against the state root.

The claims-forensics agent also attempted 16 `isClaimed(index)` getter calls through a second RPC provider at the same block. Six returned successfully and all six match the independently decoded bitmap (two claimed, four unclaimed); ten timed out. These are six completed cross-provider checks, not sixteen passes. The stored response file is `claims/isClaimed_crossprovider_spotchecks.json`.

The latest successful claim in these records is **3 May 2026 at 12:57:47 UTC**, transaction `0x40eea95f6fac65437483a33fdf9564cfd48ea3305c5dc8b3bbae50481dc484e9`, for **1,867.58442243481 ML**. This establishes a successful distribution after April 2026. The exact advertised deadline and native-token migration arrangements remain separate documentary questions.

The one successful withdrawal transferred **1 ML** to the treasury on **10 October 2025**, transaction `0xd3eb97f9e4acdf302ab98e5c058d5768e8b2a1df04b740004cc7373f7a8e520d`. This followed a 1 ML incoming transfer and preceded incoming amounts of 100,000 ML and 1,194,650.736235076901290307 ML. Calling it a test would be an inference about purpose; the verified sequence is the small round trip before main funding.

A second withdrawal call on **25 March 2026**, transaction `0xb41ca7e94895ab95886a38f49965365caeaebae8707f6c43bf37759837c23e6b`, has failed status in the explorer data. The saved Etherscan page identifies the error as a non-owner caller. No ML transfer is recorded for that failed call.

The supported conclusion is that the remaining **1,880 entries were unclaimed in this distributor at the pinned block, and its recorded ML balance exceeded their combined allocation by approximately 0.43615 ML**. This evidence does not support a claim that this distributor was emptied or underfunded then. It does not resolve conversion to native ML, off-chain investor rights, the reasons people did not claim, or who controls the treasury in human terms.
