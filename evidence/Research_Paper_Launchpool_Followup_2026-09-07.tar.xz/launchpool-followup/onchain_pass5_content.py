"""Integrate the fifth bounded continuation into existing sections, without duplicate pages."""
def add_pass5(B):
    gaps=[b for b in B if b.get('text','').startswith('<b>Delivery gap:</b> the listed Raise 1 proof endpoint')]
    assert len(gaps)==1
    gaps[0]['text']='<b>Delivery gap:</b> the listed Raise 1 proof directory, claims.launchpool.xyz/mintlayer1-11/, returned HTTP 502 in the prior check. The recovered app builds individual proof URLs from that directory plus a checksummed wallet address and .json. An exact archive-prefix query returned no captures; current tree listings of two published Launchpool Merkle repositories exposed no Mintlayer-named ledger. The full allocation ledger and reconciliation with earlier tranches remain unrecovered. Unpaused code and an unlocked app flag do not establish that holders can obtain their proofs. No human signer or automatic payment to Laura is identified. [F39; F45]'
    start=next(i for i,b in enumerate(B) if b.get('text')=='9.18 Base bridge, BAMBOO trades and returned funds')
    del B[start:]
    def p(t,k='p'):B.append({'kind':k,'text':t})
    p('9.18 Base bridge, BAMBOO trades and returned funds','h')
    p('<b>The July trading route now includes both returns from Base and the later USDT payments.</b> Wallet 1991 sent 2,100 and 25,000 USDC to 183600, which bridged those amounts from Ethereum to itself on Base through Circle CCTP V1. All four reviewed bridge messages match the source events and destination inputs: outbound nonces 81239/81473 and return nonces 235711/240419. [F42-F44]')
    p('Wallet on both chains: <font face="DVM" size="7.3">0x183600361dc42c6f022fd219c3a9dabbf08c9ce4</font><br/>BAMBOO token on Base: <font face="DVM" size="7.3">0x689644b86075ed61c647596862c7403e1c474dbf</font>','small')
    B.append({'kind':'table','widths':[242,257],'rows':[
        ['Verified July 2024 movement','Amount / result'],
        ['10-11 July: two bridge mints','27,100 USDC received on Base'],
        ['Eight BAMBOO purchases','20,100 USDC spent; 3,911,181.851848323949800498 BAMBOO acquired'],
        ['14 July: first two BAMBOO sales','2,000,000 BAMBOO sold for 14,116.998523 USDC'],
        ['All fourteen sales, through 23 July','73,854.395784 USDC received; +53,754.395784 USDC above purchase payments, before native gas'],
        ['18 July: first return via Ethereum to 1991','21,116.99 USDC'],
        ['23 July: second return to 183600 on Ethereum','59,737.4 USDC'],
        ['23 July: Ethereum swap','59,737.4 USDC exchanged for 59,724.105382 USDT'],
        ['23 July: two subsequent USDT payments','1,000 USDT to f695...aae9; 58,724.105382 USDT to 1991'],
    ]})
    p('All 22 BAMBOO trades have successful Base receipts with 66 matched transfer logs. Five further successful receipts verify the second bridge burn/mint, Ethereum swap and two USDT payments. The 13.294618 difference between swap input and output compares quantities of two different tokens; it is not measured as a fee or fiat loss. [F43-F44]','small')
    p('The complete retrieved 699-row Ethereum USDT history through the return reconciles to zero before the swap and zero after both payments. Historical balanceOf requests failed; this is an event-ledger reconciliation. [F44]','small')
    p('Additional USDT recipient: <font face="DVM" size="7.2">0xf695f1d1688698abc97b2e5937ba24934561aae9</font><br/>No public explorer name tag was retrieved. The payment purpose and recipient\'s human controller remain unknown. [F44]','small')
    p('Returns and remaining inventory','h2')
    p('The first return left 0.008523 USDC and 1,911,181.851848323949800498 BAMBOO on Base. Later sales closed that inventory except one raw BAMBOO unit. The second bridge began 118 seconds after the final sale. All 34 July USDC events reconcile to <b>0.005784 USDC</b> after the second burn; historical reads at Base block 17,475,891 independently confirm that balance and the one-unit BAMBOO remainder. [F43-F44]')
    p('The complete indexed Base token history contains 505 rows. Before the first bridge mint, both token balances were zero. At the later 7 September snapshot, block 50,987,229 at 06:50:05 UTC, balances were 0.003937 USDC and one raw BAMBOO unit (0.000000000000000001 token). Later activity is separate from the July trading calculation. [F43-F44]','small')
    p('Attribution and settlement records','h2')
    p('Verified returns to 1991 are 21,116.99 USDC and 58,724.105382 USDT, with the additional 1,000-USDT recipient identified above. The earlier Ethereum source mixed USDC, so this trading cannot be assigned exclusively to an IAG fundraising receipt. Original Mintlayer BUSD and the still-held ML reserves remain separate. Native ETH gas and fiat valuation are excluded; the human trader, company authorization and allocation of returns remain unresolved. [F39; F41-F44]')
    return [
        ('F44','Second Base return, Ethereum swap and exact USDT payments','https://etherscan.io/tx/0x7ae7223ebfbeb9c0a06f34342c1e15f1a068c7feae454548d170d2f8ac16fd43','onchain_pass5/base_final_returns/, root_reconciliation/ and peer_review/: five new successful RPC receipts, Circle nonce 240419, 34-event July USDC reconciliation, post-burn Base state and 699-event Ethereum USDT ledger. Historical USDT state calls failed; event balances are distinguished. Exact swap and payment amounts are verified; payment purpose and human ownership remain unknown.'),
        ('F45','Raise 1 wallet-specific proof files and bounded retrieval gap','https://claims.launchpool.xyz/mintlayer1-11/','onchain_pass5/raise1_entitlements/: recovered app URL construction, exact archive-prefix result and two current public Merkle repository tree listings. No full Mintlayer allocation ledger recovered. Empty archive results are limited to that query; failed requests and an input error are disclosed separately.'),
    ]
