#!/usr/bin/env python3
"""Independent raw-indexed-history arithmetic and chronological source feasibility."""
import json, hashlib
from pathlib import Path
from decimal import Decimal
from collections import defaultdict
BASE=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66';MID='0x1991e27e2908847c0274a662eb6675002e8386d0'
POOL='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf';TOKEN='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
KU='0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee';BASEADDR='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4'
MEXC='0x91187ed207f0adeaa7abd239b64baaa3347105f9';OTHER='0x3b4dfd886b2b6802573fcee2a2c0e4c745602eef'
checks=[];inputs={}
def ck(ok, name):
 checks.append({'check':name,'pass':bool(ok)})
 if not ok:raise AssertionError(name)
def read(path):
 p=BASE/path;b=p.read_bytes();inputs[path]=hashlib.sha256(b).hexdigest();return json.loads(b)
def ordered(rows):return sorted(rows,key=lambda r:(int(r['blockNumber']),int(r['transactionIndex'])))
def main():
 summary=read('onchain_pass7/iag_allocation/allocation.json')
 owner=ordered(read('onchain_pass6/source_bounds/77bf_USDC_history.json')['result'])
 mid=ordered(read('onchain_pass6/returned_funds/USDC_history.json')['result'])
 for address,rows in [(OWNER,owner),(MID,mid)]:
  cash=0;seen=set()
  for r in rows:
   ck(r['contractAddress'].lower()==TOKEN and int(r['tokenDecimal'])==6,'canonical six-decimal USDC')
   ck(address in (r['from'],r['to']),'queried wallet is endpoint')
   k=(r['hash'],r['from'],r['to'],r['value']);ck(k not in seen,'no identical indexed row');seen.add(k)
   cash+=int(r['value'])*(int(r['to']==address)-int(r['from']==address));ck(cash>=0,'full indexed history has nonnegative balance')
 start=min(int(r['blockNumber']) for r in owner if r['from']==POOL)
 end=next(int(r['blockNumber']) for r in mid if r['from']==BASEADDR and int(r['value'])==21116990000)
 ck(sum(int(r['value'])*(int(r['to']==OWNER)-int(r['from']==OWNER)) for r in owner if int(r['blockNumber'])<start)==0,'owner zero event balance before IAG receipts')
 firstmid=min(int(r['blockNumber']) for r in mid if r['from']==OWNER and int(r['blockNumber'])>=start)
 ck(sum(int(r['value'])*(int(r['to']==MID)-int(r['from']==MID)) for r in mid if int(r['blockNumber'])<firstmid)==0,'1991 zero event balance before owner receipts')
 op=[r for r in owner if start<=int(r['blockNumber'])<end and int(r['value'])>0]
 mp=[r for r in mid if firstmid<=int(r['blockNumber'])<end and int(r['value'])>0]
 ck(all(r['from']==OWNER for r in mp if r['to']==MID),'no other positive mid input before first return')
 ck(sum(int(r['value']) for r in op if r['from']==POOL)==191393685754,'IAG pool amount')
 outside=[r for r in op if r['to']==OWNER and r['from']!=POOL]
 ck(len(outside)==2 and sum(int(r['value']) for r in outside)==20000000,'two outside contributions total twenty')
 rr=read('onchain_pass7/historical_state/outside_inputs_drpc.response.json')
 receipts={r['id']:r['result'] for r in rr}
 for row in outside:
  r=receipts[row['hash']];ck(r['transactionHash']==row['hash'] and int(r['status'],16)==1,'successful raw outside receipt')
  logs=[l for l in r['logs'] if l['address']==TOKEN and l['topics'][0]=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef' and '0x'+l['topics'][1][-40:]==row['from'] and '0x'+l['topics'][2][-40:]==OWNER and int(l['data'],16)==int(row['value'])]
  ck(len(logs)==1 and not logs[0].get('removed'),'canonical exact outside transfer')
  ck(int(r['blockNumber'],16)==int(row['blockNumber']) and r['blockHash']==row['blockHash'],'outside block identification')
 dest=defaultdict(int)
 for r in mp:
  if r['from']==MID:dest[r['to']]+=int(r['value'])
 dest[MID]=sum(int(r['value'])*(int(r['to']==MID)-int(r['from']==MID)) for r in mp)
 for r in op:
  if r['from']==OWNER and r['to']!=MID:dest[r['to']]+=int(r['value'])
 ck(sum(dest.values())==191413685754,'non-overlapping partition totals all owner funding')
 combined={}
 for r in op+mp:
  k=(r['hash'],r['from'],r['to'],r['value']);combined[k]=r
 transactions=ordered(combined.values())
 # Explicitly place the entire twenty-dollar outside contribution in each of seven
 # disjoint end buckets, using original money for all other transfers. Each run
 # must be feasible in chronological order. No allocation rule is asserted.
 feasible=[]
 for chosen in dest:
  balances=defaultdict(lambda:[0,0])
  for r in transactions:
   a,b,n=r['from'],r['to'],int(r['value'])
   if b==OWNER and a!=OWNER:balances[b][0 if a==POOL else 1]+=n;continue
   ck(sum(balances[a])>=n,'chronological total feasible')
   outside_moved=0
   if a==OWNER and (b==chosen or (b==MID and chosen not in (MEXC,OTHER))):outside_moved=min(n,balances[a][1])
   if a==MID and b==chosen:outside_moved=min(n,balances[a][1])
   original_moved=n-outside_moved
   ck(original_moved<=balances[a][0] and outside_moved<=balances[a][1],'chronological color allocation feasible')
   balances[a][0]-=original_moved;balances[a][1]-=outside_moved
   balances[b][0]+=original_moved;balances[b][1]+=outside_moved
  ck(balances[chosen][1]==20000000,'all outside funds can reach chosen bucket')
  ck(sum(balances[a][1] for a in dest)==20000000,'same outside budget counted once')
  for address,n in dest.items():ck(sum(balances[address])==n,'scenario respects partition balance')
  feasible.append({'outside_destination':chosen,'original_amounts_raw':{a:str(balances[a][0]) for a in dest}})
 group_ex=dest[KU]+dest[MEXC];group_all=group_ex+dest[BASEADDR]
 ck(group_ex==90750000000 and group_all==117850000000,'exchange and exchange-plus-Base totals')
 ck(summary['joint_exchange_pool_origin_interval_USDC']==['90730','90750'],'joint exchange interval')
 ck(summary['joint_exchange_plus_Base_pool_origin_interval_USDC']==['117830','117850'],'joint exchange+Base interval')
 for bucket in summary['buckets']:
  amount=int(Decimal(bucket['amount_USDC'])*10**6)
  ck(amount in dest.values(),'reported bucket matches independent partition')
  ck([int(Decimal(x)*10**6) for x in bucket['individual_pool_origin_interval_USDC']]==[amount-20000000,amount],'individual interval with shared twenty budget')
 output={'status':'PASS','checks':len(checks),'source_inputs_sha256':inputs,'partition_raw':dict(dest),'feasible_allocations':feasible,'limitation':'Conditional on indexed USDC history completeness. Existing endpoint labels and onward exchange-sweep mechanics are reused from certified earlier passes, not newly audited here. Individual lower bounds cannot be summed because all share the same twenty-USDC outside budget.','checks_detail':checks}
 (OUT/'independent_iag.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({'status':'PASS','checks':len(checks),'partition_raw':dict(dest)},indent=2))
if __name__=='__main__':main()
