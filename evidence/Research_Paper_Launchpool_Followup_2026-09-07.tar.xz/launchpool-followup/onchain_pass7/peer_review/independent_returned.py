#!/usr/bin/env python3
"""Offline independent pass7 Ethereum returned-branch audit. No collector imports."""
import json,hashlib
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
from urllib.parse import urlparse,parse_qs
P=Path(__file__).resolve().parents[1]/'returned_branches';OUT=Path(__file__).resolve().parent
U='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';T='0xdac17f958d2ee523a2206206994597c13d831ec7'
A='0x47da741e9fada9aff75c0f2df69e9cd2b216b225';D='0xdcea03a2a2b8647ae787c4c518dbea1c54ac86d2';B='0xd5417e96dd04363c675e41ee6f30bf788412c719'
TOPIC='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
checks=[];inputs={}
def ck(ok,name):
 checks.append({'check':name,'pass':bool(ok)})
 if not ok:raise AssertionError(name)
def read(n):
 b=(P/n).read_bytes();inputs[n]=hashlib.sha256(b).hexdigest();return json.loads(b)
def seq(v):return v if isinstance(v,list) else [v]
def capture(n):
 data=read(n);req=read(n+'.request.json');receipt=read(n+'.receipt.json')
 ck(receipt['status']==200 and receipt['sha256']==inputs[n],n+': successful hash-matched capture')
 return data,req
def rpc(n,ids=None):
 data,req=capture(n);rawbody=req['request_body_utf8'].encode()
 ck(hashlib.sha256(rawbody).hexdigest()==req['request_body_sha256'],n+': exact request body SHA')
 queries=seq(json.loads(rawbody));ck(queries==seq(req['jsonrpc_body']),n+': exact declared request')
 by={x['id']:x for x in seq(data)};ck(len(by)==len(seq(data)),n+': no duplicate response IDs')
 out=[]
 for q in queries:
  if ids is not None and q['id'] not in ids:continue
  r=by[q['id']];ck('result' in r and r['result'] is not None and 'error' not in r,n+': non-null RPC result')
  out.append((q,r['result']))
 return out
def index(n,address,token):
 data,req=capture(n);params={k:v[0].lower() for k,v in parse_qs(urlparse(req['url']).query).items()}
 ck(params['action']=='tokentx' and params['address']==address and params['contractaddress']==token,n+': exact indexed filter')
 lo,hi=int(params['startblock']),int(params['endblock']);rows=data['result']
 ck(data['status']=='1' and isinstance(rows,list) and len(rows)<10000,n+': successful below-cap indexed list')
 for r in rows:
  ck(r['contractAddress']==token and r['tokenDecimal']=='6' and address in [r['from'],r['to']],n+': canonical row identity')
  ck(lo<=int(r['blockNumber'])<=hi,n+': indexed range')
 return rows,(lo,hi)
def logs(n,address,token,ids=None):
 rows=[];ranges=[]
 for q,ls in rpc(n,ids):
  ck(q['method']=='eth_getLogs',n+': log query');f=q['params'][0];lo=int(f['fromBlock'],16);hi=int(f['toBlock'],16)
  ck(f['address']==token and f['topics'][0]==TOPIC,n+': canonical log query')
  ck(hi-lo+1<=10000,n+': inclusive provider cap')
  side=2 if len(f['topics'])>2 and f['topics'][2] is not None else 1
  ck('0x'+f['topics'][side][-40:]==address,n+': exact endpoint topic')
  ranges.append((side,lo,hi))
  for l in ls:
   ck(l['address']==token and l['topics'][0]==TOPIC and not l.get('removed'),n+': canonical unremoved log')
   ck(lo<=int(l['blockNumber'],16)<=hi and '0x'+l['topics'][side][-40:]==address,n+': matching range/topic')
   rows.append({'hash':l['transactionHash'],'from':'0x'+l['topics'][1][-40:],'to':'0x'+l['topics'][2][-40:],'value':str(int(l['data'],16)),'blockNumber':str(int(l['blockNumber'],16)),'blockHash':l['blockHash'],'timeStamp':str(int(l['blockTimestamp'],16)),'transactionIndex':str(int(l['transactionIndex'],16)),'contractAddress':token,'tokenDecimal':'6'})
 return rows,ranges
def main():
 summary=read('summary.json');balances={}
 for n in ['state_0.json','state_1.json','state_2.json','dcea_state.json']:
  for q,v in rpc(n):
   ck(q['method']=='eth_call',n+': state call');call,block=q['params'];s=call['data'];addr='0x'+s[-40:]
   ck(call['to'] in (U,T) and s[:10]=='0x70a08231',n+': canonical balanceOf')
   balances[(addr,call['to'],int(block,16))]=int(v,16)
 ck(len(balances)==15,'fifteen historical balance states')
 histories={};all_rows={}
 for name,address,token,files in [('47da_USDC',A,U,['47da_USDC_24h.json','47da_USDC_extend.json']),('47da_USDT',A,T,['47da_USDT_24h.json','47da_USDT_extend.json']),('d541_USDC',B,U,['d541_USDC_24h.json']),('dcea_USDC',D,U,['dcea_USDC.json'])]:
  rows=[];ranges=[]
  for n in files:
   r,interval=index(n,address,token);rows+=r;ranges.append(interval)
  for left,right in zip(ranges,ranges[1:]):ck(left[1]+1==right[0],name+': non-overlapping contiguous indexed coverage')
  if name=='d541_USDC':
   r,scope=logs('fallback_logs.json',B,U,[0,1]);ck(r==[],'d541 RPC repaired empty extension')
   ck(sorted(scope)==[(1,20380001,20385000),(2,20380001,20385000)],'d541 full extension both directions')
  histories[name]=rows
 r,scope=logs('dcea_USDT_logs.json',D,T);ck(sorted(scope)==[(1,20333000,20342999),(2,20333000,20342999)],'dceaUSDT both directions complete range');histories['dcea_USDT']=r
 ledger_results={}
 for name,rows in histories.items():
  s=summary['histories'][name];a,t,lo,hi=s['address'],s['token'],s['start_block'],s['end_block']
  rows.sort(key=lambda r:(int(r['blockNumber']),int(r['transactionIndex'])));seen=set();op=bal=balances[(a,t,lo-1)];ins=outs=0
  for r in rows:
   ck(lo<=int(r['blockNumber'])<=hi,name+': no event outside summary bound')
   k=(r['hash'],r['from'],r['to'],r['value'],r['contractAddress']);ck(k not in seen,name+': no duplicates');seen.add(k);all_rows[k]=r
   n=int(r['value']);ins+=n if r['to']==a else 0;outs+=n if r['from']==a else 0
   bal+=n*(int(r['to']==a)-int(r['from']==a));ck(bal>=0,name+': nonnegative chronological cash')
  ck(bal==balances[(a,t,hi)],name+': independent archive balance conservation')
  for key,val in [('opening',op),('incoming',ins),('outgoing',outs),('closing',bal)]:ck(Decimal(s[key])*10**6==val,name+': summary '+key)
  ck(len(rows)==s['event_count'],name+': event count')
  for (aa,tt,block),amount in balances.items():
   if (aa,tt)==(a,t) and lo<=block<=hi:
    observed=op+sum(int(r['value'])*(int(r['to']==a)-int(r['from']==a)) for r in rows if int(r['blockNumber'])<=block)
    ck(observed==amount,name+': intermediate archive state')
  ledger_results[name]={'events':len(rows),'closing_raw':str(bal),'full_bounded_reconciliation':True}
 receiptmap={}
 for n in ['receipts_corrected_0.json','receipts_corrected_3.json','receipts_corrected_6.json','receipts_2.json','extra_receipts.json']:
  for q,r in rpc(n):
   ck(q['method']=='eth_getTransactionReceipt' and q['params'][0]==r['transactionHash'] and int(r['status'],16)==1,n+': exact successful receipt')
   receiptmap[r['transactionHash']]=r
 selected=summary['selected_transfers']
 for e in selected:
  r=receiptmap[e['hash']];token=U if e['token']=='USDC' else T
  hits=[l for l in r['logs'] if l['address']==token and l['topics'][0]==TOPIC and '0x'+l['topics'][1][-40:]==e['from'] and '0x'+l['topics'][2][-40:]==e['to'] and int(l['data'],16)==Decimal(e['amount'])*10**6]
  ck(len(hits)==1,'selected canonical exact receipt log');l=hits[0]
  ck(int(l['logIndex'],16)==e['log_index'] and not l.get('removed'),'selected unique unremoved log index')
  ck(int(l['blockNumber'],16)==e['block'] and r['blockHash']==l['blockHash'],'selected matching block')
  ck(datetime.fromtimestamp(int(l['blockTimestamp'],16),timezone.utc).isoformat()==e['utc'],'selected raw UTC')
  ck(r['from']==e['transaction_caller'],'selected actual caller')
 calls={q['id']:(q,v) for q,v in rpc('kraken_calls_and_scope.json')}
 for ident in [0,1]:
  q,tx=calls[ident];e=next(e for e in selected if e['hash']==tx['hash']);s=tx['input']
  ck(q['method']=='eth_getTransactionByHash' and q['params'][0]==tx['hash'],'collection transaction query')
  ck(s[:10]=='0x23b872dd' and len(s)==202,'collection transferFrom calldata')
  ck('0x'+s[34:74]==D and '0x'+s[98:138]==tx['from']==e['to'] and int(s[138:],16)==Decimal(e['amount'])*10**6,'collection exact sender/recipient/amount')
  ck(tx['to']==(U if ident==0 else T),'collection exact token')
  inbound=next(x for x in selected if x['to']==D and x['token']==e['token'])
  delay=(datetime.fromisoformat(e['utc'])-datetime.fromisoformat(inbound['utc'])).total_seconds()
  ck(delay==summary['kraken_collection'][e['token']]['delay_seconds'],'collection exact sweep delay')
 q,v=calls[2];ck(q['method']=='eth_getCode' and q['params']==[D,hex(20335403)] and v=='0x','deposit intermediary historical EOA')
 week=[];ranges=[]
 for n in ['d541_out_week_0.json','d541_out_week_retry.json']:
  r,ss=logs(n,B,U);week+=r;ranges+=ss
 initial_later=[r for r in histories['d541_USDC'] if r['from']==B and int(r['blockNumber'])>20377339]
 ck(initial_later==[],'full initial ledger: no outgoing after selected receipt through20385000')
 ranges.sort(key=lambda x:x[1]);cursor=20385001
 for side,lo,hi in ranges:ck(side==1 and lo==cursor,'d541 week outgoing-only continuous coverage from post-receipt');cursor=hi+1
 ck(cursor==20428001 and len(week)==1,'d541 week ends at exact bound with one transfer')
 w=week[0];ck(w['value']=='21664000000' and w['hash']==summary['d541_week']['first_outgoing']['hash'],'d541 exact later21664 transfer')
 incoming=next(e for e in selected if e['to']==B)
 ck(int(w['timeStamp'])-int(datetime.fromisoformat(incoming['utc']).timestamp())>86400,'d541 no post-receipt outgoing first24h')
 ck(balances[(B,U,20377338)]>21664000000,'d541 prior funds suffice for later payment')
 # The selected 47da inflows may be kept wholly in closing cash: every later
 # bounded running balance exceeds each selected amount. Thus zero source
 # attribution to the Kraken transfers is feasible without an allocation rule.
 for name,amount,block in [('47da_USDC',32500000000,20333159),('47da_USDT',8720194800,20333173)]:
  s=summary['histories'][name];running=int(Decimal(s['opening'])*10**6)
  for r in histories[name]:
   running+=int(r['value'])*(int(r['to']==A)-int(r['from']==A))
   if int(r['blockNumber'])>=block:ck(running>=amount,'selected47da inflow may stay in balance; zero forced Kraken contribution')
 output={'status':'PASS','checks':len(checks),'histories':ledger_results,'selected_raw_receipts':len(selected),'historical_balances':len(balances),'input_sha256':inputs,'limitations':['The 75,000 USDC and 300,000 USDT are gross intermediary throughput; zero attribution from selected 47da source payments is feasible.','The d541 week extension is outgoing-only from block 20,385,001 through 20,428,000; the initial full bounded ledger covers the selected July 24 receipt through block 20,385,000. No full-week incoming ledger is claimed.','Exchange public labels are outside this offline check.','Earlier full bounded d541 ledger includes payments preceding the selected July 24 receipt.','The fallback batch contained two failed over-wide dcea USDT queries; the successful d541 queries were independently selected, and corrected dcea USDT requests cover the required range.'],'checks_detail':checks}
 (OUT/'independent_returned.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:v for k,v in output.items() if k not in ('input_sha256','checks_detail')},indent=2))
if __name__=='__main__':main()
