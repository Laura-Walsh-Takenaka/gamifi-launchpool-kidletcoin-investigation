#!/usr/bin/env python3
"""Independent, offline pass7 BUSD audit. Imports no collection code; writes here only."""
from pathlib import Path
from decimal import Decimal, getcontext
from datetime import datetime, timezone
import json, hashlib
getcontext().prec=80
BASE=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
TOKEN='0xe9e7cea3dedca5984780bafc599bd69add087d56'
TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
BINANCE='0x8894e0a0c962cb723c1976a4421c95949be2d4e3'
checks=[]
inputs={}
def check(ok, name):
    checks.append({'check':name,'pass':bool(ok)})
    if not ok: raise AssertionError(name)
def read(p):
    b=p.read_bytes();inputs[str(p.relative_to(BASE))]=hashlib.sha256(b).hexdigest()
    return json.loads(b)
def seq(x): return x if isinstance(x,list) else [x]
def raw(p,prefix):
    pairs=[]
    for f in sorted(p.glob(prefix+'*.receipt.json')):
        meta=read(f); data=f.with_name(f.name.replace('.receipt.json','.response'))
        if not data.exists(): continue
        response=read(data)
        check(hashlib.sha256(data.read_bytes()).hexdigest()==meta['sha256'],f'{f.name}: capture SHA')
        check(meta['status']==200,f'{f.name}: HTTP success')
        byid={r['id']:r for r in seq(response)}
        for q in seq(meta['request']):
            r=byid.get(q['id'])
            check(r is not None and 'result' in r and 'error' not in r,f'{f.name}/{q["id"]}: RPC success')
            pairs.append((q,r['result'],meta['url']))
    return pairs
def event(x):
    return (x['transactionHash'].lower(),int(x['logIndex'],16))
def audit(p, result_file, specs):
    summary=read(p/result_file)
    result={'file':str((p/result_file).relative_to(BASE)),'windows':[]}
    all_rows=[]
    for name,first,last,addresses,log_prefix,balance_prefix,header_prefix,receipt_prefix,tx_prefix in specs:
        addresses=set(addresses); found={}; coverage={a:{'in':[],'out':[]} for a in addresses}
        for q,logs,url in raw(p,log_prefix):
            check(q['method']=='eth_getLogs',f'{name}: log method')
            params=q['params'][0]; topics=params['topics']; a=int(params['fromBlock'],16);b=int(params['toBlock'],16)
            check(params['address'].lower()==TOKEN and topics[0]==TRANSFER,f'{name}: canonical transfer filter')
            check(first<=a<=b<=last and b-a+1<=10000,f'{name}: range constraints')
            side=2 if len(topics)>2 and topics[2] is not None else 1
            direction='in' if side==2 else 'out'
            selected=topics[side] if isinstance(topics[side],list) else [topics[side]]
            queried={'0x'+t[-40:] for t in selected}
            check(queried==addresses,f'{name}: complete target set')
            for address in addresses:coverage[address][direction].append((a,b))
            for l in logs:
                check(l['address'].lower()==TOKEN and l['topics'][0]==TRANSFER and not l.get('removed'),f'{name}/{event(l)}: canonical unremoved event')
                check(a<=int(l['blockNumber'],16)<=b and '0x'+l['topics'][side][-40:] in queried,f'{name}/{event(l)}: matches range and topic')
                k=event(l)
                if k in found:check(found[k]==l,f'{name}/{k}: duplicate identical')
                found[k]=l
        for address,sides in coverage.items():
            for direction,intervals in sides.items():
                cursor=first
                for a,b in sorted(intervals):
                    check(a==cursor,f'{name}/{address}/{direction}: no coverage gap/overlap');cursor=b+1
                check(cursor==last+1,f'{name}/{address}/{direction}: full bounded coverage')
        balances={}
        for q,v,url in raw(p,balance_prefix):
            check(q['method']=='eth_call',f'{name}: balance method')
            call,block=q['params'];data=call['data'];address='0x'+data[-40:]
            check(call['to'].lower()==TOKEN and data[:10]=='0x70a08231',f'{name}: canonical balanceOf')
            balances[(address,int(block,16))]=int(v,16)
        headers={}
        header_pairs=raw(p,header_prefix)
        if name=='retained_d7':header_pairs+=raw(p,'sibling_extension_headers_')
        for q,v,url in header_pairs:
            check(q['method']=='eth_getBlockByNumber' and int(q['params'][0],16)==int(v['number'],16),f'{name}: header number')
            headers[int(v['number'],16)]=v
        receipts={}
        if receipt_prefix:
            receipt_pairs=raw(p,receipt_prefix)
            if name=='retained_d7':receipt_pairs+=raw(p,'sibling_extension_receipts_')
            for q,v,url in receipt_pairs:
                check(url=='https://bsc-dataseed.bnbchain.org',f'{name}: independent official receipt provider')
                check(q['method']=='eth_getTransactionReceipt' and q['params'][0].lower()==v['transactionHash'].lower(),f'{name}: receipt hash')
                receipts[v['transactionHash'].lower()]=v
        txs={}
        if tx_prefix:
            tx_pairs=raw(p,tx_prefix)
            if name=='retained_d7':tx_pairs+=raw(p,'sibling_extension_transactions_')
            for q,v,url in tx_pairs:
                check(q['method']=='eth_getTransactionByHash' and q['params'][0].lower()==v['hash'].lower(),f'{name}: transaction hash')
                txs[v['hash'].lower()]=v
        rows=[]
        for k,l in sorted(found.items(),key=lambda kv:(int(kv[1]['blockNumber'],16),int(kv[1]['logIndex'],16))):
            block=int(l['blockNumber'],16);h=headers[block]
            check(h['hash']==l['blockHash'],f'{name}/{k}: header/log hash')
            utc=datetime.fromtimestamp(int(h['timestamp'],16),timezone.utc).isoformat()
            sender='0x'+l['topics'][1][-40:];recipient='0x'+l['topics'][2][-40:];value=int(l['data'],16)
            r=receipts[k[0]];tx=txs[k[0]]
            check(int(r['status'],16)==1 and r['blockHash']==h['hash'] and int(r['blockNumber'],16)==block,f'{name}/{k}: successful matching receipt')
            matching=[rl for rl in r['logs'] if event(rl)==k]
            check(len(matching)==1,f'{name}/{k}: unique receipt log')
            for key in ('address','topics','data','blockHash','blockNumber','transactionHash','logIndex'):
                check(matching[0][key]==l[key],f'{name}/{k}: receipt log {key}')
            check(tx['from']==sender and tx['to']==TOKEN and tx['blockHash']==h['hash'],f'{name}/{k}: transaction sender/token/block')
            data=tx['input'];check(data[:10]=='0xa9059cbb' and len(data)==138,f'{name}/{k}: direct ERC20 transfer')
            check('0x'+data[34:74]==recipient and int(data[74:],16)==value,f'{name}/{k}: decoded recipient/value')
            row=next(x for x in summary['rows'] if x['tx_hash'].lower()==k[0] and x['log_index']==k[1])
            for key,v in [('block_number',block),('block_hash',h['hash']),('utc',utc),('from',sender),('to',recipient),('amount_raw',str(value)),('status',1)]:
                check(row[key]==v,f'{name}/{k}: summary {key}')
            check(Decimal(row['amount_busd'])==Decimal(value)/10**18,f'{name}/{k}: exact decimals')
            rows.append(row)
        for address in addresses:
            op=balances[(address,first-1)];close=balances[(address,last)]
            inc=sum(int(x['amount_raw']) for x in rows if x['to']==address)
            out=sum(int(x['amount_raw']) for x in rows if x['from']==address)
            check(op+inc-out==close,f'{name}/{address}: raw historical conservation')
            cash=op
            for x in rows:
                cash+=(int(x['amount_raw']) if x['to']==address else 0)-(int(x['amount_raw']) if x['from']==address else 0)
                check(cash>=0,f'{name}/{address}: nonnegative sequential balance')
            candidates=[x for x in summary['window_balances'] if x['address']==address and ('window' not in x or x['window']==name)]
            check(len(candidates)==1,f'{name}/{address}: unique summary balance')
            row=candidates[0]
            for key,v in [('opening',op),('closing',close),('in',inc),('out',out)]:
                check(int(row[key+'_raw'])==v and Decimal(row[key+'_busd'])==Decimal(v)/10**18,f'{name}/{address}: summary {key}')
        all_rows.extend(rows)
        result['windows'].append({'name':name,'first':first,'last':last,'addresses':sorted(addresses),'events':len(rows),'balanced':True})
    check(len(all_rows)==len(summary['rows']),f'{result_file}: no unverified summary rows')
    return result
def joint_week_bound():
    ownerdata=read(BASE/'onchain_pass6/original_busd_onward/verified_owner_onward.json')
    inter=read(BASE/'onchain_pass6/original_busd_onward/verified_intermediary_onward.json')
    branches=read(BASE/'onchain_pass7/busd_branches/verified_branches.json')
    extension=read(BASE/'onchain_pass7/busd_branches/verified_extension.json')
    retained=read(BASE/'onchain_pass7/owner_and_retained/verified_retained_d7.json')
    owner=ownerdata['owner'];pool='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'
    combined={}
    for document in [ownerdata,inter,branches,extension,retained]:
        for row in document['rows']:
            if int(row['amount_raw'])==0:continue
            k=(row['tx_hash'],row['log_index'])
            if k in combined:
                check(all(combined[k][f]==row[f] for f in ('from','to','amount_raw','block_number')),f'joint week/{k}: overlapping lanes identical')
            combined[k]=row
    rows=sorted(combined.values(),key=lambda r:(r['block_number'],r['log_index']))
    opening={owner:int(ownerdata['window_balances'][0]['opening_raw'])}
    for row in inter['window_balances']:
        if row['raise']==1:opening[row['address']]=int(row['opening_raw'])
    for row in branches['window_balances']:opening[row['address']]=int(row['opening_raw'])
    endpoints=[r for r in rows if r['to']==BINANCE]
    check(len(endpoints)==7 and sum(int(r['amount_raw']) for r in endpoints)==501460520000000000000000,'joint week: seven unique Binance endpoint receipts total 501460.52')
    check(sum(int(r['amount_raw']) for r in rows if r['from']==pool and r['to']==owner)==903794346419582485370326,'joint week: six original pool claims total903794.346419582485370326')
    examples=[]
    for minimum in [True,False]:
        cash={a:[0,n if a==owner else 0,n if a!=owner else 0] for a,n in opening.items()};cash[BINANCE]=[0,0,0]
        checked_anchor=False
        for r in rows:
            if not checked_anchor and r['block_number']>=22794959:
                for state in retained['window_balances']:
                    if state['window']=='retained_d7':check(sum(cash[state['address']])==int(state['opening_raw']),'joint week: carry matches archived next-week opening')
                checked_anchor=True
            a,b,n=r['from'],r['to'],int(r['amount_raw']);cash.setdefault(b,[0,0,0])
            if a==pool:cash[b][0]+=n;continue
            check(a in cash and sum(cash[a])>=n,'joint week: sufficient chronological source cash')
            priority=[0,1,2]
            if minimum and a==owner and b.startswith('0x14c840'):priority=[1,0,2]
            if minimum and a.startswith('0xcedfa'):priority=[2,0,1]
            left=n
            for color in priority:
                moved=min(cash[a][color],left);cash[a][color]-=moved;cash[b][color]+=moved;left-=moved
            check(left==0,'joint week: feasible original/owner-prior/other-prior allocation')
        expected=501153870312770845946088 if minimum else 501370000000000000000000
        check(cash[BINANCE][0]==expected,'joint week: exact original-source bound feasible')
        check(cash[BINANCE][1]==(332011149154053912 if minimum else 0),'joint week: owner small prior budget counted once')
        check(cash[BINANCE][2]==(306317676080000000000 if minimum else 90520000000000000000),'joint week: cedfa optional215.79767608 and ab3c fixed90.52')
        examples.append({'scenario':'minimum_original' if minimum else 'maximum_original','binance_original_raw':str(cash[BINANCE][0]),'binance_owner_prior_raw':str(cash[BINANCE][1]),'binance_other_prior_raw':str(cash[BINANCE][2])})
    return examples
def main():
    p=BASE/'onchain_pass7/busd_branches';s=read(p/'verified_branches.json')
    results=[audit(p,'verified_branches.json',[('first_24h',s['first_block'],s['last_block'],s['target_addresses'],'branch_logs_','branch_balances_','branch_headers_','branch_receipts_','branch_transactions_')])]
    endpoint=[r for r in s['rows'] if r['to']==BINANCE]
    check(len(endpoint)==3 and sum(int(r['amount_raw']) for r in endpoint)==int(Decimal('222090.52')*10**18),'three first-day Binance endpoint transfers')
    ab=next(r for r in s['window_balances'] if r['address'].startswith('0xab3c'))
    check(Decimal(ab['opening_busd'])==Decimal('90.52'),'90.52 predates traced input')
    prior=read(BASE/'onchain_pass6/original_busd_onward/verified_owner_onward.json')
    check(prior['window_balances'][0]['opening_raw']=='332011149154053912','owner prior 0.332011149154053912 source caveat retained')
    inter=read(BASE/'onchain_pass6/original_busd_onward/verified_intermediary_onward.json')
    owner=prior['owner'];pool='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'
    combined={}
    for row in prior['rows']+inter['rows']+s['rows']:
        if not 22732478<=row['block_number']<=22760778:continue
        k=(row['tx_hash'],row['log_index'])
        if k in combined:
            check(all(combined[k][f]==row[f] for f in ('from','to','amount_raw','block_number')),f'source bound/{k}: overlapping lanes agree')
        combined[k]=row
    opening={owner:int(prior['window_balances'][0]['opening_raw'])}
    for row in inter['window_balances']:
        if row['raise']==1:opening[row['address']]=int(row['opening_raw'])
    for row in s['window_balances']:opening[row['address']]=int(row['opening_raw'])
    origin_in=sum(int(r['amount_raw']) for r in combined.values() if r['to']==owner and r['from']==pool)
    check(origin_in==587417110289617788758000,'source bound: exact original raise1 input')
    check(all(r['from']==pool for r in combined.values() if r['to']==owner and int(r['amount_raw'])>0),'source bound: no other owner positive inputs')
    bound_examples=[]
    for lower in (True,False):
        # State vector: original pool, owner's pre-existing funds, other opening funds.
        cash={a:[0, n if a==owner else 0, n if a!=owner else 0] for a,n in opening.items()}
        cash[BINANCE]=[0,0,0]
        for r in sorted(combined.values(),key=lambda r:(r['block_number'],r['log_index'])):
            sender,recipient,value=r['from'],r['to'],int(r['amount_raw'])
            cash.setdefault(recipient,[0,0,0])
            if sender==pool:
                cash[recipient][0]+=value;continue
            check(sender in cash,'source bound: every non-pool sender initialized')
            check(sum(cash[sender])>=value,'source bound: feasible total at each transfer')
            priority=[1,0,2] if lower and sender==owner and recipient.startswith('0x14c840') else [0,1,2]
            left=value
            for color in priority:
                moved=min(cash[sender][color],left);cash[sender][color]-=moved;cash[recipient][color]+=moved;left-=moved
            check(left==0,'source bound: exact feasible allocation')
        check(sum(cash[BINANCE])==276460520000000000000000,'source bound: five unique endpoint transfers total')
        expected=276369667988850845946088 if lower else 276370000000000000000000
        check(cash[BINANCE][0]==expected,'source bound: feasible exact bound endpoint')
        check(cash[BINANCE][2]==90520000000000000000,'source bound: fixed ab3c opening money')
        bound_examples.append({'scenario':'minimum_original' if lower else 'maximum_original','binance_original_raw':str(cash[BINANCE][0]),'binance_owner_prior_raw':str(cash[BINANCE][1]),'binance_other_prior_raw':str(cash[BINANCE][2])})
    if (p/'verified_extension.json').exists():
        ext=read(p/'verified_extension.json')
        results.append(audit(p,'verified_extension.json',[('days_2_to_7',ext['first_block'],ext['last_block'],ext['target_addresses'],'extension_logs_','extension_balances_','extension_headers_','extension_receipts_','extension_transactions_')]))
    p=BASE/'onchain_pass7/owner_and_retained'
    for file in ['verified_retained_d1.json','verified_retained_d7.json']:
        if not (p/file).exists():continue
        s=read(p/file);spec=[]
        for w in s['windows']:
            n=w['name'];spec.append((n,w['first_block'],w['last_block'],w['addresses'],n+'_logs_',n+'_balances_',n+'_headers_',n+'_receipts_',n+'_transactions_'))
        results.append(audit(p,file,spec))
    joint_examples=joint_week_bound() if (p/'verified_retained_d7.json').exists() else []
    report={'status':'PASS','checks':len(checks),'results':results,'source_bound_examples':bound_examples,'joint_week_source_bound_examples':joint_examples,'inputs_sha256':inputs,'limitations':['Bounded canonical BUSD windows only; no current balances inferred.','Exchange address labeling is outside this offline check.','Endpoint throughput includes 90.52 BUSD already held by ab3c. The week extension also allows up to215.79767608 of cedfa prior cash.','Original-pool attribution remains qualified by owner opening 0.332011149154053912 BUSD.','Source bound uses prior-pass certified owner/intermediary event tables, not a fresh independent audit of their raw captures. This pass independently verifies new branch captures.'],'checks_detail':checks}
    (OUT/'independent_busd.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'PASS','checks':len(checks),'results':results},indent=2))
if __name__=='__main__':main()
