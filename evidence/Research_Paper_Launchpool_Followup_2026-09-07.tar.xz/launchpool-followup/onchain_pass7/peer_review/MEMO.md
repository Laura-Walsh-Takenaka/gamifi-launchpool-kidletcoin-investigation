# Independent pass 7 evidence review

**Result: PASS.** The three independent offline scripts completed 4,905 assertions: BUSD 2,187, initial IAG allocation 1,876, and Ethereum returned branches 842. These are verification assertions, not counts of independent transactions or sources. No factual discrepancy remains. No network requests were made by the reviewer, and no collector modules were imported or executed. Only this peer-review directory was written.

## BUSD branches and custody

The reviewer independently matched canonical BUSD log filters and query coverage to raw captured requests, checked response hashes, decoded direct token-transfer calldata, and compared each selected event with successful official BNB receipts and block headers. Opening plus incoming less outgoing equals archived closing balance for each selected wallet/window. The preserved failed batches were not counted as successful coverage; successful contiguous replacement queries supply the relevant range. Copied sibling receipts and headers retain their original request metadata and hash verification.

Three additional first-day transfers into the same Binance endpoint total **222,090.52 BUSD**. The known prior 90.52 BUSD at ab3c means their owner-chain inflows total 222,000. Including the two earlier endpoint payments gives five unique first-day payments totaling 276,460.52 BUSD. Chronological source allocations make the original Raise 1 contribution interval **276,369.667988850845946088–276,370 BUSD** feasible at both extremes.

The retained-week evidence independently confirms another **225,000 BUSD** entering 57e898 from cedfa and leaving for the same endpoint in two transfers: 125,000 on 7 November 2022 at 20:30:06 UTC and 100,000 on 8 November at 10:30:06 UTC. The source wallet begins and ends its reviewed week at zero. Delays after the final contributing input are 21 minutes 25 seconds and 27 minutes 6 seconds.

Across **seven unique endpoint payments**, gross throughput is **501,460.52 BUSD**. Independent chronological source-color replay makes the original-pool contribution interval **501,153.870312770845946088–501,370 BUSD** feasible. It separates the fixed ab3c prior 90.52, the optional cedfa prior 215.79767608, and the shared owner prior 0.332011149154053912 BUSD. The owner’s small prior balance is counted once. This replay uses already-certified pass 6 owner/intermediary tables and independently verified pass 7 raw branches; it is not a fresh re-audit of all pass 6 raw captures.

The complete canonical BUSD owner gap, blocks 22,760,779–22,766,631, contains zero events with matching archive balances. The extension covers blocks 22,794,959–22,993,378, through the 12 November 2022 13:59:08 UTC cutoff. The separate cedfa/dc127 extension ends at block 22,930,997, corresponding to the 10 November 09:02:17 UTC cutoff. Those cutoffs must not be treated as current balances or combined into a common later observation date. Positive movements and one zero-value extension event remain distinguished.

## Initial IAG allocation

The reviewer reconstructed the canonical 13-row owner USDC history and 370-row 1991 history from raw indexed JSON, checked the two newly successful raw receipts for the ten-USDC outside contributions, and reconstructed the seven-part disposition totaling **191,413.685754 USDC**. Its IAG-pool component is 191,393.685754 and its single outside budget is 20.

Seven explicit chronological allocations place all twenty outside USDC in each disjoint end bucket in turn. All remain feasible. Accordingly, the combined 80,750-USDC KuCoin and 10,000-USDC MEXC routes have a conditional IAG contribution of **90,730–90,750 USDC**. Adding the 27,100-USDC Base-funding branch produces **117,830–117,850 USDC**. Individual branch lower bounds cannot be added: they share the same twenty-USDC outside budget.

These intervals remain conditional on complete captured canonical histories because the opening source-wallet balances are event-derived. Historical states for other wallets do not replace that missing source-wallet state check. Exchange labels and earlier onward exchange mechanics are reused from prior certified findings, not newly established by this allocation calculation.

## Returned Ethereum branches

The reviewer independently reconstructed **92 bounded ledger events**, reconciled **15 historical state calls**, and matched **13 selected successful raw receipts**. The dcea collection cycles independently reconcile from zero to zero: 75,000 USDC and 300,000 USDT. Each receiving wallet initiates a correctly decoded `transferFrom(dcea, itself, amount)` transaction. The exact delays are 576 seconds for USDC and 600 seconds for USDT.

The selected 32,500-USDC and 8,720.1948-USDT inputs into 47da can remain wholly in its balance during the later reviewed events. Thus **zero attribution from either selected input to the Kraken branch is feasible**. The large sweeps are gross intermediary throughput, not newly discovered fundraising or a uniquely assigned trading-return amount. The 8,720.1948-USDT receipt predates the 23 July trading return.

The d541 initial full ledger covers blocks 20,372,000–20,385,000 and includes activity before the selected 24 July receipt. The extension covers **outgoing USDC only**, contiguously from 20,385,001 through 20,428,000. In combination, they show no outgoing USDC in the first 24 hours after the selected receipt, then one 21,664-USDC payment on 30 July. Prior funds suffice for that later payment; no unique funding attribution follows. No full-week incoming ledger is claimed.

## Report review and limits

The reviewer read `onchain_pass7_content.py` against the frozen evidence. The displayed amounts, timestamps, delays, cutoffs, source intervals and substantive qualifications agree. The exact public entity/exchange label checks are performed separately by the root researcher and are not part of this offline review. No exchange customer, fiat withdrawal, beneficial owner, human signing-key holder, investor entitlement, payment purpose or Laura’s personal receipt is established by these calculations.

Reproduce from the project root:

```text
python onchain_pass7/peer_review/independent_busd.py
python onchain_pass7/peer_review/independent_iag.py
python onchain_pass7/peer_review/independent_returned.py
```

Each script writes its own derived result JSON in this directory and hashes the exact inputs it reads. Run in a fresh extracted copy for package verification so the archived evidence remains untouched.
