# IAG USDC: reconciled disposition and shared-source bounds

The previously identified IAG pool withdrawals contributed 191,393.685754 USDC to 77bf. Two separate 10- USDC payments supply the only other positive receipts in its captured distribution interval. This pass additionally confirms both with successful dRPC transaction receipts from the canonical USDC contract; Publicnode returned null for both and that failure is preserved. No operator affiliation is assigned to the lookalike senders.

77bf distributed 191,413.685754 USDC: 150,010 to 1991,10,000 to the previously verified MEXC route via 9118, and 31,403.685754 through 3b4d. The retained histories reconstruct zero prior USDC at 77bf and 1991. This pass's Ethereum historical-state probe returned403; no new successful historical-state claim is made for these two addresses.

Before the first trading return on 18 July 2024,1991's 150,010 USDC reconciles into 80,750 sent to the previously verified KuCoin deposit, 27,100 into the Base funding route, 19,200 to 2c94, 11,500 to 0008, and 11,460 still at1991. The sum is exact in six-decimal base units. Later returns and receipts are excluded from this initial funding partition.

Conditional on complete captured histories, the joint KuCoin/MEXC routes contain 90,730–90,750 USDC originating in the IAG pool withdrawals. The total of those exchange routes and the Base funding is 117,850 USDC, with a joint IAG-origin interval 117,830–117,850. Both endpoints are feasible: allocate the entire 20 outside USDC to the selected routes or to a different sufficiently funded branch. Chronology permits these allocations.

The same 20- USDC budget is shared across every branch. Individual minimum estimates must not be added as if each branch independently contained another 20 outside USDC. No FIFO or pro-rata rule is imposed, and no legal entitlement, human controller, payment mandate or ownership of trading profits follows from this calculation. These are USDC flows, separate from original BUSD and ML token allocations.

Reproduction: `python3 onchain_pass7/iag_allocation/reconcile.py` from an extracted working copy. It consumes captured source histories and raw outside-input receipts and rewrites allocation.json. Earlier verified exchange labels and sweep evidence remain in onchain_pass3/usdc_onward; this calculation does not reclassify their receipt coverage.
