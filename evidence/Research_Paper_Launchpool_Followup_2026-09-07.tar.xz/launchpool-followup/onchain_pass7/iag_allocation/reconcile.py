from pathlib import Path
from decimal import Decimal
from collections import defaultdict
import json,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
owner='0x77bfe8d704b1948374bf8dab8328a810b2836e66';mid='0x1991e27e2908847c0274a662eb6675002e8386d0';pool='0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf';usdc='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
paths=['onchain_pass6/source_bounds/77bf_USDC_history.json','onchain_pass6/returned_funds/USDC_event_ledger.json','onchain_pass6/source_bounds/source_bounds.json','onchain_pass7/historical_state/outside_inputs_drpc.response.json']
def dec(n):return format(Decimal(n)/10**6,'f')
src=json.loads((R/paths[0]).read_text())['result'];ledger=json.loads((R/paths[1]).read_text());old=json.loads((R/paths[2]).read_text())
# Bind the two non-fundraising contributions to raw successful receipt logs.
rr={x['id']:x['result'] for x in json.loads((R/paths[3]).read_text())};outside=[]
for row in old['source_rows']['other_inflows']:
 r=rr[row['hash']];assert r['status']=='0x1' and int(r['blockNumber'],16)==int(row['blockNumber'])
 m=[l for l in r['logs'] if l['address']==usdc and len(l['topics'])==3 and l['topics'][0]=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef' and '0x'+l['topics'][1][-40:]==row['from'] and '0x'+l['topics'][2][-40:]==owner and int(l['data'],16)==int(row['value'])]
 assert len(m)==1;outside.append({'tx':row['hash'],'log':m[0],'value_raw':row['value']})
assert sum(int(r['value_raw']) for r in outside)==20_000_000
start=min(int(r['blockNumber']) for r in src if r['from']==pool)
pre=sum(int(r['value'])*(1 if r['to']==owner else -1) for r in src if int(r['blockNumber'])<start);assert pre==0
ows=[r for r in src if int(r['blockNumber'])>=start and int(r['value'])>0]
assert sum(int(r['value']) for r in ows if r['from']==pool)==191393685754
assert {r['to'] for r in ows if r['from']==owner}=={mid,'0x91187ed207f0adeaa7abd239b64baaa3347105f9','0x3b4dfd886b2b6802573fcee2a2c0e4c745602eef'}
outs={r['to']:int(r['value']) for r in ows if r['from']==owner and r['to']!=mid};assert sum(int(r['value']) for r in ows if r['from']==owner and r['to']==mid)==150010000000
first=next(i for i,r in enumerate(ledger) if r['tx_hash']==old['source_rows']['to1991'][0]['hash']);last=next(i for i,r in enumerate(ledger[first:],first) if r['from']=='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4' and int(r['value_raw'])==21116990000)
phase=ledger[first:last];assert phase[0]['balance_before_raw']=='0'
assert all(r['from']==owner for r in phase if r['to']==mid)
by=defaultdict(int)
for row in phase:
 if row['from']==mid:by[row['to']]+=int(row['value_raw'])
expected={'0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee':80750000000,'0x183600361dc42c6f022fd219c3a9dabbf08c9ce4':27100000000,'0x2c94c30bdd9aa400df9d2347ee16094ab1858941':19200000000,'0x0008458f168399ee46412c1cff180edf1ec661a7':11500000000}
assert dict(by)==expected;rem=int(phase[-1]['balance_after_raw']);assert rem==11460000000 and sum(by.values())+rem==150010000000
buckets=[('KuCoin deposit4d0d',by['0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee']),('Base funding via183600',by['0x183600361dc42c6f022fd219c3a9dabbf08c9ce4']),('Payments to2c94',by['0x2c94c30bdd9aa400df9d2347ee16094ab1858941']),('Payment to0008',by['0x0008458f168399ee46412c1cff180edf1ec661a7']),('1991 balance beforefirstreturn',rem),('MEXC route via9118',outs['0x91187ed207f0adeaa7abd239b64baaa3347105f9']),('Separate route via3b4d',outs['0x3b4dfd886b2b6802573fcee2a2c0e4c745602eef'])]
assert sum(n for _,n in buckets)==191413685754
# Both extremes are feasible. Route the entire20 outside contribution to a selected
# bucket for its minimum pool origin; route it to any disjoint bucket for maximum.
# All relevant payments occur after the outside receipts and every bucket exceeds20.
# The earlier10-USDC transfer to1991 is pool-origin and remains below every bucket.
for _,n in buckets:assert n>20_000_000
out={'method':'Conditional conservation of canonical USDC balances; shared20-USDC outside budget, no FIFO/pro rata.','conditional_on':'Completeness of retained canonical USDC histories; historical opening balances remain event-derived.','phase_start':phase[0]['utc'],'phase_end_exclusive':ledger[last]['utc'],'source_pool_USDC':'191393.685754','outside_USDC':'20','owner_disposed_USDC':'191413.685754','1991_receipts_USDC':'150010','1991_payments_USDC':'138550','1991_remaining_USDC':'11460','buckets':[{'destination':k,'amount_USDC':dec(n),'individual_pool_origin_interval_USDC':[dec(n-20_000_000),dec(n)]} for k,n in buckets],'joint_exchange_routes_USDC':'90750','joint_exchange_pool_origin_interval_USDC':['90730','90750'],'joint_exchange_plus_Base_USDC':'117850','joint_exchange_plus_Base_pool_origin_interval_USDC':['117830','117850'],'outside_raw_receipts':outside,'1991_phase_rows':phase,'sources':[{'file':x,'sha256':hashlib.sha256((R/x).read_bytes()).hexdigest()} for x in paths],'limits':['Individual intervals share the same20-USDC outside budget; do not add individual minima as a joint result.','KuCoin/MEXC endpoint mechanics reuse previously verified evidence; this file does not claim newly retrieved exchange-sweep receipts.','No investor entitlement, beneficial owner, trading profit allocation, authorization or personal receipt is inferred.','BUSD, ML and USDT remain separate from this USDC partition.']}
(P/'allocation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['outside_raw_receipts','1991_phase_rows','sources']},indent=2))
