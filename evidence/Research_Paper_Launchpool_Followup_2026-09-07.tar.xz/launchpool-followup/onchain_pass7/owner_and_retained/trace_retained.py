import pathlib,urllib.request,json,datetime,hashlib,sys,csv,time
from decimal import Decimal,getcontext
getcontext().prec=80
P=pathlib.Path(__file__).parent
U='https://rpc-bsc.blockmachine.io';BNB='https://bsc-dataseed.bnbchain.org'
OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
TARGETS=[OWNER,'0xf98f525068971a572fa1ec2dee870ddec91de420','0xbf7f26976b451cee4d055f43dbdb10c0426ce630','0x87245c288fcc858bf7225dc3ab97d0ad94730757']
BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56';TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
OFFLINE='--offline' in sys.argv
DAYS=int(next((s.split('=')[1] for s in sys.argv if s.startswith('--days=')),'1'))
assert DAYS in (1,7)
if DAYS==7:TARGETS.append('0x57e89888a0ff0730af0b7c14ea640dd87f67c969')
def rpc(name,qs,url=U):
 meta=P/(name+'.receipt.json');resp=P/(name+'.response')
 if resp.exists():
  m=json.loads(meta.read_text());b=resp.read_bytes();assert m['request']==qs and m['url']==url and m['sha256']==hashlib.sha256(b).hexdigest()
 elif OFFLINE:raise FileNotFoundError(name)
 else:
  m={'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs}
  try:
   with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=45) as r:
    b=r.read();m.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());resp.write_bytes(b)
  except Exception as e:
   m['error']=str(e)
   if hasattr(e,'read'):
    eb=e.read();(P/(name+'.error_body')).write_bytes(eb);m['error_body_sha256']=hashlib.sha256(eb).hexdigest()
   raise
  finally:meta.write_text(json.dumps(m,indent=2))
  time.sleep(8 if url==U else .4)
 data=json.loads(b)
 if isinstance(data,dict):data=[data]
 for row in data:
  if 'error' in row:raise RuntimeError((name,row))
 assert len(data)==len(qs) and set(x['id'] for x in data)==set(x['id'] for x in qs)
 return {x['id']:x['result'] for x in data}
def q(i,m,p):return {'jsonrpc':'2.0','id':i,'method':m,'params':p}
def topic(a):return '0x'+a[2:].zfill(64)
def dec(n):return format(Decimal(n)/Decimal(10**18),'f')
def utc(t):return datetime.datetime.fromtimestamp(t,datetime.timezone.utc).isoformat()
def boundary(days):
 target=int(datetime.datetime.fromisoformat('2022-11-05T13:59:08+00:00').timestamp())+days*86400
 low=22794958+days*25000;high=22794958+days*30000
 dd=rpc('d%d_boundary_initial'%days,[q(n,'eth_getBlockByNumber',[hex(n),False]) for n in [low,high]],BNB)
 assert int(dd[low]['timestamp'],16)<=target<int(dd[high]['timestamp'],16)
 for i in range(20):
  if high-low==1:break
  mid=(low+high)//2;d=rpc('d%d_boundary_%02d'%(days,i),[q(mid,'eth_getBlockByNumber',[hex(mid),False])],BNB)[mid]
  if int(d['timestamp'],16)<=target:low=mid
  else:high=mid
 assert high-low==1
 return low,target

def main():
 cache={}
 for meta in sorted(P.glob('sibling_*.receipt.json')):
  m=json.loads(meta.read_text());raw=meta.with_name(meta.name[:-len('.receipt.json')]+'.response').read_bytes();assert hashlib.sha256(raw).hexdigest()==m['sha256'] and m['url']==BNB
  data={x['id']:x['result'] for x in json.loads(raw)}
  for request in m['request']:cache[(request['method'],json.dumps(request['params']))]=data[request['id']]
 def reused(method,params):return cache.get((method,json.dumps(params)))
 end,target=boundary(DAYS)
 windows=[{'name':'owner_gap','first_block':22760779,'last_block':22766631,'addresses':[OWNER]}, {'name':'retained_d%d'%DAYS,'first_block':22794959,'last_block':end,'addresses':TARGETS,'cutoff_utc':utc(target)}]
 all_rows=[];recs=[]
 for w in windows:
  pref=w['name'];qs=[]
  for start in range(w['first_block'],w['last_block']+1,10000):
   for direction in ('out','in'):
    tops=[TRANSFER,[topic(a) for a in w['addresses']]] if direction=='out' else [TRANSFER,None,[topic(a) for a in w['addresses']]]
    qs.append(q(len(qs)+1,'eth_getLogs',[{'address':BUSD,'topics':tops,'fromBlock':hex(start),'toBlock':hex(min(start+9999,w['last_block']))}]))
  logs=[]
  small_retry=(DAYS==7 and pref=='retained_d7')
  batch_size=2 if small_retry else 4
  for part in range(0,len(qs),batch_size):
   log_name=pref+('_logs_retry2_%03d' if small_retry else '_logs_%03d')%part
   dat=rpc(log_name,qs[part:part+batch_size])
   for ls in dat.values():logs+=ls
  logs=list({(l['transactionHash'],l['logIndex']):l for l in logs}.values());logs.sort(key=lambda l:(int(l['blockNumber'],16),int(l['logIndex'],16)))
  (P/(pref+'_logs.json')).write_text(json.dumps(logs,indent=2));print(pref,'unique events',len(logs),flush=True)
  if len(logs)>200:raise RuntimeError('Bounded stop: more than200events')
  txs=sorted(set(l['transactionHash'] for l in logs));hs=sorted(set(int(l['blockNumber'],16) for l in logs)|{w['first_block']-1,w['first_block'],w['last_block'],w['last_block']+1});hd={};rd={};td={}
  for h in hs:
   old=reused('eth_getBlockByNumber',[hex(h),False]) if pref=='retained_d7' else None
   if old:hd[h]=old
  missing_hs=[h for h in hs if h not in hd]
  for part in range(0,len(missing_hs),12):hd.update(rpc(pref+'_headers_%03d'%part,[q(h,'eth_getBlockByNumber',[hex(h),False]) for h in missing_hs[part:part+12]],BNB))
  for tx in txs:
   old=reused('eth_getTransactionReceipt',[tx])
   if old:rd[tx]=old
   old=reused('eth_getTransactionByHash',[tx])
   if old:td[tx]=old
  for method,target_dict,stem in [('eth_getTransactionReceipt',rd,'receipts'),('eth_getTransactionByHash',td,'transactions')]:
   missing_txs=[tx for tx in txs if tx not in target_dict]
   for part in range(0,len(missing_txs),8):
    sub=missing_txs[part:part+8];d=rpc(pref+'_'+stem+'_%03d'%part,[q(i,method,[tx]) for i,tx in enumerate(sub)],BNB);target_dict.update({tx:d[i] for i,tx in enumerate(sub)})
  qs=[];maps={}
  for a in w['addresses']:
   for pos in ['first','last']:
    h=w['first_block']-1 if pos=='first' else w['last_block'];i=len(qs)+1;maps[i]=(a,pos);qs.append(q(i,'eth_call',[{'to':BUSD,'data':'0x70a08231'+a[2:].zfill(64)},hex(h)]))
  bals={}
  balance_batch=2 if DAYS==7 and pref=='retained_d7' else 4
  for part in range(0,len(qs),balance_batch):bals.update(rpc(pref+'_balances_%03d'%part,qs[part:part+balance_batch]))
  bal={maps[k]:int(v,16) for k,v in bals.items()};rows=[]
  for l in logs:
   h=int(l['blockNumber'],16);r=rd[l['transactionHash']];head=hd[h];tx=td[l['transactionHash']]
   assert r['status']=='0x1' and r['blockHash']==head['hash']==l['blockHash']==tx['blockHash'] and any(x==l for x in r['logs'])
   f='0x'+l['topics'][1][-40:];t='0x'+l['topics'][2][-40:];v=int(l['data'],16)
   rows.append({'window':pref,'tx_hash':l['transactionHash'],'block_number':h,'block_hash':head['hash'],'utc':utc(int(head['timestamp'],16)),'from':f,'to':t,'amount_raw':str(v),'amount_busd':dec(v),'log_index':int(l['logIndex'],16),'tx_from':tx['from'],'tx_to':tx['to'],'tx_input':tx['input'],'status':1})
  for a in w['addresses']:
   inc=sum(int(r['amount_raw']) for r in rows if r['to']==a);out=sum(int(r['amount_raw']) for r in rows if r['from']==a);op=bal[a,'first'];cl=bal[a,'last'];assert op+inc-out==cl,(a,op,inc,out,cl)
   recs.append({'window':pref,'address':a,'opening_raw':str(op),'closing_raw':str(cl),'in_raw':str(inc),'out_raw':str(out),'opening_busd':dec(op),'closing_busd':dec(cl),'in_busd':dec(inc),'out_busd':dec(out),'reconciled':True})
  w['first_block_utc']=utc(int(hd[w['first_block']]['timestamp'],16));w['last_block_utc']=utc(int(hd[w['last_block']]['timestamp'],16));w['after_block_utc']=utc(int(hd[w['last_block']+1]['timestamp'],16));all_rows+=rows
 result={'token':BUSD,'days':DAYS,'windows':windows,'rows':all_rows,'window_balances':recs}
 (P/('verified_retained_d%d.json'%DAYS)).write_text(json.dumps(result,indent=2))
 if all_rows:
  with (P/('verified_retained_d%d.csv'%DAYS)).open('w') as f:
   wr=csv.DictWriter(f,fieldnames=list(all_rows[0]));wr.writeheader();wr.writerows(all_rows)
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
