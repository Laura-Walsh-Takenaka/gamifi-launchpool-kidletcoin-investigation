# Original Mintlayer BUSD: continuous owner reconciliation and retained funds

Research date: 7 September 2026. Canonical BSC BUSD token: `0xe9e7cea3dedca5984780bafc599bd69add087d56`.

## Completed owner-gap check

The previously unscanned interval between the two original-withdrawal windows is now covered. Both incoming and outgoing canonical BUSD `Transfer` logs were queried for owner `0x77bfe8d704b1948374bf8dab8328a810b2836e66` over blocks **22,760,779–22,766,631**, inclusive. The query returned **zero events**. The first block is 4 November 2022 at 09:02:18 UTC; the last is 13:59:05 UTC; block 22,766,632 at 13:59:08 UTC begins the previously verified Raise 2 window.

Independent historical `balanceOf` calls at blocks 22,760,778 and 22,766,631 both returned **66,047.442300766942811912 BUSD**. This closes the specific uncertainty about offsetting BUSD transfers within the earlier unscanned gap.

The original owner chronology now reconciles continuously from immediately before the first original Mintlayer withdrawal through 5 November 2022 at the previous cutoff:

`0.332011149154053912 opening + 903,794.346419582485370326 six Mintlayer withdrawals - 896,370 eleven onward payments = 7,424.678430731639424238 BUSD`.

These numbers are the same previously recovered transactions, not additional fundraising or an additional loss estimate. The opening 0.332011149154053912 BUSD remains separate pre-existing funding.

## First 24 hours after the prior cutoff

Blocks **22,794,959–22,823,525**, inclusive, cover 5 November 2022 13:59:10 UTC through 6 November 2022 13:59:06 UTC. The next block is 13:59:09 UTC, correctly excluded from the 6 November 13:59:08 UTC cutoff.

Both directions of canonical BUSD transfers were checked for all four addresses. **Zero events** were returned, and independent historical balances at both boundaries matched for each wallet:

| Address | Opening and closing BUSD |
|---|---:|
| `0x77bfe8d704b1948374bf8dab8328a810b2836e66` | 7,424.678430731639424238 |
| `0xf98f525068971a572fa1ec2dee870ddec91de420` | 200,000 |
| `0xbf7f26976b451cee4d055f43dbdb10c0426ce630` | 150,000 |
| `0x87245c288fcc858bf7225dc3ab97d0ad94730757` | 25,197.437915171993026378 |

The 87245c amount includes its previously verified 197.437915171993026378 BUSD opening balance, in addition to the 25,000 BUSD payment from 77bf. These are historical balances, not current holdings. They establish custody at this cutoff; they do not establish the payment mandate or the holder's human identity.

## Completed one-week extension and the additional Binance route

The successful smaller retry covers blocks **22,794,959–22,993,378**, inclusive, from 5 November 2022 13:59:10 UTC through 12 November 2022 13:59:07 UTC. The next block is 13:59:10 UTC, correctly excluded from the 13:59:08 UTC cutoff. It queries both incoming and outgoing BUSD for the original four targets and `0x57e89888a0ff0730af0b7c14ea640dd87f67c969`, added to follow the parallel lane's cedfa convergence without a second set of log queries.

**225,000 BUSD passed from cedfa through 57e898 to the previously explorer-labelled Binance 51 address `0x8894e0a0c962cb723c1976a4421c95949be2d4e3`.** The entire seven-day 57e898 BUSD ledger contains exactly three incoming payments from cedfa and two outgoing payments to Binance 51. Its historical balance opens and closes at zero, with no other BUSD inflows or outflows in the window. Both outgoing transfers have independently acquired successful official BNB receipts, transaction calldata and matching block headers.

| UTC | From → To | BUSD | Transaction |
|---|---|---:|---|
| 2022-11-07 09:28:37 | `0xf98f525068971a572fa1ec2dee870ddec91de420` → `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | 200000 | `0x978edfbfb7031603b9f4d386447f75fdee443527eeb14dfc4a82cbbf6b0ece5e` |
| 2022-11-07 19:55:53 | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` → `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 10 | `0xafd971d5146fb24e809d1a395e93751817174ba98e48b331d86c940fafb64b61` |
| 2022-11-07 20:08:41 | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` → `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 124990 | `0xb5d52bf923bbcc5ac5b2cf2dcbe858e2dd66241db0227ef5bd06a5d545b6a5c5` |
| 2022-11-07 20:30:06 | `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` → `0x8894e0a0c962cb723c1976a4421c95949be2d4e3` | 125000 | `0x557e71f98fb53c96f0273b930e9243cf9c098c40315144ca07893c25687e3ea5` |
| 2022-11-08 10:03:00 | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` → `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 100000 | `0xf0f280b56d6107d46e308139e5deba6c7ec239594197fa80dc1697954d445389` |
| 2022-11-08 10:30:06 | `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` → `0x8894e0a0c962cb723c1976a4421c95949be2d4e3` | 100000 | `0x3ff1c1a5e8a07c2f229820de38923416e23a8b06cc695be45529cb53fc9fcff6` |

The 125,000-BUSD sweep occurred **21m25s** after the last of its two contributing cedfa payments; the 100,000-BUSD sweep occurred **27m06s** after receipt. These are observed timings, not proof of a settlement purpose or a customer identity.

The 200,000 BUSD previously held by f98f52 moved to cedfa on **7 November 2022 at 09:28:37 UTC**. It is the sole f98f52 BUSD transfer in this full window and reduces the verified historical balance from 200,000 to zero. The other three retained-fund addresses show no BUSD events throughout the week and retain their historical cutoff balances:

| Address | Opening BUSD | Incoming BUSD | Outgoing BUSD | Closing BUSD on 12 November |
|---|---:|---:|---:|---:|
| `0x77bfe8d704b1948374bf8dab8328a810b2836e66` | 7424.678430731639424238 | 0 | 0 | 7424.678430731639424238 |
| `0xf98f525068971a572fa1ec2dee870ddec91de420` | 200000 | 0 | 200000 | 0 |
| `0xbf7f26976b451cee4d055f43dbdb10c0426ce630` | 150000 | 0 | 0 | 150000 |
| `0x87245c288fcc858bf7225dc3ab97d0ad94730757` | 25197.437915171993026378 | 0 | 0 | 25197.437915171993026378 |
| `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 0 | 225000 | 225000 | 0 |

There are **six unique positive events** across the five-address week ledger. Transfers at different steps of the same route must not be summed as separate fundraising proceeds. The 225,000-BUSD Binance branch is additional endpoint throughput to the separate 54,370-BUSD and 222,000-BUSD routes already recovered; allocation of all source balances remains a separate calculation. In particular, cedfa had pre-existing BUSD before the original-withdrawal payments, so this lane does not assign every unit of its 225,000-BUSD outgoing amount exclusively to Mintlayer fundraising.

The first-day capture is a subset of the four-address portion of this one-week result. It is retained for audit and must not be counted twice. The owner-gap check plus the prior pass6 windows and this successful extension now provide a continuous owner BUSD chronology from the first Mintlayer withdrawal through 12 November 2022. The original 7,424.678430731639424238-BUSD residual remained at 77bf at that cutoff. No period after this explicit one-week extension has been scanned here.

## Rate-limit handling

The original first four-call week log batch returned HTTP 429; the exact request, failure and response body are preserved as `retained_d7_logs_000.receipt.json` and `.error_body`. The body specifies a 300-compute-unit per-minute budget and a seven-second retry delay. Other BSC work was paused; the single smaller retry used two-call batches with eight-second spacing and completed without a further rate-limit error. No wallet interaction or paid/authenticated endpoint was used.

## Provenance and reproduction

The documented keyless Blockmachine BSC RPC supplies historical BUSD logs and balances. The official BNB RPC supplies independently acquired block headers and, for any discovered transfer, successful transaction receipts and calldata. Every request has a contemporaneous receipt recording exact parameters, URL, UTC, HTTP status and response SHA-256. Inclusive log ranges stay within the provider's 10,000-block cap.

`python onchain_pass7/owner_and_retained/trace_retained.py --days=1 --offline` and `python onchain_pass7/owner_and_retained/trace_retained.py --days=7 --offline` both replayed successfully without network access. The local independent structural verifier passed 708 checks; separate peer-review outputs belong in the parent pass7 review directory. `verify_capture.py` independently checks the response hashes, exact canonical-token topics, contiguous incoming/outgoing block coverage and historical balance reconciliation. Broader histories outside the explicit windows have not been scanned. No human controller, project settlement purpose, exchange customer or Laura's personal receipt is identified by this lane.

The six `sibling_extension_*` files are byte-identical copies of the parallel branch lane's successful official BNB header, receipt and transaction captures. `reused_capture_provenance.json` identifies each source path and SHA-256. Overlapping transactions use those existing raw responses; they were not requested again.

For the Binance 51 service label, see the previously saved primary explorer provenance in `onchain_pass6/original_busd_onward/endpoint_label_provenance.json`. The label identifies the service endpoint; it does not identify the exchange account beneficiary, the human signer or Laura.
