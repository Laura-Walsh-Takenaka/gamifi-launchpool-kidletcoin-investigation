"""Independent structural checks of retained BUSD captures; no network calls."""
from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).parent
TOKEN='0xe9e7cea3dedca5984780bafc599bd69add087d56'
TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
checks=0
def ck(ok,msg):
 global checks
 assert ok,msg
 checks+=1
responses={}
for meta in sorted(P.glob('*.receipt.json')):
 m=json.loads(meta.read_text());r=meta.with_name(meta.name[:-len('.receipt.json')]+'.response')
 if 'error' in m:
  if 'error_body_sha256' in m:
   body=meta.with_name(meta.name[:-len('.receipt.json')]+'.error_body');ck(body.exists() and hashlib.sha256(body.read_bytes()).hexdigest()==m['error_body_sha256'],'preserved failure body hash')
  continue
 ck(r.exists(),str(r));ck(hashlib.sha256(r.read_bytes()).hexdigest()==m['sha256'],str(r)+' SHA256')
 d=json.loads(r.read_text());d=d if isinstance(d,list) else [d]
 ck(set(x['id'] for x in d)==set(x['id'] for x in m['request']),str(r)+' IDs')
 responses[meta.name[:-len('.receipt.json')]]=(m,{x['id']:x for x in d})
headers={}
for stem,(m,d) in responses.items():
 for q in m['request']:
  if q['method']=='eth_getBlockByNumber' and d[q['id']].get('result'):
   h=d[q['id']]['result'];n=int(q['params'][0],16);ck(int(h['number'],16)==n,'header requested block number')
   if n in headers:ck(headers[n]['hash']==h['hash'],'duplicate header consistency')
   headers[n]=h
for suffix in ['d1','d7']:
 path=P/('verified_retained_'+suffix+'.json')
 if not path.exists():continue
 result=json.loads(path.read_text());ck(result['token']==TOKEN,'canonical token')
 for w in result['windows']:
  for position in ['first','last']:
   n=w[position+'_block'];actual=datetime.datetime.fromtimestamp(int(headers[n]['timestamp'],16),datetime.timezone.utc).isoformat();ck(actual==w[position+'_block_utc'],'window timestamp')
  if 'cutoff_utc' in w:
   cutoff=datetime.datetime.fromisoformat(w['cutoff_utc']).timestamp();ck(int(headers[w['last_block']]['timestamp'],16)<=cutoff<int(headers[w['last_block']+1]['timestamp'],16),'adjacent exact time cutoff')
  name=w['name'];ranges={'in':[],'out':[]};raw=[];topics=['0x'+a[2:].zfill(64) for a in w['addresses']]
  for stem,(m,d) in responses.items():
   if not stem.startswith(name+'_logs_'):continue
   for q in m['request']:
    ck(q['method']=='eth_getLogs','log method');p=q['params'][0];ck(p['address']==TOKEN,'tokenfilter');ck(p['topics'][0]==TRANSFER,'eventfilter')
    direction='out' if len(p['topics'])==2 else 'in';ck(p['topics'][1 if direction=='out' else 2]==topics,'exacttargetfilter')
    lo=int(p['fromBlock'],16);hi=int(p['toBlock'],16);ck(0<=hi-lo<10000,'provider range cap');ranges[direction].append((lo,hi));ck('error' not in d[q['id']],'successful logs response');raw+=d[q['id']]['result']
  for direction,rs in ranges.items():
   rs.sort();ck(rs[0][0]==w['first_block'] and rs[-1][1]==w['last_block'],'range boundaries '+name+direction)
   ck(all(b[0]==a[1]+1 for a,b in zip(rs,rs[1:])),'no range gaps '+name+direction)
  raw={ (r['transactionHash'],int(r['logIndex'],16)):r for r in raw }
  rows=[r for r in result['rows'] if r['window']==name];ck(set(raw)==set((r['tx_hash'],r['log_index']) for r in rows),'all raw events represented')
  for r in rows:
   original=raw[r['tx_hash'],r['log_index']];ck(r['amount_raw']==str(int(original['data'],16)),'amount');ck(r['from']=='0x'+original['topics'][1][-40:] and r['to']=='0x'+original['topics'][2][-40:],'addresses');ck(r['block_number']==int(original['blockNumber'],16),'block')
   candidates=[]
   for stem,(m,d) in responses.items():
    if not (stem.startswith(name+'_receipts_') or stem.startswith('sibling_extension_receipts_')):continue
    for q in m['request']:
     if q['params']==[r['tx_hash']]:candidates.append(d[q['id']]['result'])
   ck(len(candidates)==1,'unique raw receipt');rc=candidates[0];ck(rc['status']=='0x1' and original in rc['logs'],'successful raw transfer receipt');ck(rc['blockHash']==original['blockHash']==headers[r['block_number']]['hash'],'receipt log header hash agreement');ck(r['utc']==datetime.datetime.fromtimestamp(int(headers[r['block_number']]['timestamp'],16),datetime.timezone.utc).isoformat(),'event UTC')
  for bal in [b for b in result['window_balances'] if b['window']==name]:
   a=bal['address'];inc=sum(int(r['amount_raw']) for r in rows if r['to']==a);out=sum(int(r['amount_raw']) for r in rows if r['from']==a);ck(str(inc)==bal['in_raw'] and str(out)==bal['out_raw'],'flow sum')
   ck(int(bal['opening_raw'])+inc-out==int(bal['closing_raw']),'equation')
   for pos,block in [('opening',w['first_block']-1),('closing',w['last_block'])]:
    matches=[]
    for stem,(m,d) in responses.items():
     if not stem.startswith(name+'_balances_'):continue
     for q in m['request']:
      if q['params']==[{'to':TOKEN,'data':'0x70a08231'+a[2:].zfill(64)},hex(block)]:matches.append(d[q['id']]['result'])
    ck(len(matches)==1,'balance source unique');ck(int(matches[0],16)==int(bal[pos+'_raw']),'balance source matches')
 summary={'status':'PASS','checks':checks,'replayed':['verified_retained_'+s+'.json' for s in ['d1','d7'] if (P/('verified_retained_'+s+'.json')).exists()],'scope':'Response hashes, exact BUSD filters, contiguous incoming/outgoing log coverage, no missing or extra event rows, selected raw receipt matches, historic balances and full integer reconciliation.'}
(P/'verification.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
