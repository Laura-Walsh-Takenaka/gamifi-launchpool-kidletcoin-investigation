# Original Mintlayer BUSD: three more branches converge at Binance 51

The five downstream addresses selected from pass6 add three successful payments to the same Binance 51 endpoint. On 3 November 2022, **222,090.52 BUSD** reached that endpoint through these branches: 200,000, 2,090.52 and 20,000. Of that gross amount, 222,000 came through the previously verified owner-transfer chain; 90.52 was already held by one intermediary.

Together with the earlier 54,370 BUSD, the captured endpoint total is **276,460.52 BUSD in five payments**. The owner-transfer component is **276,370 BUSD**. These are additional traced hops, not new fundraising receipts or evidence of loss.

## Exact new endpoint transfers

All times below are UTC on 3 November 2022. The canonical token is BSC BUSD `0xe9e7cea3dedca5984780bafc599bd69add087d56`. Endpoint: `0x8894e0a0c962cb723c1976a4421c95949be2d4e3`.

| UTC | Intermediary | BUSD sent | Receipt transaction |
|---|---|---:|---|
| 11:00:28 | `0x0d43408dfc53fef53a41d978e072a69d4a00c5dd` | 200000 | `0xe29fcd3628a526e40fd0df25d6f1370e7cc37bb28db0d1d97ed20ca64f535a06` |
| 12:00:37 | `0xab3c27e291d073c4e3d2c1e0adfbb3fcc56b7151` | 2090.52 | `0xfe96c9ac0041963b1fc9309d92652fb162f21296d6ab37717f3b947dda35d246` |
| 13:00:41 | `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 20000 | `0xa6fde49b3abd7fb91fd61d4ff019d561f2820830488db970701330a283454d99` |

The 200,000 payment occurred 19m44s after 1991 funded 0d434. The 2,090.52 sweep occurred 29m24s after 1991 supplied 2,000 to ab3c; the independently queried opening balance was 90.52. The 20,000 payment occurred 18m52s after f98 funded 57e898. All three intermediaries closed at zero BUSD.

## First-day historical balance reconciliation

The complete inclusive window is blocks 22,732,478–22,760,778: 3 November 2022 09:02:17 through the 4 November 09:02:17 UTC cutoff. Opening balances are queried at block 22,732,477; closing balances at 22,760,778. Both directions of canonical BUSD logs were captured in adjacent ranges of at most 10,000 blocks.

| Address | Opening BUSD | Incoming BUSD | Outgoing BUSD | Closing BUSD |
|---|---:|---:|---:|---:|
| `0x0d43408dfc53fef53a41d978e072a69d4a00c5dd` | 0 | 200000 | 200000 | 0 |
| `0xdc127dd1218e555684d7e5605e80afdc75868d42` | 663 | 40000 | 0 | 40663 |
| `0xab3c27e291d073c4e3d2c1e0adfbb3fcc56b7151` | 90.52 | 2000 | 2090.52 | 0 |
| `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 0 | 20000 | 20000 | 0 |
| `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | 215.79767608 | 204990 | 0 | 205205.79767608 |

Each equation reconciles exactly in 18-decimal base units. Eight unique events comprise five previously captured incoming transfers and the three new outgoing payments. Each event matches a successful receipt from the official BNB RPC, its transaction input and block header. All eight are direct BUSD transfer calls.

## Source attribution

All positive first-window inflows to 77bf were the original Mintlayer pool withdrawals, but 77bf already held 0.332011149154053912 BUSD. Balance conservation therefore bounds the original-pool share of the combined 276,460.52 Binance throughput at **276,369.667988850845946088–276,370 BUSD**. This excludes ab3c's independently established 90.52 opening balance and allows all of 77bf's opening cash to enter the selected branch. The maximum is feasible with that 0.332011149154053912 retained in 77bf's closing cash; the minimum is feasible with it flowing through 77bf's direct 29,370 payment to 14c840 and onward to Binance. The peer reviewer independently confirmed both feasible endpoints.

This is a conditional numerical source constraint based on captured histories and historical balances. It is not a determination of investor entitlement, project settlement, unlawful disposition or beneficial ownership. The entire 276,460.52 endpoint throughput must not be described as newly raised Mintlayer funds.

## Seven-day continuation

Two recipients retained funds at the first cutoff, so their complete incoming and outgoing BUSD logs were extended through seven days from the original first withdrawal. The additional inclusive scan is blocks 22,760,779–22,930,997, ending at the 10 November 2022 09:02:17 UTC cutoff. The first subsequent block, 22,930,998, is excluded. This joins the initial window without a gap or overlap.

The extension contains **four positive transfers and one zero-value event**. Address dc127 made no BUSD transfers and retained its historical 40,663 BUSD throughout this extension. Address cedfa received another 200,000 BUSD from f98 on 7 November, then paid **225,000 BUSD to the same 57e898 intermediary** that had already swept 20,000 to Binance on 3 November. This lane verifies the transfers to 57e898; their subsequent disposition is followed separately in the coordinated retained-funds lane.

| UTC | From | To | BUSD | Transaction |
|---|---|---|---:|---|
| 2022-11-07 09:28:37 | `0xf98f525068971a572fa1ec2dee870ddec91de420` | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | 200000 | `0x978edfbfb7031603b9f4d386447f75fdee443527eeb14dfc4a82cbbf6b0ece5e` |
| 2022-11-07 19:55:53 | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 10 | `0xafd971d5146fb24e809d1a395e93751817174ba98e48b331d86c940fafb64b61` |
| 2022-11-07 20:08:41 | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 124990 | `0xb5d52bf923bbcc5ac5b2cf2dcbe858e2dd66241db0227ef5bd06a5d545b6a5c5` |
| 2022-11-08 10:03:00 | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | `0x57e89888a0ff0730af0b7c14ea640dd87f67c969` | 100000 | `0xf0f280b56d6107d46e308139e5deba6c7ec239594197fa80dc1697954d445389` |
| 2022-11-09 15:27:51 | `0x6356c3cfd22e894352bcfcbbf75f609efa17c969` | `0xcedfa732228e532ef6e62296cf0f6de188c5d5a0` | 0 | `0x81026bf9833b29697a8a9efefbc43e100a9031f22ad933fc9e502dd2d0c61d98` |

Cedfa's exact extension balance equation is **205,205.79767608 + 200,000 − 225,000 = 180,205.79767608 BUSD**. Its opening amount included the original 204,990 owner-chain receipt and 215.79767608 already held before that receipt. The extra 200,000 comes through the previously captured f98 address; the retained-funds lane verifies its upstream custody. No individual payment is assigned a unique original raise merely from timing.

The zero-value incoming event on 9 November contributes no funds and provides no affiliation evidence for its displayed sender. All five extension events match successful official BNB receipts. Both endpoint balances were queried historically and reconcile exactly. The cutoff balances are historical November 2022 amounts, not current holdings.

## Endpoint identification and limits

The primary Blockscan page for the exact 8894 address was opened again on 7 September 2026. It names Binance 51 / Binance Exchange and displays BNB Chain activity. The same endpoint was independently documented in pass6. This identifies the service-associated endpoint, not its customer or a human signing-key holder. Intermediary labels are not inferred from sweep behavior or from the secondary 2019 ETH mention of 0d434. No personal receipt by Laura, customer account, custody mandate or subsequent exchange withdrawal is established.

Source: https://blockscan.com/Address/0x8894e0a0c962cb723c1976a4421c95949be2d4e3 . Label capture and failed label-search limits are retained separately.

## Reproduction and failed calls

Run `python onchain_pass7/busd_branches/trace_branches.py --offline` and `python onchain_pass7/busd_branches/trace_extension.py --offline` from the project root. Both offline replays passed. Exact requests, endpoint URLs, retrieval UTC, HTTP outcomes and SHA-256 are preserved in paired receipt/response files. Historical reads use the public keyless Blockmachine BSC RPC; transaction receipts and headers use the official BNB RPC.

One extension log batch received HTTP 429 after 13 successful batches. Its failed request receipt is retained as `extension_logs_26_failed429.receipt.json`. The error body was not captured by that initial helper version; the recorded failure is urllib's HTTP 429. A subsequent bounded retry completed with eight-second spacing per fresh Blockmachine request. No previous-pass evidence is modified. Full raw responses contain 13 unique event receipts across the two windows; these include previously known upstream transfers and one zero-value event. They must not be counted as 13 newly discovered funded payments.
