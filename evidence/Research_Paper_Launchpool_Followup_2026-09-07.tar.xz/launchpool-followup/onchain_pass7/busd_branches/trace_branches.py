from rpc_helpers import *

TARGETS=['0x0d43408dfc53fef53a41d978e072a69d4a00c5dd','0xdc127dd1218e555684d7e5605e80afdc75868d42','0xab3c27e291d073c4e3d2c1e0adfbb3fcc56b7151','0x57e89888a0ff0730af0b7c14ea640dd87f67c969','0xcedfa732228e532ef6e62296cf0f6de188c5d5a0']
START=22732478; END=22760778

def run(TARGETS=TARGETS,START=START,END=END,prefix="branch",result_name="verified_branches"):
 logs=[];qs=[]
 for start in range(START,END+1,10000):
  for direction in ('in','out'):
   tops=[TRANSFER,[topic(a) for a in TARGETS]] if direction=='out' else [TRANSFER,None,[topic(a) for a in TARGETS]]
   qs.append(q(len(qs)+1,'eth_getLogs',[{'address':BUSD,'topics':tops,'fromBlock':hex(start),'toBlock':hex(min(start+9999,END))}]))
 for part in range(0,len(qs),2):
  data=rpc(prefix+'_logs_%02d'%part,qs[part:part+2])
  for rows in data.values():logs.extend(rows)
 logs=list({(l['transactionHash'],l['logIndex']):l for l in logs}.values());logs.sort(key=lambda l:(int(l['blockNumber'],16),int(l['logIndex'],16)))
 (P/(prefix+'_logs.json')).write_text(json.dumps(logs,indent=2));print('branch logs',len(logs),flush=True)
 if len(logs)>150:raise RuntimeError('More than 150 events: bounded stop')
 txs=sorted(set(l['transactionHash'] for l in logs));hs=sorted(set(int(l['blockNumber'],16) for l in logs)|{START-1,END});hd={};rd={};td={}
 for part in range(0,len(hs),10):hd.update(rpc(prefix+'_headers_%02d'%part,[q(h,'eth_getBlockByNumber',[hex(h),False]) for h in hs[part:part+10]],BNB))
 for part in range(0,len(txs),10):
  sub=txs[part:part+10]
  data=rpc(prefix+'_receipts_%02d'%part,[q(i,'eth_getTransactionReceipt',[tx]) for i,tx in enumerate(sub)],BNB);rd.update({tx:data[i] for i,tx in enumerate(sub)})
  data=rpc(prefix+'_transactions_%02d'%part,[q(i,'eth_getTransactionByHash',[tx]) for i,tx in enumerate(sub)],BNB);td.update({tx:data[i] for i,tx in enumerate(sub)})
 qs=[];maps={}
 for a in TARGETS:
  for pos in ['first','last']:
   block=START-1 if pos=='first' else END;i=len(qs)+1;maps[i]=(a,pos)
   qs.append(q(i,'eth_call',[{'to':BUSD,'data':'0x70a08231'+a[2:].zfill(64)},hex(block)]))
 balances={}
 for part in range(0,len(qs),2):balances.update(rpc(prefix+'_balances_%02d'%part,qs[part:part+2]))
 bal={(maps[k]):int(v,16) for k,v in balances.items()};rows=[]
 for l in logs:
  h=int(l['blockNumber'],16);rec=rd[l['transactionHash']];head=hd[h];tx=td[l['transactionHash']]
  assert rec['status']=='0x1' and rec['blockHash']==head['hash']==l['blockHash']==tx['blockHash'] and any(x==l for x in rec['logs'])
  assert l['address'].lower()==BUSD and l['topics'][0]==TRANSFER and len(l['topics'])==3
  f='0x'+l['topics'][1][-40:];t='0x'+l['topics'][2][-40:];amount=int(l['data'],16)
  if tx['to'].lower()==BUSD and tx['input'].startswith('0xa9059cbb'):
   assert len(tx['input'])==138 and tx['from'].lower()==f and '0x'+tx['input'][34:74].lower()==t and int(tx['input'][74:138],16)==amount
  rows.append({'tx_hash':l['transactionHash'],'block_number':h,'block_hash':head['hash'],'utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'from':f,'to':t,'amount_raw':str(amount),'amount_busd':dec(amount),'log_index':int(l['logIndex'],16),'tx_from':tx['from'],'tx_to':tx['to'],'tx_input':tx['input'],'status':1})
 reconciliation=[]
 for a in TARGETS:
  inc=sum(int(r['amount_raw']) for r in rows if r['to']==a);out=sum(int(r['amount_raw']) for r in rows if r['from']==a);opening=bal[a,'first'];closing=bal[a,'last'];assert opening+inc-out==closing,(a,opening,inc,out,closing)
  reconciliation.append({'address':a,'opening_raw':str(opening),'closing_raw':str(closing),'in_raw':str(inc),'out_raw':str(out),'opening_busd':dec(opening),'closing_busd':dec(closing),'in_busd':dec(inc),'out_busd':dec(out),'reconciled':True})
 obj={'scope':'Specified downstream recipients of the original November 3, 2022 Mintlayer BUSD withdrawals. Both incoming and outgoing canonical BUSD logs within the inclusive block bounds shown.','target_addresses':TARGETS,'first_block':START,'last_block':END,'rows':rows,'window_balances':reconciliation}
 (P/(result_name+'.json')).write_text(json.dumps(obj,indent=2))
 with (P/(result_name+'.csv')).open('w') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['tx_hash','block_number','block_hash','utc','from','to','amount_raw','amount_busd','log_index','tx_from','tx_to','tx_input','status']);wr.writeheader();wr.writerows(rows)
 print(json.dumps(obj,indent=2))
if __name__=='__main__':run()
