import pathlib,urllib.request,json,datetime,hashlib,sys,csv,time
from decimal import Decimal,getcontext
getcontext().prec=80
P=pathlib.Path(__file__).parent
U='https://rpc-bsc.blockmachine.io';BNB='https://bsc-dataseed.bnbchain.org'
OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66'; BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56'; TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
OFFLINE='--offline' in sys.argv

def rpc(name,qs,url=U):
 meta_path=P/(name+'.receipt.json'); resp_path=P/(name+'.response')
 if resp_path.exists():
  m=json.loads(meta_path.read_text());b=resp_path.read_bytes();assert m['request']==qs and m['url']==url and m['sha256']==hashlib.sha256(b).hexdigest()
 elif OFFLINE:raise FileNotFoundError(name)
 else:
  m={'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs}
  try:
   if url==U:time.sleep(8)
   with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=45) as r:
    b=r.read();m.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());resp_path.write_bytes(b)
  except Exception as e:
   m['error']=str(e)
   if hasattr(e,'code'):m['status']=e.code
   if hasattr(e,'read'):
    error_bytes=e.read();(P/(name+'.error.response')).write_bytes(error_bytes);m['error_body_sha256']=hashlib.sha256(error_bytes).hexdigest()
   raise
  finally:meta_path.write_text(json.dumps(m,indent=2))
 data=json.loads(b)
 if isinstance(data,dict):data=[data]
 for row in data:
  if 'error' in row:raise RuntimeError((name,row))
 assert len(data)==len(qs) and set(x['id'] for x in data)==set(x['id'] for x in qs)
 return {x['id']:x['result'] for x in data}
def q(i,method,params):return {'jsonrpc':'2.0','id':i,'method':method,'params':params}
def topic(a):return '0x'+a[2:].zfill(64)
def dec(n):return format(Decimal(n)/Decimal(10**18),'f')
