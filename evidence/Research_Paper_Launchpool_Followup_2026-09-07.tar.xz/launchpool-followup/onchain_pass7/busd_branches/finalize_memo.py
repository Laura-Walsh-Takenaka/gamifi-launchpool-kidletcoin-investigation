import json,hashlib
from pathlib import Path
P=Path(__file__).parent
first=json.loads((P/'verified_branches.json').read_text())
extension=json.loads((P/'verified_extension.json').read_text())
bounds=json.loads((P/'extension_bounds.json').read_text())
summary=json.loads((P/'summary.json').read_text())
summary['extension']={'first_block':extension['first_block'],'last_block':extension['last_block'],'cutoff_utc':bounds['cutoff_utc'],'unique_event_count':len(extension['rows']),'positive_transfer_count':sum(int(r['amount_raw'])>0 for r in extension['rows']),'zero_value_transfer_count':sum(int(r['amount_raw'])==0 for r in extension['rows']),'rows':extension['rows'],'window_balances':extension['window_balances']}
summary['verified_scope']='First original 24-hour window, blocks 22732478 through 22760778, 2022-11-03 09:02:17 to 2022-11-04 09:02:17 UTC'
(P/'summary.json').write_text(json.dumps(summary,indent=2))
text='''# Original Mintlayer BUSD: three more branches converge at Binance 51

The five downstream addresses selected from pass6 add three successful payments to the same Binance 51 endpoint. On 3 November 2022, **222,090.52 BUSD** reached that endpoint through these branches: 200,000, 2,090.52 and 20,000. Of that gross amount, 222,000 came through the previously verified owner-transfer chain; 90.52 was already held by one intermediary.

Together with the earlier 54,370 BUSD, the captured endpoint total is **276,460.52 BUSD in five payments**. The owner-transfer component is **276,370 BUSD**. These are additional traced hops, not new fundraising receipts or evidence of loss.

## Exact new endpoint transfers

All times below are UTC on 3 November 2022. The canonical token is BSC BUSD `0xe9e7cea3dedca5984780bafc599bd69add087d56`. Endpoint: `0x8894e0a0c962cb723c1976a4421c95949be2d4e3`.

| UTC | Intermediary | BUSD sent | Receipt transaction |
|---|---|---:|---|
'''
for r in summary['new_binance_transfers']:
 text+=f"| {r['utc'][11:19]} | `{r['from']}` | {r['amount_busd']} | `{r['tx_hash']}` |\n"
text+='''
The 200,000 payment occurred 19m44s after 1991 funded 0d434. The 2,090.52 sweep occurred 29m24s after 1991 supplied 2,000 to ab3c; the independently queried opening balance was 90.52. The 20,000 payment occurred 18m52s after f98 funded 57e898. All three intermediaries closed at zero BUSD.

## First-day historical balance reconciliation

The complete inclusive window is blocks 22,732,478–22,760,778: 3 November 2022 09:02:17 through the 4 November 09:02:17 UTC cutoff. Opening balances are queried at block 22,732,477; closing balances at 22,760,778. Both directions of canonical BUSD logs were captured in adjacent ranges of at most 10,000 blocks.

| Address | Opening BUSD | Incoming BUSD | Outgoing BUSD | Closing BUSD |
|---|---:|---:|---:|---:|
'''
for r in first['window_balances']:
 text+=f"| `{r['address']}` | {r['opening_busd']} | {r['in_busd']} | {r['out_busd']} | {r['closing_busd']} |\n"
text+='''
Each equation reconciles exactly in 18-decimal base units. Eight unique events comprise five previously captured incoming transfers and the three new outgoing payments. Each event matches a successful receipt from the official BNB RPC, its transaction input and block header. All eight are direct BUSD transfer calls.

## Source attribution

All positive first-window inflows to 77bf were the original Mintlayer pool withdrawals, but 77bf already held 0.332011149154053912 BUSD. Balance conservation therefore bounds the original-pool share of the combined 276,460.52 Binance throughput at **276,369.667988850845946088–276,370 BUSD**. This excludes ab3c's independently established 90.52 opening balance and allows all of 77bf's opening cash to enter the selected branch. The maximum is feasible with that 0.332011149154053912 retained in 77bf's closing cash; the minimum is feasible with it flowing through 77bf's direct 29,370 payment to 14c840 and onward to Binance. The peer reviewer independently confirmed both feasible endpoints.

This is a conditional numerical source constraint based on captured histories and historical balances. It is not a determination of investor entitlement, project settlement, unlawful disposition or beneficial ownership. The entire 276,460.52 endpoint throughput must not be described as newly raised Mintlayer funds.

## Seven-day continuation

Two recipients retained funds at the first cutoff, so their complete incoming and outgoing BUSD logs were extended through seven days from the original first withdrawal. The additional inclusive scan is blocks 22,760,779–22,930,997, ending at the 10 November 2022 09:02:17 UTC cutoff. The first subsequent block, 22,930,998, is excluded. This joins the initial window without a gap or overlap.

The extension contains **four positive transfers and one zero-value event**. Address dc127 made no BUSD transfers and retained its historical 40,663 BUSD throughout this extension. Address cedfa received another 200,000 BUSD from f98 on 7 November, then paid **225,000 BUSD to the same 57e898 intermediary** that had already swept 20,000 to Binance on 3 November. This lane verifies the transfers to 57e898; their subsequent disposition is followed separately in the coordinated retained-funds lane.

| UTC | From | To | BUSD | Transaction |
|---|---|---|---:|---|
'''
for r in extension['rows']:
 text+=f"| {r['utc'].replace('T',' ').replace('+00:00','')} | `{r['from']}` | `{r['to']}` | {r['amount_busd']} | `{r['tx_hash']}` |\n"
text+='''
Cedfa's exact extension balance equation is **205,205.79767608 + 200,000 − 225,000 = 180,205.79767608 BUSD**. Its opening amount included the original 204,990 owner-chain receipt and 215.79767608 already held before that receipt. The extra 200,000 comes through the previously captured f98 address; the retained-funds lane verifies its upstream custody. No individual payment is assigned a unique original raise merely from timing.

The zero-value incoming event on 9 November contributes no funds and provides no affiliation evidence for its displayed sender. All five extension events match successful official BNB receipts. Both endpoint balances were queried historically and reconcile exactly. The cutoff balances are historical November 2022 amounts, not current holdings.

## Endpoint identification and limits

The primary Blockscan page for the exact 8894 address was opened again on 7 September 2026. It names Binance 51 / Binance Exchange and displays BNB Chain activity. The same endpoint was independently documented in pass6. This identifies the service-associated endpoint, not its customer or a human signing-key holder. Intermediary labels are not inferred from sweep behavior or from the secondary 2019 ETH mention of 0d434. No personal receipt by Laura, customer account, custody mandate or subsequent exchange withdrawal is established.

Source: https://blockscan.com/Address/0x8894e0a0c962cb723c1976a4421c95949be2d4e3 . Label capture and failed label-search limits are retained separately.

## Reproduction and failed calls

Run `python onchain_pass7/busd_branches/trace_branches.py --offline` and `python onchain_pass7/busd_branches/trace_extension.py --offline` from the project root. Both offline replays passed. Exact requests, endpoint URLs, retrieval UTC, HTTP outcomes and SHA-256 are preserved in paired receipt/response files. Historical reads use the public keyless Blockmachine BSC RPC; transaction receipts and headers use the official BNB RPC.

One extension log batch received HTTP 429 after 13 successful batches. Its failed request receipt is retained as `extension_logs_26_failed429.receipt.json`. The error body was not captured by that initial helper version; the recorded failure is urllib's HTTP 429. A subsequent bounded retry completed with eight-second spacing per fresh Blockmachine request. No previous-pass evidence is modified. Full raw responses contain 13 unique event receipts across the two windows; these include previously known upstream transfers and one zero-value event. They must not be counted as 13 newly discovered funded payments.
'''
(P/'MEMO.md').write_text(text)
files=sorted(f for f in P.rglob('*') if f.is_file() and f.name!='SHA256SUMS.txt' and '__pycache__' not in f.parts)
(P/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(P))+'\n' for f in files))
print('Wrote memo, summary and hashes:',len(files),'files')
