from trace_branches import *

def main():
 start_time=int(datetime.datetime.fromisoformat('2022-11-03T09:02:17+00:00').timestamp());cutoff=start_time+7*86400
 lo=START+180000;hi=START+210000
 data=rpc('extension_boundary_initial',[q(h,'eth_getBlockByNumber',[hex(h),False]) for h in [lo,hi]],BNB)
 assert int(data[lo]['timestamp'],16)<=cutoff<int(data[hi]['timestamp'],16)
 for step in range(20):
  if hi-lo==1:break
  mid=(lo+hi)//2;header=rpc('extension_boundary_%02d'%step,[q(mid,'eth_getBlockByNumber',[hex(mid),False])],BNB)[mid]
  if int(header['timestamp'],16)<=cutoff:lo=mid
  else:hi=mid
 assert hi-lo==1
 bounds={'rationale':'Two first-day recipients retained the received BUSD at the first cutoff; extend these two only through seven days from the original first withdrawal. No expansion of drained recipients or service wallets.','start':END+1,'last':lo,'excluded_next':hi,'cutoff_utc':datetime.datetime.fromtimestamp(cutoff,datetime.timezone.utc).isoformat()}
 (P/'extension_bounds.json').write_text(json.dumps(bounds,indent=2))
 run(TARGETS=[TARGETS[1],TARGETS[4]],START=END+1,END=lo,prefix='extension',result_name='verified_extension')
if __name__=='__main__':main()
