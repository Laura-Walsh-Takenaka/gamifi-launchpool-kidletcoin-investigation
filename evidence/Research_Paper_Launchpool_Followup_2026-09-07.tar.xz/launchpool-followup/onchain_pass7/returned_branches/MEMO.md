# Pass 7: the 47da route reaches Kraken; d541 held a mixed balance

Research date: 7 September 2026. All event times are UTC. Ethereum canonical USDC is `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48`; canonical USDT is `0xdac17f958d2ee523a2206206994597c13d831ec7`. Both use six decimals. Previous passes remain unchanged.

**The previously unlabeled 47da branch has a newly verified route to Kraken. The exchange hot wallets themselves initiated the final collection transactions.** This is a route from a mixed intermediary balance: it does not uniquely attribute the original 32,500-USDC or 8,720.1948-USDT receipt to that exchange.

## 1. Exact route and exchange-initiated collection

| Event on 18 July 2024 | Amount | UTC time | Transaction |
|---|---:|---|---|
| 2c94 to 47da, previously identified incoming leg | 32,500 USDC | 11:38:47 | `0x260905ba6e94a3bb12709f8ed4d7627ae32966ea0fe417747476180ef039ce48` |
| 2c94 to 47da, separate incoming leg | 8,720.1948 USDT | 11:41:35 | `0x757541bf62697df91c25de3fd7e6664fc71f1bc51d7710ead771788d162bbca1` |
| 47da to dcea | 300,000 USDT | 18:59:47 | `0xaeeaaf2ef1a1931d7b91b4c32c56e1f01dc2f9d884da4b2b46950209bdd9bf2c` |
| 47da to dcea | 75,000 USDC | 19:00:11 | `0x137376b536b14e1bfd5842f236dbfc6baf051a36f02f5cc28d5f9357e6b0e814` |
| dcea to Kraken 10 | 75,000 USDC | 19:09:47 | `0x22f92adbff9514a6a0bd547a3c0bd91ffc3aa7585c9a98caf5ce840e77105d10` |
| dcea to Kraken 7 | 300,000 USDT | 19:09:47 | `0x84c77b71bb9f4a63961a49dcee7b188aba0f84060a4c1a67ec0d66db4a495f95` |

Full addresses:

- 2c94: `0x2c94c30bdd9aa400df9d2347ee16094ab1858941`.
- 47da: `0x47da741e9fada9aff75c0f2df69e9cd2b216b225`.
- dcea: `0xdcea03a2a2b8647ae787c4c518dbea1c54ac86d2`.
- Kraken 10: `0xae2d4617c862309a3d75a0ffb358c7a5009c673f`.
- Kraken 7: `0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40`.

Successful independent raw RPC receipts verify every amount and full address above. Independently captured transaction inputs show selector `0x23b872dd`, decoded as `transferFrom(dcea, hot_wallet, amount)`. For the USDC collection, **Kraken 10 is the transaction caller and token recipient**; for USDT, **Kraken 7 is caller and recipient**. Thus the final steps were authorized token allowance collections initiated by those labeled wallets, not transactions signed by dcea in that moment. The two collection delays are **9 minutes 36 seconds** for USDC and **10 minutes** for USDT.

Historical `eth_getCode` for dcea immediately before collection returns `0x`. Its full bounded USDC and USDT histories each contain exactly the incoming and outgoing transfer. Both assets independently reconcile historical archive balances from **zero to zero** across blocks 20,333,000–20,342,999. This makes dcea's forwarding exact for this interval. The observed behavior is consistent with an exchange collection address. The explorer itself does not give dcea a public name tag, and the customer behind the deposit remains unknown.

The direct Etherscan address pages label the endpoints [Kraken 10](https://etherscan.io/address/0xae2d4617c862309a3d75a0ffb358c7a5009c673f) and [Kraken 7](https://etherscan.io/address/0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40). `label_records.json` preserves the observed titles, retrieval UTC, source URLs and full HTML hashes. The full-address 47da, dcea and d541 pages have generic titles.

## 2. Historical state proves 47da was already heavily mixed

Immediately before the two selected incoming transfers, independently successful archive calls show:

| Asset | Balance before selected receipt | Selected receipt | Relevant historical block |
|---|---:|---:|---:|
| USDC | 136,210.313376 | 32,500 | 20,333,158 |
| USDT | 875,068.711065 | 8,720.1948 | 20,333,172 |

These pre-existing balances alone are large enough to support the later Kraken route. Therefore **no positive amount from either selected receipt is mathematically forced into that route**. The 75,000 and 300,000 figures are intermediary throughput, not new fundraising, a missing-funds calculation or a proven amount received by Laura.

The complete captured histories span **20,328,000–20,341,000**, from 17 July 18:20:47 to 19 July 13:52:47. This encompasses the full 24 hours after both selected receipts and includes surrounding context. USDC has **15** events and USDT **69**. All four intermediate 47da balance checkpoints agree with their respective ledgers, and the two opening and closing balances also reconcile:

| Asset | Historical opening | Incoming | Outgoing | Historical closing |
|---|---:|---:|---:|---:|
| USDC | 137,539.222295 | 35,508.474931 | 94,000 | 79,047.697226 |
| USDT | 843,217.249624 | 107,690.093833 | 315,293.175261 | 635,614.168196 |

Within the first 24 hours after the selected receipts, the other USDC payments were **11,000 to `0x8d34cc4d0f2eabd1550637671a1a6f58ebc6a1b0`** at 15:02:35 and **4,000 to `0xfafc16df6d6a41ddb0977ccb8dd62b97ac152268`** at 15:19:47 on July 18. Other USDT payments were **1,607.259205 to `0x2fcd86dceff2523183bd91a6644faf2b3906c2e5`**, **1,406.672275 to `0xa9abe5abf8cbc1e45eacb1cf441d7db43499cdaf`**, and **4,428.73888 to `0x37146d5ec2431ce812b9850c31093b96c0f8c7b5`**. All have matching successful raw receipts. Their onward destinations are outside this bounded pass.

## 3. The 318,192.18-USDC recipient did not immediately forward it

The full initial d541 history spans **20,372,000–20,385,000**, from 23 July 21:43:47 to 25 July 17:17:11. It contains four canonical USDC events. The opening archive balance was **85,994.23 USDC**; total receipts of **608,190.753239** and the earlier **147,900** outgoing payment reconcile to **546,284.983239 USDC** at the end.

The selected **318,192.18-USDC** receipt from 0008 arrived at **15:36:59 on July 24**, transaction `0xe296fbf6e820cc64e514d2870c215da4d88de06695497723a72b4f08e6b6ddb8`. d541 already held **228,092.803239 USDC** immediately before that receipt. There were **no canonical USDC transfers out during the next 24 hours**.

A separate exhaustive outgoing-only scan from 20,385,001 through **20,428,000 (31 July 17:23:35)** found just one subsequent canonical USDC payment: **21,664 USDC** at **06:47:35 on July 30**, to `0x0585b2d1df27523712561163f73210096202ad52`, transaction `0x99e13b72626a5296c1b9c6ff709b9e806a10caa0883c35761c8d9333a81215ce`. Its raw receipt is successful. The earlier balance exceeds this payment; unique attribution to the July 24 receipt is unavailable. The week extension is explicitly outgoing-only; a full-week incoming ledger or end balance is not claimed.

## 4. Verification, failures and scope

`verify_branches.py` runs offline, reconstructing **five ledgers with 92 events**, **15 successful historical balance calls**, and **13 selected successful raw receipts**. It compares exact token addresses, decimals, amounts, recipients, duplicate keys, intermediate balances, end balances, collection calldata and capture hashes. Initial run: **531 passing checks**. Run `python verify_branches.py --check` for reproduction; the check count differs when non-distributable HTML intermediates are omitted, while numerical results must remain identical.

Blockscout supplied the indexed canonical-token rows. Two responses and their single later retries returned HTTP 429. Those gaps were repaired using public Blockmachine `eth_getLogs`: d541's missing extension returned empty incoming and outgoing arrays; dcea's USDT history returned its two exact events. A first dcea log query exceeded the endpoint's inclusive 10,000-block cap by one; the preserved error was corrected to a 10,000-block interval. A last d541 range hit the public per-minute limit, recorded a 9-second Retry-After and succeeded on a later single retry. Two initial dRPC receipt batches exceeded its three-request free-plan batch cap; regrouped batches respecting that cap succeeded. No failed response was interpreted as absent activity.

Every network operation has its exact request, contemporaneous UTC receipt and response hash. Canonical-token filtering prevents similarly named assets from entering the cash ledger. No blockchain write, signature, wallet connection, private account access or third-party contact occurred. No customer identity, legal entitlement, payment purpose or personal receipt by Laura is established. This pass supplies two exact Kraken collection identifiers and clarifies that the d541 branch remained a mixed balance over the first day.
