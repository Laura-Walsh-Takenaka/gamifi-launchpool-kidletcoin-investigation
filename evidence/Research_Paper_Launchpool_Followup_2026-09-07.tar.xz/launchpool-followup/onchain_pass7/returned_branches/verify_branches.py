#!/usr/bin/env python3
"""Offline verification of canonical token histories, archive balances and receipts."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime, timezone
import hashlib, json, sys
P=Path(__file__).resolve().parent
U='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
T='0xdac17f958d2ee523a2206206994597c13d831ec7'
A='0x47da741e9fada9aff75c0f2df69e9cd2b216b225'
D='0xdcea03a2a2b8647ae787c4c518dbea1c54ac86d2'
B='0xd5417e96dd04363c675e41ee6f30bf788412c719'
TOPIC='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
checks=0
def check(v,msg):
 global checks
 assert v,msg
 checks+=1
def read(n): return json.loads((P/n).read_text())
def amt(v): return format(Decimal(v)/10**6,'f')
def utc(v): return datetime.fromtimestamp(v,timezone.utc).isoformat()
def rpc(n):
 data=read(n)
 for r in data:check('result' in r and 'error' not in r,n+' RPC success')
 check(len({x['id'] for x in data})==len(data),n+' unique IDs')
 return {x['id']:x['result'] for x in data}
def indexed(n,address,token,lo,hi):
 data=read(n);check(data['status']=='1',n+' status')
 rows=data['result'];check(isinstance(rows,list) and len(rows)<10000,n+' below page cap')
 for r in rows:
  check(r['contractAddress']==token,n+' canonical token')
  check(address in [r['from'],r['to']],n+' exact wallet')
  check(r['tokenDecimal']=='6' and lo<=int(r['blockNumber'])<=hi,n+' range/decimals')
 return rows
def normalized(z,token):
 check(z['address']==token and z['topics'][0]==TOPIC and not z['removed'],'canonical log')
 return {'from':'0x'+z['topics'][1][-40:],'to':'0x'+z['topics'][2][-40:],'hash':z['transactionHash'],'contractAddress':token,'blockNumber':str(int(z['blockNumber'],16)),'transactionIndex':str(int(z['transactionIndex'],16)),'value':str(int(z['data'],16)),'timeStamp':str(int(z['blockTimestamp'],16)),'tokenDecimal':'6'}
states={}
for n in ['state_0.json','state_1.json','state_2.json']:states.update(rpc(n))
spec=read('state_specs.json')
balances={(a,t,n):int(states[i],16) for i,(a,t,n) in enumerate(spec)}
dst=rpc('dcea_state.json')
for i,(t,n) in enumerate([(t,n) for t in [U,T] for n in [20332999,20342999]]):balances[(D,t,n)]=int(dst[i],16)
histories={
 '47da_USDC':(A,U,20328000,20341000,indexed('47da_USDC_24h.json',A,U,20328000,20336000)+indexed('47da_USDC_extend.json',A,U,20336001,20341000)),
 '47da_USDT':(A,T,20328000,20341000,indexed('47da_USDT_24h.json',A,T,20328000,20336000)+indexed('47da_USDT_extend.json',A,T,20336001,20341000)),
 'd541_USDC':(B,U,20372000,20385000,indexed('d541_USDC_24h.json',B,U,20372000,20380000)),
 'dcea_USDC':(D,U,20333000,20342999,indexed('dcea_USDC.json',D,U,20333000,20343000)),
}
# Failed API extension was repaired with exact incoming/outgoing RPC log queries.
fb=read('fallback_logs.json')
for i in [0,1]:
 r=next(x for x in fb if x['id']==i)
 check(r.get('result')==[],'d541 extension: no canonical incoming/outgoing logs')
dr=rpc('dcea_USDT_logs.json');dl=[normalized(z,T) for v in dr.values() for z in v]
histories['dcea_USDT']=(D,T,20333000,20342999,dl)
summary={'generated_utc':datetime.now(timezone.utc).isoformat(),'chain':'Ethereum mainnet','histories':{},'selected_transfers':[],'limits':[]}
ledgers={}
for key,(a,t,lo,hi,rows) in histories.items():
 rows=sorted(rows,key=lambda r:(int(r['blockNumber']),int(r['transactionIndex']),r['hash']))
 sig=[(r['hash'],r['from'],r['to'],r['value'],r['contractAddress']) for r in rows]
 check(len(sig)==len(set(sig)),key+' no duplicate transfers')
 start=bal=balances[(a,t,lo-1)];ins=outs=0;ledger=[]
 for r in rows:
  value=int(r['value']);before=bal
  if r['to']==a:bal+=value;ins+=value
  if r['from']==a:bal-=value;outs+=value
  check(bal>=0,key+' nonnegative balance')
  ledger.append({**r,'balance_before_raw':str(before),'balance_after_raw':str(bal)})
 check(bal==balances[(a,t,hi)],key+' end archive balance agrees')
 for (aa,tt,bn),target in balances.items():
  if aa==a and tt==t and lo<=bn<=hi:
   candidates=[r for r in ledger if int(r['blockNumber'])<=bn]
   observed=int(candidates[-1]['balance_after_raw']) if candidates else start
   check(observed==target,key+' intermediate state '+str(bn))
 summary['histories'][key]={'address':a,'token':t,'start_block':lo,'end_block':hi,'event_count':len(rows),'opening':amt(start),'incoming':amt(ins),'outgoing':amt(outs),'closing':amt(bal),'historical_state_reconciliation':'PASS'}
 ledgers[key]=ledger
receipts={}
for n in ['receipts_corrected_0.json','receipts_corrected_3.json','receipts_corrected_6.json','receipts_2.json','extra_receipts.json']:
 for x in rpc(n).values():
  check(isinstance(x,dict) and x.get('status')=='0x1',n+' successful receipt')
  receipts[x['transactionHash']]=x
selected=read('selected_events.json')
for e in selected:
 r=receipts[e['hash']]
 check(int(r['blockNumber'],16)==int(e['blockNumber']),'receipt block')
 hits=[z for z in r['logs'] if z['address']==e['contractAddress'] and z['topics'][0]==TOPIC and '0x'+z['topics'][1][-40:]==e['from'] and '0x'+z['topics'][2][-40:]==e['to'] and int(z['data'],16)==int(e['value'])]
 check(len(hits)==1,'exact canonical selected transfer match')
 summary['selected_transfers'].append({'hash':e['hash'],'token':e['token'],'from':e['from'],'to':e['to'],'amount':amt(int(e['value'])),'utc':utc(int(e['timeStamp'])),'block':int(e['blockNumber']),'transaction_caller':r['from'],'receipt_status':'success','log_index':int(hits[0]['logIndex'],16)})
calls=rpc('kraken_calls_and_scope.json')
for i in [0,1]:
 tx=calls[i];e=next(x for x in selected if x['hash']==tx['hash']);s=tx['input']
 check(s[:10]=='0x23b872dd' and len(s)==202,'transferFrom selector/length')
 check('0x'+s[34:74]==D and '0x'+s[98:138]==e['to'] and int(s[138:202],16)==int(e['value']),'transferFrom exact arguments')
 check(tx['from']==e['to'] and tx['to']==e['contractAddress'],'hot wallet initiated collection into itself')
check(calls[2]=='0x','dcea historical code absent')
summary['kraken_collection']={'USDC':{'amount':'75000','recipient':'0xae2d4617c862309a3d75a0ffb358c7a5009c673f','label':'Kraken 10','delay_seconds':576},'USDT':{'amount':'300000','recipient':'0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40','label':'Kraken 7','delay_seconds':600},'mechanism':'Each labeled hot wallet called transferFrom(dcea, itself, exact amount); both dcea token cycles reconcile archive zero to zero.'}
week=[]
for n in ['d541_out_week_0.json','d541_out_week_retry.json']:
 req=read(n+'.request.json')['jsonrpc_body'];result=rpc(n)
 for q in req:
  params=q['params'][0];check(int(params['toBlock'],16)-int(params['fromBlock'],16)<10000,'RPC range respects inclusive cap')
  for z in result[q['id']]:week.append(normalized(z,U))
check(len(week)==1 and week[0]['hash']==selected[-1]['hash'],'one canonical d541 outgoing after initial window')
incoming_d541=next(e for e in selected if e['to']==B)
check(not [r for r in histories['d541_USDC'][4] if r['from']==B and int(r['timeStamp'])>=int(incoming_d541['timeStamp'])],'d541 initial post-receipt outgoing empty')
check(int(week[0]['timeStamp'])>int(incoming_d541['timeStamp'])+86400,'first extended outgoing after24h')
summary['d541_week']={'end_block':20428000,'end_utc':utc(int(calls[3]['timestamp'],16)),'extended_query':'outgoing canonical USDC only','outgoing_count':1,'outgoing_total':'21664','first_outgoing':summary['selected_transfers'][-1],'no_24h_outgoing':True,'attribution':'Existing USDC before the July24 receipt exceeded this later payment; its funding source is not uniquely determined.'}
summary['limits']=['47da held 136210.313376 USDC and 875068.711065 USDT before the selected incoming transfers; no positive amount from those selected inflows is forced into the Kraken branch.','The 75000-USDC and 300000-USDT sweeps are intermediary throughput, not additional fundraising or a missing-funds total.','The d541 week extension covers outgoing USDC only. Its initial full bounded history and archive balances independently reconcile; no full-week incoming ledger is claimed.','Explorer labels identify service wallets, not a customer or Laura. The untagged dcea address is an EOA with token allowances used by named Kraken hot wallets, consistent with exchange collection mechanics.']
for f in P.glob('*.receipt.json'):
 r=read(f.name)
 if r.get('status')==200 and (P/r['response_file']).exists():
  raw=(P/r['response_file']).read_bytes();check(hashlib.sha256(raw).hexdigest()==r['sha256'],f.name+' capture hash')
summary['offline_checks_passed']=checks
for name,data in [('summary.json',summary),('event_ledgers.json',ledgers)]:
 if '--check' in sys.argv:
  old=read(name)
  if name=='summary.json':old.pop('generated_utc',None);data.pop('generated_utc',None);old.pop('offline_checks_passed',None);data.pop('offline_checks_passed',None)
  check(old==data,name+' reproduction')
 else:(P/name).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':checks,'selected_successful_receipts':len(selected),'historical_state_calls':len(balances),'ledger_event_counts':{k:len(v) for k,v in ledgers.items()}},indent=2))
