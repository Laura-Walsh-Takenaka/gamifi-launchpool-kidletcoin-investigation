from pathlib import Path
import json,urllib.request,datetime,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
rows=json.loads((R/'onchain_pass6/source_bounds/source_bounds.json').read_text())['source_rows']['other_inflows']
q=[{'jsonrpc':'2.0','id':r['hash'],'method':'eth_getTransactionReceipt','params':[r['hash']]} for r in rows]
u='https://ethereum-rpc.publicnode.com';m={'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':q}
try:
 with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(q).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=35) as resp:
  b=resp.read();(P/'outside_inputs.response.json').write_bytes(b);m.update(status=resp.status,sha256=hashlib.sha256(b).hexdigest())
 data={x['id']:x.get('result') for x in json.loads(b)};verified=[]
 for row in rows:
  rec=data[row['hash']];assert rec and rec['status']=='0x1'
  matches=[l for l in rec['logs'] if l['address'].lower()==row['contractAddress'] and len(l['topics'])==3 and l['topics'][0]=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef' and '0x'+l['topics'][1][-40:]==row['from'] and '0x'+l['topics'][2][-40:]==row['to'] and int(l['data'],16)==int(row['value'])]
  assert len(matches)==1 and int(rec['blockNumber'],16)==int(row['blockNumber'])
  verified.append({'tx':row['hash'],'from':row['from'],'to':row['to'],'raw_value':row['value'],'usdc':'10','receipt_status':1,'log':matches[0]})
 (P/'outside_inputs_verified.json').write_text(json.dumps({'rows':verified,'total_USDC':'20','conclusion':'Both outside receipts in the previous source interval are real canonical USDC transfers. No attribution of the lookalike senders is made.'},indent=2));print('PASS: both10-USDC outside receipts verified from raw successful receipts')
except Exception as e:m['error']=repr(e);print('FAILED',repr(e))
finally:(P/'outside_inputs.request_receipt.json').write_text(json.dumps(m,indent=2))
