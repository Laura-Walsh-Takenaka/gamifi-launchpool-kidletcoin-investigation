# Additional acquisition checks

A documented free Ethereum Standard endpoint at rpc-eth.blockmachine.io was tested with eth_chainId and three historical USDC balanceOf calls. This request returned HTTP 403 and supplies no state evidence. The exact request, block jobs and failure are retained. No credentials, wallet interaction or repeated attempt against that denied request was used.

The two previously indexed 10- USDC outside inputs were separately checked with public transaction-receipt requests. Publicnode returned null for both. An independent public dRPC lookup returned successful receipts for both; onchain_pass7/iag_allocation/reconcile.py verifies the canonical token, exact Transfer topics, sender, recipient, amount and block. The20- USDC outside contribution remains in the conservation bounds and the senders remain unattributed.
