from pathlib import Path
import json,urllib.request,datetime,hashlib
P=Path(__file__).resolve().parent;R=P.parents[1]
u='https://rpc-eth.blockmachine.io';usdc='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
b=json.loads((R/'onchain_pass6/source_bounds/source_bounds.json').read_text())
for k,v in b['source_rows'].items():print(k,[(x.get('blockNumber'),x.get('value'),x.get('from'),x.get('to')) for x in v])
rows=b['source_rows'];jobs=[]
for address in ['0x77bfe8d704b1948374bf8dab8328a810b2836e66','0x1991e27e2908847c0274a662eb6675002e8386d0','0x183600361dc42c6f022fd219c3a9dabbf08c9ce4']:
 relevant=[r for group in rows.values() for r in group if r.get('to','').lower()==address]
 h=min(int(r['blockNumber']) for r in relevant)-1
 jobs.append({'address':address,'block':h,'expected_balance_raw':'0'})
q=[{'jsonrpc':'2.0','id':0,'method':'eth_chainId','params':[]}]+[{'jsonrpc':'2.0','id':i+1,'method':'eth_call','params':[{'to':usdc,'data':'0x70a08231'+j['address'][2:].zfill(64)},hex(j['block'])]} for i,j in enumerate(jobs)]
meta={'endpoint':u,'request':q,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'provider_documentation':'https://blockmachine.io/docs/ethereum-rpc'}
try:
 with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(q).encode(),headers={'Content-Type':'application/json'}),timeout=40) as resp:
  data=resp.read();(P/'initial.response.json').write_bytes(data);meta.update(status=resp.status,sha256=hashlib.sha256(data).hexdigest());print(data.decode())
except Exception as e:meta['error']=str(e);print(type(e).__name__,e)
finally:(P/'initial.request_receipt.json').write_text(json.dumps(meta,indent=2));(P/'jobs.json').write_text(json.dumps(jobs,indent=2))
