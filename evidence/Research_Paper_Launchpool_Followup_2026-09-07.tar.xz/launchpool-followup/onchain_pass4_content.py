"""Fourth bounded pass: additional ML custody and verified settlement routes."""
def add_pass4(B):
    def p(t,k='p'):B.append({'kind':k,'text':t})
    def h(t):p(t,'h')
    def h2(t):p(t,'h2')
    def page():B.append({'kind':'break'})
    def table(rows,widths):B.append({'kind':'table','rows':rows,'widths':widths})

    page();h('9.15 A second ML reserve and its withdrawal authority')
    p('<b>An additional 2,418,075.7303282383408825 ML remains in an earlier Raise 1 claim contract.</b> A census of all 24 unique Ethereum tranche addresses in the recovered public configuration found this one nonzero balance; the other 23 hold zero ML. The publisher maps this contract to Raise 1, tranche 11, dated 16 July 2024 and displayed as 6%. [F39]')
    p('Raise 1 reserve: <font face="DVM" size="7.4">0x9298136ec995aefb1e99fd4087080d3df328162f</font><br/>Common state block: 25,923,764 | 7 September 2026, 06:43:59 UTC','small')
    table([
        ['Complete token-flow reconciliation','Exact ML'],
        ['16 July 2024: one funding from 0x77bf...6e66','2,886,449.7276626812265525'],
        ['1,000 outgoing payments to 1,000 recipients','-468,373.99733444288567'],
        ['Reconciled remaining balance / RPC balance','2,418,075.7303282383408825'],
        ['Transfers from this contract to its owner','0'],
    ],[277,222])
    p('All 1,001 ML events across eleven explorer pages reconcile exactly. The last payout was 16 January 2026. The explorer labels all outgoing payments Claim; 105 successful normal claim calls were separately matched. All 1,000 inputs and proofs were not audited. The verified reserve is a custody balance, not a proved remaining liability or loss total. [F39]')
    h2('The upstream owner can already withdraw this reserve')
    p('Owner is 0x77bf...6e66, claiming is unpaused, and withdrawal duration is zero. The runtime matches the reviewed 4d7b contract after changing only its two embedded Merkle roots. Owner and nonowner read-only simulations confirm the withdrawal restriction. The stored threshold is its July 2024 creation time; no November 2026 wait applies. No withdrawal was sent in this research. [F35; F39]')
    h2('The final Raise 2 reserve remains separately backed')
    table([
        ['Final distributor at the same block','Result'],
        ['ML held by 0xcc3285...970c4','1,116,041.281767546177360307'],
        ['Unclaimed ledger: 1,880 allocations','1,116,040.8456174469614254 ML'],
        ['Owner and immutable treasury','0x6c2b...929c4; unchanged'],
    ],[277,222])
    p('Its root and all eight claimed-bitmap words still match the 1,999-record ledger, with 119 claimed indices. The older Raise 1 reserve must not be added as a second copy of those obligations. Fourteen configured earlier addresses currently have no code; that does not establish their historical use or why code is absent. [F39]','small')
    p('<b>Delivery gap:</b> the listed Raise 1 proof endpoint, claims.launchpool.xyz/mintlayer1-11/, returned HTTP 502. Its complete remaining allocation file and reconciliation with earlier tranches remain unrecovered. Unpaused code and a stored unlocked app flag do not establish that holders can currently obtain their proofs. No human signer or automatic payment to Laura is identified. [F39]','small')

    page();h('9.16 Actual BSC withdrawals and a ChangeNOW route')
    p('<b>D975\'s actual bytecode now establishes who can call its fundraising withdrawal and where it directs payment.</b> The caller must equal owner(); the selected pool\'s recorded raised amount is used in a token transfer call to the owner at execution time. Fresh simulations and an independent offline interpreter agree. This closes the selected mechanics gap without importing the different Ethereum contract\'s source. [F40]')
    p('At BSC block 120,448,587, 7 September 2026 06:44:32 UTC, owner remains 0x77bf...6e66. Historical owner reads for the original Mintlayer periods failed. Full source equivalence remains unverified, and claimed flags alone are not historical token-transfer receipts. [F40]','small')
    h2('Eighteen historical withdrawals independently verified')
    table([
        ['Project / pools','UTC withdrawal date','BUSD received by 77bf'],
        ['Championfy / 68-70','11 January 2023','452,941.643436827790107713'],
        ['Spark World / 134-136','30 March 2023','80,117.358323940697139962'],
        ['Yesports / 80-82','13 April 2023','396,930.330400262063764776'],
        ['5ire / 56-58','20 April 2023','454,964.151441835747044046'],
        ['Hinata / 39-41','25 April 2023','472,707.89103104557463491'],
        ['Circularr / 146-148','3 July 2024','60,526.6449367719358245'],
        ['Selected total: 18 calls','','1,918,188.019570683808515907'],
    ],[141,121,237])
    p('Each successful call, pool event and actual BUSD Transfer receipt agrees on the pool, amount and recipient. Public project records match both D975 and BSC. These are six other projects; the original Mintlayer pools 19-21 and 125-127 remain outside the recovered withdrawal history. Indexer rounding was replaced with exact RPC event integers. [F41]')
    h2('Circularr receipts connect to the ML treasury gas funder')
    p('Two minutes 21 seconds after the last Circularr withdrawal on 3 July 2024, 77bf sent <b>60,000 BUSD</b> to 0x1aafe...8da0f, the address that later funded the ML treasury\'s gas. The next day, 1aafe split it into 100 and 59,900 BUSD. Two intermediaries forwarded those exact amounts to a common destination within 117 and 104 seconds respectively. All four onward transfers have matching successful RPC receipts. [F21; F41]')
    p('Destination: <font face="DVM" size="7.3">0xa96be652a08d9905f15b7fbe2255708709becd09</font><br/>BSC-specific OKLink label: ChangeNOW. Withdraw_1; Blockscan/Etherscan label: ChangeNOW: Hot Wallet 2. [F41]','small')
    p('The service-associated destination is established as an explorer attribution. The exchange order, customer, output asset and payout remain unknown. The source wallet can mix funds; the sequence does not identify an undocumented settlement purpose or Laura as beneficiary. A separate Hinata onward transfer of 472,707.8910310446569656 BUSD is verified in the evidence. [F41]','small')

    page();h('9.17 The shared wallet reaches Gate, MEXC and KuCoin')
    p('<b>The common gas/ML counterparty is now traced to concrete exchange routes.</b> Address <font face="DVM" size="7.2">0x183600361dc42c6f022fd219c3a9dabbf08c9ce4</font> received ML from the earlier operational wallets and 525,000 ML in direct vesting releases. Its recovered exact-token histories contain 67 ML and 322 USDC events, with each event ledger netting to zero. These are historical flow totals, not investor liability calculations. [F42]')
    h2('ML forwarding is reconciled through an intermediary')
    p('Intermediary: <font face="DVM" size="7.3">0x980bff583a8133600462bc034871dc548d6bfc84</font>','small')
    table([
        ['ML route','Exact ML'],
        ['183600 to 980b: 20 transfers','1,234,268.124'],
        ['Original vesting beneficiary 3b883 to 980b','21,890.76'],
        ['Combined incoming ML','1,256,158.884'],
        ['980b to explorer-labeled MEXC 1: 16 transfers','1,069,905.362'],
        ['980b to explorer-labeled MEXC 3: 4 transfers','186,253.522'],
    ],[305,194])
    p('The complete 202-row token history contains 41 ML events. All incoming ML is accounted for by the two exchange-facing destinations. The evidence is the actual onward transfer record; 980b\'s separate initial-gas-funder label is not used to infer its operator. Representative successful RPC receipts corroborate both MEXC destinations. [F42]')
    p('A separate <b>118,172 ML</b> route passes from dd923 through 183600 to an explorer-labeled Gate deposit address, then to a Gate-labeled wallet. Deposit/account mapping remains an exchange-record question. The route does not establish an executed sale or its proceeds. [F42]')
    h2('Both connected wallets used the same KuCoin deposit')
    p('Between July 2022 and March 2023, 183600 sent <b>693,701.8471 USDC in ten payments</b> to 0x4d0d...a7ee, the same KuCoin-labeled deposit address that received 80,750 USDC from 1991 in July 2024. A representative 404,740.72 USDC payment has a successful raw RPC receipt. This establishes reuse of a precise exchange deposit destination across the two wallets; it does not identify the credited customer. [F38; F42]')
    p('KuCoin deposit: <font face="DVM" size="7.3">0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee</font>','small')
    h2('Interpretation and remaining records')
    p('These flows connect vesting beneficiaries, an administrative wallet and exchange-facing accounts. They do not show that the still-held Raise 1 or final Raise 2 reserves were withdrawn, or that every token came from a particular investor allocation. Account mandates, exchange customers and actual trade statements remain missing. The following page separately tracks the July 2024 USDC branch through Base. [F39; F42]')

    page();h('9.18 Base bridge, BAMBOO trades and returned funds')
    p('<b>The July USDC branch continues through actual cross-chain transfers and token trading.</b> After receiving 2,100 and 25,000 USDC from 1991, wallet 183600 used Circle CCTP V1 to transfer those amounts from Ethereum to itself on Base. The two destination mints match the source messages, recipient, amounts and nonces 81239 and 81473. [F42-F43]')
    p('Wallet on both chains: <font face="DVM" size="7.3">0x183600361dc42c6f022fd219c3a9dabbf08c9ce4</font><br/>BAMBOO token on Base: <font face="DVM" size="7.3">0x689644b86075ed61c647596862c7403e1c474dbf</font>','small')
    table([
        ['Verified Base movement','Amount / result'],
        ['10-11 July 2024: two bridge mints','27,100 USDC received in total'],
        ['Eight BAMBOO purchases','20,100 USDC spent; 3,911,181.851848323949800498 BAMBOO acquired'],
        ['14 July: first two BAMBOO sales','2,000,000 BAMBOO sold for 14,116.998523 USDC'],
        ['18 July: first return to Ethereum','21,116.99 USDC; matching Circle message nonce 235711'],
        ['Inventory immediately after that return','0.008523 USDC plus 1,911,181.851848323949800498 BAMBOO'],
        ['All fourteen BAMBOO sales, through 23 July','73,854.395784 USDC received'],
        ['Sales less purchases, before native gas','+53,754.395784 USDC'],
    ],[242,257])
    p('All 22 buy/sell transactions have successful Base RPC receipts. Their 66 relevant token-transfer logs match the explorer records. Historical balance reads show zero USDC and zero BAMBOO immediately before the first bridge mint. Circle\'s official contract/domain records identify Ethereum as domain 0 and Base as domain 6; exact messages and attestation inputs match the retained transactions. [F43]')
    h2('Returns and remaining inventory')
    p('The 21,116.99 USDC returned to Ethereum on 18 July was then sent back to 1991. The wallet still held 1,911,181.851848323949800498 BAMBOO on Base after that return. Subsequent sales through 23 July produce the positive USDC trading cash difference above. Native ETH gas and fiat valuation are excluded; no investor or personal profit entitlement is inferred. [F42-F43]')
    p('The complete indexed Base token history contains 505 rows. The later snapshot records 0.003937 USDC and one base unit of BAMBOO (0.000000000000000001 token) at block 50,987,229, 7 September 2026 06:50:05 UTC. Later transactions therefore need to be considered separately from the 18 July inventory and first return. [F43]','small')
    h2('What the trail proves, and the remaining attribution gap')
    p('This identifies bridge destinations, actual purchases/sales and a documented return to a connected wallet. The earlier Ethereum source wallet mixed USDC, so the Base trading cannot be assigned exclusively to the IAG fundraising receipt. It is separate from original Mintlayer BUSD purchases and the ML reserves still held in claim contracts. The human trader, company authorization and ultimate allocation of returns remain unestablished. [F39; F41-F43]')

    return [
        ('F39','24-tranche census and the additional Raise 1 reserve','https://etherscan.io/address/0x9298136ec995aefb1e99fd4087080d3df328162f','onchain_pass4/tranche_census/ and peer_review/: common block 25,923,764 at 06:43:59 UTC; complete 1,001-event token ledger, partial normal-call census, exact runtime comparison and owner simulations. Final Raise 2 root/bitmap/backing rechecked at the same block. Full Raise 1 liability/proof file unrecovered.'),
        ('F40','D975 selected withdrawal path','https://bsc-dataseed.bnbchain.org','onchain_pass4/bsc_runtime/ and peer_review/: actual bytecode, slot mapping, live read-only simulations and independent offline interpreter. Current owner receives intended transfer; historical owner queries failed. Returned ERC-20 bool is discarded; this is not evidence of an actual false-return BUSD transfer.'),
        ('F41','Actual BSC settlements and ChangeNOW-associated destination','https://www.oklink.com/zh-hans/bsc/address/0xa96be652a08d9905f15b7fbe2255708709becd09','onchain_pass4/bsc_settlements/ and bsc_project_mapping/: 18 exact withdrawal receipts, Circularr split/convergence and separate Hinata onward transfer. D975/BSC project mappings verified. OKLink supplies a BSC-specific ChangeNOW label; Blockscan and Etherscan corroborate service attribution. Customer/order/output unknown.'),
        ('F42','Shared counterparty ML and USDC exchange routes','https://etherscan.io/address/0x183600361dc42c6f022fd219c3a9dabbf08c9ce4','onchain_pass4/shared_counterparty/: exact-token histories, complete 980b intermediary ledger, Gate/MEXC/KuCoin label records and representative raw RPC receipts. Token custody, historical flow arithmetic and service labels are distinguished from customer identity, investor allocation and executed trade evidence.'),
        ('F43','Circle messages, Base receipts and BAMBOO inventory','https://developers.circle.com/cctp/v1/evm-smart-contracts','onchain_pass4/shared_counterparty/base_continuation/: official Circle message/attestation records, matching mint/burn inputs, 22 successful swap receipts with 66 matched transfer logs, complete 505-row token census and historical inventory reads. BAMBOO identified by its exact contract and token getters. Trading cash difference excludes native gas and does not identify a human or investor entitlement.'),
    ]
