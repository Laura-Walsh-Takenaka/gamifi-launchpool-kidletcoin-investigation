# Who can receive unclaimed Mintlayer allocations?

Research date: 7 September 2026. Scope: final Raise 2 distributor, its treasury/owner, its deployer, and two immediate ML funding sources. All retrieval was passive and public; no wallet connection, signature, or transaction.

## Direct answer

**The 1 November deadline does not automatically transfer the unclaimed ML to Laura or to an identified company.** The final distributor has no date-triggered sweep. Its owner already has a function that can transfer the entire remaining ML balance to a fixed treasury address. The human controller and legal beneficial owner of that address have not been established.

The relevant asset here is the remaining **ML token allocation**, not the original money participants paid. This contract does not contain a subscription-money refund or assign forfeited payments to Laura. Tracing investor payments requires the original collection wallets and payment/contract records, separately from the token-distribution ledger.

## Exact authority

Final distributor: `0xCc32853fb709666332cDe0fc47F3f74119B970c4` on Ethereum.

At previously pinned block 25,923,249 (7 September 2026, 05:00:23 UTC), both `owner()` and the immutable `treasury` are `0x6c2b3A90aCb72eF896325e19Af9098D157f929c4`. The verified implementation provides:

| Mechanism | Effect |
|---|---|
| `withdraw()` | Only the owner can invoke it. Sends all ML held by this distributor to the immutable treasury. |
| Calendar condition | Neither withdrawal nor claiming has a calendar condition. November 1 is not encoded here. |
| Destination | Fixed treasury address; transferring contract ownership does not change this destination. |
| Claim protection | A valid Merkle proof fixes the recipient and quantity. Each index can be claimed once. |
| Human/entity ownership | A treasury variable and a signing address do not identify a person or establish legal ownership. |

The earlier reconciliation established 1,880 unclaimed allocations totaling 1,116,040.8456174469614254 ML; distributor balance is 1,116,041.281767546177360307 ML. The balance covers those allocations with 0.436150099215934907 ML surplus. No later sweep of those remaining allocations was identified in the reconciled history. The owner withdrew only 1 ML during initial funding operations on 10 October 2025, before the bulk funding; a March 2026 nonowner attempt failed.

Mintlayer's current official notice sets 1 November 2026 as migration-tool closure. That is a separate platform policy and mechanism. A missed migration window is not an automatic transfer under this distributor. See `migration_support_memo.md` and the separate migration-contract examination for that mechanism.

## Wallet attribution and funding

Both the treasury and deployer are reported as noncontract accounts in retrieved Blockscout address records, without public name or ENS attribution. No source reviewed names Laura as either account's controller. The deployer transferred ownership to the treasury on 30 September 2025. No human identity is inferred from Laura's earlier executive role.

The treasury received its ML funding from two immediate sources:

| UTC time | Source | Exact ML | Transaction |
|---|---|---:|---|
| 2025-06-02 11:17:35 | `0x77BFe8d704B1948374bf8dab8328a810b2836e66` | 10 | `0x52af33bad07a0aa5b078c47d40c5333dcf5c7e3d2716215d7d2be7bc559ee061` |
| 2025-06-03 10:42:11 | Same address | 1,246,628.736235076904436035 | `0x8f2043cd852918d722fa4d46207b6fe8cc659013f4fc2528dd757a4342ec7d59` |
| 2025-08-26 15:12:11 | `0x9642b23Ed1E01Df1092B92641051881a322F5D4E`, Etherscan label **MEXC 16** | 48,011.999999999996854272 | `0xb49e67fb0823b34d8e4864b0a4c442bb27be4959ee28f280e7a10da5e6a3bc8d` |

These three inbound funding transfers total 1,294,650.736235076901290307 ML, exactly the two large October transfers into the final distributor. The initial 1 ML funding and return cancel separately. All seven ML events in the retrieved treasury history net to zero ML. This arithmetic describes retrieved transfers; it is not a new independently pinned treasury balance measurement.

The MEXC label identifies an exchange hot wallet, not the customer who requested the withdrawal. The August transfer supplies a precise exchange-account tracing target. The `0x77BFe8…` source is an unidentified noncontract account in the retrieved records. Its deeper transaction history was not obtained because the API rate-limited additional requests.

The treasury's initial ETH gas funding was 0.01 ETH from `0x1aafe5974189e5a854e20617be8176578868da0f` on 29 May 2025, transaction `0x71cfd39e902af8ec5a743064bcfef762dd48b7a1de1de84aabf8edf076e7799f`. This is an additional technical connection, not proof of common ownership or a named person.

## Earlier related deployment and added withdrawal power

The retrieved deployer history contains two direct contract creations:

| Deployment | Date UTC | Verified functionality |
|---|---|---|
| `0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b` | 24 July 2025, 20:11:59 | Merkle distributor with token/root/claim/isClaimed; no owner, treasury, or withdrawal function. |
| `0xcc32853fb709666332cde0fc47f3f74119b970c4` | 25 August 2025, 19:06:59 | Same ML token and identical Merkle root; adds ownership and an owner-only sweep to immutable treasury. |

Both were created by `0xb72fc236Ab043029776b9d25e99A5B6456A2e16D`. The earlier creation transaction is `0x38bb521feeb0391e824ad23356f97dbcecc395c29c54eb6e6c7c957b757b58bb`; final creation is `0x5ecdfe78d7bc887fe0611a18b00a98900c9e07bfccb9f2a914e7fd4f3c119c1a`.

The identical root is `0x031862a21347c8b43c3fd3e7d67615141f32476371b3a31e3447de2530d06aa7`. Both constructor records identify ML token `0x059956483753947536204e89bfaD909E1a434Cc6`.

This shows a concrete difference in technical authority. The evidence does not by itself establish why the later version was deployed, whether the earlier one was publicly used, or that funds were moved between them. The earlier contract's funding/claim history was not reconciled; do not add its repeated root as another independent set of 1,999 liabilities or claim it was a funded predecessor that was replaced.

## Evidence and limits

Principal source URLs, full request records and hashes are retained in `initial_requests.json`, `second_hop_requests.json`, `followup_requests.json`, and `pinned_requests.json`. `treasury_ml_lineage.csv` contains all seven exact ML transfer records. `lineage_summary.json` records the normalized findings. The full retrieved treasury histories contain six normal transactions and eight token events, of which seven concern ML. The retrieved deployer histories contain 154 normal transactions and 105 token events.

Primary explorer pages:

- https://etherscan.io/address/0x6c2b3a90acb72ef896325e19af9098d157f929c4
- https://etherscan.io/address/0xb72fc236ab043029776b9d25e99a5b6456a2e16d
- https://etherscan.io/address/0x77bfe8d704b1948374bf8dab8328a810b2836e66
- https://etherscan.io/address/0x9642b23ed1e01df1092b92641051881a322f5d4e
- https://etherscan.io/address/0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b
- https://etherscan.io/address/0xcc32853fb709666332cde0fc47f3f74119b970c4

The earlier verified source was extracted from the retained Etherscan HTML into `earlier_MerkleDistributor.sol`; Blockscout's source/history followups returned HTTP 429. Three new RPC attempts for the earlier contract and treasury code returned 403; they provide no balance/root/code evidence. Earlier-constructor equivalence rests on verified explorer source and creation input. The final distributor's pinned state comes from the already completed independent reconciliation in `claims/` and `claims_peer/`.

No account-holder information was obtained from MEXC, no contact requests were sent, and no legal beneficial ownership determination was made. The precise outstanding records are signing-key/custody mandates, treasury ownership documents, the identified MEXC withdrawal account/order mapping, the `0x77BFe8…` source records, and original investor payment/obligation records.
