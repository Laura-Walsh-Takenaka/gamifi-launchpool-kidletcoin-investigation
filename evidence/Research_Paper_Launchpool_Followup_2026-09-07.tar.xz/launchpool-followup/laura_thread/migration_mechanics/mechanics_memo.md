# Migration custody check — 7 September 2026

The official portal bundle targets Ethereum contract `0xe03aed8dfa6200292a2585918f656e2345ea283f`. Blockscout's verified source identifies it as TokenBurner. `burnTokens` transfers caller-approved ML into that contract and emits the amount and native-address string. Its name does not make this a supply-reducing ERC20 burn: the source calls `transferFrom`, not `_burn`.

The verified source contains no owner, withdrawal, calendar cutoff or native-chain payout. Successfully submitted tokens are held at this separate address with no withdrawal function in this source. Emitting the event alone does not prove that native ML reached the holder. The source also does not pull unsubmitted tokens out of the Launchpool distributor or holders' wallets.

This mechanism is separate from Launchpool's final distributor, which permits owner withdrawal to an immutable treasury. The November 1 deadline is Mintlayer's published migration-portal policy; the inspected contracts do not show an automatic November sweep to Laura or a named organization. Original BUSD subscriptions, unclaimed ML allocations, successfully submitted ERC20 tokens and native delivery are distinct accounting questions.

Source-code copies retain their original MIT SPDX notice. Application bodies and HTML are represented by hashes and bounded metadata in the delivered bundle. No wallet connection, transaction or native payment verification was undertaken.
