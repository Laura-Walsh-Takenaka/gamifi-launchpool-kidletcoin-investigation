# Independent distributor-control comparison

Checked 7 September 2026 against the preserved files only. Exact identifiers, assertions and source hashes are recorded in `control_peer_checks.json`.

**The common-deployer and added-withdrawal-authority finding passes. The earlier contract's funding/use history remains unverified, so operational replacement is not yet established.**

| Item | Earlier related deployment | Final-claim deployment |
|---|---|---|
| Contract | `0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b` | `0xcc32853fb709666332cde0fc47f3f74119b970c4` |
| Creation UTC | 24 July 2025, 20:11:59 | 25 August 2025, 19:06:59 |
| Creation block | 22,991,316 | 23,220,107 |
| Deployer | `0xb72fc236ab043029776b9d25e99a5b6456a2e16d` | Same address |
| Token/root | Same ML token and allocation root | Same ML token and allocation root |
| Owner powers | No owner/withdraw function in displayed source or ABI | Ownable; owner-only whole-balance withdrawal to immutable treasury |
| Calendar expiry / automatic sweep | Neither exists in displayed distributor source | Neither exists in displayed distributor source |

I independently extracted the earlier Solidity source from Etherscan's HTML `data-csource` attribute; it exactly matches the agent's extracted file. Etherscan labels it **Exact Match**. Its ABI exposes only `claim`, `isClaimed`, `merkleRoot` and `token`. The final source adds the Ownable import/inheritance, immutable treasury constructor parameter and `withdraw()` function. The bitmap, proof and claim-transfer code is identical after whitespace normalization.

The raw successful creation transactions independently decode to the same token `0x059956483753947536204e89bfad909e1a434cc6` and root `0x031862a21347c8b43c3fd3e7d67615141f32476371b3a31e3447de2530d06aa7`. This root is the one already validated against all 1,999 public claim proofs. The final constructor adds treasury `0x6c2b3a90acb72ef896325e19af9098d157f929c4`.

Creation transactions:

- Earlier: `0x38bb521feeb0391e824ad23356f97dbcecc395c29c54eb6e6c7c957b757b58bb`.
- Final: `0x5ecdfe78d7bc887fe0611a18b00a98900c9e07bfccb9f2a914e7fd4f3c119c1a`.

No successful pinned getter/balance query was obtained for the earlier contract: the new RPC attempts returned 403. Two attempts to retrieve its token history returned 429. Those responses supply no balance or claim-history result. Etherscan's preserved page describes zero transactions and a zero dollar balance; Blockscout metadata flags no logs, transfers or tokens. These are corroborating explorer observations, **not an independently reconciled proof that the earlier contract never received ML or paid a claim**. A dollar/native balance must not be substituted for an exact ML balance.

Recommended finding: **The same deployer created two contracts with the same published allocation commitment, and the later contract introduced discretionary owner withdrawal to a treasury.** Avoid stating that funds were moved from the earlier contract or that an operating contract was replaced until transfer history and promotion/retirement records establish that sequence. These are separate deployments with separate claimed-state storage; identical roots alone do not merge their claim histories.

Neither distributor source schedules a November 2026 transaction or an automatic treasury sweep. The final contract's owner must submit a transaction to invoke withdrawal; a website policy deadline is separate from the contract's checks. The added power does not identify the human who requested or authorized it, and this comparison supplies no Laura attribution.

This review compared explorer-displayed verified source and raw transaction inputs; it did not independently recompile and verify bytecode. The separate migration-contract source is assessed below.

## Separate migration contract: source-level check

The preserved Blockscout v2 response identifies **TokenBurner**, `0xe03aed8dfa6200292a2585918f656e2345ea283f`, as fully verified, with no proxy implementation recorded. Its ABI has only `burnTokens`, `isValidMintlayerAddress` and `token`.

A successful `burnTokens(amount, mintlayerAddress)` invocation transfers the specified ML amount **from its caller into the TokenBurner contract**, using `transferFrom`, and emits `TokensBurned(user, amount, mintlayerAddress)`. The source does not execute an ERC-20 `_burn`, send tokens to Launchpool's treasury, contain an owner/withdraw function, check a calendar deadline, or pay native ML on the Mintlayer chain. Its use of the word burn does not mean ERC-20 total supply is reduced by this function.

I independently checked the preserved portal JavaScript: it defines this same contract address, builds `burnTokens` calldata and submits an Ethereum transaction to that address. This source/JS match identifies the portal's requested action; it does not verify an individual transaction or a completed native payout.

**Use this narrow framing:** ERC-20 tokens successfully submitted through this function are held at the separate TokenBurner contract, with no withdrawal path in its verified source. Native-ML delivery remains a separate process. Tokens never submitted are not pulled by this function and remain at their existing Ethereum holder or distributor address unless another transaction moves them. The public portal-closure policy alone does not establish an automatic sweep, a global ERC-20 freeze, or expiry in either Launchpool distributor. A `TokensBurned` event alone is not evidence of successful native-ML receipt.

The source checks the native-address string's length and prefix, not actual native-chain ownership or receipt. No approval, transfer, migration submission or other state-changing action was performed by this review.
