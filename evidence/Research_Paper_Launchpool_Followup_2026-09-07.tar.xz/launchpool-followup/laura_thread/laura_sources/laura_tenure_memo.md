# Laura Walsh / Takenaka — Launchpool tenure and Mintlayer linkage

Review date: 7 September 2026. Public sources only; no contacts or transactions.

**The public evidence verifies Laura's Launchpool roles, but this pass did not retrieve a primary source assigning her responsibility for Mintlayer fundraising, token distribution, or a relevant wallet. The exact COO end date remains unresolved.**

## What the sources establish

| Role / connection | Supported dates | Evidence and limit |
|---|---|---|
| LaunchpoolXYZ COO | May 2021 start month, retrospectively reported | Nativz's 9 July 2022 newsletter says she joined as COO in May 2021 [L02]. No day or departure date is supplied. |
| Launchpool COO | October 2021 contemporary identification | Her interview on MoneyNeverSleeps identifies her as COO [L01]. The episode detail page displays 8 October; some index/feed results display 7 October. |
| Launchpool Web3 Techstars corporate liaison | Explicitly identified in July 2022 | Nativz describes her then as Corporate Liaison [L02]. This does not prove she simultaneously remained COO. |
| Senior corporate liaison, Launchpool Web3 TS | June 2021–January 2023, self-profile snippet | An indexed LinkedIn snippet gives this range for the liaison role [L03]. The full experience page could not be retrieved, so this is a qualified first-party lead. It is not a COO departure date. |
| Laura personally discussing Mintlayer | Not established in retrieved primary material | Her 2021 interview discusses Launchpool's general investment model; no Mintlayer name appears. |

Laura's own quoted interview comments describe Launchpool and Alphabit obtaining project allocations for retail participants on terms matching Alphabit's access [L01]. This supports her public explanation of Launchpool's model. It should not be rewritten as a Mintlayer-specific promise.

## What the direct Mintlayer source says

Launchpool's official recap dated 23 March 2022 documents an AMA on 21 March at 17:00 UTC. It names the Launchpool host as Spiderman and the guests as Enrico Rubboli and Andreas Kohl. Kohl describes the business-development/investor-relations team as himself and Sarita Yasmin; he names his longstanding relationship with Richard and the Alphabit team, Mintlayer's seed-round lead investor, as a reason for partnering with Launchpool. The retrieved article has no Laura mention [L04].

This is a more specific public lead for the Mintlayer relationship than Laura's general title. It does not identify all people working behind the scenes or those controlling the distribution contract. The AMA's host alias has not been resolved to a human in this pass.

## Negative-search scope

The 28 exact queries are preserved in `search_scope.json`. Both search engines were used for combinations of Laura Walsh / Laura Takenaka with Mintlayer, Launchpool, AMA, COO, role dates, and departure wording. Targeted domains included Mintlayer's .org and .com sites, Launchpool Medium, app.launchpool.xyz, Telegram announcements, X/Twitter, and her identified LinkedIn profile. A Mint Layer spelling variant and MLT token abbreviation were also checked. No retrieved primary source directly joined her identity to Mintlayer.

In addition, the full readable March 2022 AMA was searched for Laura, and primary 2021 interview text and the archived Nativz announcement were extracted and inspected. The latter two contain no Mintlayer mention. This is a bounded result; there was no exhaustive social export, complete audio transcription, or full historical crawl. Unrelated Laura Walsh and Laura Morgan Walsh results were excluded.

## Records that would resolve the gap

The decisive records are Laura's Launchpool employment/consulting terms and resignation/handover date; the Mintlayer–Launchpool allocation agreement and its signatories; authority/delegation records; and distribution instructions, admin-access records or correspondence naming responsible personnel. Role overlap is a reason to inspect these records, not proof of signing authority or receipt of funds.

GamiFi's separate CEO change on 1 September 2022 must not be used as the date Laura left Launchpool. Likewise, a later guest index repeating the 2021 COO description does not extend that employment through its current crawl date [L05].

## Primary source ledger

- **L01:** https://www.moneyneversleeps.ie/156-3-is-the-magic-number-laura-walsh-launchpool-and-techstars/ — interview by the show's own publisher. Web ref `turn100703view0`. Direct HTML preserved as `interview_oct2021.txt`, retrieved 2026-09-07T05:27:41.589607Z, with derived readable extraction.
- **L02:** https://www.nativzgaming.com/p/newsletter-09-07-22 — Nativz's own announcement, author Kurt Pittman, dated 9 July 2022. Web ref `turn291693view0`. Direct current raw request returned 403, but the web tool retrieved the full readable page. A substantive Internet Archive copy timestamped 2026-03-08T08:11:31Z was independently retrieved at 2026-09-07T05:28:48.817029Z and preserved as `nativz_archive_20260308.html` with extraction. Archive URL: https://web.archive.org/web/20260308081131id_/https://www.nativzgaming.com/p/newsletter-09-07-22 . Archive date is not article date.
- **L03:** https://ca.linkedin.com/in/lauralwalsh — indexed first-party profile snippet, web ref `turn541306search1`. Title/date summary preserved in `source_records.json`. No full-page or archived employment record was obtained.
- **L04:** https://launchpool.medium.com/launchpool-ama-recap-mintlayer-7dbef79f623d — official Launchpool recap. Web open `turn541306view0`; no-Laura find result `turn365579view0`. Readable article reviewed; direct raw retrieval returned 403.
- **L05:** https://www.moneyneversleeps.ie/guests/laura-walsh/ — publisher guest index, web ref `turn291693view1`.

Root should reopen these URLs before citing child source refs. All stored source receipts, excerpts and raw files are listed in the local manifest with SHA-256 hashes. No master PDF was changed.
