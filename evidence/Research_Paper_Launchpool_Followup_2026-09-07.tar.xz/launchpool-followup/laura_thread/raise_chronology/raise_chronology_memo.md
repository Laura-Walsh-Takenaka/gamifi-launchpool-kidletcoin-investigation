# Mintlayer original Launchpool raises and Laura: bounded chronology

Researcher memo — 7 September 2026. Public passive research. Source IDs resolve in `source_records.json`; archived offer fields are in `bounded_app_fields.json`. This memo concerns the original offers, not ownership of the 2025 final distributor or its withdrawal address.

## Finding

The original Launchpool offers occurred in November–December 2021 and March 2022. Laura's October 2021 interview independently establishes a Launchpool operating role near the first offer. The reviewed Mintlayer offer pages and deal announcements name other project/platform staff, but do not name Laura as the deal approver, signatory, payee or wallet controller. The evidence supports an organizational connection worth asking about; it does not establish personal responsibility for missing claims or custody of their funds.

## Offer chronology and terms

| Event | Primary evidence | What can safely be said |
|---|---|---|
| 8 October 2021 | R08 interview | Host identifies Laura Walsh as Launchpool COO. Her account describes the Alphabit/Launchpool allocation model. The Laura Walsh hyperlink points to `/in/lauratakenaka/`. |
| 22 November–1 December 2021: Raise 1 | R01 opening-day and R02 closing-day archived app | Target 600,000 BUSD on BSC; MLT price $0.0952; intended native Mintlayer distribution. Vesting: 10% at TGE, then 6% monthly for 15 months. |
| 23 November and 1 December 2021 releases | R06–R07 | Contemporary promotion confirms the $600,000 allocation and 1 December payment cutoff. About $15.3 million describes staked LPOOL value, **not money raised for Mintlayer**. |
| 16 March 2022: Raise 2 preliminary page | R03 | Target 350,000 BUSD, displayed price $0.162; preliminary vesting summary 3.33% at TGE with remainder over 20 months. |
| 21 March 2022 AMA, published 23 March | R05 | Describes a second sale with short and long tranches, detailed below. |
| 21–30 March 2022: Raise 2 event schedule | R04 retrospective app schedule, corroborated by R05 start date | Deposit 21 March; allocation mining 22–27 March; payment window closes 30 March. |
| 13 December 2022 | R11 project Medium announcement | Announces a 21 March 2023 ERC-20 TGE ahead of native mainnet, with a subsequent 1:1 native distribution envisaged. This is token issuance, not a new date for either original Launchpool funding round. |
| By 30 March 2023 | R04 later app snapshot | Target now 400,000 BUSD; price still $0.162; vesting summary now 3.33% at TGE plus 34 months; distribution field changed from native Mintlayer to ETH. |

R01–R02 give block-dependent estimates: deposit 22 November 2021 at 09:00:30 UTC (block 12,858,074); mining starts 23 November at 08:16:44 (12,885,930), ends 28 November at 17:57:20 (13,041,550); payment closes 1 December at 15:39:29 (13,125,200). These were published estimates, not verified actual block times. The page says distribution and vesting changes may occur and will be communicated. Neither this notice nor the target amounts prove completed funding or consent to a later revision.

The March AMA (R05) describes each ticket as one-third short and two-thirds long:

| Tranche | Advertised amount and price | Advertised vesting |
|---|---|---|
| Short | 720,759 MLT at $0.1952 | 10% at TGE; 6% monthly for 15 months |
| Long | 1,441,518 MLT at $0.1452 | Four-month lock; 2% monthly for ten months, then 4% monthly for twenty months |

Those amounts calculate to $350,000.5704, approximately the initial $350,000 allocation. This is arithmetic on advertised terms, not a receipt total. The two tranches also explain the aggregate initial unlock of roughly 3.33%. The AMA names Enrico Rubboli and Andreas Kohl as guests and a Launchpool host using the alias Spiderman. Kohl mentions knowing Richard and Alphabit's lead-seed relationship; Laura is not named in the reviewed text.

There are two material record differences: the preliminary R03 page prints the March dates with year **2021**, whereas its weekdays and the contemporaneous AMA correspond to **2022**; and its 20-month vesting summary differs from the AMA's detailed long schedule and R04's later 34-month summary. Preserve these differences. The later page establishes a $400,000 **target by March 2023**, not that $400,000 was collected, or the exact date the target was raised. No signed revised terms or recipient-level allocation ledger was recovered in this bounded task.

## Entity and named-person boundaries

The original offer pages link the platform's terms. The 28 January 2022 archived terms (R10), reviewed again here, name **Launch Pool Limited** under unspecified Virgin Islands law. They do not establish the British/US Virgin Islands distinction, registration number, identity with UK LAUNCH POOL LTD 12992979, or the Mintlayer purchase counterparty in an executed agreement. The Panama operator named in 2024 terms should not be substituted as the proven 2021 contracting party.

R06 identifies **RBB SRL, San Marino**, as Mintlayer development coordinator. It presents **Richard Simpson** as Launchpool cofounder/CEO and **Andreas Kohl** as Mintlayer institutional-relations director. R07 describes Kohl as RBB Lab CBDO. These are contemporary public representations, not a registry-verified corporate ownership map.

The app's project team panel (R01–R04) presents **Enrico Rubboli** as CEO/founder, **Alberto De Luigi** as research cofounder, **Luca Viviani** as tokenomics cofounder, **Andreas Kohl** as CBDO, **Ben Marsh** as VP engineering and **Giovanni Mazzanti** as head of legal. R01 additionally includes **Adrianna Mendez** as CMO, absent from R02. Laura is absent from these Mintlayer panels; the panel alone does not identify Launchpool's full staff or delegated responsibilities.

Laura's July 2022 Nativz announcement (R09) retrospectively dates her Launchpool COO appointment to May 2021 and credits GamiFi and Techstars work. It does not establish uninterrupted COO tenure at every subsequent event. The March 2023 Mintlayer–Launchpool Labs announcement names **Roxana Nasoi, managing director** (R12), not Laura. It documents an incubator partnership, not ownership of Mintlayer allocations.

## Payment routes, later claims and limits

The app explicitly identifies **BUSD funding on BSC**. The recovered static Nuxt state leaves the global and staking contract maps empty; no original sale payment-contract address or personal recipient was recovered. Do not use the unrelated site-wide LPOOL trading-pair configuration as a Mintlayer collection wallet. This task did not inspect wallets or transactions.

The 2025 final distributor is a later claims mechanism. Its deployment date, present token balance or configured withdrawal address cannot establish who received the 2021–2022 BUSD proceeds. Likewise, an original funding target cannot establish the sum available at a later missed deadline. Root's separate contract analysis is needed for the withdrawal function and the distinct native-token migration path.

The remaining personal bridge would require a dated role/delegation covering Mintlayer, an approval or executed agreement, or an independently attributable receipt/control record. No such bridge was recovered. Exact-name searches pairing Mintlayer with Laura Walsh and Laura Takenaka returned no direct deal evidence in the reviewed results; search coverage is not proof that no connection existed.

## Retrieval record

Wayback CDX returned both original app paths and dated snapshots. Four snapshots were retrieved successfully with Python urllib; the web search open endpoint rejected those archive URLs. Their embedded `window.__NUXT__.data[0].projectContent` supplied the offer fields. The March 2023 HTTP payload required gzip decompression. Source records include SHA-256 hashes of the retained decoded inputs. A further bounded CDX query for 2022–2023 Raise 2 variations timed out; no conclusion depends on that query. Raw retrieval material is under `retrieval_work/` and is not a deliverable extract.

Medium's direct request returned 403; the official AMA's full indexed article was retrieved through web search. The current Mintlayer website's copy of the token-launch announcement displays 15 January 2024 while describing a forthcoming March 2023 event. The official Medium version dated 13 December 2022 resolves that publication-date ambiguity. The podcast's LinkedIn destination failed with 999, but the source hyperlink itself is visible. No login, contact, transaction or change to a third-party system was performed.
