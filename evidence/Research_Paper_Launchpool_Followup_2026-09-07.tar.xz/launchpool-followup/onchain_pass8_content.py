"""Inspector handoff pass: bounded tails, improved source evidence and corrected old gaps."""
def apply_corrections(B,groups):
    changed=[]
    for b in B:
        if b.get('kind')=='table':
            for row in b['rows']:
                if row[0]=='Original purchase money':
                    assert 'historical withdrawal recipients remain unrecovered' in row[1]
                    row[1]='All six original Mintlayer withdrawals paid 903,794.346419582485370326 BUSD to 77bf on 3-4 November 2022. Sections 9.19-9.24 trace onward payments. Payment purposes, mandates and human control remain unresolved. These receipts are separate from ML distributor reserves. [F46-F52]';changed.append('p16')
        t=b.get('text','')
        if 'not the missing Mintlayer BUSD payment trail' in t:
            b['text']=t.replace('not the missing Mintlayer BUSD payment trail','separate from the original Mintlayer BUSD receipts recovered in section 9.19');changed.append('p18')
        if t=='The remaining cash gap is the withdrawal trail':
            b['text']='The original withdrawal trail is now recovered';changed.append('p19')
    assert sorted(changed)==['p16','p18','p19']
    edits={
      'F19':('no payment recipient recovered.','no payment recipient identified by these snapshots; F46 later supplies all six actual withdrawals.'),
      'F33':('Historical withdrawal and source acquisition failed; failures retained.','Initial historical-withdrawal retrieval failed; F46 later recovered all six receipts. Full-source acquisition remains unresolved; failures retained.'),
      'F38':('Historical starting balance is unresolved; customer identity is not established.','Initial archive state was unavailable; F48/F50/F54 supply event-derived opening balances and conditional source bounds. Customer identity is not established.'),
      'F47':('Pre-existing funds, the window gap and human-attribution limits remain explicit.','The original window gap is closed by F52. Prior-fund and human-attribution limits remain explicit.')}
    found=[]
    for group in groups:
        for i,(ref,title,url,note) in enumerate(group):
            if ref in edits:
                a,z=edits[ref];assert a in note;group[i]=(ref,title,url,note.replace(a,z));found.append(ref)
    assert sorted(found)==sorted(edits)


def append_eth_and_handoff(B):
    def p(t,k='p'):B.append({'kind':k,'text':t})
    def h(t):p(t,'h')
    def h2(t):p(t,'h2')
    def page():B.append({'kind':'break'})
    def table(rows,widths):B.append({'kind':'table','rows':rows,'widths':widths})
    page();h('9.28 The USDT return reaches Kraken and KuCoin')
    p('<b>The previously unresolved 21,882.27-USDT branch reaches Kraken 7.</b> On 23 July 2024, 1991 paid 188b; 188b passed the same amount to 0d56; Kraken 7 then called transferFrom to collect the full amount. Both intermediaries opened and closed the reviewed USDT windows at zero. Canonical logs, successful raw receipts, calldata and historical balances agree. [F48; F56]')
    table([
      ['Step on 23 July 2024','USDT','UTC / elapsed'],
      ['1991 > 188b','21,882.27','14:42:35'],
      ['188b > 0d56','21,882.27','14:49:47 / 7m 12s'],
      ['0d56 > Kraken 7','21,882.27','14:51:59 / 2m 12s'],
    ],[223,105,171])
    p('Kraken 7: <font face="DVM" size="7.1">0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40</font><br/>Intermediary: <font face="DVM" size="7.1">0x0d560ac1b578ee5ac815a0e096cac37cb4c0eb5e</font><br/>Collection: <font face="DVM" size="6.8">0x2d7f8d2319465342ca9766215c00fbded8896cdabe7a1e620cd261009650e987</font>','small')
    h2('The selected return now has a stronger source bound')
    p('Immediately before receiving <b>58,724.105382 USDT</b> from 183600 on 23 July, 1991 held 8,375.183313 USDT. It paid 21,882.27 to this Kraken branch and 4,000 to 2c94, then received 14,690.010811 and 50,000 from other sources. Its final 105,907.029506-USDT payment went through the already verified KuCoin deposit route and left zero. [F48; F56-F57]')
    table([
      ['Exchange route','Gross USDT','Selected-return contribution'],
      ['New Kraken branch','21,882.27','13,507.086687-21,882.27'],
      ['Prior KuCoin branch','105,907.029506','32,841.835382-41,217.018695'],
      ['Combined routes','127,789.299506','54,724.105382-58,724.105382'],
    ],[157,121,221])
    p('The combined interval follows because 1991 ends at zero and only 4,000 USDT leaves by the third branch. Independent chronological allocations attain both bounds. Individual minimums cannot be added: they share the same prior funds and return. The gross 127,789.299506 includes substantial other money; it is not all trading return. [F57]')
    h2('A former evidence condition is closed for this window')
    p('New successful historical calls confirm 1991\'s opening 8,375.183313 and closing zero. Complete incoming and outgoing canonical-USDT raw queries cover blocks 20,369,851-20,375,526 and match all six positive indexed events. Smaller contiguous outgoing queries replaced a preserved range-limit failure. The narrow return-window bound no longer relies solely on an indexed starting balance. This does not upgrade the separate initial IAG-USDC source histories. [F56-F57]')
    p('The selected source is the USDT payment returned by 183600. Its division between invested principal, trading gains and other funding is a separate question. This new route is also separate from the mixed 300,000-USDT Kraken sweep on 18 July in section 9.25. No customer identity, payment mandate or Laura\'s personal receipt follows. [F53; F56-F57]','small')

    page();h('9.29 The 21,664-USDC tail reaches a Binance deposit')
    p('<b>A further branch reaches an address labeled Binance Deposit.</b> After d541 paid 21,664 USDC to 0585 on 30 July 2024, a matching 21,664-USDC transfer went to 22c84, which sent a net 21,664 to 2fb794. Later that day, 2fb794 sent 66,600 USDC to the deposit address below. Historical prior funds and remaining balances define how much of the selected payment must be included. [F53; F56]')
    p('Binance deposit: <font face="DVM" size="7.0">0x67124cb10bd4cd6de2946caa1a905c61f05c838e</font><br/>This Ethereum USDC branch is separate from the November 2022 BSC BUSD routes.','small')
    table([
      ['30 July 2024 movement','USDC / UTC'],
      ['d541 > 0585','21,664 / 06:47:35'],
      ['0585 > 22c84','21,664 / 08:52:59'],
      ['22c84 > 2fb794; return to 22c84','100 sent; 60 returned'],
      ['22c84 > 2fb794 again','21,624'],
      ['2fb794 > Binance deposit','66,600 / 13:50:59'],
    ],[301,198])
    h2('A positive downstream bound, with a firm upstream limit')
    p('0585 began with <b>452.461220 USDC</b>. 22c84 began and ended at zero. 2fb794 began with <b>31,008.122752 USDC</b>, also received 14,897.345416 from another source, and ended with <b>969.468168 USDC</b>. The 60-USDC reverse transfer is included; amounts passed repeatedly between the same wallets are not counted as new funds. [F56]')
    p('The 66,600-USDC deposit includes between <b>20,242.070612 and 21,664 USDC</b> from d541\'s selected 30 July payment. The minimum allows all 452.461220 of 0585\'s prior funds into the route and all 969.468168 remaining at 2fb794 to be selected-source funds. Chronological feasible allocations, complete bounded token logs and historical states substantiate the interval. [F56]')
    p('<b>This does not force any of the earlier 24 July receipt at d541 into Binance.</b> d541 held 228,092.803239 USDC before that earlier 318,192.18-USDC receipt; its prior funds exceed the later 21,664 payment. The newly forced source is the 30 July payment at a downstream point, not uniquely IAG proceeds or the earlier trading-return branch. [F53; F56]')
    h2('What the service endpoint resolves')
    p('The label and successful transfer supply a specific deposit-account record lead. The receiving account, credit, purpose, later trade or withdrawal and human controller remain unidentified. The captured route ends at this deposit; an internal Binance credit or fiat cashout is not inferred. [F56]')
    p('Full addresses, exact hashes, block ranges, UTC timestamps, rejected zero/lookalike rows and preserved retrieval failures are in onchain_pass8/eth_tail/. The report uses historical cutoffs, not present balances. [F56]','small')

    page();h('9.30 Inspector handoff: findings and remaining records')
    p('<b>The public evidence is ready to support focused records work.</b> The original withdrawals, repeated wallet relationships and selected exchange routes have exact identifiers. Public activity still does not identify the human signer, beneficial customer or contractual authority. Further tracing can extend dated balances, but those separate questions require matching records. [F55-F58]')
    table([
      ['Question','Evidence to start from','Record that would resolve it'],
      ['Who controlled the wallets?','77bf original withdrawals; 6c2 treasury authority; 1991 repeated payments','Dated custody/delegation logs, payment instructions, approvals and control handovers. Link to each transaction time.'],
      ['Which account received credit?','Binance, Kraken, KuCoin, MEXC and Revolut routes; exact chain/token/hash/time in evidence','Deposit or sweep mapping to account/subaccount, ledger credits, account mandates, trades and later withdrawals.'],
      ['Were obligations settled?','903,794.346419582485370326 original BUSD; separate IAG-USDC and ML ledgers','Purchase and project-settlement agreements, purchaser register, invoices, allocations, refunds and alternate settlements.'],
      ['Did holders receive native ML?','Claim proofs, migration-contract mechanics, reserve snapshots','Complete Raise 1 allocation dataset, Raise 2 version mapping and Ethereum-event-to-native-payout reconciliation.'],
      ['Which entity assumed the business?','Existing corporate map and two obtained Panama deeds','Share/beneficial-owner records, voting/proxy instruments and executed asset, customer-contract and liability-transfer agreements.'],
    ],[105,179,215])
    h2('The November deadline remains a migration policy')
    p('Mintlayer\'s official page still sets <b>1 November 2026</b> as migration-tool closure, with requests processed every two weeks in the current period. The public form is retrievable; this alone proves no successful submission or mainnet payout. The separate distributor has no calendar-triggered transfer to Laura or an identified company. Its existing withdrawal authority and fixed treasury remain the relevant custody facts. [F06; F21-F24; F58]')
    h2('Corrections and external evidence dependencies')
    p('Obsolete withdrawal-gap wording on pages 16, 18 and 19 and four source notes is corrected. The recovered transactions remain the controlling evidence. The historical GamiFi deficit on page 12 references a separate study: if inspectors rely on that finding, its existing master and underlying evidence are companion materials. This bundle contains the dated extract and disclosed refresh, not that full earlier schedule audit. [F10; F58]')
    p('No sum across BUSD, USDC, USDT and ML is presented as a loss total. Exchange labels identify service leads; they do not establish misconduct, investor entitlement or personal receipt. Laura\'s published roles remain contextual evidence, not proof that she held these keys or received these funds. [F55-F58]','small')

def append_busd_tail(B):
    from pathlib import Path
    import json
    r=Path(__file__).resolve().parent
    tail=json.loads((r/'onchain_pass8/busd_tail/tail_verified.json').read_text())
    common=json.loads((r/'onchain_pass8/busd_tail/common_cut_verified.json').read_text())
    assert len(tail['rows'])==1 and tail['rows'][0]['to']=='0x87245c288fcc858bf7225dc3ab97d0ad94730757'
    assert tail['rows'][0]['amount_busd']=='3457.600228610921015515'
    assert sum(int(x['balance_raw']) for x in common['balances'])==403500914021983632450616
    def p(t,k='p'):B.append({'kind':k,'text':t})
    B.append({'kind':'break'});p('9.27 BUSD tail checks and exact flow accounting','h')
    p('<b>No BUSD leaves any of the six remaining wallets within the newly completed windows.</b> Both-direction canonical logs extend the owner, bf7f and 8724 through 19 November 2022; cedfa and dc127 through 17 November; and the small 2108 branch from 5 through 19 November. One later swap into BUSD is retained explicitly; all other queried BUSD activity is absent. Historical states agree with the complete logs. [F55]')
    p('The six wallets also have direct balance reads at one common historical block: <b>23,129,158, 17 November 2022 at 09:02:15 UTC</b>. This resolves the previously mixed-date comparison for these retained balances. [F55]')
    B.append({'kind':'table','rows':[
      ['Wallet','BUSD at the common block'],
      ['77bf owner','7,424.678430731639424238'],
      ['bf7f','150,000'],
      ['8724','25,197.437915171993026378'],
      ['cedfa','180,205.79767608'],
      ['dc127','40,663'],
      ['2108','10'],
      ['Six-wallet total','403,500.914021983632450616'],
    ],'widths':[170,329]})
    p('These balances include previously held funds. In particular, 8724 began with 197.437915171993026378 and dc127 with 663 BUSD. Cedfa\'s prior 215.79767608 may have entered earlier payments or remained. The owner\'s original prior 0.332011149154053912 is a shared source budget. The total is historical token custody, not a current reserve or liability figure. [F47; F51-F52; F55]')
    p('The captured original flow graph reconciles exactly','h2')
    p('The earlier 34 unique positive graph events reconcile in base units:<br/><b>903,794.346419582485370326</b> original withdrawals<br/>+ <b>1,167.08760240114708029</b> prior funds at participating wallets<br/>= <b>501,460.52</b> gross Binance receipts<br/>+ <b>403,500.914021983632450616</b> at the six retained leaves. [F57]')
    p('The zero-event continuations through 17 November and common-block states substantiate that retained total. The Binance figure is cumulative historical receipt throughput; it is not Binance\'s balance at that block. Intermediate hops are counted once. There is no arithmetic residual in this captured graph, while purchaser entitlements, settlement purpose and authority remain unreconciled. [F55; F57]')
    p('Where this public trail stops','h2')
    p('On 18 November at 17:38:52 UTC, 8724 swapped ULX through PancakeSwap v2 and received 3,457.600228610921015515 BUSD from pair 65f2. Its later BUSD balance is 28,655.038143782914041893. The ULX acquisition source is untraced; these swap proceeds are not counted again in the original-raise total. The owner/bf7f/8724/2108 endpoint is block 23,191,705 at 19 November 2022 13:59:08 UTC. Cedfa/dc127 stop at the common 17 November block. No later history is claimed here. The first seven Binance payments and their original-source interval remain unchanged; the BUSD extension adds no centralized-exchange receipt. [F51-F52; F55; F58]')

def add_pass8(B):
    append_busd_tail(B)
    append_eth_and_handoff(B)
    return [
      ('F55','BUSD tail closure and a common historical balance cut','https://bscscan.com/address/0x77bfe8d704b1948374bf8dab8328a810b2836e66','onchain_pass8/busd_tail/: complete bounded canonical logs for six wallets, pinned boundary headers and historical balances. Common-block custody is separately distinguished from each longer/shorter scan cutoff. No outgoing transfer is found; one later ULX-to-BUSD swap by 8724 is separately verified. Empty windows use actual successful responses; prior funds remain explicit.'),
      ('F56','Kraken USDT collection and a separate Binance USDC deposit','https://etherscan.io/address/0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40','onchain_pass8/eth_tail/: thirteen successful selected receipt/input pairs, twelve historical balance calls, complete both-direction token windows and preserved limits. Kraken collects 21,882.27 USDT from 0d56. Separate Binance deposit 67124 receives 66,600 USDC with bounded source contribution from the selected 30 July payment; no forced attribution to the earlier d541 receipt. Direct primary explorer labels and exact identifiers retained.'),
      ('F57','Joint return-source bounds and exact original BUSD flow accounting',None,'onchain_pass8/source_accounting/ and peer_review/: independently feasible chronological bounds for the selected USDT return, new raw/state corroboration for its source window, deduplicated original BUSD conservation and a focused nine-event service-record index. No token totals are combined, individual minima are not added and arithmetic conservation is not proof of authorized settlement or human ownership.'),
      ('F58','Inspector readiness audit and current migration-policy recheck','https://www.mintlayer.org/ml-coin','onchain_pass8/handoff_audit/ and public_recheck/: source-grounded content audit, corrected obsolete gaps, current official November 1, 2026 policy and concrete unresolved records. Prior GamiFi schedule study is an external evidence dependency. Public portal access is not native delivery. No outside records request or communication was made.'),
    ]
