from pathlib import Path
import json, re
from xml.sax.saxutils import escape

R=Path(__file__).resolve().parent
B=[]
def p(t,kind='p'): B.append({'kind':kind,'text':t})
def h(t):p(t,'h')
def h2(t):p(t,'h2')
def table(rows,widths):B.append({'kind':'table','rows':rows,'widths':widths})
def page():B.append({'kind':'break'})

h('9. Claims, continuity and transition follow-up')
p('Public-record and read-only blockchain checks | 7 September 2026 UTC','small')
p('<b>The website problem is corroborated by DNS records. A separate Mintlayer final-claim system remains accessible and is fully backed for the published unclaimed allocations at the checked block.</b> The historical GamiFi deficit is a different contract and token. The follow-up also identifies publicly represented Launchpool operating leadership after the 2024 transition.')
h2('9.1 Website observations and their limits')
table([
 ['Observation','Evidence and meaning'],
 ['Domain registration','CentralNic registry RDAP lists expiration on 18 September 2026, 23:59:59 UTC. The domain had not expired at the 7 September check. Registrar: GoDaddy. No registrant identity was disclosed. [F01]'],
 ['Web-address resolution','Google DNS returned no A/AAAA address for the apex and NXDOMAIN for app/www. Cloudflare DNS independently agreed for apex A and app A. These establish resolver failures at the checked time. [F02]'],
 ['Last recovered app capture','28 January 2026, 01:29:04 UTC: substantive Launchpool HTML with navigation, sign-in fields and a Panama footer. Its content digest matches an April 2025 capture; it is a shell, not proof that login, balances or claims worked. [F03]'],
 ['Other live surface','The separate Mintlayer final-claim page returned HTTP 200. Its application bundle and public allocation files were recovered. Official Launchpool notices identify this claim route. [F04-F05]'],
], [120,379])
p('RDAP and resolver nameserver lists differ; the observed SOA points to Netlify. This is a configuration-history lead. No account log establishes who changed the settings, when the web addresses disappeared, or why. Registry change fields and SOA serials are not treated as deletion dates. [F01-F02]')
p('<b>Still open:</b> DNS/hosting change logs, the last verified functioning customer session, service/closure notices and affected-user access outcomes. A January archive response and September DNS failures do not establish continuous functionality or a precise shutdown interval.')

page(); h('9.2 Mintlayer: all published claims reconciled')
p('Ethereum block <b>25,923,249</b> | 7 September 2026, <b>05:00:23 UTC</b>. Amounts are ML tokens, not dollars. Wallet counts do not identify distinct people. [F05-F07]','small')
p('Final distributor: <font face="DVM" size="7.5">0xcc32853fb709666332cde0fc47f3f74119b970c4</font><br/>ERC-20 ML token: <font face="DVM" size="7.5">0x059956483753947536204e89bfad909e1a434cc6</font>')
table([
 ['Measure','Exact result'],
 ['Published allocation ledger','1,999 unique wallet/index records; indices 0-1998'],
 ['Total allocated ML','1,294,650.3000849776853554'],
 ['Claimed records / ML','119 / 178,609.45446753072393'],
 ['Unclaimed records / ML','1,880 / 1,116,040.8456174469614254'],
 ['Distributor ML balance','1,116,041.281767546177360307'],
 ['Balance above unclaimed ledger','0.436150099215934907 ML'],
], [205,294])
p('<b>Finding:</b> this distributor has sufficient token backing for its entire published unclaimed ledger at the checked block. The 1.116 million unclaimed ML is not a missing-funds total. This does not establish that the ledger includes every historically entitled Raise 2 participant.')
h2('Independent verification')
p('Every readable allocation equals its raw integer amount at the token\'s verified 18 decimals. All 1,999 cryptographic allocation proofs validate; an independent tree reconstruction reproduces the published root, and the deployed root matches it. All eight claimed-bitmap storage words were checked, with no set bits outside the allocation range. [F05-F07]')
p('All 119 successful claim inputs match the ledger and bitmap, and each matches an ML transfer to the specified beneficiary. The 123 ML transfer events in the retrieved history reconcile exactly to the pinned balance. One unrelated token event is excluded from ML accounting. The last successful claim in that history was 3 May 2026, 12:57:47 UTC. [F06-F07]')
p('Merkle root:','small');p('0x031862a21347c8b43c3fd3e7d67615141f32476371b3a31e3447de2530d06aa7','code')

page(); h('9.3 Mintlayer: control and the corrected deadline')
h2('The migration deadline is now 1 November 2026')
p('The older Launchpool feed referred to January and then April 2026 ERC-20 support/migration dates. Mintlayer\'s current official ML page instead states that its migration tool remains open until <b>1 November 2026</b>, with requests processed every two weeks from 1 August to that date. The separate migration page also loads. This supersedes the April date for current reporting. [F04, F08]')
p('Mintlayer says the tool will then close and unmigrated ERC-20 tokens will remain locked rather than burned. That is a published policy, not a demonstrated future contract event. No migration was submitted in this research, and no individual mainnet delivery was verified. Older generic 48-hour UI text should not override the newer dated processing schedule. [F08]')
h2('Identified contract authority')
p('At the pinned Ethereum block, owner() and the immutable treasury both identify:<br/><font face="DVM" size="7.5">0x6c2b3a90acb72ef896325e19af9098d157f929c4</font><br/>The verified deployed source permits the owner to withdraw the token balance to that treasury and contains no calendar cutoff in claim(). This identifies contract powers, not the human signer or a company mandate. [F06]')
table([
 ['Dated event','Verified result'],
 ['25 August 2025','Distributor deployed. Deployer: 0xb72fc236Ab043029776b9d25e99A5B6456A2e16D. [F06]'],
 ['30 September 2025','Ownership transferred to the treasury address. [F06]'],
 ['10 October 2025','A 1-ML deposit and successful 1-ML owner withdrawal preceded the bulk funding. Later deposits backed the allocation ledger. [F06-F07]'],
 ['25 March 2026','A withdrawal call from a different address reverted; no ML withdrawal resulted. [F06-F07]'],
 ['3 May 2026','A successful claim occurred after the older April deadline. Neither that date nor the current migration policy creates a calendar expiry inside this distributor. [F06-F08]'],
], [120,379])
p('<b>Remaining claims questions:</b> reconcile the 1,999-record final ledger to original Raise 2 purchases and earlier rounds; identify the treasury controller and mandate; determine whether notices reached the remaining holders; and verify mainnet receipt after any migration. The current token backing result closes a balance question, not these delivery and identity questions.')

page(); h('9.4 GamiFi remains a separate reconciliation')
p('BNB Smart Chain | fresh state block <b>120,435,314</b>, <b>7 September 2026, 05:04:55 UTC</b>. [F09]','small')
p('GMI token: <font face="DVM" size="7.4">0x93d8d25e3c9a847a5da79f79ecac89461feca846</font><br/>Launchpool vesting vault: <font face="DVM" size="7.4">0xf50488dc8339fb7d1d5a8e8b401c4a5d71a090bb</font>')
table([
 ['Evidence date / scope','Measured result'],
 ['Fresh balance, 7 September','207.412329404181026961 GMI; token decimals 18.'],
 ['Fresh administrative owner','0xf27f9a2eb9b2c70d32476cf9dc2d74ca4e61c27b; no deployed bytecode returned for that address at the checked block.'],
 ['Prior audited schedule book','39 funding transactions on 19 April 2022; 7,495 schedules for 7,490 distinct addresses; total 15,456,885.882908530406846 GMI. [F10]'],
 ['Prior 6 September observation','Unpaid original schedules: 14,000,207.412329404181026961 GMI. Balance: 207.412329404181026961 GMI. Difference: 14,000,000 GMI. [F10]'],
], [170,329])
p('The new balance equals the earlier balance exactly. <b>The unpaid schedule book was not recalculated in this follow-up.</b> The historical 14-million-GMI finding retains its earlier observation date and supporting evidence. Equal endpoint balances do not establish no intervening activity; the fresh owner address does not identify the historical human signer. [F09-F10]')
h2('What the 2024 status label says')
p('Launchpool\'s 2024 project notice places GamiFi in the <b>Completed Vesting</b> category, while Mintlayer was still listed in vesting. The label does not explicitly say every beneficiary was paid. A schedule can finish maturing while claims remain unpaid. The relevant test is whether original obligations were delivered, refunded, migrated or discharged elsewhere. [F11]')
h2('Lifetime history remains open')
p('No requested GMI transfer-log interval completed successfully. Even 100-block queries returned provider limits; other sources were unavailable. These failed requests cannot support a zero-transfer conclusion. Complete transfers, refills, claims, control changes and any alternate settlement records are still required. Raw access results and the successful fresh-state reads are preserved separately. [F09]')
p('The original study records Laura\'s GamiFi replacement announcement on 1 September 2022, before the November control changes and withdrawals. This pass supplies no new evidence attributing those actions to her. [S18; F10]')

page(); h('9.5 The 2024 operating transition is clearer')
p('<b>Roxana Nasoi was publicly identified as Launchpool CEO by July 2024.</b> Launchpool\'s 26 July article identifies her in that role during its 19 July discussion; the Labs site also uses the title beside its 2024 XDC program. These are operating-role statements, not Carajo shareholder or director records. The same article calls Decentric a sister launchpad; no legal ownership chain follows from that phrase. [F12-F13]')
table([
 ['Migration evidence','What it adds'],
 ['28 April 2024: Gate notice','Supports a 1:1 token migration and identifies the new Arbitrum LPOOL contract. This is exchange-side corroboration, not identification of the corporate signatories. [F14]'],
 ['July 2024 reopening','Official post 1606 gives missed-window users another opportunity: KYC and old-token burning by midnight Friday 26 July; claim instructions follow. Messages 1609/1610 announce final claims. The earlier cutoff was not the last opportunity announced. [F15]'],
 ['Unizen partnership scope','The 3 May 2023 joint announcement identifies a strategic relationship. The later migration FAQ withholds guaranteed swaps for Unizen farming rewards. Contracts and any amendment/termination notice must distinguish partnership scope from reward authorization. [F16; S22-S23]'],
], [138,361])
p('Arbitrum LPOOL token: <font face="DVM" size="7.5">0xf6dae0d2be4993b00a2673360820af6bafd53887</font> [F14]','small')
h2('Records now targeted more precisely')
table([
 ['Record set','Question it resolves'],
 ['Nasoi appointment and handover','Exact start date, employing entity, delegated signing powers and transfer from earlier management.'],
 ['Migration eligibility and payouts','Legacy-chain burn logs, holder snapshot, KYC decisions, exceptions, new-token claim ledger and remaining reserve.'],
 ['Exchange and KYC mandates','Which entity instructed Gate and held the Sumsub client relationship, administration and customer-data responsibilities.'],
 ['Executed transfer documents','Assets/IP/customer contracts transferred to Carajo; consideration, liability assumptions and original issuer identity.'],
], [155,344])
p('Carajo\'s share register, February 2025 voting-owner records, SCR ownership, Linford restoration history and the named regulatory basis remain unresolved. The two Panama deeds remain obtained. No new signed transfer instrument or shareholder record was found; publicly identified operating management narrows only one part of the earlier gap.')

from laura_thread_content import add_thread
from onchain_pass2_content import add_pass2
from onchain_pass3_content import add_pass3
from onchain_pass4_content import add_pass4
from onchain_pass5_content import add_pass5
from onchain_pass6_content import add_pass6
from onchain_pass7_content import add_pass7
from onchain_pass8_content import add_pass8, apply_corrections
refs3=add_thread(B)
refs4=add_pass2(B)
refs5=add_pass3(B)
refs6=add_pass4(B)
refs7=add_pass5(B)
refs8=add_pass6(B)
refs9=add_pass7(B)
apply_corrections(B,[refs3,refs5,refs8])
refs10=add_pass8(B)
S=[]
def sp(t,k='small'):S.append({'kind':k,'text':t})
sp('Follow-up source register F01-F08','h')
sp('All live observations below were collected on 7 September 2026. Original S/D references remain on the preceding source pages. Source files and exact requests are indexed in the evidence bundle. Links identify records for review; they are not instructions to connect a wallet.','p')
refs=[
 ('F01','Registry record','https://rdap.centralnic.com/xyz/domain/launchpool.xyz','CentralNic RDAP; 04:58:45 UTC. website_sources/rdap.txt and network_receipts.json.'),
 ('F02','Two public DNS resolvers','https://dns.google/resolve?name=launchpool.xyz&amp;type=A','Google DNS and https://cloudflare-dns.com/dns-query; exact A/AAAA/app/www/NS/SOA requests and responses in website_sources/. Cloudflare checks at 05:00:55 UTC.'),
 ('F03','Archived application shell','https://web.archive.org/web/20260128012904/https://app.launchpool.xyz/','Capture 28 January 2026, 01:29:04 UTC. app_cdx_recent.txt and archived_app_source_record.json; original body hash retained. Static shell only; backend not tested.'),
 ('F04','Launchpool claim notices','https://t.me/s/launchpoolannouncements','Official channel linked from t.me/launchpoolxyz. Posts 1691-1694; complete post datetimes not exposed. Earlier deadlines superseded by F08.'),
 ('F05','Published final-claim files','https://mintlayerclaim.netlify.app/','claims.json and mintlayer_final_distro_readable.json recovered from the live UI. 1,999 records; hashes and exact CSVs in claims/.'),
 ('F06','Deployed distributor and on-chain state','https://etherscan.io/address/0xcc32853fb709666332cde0fc47f3f74119b970c4','Verified source via eth.blockscout.com; raw Ethereum RPC reads at block 25,923,249, transaction history and token events in claims/. Block hash 0xcbe553133f79829c8da8a4519d3944aa36c482c42cecc74a1986c05b5a22f912.'),
 ('F07','Independent claim reconciliation',None,'claims_peer/verify_claims.py; independent_validation.json and independent_reconciliation.json. Every allocation proof, bitmap flag, successful input and ML payment was checked against the preserved files. This is independent analysis of the same evidence, not an independent historical witness.'),
 ('F08','Current ML migration policy','https://www.mintlayer.org/ml-coin','Current policy states 1 November 2026 closure and processing every two weeks from 1 August. Separate UI: https://token.mintlayer.org/migration. No submission or mainnet delivery test. migration_support_sources/ preserves policy excerpts and retrieval metadata.'),
]
for id,title,url,note in refs:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
S.append({'kind':'break'});sp('Follow-up source register F09-F16','h')
refs2=[
 ('F09','Fresh GMI state and failed history queries','https://bsc-dataseed.bnbchain.org','gmi_sources/state_snapshot_batch.json; block 120,435,314 at 05:04:55 UTC; hash 0xf802d033535ff7f508288fc1546fa3d4e9045029967eef52c9c88860dee2605b. Exact selectors, responses and access limits preserved.'),
 ('F10','Prior GamiFi original-book study',None,'Research_Paper_GamiFi_Master_Investigation_2026-09-06.md, section 7, version 3; its 6 September 04:08:52 UTC observation at block 120,235,949 is carried forward. A dated extract and metadata are in prior_gmi_basis.json. Earlier research is not new corroboration.'),
 ('F11','2024 project status categories','https://t.me/s/launchpoolannouncements/1500','Post 1506 in this context; linked X status 1762833659093041216. GamiFi labeled Completed Vesting. Labels are distinguished from proof of delivery.'),
 ('F12','Launchpool public CEO representation','https://launchpool.medium.com/launchpool-spaces-recap-decentric-2b5923c3367b','Publisher date 26 July 2024; discussion date 19 July. Identifies Roxana Nasoi as CEO and Decentric as sister launchpad. No shareholder inference.'),
 ('F13','Labs public program and leadership','https://launchpoollabs.xyz/','Displayed 2024 program identifies Roxana Nasoi as CEO. Counterparty program corroboration: https://xdc.org/articles/xdc-weekly-jul-7 (15 July 2024). Exact date of any later staff-field change unknown.'),
 ('F14','Gate migration announcement','https://www.gate.com/announcements/article/36255/gate.io-supports-launchpool-lpool-token-migration','28 April 2024; ratio 1:1; service pause from 29 April 06:00 UTC; new Arbitrum address. Original Launchpool X references retained on source page.'),
 ('F15','July migration reopening','https://t.me/s/launchpoolannouncements/1606','Official context includes messages 1606, 1609 and 1610. Text specifies the 26 July 2024 burn/KYC deadline. Full primary message posting dates were not independently recovered.'),
 ('F16','Unizen issuer partnership announcement','https://www.globenewswire.com/news-release/2023/05/03/2660427/0/en/launchpool-and-unizen-announce-a-strategic-partnership.html','3 May 2023, issuer-supplied statement. Compare with preserved migration FAQ S22-S23; different partnership/reward scope may explain the later exclusion.'),
]
for id,title,url,note in refs2:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
S.append({'kind':'break'});sp('Follow-up source register F17-F26','h')
for id,title,url,note in refs3:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
S.append({'kind':'break'});sp('Follow-up source register F27-F31','h')
for id,title,url,note in refs4:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
S.append({'kind':'break'});sp('Follow-up source register F32-F38','h')
for id,title,url,note in refs5:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
S.append({'kind':'break'});sp('Follow-up source register F39-F45','h')
for id,title,url,note in refs6+refs7:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
S.append({'kind':'break'});sp('Follow-up source register F46-F50','h')
for id,title,url,note in refs8:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
S.append({'kind':'break'});sp('Follow-up source register F51-F54','h')
for id,title,url,note in refs9:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
S.append({'kind':'break'});sp('Follow-up source register F55-F58','h')
for id,title,url,note in refs10:
 sp(f'<b>{id} | {title}</b>')
 if url: sp(f'<link href="{url}" color="#25658a">{url}</link>')
 sp(escape(note))
sp('Preservation: factual records, exact ledgers, verification code, source metadata and SHA-256 hashes are bundled. Full third-party webpages/application bundles are represented by metadata or bounded extracts. Wallet control is not a personal identity.','small')

(R/'followup_content.json').write_text(json.dumps({'expected_body_pages':30,'expected_source_pages':9,'body':B,'sources':S},indent=2))
(R/'followup_source_register.json').write_text(json.dumps([{'id':a,'title':b,'url':c,'note':d} for a,b,c,d in refs+refs2+refs3+refs4+refs5+refs6+refs7+refs8+refs9+refs10],indent=2))
# Keep a compact readable source manuscript with the deliverable.
md=['# Launchpool follow-up integrated into the master report','', 'Research date: 7 September 2026 UTC','']
for b in B+S:
 if b['kind']=='break':md+=['','---',''];continue
 if b['kind']=='table':
  rows=b['rows'];md+=['| '+' | '.join(re.sub('<[^>]+>','',str(x)) for x in rows[0])+' |','| '+' | '.join('---' for x in rows[0])+' |']
  md+=['| '+' | '.join(re.sub('<[^>]+>','',str(x)) for x in row)+' |' for row in rows[1:]];md+=[''];continue
 text=b['text'].replace('<br/>','\n')
 text=re.sub(r'<b>(.*?)</b>',r'**\1**',text)
 text=re.sub(r'<link href="([^"]+)"[^>]*>(.*?)</link>',r'[\2](\1)',text)
 text=re.sub('<[^>]+>','',text).replace('&amp;','&')
 md += [('## ' if b['kind']=='h' else '### ' if b['kind']=='h2' else '')+text,'']
(R/'LAUNCHPOOL_FOLLOWUP_2026-09-07.md').write_text('\n'.join(md))
