# New Mintlayer Raise 1 reserve: 2.418 million ML remains in an earlier claim contract

**A census of all 24 unique Ethereum claim contracts listed in the recovered Launchpool project configuration found one additional nonzero reserve: 2,418,075.7303282383408825 ML in `0x9298136ec995aefb1e99fd4087080d3df328162f`.** The public application configuration identifies it as Mintlayer Raise 1, tranche 11, dated 16 July 2024 and displayed as 6%. Its owner getter identifies the same upstream administrative wallet, `0x77bfe8d704b1948374bf8dab8328a810b2836e66`, traced in the previous passes.

This is a newly located token balance in a different claim contract from the final Raise 2 distributor. The reserve is not a missing-funds amount, and its full remaining entitlement ledger has not been recovered. Past tranche allocations must not be added again to the final Raise 2 liabilities.

## Same-block census and final-distributor comparison

All census and final-distributor state below is pinned to **Ethereum block 25,923,764, 7 September 2026 06:43:59 UTC**, hash:

`0x8c2a3a90e518dc98e42a7e9bcafe09fee84b8bcc214d086ba76da0d11160946b`

| Scope at this block | Result |
|---|---|
| Configured earlier tranches | 24 entries, 24 unique addresses: 11 Raise 1 and 13 Raise 2 |
| Earlier tranches with zero ML | 23 |
| Earlier tranche with nonzero ML | Raise 1 tranche 11, address 9298: 2,418,075.7303282383408825 ML |
| Earlier addresses with empty current runtime | 14; owner/pause/root getters unavailable because no current code |
| Earlier addresses with current runtime | 10; all return owner 77bf, pause=false and ML as token |
| Final Raise 2 distributor, cc3285 | 1,116,041.281767546177360307 ML |
| Final Raise 2 published unclaimed ledger | 1,880 indices / 1,116,040.8456174469614254 ML |
| Final Raise 2 balance above unclaimed ledger | 0.436150099215934907 ML |

The final distributor's owner and immutable treasury remain `0x6c2b3a90acb72ef896325e19af9098d157f929c4`. Its root matches the previously verified 1,999-entry published ledger; all eight bitmap words were read at the same fresh block and still contain 119 claimed indices. This rechecks the final Raise 2 backing result while keeping the older Raise 1 balance separate.

Empty current runtime is a current-state observation, not a claim about an address's complete historical role or why its code disappeared. The census does not re-audit all 24 histories. The already reconciled 4d7b contract received only this common-block state refresh.

## Exact funding and payout accounting for 9298

The complete Etherscan token census comprises **1,001 events across eleven pages**. Every event uses the exact ML token contract `0x059956483753947536204e89bfad909e1a434cc6`; amounts were parsed from full-precision table tooltips and converted to integer base units.

| Flow | Events | Exact ML |
|---|---:|---:|
| Funding from 77bf on 16 July 2024 | 1 | 2,886,449.7276626812265525 |
| Outgoing payments recorded with the Claim method label | 1,000 | 468,373.99733444288567 |
| Remaining balance from all events | — | 2,418,075.7303282383408825 |
| Pinned ML balance from public RPC | — | 2,418,075.7303282383408825 |

All 1,000 outgoing payments go to distinct addresses. No ML transfer to owner 77bf appears in this complete token history. There is no observed ML return or sweep from this reserve in the retrieved events. The token reconciliation has no unexplained difference.

Exact source transactions:

- Creation by 77bf, **16 July 2024 16:19:11 UTC**: https://etherscan.io/tx/0x0d9ec8f3d8d3baa66cbc4d1f7c1111999e6a1f1eda4abaed1e6e29b079e6ff1a
- Funding 24 seconds later, **16 July 2024 16:19:35 UTC**: https://etherscan.io/tx/0xe922899677179395236b2204b87069ffb661cb499257d463808f40b8cf1823f2
- First outgoing payment, **17 July 2024 11:33:59 UTC**, 119.570905644655 ML: https://etherscan.io/tx/0xd8e07e44fdbc73222b911f7344b96558cfb546ed7144ce70854c63075f4cac36
- Last outgoing payment, **16 January 2026 22:55:47 UTC**, 856.286644907441 ML: https://etherscan.io/tx/0x882fa5c248ff26bd751a3c302b08682f9c733bb5c8f83a8c7d6b523c17c54c7e

The normal-transaction page advertises 1,006 transactions. This bounded lane retrieved its first and last pages, **106 rows**, including creation and 105 successful Claim calls. All 105 match the token beneficiary and sender. The remaining normal-call pages were not collected, and all 1,000 claim inputs/proofs were not independently decoded. Consequently the complete token-flow result is stronger than the partial call/proof census; the memo does not claim a full 1,000-proof audit.

## Administrative authority and claim access

At the common block, 9298 returns:

- Owner: **77bf**.
- Token: the exact ML address above.
- Root: `0x203f224dded0a827c8e18d16a08a9bb5111b55bfc9223a36ad79f3f371ed47ad`.
- `isClaimingPaused()`: **false**.
- `timelockDurationDays()`: **0**.
- `timelock()`: **1721146751**, corresponding to the creation timestamp **16 July 2024 16:19:11 UTC**.

The 3,739-byte runtime matches the earlier reviewed 4d7b runtime byte for byte after replacing only the two embedded immutable Merkle roots, at byte offsets 1650 and 2074. The token constant, owner check, withdrawal route and timelock-check instructions are identical. This gives a direct runtime comparison rather than relying solely on explorer method labels or a generic source file.

A fresh `eth_call` simulation of the withdrawal from owner 77bf completes, while the same call from a nonowner reverts with the owner-check reason. These are local read-only simulations, **not signed or submitted transactions**. The reserve was not withdrawn. The checked code path gives 77bf administrative withdrawal authority; it does not identify the human key holder or beneficial owner.

The full Solidity source is not newly verified by compilation in this lane. The control finding relies on identical selected runtime, getter values, the previous bounded bytecode review and the current simulations. All ten nonempty earlier runtimes match that reviewed implementation after their distinct roots are normalized.

The recovered Raise 1 configuration document was last updated **27 August 2024** and records this tranche's app `claimLocked` flag as false. Its listed proof path is `https://claims.launchpool.xyz/mintlayer1-11/`. A current retrieval of that exact path returned **HTTP 502**; the old complete allocation/proof file was not recovered. The stored app flag and on-chain pause state do not prove that users can currently obtain proofs or complete migration. Conversely, a failed page retrieval does not prove that the balance is irrecoverable or legally forfeited.

## Evidence, limits and next concrete gap

Primary preserved evidence consists of the recovered public application configuration, exact Ethereum RPC requests/responses at one block, and the complete Etherscan ML event tables. `census_summary.json`, `tranche_census.csv`, `reserve_history_summary.json`, `reserve_ml_events.csv` and `runtime_comparison.json` provide concise machine-readable results.

Both attempted Blockscout history endpoints returned HTTP 429 and were stopped; they were not immediately retried. A separate dRPC same-block crosscheck returned HTTP 500 and supplies no corroborating result. Etherscan's complete event arithmetic independently agrees with the successful Publicnode balance, but there is no completed second-RPC state census. The first simple fetch helper did not retain failed HTTP response headers; exact failed URL and UTC remain recorded. Later successful response bodies are hashed; transient public response cookie values are omitted from the retained request summary.

The most useful next records are the **complete Raise 1 tranche-11 allocation/proof file**, its reconciliation with earlier Raise 1 distributions and original purchases, and the operator's delivery/migration instructions for this still-held balance. The stored 6% display value must not be applied to a fundraising target to invent the full old liability: the funding may include carry-forward amounts, which require the original ledger to establish.

Nothing in this pass attributes the reserve to Laura personally, treats ML as the original BUSD fundraising cash, or establishes an automatic November 2026 payment to her. It identifies an additional live ML reserve, its wallet-level controller, its exact observed inflows/outflows, and a concrete proof-delivery gap.

Reproduce the derived results offline with `python analyze_census.py` and `python analyze_reserve.py`. The scripts named `census.py`, `fetch.py`, `fetch_token_pages.py`, `read_final.py`, `crosscheck.py` and `simulate_withdraw.py` perform public network reads and are not needed for the offline arithmetic. Exclude full external HTML from the evidence ZIP; retain the extracted events, source request metadata/hashes and all raw RPC responses.
