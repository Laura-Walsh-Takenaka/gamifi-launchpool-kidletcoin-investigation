from census import *
block=json.loads((P/'pinned_head.json').read_text())['result']['number'];A='0x9298136ec995aefb1e99fd4087080d3df328162f'
queries=[{'jsonrpc':'2.0','id':label,'method':'eth_call','params':[{'to':A,'from':sender,'data':'0x2eef326a'},block]} for label,sender in [('owner_eth_call_only','0x77bfe8d704b1948374bf8dab8328a810b2836e66'),('nonowner_eth_call_only','0x0000000000000000000000000000000000000001')]]
ans=rpc('reserve_withdraw_simulations',queries);print(ans)
