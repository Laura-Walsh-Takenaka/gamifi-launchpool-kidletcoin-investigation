from pathlib import Path
import json
from fetch import get,P
for page in range(2,11):
 get(f'https://etherscan.io/tokentxns?a=0x9298136ec995aefb1e99fd4087080d3df328162f&ps=100&p={page}',f'reserve_token_page{page}.html')
 rec=json.loads((P/'requests.json').read_text())[-1]
 if rec.get('status')!=200:
  print('STOPPED_AT_FIRST_FAILURE',page,flush=True);break
