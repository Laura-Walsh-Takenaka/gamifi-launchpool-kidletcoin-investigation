from census import *
block=json.loads((P/'pinned_head.json').read_text())['result']['number']
A='0xcc32853fb709666332cde0fc47f3f74119b970c4';reserve='0x9298136ec995aefb1e99fd4087080d3df328162f'
queries=[{'jsonrpc':'2.0','id':'final_balance','method':'eth_call','params':[{'to':ML,'data':'0x70a08231'+A[2:].zfill(64)},block]}]
for sig in ['owner()','treasury()','merkleRoot()','token()']:
 queries.append({'jsonrpc':'2.0','id':'final_'+sig,'method':'eth_call','params':[{'to':A,'data':'0x'+keccak256(sig.encode()).hex()[:8]},block]})
for word in range(8):
 slot='0x'+keccak256(word.to_bytes(32,'big')+(1).to_bytes(32,'big')).hex()
 queries.append({'jsonrpc':'2.0','id':f'final_claimed_word_{word}','method':'eth_getStorageAt','params':[A,slot,block]})
ans=rpc('final_same_pin',queries);print('FINAL',len(ans) if isinstance(ans,list) else ans)
