#!/usr/bin/env python3
"""Bounded read-only Ethereum tranche census at one block."""
from pathlib import Path
import json,urllib.request,urllib.error,datetime,hashlib,sys
P=Path(__file__).resolve().parent
BASE=P.parents[1];CFG=BASE/'onchain_pass3/archived_bsc_contracts/mintlayer_project_configuration.json'
URL='https://ethereum-rpc.publicnode.com';ML='0x059956483753947536204e89bfad909e1a434cc6'
sys.path.insert(0,str(BASE/'claims_peer'))
from verify_claims import keccak256

def rpc(name,queries):
 rec={'url':URL,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':queries,'network_mutation':False}
 try:
  req=urllib.request.Request(URL,data=json.dumps(queries).encode(),headers={'User-Agent':'Public-record-research/1.0','Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=45) as r:
   b=r.read();rec.update(status=r.status,headers={k:v for k,v in r.headers.items() if k.lower()!='set-cookie'},sha256=hashlib.sha256(b).hexdigest());(P/(name+'.json')).write_bytes(b);result=json.loads(b)
 except Exception as e:rec['error']=str(e);result=None
 (P/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2));return result

def config():
 entries=[]
 for d in json.loads(CFG.read_text()):
  f=d['fields']
  for i,a in enumerate(f['claimContractAddress']):entries.append({'project':f['slug'],'tranche':i+1,'address':a.lower(),'configured_date':f['claimDates'][i],'configured_percentage':f['claimPercentage'][i],'app_claimLocked':f['claimLocked'][i],'app_document_updated':d['updateTime'],'proof_path':f['claimProofsPath'][i]})
 assert len(entries)==24 and len({r['address'] for r in entries})==24
 (P/'configured_tranches.json').write_text(json.dumps(entries,indent=2));return entries

if __name__=='__main__':
 stage=sys.argv[1] if len(sys.argv)>1 else 'base';entries=config()
 if stage=='base':
  head=rpc('pinned_head',{'jsonrpc':'2.0','id':'head','method':'eth_getBlockByNumber','params':['latest',False]})
  if not head or not head.get('result'):print('HEAD FAILED');sys.exit(1)
  block=head['result']['number'];print('PINNED',int(block,16),flush=True)
  queries=[]
  for r in entries:
   a=r['address'];queries.extend([{'jsonrpc':'2.0','id':a+':balance','method':'eth_call','params':[{'to':ML,'data':'0x70a08231'+a[2:].zfill(64)},block]},{'jsonrpc':'2.0','id':a+':runtime','method':'eth_getCode','params':[a,block]}])
  for i in range(0,len(queries),12):
   ans=rpc(f'base_batch_{i//12}',queries[i:i+12]);print('BATCH',i//12,'OK' if isinstance(ans,list) else 'FAILED',flush=True)
   if not isinstance(ans,list):sys.exit(2)
 elif stage=='getters':
  block=json.loads((P/'pinned_head.json').read_text())['result']['number'];state={r['id']:r for f in sorted(P.glob('base_batch_[0-9].json')) for r in json.loads(f.read_text())};queries=[]
  for e in entries:
   a=e['address'];runtime=state[a+':runtime'].get('result')
   if runtime=='0x':continue
   if not runtime:print('MISSING_RUNTIME',a);continue
   for sig in ['owner()','token()','merkleRoot()','isClaimingPaused()','timelockDurationDays()','timelock()']:
    queries.append({'jsonrpc':'2.0','id':a+':'+sig,'method':'eth_call','params':[{'to':a,'data':'0x'+keccak256(sig.encode()).hex()[:8]},block]})
  for i in range(0,len(queries),12):
   ans=rpc(f'getter_batch_{i//12}',queries[i:i+12]);print('GETTERS',i//12,'OK' if isinstance(ans,list) else 'FAILED',flush=True)
   if not isinstance(ans,list):sys.exit(2)
