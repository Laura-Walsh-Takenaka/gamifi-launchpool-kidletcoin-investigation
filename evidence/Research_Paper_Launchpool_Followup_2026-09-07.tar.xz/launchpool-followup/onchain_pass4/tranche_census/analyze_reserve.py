#!/usr/bin/env python3
"""Offline full Etherscan ML-event census for the single nonzero tranche."""
from pathlib import Path
from decimal import Decimal,getcontext
import re,json,csv,html,datetime,collections
getcontext().prec=100
P=Path(__file__).resolve().parent
A='0x9298136ec995aefb1e99fd4087080d3df328162f';OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66';ML='0x059956483753947536204e89bfad909e1a434cc6'
def text(s):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>',' ',s))).strip()
def fmt(n):return str(Decimal(n)/10**18)
rows=[]
for page in range(1,12):
 s=(P/f'reserve_token_page{page}.html').read_text();assert 'A total of 1,001 txns found' in s
 for ordinal,row in enumerate(re.findall(r'<tr\b[^>]*>(.*?)</tr>',s,re.S)):
  tx=re.search(r'/tx/(0x[0-9a-fA-F]{64})',row)
  if not tx:continue
  addresses=re.findall(r'data-clipboard-text=[\'\"](0x[0-9a-fA-F]{40})[\'\"]',row);token=re.search(r'/token/(0x[0-9a-fA-F]{40})',row);amount=re.search(r'class="td_showAmount"[^>]*data-bs-title="([^"]+)"',row);stamp=re.search(r'class=[\'\"]showLocalDate[^>]*>(.*?)</td>',row,re.S);block=re.search(r'/block/(\d+)',row);method=re.search(r'data-title="([^"]+)"',row)
  assert len(addresses)==2 and token and amount and stamp and block,(page,ordinal)
  ts=int(text(stamp.group(1)));dec=amount.group(1).split('|')[0].strip().replace(',','');raw=Decimal(dec)*10**18;assert raw==raw.to_integral_value()
  rows.append({'page':page,'row':ordinal,'tx_hash':tx.group(1).lower(),'block':int(block.group(1)),'timestamp':ts,'utc':datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat(),'from':addresses[0].lower(),'to':addresses[1].lower(),'token':token.group(1).lower(),'amount_ml':dec,'raw_amount':str(int(raw)),'method_label':html.unescape(method.group(1)) if method else '', 'source_file':f'reserve_token_page{page}.html'})
assert len(rows)==1001 and len({r['tx_hash'] for r in rows})==1001
assert all(r['token']==ML and (r['from']==A or r['to']==A) for r in rows)
ins=[r for r in rows if r['to']==A];outs=[r for r in rows if r['from']==A];sumraw=lambda rs:sum(int(r['raw_amount']) for r in rs)
summary=json.loads((P/'census_summary.json').read_text());pinned=int(summary['nonzero_ML_rows'][0]['ML_raw']);assert sumraw(ins)-sumraw(outs)==pinned
normal=[]
for page in (1,11):
 s=(P/f'reserve_normal_page{page}.html').read_text();m=re.search(r"const quickExportTransactionListData = '(.*?)';",s,re.S);assert m
 for r in json.loads(m.group(1)):r['source_file']=f'reserve_normal_page{page}.html';normal.append(r)
nb={r['Txhash'].lower():r for r in normal};matches=[r for r in outs if r['tx_hash'] in nb]
assert all(nb[r['tx_hash']]['Status']=='Success' and nb[r['tx_hash']]['Sender'].lower()==r['to'] and nb[r['tx_hash']]['Receiver'].lower()==A for r in matches)
creation=[r for r in normal if not r['Receiver']]
assert len(creation)==1
out={'ML_event_count':len(rows),'distinct_tx_hashes':len({r['tx_hash'] for r in rows}),'complete_token_pages':11,'incoming_events':len(ins),'incoming_ML':fmt(sumraw(ins)),'funding_events':ins,'outgoing_events':len(outs),'outgoing_ML':fmt(sumraw(outs)),'unique_outgoing_recipients':len({r['to'] for r in outs}),'outgoing_method_labels':dict(collections.Counter(r['method_label'] for r in outs)),'outgoing_to_owner_events':len([r for r in outs if r['to']==OWNER]),'outgoing_to_owner_ML':fmt(sumraw([r for r in outs if r['to']==OWNER])),'net_ML':fmt(sumraw(ins)-sumraw(outs)),'net_matches_pinned_RPC_balance':True,'first_outgoing':min(outs,key=lambda r:r['timestamp']),'last_outgoing':max(outs,key=lambda r:r['timestamp']),'normal_history_total_advertised':1006,'normal_rows_actually_retrieved':len(normal),'normal_pages_actually_retrieved':[1,11],'successful_normal_claims_matched_to_outgoing_tokens':len(matches),'creation':creation[0],'limits':'The token-event census is complete as indexed by Etherscan and reconciles to public RPC state. The normal-call census is partial (first and last pages); all 1,000 call inputs/proofs were not independently decoded. Claim labels are explorer labels. No original full Raise 1 allocation file has been recovered in this lane; balance is not a proved outstanding-liability total.'}
(P/'reserve_ml_events.json').write_text(json.dumps(rows,indent=2));(P/'reserve_normal_subset.json').write_text(json.dumps(normal,indent=2));(P/'reserve_history_summary.json').write_text(json.dumps(out,indent=2))
with (P/'reserve_ml_events.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(sorted(rows,key=lambda r:r['block']))
print(json.dumps(out,indent=2))
