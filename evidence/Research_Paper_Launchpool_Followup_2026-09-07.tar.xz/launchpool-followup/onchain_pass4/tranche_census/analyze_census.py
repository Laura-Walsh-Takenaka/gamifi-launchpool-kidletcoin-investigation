#!/usr/bin/env python3
"""Offline arithmetic for the 24 configured tranches and same-block final distributor."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,csv,hashlib,datetime,collections
getcontext().prec=100
P=Path(__file__).resolve().parent;BASE=P.parents[1]
A='0x9298136ec995aefb1e99fd4087080d3df328162f';ML='0x059956483753947536204e89bfad909e1a434cc6'
head=json.loads((P/'pinned_head.json').read_text())['result'];entries=json.loads((P/'configured_tranches.json').read_text());state={r['id']:r for f in sorted(P.glob('base_batch_[0-9].json')) for r in json.loads(f.read_text())};getters={r['id']:r for f in sorted(P.glob('getter_batch_[0-9].json')) for r in json.loads(f.read_text())}
fmt=lambda n:str(Decimal(n)/10**18)
prior_runtime=(BASE/'onchain_pass3/old_ml_contract/pinned_runtime.txt').read_text().strip();prior_root='976c38db0b559280062fa4ae155dd9d9e310637f147a3dd8198449f131bfee8c'
normalized_prior=prior_runtime.replace(prior_root,'0'*64)
rows=[]
for e in entries:
 a=e['address'];bal=state[a+':balance']['result'];code=state[a+':runtime']['result'];assert len(bal)==66
 d={**e,'block':int(head['number'],16),'ML_raw':str(int(bal,16)),'ML_balance':fmt(int(bal,16)),'runtime_bytes':len(code[2:])//2,'runtime_sha256':hashlib.sha256(bytes.fromhex(code[2:])).hexdigest()}
 if code!='0x':
  for sig,key in [('owner()','owner'),('token()','token'),('merkleRoot()','merkle_root')]:
   val=getters[a+':'+sig]['result'];assert len(val)==66;d[key]=val if key=='merkle_root' else '0x'+val[-40:]
  d['is_claiming_paused']=bool(int(getters[a+':isClaimingPaused()']['result'],16));d['timelock_duration_getter']=int(getters[a+':timelockDurationDays()']['result'],16);d['timelock_unix']=int(getters[a+':timelock()']['result'],16);d['timelock_utc']=datetime.datetime.fromtimestamp(d['timelock_unix'],datetime.timezone.utc).isoformat();d['same_runtime_as_reviewed_4d7b_except_root']=code.replace(d['merkle_root'][2:],'0'*64)==normalized_prior;d['embedded_root_occurrences']=code.count(d['merkle_root'][2:]);assert d['token']==ML
 else:d['owner']='unavailable: empty current code';d['is_claiming_paused']='unavailable: empty current code'
 rows.append(d)
final={r['id']:r for r in json.loads((P/'final_same_pin.json').read_text())};bits=[]
for word in range(8):
 n=int(final[f'final_claimed_word_{word}']['result'],16);bits.extend(word*256+i for i in range(256) if n>>i&1)
ledger=json.loads((BASE/'claims/claims.json').read_text(encoding='utf-8-sig'));alloc=ledger['claims'];assert final['final_merkleRoot()']['result']==ledger['merkleRoot'];assert len(bits)==119 and max(bits)<1999
claimed=sum(int(r['amount'],16) for r in alloc.values() if r['index'] in bits);unclaimed=sum(int(r['amount'],16) for r in alloc.values() if r['index'] not in bits);balance=int(final['final_balance']['result'],16);nonzero=[r for r in rows if int(r['ML_raw'])>0]
summary={'pinned_block':int(head['number'],16),'pinned_block_hash':head['hash'],'pinned_utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'configured_entries':24,'unique_contracts':len({r['address'] for r in rows}),'nonzero_ML_addresses':len(nonzero),'zero_ML_addresses':sum(int(r['ML_raw'])==0 for r in rows),'empty_current_runtime_addresses':sum(r['runtime_bytes']==0 for r in rows),'nonempty_current_runtime_addresses':sum(r['runtime_bytes']>0 for r in rows),'nonempty_runtime_owner_counts':dict(collections.Counter(r['owner'] for r in rows if r['runtime_bytes']>0)),'nonempty_runtime_pause_counts':dict(collections.Counter(str(r['is_claiming_paused']) for r in rows if r['runtime_bytes']>0)),'nonempty_runtimes_equal_reviewed_template_except_root':all(r['same_runtime_as_reviewed_4d7b_except_root'] for r in rows if r['runtime_bytes']>0),'nonzero_ML_rows':nonzero,'final_distributor_same_block':{'address':'0xcc32853fb709666332cde0fc47f3f74119b970c4','owner':'0x'+final['final_owner()']['result'][-40:],'treasury':'0x'+final['final_treasury()']['result'][-40:],'token':'0x'+final['final_token()']['result'][-40:],'merkle_root':final['final_merkleRoot()']['result'],'claimed_indices':len(bits),'unclaimed_indices':1999-len(bits),'claimed_ML':fmt(claimed),'unclaimed_ML':fmt(unclaimed),'ML_balance':fmt(balance),'ML_above_unclaimed_ledger':fmt(balance-unclaimed),'all_eight_bitmap_words_checked':True},'scope_note':'The Raise 1 residual balance is token custody, not a verified count/value of remaining obligations. Final Raise 2 ledger is independently reconciled; do not sum earlier tranche allocations into its liabilities. Empty current code is not a full-history assertion.'}
(P/'census_summary.json').write_text(json.dumps(summary,indent=2));(P/'census_rows.json').write_text(json.dumps(rows,indent=2))
with (P/'tranche_census.csv').open('w') as f:
 keys=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
print(json.dumps(summary,indent=2))
