import census
from census import *
census.URL='https://eth.drpc.org'
block=json.loads((P/'pinned_head.json').read_text())['result']['number'];A='0x9298136ec995aefb1e99fd4087080d3df328162f';FINAL='0xcc32853fb709666332cde0fc47f3f74119b970c4'
q=[{'jsonrpc':'2.0','id':'same_block','method':'eth_getBlockByNumber','params':[block,False]}, {'jsonrpc':'2.0','id':'reserve_balance','method':'eth_call','params':[{'to':ML,'data':'0x70a08231'+A[2:].zfill(64)},block]}, {'jsonrpc':'2.0','id':'reserve_owner','method':'eth_call','params':[{'to':A,'data':'0x8da5cb5b'},block]}, {'jsonrpc':'2.0','id':'final_balance','method':'eth_call','params':[{'to':ML,'data':'0x70a08231'+FINAL[2:].zfill(64)},block]}]
ans=rpc('drpc_crosscheck',q);print('CROSSCHECK',len(ans) if isinstance(ans,list) else ans)
