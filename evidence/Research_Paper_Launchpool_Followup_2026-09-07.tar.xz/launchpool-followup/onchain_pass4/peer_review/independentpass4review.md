# Independent pass-4 review

Reviewed 7 September 2026 UTC. **Disposition: PASS for the balance census, completed token-event reconciliation and bounded D975 runtime findings, with the evidentiary limits below preserved.** All checks used saved public responses and local computation; no new network calls or signed transactions were made. Other agents' files and the master report were not edited.

## 1. The additional ML custody balance is confirmed

I independently checked the raw balance request destinations, selectors, response values and pinned block for all **24 unique configured tranche addresses**. At Ethereum block **25,923,764**, hash `0x8c2a3a90e518dc98e42a7e9bcafe09fee84b8bcc214d086ba76da0d11160946b`, **7 September 2026 at 06:43:59 UTC**, 23 have zero ML and one has a nonzero balance:

`0x9298136ec995aefb1e99fd4087080d3df328162f` holds **2,418,075.7303282383408825 ML**.

The independently checked current application document maps this address to **Mintlayer Raise 1, tranche 11**, displayed date **16 July 2024**, displayed percentage **6%**. The exact ML token getter matches `0x059956483753947536204e89bfad909e1a434cc6`. The owner getter returns `0x77bfe8d704b1948374bf8dab8328a810b2836e66`, the pause getter is false, and the timelock duration getter is zero. These are current contract/configuration observations, not a dated purchase-contract interpretation.

I also checked the saved, same-block withdrawal simulations: the request from 77bf completes and the otherwise identical nonowner request reverts at the owner check. Both are `eth_call` only. This is consistent with current withdrawal authority; no actual reserve withdrawal occurred in this review.

All ten addresses with nonempty current runtime have code exactly equal to the previously reviewed 4d7 runtime after replacing the two embedded immutable Merkle roots. Their owner getters all return 77bf and their pause getters all return false. Fourteen configured addresses currently have empty runtime. That does not establish that those addresses never contained code or explain their historical disposition.

## 2. The newly retrieved 9298 token history reconciles exactly

Using a separate parser, I reread **all eleven original token-history HTML pages**, extracting the full-precision amount tooltips rather than rounded visible values. Pages 1–10 each contain 100 transfer rows and page 11 contains one. All **1,001 independently parsed event tuples** match the retained JSON ledger, including transaction hash, block, sender, recipient, exact token address, base-unit amount and method label.

| Movement | Events | ML |
|---|---:|---:|
| Funding from 77bf | 1 | 2,886,449.7276626812265525 |
| Outgoing transfers | 1,000 | 468,373.99733444288567 |
| Funding minus outgoing transfers | — | 2,418,075.7303282383408825 |

There are 1,000 distinct outgoing recipients and no outgoing ML transfer to the current owner. All outgoing rows carry the explorer's Claim label. The normal-transaction subset contains **106 records**, including **105 successful claims** matched to corresponding outgoing transfers; that subset is not the complete advertised 1,006-record normal history. The full 1,000 calldata/proof sets were not independently decoded.

The correct report wording is therefore **1,000 outgoing ML transfers labeled Claim**, with a complete token-event arithmetic reconciliation. Do not upgrade this into a claim that all 1,000 cryptographic proofs and normal transaction receipts were independently verified. The observed balance is token custody, not a proved total of outstanding investor liabilities; the original full tranche allocation has not been recovered.

## 3. The final distributor was independently checked at the same block

All eight final-distributor bitmap words reproduce the previously verified set of **119 claimed indices**, leaving **1,880 unclaimed**. Reapplying that set to the retained 1,999-row allocation ledger gives **1,116,040.8456174469614254 ML** unclaimed. The same-block balance is **1,116,041.281767546177360307 ML**, leaving the previously documented **0.436150099215934907 ML** surplus. Owner, treasury and root are unchanged.

The extra 9298 balance and the final distributor's reconciled liabilities must remain distinct. Adding their token balances describes combined observed custody only; it does not establish a combined unpaid-liability figure or missing funds.

## 4. D975 withdrawal recipient and accounting path are now supported by its own runtime

I compared the fresh D975 `eth_getCode` result with the previously preserved deployed code. They match exactly: **12,612 bytes**, SHA256 `34aaf9e747ed09ee4655869f287158525de2a1f3f50961e477fcd12171a4ef0d`. This review does not import the different generic Solidity 0.6.12 source.

The actual dispatcher maps selector `0x67a49923` to wrapper `0x02e9`, then body `0x0bd2`. The selected path establishes:

- A reentrancy guard in storage slot 1.
- Caller obtained by helper `0x1f34` (CALLER), compared with the masked address from owner helper `0x12e3` (storage slot 0). A mismatch reverts.
- Bounds and rewards-configured checks before the claimed flag.
- Claimed flag read and set in the mapping at storage slot **17**, keyed by pool ID.
- Transfer amount read from the mapping at slot **15**, keyed by pool ID, matching the total-raised getter's layout.
- ERC-20 call target taken from the pool structure's fundraising-token field.
- Transfer calldata that encodes **`transfer(owner(), totalRaised[pid])`**. The recipient is the owner address read at execution time, not a permanently hard-coded 77bf address.

The four saved real `eth_call` simulations are correctly read-only and pinned to BSC block **120,448,587**. Nonowner calls for pools 19 and 125 revert at the owner check. Calls simulated from current owner 77bf pass that check and revert because the funds are already claimed. Raw storage-slot requests independently confirm the relevant mapping positions and the previously recorded pool-19 and pool-125 amounts.

### Material limitation: token return value is discarded

After the ERC-20 CALL, the runtime checks low-level call success and decodes the expected returned boolean. The decoded bool is then **discarded at `0x0da3`**; it is not required to be true. I confirmed the data flow with a small local interpreter of the actual selected bytecode path using explicitly synthetic pool storage and token responses:

- A synthetic true token return finishes, sets the claimed flag and emits the fundraising event.
- A synthetic false token return also finishes, sets the claimed flag and emits the event.
- Synthetic nonowner and already-claimed cases revert before making a token call.

This local counterfactual check is **not evidence that BUSD returned false in any historical transaction**. Its implication is narrower: the claimed flag or fundraising event alone is not an independent substitute for the actual BUSD Transfer receipt. Historical withdrawal transaction hashes, owners at those blocks, and token-transfer logs are still needed to name the actual recipients and confirm the movements.

## Report implications

The new runtime analysis supports a precise statement that D975's examined withdrawal path sends the configured fundraising token to the owner address at execution time, using the pool's recorded raised amount. It does not establish that today's owner was the owner at every historical withdrawal, that a claimed flag proves transfer success, that funds were stolen, or that Laura controls a wallet or exchange account.

The additional 9298 balance is materially new, fully reconciled custody evidence. Preserve the incomplete normal-call/proof coverage and the lack of a recovered complete tranche allocation when describing it.

## Saved independent checks

Run in this order from this directory to reproduce the combined review records:

1. `python independent_pass4_checks.py`
2. `python d975_selected_path_emulator.py`
3. `python independent_reserve_history.py`
4. `python independent_final_state.py`

Results: `independentpass4review.json`, `d975_selected_path_emulator.json`, `independent_reserve_history.json`, and `independent_final_state.json`. The interpreter is deliberately limited to the reviewed path and is not a general-purpose EVM or a full smart-contract audit.
