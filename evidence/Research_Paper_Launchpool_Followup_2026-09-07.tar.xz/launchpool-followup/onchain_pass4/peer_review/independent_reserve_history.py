#!/usr/bin/env python3
"""Reparse full-precision transfer rows and compare retained census, offline."""
import pathlib,json,re,html,collections,decimal
P=pathlib.Path(__file__).resolve().parent;Q=P.parent/'tranche_census';D=decimal.Decimal;decimal.getcontext().prec=100
A='0x9298136ec995aefb1e99fd4087080d3df328162f';ML='0x059956483753947536204e89bfad909e1a434cc6';O='0x77bfe8d704b1948374bf8dab8328a810b2836e66'
rows=[];page_counts={}
for page in range(1,12):
 p=Q/f'reserve_token_page{page}.html';text=p.read_text();n=0
 for tr in re.findall(r'<tr\b[^>]*>(.*?)</tr>',text,re.S|re.I):
  tx=re.search(r'/tx/(0x[0-9a-f]{64})',tr,re.I)
  if not tx:continue
  token=re.search(r'/token/(0x[0-9a-f]{40})',tr,re.I)
  if not token:continue
  addresses=re.findall(r'data-clipboard-text=[\"\'](0x[0-9a-f]{40})[\"\']',tr,re.I);assert len(addresses)==2,(page,addresses)
  amt=re.search(r'class=[\"\']td_showAmount[\"\'][^>]*data-bs-title=[\"\']([^|]+)\|',tr,re.I);assert amt
  exact=D(html.unescape(amt[1]).strip().replace(',',''));raw=exact*10**18;assert raw==raw.to_integral_value()
  block=int(re.search(r'/block/(\d+)',tr)[1]);method=html.unescape(re.search(r'class=[\"\']td_functionNameOri[\"\'][^>]*>.*?data-title=[\"\']([^\"\']+)',tr,re.S)[1])
  rows.append((tx[1].lower(),block,addresses[0].lower(),addresses[1].lower(),token[1].lower(),int(raw),method));n+=1
 page_counts[page]=n
assert page_counts=={**{p:100 for p in range(1,11)},11:1}
facts=json.loads((Q/'reserve_ml_events.json').read_text());expected=[(r['tx_hash'].lower(),r['block'],r['from'],r['to'],r['token'],int(r['raw_amount']),r['method_label']) for r in facts]
assert collections.Counter(rows)==collections.Counter(expected)
assert len(rows)==len({r[0] for r in rows})==1001
incoming=[r for r in rows if r[3]==A];outgoing=[r for r in rows if r[2]==A];assert len(incoming)==1 and len(outgoing)==1000
assert all(r[4]==ML for r in rows) and all(r[6]=='Claim' for r in outgoing)
assert len({r[3] for r in outgoing})==1000 and all(r[3]!=O for r in outgoing)
a=sum(r[5] for r in incoming);b=sum(r[5] for r in outgoing);assert a==2886449727662681226552500 and b==468373997334442885670000
assert a-b==2418075730328238340882500
normal=json.loads((Q/'reserve_normal_subset.json').read_text());assert len(normal)==106
normal_claims=[r for r in normal if r['Method']=='Claim' and r['Status']=='Success'];assert len(normal_claims)==105
outby={r[0]:r for r in outgoing}
for r in normal_claims:
 t=outby[r['Txhash'].lower()];assert t[3]==r['Sender'].lower() and t[1]==int(r['Blockno'])
result={'pass':True,'independent_html_reparse':True,'full_precision_tooltip_amounts_used':True,'page_row_counts':page_counts,'all_1001_event_tuples_match_retained_census':True,'incoming_events':1,'incoming_ml':str(D(a)/10**18),'outgoing_events':1000,'outgoing_ml':str(D(b)/10**18),'distinct_outgoing_recipients':1000,'outgoing_owner_transfers':0,'net_ml':str(D(a-b)/10**18),'normal_subset_records':106,'normal_subset_successes_matched':105,'normal_history_incomplete':True,'all_1000_proofs_not_validated':True,'balance_not_a_proved_liability_total':True}
(P/'independent_reserve_history.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
r=json.loads((P/'independentpass4review.json').read_text());r['census']['token_history_review_pending']=False;r['census']['history_review']=result;(P/'independentpass4review.json').write_text(json.dumps(r,indent=2))
