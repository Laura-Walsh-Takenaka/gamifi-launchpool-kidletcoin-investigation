#!/usr/bin/env python3
"""Offline independent state/call provenance and selected-runtime checks."""
import pathlib,json,hashlib,sys,datetime
from decimal import Decimal
P=pathlib.Path(__file__).resolve().parent;Q=P.parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
ML='0x059956483753947536204e89bfad909e1a434cc6';O='0x77bfe8d704b1948374bf8dab8328a810b2836e66';A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';T='0x9298136ec995aefb1e99fd4087080d3df328162f'
def J(p):return json.loads(p.read_text())
def selector(s):return '0x'+keccak256(s.encode()).hex()[:8]
C=Q/'tranche_census';head=J(C/'pinned_head.json')['result'];pin=head['number'];records=J(C/'configured_tranches.json');assert len(records)==24 and len({r['address'] for r in records})==24
source=J(P.parents[1]/'onchain_pass3/archived_bsc_contracts/mintlayer_project_configuration.json');rows={d['fields']['slug']:d['fields'] for d in source}
for r in records:
 f=rows[r['project']];i=r['tranche']-1
 assert r['address']==f['claimContractAddress'][i].lower() and r['configured_date']==f['claimDates'][i] and r['configured_percentage']==f['claimPercentage'][i]
state={};request_ids=set()
for f in sorted(C.glob('base_batch_[0-9].json')):
 batch=J(f);rq=J(C/(f.stem+'.receipt.json'))['request'];qs={r['id']:r for r in rq}
 for r in batch:
  assert 'result' in r and r['id'] not in state
  state[r['id']]=r['result'];request=qs[r['id']];assert request['params'][-1]==pin
  address,kind=r['id'].split(':')
  if kind=='balance':assert request['method']=='eth_call' and request['params'][0]=={'to':ML,'data':selector('balanceOf(address)')+'0'*24+address[2:]}
  else:assert kind=='runtime' and request['method']=='eth_getCode' and request['params'][0]==address
  request_ids.add(r['id'])
assert len(state)==48
balances={r['address']:int(state[r['address']+':balance'],16) for r in records};nonzero={a:v for a,v in balances.items() if v};assert nonzero=={T:2418075730328238340882500}
getters={}
for f in sorted(C.glob('getter_batch_[0-9].json')):
 batch=J(f);rq={r['id']:r for r in J(C/(f.stem+'.receipt.json'))['request']}
 for r in batch:
  address,sig=r['id'].split(':');assert rq[r['id']]['method']=='eth_call' and rq[r['id']]['params']==[{'to':address,'data':selector(sig)},pin]
  assert 'result' in r;getters[r['id']]=r['result']
assert '0x'+getters[T+':owner()'][-40:]==O and '0x'+getters[T+':token()'][-40:]==ML
assert int(getters[T+':isClaimingPaused()'],16)==0 and int(getters[T+':timelockDurationDays()'],16)==0
tranche=next(r for r in records if r['address']==T);assert tranche['tranche']==11 and tranche['project']=='mintlayer' and tranche['configured_percentage']=='6%' and tranche['configured_date']=='16th July 2024'
oldruntime=bytes.fromhex((P.parents[1]/'onchain_pass3/old_ml_contract/pinned_runtime.txt').read_text().strip()[2:]);newruntime=bytes.fromhex(state[T+':runtime'][2:]);oldroot=bytes.fromhex('976c38db0b559280062fa4ae155dd9d9e310637f147a3dd8198449f131bfee8c');newroot=bytes.fromhex(getters[T+':merkleRoot()'][2:]);assert oldruntime.count(oldroot)==newruntime.count(newroot)==2
assert oldruntime.replace(oldroot,bytes(32))==newruntime.replace(newroot,bytes(32))
D=Q/'bsc_runtime';mapping=J(D/'rpc_request_map.json');batch=J(D/'selected_runtime_checks.json');rs={r['id']:r for r in batch};receipts=J(D/'rpc_receipts.json');rqs={r['id']:r for r in next(r['request'] for r in receipts if r['name']=='selected_runtime_checks')}
assert all(r['params'][-1]==mapping['block'] for r in rqs.values())
assert rqs[1]['method']=='eth_call' and rqs[1]['params'][0]=={'to':A,'data':selector('owner()')}
assert rs[1]['result']==rs[7]['result'] and '0x'+rs[1]['result'][-40:]==O
runtime=bytes.fromhex(rs[2]['result'][2:]);cached=(P.parents[1]/'onchain_pass3/archived_bsc_contracts/d975_deployed_bytecode.txt').read_text().strip();assert rs[2]['result']==cached
assert bytes.fromhex('6367a49923146102e957') in runtime[:0x211]
assert runtime[0x2e9:0x2fc].hex()=='5b6102786102f7366004612344565b610bd256'
assert runtime[0x12e3:0x12f2].hex()=='5b6000546001600160a01b03169056'
assert runtime[0x1f34:0x1f38].hex()=='5b339056'
for rid,pid,caller in [(3,19,'0x1111111111111111111111111111111111111111'),(4,125,'0x1111111111111111111111111111111111111111'),(5,19,O),(6,125,O)]:
 rq=rqs[rid];assert rq['method']=='eth_call';args=rq['params'][0];assert args['from']==caller and args['to']==A and args['data']==selector('claimFundRaising(uint256)')+format(pid,'064x')
 assert ('Ownable: caller is not the owner' if rid<5 else 'Already claimed funds') in rs[rid]['error']['message']
for pid,ridset in [(19,[10,11,12]),(125,[13,14,15])]:
 for rid,slot in zip(ridset,[7,15,17]):
  assert rqs[rid]['method']=='eth_getStorageAt' and rqs[rid]['params'][0]==A and rqs[rid]['params'][1]=='0x'+keccak256(pid.to_bytes(32)+slot.to_bytes(32)).hex()
 assert int(rs[ridset[2]]['result'],16)==1
results={'review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state_runtime_checks_pass':True,'census':{'configured_unique_addresses':24,'pinned_block':int(pin,16),'pinned_hash':head['hash'],'pinned_utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'zero_balances':23,'nonzero_address':T,'nonzero_ml_raw':str(nonzero[T]),'nonzero_ml':str(Decimal(nonzero[T])/10**18),'project':'Mintlayer Raise 1','tranche':11,'displayed_date':'16th July 2024','displayed_percentage':'6%','owner':O,'onchain_paused':False,'timelock_duration_days':0,'9298_runtime_equals_4d7_after_two_root_replacements':True,'balance_is_not_unpaid_entitlement_calculation':True,'token_history_review_pending':True},'d975':{'fresh_runtime_equals_preserved_runtime':True,'runtime_bytes':len(runtime),'runtime_bytes_sha256':hashlib.sha256(runtime).hexdigest(),'pinned_block':mapping['block_decimal'],'selector':'0x67a49923','owner_getter_and_slot_0_agree':True,'all_four_raw_simulations_are_readonly_and_correctly_pinned':True,'nonowner_reverts_owner_check':True,'owner_reverts_already_claimed':True,'amount_mapping_slot':15,'claimed_flag_mapping_slot':17,'recipient_is_current_owner_at_call_time':True,'token_target_is_pool_fundraising_token':True,'decoded_token_return_boolean_is_discarded':True,'historical_beneficiary_and_actual_transfer_receipts_still_required':True,'generic_0612_source_not_used_as_proof':True}}
(P/'independentpass4review.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
