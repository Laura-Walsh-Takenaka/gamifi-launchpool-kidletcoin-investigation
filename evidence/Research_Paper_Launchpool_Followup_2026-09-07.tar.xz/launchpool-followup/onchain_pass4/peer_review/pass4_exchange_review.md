# Independent pass 4 review: shared counterparty and Base

Result: **PASS for the preserved evidence and arithmetic.** No new network queries were made. The independent checker is `pass4_exchange_check.py`; its machine-readable results are `pass4_exchange_review.json`. This review covers pass 4 only, including the first Base return, and excludes any separate pass 5 continuation.

## Ethereum flows

The 67 exact-token ML events and 322 USDC events each reconcile to a zero net balance for wallet `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4`. Zero-value USDC rows are included in the event count; the count should not be presented as 322 positive payments.

I independently reparsed the full-precision amounts from the retained intermediary `980b` explorer HTML. Its 41 ML events comprise 21 receipts and 20 outgoing transfers. The 20 receipts from `183600` total 1,234,268.124 ML and match the separate source-wallet history by transaction hash and raw amount. A further 21,890.76 ML came from `3b883`. The combined 1,256,158.884 ML exactly equals 1,069,905.362 ML sent to the MEXC 1 labeled address plus 186,253.522 ML sent to the MEXC 3 labeled address. All 20 outgoing normal transaction records report success. The exchange labels identify services, not their customers, and these deposits do not establish executed exchange sales.

The Gate deposit HTML independently yields two incoming ML transfers totaling 118,172 ML and one equal onward transfer to the Gate labeled address. The 10 USDC payments to the KuCoin labeled deposit total exactly 693,701.8471 USDC. Each matches a successful normal transaction whose direct ERC-20 transfer input names that recipient and the exact amount.

Fourteen direct vesting transfers total 525,000 ML. This review independently checks those transfers and their arithmetic, but does not repeat the sibling lane's individual Merkle proof verification. Nine representative successful Ethereum RPC receipts were independently decoded and matched to their expected token, sender, recipient and amount. The full event and normal-call history checks must remain distinct from this representative raw RPC coverage.

## Bridges and trading

All three reviewed Circle CCTP messages match byte for byte across the source MessageSent event, Circle message record and destination receiveMessage input. The supplied attestation bytes also match the destination input. Each destination has a successful raw receipt with the exact native USDC mint to the same wallet. The three routes are:

| Direction | Nonce | USDC |
| --- | ---: | ---: |
| Ethereum to Base | 81239 | 2,100 |
| Ethereum to Base | 81473 | 25,000 |
| Base to Ethereum | 235711 | 21,116.99 |

This review checks message structure, domains, nonces, recipient, amount, message hash and execution evidence. It does not independently perform Circle attestation signature verification; the successful destination execution accepted the retained input.

I independently rebuilt the 22 trades from successful Base RPC receipts, matching all 66 relevant transfer logs to the explorer ledger. Eight purchases spent 20,100 USDC and acquired 3,911,181.851848323949800498 BAMBOO. Fourteen sales received 73,854.395784 USDC for 3,911,181.851848323949800497 BAMBOO. The cash difference is therefore positive 53,754.395784 USDC before native ETH gas, with one raw BAMBOO unit remaining. This is a token cash difference, not a fiat profit or an identified person's entitlement.

The first 21,116.99 USDC return on 18 July did not liquidate the inventory: the wallet still held 0.008523 USDC and 1,911,181.851848323949800498 BAMBOO immediately afterward. Comparing 27,100 USDC of bridge receipts with only that first return would therefore give an invalid loss measure. The return's Ethereum mint and subsequent payment to `1991` have matching successful receipts.

## Inventory provenance and scope

The originally omitted inventory POST mappings are now documented in two expressly labeled reconstruction files. I checked the response hashes, endpoint, exact token and wallet mappings, response identifiers and historical/current block tags. These records reconstruct the executed requests from retained tool-call source; they are not contemporaneous request captures. The reproducibility gap is resolved with that provenance limitation disclosed.

The pre-mint snapshot at Base block 16,925,276 reads zero for both USDC and BAMBOO. Independently summing the full retained USDC and BAMBOO event ledger through the later snapshot blocks agrees with both post-return balances at block 17,255,170 and the current balances at block 50,987,229: 0.003937 USDC and one raw BAMBOO unit. The first failed current BAMBOO request is not interpreted as a zero balance; the successful same-block retry supplies the one-unit result. Later USDC activity is outside the July trade-only cash calculation.

The complete indexed Base token census contains 505 rows. This does not claim a complete normal-transaction or internal-transaction census, nor assign value to unrelated dust tokens.

## Content review and attribution

Sections 9.17 and 9.18 and references F42-F43 preserve the material evidence distinctions. The mixed Ethereum USDC ledger does not establish exclusive IAG proceeds as the Base source, nor link this trading to original Mintlayer BUSD purchases or to withdrawal of the still-held ML reserves. No human trader, exchange customer, company authorization or ultimate beneficiary is established.

The minor table wording correction has been applied and checked: “14 July: first two BAMBOO sales” correctly identifies the two transactions totaling 2,000,000 BAMBOO and 14,116.998523 USDC. The reviewed `onchain_pass4_content.py` SHA-256 is `a2bb7d484f073205c1587f8ea222336383b190e3e1b95535641280436c14906b`. There are no remaining actionable corrections from this review.
