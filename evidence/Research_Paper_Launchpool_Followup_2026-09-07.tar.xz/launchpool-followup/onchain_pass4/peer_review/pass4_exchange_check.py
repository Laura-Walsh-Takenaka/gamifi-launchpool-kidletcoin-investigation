#!/usr/bin/env python3
"""Independent offline checks of preserved shared-wallet and Base evidence."""
import pathlib,json,collections,decimal,re,html,sys,hashlib
P=pathlib.Path(__file__).resolve().parent;S=P.parent/'shared_counterparty';B=S/'base_continuation';D=decimal.Decimal;decimal.getcontext().prec=100
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
A='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4';ML='0x059956483753947536204e89bfad909e1a434cc6';EU='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';BU='0x833589fcd6edb6e08f4c7c32d4f71b54bda02913';BAM='0x689644b86075ed61c647596862c7403e1c474dbf';M='0x980bff583a8133600462bc034871dc548d6bfc84';G='0xa775134ffa4ee261dea9c04ab364897b4bb9f302';K='0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee';ZERO='0x'+'0'*40
TRANS='0x'+keccak256(b'Transfer(address,address,uint256)').hex();MSENT='0x'+keccak256(b'MessageSent(bytes)').hex()
def J(p):return json.loads(p.read_text())
def parsestandard(p,token):
 rows=[]
 for tr in re.findall(r'<tr\b[^>]*>(.*?)</tr>',p.read_text(),re.S|re.I):
  tx=re.search(r'/tx/(0x[0-9a-f]{64})',tr,re.I);tok=re.search(r'/token/(0x[0-9a-f]{40})',tr,re.I)
  if not tx or not tok or tok[1].lower()!=token:continue
  addresses=re.findall(r'data-clipboard-text=[\"\'](0x[0-9a-f]{40})[\"\']',tr,re.I);assert len(addresses)==2
  amt=re.search(r'class=[\"\']td_showAmount[\"\'][^>]*data-bs-title=[\"\']([^|]+)\|',tr,re.I);assert amt
  amount=D(html.unescape(amt[1]).strip().replace(',',''));block=int(re.search(r'/block/(\d+)',tr)[1]);rows.append((tx[1].lower(),block,addresses[0].lower(),addresses[1].lower(),tok[1].lower(),amount))
 return rows
ml=J(S/'ML_events.json');us=J(S/'USDC_events.json');normal={t['hash']:t for t in J(S/'normal_transactions_api.json')['result']}
for rows,tok,count in [(ml,ML,67),(us,EU,322)]:
 assert len(rows)==count and all(r['contractAddress'].lower()==tok for r in rows)
 assert sum((int(r['value']) if r['to'].lower()==A else 0)-(int(r['value']) if r['from'].lower()==A else 0) for r in rows)==0
mrows=sum((parsestandard(S/f'980b_tokens{i}.html',ML) for i in [1,2,3]),[]);assert len(mrows)==41
mjson=J(S/'980b_summary.json')['events'];assert collections.Counter(mrows)==collections.Counter((r['tx_hash'],r['block'],r['from'],r['to'],r['token'],D(r['amount'])) for r in mjson)
m_in=[r for r in mrows if r[3]==M];m_out=[r for r in mrows if r[2]==M];assert len(m_in)==21 and len(m_out)==20
assert sum(r[5] for r in m_in if r[2]==A)==D('1234268.124')
assert sum(r[5] for r in m_in if r[2]!=''+A)==D('21890.76')
assert sum(r[5] for r in m_out if r[3]=='0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88')==D('1069905.362')
assert sum(r[5] for r in m_out if r[3]=='0x3cc936b795a188f0e246cbb2d74c5bd190aecf18')==D('186253.522')
assert sum(r[5] for r in m_in)==sum(r[5] for r in m_out)==D('1256158.884')
mn={r['Txhash'].lower():r for r in J(S/'980b_normal.json')}
for r in m_out:assert mn[r[0]]['Status']=='Success' and mn[r[0]]['Sender'].lower()==M and mn[r[0]]['Receiver'].lower()==ML
cross={(r['hash'],int(r['value'])) for r in ml if r['from'].lower()==A and r['to'].lower()==M};assert cross=={(r[0],int(r[5]*10**18)) for r in m_in if r[2]==A}
grows=parsestandard(S/'a775_tokens1.html',ML);assert len(grows)==3
assert sum(r[5] for r in grows if r[3]==G)==sum(r[5] for r in grows if r[2]==G)==D(118172)
assert {r[2] for r in grows if r[3]==G}=={A} and {r[3] for r in grows if r[2]==G}=={'0x0d0707963952f2fba59dd06f2b425ace40b492fe'}
krows=[r for r in us if r['from'].lower()==A and r['to'].lower()==K];assert len(krows)==10 and sum(int(r['value']) for r in krows)==693701847100
for r in krows:
 t=normal[r['hash']];assert t['from'].lower()==A and t['to'].lower()==EU and t['isError']=='0' and t['txreceipt_status']=='1';data=bytes.fromhex(t['input'][2:]);assert data[:4].hex()=='a9059cbb' and len(data)==68 and '0x'+data[16:36].hex()==K and int.from_bytes(data[36:])==int(r['value'])
vesting=[r for r in ml if r['from'].lower()==ML and r['to'].lower()==A];assert len(vesting)==14 and sum(int(r['value']) for r in vesting)==525000*10**18
# Actual successful receipt logs: preserve selection coverage instead of implying full-history RPC coverage.
eth_receipts={}
for file in ['selected_rpc.json','return_rpc.json','return_drpc.json']:
 for r in J(S/file):
  x=r.get('result')
  if isinstance(x,dict) and 'logs' in x and x.get('status')=='0x1':eth_receipts[x['transactionHash']]=x
v=J(S/'verification.json');checks=[]
for expected in v['raw_RPC_receipts']:
 receipt=eth_receipts[expected['hash']];assert receipt['status']=='0x1'
 actual=collections.Counter((l['address'].lower(),'0x'+l['topics'][1][-40:],'0x'+l['topics'][2][-40:],int(l['data'],16)) for l in receipt['logs'] if l.get('topics',[None])[0]==TRANS)
 for e in expected['transfers']:assert actual[(e['token'],e['from'],e['to'],int(e['raw_amount']))]>=1
 checks.append(expected['hash'])
assert len(checks)==9
# Base token arithmetic is independently rebuilt directly from successful raw receipt logs.
base_receipts={}
for p in [B/'base_official_receipts.json']+sorted(B.glob('bamboo_rpc_receipts[1-4].json')):
 for r in J(p):
  x=r['result'];assert x['status']=='0x1';base_receipts[x['transactionHash']]=x
base_rows=sum((J(B/f'1836_base_tokens{i}.json') for i in range(1,7)),[]);assert len(base_rows)==505
buy={r['tx_hash'] for r in base_rows if r['token']==BAM and r['to']==A};sell={r['tx_hash'] for r in base_rows if r['token']==BAM and r['from']==A};assert len(buy)==8 and len(sell)==14 and not buy&sell
trade_records=[];log_counter=collections.Counter()
for h in buy|sell:
 rec=base_receipts[h];assert rec['status']=='0x1' and rec['from'].lower()==A
 delta={BU:0,BAM:0}
 for l in rec['logs']:
  token=l['address'].lower()
  if token not in delta or l.get('topics',[None])[0]!=TRANS:continue
  frm='0x'+l['topics'][1][-40:];to='0x'+l['topics'][2][-40:];amount=int(l['data'],16)
  if A not in [frm,to]:continue
  log_counter[(h,token,frm,to,amount)]+=1;delta[token]+=amount*(int(to==A)-int(frm==A))
 assert (delta[BU]<0 and delta[BAM]>0) if h in buy else (delta[BU]>0 and delta[BAM]<0)
 trade_records.append({'tx':h,'side':'buy' if h in buy else 'sell','USDC_raw_delta':delta[BU],'BAMBOO_raw_delta':delta[BAM]})
table_counter=collections.Counter((r['tx_hash'],r['token'],r['from'],r['to'],int(D(r['amount'])*(10**(6 if r['token']==BU else 18)))) for r in base_rows if r['tx_hash'] in buy|sell and r['token'] in [BU,BAM]);assert log_counter==table_counter and sum(log_counter.values())==66
spent=-sum(t['USDC_raw_delta'] for t in trade_records if t['side']=='buy');received=sum(t['USDC_raw_delta'] for t in trade_records if t['side']=='sell');bought=sum(t['BAMBOO_raw_delta'] for t in trade_records if t['side']=='buy');sold=-sum(t['BAMBOO_raw_delta'] for t in trade_records if t['side']=='sell')
assert spent==20100000000 and received==73854395784 and bought-sold==1
assert D(bought)/10**18==D('3911181.851848323949800498')
# Decode CCTP message bytes independently, compare source events/destination calldata/Circle objects.
def dynamic_bytes(encoded,which=0):
 data=bytes.fromhex(encoded.removeprefix('0x'));offset=int.from_bytes(data[which*32:which*32+32]);n=int.from_bytes(data[offset:offset+32]);assert offset+32+n<=len(data);return data[offset+32:offset+32+n]
def get_input(p):
 s=p.read_text();m=re.search(r"id=['\"]rawinput['\"][^>]*>(0x[0-9a-fA-F]+)",s);assert m;return m[1]
bridge_results=[]
for amount in [2100,25000,21116.99]:
 reverse=amount==21116.99;circle=J(B/('circle_return_message.json' if reverse else f'circle_{amount}_message.json'))['messages'][0];message=bytes.fromhex(circle['message'][2:]);assert len(message)==248
 src_domain=int.from_bytes(message[4:8]);dst_domain=int.from_bytes(message[8:12]);nonce=int.from_bytes(message[12:20]);recipient='0x'+message[164:184].hex();rawamount=int.from_bytes(message[184:216]);assert nonce==int(circle['eventNonce']) and recipient==A
 assert (src_domain,dst_domain)==((6,0) if reverse else (0,6));assert rawamount==int(D(str(amount))*10**6)
 expected=next(x for x in J(B/'verified_bridges.json') if x['nonce']==nonce);source=(base_receipts if reverse else eth_receipts)[expected['source_tx']];destination=(eth_receipts if reverse else base_receipts)[expected['destination_tx']]
 assert source['status']==destination['status']=='0x1'
 events=[l for l in source['logs'] if l.get('topics',[None])[0]==MSENT];assert len(events)==1 and dynamic_bytes(events[0]['data'])==message
 if reverse:
  raw=next(x['result']['input'] for x in J(S/'return_rpc.json') if x['id']=='return_mint_tx')
 else:raw=get_input(B/f'mint{amount}_tx.html');assert expected['destination_tx'] in (B/f'mint{amount}_tx.html').read_text()
 assert raw[:10]=='0x57ecfd28' and dynamic_bytes(raw[10:])==message and dynamic_bytes(raw[10:],1)==bytes.fromhex(circle['attestation'][2:])
 token=EU if reverse else BU;mint=[l for l in destination['logs'] if l['address'].lower()==token and l.get('topics',[None])[0]==TRANS and int(l['topics'][1],16)==0 and '0x'+l['topics'][2][-40:]==A];assert len(mint)==1 and int(mint[0]['data'],16)==rawamount
 bridge_results.append({'nonce':nonce,'USDC':str(D(rawamount)/10**6),'source_domain':src_domain,'destination_domain':dst_domain,'source_tx':expected['source_tx'],'destination_tx':expected['destination_tx'],'message_hash':'0x'+keccak256(message).hex(),'source_event_destination_input_Circle_bytes_match':True,'successful_destination_mint_matches':True})
# Historical/current inventory: mappings explicitly reconstructed, not contemporaneous request captures.
recon=J(B/'base_inventory_snapshots_request_reconstruction.json');meta_recon=J(B/'bamboo_inventory_metadata_request_reconstruction.json')
for record in [recon,meta_recon]:
 assert 'Reconstructed' in record['provenance'] and record['endpoint']=='https://mainnet.base.org'
 assert hashlib.sha256((B/record['response_file']).read_bytes()).hexdigest()==record['response_sha256']
requests={r['id']:r for r in recon['jsonrpc_request_body']};meta_requests={r['id']:r for r in meta_recon['jsonrpc_request_body']}
snap={r['id']:r for r in J(B/'base_inventory_snapshots.json')};meta={r['id']:r for r in J(B/'bamboo_inventory_metadata.json')}
expected={200:(BU,16925276),201:(BAM,16925276),202:(BU,17255170),203:(BAM,17255170),204:(BU,50987229),205:(BAM,50987229)}
for key,(token,block) in expected.items():
 assert requests[key]['method']=='eth_call' and requests[key]['params']==[{'to':token,'data':'0x70a08231'+'0'*24+A[2:]},hex(block)]
assert meta_requests[300]['method']=='eth_call' and meta_requests[300]['params']==[{'to':BAM,'data':'0x70a08231'+'0'*24+A[2:]},hex(50987229)]
assert 'error' in snap[205] and int(meta[300]['result'],16)==1
assert int(snap[200]['result'],16)==int(snap[201]['result'],16)==0
assert int(snap[202]['result'],16)==8523 and int(snap[203]['result'],16)==1911181851848323949800498
assert int(snap[204]['result'],16)==3937
for token,dec in [(BU,6),(BAM,18)]:
 for block,expected_amount in [(17255170,8523 if token==BU else 1911181851848323949800498),(50987229,3937 if token==BU else 1)]:
  amount=sum(int(D(r['amount'])*10**dec)*(int(r['to']==A)-int(r['from']==A)) for r in base_rows if r['token']==token and r['block']<=block)
  assert amount==expected_amount
assert int(base_receipts['0x7c75d20788c7c473e94ab0beb6c89ca8ac4d29ccc909fcad21d1b64ef7dc7716']['blockNumber'],16)==16925277
assert int(base_receipts['0x15b8d8a7c4236684cc220eb046cb23b414acccd055018d1da594043d2c2ad2f8']['blockNumber'],16)==17255170
inventory_review={'pass':True,'request_mappings_are_explicitly_disclosed_reconstructions':True,'response_hashes_verified':True,'before_first_mint_block':16925276,'before_USDC_raw':0,'before_BAMBOO_raw':0,'post_return_block':17255170,'post_return_USDC':'0.008523','post_return_BAMBOO':'1911181.851848323949800498','current_block':50987229,'current_USDC':'0.003937','current_BAMBOO_raw':1,'full_USDC_and_BAMBOO_event_ledger_agrees_with_both_later_snapshots':True,'native_ETH_gas_not_deducted_from_USDC_cash_difference':True,'first_return_is_not_full_liquidation_or_loss_measure':True}
results={'pass':True,'ML_rows':67,'USDC_rows':322,'ML_and_USDC_source_event_nets_zero':True,'MEXC_intermediary_ML_events_independently_reparsed':41,'MEXC_in_total_ML':'1256158.884','MEXC1_out_ML':'1069905.362','MEXC3_out_ML':'186253.522','all_20_MEXC_out_normal_records_success':True,'Gate_deposit_events':2,'Gate_sweep_events':1,'Gate_ML':'118172','KuCoin_direct_successful_call_count':10,'KuCoin_USDC':'693701.8471','direct_vesting_transfer_count':14,'direct_vesting_ML':'525000','representative_raw_Ethereum_receipts_independently_checked':9,'all_exchange_path_events_not_described_as_RPC_verified':True,'Base_buy_count':8,'Base_sell_count':14,'Base_successful_raw_trade_receipts':22,'Base_raw_transfer_logs_matched':66,'Base_USDC_spent':'20100','Base_USDC_received':'73854.395784','Base_USDC_cash_difference_before_native_gas':'53754.395784','Base_BAMBOO_bought':str(D(bought)/10**18),'Base_BAMBOO_sold':str(D(sold)/10**18),'Base_BAMBOO_trading_residual_raw':'1','bridge_checks':bridge_results,'inventory_request_mapping_review_pending':False,'inventory_review':inventory_review,'no_human_or_original_Mintlayer_cash_attribution':True}
(P/'pass4_exchange_review.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
