#!/usr/bin/env python3
"""Offline selected-path interpreter with synthetic storage, never an RPC transaction.
This is a bounded sanity check of observed runtime data flow, not a complete EVM.
"""
import pathlib,json,sys,hashlib
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
B=bytes.fromhex((P.parents[1]/'onchain_pass3/archived_bsc_contracts/d975_deployed_bytecode.txt').read_text().strip().removeprefix('0x'))
MASK=(1<<256)-1
OWNER=int('77bfe8d704b1948374bf8dab8328a810b2836e66',16);TOKEN=int('e9e7cea3dedca5984780bafc599bd69add087d56',16)
def mapping(k,s):return int.from_bytes(keccak256(k.to_bytes(32)+s.to_bytes(32)))
def execute(return_bool=1,caller=OWNER,already_claimed=0):
 pid=19;amount=194775268548166718546000;slot=mapping(pid,17)
 poolptr=int.from_bytes(keccak256(int(4).to_bytes(32)))+7*pid
 storage={0:OWNER,1:1,4:153,mapping(pid,7):111,mapping(pid,15):amount,slot:already_claimed,poolptr+1:TOKEN}
 memory=bytearray(16384);memory[0x40:0x60]=(0x80).to_bytes(32);stack=[0xdead,pid];pc=0xbd2;retdata=b'';calls=[];logs=[];steps=0
 def pop():return stack.pop()
 def push(v):stack.append(v&MASK)
 def signed(v):return v-(1<<256) if v>>255 else v
 def read(off,n):return bytes(memory[off:off+n])
 while pc!=0xdead:
  steps+=1;assert steps<3000
  at=pc;op=B[pc];pc+=1
  if 0x60<=op<=0x7f:n=op-0x5f;push(int.from_bytes(B[pc:pc+n]));pc+=n
  elif 0x80<=op<=0x8f:push(stack[-(op-0x7f)])
  elif 0x90<=op<=0x9f:n=op-0x8f;stack[-1],stack[-1-n]=stack[-1-n],stack[-1]
  elif op==0x00:break
  elif op==0x01:push(pop()+pop())
  elif op==0x02:push(pop()*pop())
  elif op==0x03:a=pop();b=pop();push(a-b)
  elif op==0x04:a=pop();b=pop();push(a//b if b else 0)
  elif op==0x10:a=pop();b=pop();push(a<b)
  elif op==0x11:a=pop();b=pop();push(a>b)
  elif op==0x12:a=pop();b=pop();push(signed(a)<signed(b))
  elif op==0x14:push(pop()==pop())
  elif op==0x15:push(pop()==0)
  elif op==0x16:push(pop()&pop())
  elif op==0x17:push(pop()|pop())
  elif op==0x19:push(~pop())
  elif op==0x1b:a=pop();b=pop();push(b<<a if a<256 else 0)
  elif op==0x1c:a=pop();b=pop();push(b>>a)
  elif op==0x20:off=pop();size=pop();push(int.from_bytes(keccak256(read(off,size))))
  elif op==0x33:push(caller)
  elif op==0x3b:pop();push(1)
  elif op==0x3d:push(len(retdata))
  elif op==0x3e:dest=pop();off=pop();n=pop();memory[dest:dest+n]=retdata[off:off+n]
  elif op==0x50:pop()
  elif op==0x51:push(int.from_bytes(read(pop(),32)))
  elif op==0x52:off=pop();v=pop();memory[off:off+32]=v.to_bytes(32)
  elif op==0x54:push(storage.get(pop(),0))
  elif op==0x55:k=pop();v=pop();storage[k]=v
  elif op==0x56:pc=pop();assert pc==0xdead or B[pc]==0x5b
  elif op==0x57:dest=pop();condition=pop();pc=dest if condition else pc
  elif op==0x5a:push(1000000)
  elif op==0x5b:pass
  elif op==0xa3:
   off=pop();n=pop();topics=[hex(pop()) for _ in range(3)];logs.append({'topics':topics,'data':read(off,n).hex()})
  elif op==0xf1:
   gas=pop();target=pop();value=pop();inoff=pop();insize=pop();outoff=pop();outsize=pop();data=read(inoff,insize)
   calls.append({'pc':hex(at),'target':'0x'+format(target,'040x'),'value':value,'calldata':'0x'+data.hex()})
   assert target==TOKEN and value==0
   assert data==bytes.fromhex('a9059cbb')+OWNER.to_bytes(32)+amount.to_bytes(32)
   retdata=return_bool.to_bytes(32);memory[outoff:outoff+min(outsize,32)]=retdata[:outsize];push(1)
  elif op==0xfd:
   off=pop();n=pop();return {'outcome':'revert','revert_data':'0x'+read(off,n).hex(),'calls':calls,'synthetic_state_only':True}
  else:raise RuntimeError((hex(at),hex(op),stack))
 return {'outcome':'returned','token_return_bool':return_bool,'claimed_flag':storage[slot]&255,'guard_reset':storage[1],'calls':calls,'logs':logs,'synthetic_state_only':True,'steps':steps}
if __name__=='__main__':
 results={'runtime_bytes_sha256':hashlib.sha256(B).hexdigest(),'synthetic_true_return':execute(1),'synthetic_false_return':execute(0),'synthetic_nonowner':execute(1,caller=1),'synthetic_already_claimed':execute(1,already_claimed=1),'scope':'Selected-path local emulator with mocked pool storage and token response. Not an on-chain transaction or proof that historical BUSD returned false.'}
 assert results['synthetic_true_return']['outcome']=='returned'
 assert results['synthetic_false_return']['outcome']=='returned' and results['synthetic_false_return']['claimed_flag']==1
 assert results['synthetic_nonowner']['outcome']=='revert' and not results['synthetic_nonowner']['calls']
 assert results['synthetic_already_claimed']['outcome']=='revert' and not results['synthetic_already_claimed']['calls']
 (P/'d975_selected_path_emulator.json').write_text(json.dumps(results,indent=2));print({k:v['outcome'] for k,v in results.items() if isinstance(v,dict)})
