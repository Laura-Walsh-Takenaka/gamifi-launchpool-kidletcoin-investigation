#!/usr/bin/env python3
import pathlib,json,csv
from decimal import Decimal,getcontext
getcontext().prec=100
P=pathlib.Path(__file__).resolve().parent;C=P.parent/'tranche_census'
r={v['id']:v['result'] for v in json.loads((C/'final_same_pin.json').read_text())}
reqs=json.loads((C/'final_same_pin.receipt.json').read_text())['request'];assert all(q['params'][-1]=='0x18b90b4' for q in reqs)
ledger=list(csv.DictReader((P.parents[1]/'claims/entitlements_status.csv').open()));assert len(ledger)==1999
bits={i for w in range(8) for i in range(w*256,w*256+256) if int(r['final_claimed_word_'+str(w)],16)&(1<<(i%256))}
assert len(bits)==119 and bits=={int(x['index']) for x in ledger if x['claimed_at_block_25923249']=='True'}
unpaid=sum(int(x['raw_amount']) for x in ledger if int(x['index']) not in bits);balance=int(r['final_balance'],16);assert unpaid==1116040845617446961425400 and balance==1116041281767546177360307
assert '0x'+r['final_owner()'][-40:]=='0x6c2b3a90acb72ef896325e19af9098d157f929c4' and r['final_owner()']==r['final_treasury()']
assert r['final_merkleRoot()']=='0x031862a21347c8b43c3fd3e7d67615141f32476371b3a31e3447de2530d06aa7'
base={v['id']:v['result'] for f in C.glob('base_batch_[0-9].json') for v in json.loads(f.read_text())};getters={v['id']:v['result'] for f in C.glob('getter_batch_[0-9].json') for v in json.loads(f.read_text())};coded=[k.split(':')[0] for k,v in base.items() if k.endswith(':runtime') and v!='0x'];assert len(coded)==10
oldroot=bytes.fromhex('976c38db0b559280062fa4ae155dd9d9e310637f147a3dd8198449f131bfee8c');oldruntime=bytes.fromhex((P.parents[1]/'onchain_pass3/old_ml_contract/pinned_runtime.txt').read_text().strip()[2:]);template=oldruntime.replace(oldroot,bytes(32))
for address in coded:
 code=bytes.fromhex(base[address+':runtime'][2:]);root=bytes.fromhex(getters[address+':merkleRoot()'][2:]);assert code.count(root)==2 and code.replace(root,bytes(32))==template
 assert '0x'+getters[address+':owner()'][-40:]=='0x77bfe8d704b1948374bf8dab8328a810b2836e66' and int(getters[address+':isClaimingPaused()'],16)==0
out={'pass':True,'same_pin_block':25923764,'final_8_bitmap_words_match_prior_verified_claim_set':True,'final_claimed_indices':119,'final_unclaimed_indices':1880,'final_unclaimed_ml':str(Decimal(unpaid)/10**18),'final_balance_ml':str(Decimal(balance)/10**18),'final_surplus_ml':str(Decimal(balance-unpaid)/10**18),'all_10_nonempty_tranche_runtimes_match_old4d7_except_root':True,'all_10_owner_getters_return_77bf':True,'all_10_pause_getters_false':True,'14_empty_current_runtime_addresses_not_historical_absence_assertion':True}
simulations={x['id']:x for x in json.loads((C/'reserve_withdraw_simulations.json').read_text())}
sim_requests={x['id']:x for x in json.loads((C/'reserve_withdraw_simulations.receipt.json').read_text())['request']}
for key,caller in [('owner_eth_call_only','0x77bfe8d704b1948374bf8dab8328a810b2836e66'),('nonowner_eth_call_only','0x0000000000000000000000000000000000000001')]:
 assert sim_requests[key]['method']=='eth_call' and sim_requests[key]['params']==[{'to':'0x9298136ec995aefb1e99fd4087080d3df328162f','from':caller,'data':'0x2eef326a'},'0x18b90b4']
assert simulations['owner_eth_call_only']['result']=='0x'
assert simulations['nonowner_eth_call_only']['error']['message']=='execution reverted: Ownable: caller is not the owner'
out['reserve_owner_withdraw_simulation_passes_and_nonowner_reverts_at_same_pin']=True
out['reserve_simulation_is_readonly_not_actual_withdrawal']=True
(P/'independent_final_state.json').write_text(json.dumps(out,indent=2));j=json.loads((P/'independentpass4review.json').read_text());j['same_pin_final_and_other_tranches']=out;(P/'independentpass4review.json').write_text(json.dumps(j,indent=2));print(json.dumps(out,indent=2))
