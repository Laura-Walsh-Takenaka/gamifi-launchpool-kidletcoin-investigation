"""Reproduce the bounded Ethereum-side factual checks; no network calls."""
from pathlib import Path
from decimal import Decimal,getcontext
import json,re,sys,collections,datetime,hashlib,html
P=Path(__file__).resolve().parent;getcontext().prec=100
sys.path.insert(0,str(P.parents[1]/'claims_peer'));from verify_claims import keccak256
A='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4';ML='0x059956483753947536204e89bfad909e1a434cc6';USDC='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48';MID='0x980bff583a8133600462bc034871dc548d6bfc84';KU='0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee';TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
s={};primary={}
for token,decimals in [('ML',18),('USDC',6)]:
 raw=json.loads((P/(token+'_tokentx_api.json')).read_text());assert raw['status']=='1';rows=raw['result'];assert len(rows)<1000 and {r['contractAddress'] for r in rows}=={ML if token=='ML' else USDC};primary[token]=rows
 bal=0;ins=outs=0;zeros=0
 for r in rows:
  v=int(r['value']);zeros+=v==0
  if r['to']==A:bal+=v;ins+=v
  if r['from']==A:bal-=v;outs+=v
  assert bal>=0
 assert bal==0;s[token]={'retrieved_rows':len(rows),'gross_in':str(Decimal(ins)/10**decimals),'gross_out':str(Decimal(outs)/10**decimals),'net':'0','zero_value_rows':zeros}
# All original-funder ML receipts to MID match the independent Etherscan rows.
m=json.loads((P/'980b_summary.json').read_text());assert m['token_rows']==202 and m['ML_rows']==41;out=[r for r in m['events'] if r['from']==MID];ins=[r for r in m['events'] if r['to']==MID];assert len(out)==20 and len(ins)==21
normal={r['Txhash'].lower():r for r in json.loads((P/'980b_normal.json').read_text())};assert len(normal)==132
for r in out:
 assert normal[r['tx_hash']]['Status']=='Success' and normal[r['tx_hash']]['Sender'].lower()==MID and normal[r['tx_hash']]['Receiver'].lower()==ML
 assert Decimal(r['running_ML'])==0
r1836=[r for r in primary['ML'] if r['to']==MID];assert len(r1836)==20
for r in r1836:
 matches=[x for x in ins if x['tx_hash']==r['hash'] and x['from']==A and Decimal(x['amount'])*10**18==int(r['value'])];assert len(matches)==1
assert sum(Decimal(r['amount']) for r in ins)==sum(Decimal(r['amount']) for r in out)==Decimal('1256158.884')
s['MEXC_route']={'all_ML_rows':41,'source1836_ML':'1234268.124','source3b883_ML':'21890.76','outgoing_MEXC1_ML':'1069905.362','outgoing_MEXC3_ML':'186253.522','total_ML':'1256158.884','outgoing_successful_normal_transactions':20,'all_outgoing_sweep_running_balance_to_zero':True,'source1836_incoming_event_crossmatches':20}
# Gate account complete index contains exactly3ML rows; incoming118172 and sweep118172.
gate=[r for r in json.loads((P/'a775_tokens1.parsed.json').read_text()) if r['token']==ML];assert len(gate)==3;assert sum(Decimal(r['amount']) for r in gate if r['from']==A)==Decimal(118172)
s['Gate_route']={'source1836_to_gate_deposit_ML':'118172','deposits':2,'sweep_ML':'118172','ML_rows':3,'all_token_rows':42}
# Historical USDC transfers to the shared KuCoin Deposit are direct successful calls.
n1836={r['hash']:r for r in json.loads((P/'normal_transactions_api.json').read_text())['result']};ku=[r for r in primary['USDC'] if r['from']==A and r['to']==KU];assert len(ku)==10
for r in ku:
 n=n1836[r['hash']];assert n['isError']=='0' and n['to']==USDC and n['from']==A and n['input'][:10]=='0xa9059cbb';b=bytes.fromhex(n['input'][10:]);assert '0x'+b[12:32].hex()==KU and int.from_bytes(b[32:64],'big')==int(r['value'])
assert sum(int(r['value']) for r in ku)==693701847100
s['KuCoin_route']={'count':10,'USDC':'693701.8471','successful_normal_input_checks':10,'hashes':[r['hash'] for r in ku]}
# Fourteen directly authorized ML vesting release proofs.
proofs=[]
for r in primary['ML']:
 if r['from']!=ML:continue
 x=r['input'];assert x[:10]=='0x3d1851c4';b=bytes.fromhex(x[10:]);addr=b[12:32];amount=int.from_bytes(b[32:64],'big');cliff=int.from_bytes(b[64:96],'big');root=b[96:128];off=int.from_bytes(b[128:160],'big');count=int.from_bytes(b[off:off+32],'big');node=keccak256(addr+amount.to_bytes(32,'big')+cliff.to_bytes(32,'big'))
 for i in range(count):p=b[off+32+i*32:off+64+i*32];node=keccak256(min(node,p)+max(node,p))
 assert node==root and '0x'+addr.hex()==A and amount==37500*10**18 and root.hex()=='2f4f2be944fcde1fa5b4d889b251686bd2cfcfc5eb76a62b0e4f42f137138aed'
 proofs.append({'hash':r['hash'],'amount_ML':'37500','cliff_seconds':cliff,'root':'0x'+root.hex(),'proof_valid':True})
assert len(proofs)==14;s['vesting']={'total_released_ML':'525000','verified_schedules':proofs,'note':'Observed releases; not a statement of total allocation or personal ownership.'}
# Independently received raw transaction receipts match selected exact Transfer logs.
rpc={r['id']:r.get('result') for r in json.loads((P/'selected_rpc.json').read_text())};ret={r['id']:r.get('result') for r in json.loads((P/'return_drpc.json').read_text())};receipts={k:v for k,v in rpc.items() if isinstance(v,dict) and 'logs' in v};receipts.update(ret)
assert len(receipts)==9
checks=[]
for name,r in receipts.items():
 assert r and r['status']=='0x1';decoded=[]
 for e in r['logs']:
  if e['address'].lower() in [ML,USDC] and e['topics'][0]==TRANSFER:
   decoded.append({'token':e['address'].lower(),'from':'0x'+e['topics'][1][-40:],'to':'0x'+e['topics'][2][-40:],'raw_amount':str(int(e['data'],16))})
 checks.append({'id':name,'hash':r['transactionHash'],'block':int(r['blockNumber'],16),'status':'success','transfers':decoded})
expected={
'bridge_2100':(USDC,A,'0xc4922d64a24675e16e1586e3e3aa56c06fabe907',2100*10**6),
'bridge_25000':(USDC,A,'0xc4922d64a24675e16e1586e3e3aa56c06fabe907',25000*10**6),
'gate_118171':(ML,A,'0xa775134ffa4ee261dea9c04ab364897b4bb9f302',118171*10**18),
'gate_sweep':(ML,'0xa775134ffa4ee261dea9c04ab364897b4bb9f302','0x0d0707963952f2fba59dd06f2b425ace40b492fe',118172*10**18),
'kucoin_404740':(USDC,A,KU,404740720000),
'mexc_35625':(ML,MID,'0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88',35625*10**18),
'mexc3_94207':(ML,MID,'0x3cc936b795a188f0e246cbb2d74c5bd190aecf18',942073*10**17),
'return_mint':(USDC,'0x0000000000000000000000000000000000000000',A,21116990000),
'return_to_1991':(USDC,A,'0x1991e27e2908847c0274a662eb6675002e8386d0',21116990000)}
for check in checks:
 token,frm,to,amount=expected[check['id']]
 assert any(e['token']==token and e['from']==frm and e['to']==to and int(e['raw_amount'])==amount for e in check['transfers']),check['id']
 check['matches_selected_route_amount_and_addresses']=True
s['raw_RPC_receipts']=checks
# Source burn events contain the exact bytes attested by Circle.
bridges=[]
for id,n,amt in [('bridge_2100','circle_2100_message.json',2100),('bridge_25000','circle_25000_message.json',25000)]:
 tx=rpc[id+'_tx'];assert tx['from']==A and tx['to']=='0xbd3fa81b58ba92a82136038b25adec7066af3155';x=tx['input'];assert x[:10]=='0x'+keccak256(b'depositForBurn(uint256,uint32,bytes32,address)').hex()[:8];b=bytes.fromhex(x[10:]);assert int.from_bytes(b[:32],'big')==amt*10**6 and int.from_bytes(b[32:64],'big')==6 and '0x'+b[76:96].hex()==A and '0x'+b[108:128].hex()==USDC
 message_log=next(e for e in rpc[id]['logs'] if e['address']=='0x0a992d191deec32afe36203ad87d7d289a738f81');d=bytes.fromhex(message_log['data'][2:]);off=int.from_bytes(d[:32],'big');length=int.from_bytes(d[off:off+32],'big');message=d[off+32:off+32+length];circle=json.loads((P/'base_continuation'/n).read_text())['messages'][0];assert '0x'+message.hex()==circle['message'];assert int.from_bytes(message[12:20],'big')==int(circle['eventNonce']);assert int.from_bytes(message[4:8],'big')==0 and int.from_bytes(message[8:12],'big')==6
 bridges.append({'Ethereum_tx':tx['hash'],'source_domain':0,'destination_domain':6,'mint_recipient':A,'USDC':str(amt),'nonce':int(circle['eventNonce']),'message_hash':'0x'+keccak256(message).hex(),'Circle_message_equals_Ethereum_MessageSent':True,'message':circle['message']})
returntx={r['id']:r.get('result') for r in json.loads((P/'return_rpc.json').read_text())}['return_mint_tx'];assert returntx['input'][:10]=='0x57ecfd28';b=bytes.fromhex(returntx['input'][10:]);off=int.from_bytes(b[:32],'big');length=int.from_bytes(b[off:off+32],'big');message=b[off+32:off+32+length];circle=json.loads((P/'base_continuation/circle_return_message.json').read_text())['messages'][0];assert '0x'+message.hex()==circle['message'];assert int.from_bytes(message[4:8],'big')==6 and int.from_bytes(message[8:12],'big')==0
bridges.append({'Ethereum_mint_tx':returntx['hash'],'source_domain':6,'destination_domain':0,'USDC':'21116.99','mint_recipient':A,'nonce':int.from_bytes(message[12:20],'big'),'message_hash':'0x'+keccak256(message).hex(),'Circle_message_equals_Ethereum_receiveMessage_input':True,'message':circle['message']})
for bridge in bridges:
 message=bytes.fromhex(bridge['message'][2:])
 assert '0x'+message[164:184].hex()==A and Decimal(int.from_bytes(message[184:216],'big'))/10**6==Decimal(bridge['USDC'])
s['CCTP_messages']=bridges
states={r['id']:r.get('result') for r in json.loads((P/'pinned_state.json').read_text())};assert states['EOA_code']=='0x' and int(states['ML_balance'],16)==0 and int(states['USDC_balance'],16)==0 and int(states['vesting_root_valid'],16)==1
head=rpc['head'];s['pinned_state']={'block':int(head['number'],16),'hash':head['hash'],'utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'ML':'0','USDC':'0','code':'0x','vesting_root_whitelisted':True}
s['all_checks_passed']=True;s['verified_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();s['scope_note']='Ethereum-side verification. Base swap amounts and destination mints are verified in the sibling base_continuation lane. Labels are explorer attribution; human customer/control remains unassigned.'
(P/'verification.json').write_text(json.dumps(s,indent=2));print('PASS:',s['pinned_state'],';9rawreceipts;14Merkleproofs;3CCTPmessagebytecomparisons;20MEXCoutgoingstatuschecks;10KuCoinUSDCcallchecks')
