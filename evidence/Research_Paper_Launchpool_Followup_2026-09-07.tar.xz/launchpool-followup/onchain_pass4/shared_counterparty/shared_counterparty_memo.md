# Shared counterparty 183600 — exchange routes and cross-chain continuation

**Finding:** the shared gas/ML counterparty `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4` is also a recurring exchange-facing wallet and a Circle bridge user. This pass connects **1,256,158.884 ML to MEXC-labelled endpoints**, **118,172 ML to Gate-labelled addresses**, and **693,701.8471 USDC to the same KuCoin Deposit address later used by 1991**. These are distinct historical flows and must not be added together as a missing-money total.

The July 2024 cash branch has also been continued across chains: 183600 received **27,100 USDC** from 1991 in two payments and submitted the exact amounts for minting to its same address on Base. On 18 July, **21,116.99 USDC** was minted back to it on Ethereum and sent to 1991. All three Circle message payloads match the retained on-chain calldata/events. The intervening Base transactions are analyzed in the sibling `base_continuation` evidence directory.

No primary source identifies the human signing-key holder, exchange customer, or Laura as a beneficiary.

## 1. The MEXC-facing ML route is now fully enumerated

Intermediate address: `0x980bff583a8133600462bc034871dc548d6bfc84` (980b). Its retained public address page does **not** give it a MEXC name tag. The finding below is based on actual outgoing token transfers to named endpoints, not on its historical MEXC gas-funding label.

| Movement | Events | ML |
|---|---:|---:|
| 183600 → 980b | 20 | 1,234,268.124 |
| Original vesting beneficiary 3b883 → 980b | 1 | 21,890.76 |
| 980b → `0x75e89d5979e4f6fba9f97c104c2f0afb3f1dcb88` — Etherscan **MEXC 1** | 16 | 1,069,905.362 |
| 980b → `0x3cc936b795a188f0e246cbb2d74c5bd190aecf18` — Etherscan **MEXC 3** | 4 | 186,253.522 |
| **Total incoming / outgoing** | **21 / 20** | **1,256,158.884 each** |

The entire 980b token census contains **202 token rows**, including **41 exact ML transfer events**. Every ML outgoing transfer brings its running ML balance back to zero. All twenty outgoing hashes match successful normal transactions sent by 980b to the exact ML token contract in its complete **132-transaction** normal census. All twenty 183600→980b incoming events also match the independent Blockscout ML history of 183600 by hash, sender, receiver and full-precision amount.

Two representative endpoint payments additionally match successful raw Ethereum RPC receipts:

- **35,625 ML to MEXC 1**, 26 August 2024: `0xb4b122fa5e4c293ed43cb945087f9f96a9721a74a25e8d94bbe7d7a632942056`.
- **94,207.3 ML to MEXC 3**, 21 January 2024: `0x97727ae34d3709a4d81530f774b801322a6cec963ba6e487768734a45e5c5234`.

This establishes a repeated token route into explorer-attributed MEXC custody. It does not establish off-chain sales, proceeds, withdrawals, a personal account holder or ownership of 980b's key. MEXC account mapping for the receiving deposits/sweeps is the next concrete records lead.

## 2. A Gate deposit and later consolidation

The earlier pass found 183600 receiving **118,172 ML from dd923** on 28 March 2023. The continuation is now:

| UTC | Movement | ML | Transaction |
|---|---|---:|---|
| 28 Mar 2023 16:16:35 | 183600 → a775 | 1 | `0x965d93ca028b01ecd55823d18aadc3f282dc8032fb6400ebba4634097fb76131` |
| 28 Mar 2023 16:18:59 | 183600 → a775 | 118,171 | `0x0ead33d77fc2e894c762d473c9ab96f81a623a81032321382de36895c0bfa346` |
| 8 May 2023 19:47:11 | a775 → 0d070 | 118,172 | `0x9992fe6e027fce4eb3c98df73e41efb4ddc8b196208e22ff1700ee25dfa9e885` |

- a775: `0xa775134ffa4ee261dea9c04ab364897b4bb9f302`, Etherscan **Gate Deposit**.
- 0d070: `0x0d0707963952f2fba59dd06f2b425ace40b492fe`, Etherscan **Gate Deposit**.

The complete a775 token census is **42 rows**, with precisely these three ML events. The 118,171 ML payment and 118,172 ML consolidation both match successful raw RPC receipts. No exchange customer identity or ML sale is inferred.

## 3. A much earlier shared KuCoin deposit route

The exact KuCoin Deposit address `0x4d0d32b42bb4d6a3e3ed503c5faaf49b6b64a7ee`, used by 1991 in the previous pass, had already received **693,701.8471 USDC in ten transfers from 183600** between 18 July 2022 and 21 March 2023.

| Date UTC | USDC |
|---|---:|
| 18 Jul 2022 | 404,740.72 |
| 8 Nov 2022 | 99,314.076832 |
| 27 Nov 2022 | 19,960.0001 |
| 21 Jan 2023 | 30,194.231251 |
| 22 Jan 2023 | 44,898.905274 |
| 23 Jan 2023 | 40,285.149178 |
| 24 Jan 2023 — first | 14,706.952456 |
| 24 Jan 2023 — second | 7,167.865001 |
| 20 Mar 2023 | 14,749.163072 |
| 21 Mar 2023 | 17,684.783936 |
| **Total** | **693,701.8471** |

All ten match successful direct USDC `transfer` calls from 183600 in the retained normal-transaction API records. The largest, **404,740.72 USDC**, transaction `0x85fba065f36fe6a286a1610da0bd8b0ea5a2b309f8b33b31693d3e1c37acf3ee`, additionally matches a successful raw RPC receipt and an independently retrieved Etherscan transaction page.

This is a shared exchange-destination connection between two wallets. It does not prove that their keys have the same owner, that Laura is the KuCoin customer, or that this older USDC came from Mintlayer investors. The 183600 wallet has extensive other inflows and trading activity. Do not combine these historical payments with the previous pass's 80,750 USDC branch as a new fundraising total.

## 4. July cash branch: Ethereum → Base → Ethereum

The Ethereum USDC event ledger shows a zero running balance before each of these two 183600 receipts and again immediately after the corresponding burn. No other Ethereum USDC event intervenes before the July 18 return.

| UTC | Event | USDC | Transaction |
|---|---|---:|---|
| 10 Jul 2024 17:19:35 | 1991 → 183600 | 2,100 | `0x383a53741d07abde132e0a8d9d30999bab4cf20c340439bced4bd840fad653cf` |
| 10 Jul 2024 17:34:35 | 183600 deposits/burns for Base mint | 2,100 | `0x1cdbe4dae25c6aa07e2f148ab30b24af8b3812d2b71c8d3377dcaafa0b9f2fad` |
| 11 Jul 2024 10:19:11 | 1991 → 183600 | 25,000 | `0xd44cb0359c341ec8642ed6e0a59e0181c7aecbf9a29422b74f122b672e338741` |
| 11 Jul 2024 10:31:11 | 183600 deposits/burns for Base mint | 25,000 | `0x090a9a094c725dc79a339476c572ecb8267f89ece6cd145374320a13aa334fdb` |
| 18 Jul 2024 11:32:35 | USDC minted back to 183600 on Ethereum | 21,116.99 | `0x05725b28e784b7a3582215be086fa260438251e6352bf02562fd8e7f23f0c48e` |
| 18 Jul 2024 11:35:11 | 183600 → 1991 | 21,116.99 | `0xd24120f60683e7e27ed0376e219f4de61b840aee28e72343e40bef1ba6377668` |

The two forward calls target `0xbd3fa81b58ba92a82136038b25adec7066af3155`. Circle's official CCTP V1 documentation identifies this as Ethereum's TokenMessenger and identifies **domain 6 as Base**. The decoded `depositForBurn` calldata specifies the exact amount, domain 6, native Ethereum USDC and the same 183600 address as mint recipient. The `superbridge` trailing bytes are preserved as calldata; no human attribution is drawn from that marker.

The forward source receipts record both the USDC transfer into Circle's TokenMinter and the actual burn to the zero address. Their `MessageSent` bytes match Circle's public message API exactly: nonces **81,239** (2,100) and **81,473** (25,000). The later Ethereum `receiveMessage` calldata matches the Base→Ethereum Circle message exactly: nonce **235,711**, 21,116.99 USDC, same 183600 recipient. Both reverse Ethereum transactions have successful dRPC receipts; the mint and subsequent transfer amounts/addresses were independently decoded. The Base lane separately verifies the destination mints, intervening trades and reverse burn.

These are linked cross-chain message records, not a guess based only on similar amounts or timing. Nevertheless, 1991's historical starting USDC balance remains unresolved in the previous pass. Thus the **27,100 received from 1991 is directly continued here**, while an exclusive-source attribution to 77bf's earlier IAG fundraising receipt is not made.

The difference between the outward and returned cash amounts is not a realized-loss calculation. Intervening token purchases/sales, residual token holdings and other balances must be considered using the Base records. Nothing in this lane determines whether any trading was authorized under an off-chain agreement.

## 5. This wallet also claims ML vesting itself

In addition to receiving ML from the earlier operational wallets, 183600 received **fourteen direct vesting releases of 37,500 ML each**, totaling **525,000 ML**, between 4 September 2023 and 22 September 2024.

All fourteen raw `releaseVested` inputs were decoded and their Merkle proofs independently verified against root:

`0x2f4f2be944fcde1fa5b4d889b251686bd2cfcfc5eb76a62b0e4f42f137138aed`.

The current ML contract returns this root as whitelisted. This proves recognized on-chain beneficiary schedules for the address. It does not identify the human beneficiary, the consideration paid, the entire lifetime allocation, or a legal right to other investors' funds. The root's public IPFS URI was recorded from `mapRootURIs`; its content was not fetched in this pass.

## 6. Coverage, current state and validation

Exact primary token addresses: ML `0x059956483753947536204e89bfad909e1a434cc6` (18 decimals), USDC `0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48` (6 decimals).

- 183600's successful token-filtered Blockscout responses returned **67 ML rows** and **322 USDC rows**, both below the requested 1,000-row limit. ML gross in/out: **1,534,912.9249529404** each. USDC gross in/out: **3,024,925.735593** each. Both histories reconcile to zero. These are repeated transfer volumes, not unique capital, revenue or missing funds.
- The USDC set contains **25 zero-value events** and small lookalike-address receipts. They remain in exact balance arithmetic but are excluded from operator/exchange affiliation claims. Full-address matching was used throughout.
- The first 1,000 normal transactions were retrieved, through 11 September 2024. A request for page 2 returned HTTP 429. The normal history is therefore explicitly incomplete; all ten historical KuCoin deposits and the two July bridge calls are nevertheless within the successful retrieved page.
- Ethereum block **25,923,801**, **7 September 2026 06:51:23 UTC**, hash `0x235710e2fd3f73947a61723eb797bfdaf1eea3a9e80d45356d34265840ed8658`: independent RPC returns **0 ML**, **0 USDC**, and bytecode `0x` for 183600. The explorer metadata also identifies an EOA with no ENS or public name tag. No human owner is assigned.
- Nine selected raw transaction receipts independently confirm exact success, token, sender, receiver and amount across the forward bridges, Gate/MEXC examples, earliest KuCoin deposit and reverse Ethereum mint/return. Representative receipt checks are not presented as a complete independent RPC census of every historical transfer.
- Blockscout returned 429 for the 980b token API and normal page 2; the route stopped. A separate ordinary Etherscan census supplied 980b's complete histories. Publicnode returned null for the two reverse receipts despite retrieving the mined mint transaction; a bounded independent dRPC request recovered both successful receipts. Failures and source differences remain preserved.
- Exact-address searches across two public search engines produced no primary human-identity source. Explorer exchange labels are stored with their URLs, title excerpts and captured source hashes in `explorer_label_records.json`. Circle protocol identifiers are recorded in `public_source_records.json`.

Run `python verify_shared_counterparty.py` for offline verification of the retained Ethereum arithmetic, twenty outgoing MEXC status checks, ten historical KuCoin calldata checks, fourteen Merkle schedules, nine exact RPC receipt matches and three Circle-message byte comparisons. All checks passed. Base verification is separately reproducible within `base_continuation`.

**Custody conclusion:** this adds concrete MEXC, Gate, KuCoin and cross-chain transaction identifiers for records requests. It does not name Laura as an exchange customer or wallet controller, establish personal spending, or alter the earlier finding that the current ML distributor's unclaimed allocations were fully backed at the audited snapshot.
