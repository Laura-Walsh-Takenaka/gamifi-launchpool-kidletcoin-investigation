from pathlib import Path
import urllib.request,urllib.error,json,datetime,hashlib,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P.parents[1]/'claims_peer'));from verify_claims import keccak256
URL='https://ethereum-rpc.publicnode.com';A='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4';ML='0x059956483753947536204e89bfad909e1a434cc6';USDC='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
def post(n,p):
 rec={'url':URL,'retrieval_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':p}
 try:
  r=urllib.request.urlopen(urllib.request.Request(URL,data=json.dumps(p).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=40);b=r.read();rec.update(status=r.status,sha256=hashlib.sha256(b).hexdigest());(P/(n+'.json')).write_bytes(b);result=json.loads(b)
 except Exception as e:rec['error']=str(e);result=None
 (P/(n+'_receipt.json')).write_text(json.dumps(rec,indent=2));return result
selected={'bridge_2100':'0x1cdbe4dae25c6aa07e2f148ab30b24af8b3812d2b71c8d3377dcaafa0b9f2fad','bridge_25000':'0x090a9a094c725dc79a339476c572ecb8267f89ece6cd145374320a13aa334fdb','gate_118171':'0x0ead33d77fc2e894c762d473c9ab96f81a623a81032321382de36895c0bfa346','gate_sweep':'0x9992fe6e027fce4eb3c98df73e41efb4ddc8b196208e22ff1700ee25dfa9e885','kucoin_404740':'0x85fba065f36fe6a286a1610da0bd8b0ea5a2b309f8b33b31693d3e1c37acf3ee','mexc_35625':'0xb4b122fa5e4c293ed43cb945087f9f96a9721a74a25e8d94bbe7d7a632942056','mexc3_94207':'0x97727ae34d3709a4d81530f774b801322a6cec963ba6e487768734a45e5c5234'}
calls=[{'jsonrpc':'2.0','id':'head','method':'eth_getBlockByNumber','params':['latest',False]}]
for n,h in selected.items():calls.append({'jsonrpc':'2.0','id':n,'method':'eth_getTransactionReceipt','params':[h]})
for n in ['bridge_2100','bridge_25000']:calls.append({'jsonrpc':'2.0','id':n+'_tx','method':'eth_getTransactionByHash','params':[selected[n]]})
res=post('selected_rpc',calls)
if res:
 by={r['id']:r for r in res};head=by['head'].get('result');print({k:(None if r.get('result') is None else 'result') for k,r in by.items()})
 if head:
  block=head['number'];sel=lambda f:keccak256(f.encode()).hex()[:8];calls=[{'jsonrpc':'2.0','id':'EOA_code','method':'eth_getCode','params':[A,block]}]
  for n,to,data in [('ML_balance',ML,sel('balanceOf(address)')+A[2:].zfill(64)),('USDC_balance',USDC,sel('balanceOf(address)')+A[2:].zfill(64)),('vesting_root_valid',ML,sel('rootWhitelist(bytes32)')+'2f4f2be944fcde1fa5b4d889b251686bd2cfcfc5eb76a62b0e4f42f137138aed'),('vesting_root_URI',ML,sel('mapRootURIs(bytes32)')+'2f4f2be944fcde1fa5b4d889b251686bd2cfcfc5eb76a62b0e4f42f137138aed')]:calls.append({'jsonrpc':'2.0','id':n,'method':'eth_call','params':[{'to':to,'data':'0x'+data},block]})
  print(post('pinned_state',calls))
else:print('RPC unavailable, recorded error')
