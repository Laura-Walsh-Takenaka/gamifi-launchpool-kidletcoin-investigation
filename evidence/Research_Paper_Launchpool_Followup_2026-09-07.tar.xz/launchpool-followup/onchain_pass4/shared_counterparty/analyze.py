from pathlib import Path
from decimal import Decimal,getcontext
import json,collections,datetime
getcontext().prec=100;P=Path(__file__).resolve().parent;A='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4'
summary={};events={}
for token,decimals in [('ML',18),('USDC',6)]:
 o=json.loads((P/(token+'_tokentx_api.json')).read_text());assert o['status']=='1';rows=o['result'];assert len(rows)<1000
 events[token]=rows; by={'in':{},'out':{}};balance=0;negative=[]
 for r in rows:
  assert int(r['tokenDecimal'])==decimals;v=int(r['value']);direction='in' if r['to']==A else 'out';counter=r['from'] if direction=='in' else r['to'];d=by[direction].setdefault(counter,{'count':0,'raw':0,'hashes':[]});d['count']+=1;d['raw']+=v;d['hashes'].append(r['hash']);balance+=v*(1 if direction=='in' else -1)
  r['utc']=datetime.datetime.fromtimestamp(int(r['timeStamp']),datetime.timezone.utc).isoformat();r['amount']=str(Decimal(v)/10**decimals);r['running_balance']=str(Decimal(balance)/10**decimals)
  if balance<0:negative.append(r['hash'])
 for d in list(by['in'].values())+list(by['out'].values()):d['amount']=str(Decimal(d.pop('raw'))/10**decimals)
 summary[token]={'count':len(rows),'by_counterparty':by,'net':str(Decimal(balance)/10**decimals),'first':rows[0]['utc'],'last':rows[-1]['utc'],'negative_running_balance_hashes':negative}
 (P/(token+'_events.json')).write_text(json.dumps(rows,indent=2))
 print(token,summary[token]['count'],summary[token]['net'],summary[token]['first'],summary[token]['last'])
 print('in',[(k,v['count'],v['amount']) for k,v in by['in'].items()]);print('out',[(k,v['count'],v['amount']) for k,v in by['out'].items()])
mlout={r['hash']:[x for x in events['ML'] if x['hash']==r['hash'] and x['from']==A] for r in events['ML'] if r['from']==A};usdcin={r['hash']:[x for x in events['USDC'] if x['hash']==r['hash'] and x['to']==A] for r in events['USDC'] if r['to']==A};both=[]
for h in sorted(mlout.keys()&usdcin.keys()):
 m=mlout[h];u=usdcin[h];both.append({'hash':h,'utc':m[0]['utc'],'ML_out':str(sum(Decimal(r['amount']) for r in m)),'USDC_in':str(sum(Decimal(r['amount']) for r in u)),'ML_to':list({r['to'] for r in m}),'USDC_from':list({r['from'] for r in u}),'method':m[0]['functionName'],'input':m[0]['input']})
summary['ML_out_USDC_in_same_transaction']=both
(P/'summary.json').write_text(json.dumps(summary,indent=2));print('ML and USDC same tx',len(both));print(json.dumps([{k:v for k,v in r.items() if k!='input'} for r in both],indent=2))
