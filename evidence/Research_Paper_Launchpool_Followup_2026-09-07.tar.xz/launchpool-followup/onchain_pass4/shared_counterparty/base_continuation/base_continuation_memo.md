# Verified Base continuation: Circle transfers and BAMBOO trading

Research date: 7 September 2026. Wallet: `0x183600361dc42c6f022fd219c3a9dabbf08c9ce4` (1836). Chain: Base, chain ID 8453. This follows the 2,100 and 25,000 USDC payments from 1991 on Ethereum identified in the shared-counterparty lane. It does not identify the original Mintlayer payment proceeds, Laura's private keys, a human beneficiary or authorization to trade.

## Verified route

| UTC event | USDC | Exact action |
|---|---:|---|
| 10 July 2024 17:34:35 | 2,100 | Ethereum 1836 calls Circle depositForBurn, destination domain 6 and recipient 1836. |
| 10 July 2024 19:31:41 | 2,100 | Circle USDC minted to the same address on Base, nonce 81239. |
| 10 July 2024 19:34:47 | 2,100 | USDC exchanged for 742,405.278571366117591865 BAMBOO. |
| 11 July 2024 10:31:11 | 25,000 | Second Ethereum depositForBurn to the same Base recipient. |
| 11 July 2024 11:06:41 | 25,000 | Base USDC mint, nonce 81473. |
| 11 July 2024 11:07:41–13:15:31 | 18,000 | Seven more purchases of BAMBOO; 7,000 USDC remains unspent. |
| 14 July 2024 13:07:49–13:09:23 | 14,116.998523 received | Two sales dispose of 2,000,000 BAMBOO. |
| 18 July 2024 10:48:07 | 21,116.99 | Base Circle burn/return to Ethereum, nonce 235711. |
| 18 July 2024 11:32:35 | 21,116.99 | Ethereum Circle mint to 1836. |
| 18 July 2024 11:35:11 | 21,116.99 | 1836 transfers USDC back to 1991 on Ethereum. |

All three bridge messages are matched byte-for-byte across the source-chain `MessageSent` log, Circle's official Iris API message and attestation, and destination `receiveMessage` calldata. All source/destination bridge receipts and the final Ethereum payment are successful; mint and payment Transfer logs match the exact amounts. This links the two chains using message contents and nonces, not merely similar transfer amounts.

## Inventory and outcome

Historical Base `balanceOf` calls show **zero USDC and zero BAMBOO** at block 16,925,276, immediately before the first mint. Thus earlier Base token inventory does not obscure these purchases.

Across eight purchases on July 10–11, the wallet spent **20,100 USDC** and acquired **3,911,181.851848323949800498 BAMBOO**. The token contract is `0x689644b86075ed61c647596862c7403e1c474dbf`; on-chain `name()` returns **Bamboo on Base**, and `symbol()` returns **BAMBOO**.

After the July 18 return of 21,116.99 USDC, historical calls at Base block 17,255,170 confirm **0.008523 USDC** and **1,911,181.851848323949800498 BAMBOO** remained. Comparing only 27,100 sent to Base with 21,116.99 initially returned would omit those assets and would give a misleading loss figure.

The remaining BAMBOO was sold in twelve further transactions on July 22–23, except for one token base unit. Across **all 14 sales**, the wallet received **73,854.395784 USDC**. Against 20,100 USDC spent buying BAMBOO, this is a **positive trading cash difference of 53,754.395784 USDC before native ETH gas**. No fiat conversion or remaining-token valuation is applied. These figures are actual USDC transfer amounts; they do not establish who beneficially owned the funds.

All **22 buy/sell transaction receipts** were retrieved from Base's official public RPC and show success. Their **66 USDC/BAMBOO Transfer logs involving 1836** match the explorer tables exactly, including transaction sender, token contract, recipient and raw integer amounts.

The current Base snapshot is block **50,987,229**, hash `0x2a4b2c54b9305aa4cd8705a49cda80f6d18a0cc4400027e89c7524cb8a8bf983`, timestamp **2026-09-07 06:50:05 UTC**. Pinned contract calls show **0.003937 USDC** and **one raw BAMBOO unit (0.000000000000000001 BAMBOO)**. Later USDC activity exists; this current balance is not solely the July trading result. Subsequent destination tracing beyond the first July 18 return was outside this bounded task.

## Exact cross-chain identifiers

| Amount USDC | Source transaction | Destination transaction | Circle nonce |
|---:|---|---|---:|
| 2,100 | `0x1cdbe4dae25c6aa07e2f148ab30b24af8b3812d2b71c8d3377dcaafa0b9f2fad` | `0x7c75d20788c7c473e94ab0beb6c89ca8ac4d29ccc909fcad21d1b64ef7dc7716` | 81239 |
| 25,000 | `0x090a9a094c725dc79a339476c572ecb8267f89ece6cd145374320a13aa334fdb` | `0xeed0e96095f91a6462c263512afdf3bdaa8eb411fe4d1fd2be06937367c8cdf2` | 81473 |
| 21,116.99 return | `0x15b8d8a7c4236684cc220eb046cb23b414acccd055018d1da594043d2c2ad2f8` | `0x05725b28e784b7a3582215be086fa260438251e6352bf02562fd8e7f23f0c48e` | 235711 |

The onward Ethereum payment back to 1991 is `0xd24120f60683e7e27ed0376e219f4de61b840aee28e72343e40bef1ba6377668`.

## Sources, coverage and reproducibility

- Circle's official contract documentation identifies Ethereum domain 0, Base domain 6, their TokenMessenger/MessageTransmitter contracts and native USDC contracts. Retained source pages: `circle_v1_contracts.html`, `circle_usdc_addresses.html`; concise metadata and hashes in `source_records.json`.
- Official Circle API responses are `circle_2100_message.json`, `circle_25000_message.json` and `circle_return_message.json`. Each includes exact message bytes, nonce and attestation. Attestation signatures were not independently recomputed offline; successful destination contracts accepted the identical submitted message and attestation.
- Base's official `https://mainnet.base.org` supplied the raw receipts and historical/current token balances. `base_official_receipts.json`, `bamboo_rpc_receipts1.json` through `bamboo_rpc_receipts4.json`, `base_inventory_snapshots.json` and `bamboo_inventory_metadata.json` preserve them.
- BaseScan advertises 505 ERC-20 transfer rows for 1836. All six pages were recovered (100+100+100+100+100+5). These cover the advertised token-transfer history, not NFTs or a full normal/internal-transaction census. `all_base_token_events.json` retains all rows. Spam/dust assets outside USDC/BAMBOO were not attributed or valued.
- Exact inventory request mappings (IDs 200–206 and 300–302) are preserved in `base_inventory_snapshots_request_reconstruction.json` and `bamboo_inventory_metadata_request_reconstruction.json`. These are explicitly labeled reconstructions from the actual executed tool-call code and saved block values, linked to the original response hashes and retrieval records; the original fetch helper had omitted POST bodies. No fresh call was substituted for an earlier response.
- `verify_base.py` reproduces all 22 swap comparisons, the three bridge-message matches, the exact arithmetic and inventory checks. It reads the sibling lane's `selected_rpc.json`, `return_rpc.json` and `return_drpc.json` for Ethereum evidence, and the preexisting pure-Python Keccak function in `claims_peer/verify_claims.py`. Its outputs are `verified_trades.json`, `verified_bridges.json` and `base_verified_summary.json`.
- The first Base Publicnode receipt batch returned HTTP 403; the official Base public RPC supplied the records. One current BAMBOO query returned a rate-limit error; a later bounded query succeeded at the same pinned block. No failure was treated as zero activity. No keys, signatures, payments or account access were used.

The 1991 upstream-wallet commingling limitation remains: these records identify how the **specific 27,100 USDC paid to 1836** was bridged and traded, not an exclusive source assignment of 1991's funds to the earlier fundraising withdrawals. They provide a documented trading destination and additional account/authorization questions, without assigning a human owner.
