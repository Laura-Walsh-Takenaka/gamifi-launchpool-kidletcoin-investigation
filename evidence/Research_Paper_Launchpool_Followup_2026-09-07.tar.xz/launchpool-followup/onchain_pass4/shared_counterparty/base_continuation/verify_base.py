#!/usr/bin/env python3
"""Offline Circle message / Base trade / inventory reconciliation."""
from pathlib import Path
from decimal import Decimal,getcontext
from collections import Counter
import json,re,html,hashlib,sys,datetime
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[2]/'claims_peer'))
from verify_claims import keccak256
getcontext().prec=100
A='0x183600361dc42c6f022fd219c3a9dabbf08c9ce4';B='0x689644b86075ed61c647596862c7403e1c474dbf';U='0x833589fcd6edb6e08f4c7c32d4f71b54bda02913'
TRANS='0x'+keccak256(b'Transfer(address,address,uint256)').hex();SENT='0x'+keccak256(b'MessageSent(bytes)').hex()
rows=[]
for i in range(1,7):
 f=P/f'1836_base_tokens{i}.json';part=json.load(open(f));assert len(part)==(100 if i<6 else 5);rows+=part
assert len(rows)==505
buyh={r['tx_hash'] for r in rows if r['token']==B and r['to']==A};sellh={r['tx_hash'] for r in rows if r['token']==B and r['from']==A};assert len(buyh)==8 and len(sellh)==14 and not buyh&sellh
receipts={}
for f in [P/'base_official_receipts.json']+sorted(P.glob('bamboo_rpc_receipts*.json')):
 for x in json.load(open(f)):
  d=x['result'];assert d['status']=='0x1';receipts[d['transactionHash']]=d
assert buyh|sellh<=receipts.keys()
def n(r):
 dec=6 if r['token']==U else 18;d=Decimal(r['amount'])*10**dec;assert d==d.to_integral_value();return int(d)
tab=Counter((r['tx_hash'],r['token'],r['from'],r['to'],n(r)) for r in rows if r['tx_hash'] in buyh|sellh and r['token'] in [U,B])
rpc=Counter()
for h in buyh|sellh:
 rec=receipts[h];assert rec['from'].lower()==A
 for l in rec['logs']:
  if l['address'] not in [U,B] or l['topics'][0]!=TRANS:continue
  frm='0x'+l['topics'][1][-40:];to='0x'+l['topics'][2][-40:]
  if A not in [frm,to]:continue
  rpc[(h,l['address'],frm,to,int(l['data'],16))]+=1
assert tab==rpc,(tab-rpc,rpc-tab)
trades=[]
for h in sorted(buyh|sellh,key=lambda h:int(receipts[h]['blockNumber'],16)):
 rr=[r for r in rows if r['tx_hash']==h];delta={tok:sum(Decimal(r['amount'])*(1 if r['to']==A else -1) for r in rr if r['token']==tok) for tok in [U,B]}
 trades.append({'tx_hash':h,'utc':rr[0]['utc'],'block':int(receipts[h]['blockNumber'],16),'status':'0x1','transaction_caller':receipts[h]['from'],'transaction_to':receipts[h]['to'],'action':'buy' if h in buyh else 'sell','USDC_delta':str(delta[U]),'BAMBOO_delta':str(delta[B]),'gas_used':receipts[h]['gasUsed'],'effective_gas_price':receipts[h]['effectiveGasPrice'],'L1_fee_raw_wei':receipts[h].get('l1Fee')})
spent=-sum(Decimal(t['USDC_delta']) for t in trades if t['action']=='buy');received=sum(Decimal(t['USDC_delta']) for t in trades if t['action']=='sell');assert spent==Decimal('20100') and received==Decimal('73854.395784')
# ABI dynamic bytes decoder. Data is ABI parameters (selector already removed).
def dyn(data,word_index=0):
 b=bytes.fromhex(data.removeprefix('0x'));off=int.from_bytes(b[word_index*32:(word_index+1)*32]);size=int.from_bytes(b[off:off+32]);assert off+32+size<=len(b);return b[off+32:off+32+size]
def msg_fields(message):
 b=bytes.fromhex(message.removeprefix('0x'));assert len(b)==248
 return {'message_keccak256':'0x'+keccak256(b).hex(),'version':int.from_bytes(b[:4]),'source_domain':int.from_bytes(b[4:8]),'destination_domain':int.from_bytes(b[8:12]),'nonce':int.from_bytes(b[12:20]),'source_token_messenger':'0x'+b[20:52][-20:].hex(),'destination_token_messenger':'0x'+b[52:84][-20:].hex(),'destination_caller':'0x'+b[84:116].hex(),'burn_token':'0x'+b[120:152][-20:].hex(),'mint_recipient':'0x'+b[152:184][-20:].hex(),'raw_amount':str(int.from_bytes(b[184:216])),'USDC':str(Decimal(int.from_bytes(b[184:216]))/10**6),'message_sender':'0x'+b[216:248][-20:].hex()}
def rawinput(file):
 s=file.read_text();raw=re.search(r"id='rawinput'[^>]*>(0x[0-9a-fA-F]+)",s).group(1);return raw
source={x['id']:x.get('result') for x in json.load(open(P.parent/'selected_rpc.json'))}
bridge=[]
for amount,baseh in [(2100,'0x7c75d20788c7c473e94ab0beb6c89ca8ac4d29ccc909fcad21d1b64ef7dc7716'),(25000,'0xeed0e96095f91a6462c263512afdf3bdaa8eb411fe4d1fd2be06937367c8cdf2')]:
 cir=json.load(open(P/f'circle_{amount}_message.json'))['messages'][0];mb=bytes.fromhex(cir['message'][2:]);rec=source[f'bridge_{amount}'];assert rec['status']=='0x1';events=[l for l in rec['logs'] if l['topics'][0]==SENT];assert len(events)==1 and dyn(events[0]['data'])==mb
 raw=rawinput(P/f'mint{amount}_tx.html');assert raw[:10]=='0x57ecfd28';assert dyn(raw[10:])==mb and dyn(raw[10:],1)==bytes.fromhex(cir['attestation'][2:]);dest=receipts[baseh];assert dest['status']=='0x1';mint=[l for l in dest['logs'] if l['address']==U and l['topics'][0]==TRANS and int(l['topics'][1],16)==0 and '0x'+l['topics'][2][-40:]==A];assert len(mint)==1 and int(mint[0]['data'],16)==amount*10**6
 d=msg_fields(cir['message']);assert d['nonce']==int(cir['eventNonce']) and d['USDC']==str(amount) and d['source_domain']==0 and d['destination_domain']==6;d.update(source_tx=rec['transactionHash'],destination_tx=baseh,source_status='0x1',destination_status='0x1',source_MessageSent_matches_Circle=True,destination_message_and_attestation_match_Circle=True);bridge.append(d)
# Return source on Base and destination Ethereum receiveMessage data.
cir=json.load(open(P/'circle_return_message.json'))['messages'][0];mb=bytes.fromhex(cir['message'][2:]);rec=receipts['0x15b8d8a7c4236684cc220eb046cb23b414acccd055018d1da594043d2c2ad2f8'];events=[l for l in rec['logs'] if l['topics'][0]==SENT];assert len(events)==1 and dyn(events[0]['data'])==mb
back={x['id']:x.get('result') for x in json.load(open(P.parent/'return_rpc.json'))};raw=back['return_mint_tx']['input'];assert raw[:10]=='0x57ecfd28' and dyn(raw[10:])==mb and dyn(raw[10:],1)==bytes.fromhex(cir['attestation'][2:]);d=msg_fields(cir['message']);assert d['nonce']==235711 and d['USDC']=='21116.99' and d['source_domain']==6 and d['destination_domain']==0;d.update(source_tx=rec['transactionHash'],destination_tx=back['return_mint_tx']['hash'],source_status='0x1',source_MessageSent_matches_Circle=True,destination_message_and_attestation_match_Circle=True)
ethreturn={x['id']:x['result'] for x in json.load(open(P.parent/'return_drpc.json'))}
for label in ['return_mint','return_to_1991']:assert ethreturn[label]['status']=='0x1'
ethU='0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
for label,frm,to in [('return_mint','0x'+'0'*40,A),('return_to_1991',A,'0x1991e27e2908847c0274a662eb6675002e8386d0')]:
 logs=[l for l in ethreturn[label]['logs'] if l['address']==ethU and l['topics'][0]==TRANS and '0x'+l['topics'][1][-40:]==frm and '0x'+l['topics'][2][-40:]==to];assert len(logs)==1 and int(logs[0]['data'],16)==21116990000
assert ethreturn['return_mint']['transactionHash']==d['destination_tx']
d.update(destination_status='0x1',destination_mint_log_verified=True,onward_to_1991_tx=ethreturn['return_to_1991']['transactionHash'],onward_to_1991_USDC='21116.99',onward_to_1991_status='0x1');bridge.append(d)
# Pin inventory before first mint, after first return, and at captured current head.
# Inventory request bodies were reconstructed from actual original tool calls.
request_maps={}
for name in ['base_inventory_snapshots','bamboo_inventory_metadata']:
 record=json.load(open(P/(name+'_request_reconstruction.json')))
 assert record['response_sha256']==hashlib.sha256((P/(name+'.json')).read_bytes()).hexdigest()
 request_maps.update({r['id']:r for r in record['jsonrpc_request_body']})
for i,tok in [(200,U),(201,B),(202,U),(203,B),(204,U),(205,B),(300,B)]:
 req=request_maps[i];assert req['method']=='eth_call' and req['params'][0]=={'to':tok,'data':'0x70a08231'+A[2:].rjust(64,'0')}
assert request_maps[200]['params'][1]==request_maps[201]['params'][1]==hex(16925276)
assert request_maps[202]['params'][1]==request_maps[203]['params'][1]==rec['blockNumber']
assert request_maps[204]['params'][1]==request_maps[205]['params'][1]==request_maps[300]['params'][1]==request_maps[206]['params'][0]
snap={x['id']:x for x in json.load(open(P/'base_inventory_snapshots.json'))};assert int(snap[200]['result'],16)==0 and int(snap[201]['result'],16)==0
postusdc=Decimal(int(snap[202]['result'],16))/10**6;postbamboo=Decimal(int(snap[203]['result'],16))/10**18;assert postusdc==Decimal('0.008523') and postbamboo==Decimal('1911181.851848323949800498')
nowmeta={x['id']:x for x in json.load(open(P/'bamboo_inventory_metadata.json'))};assert int(nowmeta[300]['result'],16)==1;currentUSDC=Decimal(int(snap[204]['result'],16))/10**6;assert currentUSDC==Decimal('0.003937')
name=dyn(nowmeta[301]['result']).decode();symbol=dyn(nowmeta[302]['result']).decode();assert symbol=='BAMBOO';head=snap[206]['result'];inventory={'before_first_mint_block':16925276,'before_first_mint_USDC':'0','before_first_mint_BAMBOO':'0','after_first_return_block':int(rec['blockNumber'],16),'after_first_return_USDC':str(postusdc),'after_first_return_BAMBOO':str(postbamboo),'current_block':int(head['number'],16),'current_block_hash':head['hash'],'current_block_utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'current_USDC':str(currentUSDC),'current_BAMBOO_raw':'1','current_BAMBOO':'0.000000000000000001','onchain_token_name':name,'onchain_token_symbol':symbol}
summary={'wallet':A,'chain':'Base','chain_id':8453,'all_explorer_token_rows':505,'first_token_row_utc':min(r['utc'] for r in rows),'last_token_row_utc':max(r['utc'] for r in rows),'forward_bridge_total_USDC':'27100','BAMBOO_buy_transactions':8,'BAMBOO_sell_transactions':14,'successful_raw_swap_receipts':22,'raw_transfer_logs_matched_to_explorer_rows':sum(rpc.values()),'USDC_spent_buying_BAMBOO':str(spent),'BAMBOO_acquired':'3911181.851848323949800498','USDC_received_selling_BAMBOO':str(received),'USDC_trading_cash_difference_before_native_gas':str(received-spent),'first_return_bridge_USDC':'21116.99','bridges':bridge,'inventory':inventory,'cautions':['USDC trading cash difference excludes native ETH gas and fiat valuation; no missing-money or loss conclusion.','Current inventory reflects subsequent transactions. July18 residual inventory must accompany the first-return amount.','Same wallet bridge and token trading proven; human key holder, authorization, exchange customer and original Mintlayer payment attribution remain outside this lane.']}
(P/'verified_trades.json').write_text(json.dumps(trades,indent=2));(P/'verified_bridges.json').write_text(json.dumps(bridge,indent=2));(P/'base_verified_summary.json').write_text(json.dumps(summary,indent=2));(P/'all_base_token_events.json').write_text(json.dumps(rows,indent=2));print(json.dumps(summary,indent=2))
