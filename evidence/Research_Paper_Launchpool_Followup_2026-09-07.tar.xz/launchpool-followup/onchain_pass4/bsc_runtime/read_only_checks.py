from pathlib import Path
import sys,json,urllib.request,datetime,hashlib
P=Path(__file__).parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'; URL='https://bsc-dataseed.bnbchain.org'
records=[]
def fetch(name,payload):
 r={'name':name,'url':URL,'method':'POST','request':payload,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  q=urllib.request.Request(URL,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'})
  with urllib.request.urlopen(q,timeout=30) as z:b=z.read();r.update(status=z.status)
  (P/(name+'.json')).write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());out=json.loads(b)
 except Exception as e:r['error']=str(e);out=None
 records.append(r);(P/'rpc_receipts.json').write_text(json.dumps(records,indent=2));print(name,r.get('error','ok'),flush=True);return out
h=fetch('head',{'jsonrpc':'2.0','id':1,'method':'eth_getBlockByNumber','params':['latest',False]})
if not h or 'result' not in h:raise SystemExit
block=h['result']['number']
O='0x77bfe8d704b1948374bf8dab8328a810b2836e66';N='0x1111111111111111111111111111111111111111';calls=[];mapping={}
def add(label,method,params):
 i=len(calls)+1;calls.append({'jsonrpc':'2.0','id':i,'method':method,'params':params});mapping[str(i)]=label
sel=lambda s: '0x'+keccak256(s.encode()).hex()[:8]
add('owner','eth_call',[{'to':A,'data':sel('owner()')},block])
add('runtime','eth_getCode',[A,block])
for label,caller in [('nonowner',N),('current_owner_simulation',O)]:
 for pid in [19,125]:add(f'claimFundRaising_{label}_pool{pid}','eth_call',[{'from':caller,'to':A,'gas':'0x4c4b40','data':sel('claimFundRaising(uint256)')+pid.to_bytes(32,'big').hex()},block])
for slot in [0,1,4]:add(f'storage_slot_{slot}','eth_getStorageAt',[A,hex(slot),block])
for pid in [19,125]:
 for slot,label in [(7,'reward_per_block'),(15,'total_raised'),(17,'funds_claimed')]:
  key=int.from_bytes(keccak256(pid.to_bytes(32,'big')+slot.to_bytes(32,'big')),'big')
  add(f'storage_{label}_pool{pid}','eth_getStorageAt',[A,hex(key),block])
(P/'rpc_request_map.json').write_text(json.dumps({'block':block,'block_decimal':int(block,16),'labels':mapping},indent=2))
r=fetch('selected_runtime_checks',calls)
print(json.dumps({'block':block,'results':[(mapping[str(x['id'])],x.get('error',x.get('result',''))[:100] if isinstance(x.get('error',x.get('result','')),str) else x.get('error')) for x in r]} if r else {},indent=2))
