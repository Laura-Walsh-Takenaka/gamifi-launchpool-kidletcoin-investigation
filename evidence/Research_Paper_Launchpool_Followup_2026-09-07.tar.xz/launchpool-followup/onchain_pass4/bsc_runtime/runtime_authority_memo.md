# D975 fundraising withdrawal authority — exact-runtime review

Read-only investigation, 7 September 2026. Contract: **0xd975b13cdf91de3aa0e0e888fb827fec3650624a**, BSC. This analysis uses its actual deployed runtime rather than importing the different Ethereum 689c source.

## Result

The selected D975 runtime path for **claimFundRaising(uint256)** requires the caller to equal the contract's owner and constructs a fundraising-token transfer **to the owner at the time of execution**. The amount is the selected pool's recorded total raised. It marks the pool's funds-claimed flag and emits the corresponding fundraising-claimed event. Historical owner identity and actual historical token receipts remain separate evidence questions.

At pinned block **120,448,587**, hash `0x62ac42c4814acc68d787b7aef565461366f09602dfc87d1f95b67e8d55245610`, timestamp **2026-09-07 06:44:32 UTC**, `owner()` and raw storage slot 0 both return **0x77bfe8d704b1948374bf8dab8328a810b2836e66**. The 12,612-byte runtime is unchanged from pass 3; its decoded-byte SHA-256 is `34aaf9e747ed09ee4655869f287158525de2a1f3f50961e477fcd12171a4ef0d`.

## Independent observations

| Check | Result |
|---|---|
| Nonowner `eth_call`, pool 19 | Reverted: `Ownable: caller is not the owner` |
| Nonowner `eth_call`, pool 125 | Same ownership rejection |
| `eth_call` with current owner as simulated sender, pool 19 | Passed ownership check, then reverted: `claimFundRaising: Already claimed funds` |
| Same simulated sender, pool 125 | Same already-claimed rejection |
| Slot 0 | Current owner address above |
| Slot 1 | 1, consistent with the idle reentrancy guard state |
| Slot 4 | 153, the pool-array length |
| `keccak256(pid || 15)`, pools 19 / 125 | Matches the previously recovered total-raised counters |
| `keccak256(pid || 17)`, pools 19 / 125 | Low byte 1 in both cases, consistent with funds already claimed |

All calls used `eth_call`, `eth_getCode`, `eth_getStorageAt` or `eth_getBlockByNumber`. The simulated sender parameter does not require or demonstrate possession of that address's signing key. No transaction was signed, sent or mined, and no chain state was changed.

## Selected bytecode evidence

The recovered ABI name is used to identify selector **0x67a49923**, which is present in D975's dispatcher. The behavior below is established from D975 itself.

| Runtime location | Interpretation |
|---|---|
| Dispatcher `0x018e`; entry `0x02e9` | Selects `claimFundRaising(uint256)`, decodes its pool ID and jumps into body `0x0bd2` |
| `0x0bd2`–`0x0bfa` | Reentrancy guard: rejects status 2, then sets slot 1 to 2 |
| Caller helper `0x1f34` | Returns the EVM `CALLER` |
| Owner helper `0x12e3` | Returns the low 160 bits of storage slot 0 |
| `0x0bfb`–`0x0c38` | Compares caller with owner; mismatch constructs the Ownable rejection |
| `0x0c39`–`0x0cb9` | Requires an in-range pool and a nonzero reward-per-block mapping value (slot 7) |
| `0x0cba`–`0x0d05` | Requires the slot-17 claimed flag to be false, then sets it true |
| `0x0d06`–`0x0d4f` | Selects the pool's fundraising-token field, loads owner as recipient and slot-15 pool counter as amount, and encodes `transfer(address,uint256)` selector `0xa9059cbb` |
| `0x0d6d` | Calls that token contract; a reverted/failed EVM call bubbles its failure |
| `0x0d96`–`0x0da3` | ABI-decodes the returned boolean, then discards it rather than requiring true |
| `0x0da4`–`0x0dff` | Emits event topic `0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089`, with pool ID, owner and recorded amount |
| `0x0e02`–`0x0e07` | Restores reentrancy status 1 and returns |

Getter-dispatch checks independently associate slot 15 with `poolIdToTotalRaised(uint256)`, selector `0x07ac1ea8`; slot 17 with `poolIdToFundsClaimed(uint256)`, selector `0xb9641a21`; and slot 7 with `poolIdToRewardPerBlock(uint256)`, selector `0xd53e7bcb`. The pool struct starts at `keccak256(uint256(4))`, has seven slots per entry, and uses offset +1 for its fundraising-token field. Exact selected instructions are retained in `selected_disassembly.json`.

The separate peer reviewer reproduced the selected runtime path in an offline interpreter with synthetic storage. Its constructed CALL data matched `transfer(current owner, selected pool totalRaised)`. Both canonical true and false token return values allowed the function to complete and emit its event. Those synthetic checks verify control flow; they are not historical transactions or evidence that BUSD ever returned false here. Peer-review files are under `../peer_review/`.

## Meaning and limits

This establishes the current runtime's **on-chain authority and intended transfer destination**. It does not establish that 77bf was owner at a particular historical withdrawal, that Laura controls 77bf, or the legal owner of funds. The destination is the owner getter at execution time; it is not a separately immutable treasury or named person's address.

Because the function discards the token's returned boolean, a claimed flag or emitted claim event alone is weaker evidence than a successful fundraising-token Transfer receipt. This is a bytecode-level observation, not an allegation of a failed BUSD transfer. The parallel settlement lane must continue to verify the actual token transfers and recipients for each claimed amount.

Historical owner reads at blocks **13,125,200** and **16,525,000** both failed with `missing trie node`. Two additional token-field storage reads at the previously pinned current block also returned that error; those failures are recorded, not converted into zero values. Owner chronology therefore remains unresolved in this lane. Earlier successful dated `poolInfo` token fields remain preserved separately in pass 3.

D975 remains a different executable from the archived Solidity 0.6.12 Ethereum artifact. Its metadata encodes Solidity 0.8.0. This selected-path analysis does not claim whole-contract source equivalence or a complete security audit. No unchanged blocked BscScan, Sourcify or IPFS paths were retried. A bounded web search for the exact address and contract name did not recover matching verified source.

## Reproduction

- `disassemble.py`: offline disassembly of the preserved deployed runtime.
- `read_only_checks.py`: pinned live runtime, owner, selected simulations and storage reads.
- `historical_owner_checks.py`: the two historical owner attempts and two derived token-field storage attempts.
- `summarize_checks.py`: deterministic factual summary and selected instruction extract.
- `runtime_findings.json`: machine-readable results and limitations.
- `rpc_receipts.json`, `historical_owner_receipt.json`: exact public RPC URLs, request bodies, retrieval times, statuses and response hashes.
