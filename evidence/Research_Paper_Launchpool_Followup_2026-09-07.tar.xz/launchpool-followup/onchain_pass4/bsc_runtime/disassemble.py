from pathlib import Path
import json,sys,hashlib
P=Path(__file__).parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
raw=(P.parents[1]/'onchain_pass3/archived_bsc_contracts/d975_deployed_bytecode.txt').read_text().strip()
b=bytes.fromhex(raw[2:])
op={0x00:'STOP',0x01:'ADD',0x02:'MUL',0x03:'SUB',0x04:'DIV',0x05:'SDIV',0x06:'MOD',0x07:'SMOD',0x08:'ADDMOD',0x09:'MULMOD',0x0a:'EXP',0x0b:'SIGNEXTEND',0x10:'LT',0x11:'GT',0x12:'SLT',0x13:'SGT',0x14:'EQ',0x15:'ISZERO',0x16:'AND',0x17:'OR',0x18:'XOR',0x19:'NOT',0x1a:'BYTE',0x1b:'SHL',0x1c:'SHR',0x1d:'SAR',0x20:'KECCAK256',0x30:'ADDRESS',0x31:'BALANCE',0x32:'ORIGIN',0x33:'CALLER',0x34:'CALLVALUE',0x35:'CALLDATALOAD',0x36:'CALLDATASIZE',0x37:'CALLDATACOPY',0x38:'CODESIZE',0x39:'CODECOPY',0x3a:'GASPRICE',0x3b:'EXTCODESIZE',0x3c:'EXTCODECOPY',0x3d:'RETURNDATASIZE',0x3e:'RETURNDATACOPY',0x3f:'EXTCODEHASH',0x40:'BLOCKHASH',0x41:'COINBASE',0x42:'TIMESTAMP',0x43:'NUMBER',0x44:'PREVRANDAO',0x45:'GASLIMIT',0x46:'CHAINID',0x47:'SELFBALANCE',0x48:'BASEFEE',0x50:'POP',0x51:'MLOAD',0x52:'MSTORE',0x53:'MSTORE8',0x54:'SLOAD',0x55:'SSTORE',0x56:'JUMP',0x57:'JUMPI',0x58:'PC',0x59:'MSIZE',0x5a:'GAS',0x5b:'JUMPDEST',0xf0:'CREATE',0xf1:'CALL',0xf2:'CALLCODE',0xf3:'RETURN',0xf4:'DELEGATECALL',0xf5:'CREATE2',0xfa:'STATICCALL',0xfd:'REVERT',0xfe:'INVALID',0xff:'SELFDESTRUCT'}
rows=[];i=0
while i<len(b):
 pc=i;v=b[i];i+=1;arg=''
 if 0x60<=v<=0x7f:n=v-0x5f;arg=b[i:i+n].hex();i+=n;name=f'PUSH{n}'
 elif 0x80<=v<=0x8f:name=f'DUP{v-0x7f}'
 elif 0x90<=v<=0x9f:name=f'SWAP{v-0x8f}'
 elif 0xa0<=v<=0xa4:name=f'LOG{v-0xa0}'
 else:name=op.get(v,f'UNKNOWN_{v:02x}')
 rows.append({'pc':pc,'pc_hex':hex(pc),'opcode':v,'op':name,'arg':arg})
(P/'d975_disassembly.json').write_text(json.dumps(rows,indent=2))
(P/'d975_disassembly.txt').write_text('\n'.join(f"{x['pc']:04x}: {x['op']} {x['arg']}" for x in rows)+'\n')
for sig in ['claimFundRaising(uint256)','owner()','transferOwnership(address)','rewardGuildBank()','poolIdToFundRaised(uint256)','poolIdToFundRaisingClaimed(uint256)']:
 sel=keccak256(sig.encode()).hex()[:8]
 hits=[(j,x) for j,x in enumerate(rows) if x['op']=='PUSH4' and x['arg']==sel]
 print(sig,sel)
 for j,x in hits:print(rows[max(0,j-2):j+5])
