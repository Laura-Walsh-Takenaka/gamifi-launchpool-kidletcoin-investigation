from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).parent
labels=json.loads((P/'rpc_request_map.json').read_text())['labels']
rr=json.loads((P/'selected_runtime_checks.json').read_text());byname={labels[str(x['id'])]:x for x in rr}
head=json.loads((P/'head.json').read_text())['result']
code=byname['runtime']['result'];previous=(P.parents[1]/'onchain_pass3/archived_bsc_contracts/d975_deployed_bytecode.txt').read_text().strip()
def error_text(x):
 h=x['error'].get('data','')
 if h.startswith('0x08c379a0'):
  b=bytes.fromhex(h[10:]);offset=int.from_bytes(b[:32],'big');length=int.from_bytes(b[offset:offset+32],'big');return b[offset+32:offset+32+length].decode()
 return x['error']['message']
summary={'address':'0xd975b13cdf91de3aa0e0e888fb827fec3650624a','block':int(head['number'],16),'block_hash':head['hash'],'block_utc':datetime.datetime.fromtimestamp(int(head['timestamp'],16),datetime.timezone.utc).isoformat(),'runtime_bytes_sha256':hashlib.sha256(bytes.fromhex(code[2:])).hexdigest(),'runtime_unchanged_from_pass3':code.lower()==previous.lower(),'current_owner':'0x'+byname['owner']['result'][-40:],'checks':[]}
for name,x in byname.items():
 if name.startswith('claimFundRaising_'):summary['checks'].append({'check':name,'type':'eth_call simulation, no signature or transaction','result':'reverted','reason':error_text(x)})
 elif name.startswith('storage_'):summary['checks'].append({'check':name,'value_hex':x['result'],'value_decimal':str(int(x['result'],16))})
summary['static_bytecode_findings']={'selector':'0x67a49923','dispatcher_entry':'0x02e9','body_range_inclusive':['0x0bd2','0x0e07'],'caller_helper':'0x1f34','owner_helper':'0x12e3','owner_storage_slot':0,'reentrancy_storage_slot':1,'pool_array_storage_slot':4,'pool_array_stride_slots':7,'reward_per_block_mapping_slot':7,'total_raised_mapping_slot':15,'funds_claimed_mapping_slot':17,'transfer_selector':'0xa9059cbb','transfer_destination':'owner() at the time the function executes','transfer_amount':'poolIdToTotalRaised(pid), mapping slot15','transfer_target':'fundRaisingToken field of selected pool, array fieldoffset1','token_call_pc':'0x0d6d','return_bool_is_required_true':False,'return_bool_discard_pc':'0x0da3','event_topic0':'0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089','event_log_pc':'0x0dff'}
h=json.loads((P/'historical_owner_response.json').read_text());summary['historical_owner_attempts']=[{'block':13125200 if x['id']==1 else 16525000,'error':x['error']} for x in h if x['id'] in [1,2]]
summary['limits']=['Source code for D975 remains unrecovered; interpretation derives from its exact runtime, read-only calls and storage.', 'Current owner is not proof of ownership at historical withdrawals.', 'Simulation from an address does not require or prove possession of its signing key.', 'Pool flags and emitted events alone do not replace successful fundraising-token Transfer receipts; this runtime discards the returned transfer bool after decoding it.', 'Two additional token-field storage reads at the previously pinned current block also failed missing trie node; previous successful poolInfo token fields remain separately dated.']
(P/'runtime_findings.json').write_text(json.dumps(summary,indent=2))
r=json.loads((P/'d975_disassembly.json').read_text());ranges=[('claim_dispatcher',0x18e,0x199),('claim_entry',0x2e9,0x2fc),('claim_body',0xbd2,0xe08),('owner_getter',0x12e3,0x12f2),('caller_helper',0x1f34,0x1f38),('total_raised_getter',0x4c5,0x4d7),('claimed_getter',0x157b,0x1590),('reward_per_block_getter',0x174f,0x1761),('transfer_encoder',0x2452,0x246b),('bool_decoder',0x22ad,0x22c9),('owner_revert_string',0x2b7a,0x2baf),('claimed_revert_string',0x264d,0x2694)]
selections=[]
for name,start,end in ranges:selections.append({'name':name,'start':hex(start),'end_exclusive':hex(end),'instructions':[x for x in r if start<=x['pc']<end]})
(P/'selected_disassembly.json').write_text(json.dumps(selections,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ['checks','static_bytecode_findings','limits']},indent=2))
