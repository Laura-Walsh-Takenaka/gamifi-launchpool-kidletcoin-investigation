from pathlib import Path
import json,sys,urllib.request,datetime,hashlib
P=Path(__file__).parent
sys.path.insert(0,str(P.parents[1]/'claims_peer'))
from verify_claims import keccak256
A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';u='https://bsc-dataseed.bnbchain.org'
payload=[];labels={}
def add(label,method,params):
 i=len(payload)+1;payload.append({'jsonrpc':'2.0','id':i,'method':method,'params':params});labels[str(i)]=label
for label,block in [('raise1_payment_end',13125200),('raise2_payment_end',16525000)]:add(label+'_owner','eth_call',[{'to':A,'data':'0x8da5cb5b'},hex(block)])
block=json.loads((P/'head.json').read_text())['result']['number']
base=int.from_bytes(keccak256((4).to_bytes(32,'big')),'big')
for pid in [19,125]:add(f'current_pool{pid}_fundraising_token_storage','eth_getStorageAt',[A,hex((base+7*pid+1)%(2**256)),block])
r={'url':u,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':payload,'labels':labels}
try:
 with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=30) as z:b=z.read();r['status']=z.status
 (P/'historical_owner_response.json').write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());print(b.decode())
except Exception as e:r['error']=str(e);print(str(e))
(P/'historical_owner_receipt.json').write_text(json.dumps(r,indent=2))
