"""Independent offline review: decode raw RPC records; never call the network."""
from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).parent
D975='0xd975b13cdf91de3aa0e0e888fb827fec3650624a'; OWNER='0x77bfe8d704b1948374bf8dab8328a810b2836e66';BUSD='0xe9e7cea3dedca5984780bafc599bd69add087d56';GAS='0x1aafe5974189e5a854e20617be8176578868da0f';DEST='0xa96be652a08d9905f15b7fbe2255708709becd09'
TRANSFER='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';CLAIM='0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089'
checks=[];sources=[]
def check(name,cond):
 assert cond,name
 checks.append(name)
def amount(n):
 a,b=divmod(n,10**18);return str(a)+(('.'+f'{b:018d}'.rstrip('0')) if b else '')
def read(n):
 f=P/n;sources.append({'path':n,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()});return json.loads(f.read_text())
def rpc(n):
 receipt=read(n+'.receipt.json');response=read(n+'.response');byid={x['id']:x for x in response}
 check(n+' response hash equals captured hash',sources[-1]['sha256']==receipt['sha256'])
 out={}
 for q in receipt['request']:
  x=byid[q['id']];check(n+' response '+str(q['id'])+' successful data','result' in x and x['result'] is not None)
  x=x['result'];h=q['params'][0];check(n+' requested hash preserved '+h,x.get('hash',x.get('transactionHash'))==h)
  out[(q['method'],h)]=x
 return out
raw={}
for n in ['owner_d975_calls','claim_and_onward_receipts','circularr_exit_receipts']:raw.update(rpc(n))
claims=[];transfers=[]
for (method,h),rec in raw.items():
 if method!='eth_getTransactionReceipt':continue
 tx=raw[('eth_getTransactionByHash',h)]
 check(h+' success',int(rec['status'],16)==1)
 check(h+' BSC chainId',int(tx['chainId'],16)==56)
 check(h+' matching tx/receipt identity',all(rec[k]==tx[k] for k in ['from','to','blockNumber','blockHash','transactionIndex']))
 check(h+' zero native value',int(tx['value'],16)==0)
 logs=rec['logs'];busd=[];events=[];times=set()
 for l in logs:
  check(h+' log identity '+l['logIndex'],l['transactionHash']==h and l['blockHash']==rec['blockHash'] and l['blockNumber']==rec['blockNumber'] and not l.get('removed',False))
  if 'blockTimestamp' in l:times.add(int(l['blockTimestamp'],16))
  if l['address']==BUSD and l['topics'][0]==TRANSFER:
   check(h+' standard token Transfer encoding',len(l['topics'])==3 and len(l['data'])==66)
   busd.append({'from':'0x'+l['topics'][1][-40:],'to':'0x'+l['topics'][2][-40:],'amount':int(l['data'],16),'log_index':int(l['logIndex'],16)})
  if l['address']==D975 and l['topics'][0]==CLAIM:
   check(h+' standard FundRaisingClaimed encoding',len(l['topics'])==3 and len(l['data'])==66)
   events.append({'pid':int(l['topics'][1],16),'recipient':'0x'+l['topics'][2][-40:],'amount':int(l['data'],16),'log_index':int(l['logIndex'],16)})
 check(h+' one consistent RPC log timestamp',len(times)==1);ts=next(iter(times))
 check(h+' exactly one BUSD transfer',len(busd)==1);b=busd[0]
 row={'tx':h,'block':int(rec['blockNumber'],16),'block_hash':rec['blockHash'],'timestamp':ts,'utc':datetime.datetime.fromtimestamp(ts,datetime.timezone.utc).isoformat(),'from':b['from'],'to':b['to'],'amount_raw':str(b['amount']),'amount_busd':amount(b['amount'])}
 inp=tx['input']
 if tx['to']==D975:
  check(h+' actual claim caller',tx['from']==OWNER)
  check(h+' claim selector and single uint256',inp[:10]=='0x67a49923' and len(inp)==74)
  pid=int(inp[10:],16);check(h+' single matching claim event',len(events)==1 and events[0]['pid']==pid)
  e=events[0];check(h+' event and BUSD payout agree',b['from']==D975 and b['to']==OWNER and e['recipient']==OWNER and e['amount']==b['amount'] and b['log_index']<e['log_index'])
  row['pid']=pid;claims.append(row)
 else:
  check(h+' BUSD direct transfer invocation',tx['to']==BUSD and inp[:10]=='0xa9059cbb' and len(inp)==138)
  check(h+' transfer calldata exactly matches log',b['from']==tx['from'] and b['to']=='0x'+inp[10:74][-40:] and b['amount']==int(inp[74:],16));transfers.append(row)
check('18 distinct original claims',len(claims)==18 and len({x['tx'] for x in claims})==18)
check('six independent onward transfer records',len(transfers)==6)
config=read('../bsc_project_mapping/project_pool_mapping.json')
project_by_pid={int(pid):r['fields']['title'] for r in config if r['fields']['contractAddress'].lower()==D975 and r['fields']['network']=='BSC' for pid in r['fields']['pools']}
check('exclude original Mintlayer six pools',not ({x['pid'] for x in claims}&{19,20,21,125,126,127}))
groups={}
for c in claims:
 p=project_by_pid[c['pid']];g=groups.setdefault(p,{'pids':[],'amount':0,'transactions':[],'dates':set()});g['pids'].append(c['pid']);g['amount']+=int(c['amount_raw']);g['transactions'].append(c['tx']);g['dates'].add(c['utc'][:10])
summary=read('summary.json')
for g in summary['groups']:
 r=groups[g['project_from_config']]
 check(g['project_from_config']+' exact base-unit sum',int(g['amount_raw'])==r['amount'])
 check(g['project_from_config']+' exact decimal sum',g['amount_busd']==amount(r['amount']))
 check(g['project_from_config']+' exact pool membership',set(g['pids'])==set(r['pids']))
 check(g['project_from_config']+' exact tx membership',set(g['transactions'])==set(r['transactions']))
 check(g['project_from_config']+' date',r['dates']=={g['date_utc']})
check('summary exactly six groups',len(groups)==len(summary['groups'])==6)
total=sum(x['amount'] for x in groups.values());check('summary grand total exact',summary['total_busd']==amount(total))
index={x['tx']:x for x in transfers}
fund=index['0x961b7f971bf3e7022dba7670582b14e40f2b88cae7c82d02c111d72f94455de4'];check('60k to exact gas funder',fund['from']==OWNER and fund['to']==GAS and int(fund['amount_raw'])==60000*10**18)
check('60k transfer follows all three Circularr withdrawals',fund['timestamp']>max(x['timestamp'] for x in claims if project_by_pid[x['pid']]=='Circularr'))
branches=[]
for first,second,intermediate,n in [('0xdb7e8484e7e4c791a93f88794bd376fab580bfa8ca89606e4cbe2a908200e800','0x8e6a1250a9c8ad44355b73f28ca417c695996359804315c5064a027ad08584b0','0xe99382e72a005c0d57f20ed31cb519101273c756',100),('0x6330c83f1fb369310252045d55667ad35ee44de6542df02abf721d3760c44162','0x4b3cd1c39ec640f3aeb64e13676cd526ff8200211c57f202c00c5f0f736861b1','0x869c3e3fcc15b801727dabca6cdfeba89e743327',59900)]:
 a=index[first];b=index[second]
 check(str(n)+' branch exact full addresses',a['from']==GAS and a['to']==intermediate and b['from']==intermediate and b['to']==DEST)
 check(str(n)+' branch exact integer conservation',int(a['amount_raw'])==int(b['amount_raw'])==n*10**18)
 check(str(n)+' branch time ordering',fund['timestamp']<a['timestamp']<b['timestamp'])
 branches.append({'amount_busd':str(n),'intermediate':intermediate,'incoming_tx':first,'outgoing_tx':second,'incoming_utc':a['utc'],'outgoing_utc':b['utc'],'seconds_between_hops':b['timestamp']-a['timestamp']})
check('60k split sums exactly',sum(int(x['amount_busd']) for x in branches)==60000)
gas_source=P.parents[1]/'onchain_pass2/gas_control/prior_treasury_txlist.json';gas_record=next(x for x in json.loads(gas_source.read_text())['result'] if x['hash']=='0x71cfd39e902af8ec5a743064bcfef762dd48b7a1de1de84aabf8edf076e7799f')
check('same full address as prior Ethereum gas funder',gas_record['from']==GAS and gas_record['to']=='0x6c2b3a90acb72ef896325e19af9098d157f929c4' and gas_record['value']=='10000000000000000' and gas_record['txreceipt_status']=='1')
hinata=index['0xdd2f6f2a0947f5399476cf91b3828d744716930b3380acff9cceac29be8c42d9'];hinata_delta=groups['Hinata']['amount']-int(hinata['amount_raw']);check('Hinata precise observed difference',hinata_delta==917669310);check('Hinata onward after final claim by528seconds',hinata['timestamp']-max(x['timestamp'] for x in claims if project_by_pid[x['pid']]=='Hinata')==528)
check('Circularr60k after final claim by141seconds',fund['timestamp']-max(x['timestamp'] for x in claims if project_by_pid[x['pid']]=='Circularr')==141)
labels=read('exchange_label_sources.json');check('exchange label is exact observed destination',labels['label_address']==DEST)
check('BSC-specific attribution source supplied',any(s.get('chain')=='BNB Smart Chain' and '/bsc/address/'+DEST in s['url'] and 'ChangeNOW' in s['label'] for s in labels['sources']))
rounding=[]
for filename in ['binplorer_owner_busd_history.response','binplorer_gasfunder_busd_history.response','binplorer_e993_busd_history.response','binplorer_869c_busd_history.response']:
 d=json.loads((P/filename).read_text())
 for op in d.get('operations',[]):
  if op['transactionHash'] in index:
   actual=index[op['transactionHash']]
   if op['from']==actual['from'] and op['to']==actual['to']:
    displayed=int(op['value']);exact=int(actual['amount_raw'])
    if displayed!=exact:rounding.append({'file':filename,'tx':op['transactionHash'],'indexer_raw':str(displayed),'rpc_raw':str(exact),'difference_base_units':str(displayed-exact)})
result={'verdict':'PASS with stated attribution and history limits','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks_passed':len(checks),'claim_count':len(claims),'claim_total_busd':amount(total),'groups':[{**{k:v for k,v in r.items() if k not in ['amount','dates']},'project':name,'amount_raw':str(r['amount']),'amount_busd':amount(r['amount']),'dates':sorted(r['dates'])} for name,r in groups.items()],'circularr_total_busd':amount(groups['Circularr']['amount']),'hinata_observed_difference_busd':amount(hinata_delta),'circularr_selected_inflow_less_60k_outflow_busd':amount(groups['Circularr']['amount']-60000*10**18),'branch_destination':DEST,'branches':branches,'owner_to_gasfunder':fund,'prior_ethereum_gas_transaction':gas_record['hash'],'amount_source':'Raw successful RPC receipt BUSD Transfer log data; integer arithmetic with18decimals','indexer_precision_differences':rounding,'source_hashes':sources,'limits':['Labels are explorer attribution, including root-provided BSC-specific OKLink evidence; no exchange customer, ChangeNOW order or output payout is identified.','Circularr-to60k link is a documented timed flow through a shared wallet; no unverified historical zero starting balance or exclusive-source tracing claim.','526.6449367719358245 BUSD is the difference between the selected three inflows and60koutflow, not a newly measured account balance.','This18claim sample covers six other projects; it is neither a full153pool census nor the original Mintlayer settlement receipts.','Times were checked against consistent timestamp fields supplied in raw RPC logs, not newly fetched independent historical block headers.','The same gas-funder address appears on Ethereum and BSC; no human identity follows from that address match.']}
(P/'peer_review.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k in ['verdict','checks_passed','claim_total_busd','circularr_total_busd','circularr_selected_inflow_less_60k_outflow_busd','indexer_precision_differences']},indent=2))
