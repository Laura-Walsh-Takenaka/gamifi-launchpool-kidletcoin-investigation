import importlib.util,json,pathlib
P=pathlib.Path(__file__).parent;s=importlib.util.spec_from_file_location('r',P/'rpc_helper.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
a=json.loads((P/'binplorer_owner_transactions.response').read_text());a=[x for x in a if x.get('to')==r.A];qs=[{'jsonrpc':'2.0','id':i+1,'method':'eth_getTransactionByHash','params':[x['hash']]} for i,x in enumerate(a)]
print('querying',len(qs),'specific indexed D975 calls');x=r.rpc('owner_d975_calls',qs)
R=P.parents[1];spec=importlib.util.spec_from_file_location('v',R/'claims_peer/verify_claims.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
abi=json.loads((R/'onchain_pass3/archived_bsc_contracts/raise1_last_fundraising_abi.json').read_text())['abi'];sel={}
for q in abi:
 if q['type']=='function':
  sig=q['name']+'('+','.join(i['type'] for i in q['inputs'])+')';sel['0x'+v.keccak256(sig.encode()).hex()[:8]]=sig
out=[]
for i in x or []:
 if not i.get('result'):print(i);continue
 t=i['result'];inp=t['input'];out.append({'tx':t['hash'],'from':t['from'],'block':int(t['blockNumber'],16),'method':sel.get(inp[:10],inp[:10]),'first_parameter':int(inp[10:74],16) if len(inp)>=74 else None,'input':inp})
(P/'owner_calls_decoded.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2)[:24000])
