# BSC settlements: actual withdrawals and a ChangeNOW route

Retrieved 7 September 2026. This pass recovered **18 successful fundraising withdrawals totaling 1,918,188.019570683808515907 BUSD** from Launchpool's BSC contract `0xd975b13cdf91de3aa0e0e888fb827fec3650624a` into `0x77bfe8d704b1948374bf8dab8328a810b2836e66`.

The recovered withdrawals concern six projects other than Mintlayer. Their exact pool IDs were matched to the public Launchpool application configuration by the separate `../bsc_project_mapping/` lane, including the contract address and BSC network. A pool number alone is insufficient because IDs repeat across deployments. The configuration was read in 2026; transaction dates below come from historical BSC receipts.

## Actual received amounts

| Project mapping | Pool IDs | UTC date | BUSD received by 77bf |
|---|---|---|---:|
| Championfy | 68, 69, 70 | 2023-01-11 | 452941.643436827790107713 |
| Spark World | 134, 135, 136 | 2023-03-30 | 80117.358323940697139962 |
| Yesports | 80, 81, 82 | 2023-04-13 | 396930.330400262063764776 |
| 5ire | 56, 57, 58 | 2023-04-20 | 454964.151441835747044046 |
| Hinata | 39, 40, 41 | 2023-04-25 | 472707.89103104557463491 |
| Circularr | 146, 147, 148 | 2024-07-03 | 60526.6449367719358245 |
| **Total: selected 18 withdrawals** | | | **1918188.019570683808515907** |

For every entry, the fresh RPC transaction input decodes to `claimFundRaising(pid)`, the receipt status is successful, the contract's `FundRaisingClaimed` event identifies the same pool and recipient, and the BUSD contract's `Transfer` event matches the exact amount. All 18 actual recipients are 77bf. This is a historical receipt finding in addition to the previous current-owner finding.

## Circularr: 60000 BUSD reaches a ChangeNOW-labeled address

On 3 July 2024, pools 146–148 paid **60526.6449367719358245 BUSD** to 77bf in three transactions between 14:59:23 and 15:34:38 UTC.

At **15:36:59 UTC**, 77bf sent **60000 BUSD** to `0x1aafe5974189e5a854e20617be8176578868da0f`, transaction `0x961b7f971bf3e7022dba7670582b14e40f2b88cae7c82d02c111d72f94455de4`. This occurred **2 minutes 21 seconds** after the final Circularr claim. This same 1aafe address was independently identified in the earlier Ethereum investigation as a gas funder of the ML treasury in May 2025. The new BSC evidence establishes a cash-transfer relationship between two already relevant operational addresses.

On 4 July 2024, 1aafe split exactly 60000 BUSD into two branches, which converged on `0xa96be652a08d9905f15b7fbe2255708709becd09`:

| UTC time | From | To | BUSD | Transaction |
|---|---|---|---:|---|
| 16:44:57 | 1aafe | `0xe99382e72a005c0d57f20ed31cb519101273c756` | 100 | `0xdb7e8484e7e4c791a93f88794bd376fab580bfa8ca89606e4cbe2a908200e800` |
| 16:46:54 | e993 | `0xa96be652a08d9905f15b7fbe2255708709becd09` | 100 | `0x8e6a1250a9c8ad44355b73f28ca417c695996359804315c5064a027ad08584b0` |
| 16:52:51 | 1aafe | `0x869c3e3fcc15b801727dabca6cdfeba89e743327` | 59900 | `0x6330c83f1fb369310252045d55667ad35ee44de6542df02abf721d3760c44162` |
| 16:54:35 | 869c | `0xa96be652a08d9905f15b7fbe2255708709becd09` | 59900 | `0x4b3cd1c39ec640f3aeb64e13676cd526ff8200211c57f202c00c5f0f736861b1` |

All four branches were freshly verified by BSC RPC: successful receipts, direct caller, `transfer(address,uint256)` inputs, exact BUSD token address, and matching transfer logs. The intermediaries passed on their respective amounts in **117 seconds** and **104 seconds**.

Root independently verified a **BSC-specific OKLink label, “ChangeNOW. Withdraw_1”**, for the final address. Blockscan and Etherscan also label the same address **“ChangeNOW: Hot Wallet 2.”** Relevant source URLs and qualification are in `exchange_label_sources.json`. The BSC transfer evidence is independent of the label. The label identifies a service-associated destination; the exchange order, customer, output asset, payout address, and human controller remain unresolved.

The sequence and amount conservation establish the recorded route. The 77bf account can mix balances, so no unique-token earmarking or undocumented settlement purpose is asserted. Zero-value transfers and dust from lookalike addresses appear in the index and were excluded from the financial route.

## Hinata: a separate onward payment

Hinata's three pools paid **472707.89103104557463491 BUSD** to 77bf between 08:24:32 and 08:25:26 UTC on 25 April 2023. At **08:34:14 UTC**, 77bf sent **472707.8910310446569656 BUSD** to `0x9a7c8ae50ee2bae50d32e153513d843b14a920ed`, transaction `0xdd2f6f2a0947f5399476cf91b3828d744716930b3380acff9cceac29be8c42d9`.

That successful direct transfer occurred **8 minutes 48 seconds** after the final claim. The difference between the three receipts and this payment is **0.00000000091766931 BUSD**. Exact-address searching recovered no useful recipient label in this pass. Its onward history was outside this bounded lane.

## Mintlayer boundary and methods

Original Mintlayer withdrawals for pools **19, 20, 21, 125, 126, 127** remain unrecovered. The new public API returned the latest 100 BSC transactions of 77bf, spanning 6 January 2023 to 12 August 2026; 55 called D975, and none of those 55 inputs selected the six Mintlayer pools. This observation covers only that returned window. The existing 903794.346419582485370326 BUSD Mintlayer raised-counter finding remains separate from these six other projects' actual withdrawals. The monetary figures here are not loss estimates or personal receipts by Laura.

The new route used Binplorer's documented public API with its published `freekey`, a maximum of 100 records per request, and no timestamp paging beyond documented access limits. Six API requests recovered bounded transaction/token histories. Three promising blocks from independent Tokenview search results were also retrieved exactly by BNB RPC; they concerned unrelated pool operations and were rejected as target-settlement leads. No previously denied BscScan endpoint or rejected historical log request was repeated. No accounts, paid access, signatures, transactions, or outside messages were used.

Binplorer's displayed raw token values had small rounding differences relative to BSC receipt logs. Every reported amount above uses the **exact RPC event integer divided by 10^18**, with integer summation and high-precision Decimal conversion. Its current token-price fields were not used.

## Evidence

- `summary.json`: exact project group totals and remaining boundaries.
- `verified_cash_transfers.csv`: all 18 withdrawals and six subsequent verified transfers, with full addresses, amounts, block numbers, and hashes.
- `owner_d975_calls.response`: 55 exact normal transaction inputs; accompanying receipt preserves all requests.
- `claim_and_onward_receipts.response`: 18 fundraising receipts, the 60000 and Hinata onward receipts, and their normal transaction records.
- `circularr_exit_receipts.response`: four split-and-forward receipts and four corresponding normal transactions.
- `claims_and_onward_verified.json` / `circularr_exit_verified.json`: decoded events and transfer agreement.
- `binplorer_*.response` and matching receipts: original discovery records, including excluded zero/dust operations.
- `search_provenance.json`: exact search queries, useful primary-source URLs, and API documentation constraints.
- `exchange_label_sources.json`: chain-qualified explorer labels, independently reviewed by root.
- `../bsc_project_mapping/project_pool_mapping.json`: explicit D975/BSC project mapping; other deployment matches excluded.
