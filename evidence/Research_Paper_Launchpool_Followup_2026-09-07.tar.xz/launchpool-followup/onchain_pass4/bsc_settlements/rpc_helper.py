import json,hashlib,datetime,pathlib,urllib.request
P=pathlib.Path(__file__).parent;A='0xd975b13cdf91de3aa0e0e888fb827fec3650624a';U='https://bsc-dataseed.bnbchain.org';TX='0x56ba03b73564c3c110319c4c056230441b58c89a8cdaff071cfe71afc3912da9'
def rpc(name,qs):
 r={'url':U,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':qs}
 try:
  with urllib.request.urlopen(urllib.request.Request(U,data=json.dumps(qs).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=35) as z:
   b=z.read();r.update(status=z.status,sha256=hashlib.sha256(b).hexdigest());(P/(name+'.response')).write_bytes(b);x=json.loads(b)
 except Exception as e:r['error']=str(e);x=None
 (P/(name+'.receipt.json')).write_text(json.dumps(r,indent=2));return x
