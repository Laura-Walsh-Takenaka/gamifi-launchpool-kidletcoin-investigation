# Independent peer review — BSC withdrawals and Circularr exit

**Verdict: PASS.** Offline review on 7 September 2026 independently confirms the reported receipt amounts, project group membership, transaction identities, calldata, timestamps and selected onward transfer conservation. No correction to the financial figures in `summary.json` or `MEMO.md` is required.

The review decoded the raw RPC records itself, without calling the original verification functions or making new network requests. `peer_review_verify.py` reproduces the checks; `peer_review.json` contains results and input hashes. All 535 assertions passed.

## Confirmed

- **18 successful D975 withdrawals**, each from a transaction signed from address **0x77bfe8d704b1948374bf8dab8328a810b2836e66**, each with calldata selector `0x67a49923` and the expected pool ID, and each carrying a matching `FundRaisingClaimed` event and actual BUSD `Transfer` log to that same address. BSC chain ID 56, transaction/receipt/block/log hashes, statuses and log identities agree.
- The six project groups total exactly **1,918,188.019570683808515907 BUSD**, using raw integer log amounts and 18-decimal formatting. Their pool IDs, transaction membership and dates agree with `summary.json` and the exact D975/BSC app configuration. None is one of the six original Mintlayer pools.
- Circularr's three withdrawals total exactly **60,526.6449367719358245 BUSD**. The subsequent **60,000 BUSD** payment to **0x1aafe5974189e5a854e20617be8176578868da0f** occurred **141 seconds** after the last withdrawal. Calldata and the actual token transfer agree.
- The 1aafe address matches the previously preserved Ethereum transaction that sent **0.01 ETH** to the ML treasury on 29 May 2025. This is an exact address/transaction relationship, without a human identity inference.
- The two subsequent branches carry exactly **100 BUSD** through **0xe99382e72a005c0d57f20ed31cb519101273c756** and **59,900 BUSD** through **0x869c3e3fcc15b801727dabca6cdfeba89e743327**. Both reach **0xa96be652a08d9905f15b7fbe2255708709becd09**. All four direct transfer inputs and successful receipts match; the intermediary delays are **117** and **104 seconds**, respectively. **100 + 59,900 = 60,000** exactly.
- Hinata's separately documented onward transfer occurred **528 seconds** after its final claim. The selected inflow-minus-outflow difference is exactly **0.00000000091766931 BUSD**.

## Precision and label checks

The financial totals use exact RPC event integers. The independent review found actual differences in the discovery indexer's displayed raw values—for example, 59,900 BUSD was represented there with an extra **1,048,576 base units**. Those approximations were not used in the reported amounts.

The final address is supported by root's saved **BSC-specific OKLink** source record with label **ChangeNOW. Withdraw_1**, alongside the separately recorded Blockscan/Ethereum label. The chain-qualified source URL and full address match the receipt destination. Per the bounded review instruction, these label sources were not fetched again. The label remains explorer attribution; the actual BSC transfers are independently established by RPC receipts.

## Boundaries retained

The review does not turn the observed sequence into proof of exclusive source attribution within the 77bf account, a measured historical zero starting balance, a ChangeNOW order/customer/output mapping, or a personal receipt by Laura. The **526.6449367719358245 BUSD** difference between Circularr's selected inflows and the 60,000 outflow is arithmetic, not a newly measured remaining wallet balance. Timestamp checks used the consistent historical block-timestamp fields supplied in the raw RPC logs; no additional historical block-header fetch was performed.

The reviewed sample is 18 withdrawals for six other projects, not a census of all 153 pools and not a recovery of the original Mintlayer settlement receipts. The supplied memo states these limitations appropriately. The runtime's ability to discard a false token-return boolean does not weaken these 18 particular receipt findings: each independently includes the actual BUSD transfer log, rather than relying only on claimed flags or claim events.
