import importlib.util,json,pathlib
P=pathlib.Path(__file__).parent;s=importlib.util.spec_from_file_location('r',P/'rpc_helper.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
blocks=[13455169,13455188,17073210]
qs=[{'jsonrpc':'2.0','id':i+1,'method':'eth_getBlockByNumber','params':[hex(b),True]} for i,b in enumerate(blocks)]
x=r.rpc('indexed_blocks',qs);matches=[]
for row in x or []:
 if not row.get('result'):print(row);continue
 b=row['result'];ts=b.get('timestamp')
 for t in b['transactions']:
  if t.get('to')==r.A or t.get('from')==r.A:matches.append({'block_timestamp':ts,**t})
(P/'indexed_d975_transactions.json').write_text(json.dumps(matches,indent=2));print(json.dumps(matches,indent=2)[:18000])
