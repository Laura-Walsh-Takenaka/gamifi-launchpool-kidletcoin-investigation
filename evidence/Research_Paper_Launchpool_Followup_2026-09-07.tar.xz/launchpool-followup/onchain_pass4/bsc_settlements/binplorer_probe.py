import json,urllib.request,pathlib,datetime,hashlib,time
P=pathlib.Path(__file__).parent
queries=[('binplorer_owner_transactions','https://api.binplorer.com/getAddressTransactions/0x77bfe8d704b1948374bf8dab8328a810b2836e66?apiKey=freekey&limit=100&showZeroValues=true'),('binplorer_contract_history','https://api.binplorer.com/getAddressHistory/0xd975b13cdf91de3aa0e0e888fb827fec3650624a?apiKey=freekey&limit=100')]
records=[]
for name,u in queries:
 r={'url':u,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Public-record-research/1.0'}),timeout=35) as z:
   b=z.read();r.update(status=z.status,sha256=hashlib.sha256(b).hexdigest());(P/(name+'.response')).write_bytes(b);r['preview']=b.decode()[:2000]
 except Exception as e:r['error']=str(e)
 (P/(name+'.receipt.json')).write_text(json.dumps(r,indent=2));records.append(r);print(json.dumps(r,indent=2));time.sleep(1)
