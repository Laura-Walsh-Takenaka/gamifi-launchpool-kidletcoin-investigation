import importlib.util,json,pathlib,datetime
from decimal import Decimal,getcontext
getcontext().prec=80;P=pathlib.Path(__file__).parent;s=importlib.util.spec_from_file_location('r',P/'rpc_helper.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
hashes=['0xdb7e8484e7e4c791a93f88794bd376fab580bfa8ca89606e4cbe2a908200e800','0x8e6a1250a9c8ad44355b73f28ca417c695996359804315c5064a027ad08584b0','0x6330c83f1fb369310252045d55667ad35ee44de6542df02abf721d3760c44162','0x4b3cd1c39ec640f3aeb64e13676cd526ff8200211c57f202c00c5f0f736861b1']
qs=[{'jsonrpc':'2.0','id':i+1,'method':'eth_getTransactionReceipt','params':[h]} for i,h in enumerate(hashes)]+[{'jsonrpc':'2.0','id':len(hashes)+i+1,'method':'eth_getTransactionByHash','params':[h]} for i,h in enumerate(hashes)]
raw=r.rpc('circularr_exit_receipts',qs);by={x['id']:x for x in raw or []};out=[]
for i,h in enumerate(hashes,1):
 rec=by[i].get('result');t=by[i+len(hashes)].get('result');assert rec and t and rec['transactionHash']==h and rec['status']=='0x1' and t['from']==rec['from'];transfers=[]
 for l in rec['logs']:
  if l['address']=='0xe9e7cea3dedca5984780bafc599bd69add087d56' and l['topics'][0]=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef':
   n=int(l['data'],16);transfers.append({'from':'0x'+l['topics'][1][-40:],'to':'0x'+l['topics'][2][-40:],'amount_raw':str(n),'amount_busd':format(Decimal(n)/10**18,'f'),'log_index':int(l['logIndex'],16)})
 ts=rec['logs'][0]['blockTimestamp'];row={'tx':h,'block':int(rec['blockNumber'],16),'block_hash':rec['blockHash'],'timestamp_from_rpc_log':int(ts,16),'utc':datetime.datetime.fromtimestamp(int(ts,16),datetime.timezone.utc).isoformat(),'caller':rec['from'],'destination':rec['to'],'success':True,'input':t['input'],'busd_transfers':transfers};out.append(row)
 assert len(transfers)==1 and transfers[0]['from']==t['from'];assert t['input'][:10]=='0xa9059cbb';assert '0x'+t['input'][10:74][-40:]==transfers[0]['to'];assert str(int(t['input'][74:138],16))==transfers[0]['amount_raw']
(P/'circularr_exit_verified.json').write_text(json.dumps(out,indent=2))
for q in out:print(q['utc'],q['tx'],q['caller'],[(e['amount_busd'],e['to']) for e in q['busd_transfers']])
