import importlib.util,json,pathlib,datetime
from decimal import Decimal,getcontext
getcontext().prec=80;P=pathlib.Path(__file__).parent;s=importlib.util.spec_from_file_location('r',P/'rpc_helper.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
claims=[x for x in json.loads((P/'owner_calls_decoded.json').read_text()) if x['method']=='claimFundRaising(uint256)'];extra=['0x961b7f971bf3e7022dba7670582b14e40f2b88cae7c82d02c111d72f94455de4','0xdd2f6f2a0947f5399476cf91b3828d744716930b3380acff9cceac29be8c42d9'];hashes=[x['tx'] for x in claims]+extra
qs=[{'jsonrpc':'2.0','id':i+1,'method':'eth_getTransactionReceipt','params':[h]} for i,h in enumerate(hashes)]+[{'jsonrpc':'2.0','id':len(hashes)+i+1,'method':'eth_getTransactionByHash','params':[h]} for i,h in enumerate(extra)]
raw=r.rpc('claim_and_onward_receipts',qs);by={x['id']:x for x in raw or []};out=[]
for i,h in enumerate(hashes,1):
 rec=by[i].get('result');assert rec and rec['transactionHash']==h and rec['status']=='0x1';transfers=[];events=[]
 for l in rec['logs']:
  if l['address']=='0xe9e7cea3dedca5984780bafc599bd69add087d56' and l['topics'][0]=='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef':
   n=int(l['data'],16);transfers.append({'from':'0x'+l['topics'][1][-40:],'to':'0x'+l['topics'][2][-40:],'amount_raw':str(n),'amount_busd':format(Decimal(n)/10**18,'f'),'log_index':int(l['logIndex'],16)})
  if l['address']==r.A and l['topics'][0]=='0x90b6b0d5b4b6169cc45fd20c2536a9d57c31e428447bd18963c0210541a87089':
   events.append({'pid':int(l['topics'][1],16),'recipient':'0x'+l['topics'][2][-40:],'amount_raw':str(int(l['data'],16)),'log_index':int(l['logIndex'],16)})
 ts=rec['logs'][0].get('blockTimestamp');row={'tx':h,'block':int(rec['blockNumber'],16),'block_hash':rec['blockHash'],'timestamp_from_rpc_log':int(ts,16) if ts else None,'utc':datetime.datetime.fromtimestamp(int(ts,16),datetime.timezone.utc).isoformat() if ts else None,'caller':rec['from'],'destination':rec['to'],'success':True,'busd_transfers':transfers,'fundraising_claim_events':events}
 if i<=len(claims):
  c=claims[i-1];assert len(events)==1 and events[0]['pid']==c['first_parameter'];assert len(transfers)==1 and events[0]['recipient']==transfers[0]['to'] and events[0]['amount_raw']==transfers[0]['amount_raw'];row['input_pid_matches_event']=True;row['event_matches_busd_transfer']=True
 else:
  t=by[len(hashes)+extra.index(h)+1]['result'];row['input']=t['input'];assert t['from']==rec['from']
 out.append(row)
(P/'claims_and_onward_verified.json').write_text(json.dumps(out,indent=2))
for q in out:print(q['utc'],q['tx'],[(e['pid'],e['recipient']) for e in q['fundraising_claim_events']],[(e['amount_busd'],e['to']) for e in q['busd_transfers']])
