from pathlib import Path
import urllib.request,json,datetime,hashlib
P=Path(__file__).parent
ids=[146,147,148,39,40,41,56,57,58,80,81,82,134,135,136,68,69,70]
fields=['slug','title','contractAddress','network','pools','targetraise','publicStartBlock','tokenAllocStartBlock','stakingEndBlock','pledgeFundingEndBlock','publicStartDate','stakingEndDate','pledgeFundingEndDate']
q={'structuredQuery':{'from':[{'collectionId':'projects'}],'select':{'fields':[{'fieldPath':x} for x in fields]},'where':{'fieldFilter':{'field':{'fieldPath':'pools'},'op':'ARRAY_CONTAINS_ANY','value':{'arrayValue':{'values':[{'stringValue':str(x)} for x in ids]}}}},'limit':30}}
u='https://firestore.googleapis.com/v1/projects/lpstakeapp/databases/(default)/documents:runQuery'
(P/'project_query.json').write_text(json.dumps(q,indent=2))
r={'url':u,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Bounded read-only public sale-project mapping for 18 pool IDs present in independently recovered D975 owner transactions; projected sale fields only; no user collections.'}
try:
 with urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(q).encode(),headers={'Content-Type':'application/json','User-Agent':'Public-record-research/1.0'}),timeout=30) as z:b=z.read();r['status']=z.status
 (P/'project_query_response.json').write_bytes(b);r.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());print(b.decode()[:500])
except urllib.error.HTTPError as e:
 b=e.read();r.update(status=e.code,error=str(e),error_body=b.decode());print(b.decode())
except Exception as e:r['error']=str(e);print(str(e))
(P/'project_query_receipt.json').write_text(json.dumps(r,indent=2))
