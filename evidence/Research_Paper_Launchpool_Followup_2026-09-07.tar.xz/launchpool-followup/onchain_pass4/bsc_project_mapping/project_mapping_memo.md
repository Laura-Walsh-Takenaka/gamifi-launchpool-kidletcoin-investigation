# Mapping recovered D975 payout pool IDs to Launchpool projects

The parallel BSC settlement lane recovered owner transactions for 18 additional D975 pool IDs. One read-only public Firestore query searched only those IDs and projected public sale configuration fields. It returned ten project records at **2026-09-07 06:47:08.889785 UTC**. Six match both D975 and BSC; four use a different contract or network and are excluded from these mappings.

| D975 pool IDs | Project | Configuration's displayed sale start | Configuration's last update |
|---|---|---|---|
| 146, 147, 148 | Circularr | 8 May 2022, 23:00 UTC | 20 June 2022 |
| 39, 40, 41 | Hinata | 6 December 2021, 09:00 UTC | 15 April 2024 |
| 56, 57, 58 | 5ire | 13 December 2021, 10:00 UTC | 15 April 2024 |
| 80, 81, 82 | Yesports | 17 January 2022, 10:00 UTC | 4 September 2024 |
| 134, 135, 136 | Spark World | 11 April 2022, 08:00 UTC | 20 April 2023 |
| 68, 69, 70 | Championfy | 10 January 2022, 09:00 UTC | 15 April 2024 |

All six records explicitly name **0xD975B13CDF91de3AA0e0E888fb827Fec3650624A** and network **BSC**. This is a current read of older configuration records, not proof each field was unchanged since its displayed sale date. Exact schedule blocks are preserved for independent comparison with the contract's pool states. Target figures are published configuration fields and are not receipt totals.

The four excluded results demonstrate why pool numbers alone are insufficient: Alium Finance, Chain and Polkacipher use the older BSC 7134 deployment, while Amplifi uses an Arbitrum contract. Pools 80–82 map to **Yesports**, not GamiFi. None of these six project mappings substitutes for the already established Mintlayer pools 19–21 and 125–127.

The public app's Firestore project ID and `projects` collection were recovered from the archived official application in pass 3. This bounded query used `ARRAY_CONTAINS_ANY` over the 18 requested string IDs, limit 30, and selected only slug, title, contract, network, pool IDs, target and schedule fields. No user, investor, KYC, wallet login or credential record was requested. The raw response, exact query, decoded records, receipt and hashes are retained here.

The mapping supplies project labels for independently verified on-chain transactions; it does not itself verify those transactions, their cash amounts, exchange customers, Laura's involvement or human ownership of any wallet.
