"""Seventh integrated pass: deeper service routes, custody continuity, and source accounting."""
def add_pass7(B):
    changes=[
      ('Specific unresolved records: D975 withdrawal transactions and BUSD recipients; wallet signers and corporate mandates; KuCoin/MEXC customer mappings; complete purchase-to-tranche reconciliation; and actual native Mintlayer delivery. Current job titles, shared funding and explorer labels do not resolve those questions.',
       'The D975 original withdrawal receipts and recipients are now recovered in sections 9.19-9.24. Remaining records include wallet signers and corporate mandates, exchange customer mappings, complete purchase-to-tranche reconciliation, and actual native Mintlayer delivery. Public roles and explorer labels do not identify a human key holder. [F46-F53]'),
      ('Raise 1 closes at <b>66,047.442300766942811912 BUSD</b>; the next window opens at that same amount. Raise 2 closes at <b>7,424.678430731639424238 BUSD</b>. The windows run from 3 November 09:02:17 to 4 November 09:02:17, and from 4 November 13:59:08 to 5 November 13:59:08 UTC. Equal balances across the intervening gap do not prove no intervening activity. These are historical balances, not September 2026 reserves. [F47]',
       'Raise 1 closes at <b>66,047.442300766942811912 BUSD</b>; the next window opens at that same amount. Raise 2 closes at <b>7,424.678430731639424238 BUSD</b>. The original windows cover 3-4 and 4-5 November 2022. Section 9.24 now closes the intervening gap with complete zero-event BUSD queries and matching historical balances, allowing continuous owner reconciliation. These are historical balances, not September 2026 reserves. [F47; F52]'),
    ]
    for old,new in changes:
      matches=[b for b in B if b.get('text')==old];assert len(matches)==1,old[:70];matches[0]['text']=new
    def p(t,k='p'):B.append({'kind':k,'text':t})
    def h(t):p(t,'h')
    def h2(t):p(t,'h2')
    def page():B.append({'kind':'break'})
    def table(rows,widths):B.append({'kind':'table','rows':rows,'widths':widths})

    page();h('9.23 Three more BUSD routes converge at Binance')
    p('<b>Three additional branches sent 222,090.52 BUSD to Binance 51 on 3 November 2022.</b> Of that amount, 222,000 arrived through the already traced owner-payment chain; 90.52 was an intermediary\'s prior balance. Together with the earlier two transfers, the endpoint received <b>276,460.52 BUSD in five payments</b>, including 276,370 from the traced chain. These are further hops of previously counted funds. [F47; F51]')
    p('Binance 51 endpoint: <font face="DVM" size="7.2">0x8894e0a0c962cb723c1976a4421c95949be2d4e3</font><br/>Token: canonical BSC BUSD, <font face="DVM" size="7.2">0xe9e7cea3dedca5984780bafc599bd69add087d56</font>','small')
    table([
      ['Path before Binance','Endpoint BUSD','UTC on 3 November','Delay after receipt'],
      ['1991 > 0d434','200,000','11:00:28','19m 44s'],
      ['1991 > ab3c','2,090.52','12:00:37','29m 24s'],
      ['f98 > 57e898','20,000','13:00:41','18m 52s'],
      ['New three transfers','222,090.52','',''],
      ['Earlier two via 14c840','54,370','09:38:08 / 10:00:27','See section 9.20'],
      ['Five-transfer total','276,460.52','',''],
    ],[155,106,125,113])
    h2('Each intermediary has a reconciled historical balance')
    p('0d434 and 57e898 opened at zero, received 200,000 and 20,000 respectively, sent the full amounts to Binance, and closed at zero. ab3c opened with 90.52, received 2,000 from 1991, then sent 2,090.52 and closed at zero. Complete first-window logs, successful official BNB receipts, matching token calldata and archive balance calls agree. [F51]')
    h2('Original-raise source amount')
    p('After excluding ab3c\'s 90.52 and allowing for 77bf\'s pre-existing 0.332011149154053912 BUSD, the original Mintlayer Raise 1 contribution to these five endpoint payments is bounded at <b>276,369.667988850845946088-276,370 BUSD</b>. Independent chronological allocations make both endpoints feasible. This is a conservation bound using captured histories and historical states; it assigns neither investor entitlements nor payment purposes. [F47; F51]')
    h2('A second use of the same intermediary')
    p('The later continuation finds cedfa sending another 225,000 BUSD to 57e898. The following section records its onward disposition and keeps this later interval separate from the five first-day payments above. [F51-F52]')
    p('The exact public explorer label identifies Binance 51. The route does not establish which customer received credit, what happened inside the exchange, or who controlled the sending wallets. Full addresses, transaction hashes and timestamps are in the evidence. No human identity is assigned to an unlabeled intermediary based on its transfer pattern. [F51]','small')

    page();h('9.24 Owner continuity and later BUSD custody')
    p('<b>Another 225,000 BUSD reached Binance 51 on 7-8 November 2022.</b> Cedfa received the second 200,000-BUSD payment from f98, then sent 10, 124,990 and 100,000 to 57e898. That intermediary forwarded 125,000 and 100,000 to Binance, with a complete zero-opening/zero-closing BUSD ledger for the reviewed week. All six route events have successful raw receipts. [F51-F52]')
    table([
      ['Binance transfer from 57e898','UTC','Delay after final input'],
      ['125,000 BUSD','7 Nov 2022 20:30:06','21m 25s'],
      ['100,000 BUSD','8 Nov 2022 10:30:06','27m 06s'],
      ['Combined later endpoint amount','225,000 BUSD',''],
    ],[217,163,119])
    h2('Seven endpoint payments, with prior funds separated')
    p('The seven unique Binance receipts across 3, 7 and 8 November total <b>501,460.52 BUSD</b>. The original Mintlayer contribution is bounded at <b>501,153.870312770845946088-501,370 BUSD</b>. The interval excludes ab3c\'s 90.52 and allows for cedfa\'s prior 215.79767608 and the owner\'s prior 0.332011149154053912 BUSD. The small owner balance is counted once across the joint route. Both chronological extremes are feasible. [F47; F51-F52]')
    h2('The owner-window gap is now closed')
    p('Both-direction BUSD queries over blocks 22,760,779-22,766,631 returned zero events, and historical balances at both boundaries equal 66,047.442300766942811912 BUSD. Combined with the original windows and the extension, the owner now has a continuous captured BUSD history from the first withdrawal through 12 November 2022. Its accounting remains: opening 0.332011149154053912 + six receipts of 903,794.346419582485370326 - eleven payments of 896,370 = 7,424.678430731639424238 BUSD. [F46-F47; F52]')
    h2('What remained at the historical cutoffs')
    table([
      ['Wallet','BUSD balance','Cutoff UTC in November 2022'],
      ['77bf','7,424.678430731639424238','12 Nov / 13:59:08'],
      ['bf7f','150,000','12 Nov / 13:59:08'],
      ['8724','25,197.437915171993026378','12 Nov / 13:59:08'],
      ['f98 / 57e898','0 / 0','12 Nov / 13:59:08'],
      ['cedfa','180,205.79767608','10 Nov / 09:02:17'],
      ['dc127','40,663','10 Nov / 09:02:17'],
    ],[82,211,206])
    p('The 8724 and dc127 balances include 197.437915171993026378 and 663 BUSD already held before the traced payments. Cedfa also had the prior funds identified above. These are dated custody balances, not amounts confirmed to remain today or a loss estimate. Address windows and overlapping first-day captures are kept distinct. [F51-F52]','small')
    p('No later period beyond the stated cutoffs was scanned in this pass. Successful smaller, slower log batches resolved the preserved rate limits. Exchange customer identity, payment mandate and human signing-key custody remain unresolved. [F51-F52]','small')

    page();h('9.25 A returned-funds recipient connects to Kraken')
    p('<b>Wallet 47da later sent 75,000 USDC and 300,000 USDT through dcea into Kraken-labeled collection wallets.</b> The exact sweeps are verified, including successful receipts and transferFrom calls made by the labeled receiving wallets. These service routes extend the address trail, but the sender\'s prior balances prevent assigning them specifically to the earlier trading returns. [F48; F53]')
    p('Intermediary: <font face="DVM" size="7.2">0xdcea03a2a2b8647ae787c4c518dbea1c54ac86d2</font><br/>Kraken 10: <font face="DVM" size="7.2">0xae2d4617c862309a3d75a0ffb358c7a5009c673f</font><br/>Kraken 7: <font face="DVM" size="7.2">0x89e51fa8ca5d66cd220baed62ed01e8951aa7c40</font>','small')
    table([
      ['Asset','47da > dcea','dcea > Kraken','Collection delay'],
      ['75,000 USDC','18 Jul 2024 19:00:11','Kraken 10 / 19:09:47','9m 36s'],
      ['300,000 USDT','18 Jul 2024 18:59:47','Kraken 7 / 19:09:47','10m'],
    ],[107,151,148,93])
    p('All times are UTC. dcea\'s captured USDC and USDT cycles each begin at zero and end at zero, with one receipt and one exact sweep. The named Kraken wallet called the token contract to collect each amount from dcea. This supports exchange collection mechanics; it does not label dcea\'s customer or identify a human controller. [F53]')
    h2('Why the trading return cannot be assigned to these sweeps')
    p('Before receiving the selected 32,500-USDC payment from 2c94, 47da already held <b>136,210.313376 USDC</b>. Before the separate 8,720.1948-USDT receipt, it held <b>875,068.711065 USDT</b>. The 8,720.1948-USDT receipt predates the 23 July trading return. These are successful historical-state reads. The prior funds are sufficient to fund the later Kraken paths, so no positive amount from the selected incoming payments is mathematically forced into either sweep. [F48; F53]')
    p('47da\'s full captured window reconciles 15 USDC events and 69 USDT events against independently queried opening and closing states. Other inflows and outflows remain in the ledger. The 75,000 and 300,000 are separate token amounts and are not added to fundraising proceeds, missing funds or trading profits. [F53]')
    h2('The separate d541 branch waited more than five days')
    p('Before its 318,192.18-USDC receipt on 24 July, d541 held 228,092.803239 USDC. No outgoing USDC transfer occurred during the next 24 hours. The bounded extension finds one later payment: <b>21,664 USDC</b> to 0585 on 30 July at 06:47:35 UTC. Its existing funds exceed that payment, so the source is not unique. The extension follows outgoing USDC only through 31 July 17:23:35 UTC; it is not a complete week-long incoming ledger. [F53]')
    p('The endpoint addresses supply specific service-record leads. No exchange customer, fiat withdrawal, corporate mandate or Laura\'s personal receipt has been identified. Later histories beyond these explicit windows remain outside this pass. [F53]','small')

    page();h('9.26 IAG USDC: the complete initial disposition')
    p('<b>The 191,393.685754-USDC IAG pool receipts now reconcile through the initial distribution, with a shared 20-USDC outside contribution.</b> That contribution is additionally verified by two successful raw dRPC receipts from the canonical USDC contract. Its lookalike senders remain unattributed. The earlier source histories still supply the zero starting event balances. [F38; F48; F50; F54]')
    table([
      ['Initial destination or retained balance','USDC'],
      ['KuCoin deposit 4d0d via 1991','80,750'],
      ['Base funding via 1991 > 183600','27,100'],
      ['Payments from 1991 to 2c94','19,200'],
      ['Payment from 1991 to 0008','11,500'],
      ['Still at 1991 before 18 July return','11,460'],
      ['MEXC route via 9118','10,000'],
      ['Separate route via 3b4d','31,403.685754'],
      ['Total disposition / retained balance','191,413.685754'],
      ['Less outside receipts','20'],
      ['IAG pool contribution','191,393.685754'],
    ],[334,165])
    p('The first five rows sum to the 150,010 USDC received by 1991. It paid 138,550 before the first trading return, leaving 11,460. The separate 10,000 and 31,403.685754 branches originate directly from 77bf. This partition excludes the later returned funds and avoids counting transfers between these wallets twice. [F54]')
    h2('The exchange-source interval is now explicit')
    p('The previously verified KuCoin and MEXC routes total <b>90,750 USDC</b>. Conditional on complete captured histories, <b>90,730-90,750 USDC</b> of that combined amount came through the IAG pool receipts. Including the separately verified 27,100-USDC Base funding gives a combined source interval of <b>117,830-117,850 USDC</b>. Independent chronological allocations verify both extremes. [F38; F50; F54]')
    p('Only one 20-USDC outside budget exists across the entire distribution. Individual branch minimums cannot be added as though each branch contained another 20 outside USDC. The calculation uses neither FIFO nor proportional allocation. It measures source constraints; it does not determine authorized use, investor entitlement or ownership of trading returns. [F54]')
    h2('What the new checks did and did not resolve')
    p('The two outside-input receipts are now raw-RPC verified. Publicnode returned null before dRPC succeeded; both outcomes are preserved. A new historical balance request for the original source wallets returned HTTP 403 and supplies no state evidence, so the source intervals retain their event-history completeness condition. Successful state reads for the separate Kraken-route wallets do not replace this missing source-wallet check. [F53-F54]')
    p('Bounded exact-address public searches found no reliable corporate declaration or human signing-key attribution for the selected original BUSD recipients. Generic analytics pages, NFT ownership records and API-documentation examples were not treated as proof of company ownership or Laura\'s control. [F54]','small')
    return [
      ('F51','Original BUSD: three more Binance routes and later convergence','https://blockscan.com/Address/0x8894e0a0c962cb723c1976a4421c95949be2d4e3','onchain_pass7/busd_branches/ and peer_review/: canonical logs, official BNB receipts/calldata, historical balances, exact delays and source bounds. Three new sweeps add 222,090.52 BUSD gross, including 90.52 previously held. Later cedfa/57e898 convergence is separately reconciled; no customer identity inferred.'),
      ('F52','Owner gap closure and bounded retained-funds continuation','https://bscscan.com/address/0x77bfe8d704b1948374bf8dab8328a810b2836e66','onchain_pass7/owner_and_retained/ and peer_review/: exact zero-event gap, state-backed continuous original withdrawal accounting, first-day checks and bounded later custody/outflow records. Seven Binance payments total 501,460.52 BUSD; the joint original-source interval accounts for all prior balances. Retrieval limits and historical cutoffs are preserved; later transfers are not new fundraising.'),
      ('F53','Kraken collection mechanics and mixed-funds limits','https://etherscan.io/address/0xae2d4617c862309a3d75a0ffb358c7a5009c673f','onchain_pass7/returned_branches/ and peer_review/: successful raw receipts and transferFrom calldata, exact USDC/USDT cycles, primary explorer labels, independent historical balances and bounded d541 outgoing continuation. Prior funds prevent exclusive allocation of the selected returns to Kraken.'),
      ('F54','Initial IAG disposition and shared-source bounds','https://etherscan.io/tx/0xdb32b44e9cb8048521ee3d350c5fdcc3175db307bf8779887f9fa0a0b6c9ecc4','onchain_pass7/iag_allocation/, historical_state/, entity_checks/ and peer_review/: seven-part exact USDC partition; two newly successful outside-input receipts; shared 20-USDC budget and feasible joint intervals. Failed source-wallet state probe preserved. Public searches did not supply a human/controller attribution.'),
    ]
