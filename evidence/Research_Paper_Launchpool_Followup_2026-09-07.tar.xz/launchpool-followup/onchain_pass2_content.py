"""Second read-only on-chain pass, integrated into the preserved master."""
def add_pass2(B):
    def p(t,k='p'):B.append({'kind':k,'text':t})
    def h(t):p(t,'h')
    def h2(t):p(t,'h2')
    def page():B.append({'kind':'break'})
    def table(rows,widths):B.append({'kind':'table','rows':rows,'widths':widths})
    page();h('9.9 Upstream ML and the treasury-owned Safe')
    p('<b>The June funding can now be reconciled one step further upstream.</b> The unidentified account 0x77bf...6e66 received ML from earlier contracts and other wallets before funding the current treasury. Its recovered 90 ML events total 31,915,885.437859292120865343 ML in and the same amount out. This includes repeated movement of tokens; it is not money raised or new investor allocations. [F27]')
    table([
        ['Immediate funding calculation','Exact ML'],
        ['Carried balance before 29 May 2025','675,375.086483023767618475'],
        ['29 May: received from contract 0x4d7b...f0a9','571,273.64975205313681756'],
        ['29 May: sent to a separate Safe address','-10'],
        ['2-3 June: combined transfers to current treasury','1,246,638.736235076904436035'],
    ],[277,222])
    p('At 11:10:47 UTC on 29 May, a call by 0x77bf...6e66 caused the 571,273.64975205313681756 ML transfer from 0x4d7b84910d042f5431b156397bff0db5ebb4f0a9. The explorer labels the method Transfer Remaining To Owner. The source remains unverified. Section 9.12 now verifies the selected owner/time checks in deployed bytecode and reconciles earlier holder payments; the explorer label alone was insufficient. [F27]')
    p('Withdrawal transaction:','small')
    p('0xf86225aedc2adce03c53e006d295c8241623154d664ecd92b45f1c3dec3e8769','code')
    h2('A second wallet under the current treasury owner')
    p('Safe: <font face="DVM" size="7.4">0x03fafab75267cdf75c64a1c86188e612205b455e</font>','small')
    table([
        ['29 May 2025 UTC','Observed sequence'],
        ['11:12:35','0x77bf...6e66 sends 10 ML to the future Safe address.'],
        ['12:11:23','0x1aafe...8da0f sends 0.01 ETH to treasury 0x6c2b...929c4.'],
        ['12:12:11','Treasury creates the Safe with itself as sole owner and threshold 1.'],
    ],[115,384])
    p('Official Safe creation data and independently decoded initialization bytes agree. At block 25,923,475, fresh RPC reads show the same sole owner, threshold 1, nonce 0 and <b>10 ML still held in the Safe</b>. This is separate from the fully backed final distributor. A threshold of one does not require a second owner\'s approval. Modules and guards were not audited. [F28]')
    p('The ML transfer precedes creation by 59 minutes 36 seconds. Prefunding a predicted address is plausible; an attempted historical code check was denied for lack of archive access. The sequence supports an operational link between the upstream wallet and treasury arrangement, but identifies no human controller or company mandate. [F27-F28]','small')

    page();h('9.10 Control evidence, exchange leads and refreshed state')
    h2('The upstream wallet exercised fundraising authority')
    p('On 2 July 2024, 0x77bf...6e66 successfully called claimFundRaising for pools 9 and 10 in verified contract 0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf, receiving a combined <b>191,393.685754 USDC</b>. The function is restricted to the owner and pays owner(). This establishes wallet-level administrative control at those calls. Current poolInfo reads identify IAGON (IAG) as the reward token for both pools, matching IAGON\'s published token address. These are IAG-pool receipts, not the missing Mintlayer BUSD payment trail. [F31]')
    h2('The distributor deployer has exchange-facing routes')
    table([
        ['Observed route','Meaning and boundary'],
        ['5 June 2025: 90,843 TLOS sold; net 4,761.97158 USDC received by deployer','Exact USDC amount sent to 0xaa3f...b2d1 and then, four minutes later, to Etherscan-labeled Coinbase 10 (0xa9d1...3e43). Three successful transaction/receipt pairs verify the route. These are TLOS sale proceeds. [F29]'],
        ['2 October 2025: deployer sends 0.006568313627127521 ETH to 0xc989...26ed','That address later sends 0.006559021031199521 ETH to Coinbase 44 (0xb5d8...f511) on 22 August 2026. The long interval and incomplete intervening flows prevent a closed funds reconciliation. [F29]'],
    ],[226,273])
    p('These are precise account-mapping leads, not evidence of the exchange customer\'s identity. Labels are Etherscan attributions, not customer records. No ML event appears in the retained 105-event deployer token history, and neither route establishes diversion of the final distributor balance or a transfer to Laura. [F29]','small')
    h2('Earlier contract gap closed; final allocation unchanged')
    p('At Ethereum block <b>25,923,475, 7 September 2026 05:45:47 UTC</b>, the July contract has zero ML and all eight claim bitmap words zero. Successful explorer history returns creation only and zero token transfers, with pagination complete. It appears unused in these records; this does not prove an operational replacement or add a second set of debts. [F30]')
    table([
        ['Final distributor, refreshed state','Result'],
        ['Claimed / unclaimed indices','119 / 1,880'],
        ['Unclaimed ML entitlement','1,116,040.8456174469614254'],
        ['ML held by distributor','1,116,041.281767546177360307'],
        ['Balance above unclaimed amount','0.436150099215934907'],
    ],[277,222])
    p('All eight bitmap words, owner, treasury, token, root and balance match the preceding snapshot. A fresh full final-contract transfer history was not fetched. The remaining gap is attribution and mandate: who controls 0x77bf...6e66 and 0x6c2b...929c4, who receives the exchange credits, and which signed investor obligations each arrangement serves. Nothing here establishes Laura as beneficiary or a deadline-triggered transfer. [F27-F31]','small')
    return [
        ('F27','Upstream ML event reconstruction','https://etherscan.io/address/0x77bfe8d704b1948374bf8dab8328a810b2836e66','onchain_pass2/ml_origin/: 131 token rows recovered, 90 ML events, exact running ledger and independent parser/arithmetic check. May 29 caller/transfer and source-verification limits preserved; F35 adds selected runtime and earlier-payment checks. Gross turnover is not money raised.'),
        ('F28','Treasury-owned Safe and pinned state','https://safe-transaction-mainnet.safe.global/api/v1/safes/0x03FAFab75267CdF75c64a1c86188E612205B455E/creation/','onchain_pass2/gas_control/: official creation/history records, initializer decoding and root RPC requests/results. Current sole owner, threshold 1, nonce 0 and 10 ML at block 25,923,475. Archive-code query denied; no bypass.'),
        ('F29','Deployer routes and exchange labels','https://etherscan.io/tx/0x9f2022618d5326b97338f704ebf394485a48f083ff92942fe7c55951bffb4420','onchain_pass2/deployer/: four transaction/receipt pairs, exact CSV and independent review. Etherscan address labels identify Coinbase 10/44, not customers; Coinbase 10 pairing also in docs.etherscan.io/api-reference/endpoint/getaddresstag.'),
        ('F30','Earlier/final distributor state refresh','https://eth.blockscout.com/api/v2/addresses/0xaf6a981053942dd8cb1ee99c37f99227ed7ca34b/token-transfers','onchain_pass2/distributors/: successful pinned PublicNode reads, explicit empty old transfer history and creation-only normal history. Block hash 0x649e3846d637a57dfa2efdc0ab4173b42c3d339b017aab2ab979361ef60c5622. Optional dRPC state crosscheck failed HTTP 500.'),
        ('F31','Fundraising-owner USDC receipts','https://etherscan.io/address/0x689cf22e945466340f2e0bfd80ac8ee398ab9ecf#code','onchain_pass2/cash_custody/: two 2 July 2024 successful claims, verified source and exact received USDC. Current poolInfo reward-token fields identify IAG, corroborated by blog.iagon.com/iagon-smart-contract-audited-by-gordian-agency/. Source has no reward-token setter; these are not Mintlayer BUSD receipts.'),
    ]
