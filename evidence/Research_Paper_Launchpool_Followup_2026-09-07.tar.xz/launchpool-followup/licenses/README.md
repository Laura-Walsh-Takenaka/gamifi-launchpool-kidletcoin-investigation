# Source-code licenses

The preserved deployed MerkleDistributor source declares GPL-3.0-or-later. Its SPDX notice is retained and GPL-3.0 is included. Explorer source metadata also contains OpenZeppelin imports with their original license notices. Research scripts are supplied for reproducibility.
